#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v56.0 - Claude Bridge
# Claude CLIの全能力を引き出す知的ブリッジ層
#
# 従来: claude -p --dangerously-skip-permissions --output-format text "巨大プロンプト"
# v56.0: --system-prompt でルール分離 + --append-system-prompt でドメイン注入
#        + --fallback-model で自動フォールバック + --max-budget-usd でネイティブ予算
#        + --json-schema で構造化出力保証 + --tools でツール制御
#
# v56.0: Claude Maximizer
# ============================================================

# --- グローバル状態 ---
CB2_VERSION="178.0"
CB2_INITIALIZED=false
CB2_CALL_COUNT=0
CB2_TOTAL_INPUT_TOKENS=0
CB2_TOTAL_OUTPUT_TOKENS=0
CB2_SYSTEM_PROMPT_CACHE=""
CB2_DOMAIN_CONTEXT_CACHE=""

# --- 設定 ---
CB2_MAX_SYSTEM_PROMPT_CHARS=30000      # system promptの最大文字数
CB2_MAX_USER_PROMPT_CHARS=150000       # user promptの最大文字数
CB2_DEFAULT_TIMEOUT=300                # デフォルトタイムアウト(秒)
CB2_ENABLE_SYSTEM_PROMPT="true"        # --system-prompt使用
CB2_ENABLE_FALLBACK_MODEL="true"       # --fallback-model使用
CB2_ENABLE_NATIVE_BUDGET="true"        # --max-budget-usd使用
CB2_ENABLE_TOOL_CONTROL="false"        # --tools使用（将来拡張）

# ============================================================
# 初期化
# ============================================================
cb2_init() {
    CB2_INITIALIZED=true
    CB2_CALL_COUNT=0
    CB2_TOTAL_INPUT_TOKENS=0
    CB2_TOTAL_OUTPUT_TOKENS=0
    CB2_SYSTEM_PROMPT_CACHE=""
    CB2_DOMAIN_CONTEXT_CACHE=""
    return 0
}

# ============================================================
# システムプロンプト構築
# Claude CLIの --system-prompt に渡すべき「不変のルール・制約」を構築
# ユーザープロンプトからルール部分を分離することで:
# 1. Claudeがルールをより確実に遵守する（system promptの方が権威が高い）
# 2. ユーザープロンプトをタスク記述に集中できる（ノイズ削減）
# 3. プロンプト全体のトークン効率が上がる（ルール部分の重複排除）
# ============================================================
cb2_build_system_prompt() {
    local phase="${1:-implementation}"
    local domain="${2:-general}"
    local project_type="${3:-fullstack}"

    # キャッシュがあればそのまま返す（同一セッション内で不変の部分）
    if [[ -n "$CB2_SYSTEM_PROMPT_CACHE" && "$CB2_SYSTEM_PROMPT_CACHE" == *"$phase"* ]]; then
        echo "$CB2_SYSTEM_PROMPT_CACHE"
        return 0
    fi

    local sys_prompt=""

    # --- 基本ロール定義 ---
    sys_prompt+="あなたはSoloptiLinkAI v56.0のコード生成AIです。
プロダクションレベルの高品質コードを生成する専門家として振る舞ってください。

## 絶対遵守ルール（違反厳禁）
- モックデータ/ハードコード配列/ダミーデータは絶対に使わない → 全てDB永続化
- console.log/print文をプロダクションコードに残さない
- any型（TypeScript）を使わない → 全て適切な型定義
- 空のイベントハンドラ/TODO/FIXME を残さない → 全て実装
- eslint-disable/ts-ignore を使わない
- Date.now()でIDを生成しない → UUID/CUID/nanoid使用
- localStorageをデータストアとして使わない → DB使用

## v120.0 Golden Pattern必須指令
- 全てのUIコンポーネントは後述のGolden Patternに完全準拠して実装すること
- Golden Pattern以外の実装パターンは品質ゲートで自動FAIL
- 「簡潔にするため省略」「同様のパターンで実装」等の手抜きは絶対禁止
- 全てのボタン・フォーム・リスト・モーダルを省略なく完全に実装する
- 全てのページにloading/error/empty/success の4状態を実装する"

    # --- フェーズ別の専門指示 ---
    case "$phase" in
        backend|api|database)
            sys_prompt+="

## バックエンド実装ルール
- 全APIエンドポイントにzodバリデーション必須
- 全async関数にtry-catch + 適切なHTTPエラーレスポンス
- サービス層分離（APIハンドラにビジネスロジック禁止）
- Prisma ORMでDB操作（raw SQL禁止）
- トランザクション（$transaction）を複数テーブル操作時に必須使用
- 監査ログ: 全CUD操作にcreatedBy/updatedBy/deletedAt記録"
            ;;
        frontend|ui_design)
            sys_prompt+="

## フロントエンド実装ルール
- React Hook Form + zodResolverでフォームバリデーション
- useSWR/React Queryでサーバーステート管理
- ErrorBoundaryで全ページをラップ
- ローディング/エラー/空状態を全て実装
- アクセシビリティ: aria-label, role属性必須
- レスポンシブ: モバイルファースト設計

## UI接続性ルール（v100.1 最重要 - 違反は即FAIL）
- 全てのボタンに実動作するonClickハンドラを設定（空ハンドラ/console.logのみ禁止）
- 「新規作成」「編集」等のボタンはrouter.push()で実際のページに遷移させること
- href=\"#\" は絶対禁止 → 実URLを設定
- フォームには必ずonSubmit（API呼び出し+エラーハンドリング+成功時遷移）を実装
- モーダル/ダイアログは開くトリガー(setState(true))を必ず接続
- 削除ボタンは確認ダイアログ→API DELETE→データ再取得を実装"
            ;;
        implementation)
            sys_prompt+="

## フルスタック実装ルール
- バックエンド: zod + Prisma + サービス層 + 監査ログ
- フロントエンド: React Hook Form + SWR + ErrorBoundary
- 認証: JWT RS256 or セッション（有効期限15分以内）
- セキュリティ: helmet, CORS明示オリジン, レート制限
- テスト: 主要ロジックにユニットテスト
- UI接続性: 全ボタンに実動作onClick、href='#'禁止、フォームにonSubmit必須、モーダルに開閉トリガー必須"
            ;;
    esac

    # --- セキュリティルール（常時注入） ---
    sys_prompt+="

## セキュリティ（OWASP準拠）
- パスワード: bcrypt/argon2idハッシュ必須
- SQL: パラメータ化クエリ/ORM使用（SQLインジェクション防止）
- XSS: 出力エスケープ、CSPヘッダー
- CSRF: トークンベース対策
- CORS: 明示的オリジンホワイトリスト（* 禁止）
- 入力: 全外部入力をzod/pydanticでバリデーション"

    # --- 出力形式指示 ---
    sys_prompt+="

## 出力形式
ファイルを出力する場合、各ファイルの前に以下のマーカーを付けてください:
--- FILE: relative/path/to/file ---
ファイル内容をここに記述
--- END FILE ---"

    # v151: Priority-based system prompt management
    if [[ ${#sys_prompt} -gt $CB2_MAX_SYSTEM_PROMPT_CHARS ]]; then
        echo -e "  ⚠️ [v151] System Prompt超過: ${#sys_prompt}/${CB2_MAX_SYSTEM_PROMPT_CHARS}文字 → 優先度ベース切詰" >&2
        # Priority: Security rules > Golden Patterns > Enterprise Patterns > Domain knowledge
        # Remove domain knowledge section first, then EP, then GP
        local _trimmed="$sys_prompt"
        if [[ ${#_trimmed} -gt $CB2_MAX_SYSTEM_PROMPT_CHARS ]]; then
            _trimmed=$(echo "$_trimmed" | sed '/=== ドメイン知識/,/=== ドメイン知識 END ===/d')
            echo -e "  📝 [v151] ドメイン知識セクション除去 → ${#_trimmed}文字" >&2
        fi
        if [[ ${#_trimmed} -gt $CB2_MAX_SYSTEM_PROMPT_CHARS ]]; then
            _trimmed=$(echo "$_trimmed" | sed '/=== Enterprise Patterns/,/=== Enterprise Patterns END ===/d')
            echo -e "  📝 [v151] Enterprise Patternsセクション除去 → ${#_trimmed}文字" >&2
        fi
        if [[ ${#_trimmed} -gt $CB2_MAX_SYSTEM_PROMPT_CHARS ]]; then
            _trimmed="${_trimmed:0:$CB2_MAX_SYSTEM_PROMPT_CHARS}"
            echo -e "  📝 [v151] 最終切詰 → ${CB2_MAX_SYSTEM_PROMPT_CHARS}文字" >&2
        fi
        sys_prompt="$_trimmed"
    fi

    CB2_SYSTEM_PROMPT_CACHE="$sys_prompt"
    echo "$sys_prompt"
}

# ============================================================
# ドメイン別追加システムプロンプト構築
# --append-system-prompt に渡す動的コンテキスト
# ============================================================
cb2_build_append_system_prompt() {
    local phase="${1:-implementation}"
    local domain="${2:-general}"

    local append_prompt=""

    # --- Enterprise Patterns（参照実装テンプレート） ---
    if [[ "${CLI_ENABLE_ENTERPRISE_PATTERNS:-true}" == "true" ]] && type -t ep_inject_for_phase &>/dev/null; then
        local ep_content
        ep_content=$(ep_inject_for_phase "" "$phase" 2>/dev/null || echo "")
        if [[ -n "$ep_content" && ${#ep_content} -gt 20 ]]; then
            append_prompt+="$ep_content
"
        fi
    fi

    # --- セキュリティガイダンス ---
    if [[ "${ENABLE_SECURITY:-true}" == "true" ]] && type -t sg_generate_security_prompt &>/dev/null; then
        local sec_content
        sec_content=$(sg_generate_security_prompt 2>/dev/null || echo "")
        if [[ -n "$sec_content" && ${#sec_content} -gt 20 ]]; then
            append_prompt+="$sec_content
"
        fi
    fi

    # --- データ整合性ルール ---
    if [[ "${ENABLE_DATA_INTEGRITY:-true}" == "true" ]] && type -t di_generate_integrity_prompt &>/dev/null; then
        local di_content
        di_content=$(di_generate_integrity_prompt 2>/dev/null || echo "")
        if [[ -n "$di_content" && ${#di_content} -gt 20 ]]; then
            append_prompt+="$di_content
"
        fi
    fi

    # --- v130.0: 予測的学習注入（Cross-Session + EPLを統合） ---
    if type -t cs_predictive_inject &>/dev/null; then
        local cs_content
        cs_content=$(cs_predictive_inject "$domain" 2>/dev/null || echo "")
        if [[ -n "$cs_content" && ${#cs_content} -gt 20 ]]; then
            append_prompt+="$cs_content
"
        fi
    elif type -t cs_inject_warnings &>/dev/null; then
        # v130.0未対応時のフォールバック
        local cs_content
        cs_content=$(cs_inject_warnings "" "${domain}" 2>/dev/null || echo "")
        if [[ -n "$cs_content" && ${#cs_content} -gt 20 ]]; then
            append_prompt+="$cs_content
"
        fi
    fi

    # --- 過去の成功パターン（Prompt Memory） ---
    if type -t mm_recall_long &>/dev/null; then
        local mem_content
        mem_content=$(mm_recall_long "$phase" 2>/dev/null || echo "")
        if [[ -n "$mem_content" && ${#mem_content} -gt 20 ]]; then
            append_prompt+="
[過去の成功パターン]
$mem_content"
        fi
    fi

    # --- Learning Hub知見 ---
    if type -t lh_build_intelligence_context &>/dev/null; then
        local lh_content
        lh_content=$(lh_build_intelligence_context "$phase" "${LH_DOMAIN:-general}" 1500 2>/dev/null || echo "")
        if [[ -n "$lh_content" && ${#lh_content} -gt 20 ]]; then
            append_prompt+="$lh_content
"
        fi
    fi

    # --- v100.0: Knowledge DB RAG注入 ---
    # 蓄積された全セッション知見をプロンプトに注入
    if [[ "${ENABLE_KNOWLEDGE_DB:-true}" == "true" ]] && type -t kdb_build_injection &>/dev/null; then
        local kdb_content
        kdb_content=$(kdb_build_injection "$phase" "$domain" "" 2>/dev/null || echo "")
        if [[ -n "$kdb_content" && ${#kdb_content} -gt 20 ]]; then
            append_prompt+="$kdb_content
"
        fi
    fi

    # --- v120.0: Golden Patterns注入 ---
    # 必須コードテンプレートをプロンプトに注入
    if [[ "${ENABLE_GOLDEN_PATTERNS:-true}" == "true" ]] && type -t gp_inject_for_phase &>/dev/null; then
        local gp_content
        gp_content=$(gp_inject_for_phase "$phase" "$domain" 2>/dev/null || echo "")
        if [[ -n "$gp_content" && ${#gp_content} -gt 20 ]]; then
            append_prompt+="$gp_content
"
        fi
    fi

    echo "$append_prompt"
}

# ============================================================
# ユーザープロンプト構築
# タスク記述のみに集中（ルール・制約はsystem promptに分離済み）
# ============================================================
cb2_build_user_prompt() {
    local original_prompt="$1"
    local phase="${2:-implementation}"

    local user_prompt="$original_prompt"

    # --- 前フェーズのコンテキスト（最小限のみ） ---
    if type -t mm_build_context &>/dev/null; then
        local prev_ctx
        prev_ctx=$(mm_build_context "$phase" 2>/dev/null || echo "")
        if [[ -n "$prev_ctx" && ${#prev_ctx} -gt 10 ]]; then
            user_prompt+="

[前フェーズの成果物]
${prev_ctx}"
        fi
    fi

    # --- Prompt Evolution変異適用 ---
    if type -t pev_mutate_prompt &>/dev/null && [[ "${PEV_ENABLED:-false}" == "true" ]]; then
        user_prompt=$(pev_mutate_prompt "$user_prompt" "${DOMAIN_TYPE:-general}" "$phase" 2>/dev/null || echo "$user_prompt")
    fi

    # --- v120.0: Completion Checklist注入 ---
    # プロンプト末尾に自己検証チェックリストを追加
    if [[ "${ENABLE_COMPLETION_CHECKLIST:-true}" == "true" ]] && type -t ccl_get_checklist &>/dev/null; then
        local checklist
        checklist=$(ccl_get_checklist "$phase" "${DOMAIN_TYPE:-general}" 2>/dev/null || echo "")
        if [[ -n "$checklist" && ${#checklist} -gt 20 ]]; then
            user_prompt+="

${checklist}"
        fi
    fi

    # 文字数制限
    if [[ ${#user_prompt} -gt $CB2_MAX_USER_PROMPT_CHARS ]]; then
        user_prompt="${user_prompt:0:$CB2_MAX_USER_PROMPT_CHARS}"
    fi

    echo "$user_prompt"
}

# ============================================================
# モデルフラグ構築
# --model + --fallback-model の最適組み合わせ
# ============================================================
cb2_build_model_flags() {
    local phase="${1:-implementation}"
    local prompt_text="${2:-}"

    local flags=""

    # プライマリモデル選択
    if [[ "${MR_ENABLED:-false}" == "true" ]] && type -t mr_route_phase &>/dev/null; then
        local tier
        tier=$(mr_route_phase "$phase" "$prompt_text" 2>/dev/null || echo "balanced")

        # Cost Gate連動ダウングレード
        if [[ "${CG_ENABLED:-false}" == "true" ]] && type -t cg_suggest_downgrade &>/dev/null; then
            local cg_tier
            cg_tier=$(cg_suggest_downgrade 2>/dev/null || echo "")
            if [[ -n "$cg_tier" ]]; then
                tier="$cg_tier"
            fi
        fi

        if type -t mr_get_model_flag &>/dev/null; then
            flags=$(mr_get_model_flag "$tier" 2>/dev/null || echo "")
        fi
    fi

    # フォールバックモデル追加（Claude CLI v2.1.20のネイティブ機能）
    if [[ "${CB2_ENABLE_FALLBACK_MODEL}" == "true" ]]; then
        # プライマリがOpusならSonnetにフォールバック
        # プライマリがSonnetならHaikuにフォールバック
        if echo "$flags" | grep -q "opus" 2>/dev/null; then
            flags+=" --fallback-model claude-sonnet-4-20250514"
        elif echo "$flags" | grep -q "sonnet" 2>/dev/null; then
            flags+=" --fallback-model claude-haiku-3-5-20241022"
        fi
    fi

    echo "$flags"
}

# ============================================================
# v176.0: Prompt Deduplication
# 同一セクションが複数回注入された場合、最初のみ残す
# ============================================================
_cb2_deduplicate_prompt() {
    local prompt="$1"
    local deduped="$prompt"

    # Remove duplicate section markers
    # If the same section appears twice, keep only the first
    local sections=("Golden Patterns" "Enterprise Patterns" "UI Interaction" "エラー予防" "API Contract")
    for section in "${sections[@]}"; do
        local count
        count=$(echo "$deduped" | grep -c "=== .*${section}" 2>/dev/null || echo "0")
        if [[ "$count" -gt 1 ]]; then
            # Keep first occurrence, remove subsequent
            local first_found=false
            local result=""
            local in_dup_section=false
            while IFS= read -r line; do
                if echo "$line" | grep -q "=== .*${section}" 2>/dev/null; then
                    if ! $first_found; then
                        first_found=true
                        result+="${line}"$'\n'
                    else
                        in_dup_section=true
                    fi
                elif echo "$line" | grep -q "=== .*END ===" 2>/dev/null && $in_dup_section; then
                    in_dup_section=false
                elif ! $in_dup_section; then
                    result+="${line}"$'\n'
                fi
            done <<< "$deduped"
            deduped="$result"
        fi
    done

    echo "$deduped"
}

# ============================================================
# v178.0: Prompt Response Cache
# 同一プロンプト+フェーズのレスポンスをキャッシュ
# ============================================================
CB2_CACHE_DIR="${HOME}/.soloptilink/cache"
CB2_CACHE_ENABLED="${CB2_CACHE_ENABLED:-false}"  # Disabled by default for safety
CB2_CACHE_TTL=86400  # 24 hours

_cb2_cache_key() {
    local prompt="$1"
    local phase="$2"
    echo "${phase}:$(echo "$prompt" | shasum -a 256 | cut -d' ' -f1)"
}

_cb2_cache_get() {
    local key="$1"
    local cache_file="$CB2_CACHE_DIR/${key}.cache"

    if [[ -f "$cache_file" ]]; then
        local age
        age=$(( $(date +%s) - $(stat -f%m "$cache_file" 2>/dev/null || stat -c%Y "$cache_file" 2>/dev/null || echo "0") ))
        if [[ "$age" -lt "$CB2_CACHE_TTL" ]]; then
            cat "$cache_file"
            return 0
        fi
        rm -f "$cache_file"
    fi
    return 1
}

_cb2_cache_set() {
    local key="$1"
    local content="$2"
    mkdir -p "$CB2_CACHE_DIR" 2>/dev/null || true
    echo "$content" > "$CB2_CACHE_DIR/${key}.cache"
}

# ============================================================
# メインClaude呼び出し（v101.0 AI Provider経由）
#
# v101.0: ai_call()への薄いラッパーに変更。
# Claude固有のCLI構築・実行ロジックは lib/providers/claude-cli.sh に移動。
# プロンプト構築関数（cb2_build_*）はClaude固有知識としてこのファイルに残る。
#
# 後方互換: 既存の80+モジュールからの cb2_call() 呼び出しは変更不要。
# ============================================================
cb2_call() {
    local prompt="$1"
    local output_file="${2:-}"
    local phase="${3:-implementation}"
    local domain="${4:-general}"
    local max_retries="${5:-3}"
    local timeout_sec="${6:-$CB2_DEFAULT_TIMEOUT}"

    CB2_CALL_COUNT=$((CB2_CALL_COUNT + 1))

    # v176.0: Prompt deduplication - 重複セクション除去
    prompt=$(_cb2_deduplicate_prompt "$prompt")

    # v178.0: Cache check - キャッシュヒット時は即座に返す
    if [[ "${CB2_CACHE_ENABLED}" == "true" ]]; then
        local _cache_key
        _cache_key=$(_cb2_cache_key "$prompt" "$phase")
        local _cached_result
        if _cached_result=$(_cb2_cache_get "$_cache_key"); then
            echo -e "  ⚡ [v178] キャッシュヒット (phase=${phase})" >&2
            if [[ -n "$output_file" ]]; then
                mkdir -p "$(dirname "$output_file")" 2>/dev/null || true
                printf '%s\n' "$_cached_result" > "$output_file"
            else
                printf '%s\n' "$_cached_result"
            fi
            return 0
        fi
    fi

    # v101.0: AI Provider Layer経由で実行
    local _call_result=""
    local _call_rc=0
    if type -t ai_call &>/dev/null; then
        AIP_PROVIDER="claude-cli" \
        AIP_MAX_RETRIES="$max_retries" \
        AIP_TIMEOUT="$timeout_sec" \
        ai_call "$prompt" "$output_file" "$phase" "$domain"
        _call_rc=$?
    else
        # フォールバック: AI Provider未ロード時は直接実行（起動順序対応）
        _cb2_call_direct "$prompt" "$output_file" "$phase" "$domain" "$max_retries" "$timeout_sec"
        _call_rc=$?
    fi

    # v178.0: Cache store - 成功時にキャッシュ保存
    if [[ "$_call_rc" -eq 0 && "${CB2_CACHE_ENABLED}" == "true" && -n "$output_file" && -f "$output_file" ]]; then
        local _cache_key_store
        _cache_key_store=$(_cb2_cache_key "$prompt" "$phase")
        _cb2_cache_set "$_cache_key_store" "$(cat "$output_file")" 2>/dev/null || true
    fi

    return $_call_rc
}

# --- AI Provider未ロード時の直接実行（フォールバック）---
_cb2_call_direct() {
    local prompt="$1"
    local output_file="${2:-}"
    local phase="${3:-implementation}"
    local domain="${4:-general}"
    local max_retries="${5:-3}"
    local timeout_sec="${6:-$CB2_DEFAULT_TIMEOUT}"

    local system_prompt=""
    local user_prompt=""

    if [[ "${CB2_ENABLE_SYSTEM_PROMPT}" == "true" ]]; then
        system_prompt=$(cb2_build_system_prompt "$phase" "$domain")
        user_prompt=$(cb2_build_user_prompt "$prompt" "$phase")
    else
        user_prompt="$prompt"
    fi

    local model_flags
    model_flags=$(cb2_build_model_flags "$phase" "$user_prompt")

    local claude_err_log="${SESSION_LOG_DIR:-/tmp}/claude_stderr.log"
    mkdir -p "$(dirname "$claude_err_log")" 2>/dev/null || true

    for ((i=1; i<=max_retries; i++)); do
        local result
        local cmd_args=(-p --dangerously-skip-permissions --output-format text)
        [[ -n "$system_prompt" ]] && cmd_args+=(--system-prompt "$system_prompt")
        [[ -n "$model_flags" ]] && cmd_args+=($model_flags)
        cmd_args+=("$user_prompt")

        if command -v timeout &>/dev/null; then
            result=$(timeout "$timeout_sec" claude "${cmd_args[@]}" 2>>"$claude_err_log") && {
                _cb2_handle_success "$result" "$output_file" "$phase"
                return 0
            }
        else
            result=$(claude "${cmd_args[@]}" 2>>"$claude_err_log") && {
                _cb2_handle_success "$result" "$output_file" "$phase"
                return 0
            }
        fi
        sleep $((i * 2))
    done
    return 1
}

# --- 成功時の共通処理（後方互換のため残す）---
_cb2_handle_success() {
    local result="$1"
    local output_file="$2"
    local phase="$3"

    [[ -z "$result" ]] && return 1

    if [[ -n "$output_file" ]]; then
        mkdir -p "$(dirname "$output_file")" 2>/dev/null || true
        printf '%s\n' "$result" > "$output_file"
    else
        printf '%s\n' "$result"
    fi

    # ログ記録
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        printf '[%s] cb2_call#%d SUCCESS result_chars=%d\n' \
            "$(date '+%Y-%m-%d %H:%M:%S')" "$CB2_CALL_COUNT" "${#result}" \
            >> "${SESSION_LOG_DIR}/claude_calls.log" 2>/dev/null || true
    fi

    return 0
}

# ============================================================
# JSON Schema付き構造化呼び出し（v101.0 AI Provider経由）
# ============================================================
cb2_call_structured() {
    local prompt="$1"
    local json_schema="$2"
    local phase="${3:-implementation}"

    # v101.0: AI Provider Layer経由で実行
    if type -t ai_call_structured &>/dev/null; then
        AIP_PROVIDER="claude-cli" ai_call_structured "$prompt" "$json_schema" "$phase"
        return $?
    fi

    # フォールバック: 直接実行
    local system_prompt
    system_prompt=$(cb2_build_system_prompt "$phase" 2>/dev/null || echo "")
    local model_flags
    model_flags=$(cb2_build_model_flags "$phase" 2>/dev/null || echo "")
    local claude_err_log="${SESSION_LOG_DIR:-/tmp}/claude_stderr.log"
    local cmd_args=(-p --dangerously-skip-permissions --output-format json --json-schema "$json_schema")
    [[ -n "$system_prompt" ]] && cmd_args+=(--system-prompt "$system_prompt")
    [[ -n "$model_flags" ]] && cmd_args+=($model_flags)
    cmd_args+=("$prompt")

    local result
    if command -v timeout &>/dev/null; then
        result=$(timeout 300 claude "${cmd_args[@]}" 2>>"$claude_err_log") || return 1
    else
        result=$(claude "${cmd_args[@]}" 2>>"$claude_err_log") || return 1
    fi
    echo "$result"
}

# ============================================================
# レポート
# ============================================================
cb2_report() {
    echo -e "\n  ${BOLD:-}═══ Claude Bridge v56.0 レポート ═══${NC:-}"
    echo -e "  呼び出し回数      : ${CB2_CALL_COUNT}"
    echo -e "  システムプロンプト : ${CB2_ENABLE_SYSTEM_PROMPT}"
    echo -e "  フォールバックモデル: ${CB2_ENABLE_FALLBACK_MODEL}"
    echo -e "  ネイティブ予算制御 : ${CB2_ENABLE_NATIVE_BUDGET}"
    echo -e "  ツール制御        : ${CB2_ENABLE_TOOL_CONTROL}"
}

cb2_report_json() {
    cat <<EOF
{"module":"claude-bridge","version":"${CB2_VERSION}","calls":${CB2_CALL_COUNT},"system_prompt":${CB2_ENABLE_SYSTEM_PROMPT},"fallback_model":${CB2_ENABLE_FALLBACK_MODEL},"native_budget":${CB2_ENABLE_NATIVE_BUDGET}}
EOF
}

# ============================================================
# スコア
# ============================================================
cb2_score() {
    local score=50
    [[ "${CB2_ENABLE_SYSTEM_PROMPT}" == "true" ]] && score=$((score + 15))
    [[ "${CB2_ENABLE_FALLBACK_MODEL}" == "true" ]] && score=$((score + 10))
    [[ "${CB2_ENABLE_NATIVE_BUDGET}" == "true" ]] && score=$((score + 10))
    [[ "${CB2_ENABLE_TOOL_CONTROL}" == "true" ]] && score=$((score + 15))
    echo "$score"
}

# ============================================================
# v59.0: Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "claude-bridge" \
        --version "56.0" \
        --description "System Prompt分離×Fallback Model×Native Budget" \
        --init "cb2_init" \
        --report "cb2_report" \
        --score "cb2_score" \
        --enable-var "ENABLE_CLAUDE_BRIDGE" \
        --cli-flags "--claude-bridge:--no-claude-bridge"
fi

# v2003.1: source時のexit codeを確実に0にする
true
