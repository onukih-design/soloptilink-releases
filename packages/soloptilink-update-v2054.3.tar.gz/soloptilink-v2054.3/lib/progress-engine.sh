#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2040 - Progress Engine (PFP-117 進捗エンジン)
# =============================================================================
# chain.sh の主要フェーズ境界から呼び出され、顧客向けの進捗マイルストーンを
# ~/.soloptilink/.progress/<プロジェクト名>.json に永続化するモジュール。
# Goランチャーの MCP ツール check_progress (Phase 2) がこの JSON を読む前提。
#
# CLI 契約 (厳守):
#   progress-engine.sh start     "$PROJECT_DIR" "<総工程数>"
#   progress-engine.sh milestone "$PROJECT_DIR" <番号> "<日本語マイルストーン名>"
#   progress-engine.sh done      "$PROJECT_DIR"
#
# 出力先: ~/.soloptilink/.progress/<basename(PROJECT_DIR) を正規化した名前>.json
#
# JSON スキーマ (MCP check_progress 読み取り契約 — キー名・型を変更しないこと):
#   {
#     "milestone_now":   <int>,    // 現在のマイルストーン番号 (start 直後は 0)
#     "milestone_total": <int>,    // 総工程数 (start の第2引数)
#     "label_ja":        <string>, // 顧客に見せる日本語マイルストーン名
#     "started_at":      <string>, // ISO8601 UTC (例 "2026-06-12T01:23:45Z")
#     "updated_at":      <string>, // ISO8601 UTC 最終更新時刻
#     "status":          <string>  // "running" | "done"
#   }
#
# 設計原則:
#   - 呼び出し元 (chain.sh ビルドパイプライン) を絶対にブロックしない。
#     書き込み失敗・python3 不在などの実行時障害は silent に exit 0。
#     引数不足などの使い方誤りのみ exit 1 (配線ミスを自己テストで検出するため)。
#   - 書き込みは tmp ファイル + mv のアトミック更新 (MCP 側の読み取り途中破損防止)。
#   - 7日 (10080分) より古い .progress/*.json は start のたびに自動掃除。
#   - sourcing にも対応: source 後 progress_start / progress_milestone /
#     progress_done 関数を直接呼べる。
# =============================================================================

# 二重読み込みガード (source 用。直接実行時は影響なし)
if [[ -n "${_PROGRESS_ENGINE_LOADED:-}" ]] && [[ "${BASH_SOURCE[0]}" != "${0}" ]]; then
    return 0
fi
_PROGRESS_ENGINE_LOADED=1

_PE_SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
_PE_PROGRESS_DIR="${_PE_SL_DIR}/.progress"

# -----------------------------------------------------------------------------
# _pe_now_utc - ISO8601 UTC タイムスタンプ
# -----------------------------------------------------------------------------
_pe_now_utc() {
    date -u '+%Y-%m-%dT%H:%M:%SZ'
}

# -----------------------------------------------------------------------------
# _pe_project_name - PROJECT_DIR から安全なプロジェクト名を導出
#   basename を取り、ファイル名として危険な文字 (パス区切り・空白・制御文字・
#   引用符類) のみ _ に置換する。日本語などの多バイト文字はそのまま保持
#   (全置換すると別プロジェクト同士で進捗ファイルが衝突するため)。
# -----------------------------------------------------------------------------
_pe_project_name() {
    local dir="${1:-}"
    local name
    name="$(basename "${dir%/}" 2>/dev/null)"
    [[ -z "$name" || "$name" == "/" || "$name" == "." ]] && name="unknown-project"
    if command -v python3 &>/dev/null; then
        name="$(PE_NAME="$name" python3 -c "
import os, re
n = os.environ.get('PE_NAME', 'unknown-project')
# パス区切り・空白・制御文字・シェル危険文字のみ _ へ (多バイトは保持)
n = re.sub(r'[/\\\\:*?\"<>|\\s\\x00-\\x1f\\x7f\\x27\\x60\$]', '_', n)
print(n if n else 'unknown-project')
" 2>/dev/null)"
    else
        # フォールバック: 多バイト非対応環境では英数 . _ - のみ許可
        name="$(printf '%s' "$name" | LC_ALL=C tr -c 'A-Za-z0-9._-' '_')"
    fi
    [[ -z "$name" ]] && name="unknown-project"
    printf '%s' "$name"
}

# -----------------------------------------------------------------------------
# _pe_cleanup_stale - 7日より古い進捗 JSON を自動掃除 (BSD find 互換)
# -----------------------------------------------------------------------------
_pe_cleanup_stale() {
    [[ -d "$_PE_PROGRESS_DIR" ]] || return 0
    find "$_PE_PROGRESS_DIR" -maxdepth 1 -name "*.json" -type f -mtime +7 -delete 2>/dev/null || true
}

# -----------------------------------------------------------------------------
# _pe_write_json - 進捗 JSON をアトミックに書き込む
#   引数: <file> <now> <total> <label_ja> <started_at> <status>
#   python3 (標準ライブラリのみ) で JSON エスケープを保証。
#   python3 不在環境では printf フォールバック (ラベルの " と \ のみエスケープ)。
# -----------------------------------------------------------------------------
_pe_write_json() {
    local file="$1" m_now="$2" m_total="$3" label="$4" started="$5" status="$6"
    local updated tmp
    updated="$(_pe_now_utc)"
    tmp="${file}.tmp.$$"

    if command -v python3 &>/dev/null; then
        PE_FILE="$tmp" PE_NOW="$m_now" PE_TOTAL="$m_total" PE_LABEL="$label" \
        PE_STARTED="$started" PE_UPDATED="$updated" PE_STATUS="$status" \
        python3 - <<'PYEOF' 2>/dev/null || return 1
import json, os
def to_int(v, default=0):
    try:
        return int(str(v).strip())
    except Exception:
        return default
data = {
    "milestone_now":   to_int(os.environ.get("PE_NOW", "0")),
    "milestone_total": to_int(os.environ.get("PE_TOTAL", "0")),
    "label_ja":        os.environ.get("PE_LABEL", ""),
    "started_at":      os.environ.get("PE_STARTED", ""),
    "updated_at":      os.environ.get("PE_UPDATED", ""),
    "status":          os.environ.get("PE_STATUS", "running"),
}
with open(os.environ["PE_FILE"], "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
    f.write("\n")
PYEOF
    else
        # フォールバック: 数値検証 + 最小限のエスケープ
        case "$m_now"   in (*[!0-9]*|'') m_now=0   ;; esac
        case "$m_total" in (*[!0-9]*|'') m_total=0 ;; esac
        local esc_label
        esc_label="$(printf '%s' "$label" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g')"
        printf '{\n  "milestone_now": %s,\n  "milestone_total": %s,\n  "label_ja": "%s",\n  "started_at": "%s",\n  "updated_at": "%s",\n  "status": "%s"\n}\n' \
            "$m_now" "$m_total" "$esc_label" "$started" "$updated" "$status" > "$tmp" 2>/dev/null || return 1
    fi

    mv -f "$tmp" "$file" 2>/dev/null || { rm -f "$tmp" 2>/dev/null; return 1; }
    return 0
}

# -----------------------------------------------------------------------------
# _pe_read_field - 既存 JSON から 1 フィールドを安全に読む (無ければ default)
#   引数: <file> <key> <default>
# -----------------------------------------------------------------------------
_pe_read_field() {
    local file="$1" key="$2" default="${3:-}"
    if [[ -f "$file" ]] && command -v python3 &>/dev/null; then
        local val
        val=$(PE_FILE="$file" PE_KEY="$key" python3 -c "
import json, os
try:
    d = json.load(open(os.environ['PE_FILE'], encoding='utf-8'))
    v = d.get(os.environ['PE_KEY'], '')
    print(v if v != '' else '')
except Exception:
    pass
" 2>/dev/null)
        if [[ -n "$val" ]]; then
            printf '%s' "$val"
            return 0
        fi
    fi
    printf '%s' "$default"
}

# =============================================================================
# progress_start <PROJECT_DIR> <総工程数>
#   進捗ファイルを初期化 (milestone_now=0, status=running) + 古いファイル掃除
# =============================================================================
progress_start() {
    local project_dir="${1:-}" total="${2:-}"
    if [[ -z "$project_dir" || -z "$total" ]]; then
        echo "使い方: progress-engine.sh start <PROJECT_DIR> <総工程数>" >&2
        return 1
    fi
    case "$total" in (*[!0-9]*|'')
        echo "進捗エンジン: 総工程数は正の整数で指定してください (受領値: $total)" >&2
        return 1
    ;; esac

    mkdir -p "$_PE_PROGRESS_DIR" 2>/dev/null || return 0
    _pe_cleanup_stale

    local file started
    file="${_PE_PROGRESS_DIR}/$(_pe_project_name "$project_dir").json"
    started="$(_pe_now_utc)"
    _pe_write_json "$file" 0 "$total" "構築を開始しました" "$started" "running" || return 0
    return 0
}

# =============================================================================
# progress_translate_label <label> — 顧客可視ラベルの翻訳/浄化 (v2043 / レーン2)
#   顧客可視出力ポリシー(地の文に機械言語を出さない)を進捗ラベルにも徹底するための翻訳テーブル。
#   ① 純ASCII(=内部英語キーの可能性)は既知フェーズキー→顧客向け日本語マイルストーンへ翻訳。
#   ② 機械言語(パス/コマンド断片/HTTP/exitコード/phase_*/<invoke>等)の混入を検出したら
#      安全な汎用日本語へ置換 (顧客の進捗表示に bash/コード/生ログを出さない)。
#   ③ 既にクリーンな日本語ラベルはそのまま素通し (既存挙動を1ミリも変えない=回帰ゼロ)。
#   stdout に浄化済ラベルを返す。set -e 下でも非ゼロ終了しない。
# =============================================================================
progress_translate_label() {
    local raw="${1:-}"
    # 非ASCII(日本語等)を含むか。含むなら既に顧客可視語 → ①英語キー翻訳はしない(過剰翻訳防止)。
    local has_ja=0
    printf '%s' "$raw" | LC_ALL=C grep -qE '[^ -~]' 2>/dev/null && has_ja=1
    if [[ "$has_ja" -eq 0 ]]; then
        local low; low="$(printf '%s' "$raw" | tr '[:upper:]' '[:lower:]')"
        case "$low" in
            *analy*|*intent*|*requirement*)                     printf '%s' "ご要望を分析しています"; return 0 ;;
            *architect*|*design*|*blueprint*|*schema*)          printf '%s' "システムを設計しています"; return 0 ;;
            *implement*|*generat*|*build*|*scaffold*|*codegen*) printf '%s' "画面と機能を実装しています"; return 0 ;;
            *verify*|*test*|*smoke*|*quality*|*gate*)           printf '%s' "動作を検証しています"; return 0 ;;
            *refine*|*polish*|*finaliz*|*deploy*|*complete*)    printf '%s' "仕上げをしています"; return 0 ;;
        esac
    fi
    # ② 機械言語の混入検出 → 安全な汎用語へ置換 (日本語ラベルにパス/コマンドが混じった場合も浄化)
    if printf '%s' "$raw" | grep -qiE '(\.sh|\.tsx|\.ts|\.js|\.py)([^a-zA-Z]|$)|/[a-zA-Z]+/|phase_|exit[[:space:]]*[0-9]|https?://|HTTP[/ ][0-9]|<invoke|\$\(|&&|\|\|' 2>/dev/null; then
        printf '%s' "処理を進めています"
        return 0
    fi
    # ③ クリーンな日本語 → 素通し
    printf '%s' "$raw"
    return 0
}

# =============================================================================
# progress_milestone <PROJECT_DIR> <番号> <日本語マイルストーン名>
#   現在のマイルストーンを更新。start 未実行でも自己修復で初期化する。
#   v2043(L2): ラベルは progress_translate_label で浄化してから書き込む(機械言語を顧客に出さない)。
# =============================================================================
progress_milestone() {
    local project_dir="${1:-}" num="${2:-}" label="${3:-}"
    if [[ -z "$project_dir" || -z "$num" || -z "$label" ]]; then
        echo "使い方: progress-engine.sh milestone <PROJECT_DIR> <番号> <日本語マイルストーン名>" >&2
        return 1
    fi
    case "$num" in (*[!0-9]*|'')
        echo "進捗エンジン: マイルストーン番号は正の整数で指定してください (受領値: $num)" >&2
        return 1
    ;; esac
    # 顧客可視ラベルの浄化 (クリーンな日本語は素通し=回帰ゼロ)
    label="$(progress_translate_label "$label")"

    mkdir -p "$_PE_PROGRESS_DIR" 2>/dev/null || return 0

    local file total started
    file="${_PE_PROGRESS_DIR}/$(_pe_project_name "$project_dir").json"
    # 既存ファイルから total / started_at を引き継ぐ (無ければ自己修復の既定値)
    total="$(_pe_read_field "$file" "milestone_total" "5")"
    started="$(_pe_read_field "$file" "started_at" "$(_pe_now_utc)")"
    # 番号が total を超えていたら total 側を引き上げる (表示破綻防止)
    if [[ "$num" -gt "$total" ]] 2>/dev/null; then
        total="$num"
    fi
    _pe_write_json "$file" "$num" "$total" "$label" "$started" "running" || return 0
    return 0
}

# =============================================================================
# progress_done <PROJECT_DIR>
#   status=done に確定。milestone_now は milestone_total に揃える。
# =============================================================================
progress_done() {
    local project_dir="${1:-}"
    if [[ -z "$project_dir" ]]; then
        echo "使い方: progress-engine.sh done <PROJECT_DIR>" >&2
        return 1
    fi

    mkdir -p "$_PE_PROGRESS_DIR" 2>/dev/null || return 0

    local file total started
    file="${_PE_PROGRESS_DIR}/$(_pe_project_name "$project_dir").json"
    total="$(_pe_read_field "$file" "milestone_total" "5")"
    started="$(_pe_read_field "$file" "started_at" "$(_pe_now_utc)")"
    _pe_write_json "$file" "$total" "$total" "完了しました" "$started" "done" || return 0
    return 0
}

# =============================================================================
# CLI ディスパッチ (直接実行時のみ。source 時は関数提供のみ)
# =============================================================================
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    _pe_cmd="${1:-}"
    shift 2>/dev/null || true
    case "$_pe_cmd" in
        start)     progress_start "$@" ;;
        milestone) progress_milestone "$@" ;;
        done)      progress_done "$@" ;;
        *)
            echo "使い方: progress-engine.sh {start|milestone|done} ..." >&2
            echo "  start     <PROJECT_DIR> <総工程数>" >&2
            echo "  milestone <PROJECT_DIR> <番号> <日本語マイルストーン名>" >&2
            echo "  done      <PROJECT_DIR>" >&2
            exit 1
            ;;
    esac
    exit $?
fi
