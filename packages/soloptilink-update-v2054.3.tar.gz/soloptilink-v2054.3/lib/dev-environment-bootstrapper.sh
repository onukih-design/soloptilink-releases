#!/usr/bin/env bash
# =====================================================================
# SoloptiLinkAI v2026.0 — Dev Environment Bootstrapper
# =====================================================================
# Purpose:
#   生成完了後に "ユーザーが何もしなくても dev が即起動できる状態" まで
#   一気通貫で持っていく。preview_start 失敗 (next: command not found,
#   prisma DB 接続拒否, seed 未実行 等) を構造的に潰す。
#
# Triggered after Step 4 builds, before preview_start handoff.
# Idempotent: 何度実行しても破壊しない。
# =====================================================================

set -uo pipefail

DEB_VERSION="1.0.0"

# ---------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------
deb_log()  { printf '\033[1;34m[DEB]\033[0m %s\n' "$*" >&2; }
deb_ok()   { printf '\033[1;32m[DEB ✓]\033[0m %s\n' "$*" >&2; }
deb_warn() { printf '\033[1;33m[DEB ⚠]\033[0m %s\n' "$*" >&2; }
deb_err()  { printf '\033[1;31m[DEB ✗]\033[0m %s\n' "$*" >&2; }

# ---------------------------------------------------------------------
# Detect project type
# Returns: nextjs-prisma | nextjs-only | node-generic | python | unknown
# ---------------------------------------------------------------------
deb_detect_project_type() {
    local proj="$1"
    if [[ -f "$proj/package.json" ]]; then
        if [[ -f "$proj/prisma/schema.prisma" ]]; then
            echo "nextjs-prisma"
        elif grep -q '"next"' "$proj/package.json" 2>/dev/null; then
            echo "nextjs-only"
        else
            echo "node-generic"
        fi
    elif [[ -f "$proj/pyproject.toml" ]] || [[ -f "$proj/requirements.txt" ]]; then
        echo "python"
    else
        echo "unknown"
    fi
}

# ---------------------------------------------------------------------
# Step 1: ensure .env exists (copy from .env.example if missing)
# ---------------------------------------------------------------------
deb_ensure_env_file() {
    local proj="$1"
    if [[ -f "$proj/.env" ]]; then
        deb_ok ".env already present"
        return 0
    fi
    if [[ -f "$proj/.env.example" ]]; then
        cp "$proj/.env.example" "$proj/.env"
        deb_ok ".env created from .env.example"
        return 0
    fi
    deb_warn ".env.example not found; skipping .env creation"
    return 0
}

# ---------------------------------------------------------------------
# Step 2: ensure DATABASE_URL points to a working dev DB
# Strategy:
#   - if schema.prisma provider == sqlite, ensure DATABASE_URL=file:./prisma/dev.db
#   - if provider == postgresql AND user has not provided real PG, switch to sqlite
# ---------------------------------------------------------------------
deb_ensure_dev_database_url() {
    local proj="$1"
    local schema="$proj/prisma/schema.prisma"
    [[ -f "$schema" ]] || return 0

    local provider
    provider=$(awk '/^[[:space:]]*provider[[:space:]]*=/ {gsub(/"/, ""); print $3; exit}' "$schema" 2>/dev/null || echo "")

    if [[ "$provider" == "sqlite" ]]; then
        if [[ -f "$proj/.env" ]]; then
            if ! grep -q '^DATABASE_URL=.*file:' "$proj/.env"; then
                # Comment out any postgres URL and add SQLite URL
                sed -i.bak 's|^DATABASE_URL=.*postgresql.*|# &|' "$proj/.env" 2>/dev/null || true
                sed -i.bak 's|^DATABASE_URL=.*postgres://.*|# &|' "$proj/.env" 2>/dev/null || true
                if ! grep -q '^DATABASE_URL=' "$proj/.env"; then
                    echo 'DATABASE_URL="file:./prisma/dev.db"' >> "$proj/.env"
                    deb_ok ".env: DATABASE_URL set to SQLite (file:./prisma/dev.db)"
                fi
            fi
        fi
    fi
    return 0
}

# ---------------------------------------------------------------------
# Step 3: npm install (idempotent)
# ---------------------------------------------------------------------
deb_npm_install() {
    local proj="$1"
    [[ -f "$proj/package.json" ]] || return 0

    if [[ -d "$proj/node_modules" ]] && [[ -f "$proj/package-lock.json" ]]; then
        # check freshness — if package.json newer than node_modules, reinstall
        if [[ "$proj/package.json" -nt "$proj/node_modules" ]]; then
            deb_log "package.json newer than node_modules — reinstalling"
        else
            deb_ok "node_modules is up-to-date"
            return 0
        fi
    fi

    deb_log "running: npm install (in $proj)"
    if (cd "$proj" && npm install --no-audit --no-fund --loglevel=error 2>&1 | tail -10); then
        deb_ok "npm install succeeded"
        return 0
    else
        deb_err "npm install failed"
        return 1
    fi
}

# ---------------------------------------------------------------------
# Step 4: prisma generate + db push + seed
# ---------------------------------------------------------------------
deb_prisma_setup() {
    local proj="$1"
    [[ -f "$proj/prisma/schema.prisma" ]] || return 0

    deb_log "prisma generate"
    (cd "$proj" && npx --no-install prisma generate 2>&1 | tail -5) || {
        deb_warn "prisma generate failed (may need npm install first)"
        return 1
    }

    deb_log "prisma db push (no migration files for dev SQLite)"
    if (cd "$proj" && npx --no-install prisma db push --skip-generate --accept-data-loss 2>&1 | tail -5); then
        deb_ok "prisma db push succeeded"
    else
        deb_warn "prisma db push failed — DB may be unreachable"
        return 1
    fi

    # Seed (only if a seed script exists)
    if grep -q '"prisma":[[:space:]]*{' "$proj/package.json" 2>/dev/null \
       || grep -qE '"db:seed"|"seed"' "$proj/package.json" 2>/dev/null; then
        deb_log "prisma db seed"
        (cd "$proj" && npx --no-install prisma db seed 2>&1 | tail -5) || {
            deb_warn "prisma db seed failed (non-fatal — may have no seed script)"
        }
    fi
    return 0
}

# ---------------------------------------------------------------------
# Step 5: smoke probe — start dev briefly, ping http://localhost:3000/, kill
# ---------------------------------------------------------------------
deb_smoke_probe() {
    local proj="$1"
    local port="${2:-3000}"
    [[ -f "$proj/package.json" ]] || return 0

    deb_log "smoke probe on port $port (10s timeout)"

    # spawn dev server in background, capture pid, wait, probe, kill
    local logfile="$proj/.deb-dev-probe.log"
    (cd "$proj" && nohup npm run dev > "$logfile" 2>&1 &
     echo $! > "$proj/.deb-dev-pid")
    local pid
    pid=$(cat "$proj/.deb-dev-pid" 2>/dev/null)

    local wait_for=15
    local elapsed=0
    local ready=false
    while [[ $elapsed -lt $wait_for ]]; do
        if curl -sf "http://localhost:$port/" -o /dev/null 2>/dev/null \
           || curl -sf "http://localhost:$port/api/health" -o /dev/null 2>/dev/null; then
            ready=true
            break
        fi
        sleep 1
        elapsed=$((elapsed + 1))
    done

    # Always kill the probe server
    if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
        kill "$pid" 2>/dev/null || true
        sleep 1
        kill -9 "$pid" 2>/dev/null || true
    fi
    rm -f "$proj/.deb-dev-pid"

    if $ready; then
        deb_ok "smoke probe PASS (server reachable)"
        return 0
    else
        deb_warn "smoke probe FAIL (no response in ${wait_for}s)"
        if [[ -f "$logfile" ]]; then
            deb_warn "tail of dev log:"
            tail -20 "$logfile" >&2 || true
        fi
        return 1
    fi
}

# ---------------------------------------------------------------------
# Main: deb_run <project_dir> [--port N] [--skip-smoke]
# ---------------------------------------------------------------------
deb_run() {
    local proj="${1:-}"
    local port=3000
    local skip_smoke=false
    shift || true
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --port) port="$2"; shift 2;;
            --skip-smoke) skip_smoke=true; shift;;
            *) shift;;
        esac
    done

    if [[ -z "$proj" ]] || [[ ! -d "$proj" ]]; then
        deb_err "invalid project dir: $proj"
        return 2
    fi

    local ptype
    ptype=$(deb_detect_project_type "$proj")
    deb_log "project type: $ptype"

    case "$ptype" in
        nextjs-prisma)
            deb_ensure_env_file "$proj"
            deb_ensure_dev_database_url "$proj"
            deb_npm_install "$proj" || return 1
            deb_prisma_setup "$proj" || deb_warn "prisma setup partial"
            $skip_smoke || deb_smoke_probe "$proj" "$port" || deb_warn "smoke not OK"
            ;;
        nextjs-only)
            deb_ensure_env_file "$proj"
            deb_npm_install "$proj" || return 1
            $skip_smoke || deb_smoke_probe "$proj" "$port" || deb_warn "smoke not OK"
            ;;
        node-generic)
            deb_ensure_env_file "$proj"
            deb_npm_install "$proj" || return 1
            ;;
        python)
            deb_log "python project — bootstrapper out of scope (use poetry/uv)"
            ;;
        unknown)
            deb_warn "unknown project type — skipping bootstrap"
            ;;
    esac

    deb_ok "bootstrap complete"
    return 0
}

# ---------------------------------------------------------------------
# CLI entry
# ---------------------------------------------------------------------
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-}" in
        run)
            shift
            deb_run "$@"
            ;;
        version)
            echo "$DEB_VERSION"
            ;;
        *)
            echo "Usage: $0 run <project_dir> [--port N] [--skip-smoke]"
            exit 1
            ;;
    esac
fi
