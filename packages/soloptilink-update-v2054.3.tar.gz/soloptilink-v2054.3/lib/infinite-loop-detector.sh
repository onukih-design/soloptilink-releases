#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v277.0 - Infinite Loop Detector
# =============================================================================
# 無限ループの原因となるパターンを静的解析で検出。
# while/for ループ、再帰関数、useEffect依存ループ、
# 状態更新ループを検出し、ガードコードを追加する。
#
# Functions:
#   _ild_init                - 初期化
#   _ild_scan_while_loops    - 終了条件なしwhileループ検出
#   _ild_scan_recursive      - ベースケースなし再帰検出
#   _ild_scan_useeffect_loops - useEffect依存ループ検出
#   _ild_scan_state_loops    - 状態更新ループ検出
#   _ild_add_guards          - ループガード追加
#   _ild_report              - レポート出力
#   _ild_score               - スコア算出(0-100)
#
# All globals use the ILD_ prefix.
# =============================================================================

[[ -n "${_INFINITE_LOOP_DETECTOR_LOADED:-}" ]] && return 0
_INFINITE_LOOP_DETECTOR_LOADED=1

ILD_VERSION="277.0"
ILD_INITIALIZED=false
ENABLE_ILD="${ENABLE_ILD:-true}"

# Counters
ILD_WHILE_ISSUES=0
ILD_RECURSIVE_ISSUES=0
ILD_USEEFFECT_ISSUES=0
ILD_STATE_LOOP_ISSUES=0
ILD_GUARDS_ADDED=0
ILD_TOTAL_SCANS=0
ILD_TOTAL_FILES=0

# Storage
ILD_WORK_DIR=""
declare -g -a _ILD_FINDINGS=()
declare -g -a _ILD_GUARD_SUGGESTIONS=()

# =============================================================================
# _ild_init
# =============================================================================
_ild_init() {
    ILD_WORK_DIR="${HOME}/.soloptilink/loop-detector"
    mkdir -p "$ILD_WORK_DIR" 2>/dev/null || true

    ILD_WHILE_ISSUES=0
    ILD_RECURSIVE_ISSUES=0
    ILD_USEEFFECT_ISSUES=0
    ILD_STATE_LOOP_ISSUES=0
    ILD_GUARDS_ADDED=0
    ILD_TOTAL_SCANS=0
    ILD_TOTAL_FILES=0
    _ILD_FINDINGS=()
    _ILD_GUARD_SUGGESTIONS=()

    ILD_INITIALIZED=true
    return 0
}

# =============================================================================
# _ild_scan_while_loops - Find while loops without clear exit condition
# Usage: _ild_scan_while_loops <project_dir>
# =============================================================================
_ild_scan_while_loops() {
    [[ "$ILD_INITIALIZED" != "true" ]] && _ild_init
    local project_dir="${1:-.}"
    ILD_TOTAL_SCANS=$((ILD_TOTAL_SCANS + 1))

    echo -e "  ${CYAN:-}[ILD] Scanning for unsafe while loops...${NC:-}" >&2

    local src_dirs=("${project_dir}/src" "${project_dir}/app" "${project_dir}/lib" "${project_dir}/server")

    for dir in "${src_dirs[@]}"; do
        [[ ! -d "$dir" ]] && continue

        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            ILD_TOTAL_FILES=$((ILD_TOTAL_FILES + 1))
            local content
            content=$(cat "$file" 2>/dev/null || echo "")
            local line_num=0

            while IFS= read -r line; do
                line_num=$((line_num + 1))

                # while(true) or while(1) without break
                if echo "$line" | grep -qE 'while\s*\(\s*(true|1|!0)\s*\)' 2>/dev/null; then
                    # Check if there's a break within reasonable range
                    local context
                    context=$(sed -n "${line_num},$((line_num + 50))p" "$file" 2>/dev/null)
                    if ! echo "$context" | grep -q 'break\|return\|throw' 2>/dev/null; then
                        _ILD_FINDINGS+=("[While] ${file}:${line_num}: while(true) without break/return within 50 lines")
                        ILD_WHILE_ISSUES=$((ILD_WHILE_ISSUES + 1))
                    fi
                fi

                # for(;;) without break
                if echo "$line" | grep -qE 'for\s*\(\s*;\s*;\s*\)' 2>/dev/null; then
                    local context
                    context=$(sed -n "${line_num},$((line_num + 50))p" "$file" 2>/dev/null)
                    if ! echo "$context" | grep -q 'break\|return\|throw' 2>/dev/null; then
                        _ILD_FINDINGS+=("[While] ${file}:${line_num}: for(;;) without break/return")
                        ILD_WHILE_ISSUES=$((ILD_WHILE_ISSUES + 1))
                    fi
                fi

                # do-while(true) pattern
                if echo "$line" | grep -qE 'while\s*\(\s*true\s*\)\s*;' 2>/dev/null; then
                    _ILD_FINDINGS+=("[While] ${file}:${line_num}: do-while(true) detected")
                    ILD_WHILE_ISSUES=$((ILD_WHILE_ISSUES + 1))
                fi

            done < <(cat "$file" 2>/dev/null)

        done < <(find "$dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
            -not -path "*/node_modules/*" 2>/dev/null)
    done

    return 0
}

# =============================================================================
# _ild_scan_recursive - Find recursive functions without base case
# Usage: _ild_scan_recursive <project_dir>
# =============================================================================
_ild_scan_recursive() {
    [[ "$ILD_INITIALIZED" != "true" ]] && _ild_init
    local project_dir="${1:-.}"
    ILD_TOTAL_SCANS=$((ILD_TOTAL_SCANS + 1))

    echo -e "  ${CYAN:-}[ILD] Scanning for unsafe recursion...${NC:-}" >&2

    local src_dirs=("${project_dir}/src" "${project_dir}/app" "${project_dir}/lib")

    for dir in "${src_dirs[@]}"; do
        [[ ! -d "$dir" ]] && continue

        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            local content
            content=$(cat "$file" 2>/dev/null || echo "")

            # Find function declarations and check for self-calls
            while IFS= read -r func_name; do
                [[ -z "$func_name" ]] && continue
                [[ ${#func_name} -lt 3 ]] && continue

                # Count self-references (calls to itself)
                local self_calls
                self_calls=$(echo "$content" | grep -c "${func_name}(" 2>/dev/null || echo "0")

                # Definition counts as 1, so >1 means it calls itself
                if [[ $self_calls -gt 1 ]]; then
                    # Check for base case (if/return before recursive call)
                    local func_body
                    func_body=$(echo "$content" | awk "/function\s+${func_name}\b|const\s+${func_name}\s*=/,/^}/" '{print}' 2>/dev/null)

                    if [[ -n "$func_body" ]]; then
                        local has_base_case=false
                        if echo "$func_body" | grep -qE 'if\s*\(.*\)\s*return|if\s*\(.*\)\s*\{[^}]*return' 2>/dev/null; then
                            has_base_case=true
                        fi

                        if [[ "$has_base_case" != "true" ]]; then
                            _ILD_FINDINGS+=("[Recursive] ${file}: Function '${func_name}' is recursive without clear base case")
                            ILD_RECURSIVE_ISSUES=$((ILD_RECURSIVE_ISSUES + 1))
                        fi

                        # Check for depth limit
                        if ! echo "$func_body" | grep -qE 'depth|level|maxDepth|MAX_DEPTH|max_depth' 2>/dev/null; then
                            _ILD_FINDINGS+=("[Recursive] ${file}: Function '${func_name}' has no depth limit")
                            ILD_RECURSIVE_ISSUES=$((ILD_RECURSIVE_ISSUES + 1))
                        fi
                    fi
                fi

            done < <(echo "$content" | grep -oE '(function\s+|const\s+|let\s+)([a-zA-Z_]\w+)' | \
                awk '{print $NF}' | sort -u)

        done < <(find "$dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
            -not -path "*/node_modules/*" 2>/dev/null)
    done

    return 0
}

# =============================================================================
# _ild_scan_useeffect_loops - Find useEffect dependency loops
# Usage: _ild_scan_useeffect_loops <project_dir>
# =============================================================================
_ild_scan_useeffect_loops() {
    [[ "$ILD_INITIALIZED" != "true" ]] && _ild_init
    local project_dir="${1:-.}"
    ILD_TOTAL_SCANS=$((ILD_TOTAL_SCANS + 1))

    echo -e "  ${CYAN:-}[ILD] Scanning for useEffect dependency loops...${NC:-}" >&2

    local src_dirs=("${project_dir}/src" "${project_dir}/app" "${project_dir}/components")

    for dir in "${src_dirs[@]}"; do
        [[ ! -d "$dir" ]] && continue

        while IFS= read -r file; do
            [[ -z "$file" ]] && continue

            # Only check React component files
            echo "$file" | grep -qE '\.(tsx|jsx)$' || continue

            local content
            content=$(cat "$file" 2>/dev/null || echo "")

            # useEffect without dependency array
            local effects_no_deps
            effects_no_deps=$(echo "$content" | grep -cE 'useEffect\s*\(\s*\(\s*\)\s*=>' 2>/dev/null || echo "0")

            # Check if any useEffect has no dependency array (runs every render)
            if [[ $effects_no_deps -gt 0 ]]; then
                # Try to detect if the closing has no deps array
                local no_deps_count
                no_deps_count=$(echo "$content" | grep -cE 'useEffect\([^)]*\)\s*;?\s*$' 2>/dev/null || echo "0")
                if [[ $no_deps_count -gt 0 ]]; then
                    _ILD_FINDINGS+=("[useEffect] ${file}: useEffect without dependency array - runs every render")
                    ILD_USEEFFECT_ISSUES=$((ILD_USEEFFECT_ISSUES + 1))
                fi
            fi

            # useEffect that sets state that is also in deps
            # Pattern: useEffect(() => { setState(x) }, [state])
            while IFS= read -r state_var; do
                [[ -z "$state_var" ]] && continue

                local setter="set${state_var^}"
                # Check if both state and setter are used in same useEffect
                if echo "$content" | grep -qE "useEffect.*${setter}" 2>/dev/null; then
                    if echo "$content" | grep -qE "\[.*${state_var}.*\]" 2>/dev/null; then
                        _ILD_FINDINGS+=("[useEffect] ${file}: '${state_var}' both in deps and modified by '${setter}' - possible infinite loop")
                        ILD_USEEFFECT_ISSUES=$((ILD_USEEFFECT_ISSUES + 1))
                    fi
                fi
            done < <(echo "$content" | grep -oE 'const\s+\[(\w+),' | sed 's/const \[//;s/,//')

            # Object/array in dependency array (new reference every render)
            if echo "$content" | grep -qE 'useEffect\([^)]+,\s*\[.*\{.*\}.*\]' 2>/dev/null; then
                _ILD_FINDINGS+=("[useEffect] ${file}: Object literal in dependency array - creates new ref each render")
                ILD_USEEFFECT_ISSUES=$((ILD_USEEFFECT_ISSUES + 1))
            fi

            # useMemo/useCallback with no deps that's used in useEffect deps
            if echo "$content" | grep -qE 'useMemo\([^,]+\)\s*$|useCallback\([^,]+\)\s*$' 2>/dev/null; then
                _ILD_FINDINGS+=("[useEffect] ${file}: useMemo/useCallback without deps - may cause re-render loop")
                ILD_USEEFFECT_ISSUES=$((ILD_USEEFFECT_ISSUES + 1))
            fi

        done < <(find "$dir" -type f \( -name "*.tsx" -o -name "*.jsx" \) \
            -not -path "*/node_modules/*" 2>/dev/null)
    done

    return 0
}

# =============================================================================
# _ild_scan_state_loops - Find state update loops
# Usage: _ild_scan_state_loops <project_dir>
# =============================================================================
_ild_scan_state_loops() {
    [[ "$ILD_INITIALIZED" != "true" ]] && _ild_init
    local project_dir="${1:-.}"
    ILD_TOTAL_SCANS=$((ILD_TOTAL_SCANS + 1))

    echo -e "  ${CYAN:-}[ILD] Scanning for state update loops...${NC:-}" >&2

    local src_dirs=("${project_dir}/src" "${project_dir}/app" "${project_dir}/components")

    for dir in "${src_dirs[@]}"; do
        [[ ! -d "$dir" ]] && continue

        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            echo "$file" | grep -qE '\.(tsx|jsx)$' || continue

            local content
            content=$(cat "$file" 2>/dev/null || echo "")

            # setState in render body (not in event handler or useEffect)
            while IFS= read -r setter; do
                [[ -z "$setter" ]] && continue

                # Check if setter is called directly in component body (outside useEffect/handler)
                # This is a simplified check - looks for setter at top level of component
                local in_render
                in_render=$(echo "$content" | grep -cE "^\s+${setter}\(" 2>/dev/null || echo "0")
                local in_effect
                in_effect=$(echo "$content" | awk '/useEffect/,/\]/' | grep -c "${setter}" 2>/dev/null || echo "0")
                local in_handler
                in_handler=$(echo "$content" | awk '/on[A-Z]\w+\s*=|handle[A-Z]\w+/,/}/' | grep -c "${setter}" 2>/dev/null || echo "0")

                if [[ $in_render -gt 0 ]] && [[ $in_render -gt $((in_effect + in_handler)) ]]; then
                    _ILD_FINDINGS+=("[State] ${file}: '${setter}' may be called during render - causes infinite re-render")
                    ILD_STATE_LOOP_ISSUES=$((ILD_STATE_LOOP_ISSUES + 1))
                fi
            done < <(echo "$content" | grep -oE 'set[A-Z]\w+' | sort -u)

            # Zustand/Redux dispatch in render
            if echo "$content" | grep -qE 'dispatch\(|useDispatch' 2>/dev/null; then
                local dispatch_in_render
                dispatch_in_render=$(echo "$content" | grep -cE '^\s+dispatch\(' 2>/dev/null || echo "0")
                if [[ $dispatch_in_render -gt 0 ]]; then
                    _ILD_FINDINGS+=("[State] ${file}: dispatch() may be called during render")
                    ILD_STATE_LOOP_ISSUES=$((ILD_STATE_LOOP_ISSUES + 1))
                fi
            fi

            # Derived state that triggers re-render
            if echo "$content" | grep -qE 'useMemo\(.*\bset[A-Z]' 2>/dev/null; then
                _ILD_FINDINGS+=("[State] ${file}: setState inside useMemo - should use useEffect instead")
                ILD_STATE_LOOP_ISSUES=$((ILD_STATE_LOOP_ISSUES + 1))
            fi

        done < <(find "$dir" -type f \( -name "*.tsx" -o -name "*.jsx" \) \
            -not -path "*/node_modules/*" 2>/dev/null)
    done

    return 0
}

# =============================================================================
# _ild_add_guards - Add loop guards (max iterations, depth limits)
# Usage: _ild_add_guards <output_dir>
# =============================================================================
_ild_add_guards() {
    [[ "$ILD_INITIALIZED" != "true" ]] && _ild_init
    local output_dir="${1:-.}/src/lib"
    mkdir -p "$output_dir" 2>/dev/null || true
    local target="${output_dir}/loop-guards.ts"

    echo -e "  ${CYAN:-}[ILD] Generating loop guard utilities...${NC:-}" >&2

    cat > "$target" << 'LGEOF'
/**
 * Loop Guards - Prevent infinite loops and unbounded recursion
 * Generated by SoloptiLinkAI v277.0 Infinite Loop Detector
 */

const DEFAULT_MAX_ITERATIONS = 10000;
const DEFAULT_MAX_DEPTH = 100;

/**
 * Create a loop guard that throws after max iterations
 */
export function createLoopGuard(
  maxIterations = DEFAULT_MAX_ITERATIONS,
  label = 'loop'
): { check: () => void; reset: () => void; count: () => number } {
  let iterations = 0;

  return {
    check() {
      iterations++;
      if (iterations > maxIterations) {
        throw new Error(
          `[LoopGuard] ${label}: exceeded ${maxIterations} iterations - possible infinite loop`
        );
      }
    },
    reset() {
      iterations = 0;
    },
    count() {
      return iterations;
    },
  };
}

/**
 * Create a recursion depth guard
 */
export function createDepthGuard(
  maxDepth = DEFAULT_MAX_DEPTH,
  label = 'recursion'
): { enter: () => number; leave: () => void; depth: () => number } {
  let currentDepth = 0;

  return {
    enter() {
      currentDepth++;
      if (currentDepth > maxDepth) {
        throw new Error(
          `[DepthGuard] ${label}: exceeded max depth ${maxDepth} - possible infinite recursion`
        );
      }
      return currentDepth;
    },
    leave() {
      currentDepth = Math.max(0, currentDepth - 1);
    },
    depth() {
      return currentDepth;
    },
  };
}

/**
 * Wrap a recursive function with depth protection
 */
export function withDepthLimit<Args extends any[], R>(
  fn: (...args: Args) => R,
  maxDepth = DEFAULT_MAX_DEPTH,
  label?: string
): (...args: Args) => R {
  const guard = createDepthGuard(maxDepth, label || fn.name || 'anonymous');

  return function wrappedFn(...args: Args): R {
    guard.enter();
    try {
      return fn(...args);
    } finally {
      guard.leave();
    }
  };
}

/**
 * Safe while loop with max iterations
 */
export function safeWhile(
  condition: () => boolean,
  body: (iteration: number) => void,
  maxIterations = DEFAULT_MAX_ITERATIONS,
  label = 'safeWhile'
): number {
  const guard = createLoopGuard(maxIterations, label);
  let iteration = 0;

  while (condition()) {
    guard.check();
    body(iteration);
    iteration++;
  }

  return iteration;
}

/**
 * Retry with max attempts (prevents infinite retry loops)
 */
export async function safeRetry<T>(
  fn: (attempt: number) => Promise<T>,
  maxAttempts = 3,
  delay = 1000,
  backoff = 2
): Promise<T> {
  let lastError: Error | null = null;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      return await fn(attempt);
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      if (attempt < maxAttempts - 1) {
        await new Promise((resolve) =>
          setTimeout(resolve, delay * Math.pow(backoff, attempt))
        );
      }
    }
  }

  throw lastError || new Error(`Failed after ${maxAttempts} attempts`);
}
LGEOF

    ILD_GUARDS_ADDED=$((ILD_GUARDS_ADDED + 1))
    _ILD_GUARD_SUGGESTIONS+=("Generated loop-guards.ts")
    return 0
}

# =============================================================================
# _ild_scan_all - Run all scans
# =============================================================================
_ild_scan_all() {
    local project_dir="${1:-.}"
    _ild_scan_while_loops "$project_dir"
    _ild_scan_recursive "$project_dir"
    _ild_scan_useeffect_loops "$project_dir"
    _ild_scan_state_loops "$project_dir"

    local total=$((ILD_WHILE_ISSUES + ILD_RECURSIVE_ISSUES + ILD_USEEFFECT_ISSUES + ILD_STATE_LOOP_ISSUES))
    if [[ $total -gt 0 ]]; then
        echo -e "  ${RED:-}[ILD] ${total} potential infinite loop risks detected${NC:-}" >&2
    else
        echo -e "  ${GREEN:-}[ILD] No infinite loop risks detected${NC:-}" >&2
    fi
}

# =============================================================================
# _ild_report
# =============================================================================
_ild_report() {
    echo -e "\n  ${BOLD:-}═══ Infinite Loop Detector v277.0 ═══${NC:-}"
    echo -e "  Total scans         : ${ILD_TOTAL_SCANS}"
    echo -e "  Files scanned       : ${ILD_TOTAL_FILES}"
    echo -e "  While loop issues   : ${ILD_WHILE_ISSUES}"
    echo -e "  Recursion issues    : ${ILD_RECURSIVE_ISSUES}"
    echo -e "  useEffect loops     : ${ILD_USEEFFECT_ISSUES}"
    echo -e "  State loops         : ${ILD_STATE_LOOP_ISSUES}"
    echo -e "  Guards generated    : ${ILD_GUARDS_ADDED}"

    if [[ ${#_ILD_FINDINGS[@]} -gt 0 ]]; then
        echo -e "  ${YELLOW:-}--- Findings ---${NC:-}"
        for f in "${_ILD_FINDINGS[@]}"; do
            echo -e "    ${YELLOW:-}${f}${NC:-}"
        done
    fi
}

# =============================================================================
# _ild_score
# =============================================================================
_ild_score() {
    local total=$((ILD_WHILE_ISSUES + ILD_RECURSIVE_ISSUES + ILD_USEEFFECT_ISSUES + ILD_STATE_LOOP_ISSUES))
    local score=90
    [[ $total -gt 0 ]] && score=$((90 - total * 5))
    [[ $score -lt 20 ]] && score=20
    [[ $ILD_GUARDS_ADDED -gt 0 ]] && score=$((score + 5))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "infinite-loop-detector" \
    --version "277.0" \
    --description "無限ループ静的検出（while/再帰/useEffect/状態更新ループ）" \
    --init "_ild_init" \
    --report "_ild_report" \
    --score "_ild_score" \
    --enable-var "ENABLE_ILD" \
    --cli-flags "--loop-detector:--no-loop-detector"
