#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v484.0 - Design Pattern Selector
# =============================================================================
# 問題の特性を分析し、最適なデザインパターンを自動選択して
# 実装テンプレートを生成する。GoF/GRASP/アーキテクチャパターンの
# 知識ベースを持ち、コンテキストに応じたパターン組合せを推薦。
#
# Functions:
#   _dps3_init                    - 初期化
#   _dps3_analyze_problem         - 問題分析
#   _dps3_match_pattern           - パターンマッチング
#   _dps3_generate_implementation - 実装テンプレート生成
#   _dps3_suggest_combination     - パターン組合せ提案
#   _dps3_report                  - レポート出力
#   _dps3_score                   - モジュールスコア(0-100)
#
# Globals: DPS3_ prefix
# =============================================================================

[[ -n "${_DESIGN_PATTERN_SELECTOR_LOADED:-}" ]] && return 0
_DESIGN_PATTERN_SELECTOR_LOADED=1

DPS3_VERSION="484.0"
DPS3_INITIALIZED=false

# --- Storage ---
DPS3_DATA_DIR=""
DPS3_SELECTION_LOG=""

# --- State ---
DPS3_TOTAL_SELECTIONS=0
DPS3_PATTERNS_APPLIED=0

# --- Pattern Knowledge Base ---
declare -g -A _DPS3_PATTERNS=()
declare -g -A _DPS3_PATTERN_CATEGORY=()
declare -g -A _DPS3_PATTERN_USE_CASE=()
declare -g -A _DPS3_PATTERN_TEMPLATE=()
declare -g -a _DPS3_SELECTED_PATTERNS=()

# =============================================================================
# 初期化
# =============================================================================
_dps3_init() {
    local project_dir="${PROJECT_DIR:-.}"
    DPS3_DATA_DIR="${project_dir}/.soloptilink/dps3"
    DPS3_SELECTION_LOG="${DPS3_DATA_DIR}/selections.jsonl"

    mkdir -p "$DPS3_DATA_DIR"

    # パターン知識ベースの構築
    _dps3_build_knowledge_base

    DPS3_INITIALIZED=true
    return 0
}

_dps3_build_knowledge_base() {
    # --- Creational Patterns ---
    _DPS3_PATTERNS["factory"]="Factory Pattern: オブジェクト生成の抽象化"
    _DPS3_PATTERN_CATEGORY["factory"]="creational"
    _DPS3_PATTERN_USE_CASE["factory"]="テストデータ生成 複数種類のオブジェクト作成 DB seed"
    _DPS3_PATTERN_TEMPLATE["factory"]="export function create{Entity}(overrides?: Partial<{Entity}>): {Entity} { return { ...defaults, ...overrides } }"

    _DPS3_PATTERNS["builder"]="Builder Pattern: 複雑なオブジェクトの段階的構築"
    _DPS3_PATTERN_CATEGORY["builder"]="creational"
    _DPS3_PATTERN_USE_CASE["builder"]="クエリビルダー フォーム構築 設定オブジェクト"
    _DPS3_PATTERN_TEMPLATE["builder"]="class QueryBuilder { private query = {}; where(field, value) { this.query.where = {...}; return this; } build() { return this.query; } }"

    _DPS3_PATTERNS["singleton"]="Singleton Pattern: インスタンスの一意性保証"
    _DPS3_PATTERN_CATEGORY["singleton"]="creational"
    _DPS3_PATTERN_USE_CASE["singleton"]="DB接続 設定マネージャ ログインスタンス Prismaクライアント"
    _DPS3_PATTERN_TEMPLATE["singleton"]="const globalForPrisma = global as unknown as { prisma: PrismaClient }; export const prisma = globalForPrisma.prisma ?? new PrismaClient(); if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma;"

    # --- Structural Patterns ---
    _DPS3_PATTERNS["repository"]="Repository Pattern: データアクセスの抽象化"
    _DPS3_PATTERN_CATEGORY["repository"]="structural"
    _DPS3_PATTERN_USE_CASE["repository"]="CRUD操作 データベースアクセス テスタビリティ"
    _DPS3_PATTERN_TEMPLATE["repository"]="export const {entity}Repository = { findAll: () => prisma.{entity}.findMany(), findById: (id) => prisma.{entity}.findUnique({where:{id}}), create: (data) => prisma.{entity}.create({data}), update: (id,data) => prisma.{entity}.update({where:{id},data}), delete: (id) => prisma.{entity}.delete({where:{id}}) }"

    _DPS3_PATTERNS["service"]="Service Layer Pattern: ビジネスロジックの分離"
    _DPS3_PATTERN_CATEGORY["service"]="structural"
    _DPS3_PATTERN_USE_CASE["service"]="複雑なビジネスロジック トランザクション バリデーション"
    _DPS3_PATTERN_TEMPLATE["service"]="export class {Entity}Service { async create(input: Create{Entity}Input) { const validated = schema.parse(input); return prisma.\$transaction(async (tx) => { return tx.{entity}.create({data: validated}); }); } }"

    _DPS3_PATTERNS["adapter"]="Adapter Pattern: 異なるインターフェースの統合"
    _DPS3_PATTERN_CATEGORY["adapter"]="structural"
    _DPS3_PATTERN_USE_CASE["adapter"]="外部API統合 レガシーシステム連携 サードパーティライブラリ"
    _DPS3_PATTERN_TEMPLATE["adapter"]="export class PaymentAdapter { constructor(private provider: StripeProvider | PayPalProvider) {} async charge(amount: number) { return this.provider.processPayment(amount); } }"

    _DPS3_PATTERNS["middleware"]="Middleware Pattern: リクエスト処理チェーン"
    _DPS3_PATTERN_CATEGORY["middleware"]="structural"
    _DPS3_PATTERN_USE_CASE["middleware"]="認証 ログ バリデーション レート制限"
    # v2034.6: 正しい withAuth テンプレ. handler が Response を返した場合は instanceof Response でそのまま返却.
    # 旧式は `result instanceof NextResponse` のみで判定し、`new Response('{...}', {status:400})` を JSON ラップして 200 にしてしまう (PFP-049).
    _DPS3_PATTERN_TEMPLATE["middleware"]="export async function withAuth<T>(req: NextRequest, handler: (session: Session) => Promise<T | Response>): Promise<Response> { const session = await getSession(); if (!session) return NextResponse.json({error:'認証が必要です'},{ status:401 }); try { const result = await handler(session); if (result instanceof Response) return result as Response; return NextResponse.json(result); } catch (e: any) { if (e instanceof Response) return e; return NextResponse.json({error: e?.message || 'サーバーエラー'}, { status:500 }); } }"

    # --- Behavioral Patterns ---
    _DPS3_PATTERNS["observer"]="Observer Pattern: イベント駆動型通知"
    _DPS3_PATTERN_CATEGORY["observer"]="behavioral"
    _DPS3_PATTERN_USE_CASE["observer"]="リアルタイム通知 状態変更監視 イベントバス Webhook"
    _DPS3_PATTERN_TEMPLATE["observer"]="class EventBus { private listeners = new Map(); on(event, handler) { if(!this.listeners.has(event)) this.listeners.set(event,[]); this.listeners.get(event).push(handler); } emit(event, data) { this.listeners.get(event)?.forEach(h => h(data)); } }"

    _DPS3_PATTERNS["strategy"]="Strategy Pattern: アルゴリズムの切替"
    _DPS3_PATTERN_CATEGORY["strategy"]="behavioral"
    _DPS3_PATTERN_USE_CASE["strategy"]="認証方式切替 支払い方法 ソートアルゴリズム 通知チャネル"
    _DPS3_PATTERN_TEMPLATE["strategy"]="interface AuthStrategy { authenticate(credentials): Promise<User>; } class JWTStrategy implements AuthStrategy { async authenticate(creds) { /* JWT logic */ } } class OAuthStrategy implements AuthStrategy { async authenticate(creds) { /* OAuth logic */ } }"

    _DPS3_PATTERNS["command"]="Command Pattern: 操作のカプセル化"
    _DPS3_PATTERN_CATEGORY["command"]="behavioral"
    _DPS3_PATTERN_USE_CASE["command"]="Undo/Redo CQRS タスクキュー バッチ処理"
    _DPS3_PATTERN_TEMPLATE["command"]="interface Command { execute(): Promise<void>; undo(): Promise<void>; } class CreateOrderCommand implements Command { async execute() { /* create */ } async undo() { /* rollback */ } }"

    # --- Architecture Patterns ---
    _DPS3_PATTERNS["cqrs"]="CQRS: コマンドとクエリの責務分離"
    _DPS3_PATTERN_CATEGORY["cqrs"]="architecture"
    _DPS3_PATTERN_USE_CASE["cqrs"]="高負荷システム 読み書き非対称 イベントソーシング"

    _DPS3_PATTERNS["event_sourcing"]="Event Sourcing: イベントとしての状態記録"
    _DPS3_PATTERN_CATEGORY["event_sourcing"]="architecture"
    _DPS3_PATTERN_USE_CASE["event_sourcing"]="監査ログ 状態履歴 undo対応"

    _DPS3_PATTERNS["saga"]="Saga Pattern: 分散トランザクション管理"
    _DPS3_PATTERN_CATEGORY["saga"]="architecture"
    _DPS3_PATTERN_USE_CASE["saga"]="マイクロサービス 複数ステップ処理 補償トランザクション"
}

# =============================================================================
# 問題分析
# =============================================================================
_dps3_analyze_problem() {
    local description="$1"
    local domain="${2:-general}"

    [[ "$DPS3_INITIALIZED" != "true" ]] && _dps3_init

    _DPS3_SELECTED_PATTERNS=()

    # 問題特性の抽出とパターンマッチング
    for pattern in "${!_DPS3_PATTERN_USE_CASE[@]}"; do
        local use_cases="${_DPS3_PATTERN_USE_CASE[$pattern]}"
        local matches=0

        for use_case in $use_cases; do
            if echo "$description" | grep -qi "$use_case" 2>/dev/null; then
                matches=$((matches + 1))
            fi
        done

        if [[ $matches -gt 0 ]]; then
            _DPS3_SELECTED_PATTERNS+=("$pattern")
        fi
    done

    # ドメイン固有のパターン推薦
    case "$domain" in
        crm|saas|ec)
            # エンタープライズドメインは必ずRepository+Service
            local has_repo=false has_service=false
            for p in "${_DPS3_SELECTED_PATTERNS[@]}"; do
                [[ "$p" == "repository" ]] && has_repo=true
                [[ "$p" == "service" ]] && has_service=true
            done
            [[ "$has_repo" == "false" ]] && _DPS3_SELECTED_PATTERNS+=("repository")
            [[ "$has_service" == "false" ]] && _DPS3_SELECTED_PATTERNS+=("service")
            ;;
    esac

    # 常に推奨するパターン
    _DPS3_SELECTED_PATTERNS+=("singleton")  # Prismaクライアント
    _DPS3_SELECTED_PATTERNS+=("middleware")  # 認証ミドルウェア

    DPS3_TOTAL_SELECTIONS=$((DPS3_TOTAL_SELECTIONS + 1))

    echo "${#_DPS3_SELECTED_PATTERNS[@]}"
    return 0
}

# =============================================================================
# パターンマッチング
# =============================================================================
_dps3_match_pattern() {
    local problem_type="$1"

    [[ "$DPS3_INITIALIZED" != "true" ]] && _dps3_init

    local matched=""
    for pattern in "${!_DPS3_PATTERN_USE_CASE[@]}"; do
        if echo "${_DPS3_PATTERN_USE_CASE[$pattern]}" | grep -qi "$problem_type" 2>/dev/null; then
            matched+="${pattern} "
        fi
    done

    echo "${matched% }"
    return 0
}

# =============================================================================
# 実装テンプレート生成
# =============================================================================
_dps3_generate_implementation() {
    local pattern="$1"
    local entity="${2:-Item}"

    [[ "$DPS3_INITIALIZED" != "true" ]] && _dps3_init

    local template="${_DPS3_PATTERN_TEMPLATE[$pattern]:-}"
    if [[ -z "$template" ]]; then
        echo "// No template available for pattern: $pattern"
        return 1
    fi

    # エンティティ名の置換
    local impl="$template"
    impl=$(echo "$impl" | sed "s/{Entity}/${entity}/g; s/{entity}/${entity,,}/g")

    DPS3_PATTERNS_APPLIED=$((DPS3_PATTERNS_APPLIED + 1))

    echo "$impl"
    return 0
}

# =============================================================================
# パターン組合せ提案
# =============================================================================
_dps3_suggest_combination() {
    local domain="${1:-general}"

    [[ "$DPS3_INITIALIZED" != "true" ]] && _dps3_init

    case "$domain" in
        crm)
            echo "推奨パターン組合せ: Repository + Service + Observer + Factory + Middleware"
            ;;
        ec)
            echo "推奨パターン組合せ: Repository + Service + Strategy(Payment) + Saga(Order) + Factory"
            ;;
        saas)
            echo "推奨パターン組合せ: Repository + Service + Strategy(Auth) + Observer(Events) + Middleware + Singleton"
            ;;
        chat)
            echo "推奨パターン組合せ: Observer(Messages) + Strategy(Notification) + Service + Repository"
            ;;
        *)
            echo "推奨パターン組合せ: Repository + Service + Middleware + Singleton + Factory"
            ;;
    esac
}

# =============================================================================
# レポート
# =============================================================================
_dps3_report() {
    echo -e "\n  ${BOLD:-}═══ Design Pattern Selector v${DPS3_VERSION} ═══${NC:-}"
    echo -e "  パターン知識数     : ${#_DPS3_PATTERNS[@]}"
    echo -e "  選択実行数         : ${DPS3_TOTAL_SELECTIONS}"
    echo -e "  パターン適用数     : ${DPS3_PATTERNS_APPLIED}"
    echo -e "  選択パターン       : ${_DPS3_SELECTED_PATTERNS[*]:-none}"
}

_dps3_score() {
    [[ "$DPS3_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=60
    [[ $DPS3_TOTAL_SELECTIONS -gt 0 ]] && s=$((s + 15))
    [[ $DPS3_PATTERNS_APPLIED -gt 0 ]] && s=$((s + 15))
    [[ ${#_DPS3_SELECTED_PATTERNS[@]} -gt 3 ]] && s=$((s + 10))
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_dps3_init_message() {
    echo -e "  ${GREEN:-}✅ v${DPS3_VERSION} design-pattern-selector: デザインパターン選択エンジン (${#_DPS3_PATTERNS[@]} patterns)${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "design-pattern-selector" \
    --version "$DPS3_VERSION" \
    --description "デザインパターン選択エンジン" \
    --init "_dps3_init" \
    --report "_dps3_report" \
    --score "_dps3_score" \
    --enable-var "ENABLE_DESIGN_PATTERN_SELECTOR" \
    --cli-flags "--design-pattern-selector:--no-design-pattern-selector" \
    --init-msg "_dps3_init_message"
