#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v356.0 - Health Check System
# =============================================================================
# ヘルスエンドポイント生成×依存関係チェック×ダッシュボード
#
# 機能:
#   - /health, /health/ready, /health/live エンドポイント生成
#   - DB/Redis/外部API依存関係チェック
#   - ヘルスダッシュボードUI生成
#   - Kubernetes readiness/liveness probe対応
#   - 構造化ヘルスレスポンス
#
# 全globals: HCS_ prefix
# =============================================================================

[[ -n "${_HCS_LOADED:-}" ]] && return 0; _HCS_LOADED=1

HCS_VERSION="356.0"
HCS_GENERATED=0
HCS_ERRORS=0
HCS_PHASE="health_check"
HCS_FILES_CREATED=()

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_hcs_log() { echo -e "  ${CYAN}[HCS]${NC} $*"; }
_hcs_ok() { echo -e "  ${GREEN}[HCS]${NC} $*"; }
_hcs_err() { echo -e "  ${RED}[HCS]${NC} $*"; }

_hcs_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        HCS_FILES_CREATED+=("$filepath")
        HCS_GENERATED=$((HCS_GENERATED + 1))
        _hcs_ok "Created: ${filepath##*/}"
    else
        HCS_ERRORS=$((HCS_ERRORS + 1))
        _hcs_err "Failed: ${filepath##*/}"
    fi
}

hcs_init() {
    HCS_GENERATED=0; HCS_ERRORS=0; HCS_FILES_CREATED=()
    _hcs_log "Health Check System v${HCS_VERSION} initialized"
    return 0
}

# =============================================================================
# Generate Health Endpoint
# =============================================================================
_hcs_generate_health_endpoint() {
    local project_dir="${1:-.}"

    _hcs_log "Generating health check endpoints..."

    local api_dir="${project_dir}/src/app/api/health"
    mkdir -p "$api_dir" "${api_dir}/ready" "${api_dir}/live" "${api_dir}/db" 2>/dev/null

    _hcs_write_file "${api_dir}/route.ts" "$(cat <<'TS'
import { NextResponse } from 'next/server';

interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  version: string;
  uptime: number;
  timestamp: string;
  checks: Record<string, { status: string; latency?: number; details?: string }>;
}

const startTime = Date.now();

export async function GET() {
  const checks: HealthStatus['checks'] = {};

  // Database check
  try {
    const start = Date.now();
    const { PrismaClient } = await import('@prisma/client');
    const prisma = new PrismaClient();
    await prisma.$queryRaw\`SELECT 1\`;
    await prisma.$disconnect();
    checks.database = { status: 'ok', latency: Date.now() - start };
  } catch (e) {
    checks.database = { status: 'error', details: String(e) };
  }

  // Memory check
  const mem = process.memoryUsage();
  const memMb = Math.round(mem.heapUsed / 1048576);
  checks.memory = { status: memMb < 512 ? 'ok' : 'warning', details: `${memMb}MB heap used` };

  const allOk = Object.values(checks).every(c => c.status === 'ok');
  const hasDegraded = Object.values(checks).some(c => c.status === 'warning');

  const health: HealthStatus = {
    status: allOk ? 'healthy' : hasDegraded ? 'degraded' : 'unhealthy',
    version: process.env.APP_VERSION || '0.0.0',
    uptime: Math.round((Date.now() - startTime) / 1000),
    timestamp: new Date().toISOString(),
    checks,
  };

  return NextResponse.json(health, { status: allOk || hasDegraded ? 200 : 503 });
}
TS
)"

    _hcs_write_file "${api_dir}/ready/route.ts" "$(cat <<'TS'
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const { PrismaClient } = await import('@prisma/client');
    const prisma = new PrismaClient();
    await prisma.$queryRaw\`SELECT 1\`;
    await prisma.$disconnect();
    return NextResponse.json({ ready: true }, { status: 200 });
  } catch {
    return NextResponse.json({ ready: false }, { status: 503 });
  }
}
TS
)"

    _hcs_write_file "${api_dir}/live/route.ts" "$(cat <<'TS'
import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    alive: true,
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
}
TS
)"

    _hcs_ok "Health check endpoints generated"
}

# =============================================================================
# Check Dependencies
# =============================================================================
_hcs_check_dependencies() {
    local project_dir="${1:-.}"

    _hcs_log "Generating dependency health checker..."

    local health_dir="${project_dir}/src/lib/health"
    mkdir -p "$health_dir" 2>/dev/null

    _hcs_write_file "${health_dir}/dependency-checker.ts" "$(cat <<'TS'
// Dependency Health Checker - Check all external service dependencies

interface DependencyConfig {
  name: string;
  type: 'database' | 'cache' | 'api' | 'queue' | 'storage';
  checkFn: () => Promise<boolean>;
  critical: boolean;
  timeoutMs: number;
}

interface DependencyStatus {
  name: string;
  type: string;
  healthy: boolean;
  latencyMs: number;
  critical: boolean;
  error?: string;
}

export class DependencyChecker {
  private deps: DependencyConfig[] = [];

  register(config: DependencyConfig): void {
    this.deps.push(config);
  }

  async checkAll(): Promise<{ healthy: boolean; deps: DependencyStatus[] }> {
    const results = await Promise.allSettled(
      this.deps.map(dep => this.checkOne(dep))
    );

    const statuses = results.map((r, i) => {
      if (r.status === 'fulfilled') return r.value;
      return {
        name: this.deps[i].name,
        type: this.deps[i].type,
        healthy: false,
        latencyMs: this.deps[i].timeoutMs,
        critical: this.deps[i].critical,
        error: String((r as PromiseRejectedResult).reason),
      };
    });

    const criticalDown = statuses.some(s => s.critical && !s.healthy);
    return { healthy: !criticalDown, deps: statuses };
  }

  private async checkOne(dep: DependencyConfig): Promise<DependencyStatus> {
    const start = Date.now();
    try {
      const result = await Promise.race([
        dep.checkFn(),
        new Promise<never>((_, reject) => setTimeout(() => reject(new Error('Timeout')), dep.timeoutMs)),
      ]);
      return { name: dep.name, type: dep.type, healthy: result, latencyMs: Date.now() - start, critical: dep.critical };
    } catch (e) {
      return { name: dep.name, type: dep.type, healthy: false, latencyMs: Date.now() - start, critical: dep.critical, error: String(e) };
    }
  }
}

export const dependencyChecker = new DependencyChecker();

// Default registrations
dependencyChecker.register({
  name: 'PostgreSQL',
  type: 'database',
  critical: true,
  timeoutMs: 5000,
  checkFn: async () => {
    const { PrismaClient } = await import('@prisma/client');
    const prisma = new PrismaClient();
    await prisma.$queryRaw\`SELECT 1\`;
    await prisma.$disconnect();
    return true;
  },
});
TS
)"

    _hcs_ok "Dependency health checker generated"
}

# =============================================================================
# Generate Dashboard
# =============================================================================
_hcs_generate_dashboard() {
    local project_dir="${1:-.}"

    _hcs_log "Generating health dashboard..."

    local dash_dir="${project_dir}/src/app/admin/health"
    mkdir -p "$dash_dir" 2>/dev/null

    _hcs_write_file "${dash_dir}/page.tsx" "$(cat <<'TSX'
'use client';
import { useEffect, useState } from 'react';

interface HealthData {
  status: string;
  version: string;
  uptime: number;
  timestamp: string;
  checks: Record<string, { status: string; latency?: number; details?: string }>;
}

export default function HealthDashboard() {
  const [health, setHealth] = useState<HealthData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchHealth = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/health');
      const data = await res.json();
      setHealth(data);
      setError(null);
    } catch (e) {
      setError(String(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHealth();
    const interval = setInterval(fetchHealth, 30000);
    return () => clearInterval(interval);
  }, []);

  if (loading && !health) return <div className="p-8">Loading health data...</div>;
  if (error) return <div className="p-8 text-red-500">Error: {error}</div>;
  if (!health) return null;

  const statusColor = health.status === 'healthy' ? 'bg-green-500' : health.status === 'degraded' ? 'bg-yellow-500' : 'bg-red-500';
  const uptimeStr = `${Math.floor(health.uptime / 3600)}h ${Math.floor((health.uptime % 3600) / 60)}m`;

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">System Health</h1>
      <div className="flex items-center gap-3 mb-8">
        <span className={`w-4 h-4 rounded-full ${statusColor}`} />
        <span className="text-xl font-medium capitalize">{health.status}</span>
        <span className="text-gray-500 ml-auto">v{health.version} | Uptime: {uptimeStr}</span>
      </div>
      <div className="space-y-4">
        {Object.entries(health.checks).map(([name, check]) => (
          <div key={name} className="border rounded-lg p-4 flex items-center justify-between">
            <div>
              <h3 className="font-medium capitalize">{name}</h3>
              {check.details && <p className="text-sm text-gray-500">{check.details}</p>}
            </div>
            <div className="flex items-center gap-4">
              {check.latency !== undefined && <span className="text-sm text-gray-500">{check.latency}ms</span>}
              <span className={`px-2 py-1 rounded text-xs font-medium ${
                check.status === 'ok' ? 'bg-green-100 text-green-800' :
                check.status === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                'bg-red-100 text-red-800'
              }`}>{check.status}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
TSX
)"

    _hcs_ok "Health dashboard generated"
}

# =============================================================================
# Report / Score / Register
# =============================================================================
hcs_report() {
    echo -e "\n  ${BOLD}=== Health Check System v${HCS_VERSION} ===${NC}"
    echo -e "  生成ファイル数 : ${HCS_GENERATED}"
    echo -e "  エラー         : ${HCS_ERRORS}"
    if [[ ${#HCS_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${HCS_FILES_CREATED[@]}"; do echo -e "    - ${f}"; done
    fi
}

hcs_score() {
    if [[ ${HCS_GENERATED} -ge 5 ]] && [[ ${HCS_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${HCS_GENERATED} -gt 0 ]] && [[ ${HCS_ERRORS} -eq 0 ]]; then echo "90"
    elif [[ ${HCS_GENERATED} -gt 0 ]]; then echo "70"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "health-check-system" --version "356.0" \
        --description "ヘルスエンドポイント生成×依存関係チェック×ダッシュボード" \
        --init "hcs_init" --report "hcs_report" --score "hcs_score" \
        --enable-var "ENABLE_HEALTH_CHECK_SYSTEM" --cli-flags "--health-check-system:--no-health-check-system"
fi

# v2003.1: source時のexit codeを確実に0にする
true
