#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v30.0 - Voting Engine (投票エンジン)
# =============================================================================
# エージェント間の意思決定を投票メカニズムで実現。重み付き多数決・
# 少数意見レポート・タイブレーク解決・エージェント精度追跡を備えた
# 分散合意形成エンジン。
#
# v30.0: 初版 - Swarm Autonomy 投票メカニズム
#
# 機能:
#   vt_init               - 投票エンジン初期化
#   vt_create_ballot      - 新規投票の作成
#   vt_cast_vote          - 投票の実行
#   vt_close_ballot       - 投票の締め切り
#   vt_tally              - 重み付きスコアで集計
#   vt_get_result         - 最終結果の取得
#   vt_get_minority_report - 少数意見の取得
#   vt_auto_resolve_conflict - タイブレーク自動解決
#   vt_history            - 投票履歴の取得
#   vt_agent_accuracy     - エージェントの過去投票精度
#   vt_report             - 投票レポート出力
#   vt_score              - 投票健全性スコア（0-100）
#   vt_report_json        - JSON形式レポート
#
# All globals use the VT_ prefix.
# =============================================================================

[[ -n "${_VOTING_ENGINE_LOADED:-}" ]] && return 0
_VOTING_ENGINE_LOADED=1

# ============================================================
# State
# ============================================================
declare -g VT_VERSION="30.0"
declare -g VT_ENABLED="false"
declare -g VT_SESSION_ID=""
declare -g VT_SCORE=0

# Counters
declare -g VT_BALLOT_COUNT=0
declare -g VT_TOTAL_VOTES_CAST=0
declare -g VT_CONSENSUS_COUNT=0
declare -g VT_CONFLICT_COUNT=0
declare -g VT_TIEBREAK_COUNT=0

# Voting mode constants
declare -g VT_MODE_MAJORITY="majority"
declare -g VT_MODE_SUPERMAJORITY="supermajority"
declare -g VT_MODE_WEIGHTED="weighted"

# PM agent ID for tiebreak
declare -g VT_TIEBREAK_AGENT="pm"

# Ballot registry: associative arrays keyed by ballot_id
declare -g -A VT_BALLOT_QUESTION=()     # ballot_id -> question string
declare -g -A VT_BALLOT_OPTIONS=()      # ballot_id -> JSON options array
declare -g -A VT_BALLOT_VOTERS=()       # ballot_id -> comma-separated voter agent_ids
declare -g -A VT_BALLOT_STATUS=()       # ballot_id -> open|closed|tallied|resolved
declare -g -A VT_BALLOT_MODE=()         # ballot_id -> majority|supermajority|weighted
declare -g -A VT_BALLOT_RESULT=()       # ballot_id -> winning option
declare -g -A VT_BALLOT_MARGIN=()       # ballot_id -> winning margin (0-100)
declare -g -a VT_BALLOT_IDS=()          # ordered list of ballot IDs

# Votes: keyed by ballot_id:agent_id
declare -g -A VT_VOTE_OPTION=()         # ballot_id:agent_id -> selected option
declare -g -A VT_VOTE_CONFIDENCE=()     # ballot_id:agent_id -> confidence (0-100)
declare -g -A VT_VOTE_REASONING=()      # ballot_id:agent_id -> reasoning text

# Agent accuracy tracking
declare -g -A VT_AGENT_VOTES_TOTAL=()   # agent_id -> total votes cast
declare -g -A VT_AGENT_VOTES_CORRECT=() # agent_id -> votes aligned with winning option
declare -g -A VT_AGENT_EXPERTISE=()     # agent_id -> expertise score (0-100)

# ============================================================
# Internal logger
# ============================================================
_vt_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[VOTING]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize
# ============================================================
vt_init() {
    local session_id="${1:-${SESSION_ID:-unknown}}"

    VT_SESSION_ID="$session_id"
    VT_ENABLED="true"
    VT_SCORE=0
    VT_BALLOT_COUNT=0
    VT_TOTAL_VOTES_CAST=0
    VT_CONSENSUS_COUNT=0
    VT_CONFLICT_COUNT=0
    VT_TIEBREAK_COUNT=0

    # Clear registries
    VT_BALLOT_QUESTION=()
    VT_BALLOT_OPTIONS=()
    VT_BALLOT_VOTERS=()
    VT_BALLOT_STATUS=()
    VT_BALLOT_MODE=()
    VT_BALLOT_RESULT=()
    VT_BALLOT_MARGIN=()
    VT_BALLOT_IDS=()
    VT_VOTE_OPTION=()
    VT_VOTE_CONFIDENCE=()
    VT_VOTE_REASONING=()
    VT_AGENT_VOTES_TOTAL=()
    VT_AGENT_VOTES_CORRECT=()
    VT_AGENT_EXPERTISE=()

    _vt_log "SUCCESS" "Voting Engine v${VT_VERSION} 初期化完了 (session=${session_id})"
    return 0
}

# ============================================================
# Create a new ballot
# ============================================================
vt_create_ballot() {
    local ballot_id="${1:?ballot_id required}"
    local question="${2:?question required}"
    local options_json="${3:?options_json required}"
    local voter_agents="${4:-""}"  # comma-separated agent IDs

    VT_BALLOT_QUESTION["$ballot_id"]="$question"
    VT_BALLOT_OPTIONS["$ballot_id"]="$options_json"
    VT_BALLOT_VOTERS["$ballot_id"]="$voter_agents"
    VT_BALLOT_STATUS["$ballot_id"]="open"
    VT_BALLOT_MODE["$ballot_id"]="$VT_MODE_WEIGHTED"
    VT_BALLOT_RESULT["$ballot_id"]=""
    VT_BALLOT_MARGIN["$ballot_id"]=0

    # Add to ordered list
    local found=0
    for existing in "${VT_BALLOT_IDS[@]}"; do
        [[ "$existing" == "$ballot_id" ]] && found=1 && break
    done
    [[ $found -eq 0 ]] && VT_BALLOT_IDS+=("$ballot_id")

    VT_BALLOT_COUNT=${#VT_BALLOT_IDS[@]}

    _vt_log "SUCCESS" "投票作成: ${ballot_id} - ${question}"
    return 0
}

# ============================================================
# Cast a vote
# ============================================================
vt_cast_vote() {
    local ballot_id="${1:?ballot_id required}"
    local agent_id="${2:?agent_id required}"
    local selected_option="${3:?selected_option required}"
    local confidence="${4:-50}"
    local reasoning="${5:-""}"

    # Validate ballot is open
    if [[ "${VT_BALLOT_STATUS[$ballot_id]:-}" != "open" ]]; then
        _vt_log "WARN" "投票 ${ballot_id} は受付終了済み"
        return 1
    fi

    # Check if agent is in the voter list (if list is specified)
    local voters="${VT_BALLOT_VOTERS[$ballot_id]:-}"
    if [[ -n "$voters" ]]; then
        local authorized=0
        IFS=',' read -ra voter_list <<< "$voters"
        for v in "${voter_list[@]}"; do
            v=$(echo "$v" | tr -d ' ')
            [[ "$v" == "$agent_id" ]] && authorized=1 && break
        done
        if [[ $authorized -eq 0 ]]; then
            _vt_log "WARN" "エージェント ${agent_id} は投票 ${ballot_id} の投票権がありません"
            return 1
        fi
    fi

    # Validate confidence range
    [[ $confidence -lt 0 ]] && confidence=0
    [[ $confidence -gt 100 ]] && confidence=100

    # Store vote
    local key="${ballot_id}:${agent_id}"
    VT_VOTE_OPTION["$key"]="$selected_option"
    VT_VOTE_CONFIDENCE["$key"]=$confidence
    VT_VOTE_REASONING["$key"]="$reasoning"

    VT_TOTAL_VOTES_CAST=$((VT_TOTAL_VOTES_CAST + 1))

    # Track agent vote count
    VT_AGENT_VOTES_TOTAL["$agent_id"]=$(( ${VT_AGENT_VOTES_TOTAL[$agent_id]:-0} + 1 ))

    _vt_log "SUCCESS" "投票受付: ${agent_id} -> ${selected_option} (confidence=${confidence}) [${ballot_id}]"
    return 0
}

# ============================================================
# Close a ballot (no more votes accepted)
# ============================================================
vt_close_ballot() {
    local ballot_id="${1:?ballot_id required}"

    if [[ "${VT_BALLOT_STATUS[$ballot_id]:-}" != "open" ]]; then
        _vt_log "WARN" "投票 ${ballot_id} は既にクローズ済み"
        return 1
    fi

    VT_BALLOT_STATUS["$ballot_id"]="closed"
    _vt_log "SUCCESS" "投票締切: ${ballot_id}"
    return 0
}

# ============================================================
# Tally votes with weighted scoring
# Weight = confidence * expertise_score * historical_accuracy
# ============================================================
vt_tally() {
    local ballot_id="${1:?ballot_id required}"

    # Close ballot if still open
    if [[ "${VT_BALLOT_STATUS[$ballot_id]:-}" == "open" ]]; then
        vt_close_ballot "$ballot_id"
    fi

    if [[ "${VT_BALLOT_STATUS[$ballot_id]:-}" == "tallied" || "${VT_BALLOT_STATUS[$ballot_id]:-}" == "resolved" ]]; then
        echo "${VT_BALLOT_RESULT[$ballot_id]:-}"
        return 0
    fi

    _vt_log "SUCCESS" "投票集計開始: ${ballot_id}"

    # Collect all votes for this ballot
    declare -A option_scores=()
    declare -A option_vote_count=()
    local total_weight=0
    local vote_count=0

    # Iterate through known voter agents
    local voters="${VT_BALLOT_VOTERS[$ballot_id]:-}"
    local -a voter_list=()

    if [[ -n "$voters" ]]; then
        IFS=',' read -ra voter_list <<< "$voters"
    else
        # Discover voters from cast votes
        for key in "${!VT_VOTE_OPTION[@]}"; do
            if [[ "$key" == "${ballot_id}:"* ]]; then
                local agent="${key#${ballot_id}:}"
                voter_list+=("$agent")
            fi
        done
    fi

    for agent_id in "${voter_list[@]}"; do
        agent_id=$(echo "$agent_id" | tr -d ' ')
        local key="${ballot_id}:${agent_id}"
        local option="${VT_VOTE_OPTION[$key]:-}"
        [[ -z "$option" ]] && continue

        local confidence="${VT_VOTE_CONFIDENCE[$key]:-50}"
        local expertise="${VT_AGENT_EXPERTISE[$agent_id]:-50}"

        # Calculate historical accuracy
        local accuracy=50
        local agent_total="${VT_AGENT_VOTES_TOTAL[$agent_id]:-0}"
        local agent_correct="${VT_AGENT_VOTES_CORRECT[$agent_id]:-0}"
        if [[ $agent_total -gt 0 ]]; then
            accuracy=$(( (agent_correct * 100) / agent_total ))
        fi

        # Weighted score = (confidence/100) * (expertise/100) * (accuracy/100) * 1000
        # Using integer arithmetic with scaling factor
        local weight=$(( (confidence * expertise * accuracy) / 10000 ))
        [[ $weight -lt 1 ]] && weight=1

        option_scores["$option"]=$(( ${option_scores[$option]:-0} + weight ))
        option_vote_count["$option"]=$(( ${option_vote_count[$option]:-0} + 1 ))
        total_weight=$((total_weight + weight))
        vote_count=$((vote_count + 1))
    done

    # Find winner
    local winner=""
    local winner_score=0
    local runner_up_score=0

    for option in "${!option_scores[@]}"; do
        local score="${option_scores[$option]}"
        if [[ $score -gt $winner_score ]]; then
            runner_up_score=$winner_score
            winner_score=$score
            winner="$option"
        elif [[ $score -gt $runner_up_score ]]; then
            runner_up_score=$score
        fi
    done

    # Check for tie
    local is_tie=0
    if [[ $winner_score -gt 0 && $winner_score -eq $runner_up_score ]]; then
        is_tie=1
    fi

    # Calculate margin
    local margin=0
    if [[ $total_weight -gt 0 ]]; then
        margin=$(( ((winner_score - runner_up_score) * 100) / total_weight ))
    fi

    # Apply voting mode checks
    local mode="${VT_BALLOT_MODE[$ballot_id]:-$VT_MODE_WEIGHTED}"
    local consensus_reached=1

    case "$mode" in
        "$VT_MODE_SUPERMAJORITY")
            # Requires 2/3 of total weighted votes
            local threshold=$(( (total_weight * 67) / 100 ))
            if [[ $winner_score -lt $threshold ]]; then
                consensus_reached=0
                VT_CONFLICT_COUNT=$((VT_CONFLICT_COUNT + 1))
                _vt_log "WARN" "超多数決未達成: ${winner} (${winner_score}/${threshold}必要)"
            fi
            ;;
        "$VT_MODE_MAJORITY")
            # Requires simple majority (>50%)
            local threshold=$(( total_weight / 2 ))
            if [[ $winner_score -le $threshold ]]; then
                consensus_reached=0
                VT_CONFLICT_COUNT=$((VT_CONFLICT_COUNT + 1))
            fi
            ;;
        "$VT_MODE_WEIGHTED")
            # Weighted consensus: just pick highest
            if [[ $is_tie -eq 1 ]]; then
                consensus_reached=0
                VT_CONFLICT_COUNT=$((VT_CONFLICT_COUNT + 1))
                _vt_log "WARN" "同点: タイブレーク解決が必要 [${ballot_id}]"
            fi
            ;;
    esac

    if [[ $is_tie -eq 1 ]]; then
        # Try auto-resolve
        vt_auto_resolve_conflict "$ballot_id"
        winner="${VT_BALLOT_RESULT[$ballot_id]:-$winner}"
    else
        VT_BALLOT_RESULT["$ballot_id"]="$winner"
        VT_BALLOT_MARGIN["$ballot_id"]=$margin
        VT_BALLOT_STATUS["$ballot_id"]="tallied"
    fi

    if [[ $consensus_reached -eq 1 ]]; then
        VT_CONSENSUS_COUNT=$((VT_CONSENSUS_COUNT + 1))
    fi

    # Update agent accuracy tracking based on winner
    for agent_id in "${voter_list[@]}"; do
        agent_id=$(echo "$agent_id" | tr -d ' ')
        local key="${ballot_id}:${agent_id}"
        local option="${VT_VOTE_OPTION[$key]:-}"
        [[ -z "$option" ]] && continue
        if [[ "$option" == "$winner" ]]; then
            VT_AGENT_VOTES_CORRECT["$agent_id"]=$(( ${VT_AGENT_VOTES_CORRECT[$agent_id]:-0} + 1 ))
        fi
    done

    _vt_log "SUCCESS" "投票集計完了: ${ballot_id} -> ${winner} (margin=${margin}%, votes=${vote_count})"

    unset option_scores
    unset option_vote_count

    echo "$winner"
    return 0
}

# ============================================================
# Get final result
# ============================================================
vt_get_result() {
    local ballot_id="${1:?ballot_id required}"

    local status="${VT_BALLOT_STATUS[$ballot_id]:-}"
    if [[ "$status" != "tallied" && "$status" != "resolved" ]]; then
        # Auto-tally if not yet done
        vt_tally "$ballot_id"
    fi

    echo "${VT_BALLOT_RESULT[$ballot_id]:-}"
    return 0
}

# ============================================================
# Get minority report (dissenting opinions)
# ============================================================
vt_get_minority_report() {
    local ballot_id="${1:?ballot_id required}"

    local winner="${VT_BALLOT_RESULT[$ballot_id]:-}"
    if [[ -z "$winner" ]]; then
        echo "[]"
        return 0
    fi

    local report="["
    local first=1

    # Find all voters for this ballot
    local voters="${VT_BALLOT_VOTERS[$ballot_id]:-}"
    local -a voter_list=()
    if [[ -n "$voters" ]]; then
        IFS=',' read -ra voter_list <<< "$voters"
    else
        for key in "${!VT_VOTE_OPTION[@]}"; do
            if [[ "$key" == "${ballot_id}:"* ]]; then
                local agent="${key#${ballot_id}:}"
                voter_list+=("$agent")
            fi
        done
    fi

    for agent_id in "${voter_list[@]}"; do
        agent_id=$(echo "$agent_id" | tr -d ' ')
        local key="${ballot_id}:${agent_id}"
        local option="${VT_VOTE_OPTION[$key]:-}"
        [[ -z "$option" ]] && continue

        # Only include dissenting votes
        if [[ "$option" != "$winner" ]]; then
            [[ $first -eq 0 ]] && report+=","
            first=0
            local confidence="${VT_VOTE_CONFIDENCE[$key]:-50}"
            local reasoning="${VT_VOTE_REASONING[$key]:-}"
            reasoning=$(echo "$reasoning" | sed 's/\\/\\\\/g; s/"/\\"/g')
            report+="{\"agent_id\":\"${agent_id}\",\"vote\":\"${option}\",\"confidence\":${confidence},\"reasoning\":\"${reasoning}\"}"
        fi
    done

    report+="]"
    echo "$report"
    return 0
}

# ============================================================
# Auto-resolve tied votes
# Tiebreak: PM agent gets deciding vote, or escalate to frontier model
# ============================================================
vt_auto_resolve_conflict() {
    local ballot_id="${1:?ballot_id required}"

    _vt_log "SUCCESS" "タイブレーク解決開始: ${ballot_id}"

    VT_TIEBREAK_COUNT=$((VT_TIEBREAK_COUNT + 1))

    # Strategy 1: Check if PM agent voted - PM gets tiebreak authority
    local pm_key="${ballot_id}:${VT_TIEBREAK_AGENT}"
    local pm_vote="${VT_VOTE_OPTION[$pm_key]:-}"

    if [[ -n "$pm_vote" ]]; then
        VT_BALLOT_RESULT["$ballot_id"]="$pm_vote"
        VT_BALLOT_STATUS["$ballot_id"]="resolved"
        _vt_log "SUCCESS" "タイブレーク解決: PM投票優先 -> ${pm_vote} [${ballot_id}]"
        echo "$pm_vote"
        return 0
    fi

    # Strategy 2: Select vote with highest individual confidence
    local best_option=""
    local best_confidence=0

    for key in "${!VT_VOTE_OPTION[@]}"; do
        if [[ "$key" == "${ballot_id}:"* ]]; then
            local conf="${VT_VOTE_CONFIDENCE[$key]:-0}"
            if [[ $conf -gt $best_confidence ]]; then
                best_confidence=$conf
                best_option="${VT_VOTE_OPTION[$key]}"
            fi
        fi
    done

    if [[ -n "$best_option" ]]; then
        VT_BALLOT_RESULT["$ballot_id"]="$best_option"
        VT_BALLOT_STATUS["$ballot_id"]="resolved"
        _vt_log "SUCCESS" "タイブレーク解決: 最高信頼度投票 -> ${best_option} (confidence=${best_confidence}) [${ballot_id}]"
        echo "$best_option"
        return 0
    fi

    # Strategy 3: Select first option as fallback
    local options="${VT_BALLOT_OPTIONS[$ballot_id]:-"[]"}"
    local first_option
    first_option=$(python3 -c "
import json
try:
    opts = json.loads('${options}')
    print(opts[0] if opts else 'unknown')
except: print('unknown')
" 2>/dev/null || echo "unknown")

    VT_BALLOT_RESULT["$ballot_id"]="$first_option"
    VT_BALLOT_STATUS["$ballot_id"]="resolved"
    _vt_log "WARN" "タイブレーク解決: フォールバック -> ${first_option} [${ballot_id}]"

    echo "$first_option"
    return 0
}

# ============================================================
# Get voting history for current session
# ============================================================
vt_history() {
    local history="["
    local first=1

    for ballot_id in "${VT_BALLOT_IDS[@]}"; do
        [[ $first -eq 0 ]] && history+=","
        first=0

        local question="${VT_BALLOT_QUESTION[$ballot_id]:-}"
        question=$(echo "$question" | sed 's/\\/\\\\/g; s/"/\\"/g')
        local status="${VT_BALLOT_STATUS[$ballot_id]:-}"
        local result="${VT_BALLOT_RESULT[$ballot_id]:-}"
        local margin="${VT_BALLOT_MARGIN[$ballot_id]:-0}"

        # Count votes for this ballot
        local vote_count=0
        for key in "${!VT_VOTE_OPTION[@]}"; do
            [[ "$key" == "${ballot_id}:"* ]] && vote_count=$((vote_count + 1))
        done

        history+="{\"ballot_id\":\"${ballot_id}\",\"question\":\"${question}\",\"status\":\"${status}\",\"result\":\"${result}\",\"margin\":${margin},\"vote_count\":${vote_count}}"
    done

    history+="]"
    echo "$history"
    return 0
}

# ============================================================
# Calculate agent's historical voting accuracy
# ============================================================
vt_agent_accuracy() {
    local agent_id="${1:?agent_id required}"

    local total="${VT_AGENT_VOTES_TOTAL[$agent_id]:-0}"
    local correct="${VT_AGENT_VOTES_CORRECT[$agent_id]:-0}"

    if [[ $total -eq 0 ]]; then
        echo "50"  # Default accuracy for new agents
        return 0
    fi

    local accuracy=$(( (correct * 100) / total ))
    echo "$accuracy"
    return 0
}

# ============================================================
# Set agent expertise score
# ============================================================
vt_set_expertise() {
    local agent_id="${1:?agent_id required}"
    local expertise="${2:-50}"

    [[ $expertise -lt 0 ]] && expertise=0
    [[ $expertise -gt 100 ]] && expertise=100

    VT_AGENT_EXPERTISE["$agent_id"]=$expertise
    return 0
}

# ============================================================
# Set voting mode for a ballot
# ============================================================
vt_set_mode() {
    local ballot_id="${1:?ballot_id required}"
    local mode="${2:-$VT_MODE_WEIGHTED}"

    case "$mode" in
        "$VT_MODE_MAJORITY"|"$VT_MODE_SUPERMAJORITY"|"$VT_MODE_WEIGHTED")
            VT_BALLOT_MODE["$ballot_id"]="$mode"
            ;;
        *)
            _vt_log "WARN" "不正な投票モード: ${mode} - デフォルト(weighted)を使用"
            VT_BALLOT_MODE["$ballot_id"]="$VT_MODE_WEIGHTED"
            ;;
    esac
    return 0
}

# ============================================================
# Score (0-100) - Voting health
# Factors: participation rate, consensus rate, conflict rate
# ============================================================
vt_score() {
    local score=100

    if [[ $VT_BALLOT_COUNT -eq 0 ]]; then
        # No ballots = neutral score
        VT_SCORE=50
        echo "50"
        return 0
    fi

    # Factor 1: Participation rate (are agents actually voting?)
    local expected_votes=0
    for ballot_id in "${VT_BALLOT_IDS[@]}"; do
        local voters="${VT_BALLOT_VOTERS[$ballot_id]:-}"
        if [[ -n "$voters" ]]; then
            local count
            count=$(echo "$voters" | tr ',' '\n' | wc -l | tr -d ' ')
            expected_votes=$((expected_votes + count))
        fi
    done

    if [[ $expected_votes -gt 0 ]]; then
        local participation_rate=$(( (VT_TOTAL_VOTES_CAST * 100) / expected_votes ))
        if [[ $participation_rate -lt 50 ]]; then
            score=$((score - 25))
        elif [[ $participation_rate -lt 75 ]]; then
            score=$((score - 10))
        fi
    fi

    # Factor 2: Consensus rate (how often do votes reach consensus?)
    local resolved_count=0
    for ballot_id in "${VT_BALLOT_IDS[@]}"; do
        local status="${VT_BALLOT_STATUS[$ballot_id]:-}"
        [[ "$status" == "tallied" || "$status" == "resolved" ]] && resolved_count=$((resolved_count + 1))
    done

    if [[ $VT_BALLOT_COUNT -gt 0 ]]; then
        local consensus_rate=$(( (VT_CONSENSUS_COUNT * 100) / VT_BALLOT_COUNT ))
        if [[ $consensus_rate -lt 50 ]]; then
            score=$((score - 20))
        elif [[ $consensus_rate -lt 75 ]]; then
            score=$((score - 10))
        fi
    fi

    # Factor 3: Conflict/tiebreak rate (lower is better)
    if [[ $VT_BALLOT_COUNT -gt 0 ]]; then
        local conflict_rate=$(( (VT_CONFLICT_COUNT * 100) / VT_BALLOT_COUNT ))
        if [[ $conflict_rate -gt 50 ]]; then
            score=$((score - 20))
        elif [[ $conflict_rate -gt 25 ]]; then
            score=$((score - 10))
        fi
    fi

    # Factor 4: Tiebreak frequency (too many tiebreaks = poor consensus)
    if [[ $VT_BALLOT_COUNT -gt 0 ]]; then
        local tiebreak_rate=$(( (VT_TIEBREAK_COUNT * 100) / VT_BALLOT_COUNT ))
        if [[ $tiebreak_rate -gt 40 ]]; then
            score=$((score - 15))
        elif [[ $tiebreak_rate -gt 20 ]]; then
            score=$((score - 5))
        fi
    fi

    # Factor 5: Average margin (higher margins = stronger consensus)
    local total_margin=0
    local margin_count=0
    for ballot_id in "${VT_BALLOT_IDS[@]}"; do
        local margin="${VT_BALLOT_MARGIN[$ballot_id]:-0}"
        total_margin=$((total_margin + margin))
        margin_count=$((margin_count + 1))
    done
    if [[ $margin_count -gt 0 ]]; then
        local avg_margin=$((total_margin / margin_count))
        if [[ $avg_margin -gt 50 ]]; then
            score=$((score + 5))  # Bonus for strong consensus
        fi
    fi

    [[ $score -lt 0 ]] && score=0
    [[ $score -gt 100 ]] && score=100
    VT_SCORE=$score

    echo "$score"
    return 0
}

# ============================================================
# Report
# ============================================================
vt_report() {
    echo -e "  ${BOLD:-}${CYAN:-}+============================================+${NC:-}"
    echo -e "  ${BOLD:-}${CYAN:-}|  Voting Engine Report (v30.0)              |${NC:-}"
    echo -e "  ${BOLD:-}${CYAN:-}+============================================+${NC:-}"
    echo -e "  投票ラウンド数:       ${VT_BALLOT_COUNT}"
    echo -e "  総投票数:             ${VT_TOTAL_VOTES_CAST}"
    echo -e "  コンセンサス達成:     ${VT_CONSENSUS_COUNT}"
    echo -e "  コンフリクト発生:     ${VT_CONFLICT_COUNT}"
    echo -e "  タイブレーク解決:     ${VT_TIEBREAK_COUNT}"
    echo ""

    # Ballot details
    if [[ ${#VT_BALLOT_IDS[@]} -gt 0 ]]; then
        echo -e "  ${BOLD:-}投票詳細:${NC:-}"
        printf "  %-15s %-12s %-15s %-8s\n" "Ballot ID" "Status" "Result" "Margin"
        echo "  ---------------------------------------------------"
        for ballot_id in "${VT_BALLOT_IDS[@]}"; do
            local status="${VT_BALLOT_STATUS[$ballot_id]:-open}"
            local result="${VT_BALLOT_RESULT[$ballot_id]:-pending}"
            local margin="${VT_BALLOT_MARGIN[$ballot_id]:-0}"
            local status_color="${YELLOW:-}"
            [[ "$status" == "tallied" ]] && status_color="${GREEN:-}"
            [[ "$status" == "resolved" ]] && status_color="${CYAN:-}"
            printf "  %-15s ${status_color}%-12s${NC:-} %-15s %d%%\n" "$ballot_id" "$status" "$result" "$margin"
        done
        echo ""
    fi

    # Agent accuracy table
    local has_agents=0
    for key in "${!VT_AGENT_VOTES_TOTAL[@]}"; do
        has_agents=1
        break
    done

    if [[ $has_agents -eq 1 ]]; then
        echo -e "  ${BOLD:-}エージェント投票精度:${NC:-}"
        printf "  %-20s %-8s %-8s %-10s\n" "Agent ID" "Total" "Correct" "Accuracy"
        echo "  ---------------------------------------------------"
        for agent_id in "${!VT_AGENT_VOTES_TOTAL[@]}"; do
            local total="${VT_AGENT_VOTES_TOTAL[$agent_id]:-0}"
            local correct="${VT_AGENT_VOTES_CORRECT[$agent_id]:-0}"
            local accuracy=0
            [[ $total -gt 0 ]] && accuracy=$(( (correct * 100) / total ))
            local acc_color="${GREEN:-}"
            [[ $accuracy -lt 70 ]] && acc_color="${YELLOW:-}"
            [[ $accuracy -lt 50 ]] && acc_color="${RED:-}"
            printf "  %-20s %-8d %-8d ${acc_color}%d%%${NC:-}\n" "$agent_id" "$total" "$correct" "$accuracy"
        done
        echo ""
    fi

    local score_color="${GREEN:-}"
    [[ "$VT_SCORE" -lt 80 ]] && score_color="${YELLOW:-}"
    [[ "$VT_SCORE" -lt 60 ]] && score_color="${RED:-}"
    echo -e "  投票健全性スコア: ${score_color}${VT_SCORE}/100${NC:-}"
}

# ============================================================
# JSON Report
# ============================================================
vt_report_json() {
    local ballots_json="["
    local first=1
    for ballot_id in "${VT_BALLOT_IDS[@]}"; do
        [[ $first -eq 0 ]] && ballots_json+=","
        first=0
        local question="${VT_BALLOT_QUESTION[$ballot_id]:-}"
        question=$(echo "$question" | sed 's/\\/\\\\/g; s/"/\\"/g')
        local status="${VT_BALLOT_STATUS[$ballot_id]:-open}"
        local result="${VT_BALLOT_RESULT[$ballot_id]:-}"
        local margin="${VT_BALLOT_MARGIN[$ballot_id]:-0}"
        local mode="${VT_BALLOT_MODE[$ballot_id]:-weighted}"
        ballots_json+="{\"id\":\"${ballot_id}\",\"question\":\"${question}\",\"status\":\"${status}\",\"result\":\"${result}\",\"margin\":${margin},\"mode\":\"${mode}\"}"
    done
    ballots_json+="]"

    local agents_json="["
    first=1
    for agent_id in "${!VT_AGENT_VOTES_TOTAL[@]}"; do
        [[ $first -eq 0 ]] && agents_json+=","
        first=0
        local total="${VT_AGENT_VOTES_TOTAL[$agent_id]:-0}"
        local correct="${VT_AGENT_VOTES_CORRECT[$agent_id]:-0}"
        local expertise="${VT_AGENT_EXPERTISE[$agent_id]:-50}"
        local accuracy=0
        [[ $total -gt 0 ]] && accuracy=$(( (correct * 100) / total ))
        agents_json+="{\"id\":\"${agent_id}\",\"total\":${total},\"correct\":${correct},\"accuracy\":${accuracy},\"expertise\":${expertise}}"
    done
    agents_json+="]"

    cat <<EOF
{
    "module": "voting-engine",
    "version": "${VT_VERSION}",
    "session_id": "${VT_SESSION_ID}",
    "ballot_count": ${VT_BALLOT_COUNT},
    "total_votes_cast": ${VT_TOTAL_VOTES_CAST},
    "consensus_count": ${VT_CONSENSUS_COUNT},
    "conflict_count": ${VT_CONFLICT_COUNT},
    "tiebreak_count": ${VT_TIEBREAK_COUNT},
    "score": ${VT_SCORE},
    "ballots": ${ballots_json},
    "agents": ${agents_json}
}
EOF
}
