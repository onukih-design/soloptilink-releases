#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v472.0 - Cross-Project Learning Engine
# =============================================================================
# 複数プロジェクトの実行結果からパターンを抽出し、ナレッジベースに蓄積。
# 新規プロジェクト開始時に過去の学習を適用して初回品質を向上させる。
# ドメイン別×技術スタック別の最適パターンを自動選択する知識転移エンジン。
#
# Functions:
#   _cpl_init               - 初期化・ナレッジベースロード
#   _cpl_extract_patterns   - プロジェクトからパターン抽出
#   _cpl_store_knowledge    - ナレッジベースに蓄積
#   _cpl_apply_learning     - 新プロジェクトに学習適用
#   _cpl_find_similar       - 類似プロジェクト検索
#   _cpl_merge_knowledge    - 複数ソースの知識統合
#   _cpl_report             - レポート出力
#   _cpl_score              - モジュールスコア(0-100)
#
# Globals: CPL_ prefix
# =============================================================================

[[ -n "${_CROSS_PROJECT_LEARNING_LOADED:-}" ]] && return 0
_CROSS_PROJECT_LEARNING_LOADED=1

CPL_VERSION="472.0"
CPL_INITIALIZED=false

# --- Storage ---
CPL_DATA_DIR=""
CPL_KNOWLEDGE_BASE=""
CPL_PROJECT_INDEX=""
CPL_PATTERN_DB=""

# --- State ---
CPL_TOTAL_PROJECTS=0
CPL_TOTAL_PATTERNS=0
CPL_TOTAL_APPLICATIONS=0
CPL_KNOWLEDGE_ENTRIES=0
CPL_SIMILARITY_THRESHOLD=60

# --- Knowledge Structures ---
declare -g -A _CPL_DOMAIN_PATTERNS=()
declare -g -A _CPL_STACK_PATTERNS=()
declare -g -A _CPL_ERROR_FIXES=()
declare -g -A _CPL_QUALITY_SCORES=()
declare -g -A _CPL_PROJECT_META=()
declare -g -a _CPL_DOMAINS=("crm" "saas" "ec" "blog" "task" "chat" "dashboard" "api" "mobile" "portfolio")

# =============================================================================
# 初期化
# =============================================================================
_cpl_init() {
    local base_dir="${HOME}/.soloptilink/cross-project"
    CPL_DATA_DIR="$base_dir"
    CPL_KNOWLEDGE_BASE="${base_dir}/knowledge.jsonl"
    CPL_PROJECT_INDEX="${base_dir}/projects.json"
    CPL_PATTERN_DB="${base_dir}/patterns.jsonl"

    mkdir -p "$CPL_DATA_DIR"

    # 既存ナレッジのロード
    if [[ -f "$CPL_KNOWLEDGE_BASE" ]]; then
        CPL_KNOWLEDGE_ENTRIES=$(wc -l < "$CPL_KNOWLEDGE_BASE" 2>/dev/null || echo "0")
    fi
    if [[ -f "$CPL_PROJECT_INDEX" ]]; then
        CPL_TOTAL_PROJECTS=$(grep -c '"project"' "$CPL_PROJECT_INDEX" 2>/dev/null || echo "0")
    fi

    CPL_INITIALIZED=true
    return 0
}

# =============================================================================
# プロジェクトからパターン抽出
# =============================================================================
_cpl_extract_patterns() {
    local project_dir="$1"
    local domain="${2:-general}"
    local stack="${3:-nextjs}"

    [[ "$CPL_INITIALIZED" != "true" ]] && _cpl_init
    [[ ! -d "$project_dir" ]] && return 1

    local patterns_found=0
    local timestamp
    timestamp=$(date +%s)

    # --- ファイル構造パターン ---
    local has_prisma=false has_trpc=false has_auth=false has_api=false has_tests=false
    [[ -f "${project_dir}/prisma/schema.prisma" ]] && has_prisma=true
    [[ -d "${project_dir}/server/trpc" || -d "${project_dir}/src/trpc" ]] && has_trpc=true
    [[ -d "${project_dir}/app/api/auth" || -f "${project_dir}/lib/auth.ts" ]] && has_auth=true
    [[ -d "${project_dir}/app/api" ]] && has_api=true
    [[ -d "${project_dir}/__tests__" || -d "${project_dir}/tests" ]] && has_tests=true

    local structure_pattern="prisma:${has_prisma},trpc:${has_trpc},auth:${has_auth},api:${has_api},tests:${has_tests}"
    _CPL_DOMAIN_PATTERNS["${domain}::structure"]="$structure_pattern"
    patterns_found=$((patterns_found + 1))

    # --- コードパターン抽出 ---
    local ts_files
    ts_files=$(find "$project_dir" -name "*.ts" -o -name "*.tsx" 2>/dev/null | head -100)

    # バリデーションパターン
    local validation_pattern="none"
    if echo "$ts_files" | xargs grep -l "zod" 2>/dev/null | head -1 | grep -q .; then
        validation_pattern="zod"
    elif echo "$ts_files" | xargs grep -l "yup" 2>/dev/null | head -1 | grep -q .; then
        validation_pattern="yup"
    fi
    _CPL_STACK_PATTERNS["${stack}::validation"]="$validation_pattern"
    patterns_found=$((patterns_found + 1))

    # 認証パターン
    local auth_pattern="none"
    if echo "$ts_files" | xargs grep -l "next-auth\|NextAuth" 2>/dev/null | head -1 | grep -q .; then
        auth_pattern="next-auth"
    elif echo "$ts_files" | xargs grep -l "jose\|jsonwebtoken" 2>/dev/null | head -1 | grep -q .; then
        auth_pattern="jwt-custom"
    fi
    _CPL_STACK_PATTERNS["${stack}::auth"]="$auth_pattern"
    patterns_found=$((patterns_found + 1))

    # DB パターン
    local db_pattern="none"
    if [[ "$has_prisma" == "true" ]]; then
        db_pattern="prisma"
    elif echo "$ts_files" | xargs grep -l "drizzle" 2>/dev/null | head -1 | grep -q .; then
        db_pattern="drizzle"
    fi
    _CPL_STACK_PATTERNS["${stack}::database"]="$db_pattern"
    patterns_found=$((patterns_found + 1))

    # --- エラーパターンの収集 ---
    local error_log="${project_dir}/.soloptilink/errors.jsonl"
    if [[ -f "$error_log" ]]; then
        local error_count
        error_count=$(wc -l < "$error_log" 2>/dev/null || echo "0")
        while IFS= read -r line; do
            local error_type
            error_type=$(echo "$line" | grep -oP '"type":"[^"]*"' | head -1 | cut -d'"' -f4)
            local fix
            fix=$(echo "$line" | grep -oP '"fix":"[^"]*"' | head -1 | cut -d'"' -f4)
            if [[ -n "$error_type" && -n "$fix" ]]; then
                _CPL_ERROR_FIXES["${domain}::${error_type}"]="$fix"
            fi
        done < "$error_log" 2>/dev/null
    fi

    # --- 品質スコアの記録 ---
    local quality_file="${project_dir}/.soloptilink/quality.json"
    if [[ -f "$quality_file" ]]; then
        local score
        score=$(grep -oP '"overall":\s*\d+' "$quality_file" 2>/dev/null | grep -oP '\d+' | head -1)
        [[ -n "$score" ]] && _CPL_QUALITY_SCORES["${domain}::${stack}"]="$score"
    fi

    # ナレッジベースに記録
    echo "{\"ts\":${timestamp},\"project\":\"${project_dir##*/}\",\"domain\":\"${domain}\",\"stack\":\"${stack}\",\"patterns\":${patterns_found}}" >> "$CPL_KNOWLEDGE_BASE" 2>/dev/null

    CPL_TOTAL_PATTERNS=$((CPL_TOTAL_PATTERNS + patterns_found))
    CPL_KNOWLEDGE_ENTRIES=$((CPL_KNOWLEDGE_ENTRIES + 1))

    echo "$patterns_found"
    return 0
}

# =============================================================================
# ナレッジベースに蓄積
# =============================================================================
_cpl_store_knowledge() {
    local key="$1"
    local value="$2"
    local category="${3:-general}"
    local confidence="${4:-70}"

    [[ "$CPL_INITIALIZED" != "true" ]] && _cpl_init

    local timestamp
    timestamp=$(date +%s)

    echo "{\"ts\":${timestamp},\"key\":\"${key}\",\"value\":\"${value}\",\"category\":\"${category}\",\"confidence\":${confidence}}" >> "$CPL_PATTERN_DB" 2>/dev/null

    CPL_KNOWLEDGE_ENTRIES=$((CPL_KNOWLEDGE_ENTRIES + 1))
    return 0
}

# =============================================================================
# 新プロジェクトに学習適用
# =============================================================================
_cpl_apply_learning() {
    local domain="$1"
    local stack="${2:-nextjs}"
    local output_file="${3:-}"

    [[ "$CPL_INITIALIZED" != "true" ]] && _cpl_init

    local recommendations=""
    local applied=0

    # ドメイン別構造パターンの適用
    local structure="${_CPL_DOMAIN_PATTERNS["${domain}::structure"]:-}"
    if [[ -n "$structure" ]]; then
        recommendations+="[構造パターン] 過去の${domain}プロジェクトの構造: ${structure}\n"
        applied=$((applied + 1))
    fi

    # スタック別パターンの適用
    for key in "${!_CPL_STACK_PATTERNS[@]}"; do
        if [[ "$key" == "${stack}::"* ]]; then
            local aspect="${key##*::}"
            local pattern="${_CPL_STACK_PATTERNS[$key]}"
            recommendations+="[技術パターン] ${aspect}: ${pattern}\n"
            applied=$((applied + 1))
        fi
    done

    # エラー予防の適用
    for key in "${!_CPL_ERROR_FIXES[@]}"; do
        if [[ "$key" == "${domain}::"* ]]; then
            local error_type="${key##*::}"
            local fix="${_CPL_ERROR_FIXES[$key]}"
            recommendations+="[エラー予防] ${error_type}: ${fix}\n"
            applied=$((applied + 1))
        fi
    done

    # 品質ベンチマーク
    local past_score="${_CPL_QUALITY_SCORES["${domain}::${stack}"]:-}"
    if [[ -n "$past_score" ]]; then
        recommendations+="[品質目標] 過去最高スコア: ${past_score}/100 (これを超えること)\n"
        applied=$((applied + 1))
    fi

    CPL_TOTAL_APPLICATIONS=$((CPL_TOTAL_APPLICATIONS + applied))

    if [[ -n "$output_file" ]]; then
        echo -e "$recommendations" > "$output_file"
    fi

    echo -e "$recommendations"
    return 0
}

# =============================================================================
# 類似プロジェクト検索
# =============================================================================
_cpl_find_similar() {
    local domain="$1"
    local stack="${2:-}"

    [[ "$CPL_INITIALIZED" != "true" ]] && _cpl_init
    [[ ! -f "$CPL_KNOWLEDGE_BASE" ]] && return 1

    local matches=0
    while IFS= read -r line; do
        local proj_domain
        proj_domain=$(echo "$line" | grep -oP '"domain":"[^"]*"' | cut -d'"' -f4)
        if [[ "$proj_domain" == "$domain" ]]; then
            echo "$line"
            matches=$((matches + 1))
        fi
    done < "$CPL_KNOWLEDGE_BASE" 2>/dev/null

    echo "# Found ${matches} similar projects" >&2
    return 0
}

# =============================================================================
# 複数ソースの知識統合
# =============================================================================
_cpl_merge_knowledge() {
    local sources=("$@")

    [[ "$CPL_INITIALIZED" != "true" ]] && _cpl_init

    local merged_count=0
    for source_dir in "${sources[@]}"; do
        local kb="${source_dir}/knowledge.jsonl"
        [[ ! -f "$kb" ]] && continue

        while IFS= read -r line; do
            echo "$line" >> "$CPL_KNOWLEDGE_BASE" 2>/dev/null
            merged_count=$((merged_count + 1))
        done < "$kb"
    done

    CPL_KNOWLEDGE_ENTRIES=$((CPL_KNOWLEDGE_ENTRIES + merged_count))
    echo "$merged_count"
    return 0
}

# =============================================================================
# レポート
# =============================================================================
_cpl_report() {
    echo -e "\n  ${BOLD:-}═══ Cross-Project Learning v${CPL_VERSION} ═══${NC:-}"
    echo -e "  プロジェクト数     : ${CPL_TOTAL_PROJECTS}"
    echo -e "  抽出パターン数     : ${CPL_TOTAL_PATTERNS}"
    echo -e "  ナレッジ件数       : ${CPL_KNOWLEDGE_ENTRIES}"
    echo -e "  適用回数           : ${CPL_TOTAL_APPLICATIONS}"
}

_cpl_score() {
    [[ "$CPL_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=50
    [[ $CPL_KNOWLEDGE_ENTRIES -gt 0 ]] && s=$((s + 15))
    [[ $CPL_TOTAL_PATTERNS -gt 10 ]] && s=$((s + 15))
    [[ $CPL_TOTAL_APPLICATIONS -gt 0 ]] && s=$((s + 20))
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_cpl_init_message() {
    echo -e "  ${GREEN:-}✅ v${CPL_VERSION} cross-project-learning: クロスプロジェクト学習エンジン (${CPL_KNOWLEDGE_ENTRIES} entries)${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "cross-project-learning" \
    --version "$CPL_VERSION" \
    --description "クロスプロジェクト学習エンジン" \
    --init "_cpl_init" \
    --report "_cpl_report" \
    --score "_cpl_score" \
    --enable-var "ENABLE_CROSS_PROJECT_LEARNING" \
    --cli-flags "--cross-project-learning:--no-cross-project-learning" \
    --init-msg "_cpl_init_message"
