#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v25.0 - API Contract Validator
# =============================================================================
# OpenAPI/GraphQL スキーマの自動検証・整合性チェック・クライアント生成エンジン
#
# v25.0: 初版 - APIスキーマ検証・エンドポイント整合性・型安全性チェック
# v23.0: Error Guardian integration (err_handle/err_degrade/err_try)
#
# 機能:
#   acv_init                  - 初期化
#   acv_detect_api_style      - API形式の自動検出（REST/GraphQL/gRPC）
#   acv_scan_endpoints        - エンドポイントの自動スキャン
#   acv_validate_schema       - OpenAPIスキーマの検証
#   acv_check_consistency     - フロント↔バックAPI呼び出し整合性チェック
#   acv_check_error_handling  - エラーハンドリングパターンの検証
#   acv_check_auth            - 認証・認可の一貫性チェック
#   acv_check_versioning      - APIバージョニングの検証
#   acv_generate_types        - APIスキーマから型定義を自動生成
#   acv_score                 - API品質スコア（0-100）
#   acv_report                - API契約検証レポート出力
#
# All globals use the ACV_ prefix.
# =============================================================================

[[ -n "${_API_CONTRACT_VALIDATOR_LOADED:-}" ]] && return 0
_API_CONTRACT_VALIDATOR_LOADED=1

# ============================================================
# State
# ============================================================
declare -g ACV_VERSION="25.0"
declare -g ACV_ENABLED="false"
declare -g ACV_SESSION_ID=""
declare -g ACV_PROJECT_DIR=""
declare -g ACV_API_STYLE=""          # rest|graphql|grpc|mixed
declare -g ACV_ENDPOINT_COUNT=0
declare -g ACV_SCHEMA_ERRORS=0
declare -g ACV_CONSISTENCY_ERRORS=0
declare -g ACV_AUTH_ISSUES=0
declare -g ACV_ERROR_HANDLING_ISSUES=0
declare -g ACV_VERSIONING_ISSUES=0
declare -g ACV_SCORE=0
declare -g -a ACV_ISSUES=()
declare -g -a ACV_ENDPOINTS=()

# ============================================================
# Internal logger
# ============================================================
_acv_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[API-CONTRACT]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize
# ============================================================
acv_init() {
    local session_id="${1:-${SESSION_ID:-unknown}}"
    local project_dir="${2:-.}"

    ACV_SESSION_ID="$session_id"
    ACV_PROJECT_DIR="$project_dir"
    ACV_ENABLED="true"
    ACV_ENDPOINT_COUNT=0
    ACV_SCHEMA_ERRORS=0
    ACV_CONSISTENCY_ERRORS=0
    ACV_AUTH_ISSUES=0
    ACV_ERROR_HANDLING_ISSUES=0
    ACV_VERSIONING_ISSUES=0
    ACV_SCORE=0
    ACV_ISSUES=()
    ACV_ENDPOINTS=()

    ACV_API_STYLE=$(acv_detect_api_style "$project_dir")

    _acv_log "SUCCESS" "API Contract Validator 初期化完了 (style=${ACV_API_STYLE})"
    return 0
}

# ============================================================
# Detect API style
# ============================================================
acv_detect_api_style() {
    local dir="${1:-.}"
    local has_rest=0
    local has_graphql=0

    # Check for OpenAPI/Swagger
    if [[ -f "${dir}/openapi.yaml" || -f "${dir}/openapi.json" || -f "${dir}/swagger.yaml" || -f "${dir}/swagger.json" ]]; then
        has_rest=1
    fi

    # Check for REST API routes
    if [[ -d "${dir}/app/api" || -d "${dir}/routes" || -d "${dir}/src/routes" ]]; then
        has_rest=1
    fi

    # Check for GraphQL
    if find "$dir" -name "*.graphql" -o -name "*.gql" 2>/dev/null | head -1 | grep -q .; then
        has_graphql=1
    fi
    if grep -rl "graphql\|apollo\|@Query\|@Mutation" "$dir" 2>/dev/null | head -1 | grep -q .; then
        has_graphql=1
    fi

    if [[ $has_rest -eq 1 && $has_graphql -eq 1 ]]; then
        echo "mixed"; return 0
    elif [[ $has_graphql -eq 1 ]]; then
        echo "graphql"; return 0
    elif [[ $has_rest -eq 1 ]]; then
        echo "rest"; return 0
    fi

    echo "rest"
    return 0
}

# ============================================================
# Scan endpoints
# ============================================================
acv_scan_endpoints() {
    local project_dir="${1:-$ACV_PROJECT_DIR}"
    local count=0

    ACV_ENDPOINTS=()

    # Next.js API routes
    if [[ -d "${project_dir}/app/api" ]]; then
        while IFS= read -r route_file; do
            [[ -z "$route_file" ]] && continue
            local endpoint
            endpoint=$(echo "$route_file" | sed "s|${project_dir}/app/api||" | sed 's|/route\.\(ts\|js\)||' | sed 's|\[|{|g; s|\]|}|g')
            ACV_ENDPOINTS+=("/api${endpoint}")
            count=$((count + 1))
        done < <(find "${project_dir}/app/api" -name "route.ts" -o -name "route.js" 2>/dev/null)
    fi

    # Express routes
    if [[ -d "${project_dir}/routes" || -d "${project_dir}/src/routes" ]]; then
        local routes_dir="${project_dir}/routes"
        [[ ! -d "$routes_dir" ]] && routes_dir="${project_dir}/src/routes"
        local route_count
        route_count=$(find "$routes_dir" -name "*.ts" -o -name "*.js" 2>/dev/null | wc -l | tr -d ' ' || echo "0")
        count=$((count + route_count))
    fi

    # Express router.get/post/put/delete patterns
    local method_routes
    method_routes=$(grep -rn "router\.\(get\|post\|put\|delete\|patch\)\|app\.\(get\|post\|put\|delete\|patch\)" "$project_dir" \
        --include="*.ts" --include="*.js" \
        -l 2>/dev/null | grep -v node_modules | wc -l | tr -d ' ' || echo "0")
    [[ $count -eq 0 ]] && count=$method_routes

    ACV_ENDPOINT_COUNT=$count
    _acv_log "SUCCESS" "エンドポイント検出: ${count}件"

    echo "$count"
    return 0
}

# ============================================================
# Validate OpenAPI schema
# ============================================================
acv_validate_schema() {
    local project_dir="${1:-$ACV_PROJECT_DIR}"
    local errors=0

    # Check for OpenAPI spec
    local spec_file=""
    for f in openapi.yaml openapi.json swagger.yaml swagger.json; do
        if [[ -f "${project_dir}/${f}" ]]; then
            spec_file="${project_dir}/${f}"
            break
        fi
    done

    if [[ -z "$spec_file" ]]; then
        # No OpenAPI spec found - that's an issue
        ACV_ISSUES+=("[SCHEMA] OpenAPI/Swaggerスペックファイルが見つかりません")
        errors=$((errors + 1))
        _acv_log "WARN" "OpenAPIスペック未検出"
    else
        # Basic validation of spec file
        if [[ "$spec_file" =~ \.json$ ]]; then
            if ! python3 -c "import json; json.load(open('${spec_file}'))" 2>/dev/null; then
                ACV_ISSUES+=("[SCHEMA] OpenAPIスペックのJSON構文エラー")
                errors=$((errors + 1))
            fi
        elif [[ "$spec_file" =~ \.yaml$ ]]; then
            if ! python3 -c "import yaml; yaml.safe_load(open('${spec_file}'))" 2>/dev/null; then
                ACV_ISSUES+=("[SCHEMA] OpenAPIスペックのYAML構文エラー")
                errors=$((errors + 1))
            fi
        fi
    fi

    ACV_SCHEMA_ERRORS=$errors
    echo "$errors"
    return 0
}

# ============================================================
# Check frontend-backend consistency
# ============================================================
acv_check_consistency() {
    local project_dir="${1:-$ACV_PROJECT_DIR}"
    local errors=0

    # Find frontend API calls
    local frontend_calls
    frontend_calls=$(grep -rn "fetch(\|axios\.\|\.get(\|\.post(\|\.put(\|\.delete(" "$project_dir" \
        --include="*.tsx" --include="*.jsx" --include="*.ts" --include="*.js" \
        2>/dev/null | grep -v "node_modules" | grep -v ".next" || true)

    # Extract API endpoints called from frontend
    local called_endpoints
    called_endpoints=$(echo "$frontend_calls" | grep -oE "['\"]/(api/[^'\"]+)['\"]" | sort -u 2>/dev/null || true)

    if [[ -n "$called_endpoints" ]]; then
        local call_count
        call_count=$(echo "$called_endpoints" | wc -l | tr -d ' ')

        # Check if backend routes exist for called endpoints
        while IFS= read -r endpoint; do
            [[ -z "$endpoint" ]] && continue
            endpoint=$(echo "$endpoint" | tr -d "\"'")
            # Normalize: remove dynamic params
            local normalized
            normalized=$(echo "$endpoint" | sed 's|/[0-9a-f-]\{8,\}||g; s|/\$\{[^}]*\}||g')

            # Check if corresponding route file exists
            local route_path="${project_dir}/app${normalized}/route.ts"
            local route_path_js="${project_dir}/app${normalized}/route.js"
            if [[ ! -f "$route_path" && ! -f "$route_path_js" ]]; then
                # Not necessarily an error - could be dynamic routes
                :
            fi
        done <<< "$called_endpoints"
    fi

    # Check for hardcoded URLs (should use env vars)
    local hardcoded
    hardcoded=$(grep -rnE "https?://localhost|https?://127\.0\.0\.1|https?://0\.0\.0\.0" "$project_dir" \
        --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" \
        2>/dev/null | grep -v "node_modules" | grep -v ".next" | grep -v ".env" | wc -l | tr -d ' ' || echo "0")

    if [[ "$hardcoded" -gt 0 ]]; then
        ACV_ISSUES+=("[CONSISTENCY] ${hardcoded}箇所のハードコードURL (環境変数を使用してください)")
        errors=$((errors + hardcoded))
    fi

    ACV_CONSISTENCY_ERRORS=$errors

    if [[ "$errors" -gt 0 ]]; then
        _acv_log "WARN" "整合性エラー: ${errors}件"
    fi

    echo "$errors"
    return 0
}

# ============================================================
# Check error handling
# ============================================================
acv_check_error_handling() {
    local project_dir="${1:-$ACV_PROJECT_DIR}"
    local issues=0

    # Check API routes for try-catch
    local api_dir="${project_dir}/app/api"
    [[ ! -d "$api_dir" ]] && api_dir="${project_dir}/routes"
    [[ ! -d "$api_dir" ]] && api_dir="${project_dir}/src/routes"

    if [[ -d "$api_dir" ]]; then
        local route_files
        route_files=$(find "$api_dir" -name "*.ts" -o -name "*.js" 2>/dev/null | grep -v node_modules)

        while IFS= read -r file; do
            [[ -z "$file" || ! -f "$file" ]] && continue

            # Check for error handling
            local has_try_catch
            has_try_catch=$(grep -c "try\s*{" "$file" 2>/dev/null || echo "0")

            if [[ "$has_try_catch" -eq 0 ]]; then
                issues=$((issues + 1))
            fi
        done <<< "$route_files"
    fi

    ACV_ERROR_HANDLING_ISSUES=$issues

    if [[ "$issues" -gt 0 ]]; then
        ACV_ISSUES+=("[ERROR-HANDLING] ${issues}個のAPIルートにtry-catchが未実装")
        _acv_log "WARN" "エラーハンドリング不足: ${issues}件"
    fi

    echo "$issues"
    return 0
}

# ============================================================
# Check authentication consistency
# ============================================================
acv_check_auth() {
    local project_dir="${1:-$ACV_PROJECT_DIR}"
    local issues=0

    # Check if middleware/auth exists
    local has_auth_middleware=0
    if grep -rl "middleware\|getServerSession\|getToken\|verify.*jwt\|authenticate" "$project_dir" \
        --include="*.ts" --include="*.js" 2>/dev/null | grep -v node_modules | head -1 | grep -q .; then
        has_auth_middleware=1
    fi

    # Check API routes without auth protection
    if [[ "$has_auth_middleware" -eq 1 && -d "${project_dir}/app/api" ]]; then
        local unprotected
        unprotected=$(find "${project_dir}/app/api" -name "route.ts" -o -name "route.js" 2>/dev/null | while read -r f; do
            if ! grep -q "getServerSession\|getToken\|verify\|authenticate\|auth\|middleware" "$f" 2>/dev/null; then
                echo "$f"
            fi
        done | wc -l | tr -d ' ' || echo "0")

        if [[ "$unprotected" -gt 0 ]]; then
            # Exclude public routes (auth, register, health, etc.)
            local truly_unprotected=$((unprotected > 3 ? unprotected - 3 : 0))
            if [[ "$truly_unprotected" -gt 0 ]]; then
                ACV_ISSUES+=("[AUTH] ${truly_unprotected}個のAPIルートに認証チェックがありません")
                issues=$((issues + truly_unprotected))
            fi
        fi
    fi

    ACV_AUTH_ISSUES=$issues

    echo "$issues"
    return 0
}

# ============================================================
# Check API versioning
# ============================================================
acv_check_versioning() {
    local project_dir="${1:-$ACV_PROJECT_DIR}"
    local issues=0

    # Check if API routes have version prefix
    if [[ -d "${project_dir}/app/api" ]]; then
        local has_versioning
        has_versioning=$(find "${project_dir}/app/api" -type d -name "v[0-9]*" 2>/dev/null | head -1)

        if [[ -z "$has_versioning" ]]; then
            # No versioning found
            ACV_ISSUES+=("[VERSIONING] APIバージョニング (例: /api/v1/) が未実装")
            issues=$((issues + 1))
        fi
    fi

    ACV_VERSIONING_ISSUES=$issues
    echo "$issues"
    return 0
}

# ============================================================
# Score (0-100)
# ============================================================
acv_score() {
    local score=100

    # Schema errors
    if [[ "$ACV_SCHEMA_ERRORS" -gt 0 ]]; then
        local schema_penalty=$((ACV_SCHEMA_ERRORS * 10))
        [[ $schema_penalty -gt 20 ]] && schema_penalty=20
        score=$((score - schema_penalty))
    fi

    # Consistency errors
    if [[ "$ACV_CONSISTENCY_ERRORS" -gt 0 ]]; then
        local consist_penalty=$((ACV_CONSISTENCY_ERRORS * 3))
        [[ $consist_penalty -gt 20 ]] && consist_penalty=20
        score=$((score - consist_penalty))
    fi

    # Auth issues
    if [[ "$ACV_AUTH_ISSUES" -gt 0 ]]; then
        local auth_penalty=$((ACV_AUTH_ISSUES * 5))
        [[ $auth_penalty -gt 20 ]] && auth_penalty=20
        score=$((score - auth_penalty))
    fi

    # Error handling issues
    if [[ "$ACV_ERROR_HANDLING_ISSUES" -gt 0 ]]; then
        local err_penalty=$((ACV_ERROR_HANDLING_ISSUES * 3))
        [[ $err_penalty -gt 15 ]] && err_penalty=15
        score=$((score - err_penalty))
    fi

    # Versioning
    if [[ "$ACV_VERSIONING_ISSUES" -gt 0 ]]; then
        score=$((score - 5))
    fi

    # No endpoints detected penalty
    if [[ "$ACV_ENDPOINT_COUNT" -eq 0 ]]; then
        score=$((score - 10))
    fi

    [[ $score -lt 0 ]] && score=0
    ACV_SCORE=$score

    echo "$score"
    return 0
}

# ============================================================
# Full validation pipeline
# ============================================================
acv_full_validation() {
    local project_dir="${1:-$ACV_PROJECT_DIR}"

    acv_scan_endpoints "$project_dir"
    acv_validate_schema "$project_dir"
    acv_check_consistency "$project_dir"
    acv_check_error_handling "$project_dir"
    acv_check_auth "$project_dir"
    acv_check_versioning "$project_dir"
    acv_score

    echo "$ACV_SCORE"
    return 0
}

# ============================================================
# Report
# ============================================================
acv_report() {
    echo -e "  ${BOLD:-}${CYAN:-}╔══════════════════════════════════════════╗${NC:-}"
    echo -e "  ${BOLD:-}${CYAN:-}║  API Contract Validator Report (v25.0)   ║${NC:-}"
    echo -e "  ${BOLD:-}${CYAN:-}╚══════════════════════════════════════════╝${NC:-}"
    echo -e "  API形式:              ${ACV_API_STYLE}"
    echo -e "  エンドポイント数:     ${ACV_ENDPOINT_COUNT}"
    echo -e "  スキーマエラー:       ${ACV_SCHEMA_ERRORS}"
    echo -e "  整合性エラー:         ${ACV_CONSISTENCY_ERRORS}"
    echo -e "  認証問題:             ${ACV_AUTH_ISSUES}"
    echo -e "  エラーハンドリング:   ${ACV_ERROR_HANDLING_ISSUES}"
    echo -e "  バージョニング:       ${ACV_VERSIONING_ISSUES}"
    echo ""

    local score_color="${GREEN:-}"
    [[ "$ACV_SCORE" -lt 80 ]] && score_color="${YELLOW:-}"
    [[ "$ACV_SCORE" -lt 60 ]] && score_color="${RED:-}"
    echo -e "  API品質スコア:        ${score_color}${ACV_SCORE}/100${NC:-}"

    if [[ ${#ACV_ISSUES[@]} -gt 0 ]]; then
        echo ""
        echo -e "  ${BOLD:-}検出事項:${NC:-}"
        for issue in "${ACV_ISSUES[@]}"; do
            echo -e "    ${YELLOW:-}${issue}${NC:-}"
        done
    fi
}

# ============================================================
# JSON Report
# ============================================================
acv_report_json() {
    cat <<EOF
{
    "module": "api-contract-validator",
    "version": "${ACV_VERSION}",
    "api_style": "${ACV_API_STYLE}",
    "endpoint_count": ${ACV_ENDPOINT_COUNT},
    "schema_errors": ${ACV_SCHEMA_ERRORS},
    "consistency_errors": ${ACV_CONSISTENCY_ERRORS},
    "auth_issues": ${ACV_AUTH_ISSUES},
    "error_handling_issues": ${ACV_ERROR_HANDLING_ISSUES},
    "versioning_issues": ${ACV_VERSIONING_ISSUES},
    "score": ${ACV_SCORE}
}
EOF
}
