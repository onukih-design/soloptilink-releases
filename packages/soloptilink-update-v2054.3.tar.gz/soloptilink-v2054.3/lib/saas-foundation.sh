#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v300.0 - SaaS Foundation
# =============================================================================
# SaaS基盤自動生成。テナント分離、課金/サブスクリプション、
# テナントオンボーディング、スーパー管理パネルを生成する。
#
# 機能一覧:
#   _sf_generate_tenant_isolation - テナント分離
#   _sf_generate_billing          - 課金/サブスクリプション
#   _sf_generate_onboarding       - テナントオンボーディング
#   _sf_generate_admin_panel      - スーパー管理パネル
#
# 全globals: SF_ prefix
# =============================================================================

[[ -n "${_SF_LOADED:-}" ]] && return 0; _SF_LOADED=1

declare -g SF_VERSION="300.0"
declare -g SF_GENERATED=0
declare -g SF_ERRORS=0
declare -g SF_FILES_WRITTEN=0

sf_init() { SF_GENERATED=0; SF_ERRORS=0; SF_FILES_WRITTEN=0; return 0; }

_sf_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then SF_FILES_WRITTEN=$((SF_FILES_WRITTEN + 1)); echo "  [sf] wrote: $filepath" >&2
    else SF_ERRORS=$((SF_ERRORS + 1)); fi
}

_sf_log() { echo -e "  ${GREEN:-\033[0;32m}[SF]${NC:-\033[0m} $*" >&2; }

# =============================================================================
# _sf_generate_tenant_isolation
# =============================================================================
_sf_generate_tenant_isolation() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _sf_log "Generating tenant isolation..."

    local tenant_ts
    tenant_ts=$(cat <<'TENEOF'
// =============================================================================
// Tenant Isolation - Row-level isolation with AsyncLocalStorage
// Every query is automatically scoped to the current tenant
// =============================================================================
import { AsyncLocalStorage } from 'async_hooks';
import { PrismaClient } from '@prisma/client';

export interface TenantContext {
  tenantId: string;
  tenantName: string;
  plan: 'free' | 'pro' | 'enterprise';
  userId: string;
  role: string;
}

const tenantStorage = new AsyncLocalStorage<TenantContext>();

export function getCurrentTenant(): TenantContext {
  const ctx = tenantStorage.getStore();
  if (!ctx) throw new Error('No tenant context - ensure middleware sets tenant');
  return ctx;
}

export function runWithTenant<T>(ctx: TenantContext, fn: () => T): T {
  return tenantStorage.run(ctx, fn);
}

// --- Prisma Extension for Row-Level Security ---
export function createTenantPrisma(basePrisma: PrismaClient): PrismaClient {
  return basePrisma.$extends({
    query: {
      $allOperations({ model, operation, args, query }: any) {
        const tenant = tenantStorage.getStore();
        if (!tenant || !model) return query(args);

        // Skip tenant filtering for system models
        const systemModels = ['Tenant', 'Plan', 'SystemConfig'];
        if (systemModels.includes(model)) return query(args);

        // Inject tenantId into where clauses
        if (['findMany', 'findFirst', 'findUnique', 'count', 'aggregate', 'groupBy'].includes(operation)) {
          args.where = { ...args.where, tenantId: tenant.tenantId };
        }

        // Inject tenantId into create
        if (['create', 'createMany'].includes(operation)) {
          if (args.data) {
            if (Array.isArray(args.data)) {
              args.data = args.data.map((d: any) => ({ ...d, tenantId: tenant.tenantId }));
            } else {
              args.data.tenantId = tenant.tenantId;
            }
          }
        }

        // Inject tenantId into update/delete where
        if (['update', 'updateMany', 'delete', 'deleteMany'].includes(operation)) {
          args.where = { ...args.where, tenantId: tenant.tenantId };
        }

        return query(args);
      },
    },
  }) as unknown as PrismaClient;
}

// --- Middleware ---
export function tenantMiddleware(prisma: PrismaClient) {
  return async (req: any, res: any, next: any) => {
    // Extract tenant from subdomain, header, or JWT
    const tenantId = req.headers['x-tenant-id']
      || req.user?.tenantId
      || extractTenantFromHost(req.headers.host);

    if (!tenantId) {
      return res.status(400).json({ error: 'Tenant not identified' });
    }

    const tenant = await prisma.tenant.findUnique({ where: { id: tenantId } });
    if (!tenant || tenant.status !== 'active') {
      return res.status(403).json({ error: 'Tenant not found or inactive' });
    }

    const ctx: TenantContext = {
      tenantId: tenant.id,
      tenantName: tenant.name,
      plan: tenant.plan as any,
      userId: req.user?.userId || '',
      role: req.user?.role || 'user',
    };

    runWithTenant(ctx, () => next());
  };
}

function extractTenantFromHost(host?: string): string | null {
  if (!host) return null;
  const parts = host.split('.');
  if (parts.length >= 3) return parts[0]; // subdomain
  return null;
}
TENEOF
)
    _sf_write_file "${project_dir}/src/lib/saas/tenant-isolation.ts" "$tenant_ts"
    SF_GENERATED=$((SF_GENERATED + 1))
    return 0
}

# =============================================================================
# _sf_generate_billing
# =============================================================================
_sf_generate_billing() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _sf_log "Generating billing/subscription system..."

    local billing_ts
    billing_ts=$(cat <<'BILLEOF'
// =============================================================================
// SaaS Billing - Plan management, usage tracking, subscription lifecycle
// =============================================================================
import { z } from 'zod';

export const PlanSchema = z.object({
  id: z.string(),
  name: z.string(),
  price: z.number(),
  currency: z.string().default('JPY'),
  interval: z.enum(['month', 'year']),
  features: z.array(z.string()),
  limits: z.object({
    users: z.number(),
    storage: z.number(),   // MB
    apiCalls: z.number(),  // per month
    projects: z.number(),
  }),
  active: z.boolean().default(true),
});
export type Plan = z.infer<typeof PlanSchema>;

export const PLANS: Plan[] = [
  {
    id: 'free', name: 'Free', price: 0, currency: 'JPY', interval: 'month',
    features: ['3 users', '100MB storage', '1,000 API calls/month', '3 projects'],
    limits: { users: 3, storage: 100, apiCalls: 1000, projects: 3 }, active: true,
  },
  {
    id: 'pro', name: 'Pro', price: 4980, currency: 'JPY', interval: 'month',
    features: ['20 users', '10GB storage', '50,000 API calls/month', 'Unlimited projects', 'Priority support'],
    limits: { users: 20, storage: 10240, apiCalls: 50000, projects: -1 }, active: true,
  },
  {
    id: 'enterprise', name: 'Enterprise', price: 19800, currency: 'JPY', interval: 'month',
    features: ['Unlimited users', '100GB storage', 'Unlimited API calls', 'Dedicated support', 'Custom integrations', 'SLA'],
    limits: { users: -1, storage: 102400, apiCalls: -1, projects: -1 }, active: true,
  },
];

// --- Usage Tracking ---
export interface UsageRecord {
  tenantId: string;
  metric: 'api_calls' | 'storage_mb' | 'users';
  value: number;
  period: string;  // YYYY-MM
}

const usageStore: Map<string, number> = new Map();

export function trackUsage(tenantId: string, metric: string, increment = 1): void {
  const period = new Date().toISOString().slice(0, 7);
  const key = `${tenantId}:${metric}:${period}`;
  usageStore.set(key, (usageStore.get(key) || 0) + increment);
}

export function getUsage(tenantId: string, metric: string, period?: string): number {
  const p = period || new Date().toISOString().slice(0, 7);
  return usageStore.get(`${tenantId}:${metric}:${p}`) || 0;
}

export function checkLimit(tenantId: string, planId: string, metric: string): { allowed: boolean; current: number; limit: number } {
  const plan = PLANS.find((p) => p.id === planId);
  if (!plan) return { allowed: false, current: 0, limit: 0 };

  const limitMap: Record<string, number> = {
    users: plan.limits.users,
    storage_mb: plan.limits.storage,
    api_calls: plan.limits.apiCalls,
    projects: plan.limits.projects,
  };
  const limit = limitMap[metric] ?? -1;
  const current = getUsage(tenantId, metric);

  if (limit === -1) return { allowed: true, current, limit };
  return { allowed: current < limit, current, limit };
}

export function getPlan(planId: string): Plan | undefined { return PLANS.find((p) => p.id === planId); }
BILLEOF
)
    _sf_write_file "${project_dir}/src/lib/saas/billing.ts" "$billing_ts"
    SF_GENERATED=$((SF_GENERATED + 1))
    return 0
}

# =============================================================================
# _sf_generate_onboarding
# =============================================================================
_sf_generate_onboarding() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _sf_log "Generating tenant onboarding flow..."

    local onboard_ts
    onboard_ts=$(cat <<'ONBEOF'
// =============================================================================
// Tenant Onboarding Flow
// Step-by-step tenant setup: create tenant -> create admin -> setup billing
// =============================================================================
import { z } from 'zod';

export const OnboardingInputSchema = z.object({
  companyName: z.string().min(2).max(100),
  subdomain: z.string().min(3).max(50).regex(/^[a-z0-9-]+$/),
  adminEmail: z.string().email(),
  adminName: z.string().min(2),
  adminPassword: z.string().min(8),
  plan: z.enum(['free', 'pro', 'enterprise']).default('free'),
  timezone: z.string().default('Asia/Tokyo'),
  locale: z.string().default('ja'),
});
export type OnboardingInput = z.infer<typeof OnboardingInputSchema>;

export interface OnboardingResult {
  tenantId: string;
  adminUserId: string;
  subdomain: string;
  loginUrl: string;
  steps: Array<{ name: string; status: 'completed' | 'failed'; error?: string }>;
}

export async function onboardTenant(input: OnboardingInput): Promise<OnboardingResult> {
  const validated = OnboardingInputSchema.parse(input);
  const steps: OnboardingResult['steps'] = [];
  let tenantId = '';
  let adminUserId = '';

  // Step 1: Create tenant
  try {
    tenantId = crypto.randomUUID();
    // await prisma.tenant.create({ data: { id: tenantId, name: validated.companyName, subdomain: validated.subdomain, plan: validated.plan, ... } });
    steps.push({ name: 'Create tenant', status: 'completed' });
  } catch (err: any) {
    steps.push({ name: 'Create tenant', status: 'failed', error: err.message });
    throw new Error(`Onboarding failed at step 1: ${err.message}`);
  }

  // Step 2: Create admin user
  try {
    adminUserId = crypto.randomUUID();
    // const hashedPassword = await bcrypt.hash(validated.adminPassword, 12);
    // await prisma.user.create({ data: { id: adminUserId, tenantId, email: validated.adminEmail, name: validated.adminName, password: hashedPassword, role: 'admin' } });
    steps.push({ name: 'Create admin user', status: 'completed' });
  } catch (err: any) {
    steps.push({ name: 'Create admin user', status: 'failed', error: err.message });
    throw new Error(`Onboarding failed at step 2: ${err.message}`);
  }

  // Step 3: Initialize default settings
  try {
    // await prisma.tenantSettings.create({ data: { tenantId, timezone: validated.timezone, locale: validated.locale, ... } });
    steps.push({ name: 'Initialize settings', status: 'completed' });
  } catch (err: any) {
    steps.push({ name: 'Initialize settings', status: 'failed', error: err.message });
  }

  // Step 4: Send welcome email
  try {
    // await emailService.send({ to: validated.adminEmail, template: 'tenant-welcome', ... });
    steps.push({ name: 'Send welcome email', status: 'completed' });
  } catch (err: any) {
    steps.push({ name: 'Send welcome email', status: 'failed', error: err.message });
  }

  const baseUrl = process.env.BASE_URL || 'https://app.example.com';
  return {
    tenantId,
    adminUserId,
    subdomain: validated.subdomain,
    loginUrl: `https://${validated.subdomain}.${new URL(baseUrl).host}/login`,
    steps,
  };
}

export async function checkSubdomainAvailability(subdomain: string): Promise<boolean> {
  const reserved = ['www', 'api', 'admin', 'app', 'dashboard', 'mail', 'help', 'support', 'docs', 'status'];
  if (reserved.includes(subdomain)) return false;
  // const existing = await prisma.tenant.findUnique({ where: { subdomain } });
  // return !existing;
  return true;
}
ONBEOF
)
    _sf_write_file "${project_dir}/src/lib/saas/onboarding.ts" "$onboard_ts"
    SF_GENERATED=$((SF_GENERATED + 1))
    return 0
}

# =============================================================================
# _sf_generate_admin_panel
# =============================================================================
_sf_generate_admin_panel() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _sf_log "Generating super-admin panel API..."

    local admin_ts
    admin_ts=$(cat <<'ADMINEOF'
// =============================================================================
// Super Admin Panel API - Manage all tenants from a central dashboard
// =============================================================================
import { NextRequest, NextResponse } from 'next/server';

// GET /api/superadmin/tenants - List all tenants
export async function GET(req: NextRequest) {
  // Verify super-admin role
  const role = req.headers.get('x-user-role');
  if (role !== 'superadmin') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const { searchParams } = new URL(req.url);
  const status = searchParams.get('status') || 'all';
  const plan = searchParams.get('plan') || 'all';
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '20');

  // In real implementation: query database
  const mockTenants = [
    { id: 't1', name: 'Company A', subdomain: 'company-a', plan: 'pro', status: 'active', users: 12, createdAt: '2024-01-15', mrr: 4980 },
    { id: 't2', name: 'Company B', subdomain: 'company-b', plan: 'enterprise', status: 'active', users: 45, createdAt: '2024-02-20', mrr: 19800 },
    { id: 't3', name: 'Company C', subdomain: 'company-c', plan: 'free', status: 'active', users: 3, createdAt: '2024-03-10', mrr: 0 },
  ];

  return NextResponse.json({
    tenants: mockTenants,
    pagination: { page, limit, total: mockTenants.length, totalPages: 1 },
    stats: {
      totalTenants: mockTenants.length,
      activeTenants: mockTenants.filter((t) => t.status === 'active').length,
      totalMRR: mockTenants.reduce((s, t) => s + t.mrr, 0),
      totalUsers: mockTenants.reduce((s, t) => s + t.users, 0),
    },
  });
}

// POST /api/superadmin/tenants/:id/action
export async function POST(req: NextRequest) {
  const role = req.headers.get('x-user-role');
  if (role !== 'superadmin') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const body = await req.json();
  const { action, tenantId, reason } = body;

  switch (action) {
    case 'suspend':
      console.log(`[superadmin] Suspending tenant: ${tenantId} (reason: ${reason})`);
      return NextResponse.json({ success: true, action: 'suspended', tenantId });
    case 'reactivate':
      console.log(`[superadmin] Reactivating tenant: ${tenantId}`);
      return NextResponse.json({ success: true, action: 'reactivated', tenantId });
    case 'delete':
      console.log(`[superadmin] Deleting tenant: ${tenantId}`);
      return NextResponse.json({ success: true, action: 'deleted', tenantId });
    case 'upgrade':
      const { plan } = body;
      console.log(`[superadmin] Upgrading tenant ${tenantId} to ${plan}`);
      return NextResponse.json({ success: true, action: 'upgraded', tenantId, plan });
    case 'impersonate':
      console.log(`[superadmin] Impersonating tenant: ${tenantId}`);
      // Generate impersonation token
      return NextResponse.json({ success: true, action: 'impersonated', tenantId, token: 'imp_' + crypto.randomUUID() });
    default:
      return NextResponse.json({ error: `Unknown action: ${action}` }, { status: 400 });
  }
}
ADMINEOF
)
    _sf_write_file "${project_dir}/src/app/api/superadmin/tenants/route.ts" "$admin_ts"
    SF_GENERATED=$((SF_GENERATED + 1))
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
sf_report() {
    echo -e "\n  ${BOLD:-}=== saas-foundation v${SF_VERSION} ===${NC:-}"
    echo -e "  生成数: ${SF_GENERATED}"; echo -e "  エラー: ${SF_ERRORS}"
}

sf_score() {
    if [[ ${SF_GENERATED} -ge 4 ]] && [[ ${SF_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${SF_GENERATED} -gt 0 ]] && [[ ${SF_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "saas-foundation" --version "${SF_VERSION}" \
        --description "SaaS基盤×テナント分離×課金×オンボーディング×管理パネル" \
        --init "sf_init" --report "sf_report" --score "sf_score" \
        --enable-var "ENABLE_SAAS_FOUNDATION" --cli-flags "--saas-foundation:--no-saas-foundation"
fi

# v2003.1: source時のexit codeを確実に0にする
true
