#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v250.0 - Generation Quality Integration
# =============================================================================
# v221-v249 の全 Generation Quality モジュールを統合する
# オーケストレーションレイヤー。
#
# タスク要件を分析し、関連モジュールを選択、品質パターンを注入、
# 生成コードを検証する統合エンジン。
#
# 機能:
#   - 全 Generation Quality モジュールの初期化
#   - 要件分析 → 必要モジュール選択
#   - 生成プロンプトへの品質パターン注入
#   - 生成コードの品質検証
#   - 統合品質レポート生成
#
# 全globals: GQI_ prefix
# =============================================================================

[[ -n "${_GENERATION_QUALITY_INTEGRATION_LOADED:-}" ]] && return 0
_GENERATION_QUALITY_INTEGRATION_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g GQI_VERSION="250.0"
declare -g GQI_INITIALIZED=false
declare -g GQI_MODULES_AVAILABLE=0
declare -g GQI_MODULES_SELECTED=0
declare -g GQI_INJECTIONS_MADE=0
declare -g GQI_VALIDATIONS_RUN=0
declare -g GQI_VALIDATION_PASS=0
declare -g GQI_VALIDATION_FAIL=0
declare -g GQI_PROJECT_DIR=""
declare -g GQI_LOG_PREFIX="[GQI]"

# モジュール選択状態
declare -g GQI_USE_DARK_MODE=false
declare -g GQI_USE_A11Y=false
declare -g GQI_USE_SEO=false
declare -g GQI_USE_PERF_BUDGET=false
declare -g GQI_USE_CODE_SPLIT=false
declare -g GQI_USE_IMAGE_OPT=false
declare -g GQI_USE_CACHE=false
declare -g GQI_USE_RATE_LIMIT=false
declare -g GQI_USE_LOGGING=false

# v221-v240 モジュール（存在すれば使用）
declare -g GQI_USE_FORM_GEN=false
declare -g GQI_USE_TABLE_GEN=false
declare -g GQI_USE_AUTH_GEN=false
declare -g GQI_USE_API_GEN=false

# =============================================================================
# ログユーティリティ
# =============================================================================
_gqi_log() { echo -e "  ${CLR_CYAN:-\033[0;36m}${GQI_LOG_PREFIX}${CLR_NC:-\033[0m} $*" >&2; }
_gqi_success() { echo -e "  ${CLR_GREEN:-\033[0;32m}${GQI_LOG_PREFIX} OK${CLR_NC:-\033[0m} $*" >&2; }
_gqi_warn() { echo -e "  ${CLR_YELLOW:-\033[0;33m}${GQI_LOG_PREFIX} WARN${CLR_NC:-\033[0m} $*" >&2; }
_gqi_error() { echo -e "  ${CLR_RED:-\033[0;31m}${GQI_LOG_PREFIX} ERROR${CLR_NC:-\033[0m} $*" >&2; }

# =============================================================================
# 初期化
# =============================================================================
# 全 Generation Quality モジュール (v221-v249) を検出し初期化する。
#
# 使い方: _gqi_init
# =============================================================================
_gqi_init() {
    GQI_INITIALIZED=true
    GQI_MODULES_AVAILABLE=0
    GQI_MODULES_SELECTED=0
    GQI_INJECTIONS_MADE=0
    GQI_VALIDATIONS_RUN=0
    GQI_VALIDATION_PASS=0
    GQI_VALIDATION_FAIL=0
    GQI_PROJECT_DIR="${PROJECT_DIR:-.}"

    _gqi_log "Generation Quality Integration v${GQI_VERSION} 初期化中..."

    # v241-v249 モジュールの存在チェック
    local modules=(
        "dark-mode-generator:DMG:dmg_init"
        "accessibility-enforcer:AE:ae_init"
        "seo-optimizer:SO:so_init"
        "performance-budget-engine:PBE:pbe_init"
        "code-splitting-optimizer:CSO:cso_init"
        "image-optimization-pipeline:IOP:iop_init"
        "caching-strategy-generator:CSG:csg_init"
        "rate-limiting-system:RLS:rls_init"
        "logging-monitoring-setup:LMS:lms_init"
    )

    for entry in "${modules[@]}"; do
        local name="${entry%%:*}"
        local rest="${entry#*:}"
        local prefix="${rest%%:*}"
        local init_fn="${rest#*:}"

        if type -t "$init_fn" &>/dev/null; then
            GQI_MODULES_AVAILABLE=$((GQI_MODULES_AVAILABLE + 1))
            _gqi_log "  検出: ${name} (v${prefix})"
        fi
    done

    _gqi_success "利用可能モジュール: ${GQI_MODULES_AVAILABLE}/9"
    return 0
}

gqi_init() {
    _gqi_init
}

# =============================================================================
# 要件分析
# =============================================================================
# プロジェクト要件（プロンプト、既存コード）を分析し、
# どの Generation Quality モジュールが必要かを判定する。
#
# 使い方: _gqi_analyze_requirements <prompt> [project_dir]
# =============================================================================
_gqi_analyze_requirements() {
    local prompt="${1:-}"
    local project_dir="${2:-${GQI_PROJECT_DIR}}"

    [[ "$GQI_INITIALIZED" != "true" ]] && { _gqi_error "未初期化"; return 1; }

    _gqi_log "要件分析中..."

    local prompt_lower
    prompt_lower=$(echo "$prompt" | tr '[:upper:]' '[:lower:]')

    # プロンプトキーワードからモジュール推定
    # ダークモード
    if [[ "$prompt_lower" == *"dark"* || "$prompt_lower" == *"テーマ"* || "$prompt_lower" == *"ダーク"* ]]; then
        GQI_USE_DARK_MODE=true
        _gqi_log "  要件検出: ダークモード対応"
    fi

    # アクセシビリティ（常に推奨）
    GQI_USE_A11Y=true
    _gqi_log "  要件: アクセシビリティ (常時有効)"

    # SEO
    if [[ "$prompt_lower" == *"seo"* || "$prompt_lower" == *"lp"* || "$prompt_lower" == *"ランディング"* \
       || "$prompt_lower" == *"ブログ"* || "$prompt_lower" == *"cms"* || "$prompt_lower" == *"公開"* ]]; then
        GQI_USE_SEO=true
        _gqi_log "  要件検出: SEO 最適化"
    fi

    # パフォーマンス（常に推奨）
    GQI_USE_PERF_BUDGET=true
    _gqi_log "  要件: パフォーマンスバジェット (常時有効)"

    # コード分割
    if [[ "$prompt_lower" == *"dashboard"* || "$prompt_lower" == *"admin"* || "$prompt_lower" == *"管理"* \
       || "$prompt_lower" == *"saas"* || "$prompt_lower" == *"大規模"* ]]; then
        GQI_USE_CODE_SPLIT=true
        _gqi_log "  要件検出: コード分割"
    fi

    # 画像最適化
    if [[ "$prompt_lower" == *"画像"* || "$prompt_lower" == *"image"* || "$prompt_lower" == *"写真"* \
       || "$prompt_lower" == *"ギャラリー"* || "$prompt_lower" == *"ec"* || "$prompt_lower" == *"ecommerce"* ]]; then
        GQI_USE_IMAGE_OPT=true
        _gqi_log "  要件検出: 画像最適化"
    fi

    # キャッシュ
    if [[ "$prompt_lower" == *"api"* || "$prompt_lower" == *"saas"* || "$prompt_lower" == *"高速"* \
       || "$prompt_lower" == *"パフォーマンス"* || "$prompt_lower" == *"cache"* ]]; then
        GQI_USE_CACHE=true
        _gqi_log "  要件検出: キャッシュ戦略"
    fi

    # レート制限
    if [[ "$prompt_lower" == *"api"* || "$prompt_lower" == *"saas"* || "$prompt_lower" == *"認証"* \
       || "$prompt_lower" == *"セキュリティ"* || "$prompt_lower" == *"公開api"* ]]; then
        GQI_USE_RATE_LIMIT=true
        _gqi_log "  要件検出: レート制限"
    fi

    # ロギング & 監視（本番向けは常に推奨）
    if [[ "$prompt_lower" == *"本番"* || "$prompt_lower" == *"production"* || "$prompt_lower" == *"デプロイ"* \
       || "$prompt_lower" == *"saas"* || "$prompt_lower" == *"監視"* || "$prompt_lower" == *"ログ"* ]]; then
        GQI_USE_LOGGING=true
        _gqi_log "  要件検出: ロギング & 監視"
    fi

    # 既存プロジェクトの分析
    if [[ -d "$project_dir" ]]; then
        # package.json の依存関係チェック
        if [[ -f "${project_dir}/package.json" ]]; then
            if grep -q '"next"' "${project_dir}/package.json" 2>/dev/null; then
                GQI_USE_IMAGE_OPT=true
                GQI_USE_CODE_SPLIT=true
            fi
            if grep -q '"prisma\|drizzle"' "${project_dir}/package.json" 2>/dev/null; then
                GQI_USE_CACHE=true
            fi
        fi

        # API ルートがあればレート制限を推奨
        if [[ -d "${project_dir}/app/api" ]]; then
            GQI_USE_RATE_LIMIT=true
            GQI_USE_LOGGING=true
        fi
    fi

    # v2003.1: Layer 26 生成エンジン群の自動有効化
    # フォーム生成（フルスタック/CRM/管理画面は必ずフォームを含む）
    if [[ "$prompt_lower" == *"フォーム"* || "$prompt_lower" == *"form"* || "$prompt_lower" == *"入力"* \
       || "$prompt_lower" == *"crm"* || "$prompt_lower" == *"管理"* || "$prompt_lower" == *"admin"* \
       || "$prompt_lower" == *"登録"* || "$prompt_lower" == *"予約"* ]]; then
        GQI_USE_FORM_GEN=true
        _gqi_log "  要件検出: フォーム自動生成"
    fi

    # テーブル/リスト生成
    if [[ "$prompt_lower" == *"一覧"* || "$prompt_lower" == *"リスト"* || "$prompt_lower" == *"table"* \
       || "$prompt_lower" == *"管理"* || "$prompt_lower" == *"ダッシュボード"* || "$prompt_lower" == *"crm"* \
       || "$prompt_lower" == *"在庫"* || "$prompt_lower" == *"hr"* ]]; then
        GQI_USE_TABLE_GEN=true
        _gqi_log "  要件検出: テーブル/リスト自動生成"
    fi

    # 認証フロー生成
    if [[ "$prompt_lower" == *"認証"* || "$prompt_lower" == *"ログイン"* || "$prompt_lower" == *"auth"* \
       || "$prompt_lower" == *"login"* || "$prompt_lower" == *"saas"* || "$prompt_lower" == *"ユーザー"* \
       || "$prompt_lower" == *"会員"* || "$prompt_lower" == *"アカウント"* ]]; then
        GQI_USE_AUTH_GEN=true
        _gqi_log "  要件検出: 認証フロー自動生成"
    fi

    # ダッシュボード生成
    if [[ "$prompt_lower" == *"ダッシュボード"* || "$prompt_lower" == *"dashboard"* || "$prompt_lower" == *"kpi"* \
       || "$prompt_lower" == *"分析"* || "$prompt_lower" == *"レポート"* ]]; then
        GQI_USE_DASHBOARD_GEN=true
        _gqi_log "  要件検出: ダッシュボード自動生成"
    fi

    # 選択モジュール数をカウント
    local selected=0
    [[ "$GQI_USE_DARK_MODE" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_A11Y" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_SEO" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_PERF_BUDGET" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_CODE_SPLIT" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_IMAGE_OPT" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_CACHE" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_RATE_LIMIT" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_LOGGING" == "true" ]] && selected=$((selected + 1))
    [[ "${GQI_USE_FORM_GEN:-false}" == "true" ]] && selected=$((selected + 1))
    [[ "${GQI_USE_TABLE_GEN:-false}" == "true" ]] && selected=$((selected + 1))
    [[ "${GQI_USE_AUTH_GEN:-false}" == "true" ]] && selected=$((selected + 1))
    [[ "${GQI_USE_DASHBOARD_GEN:-false}" == "true" ]] && selected=$((selected + 1))

    GQI_MODULES_SELECTED=$selected
    _gqi_success "要件分析完了: ${selected}モジュール選択"
    echo "$selected"
    return 0
}

# =============================================================================
# モジュール選択
# =============================================================================
# 要件分析結果に基づいて、使用するモジュールを手動選択/上書きする。
#
# 使い方: _gqi_select_modules [--dark-mode] [--a11y] [--seo] [--perf] ...
# =============================================================================
_gqi_select_modules() {
    [[ "$GQI_INITIALIZED" != "true" ]] && { _gqi_error "未初期化"; return 1; }

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --dark-mode)    GQI_USE_DARK_MODE=true; shift ;;
            --no-dark-mode) GQI_USE_DARK_MODE=false; shift ;;
            --a11y)         GQI_USE_A11Y=true; shift ;;
            --no-a11y)      GQI_USE_A11Y=false; shift ;;
            --seo)          GQI_USE_SEO=true; shift ;;
            --no-seo)       GQI_USE_SEO=false; shift ;;
            --perf)         GQI_USE_PERF_BUDGET=true; shift ;;
            --no-perf)      GQI_USE_PERF_BUDGET=false; shift ;;
            --code-split)   GQI_USE_CODE_SPLIT=true; shift ;;
            --image-opt)    GQI_USE_IMAGE_OPT=true; shift ;;
            --cache)        GQI_USE_CACHE=true; shift ;;
            --rate-limit)   GQI_USE_RATE_LIMIT=true; shift ;;
            --logging)      GQI_USE_LOGGING=true; shift ;;
            --all)
                GQI_USE_DARK_MODE=true; GQI_USE_A11Y=true; GQI_USE_SEO=true
                GQI_USE_PERF_BUDGET=true; GQI_USE_CODE_SPLIT=true; GQI_USE_IMAGE_OPT=true
                GQI_USE_CACHE=true; GQI_USE_RATE_LIMIT=true; GQI_USE_LOGGING=true
                shift ;;
            *) shift ;;
        esac
    done

    local selected=0
    [[ "$GQI_USE_DARK_MODE" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_A11Y" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_SEO" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_PERF_BUDGET" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_CODE_SPLIT" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_IMAGE_OPT" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_CACHE" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_RATE_LIMIT" == "true" ]] && selected=$((selected + 1))
    [[ "$GQI_USE_LOGGING" == "true" ]] && selected=$((selected + 1))

    GQI_MODULES_SELECTED=$selected
    _gqi_success "モジュール選択: ${selected}個"
    return 0
}

# =============================================================================
# 品質パターン注入
# =============================================================================
# 選択されたモジュールの品質ルールを生成プロンプトに注入する。
# 各モジュールの _inject_prompt を呼び出し、統合プロンプトを構築。
#
# 使い方: _gqi_inject_quality
# =============================================================================
_gqi_inject_quality() {
    [[ "$GQI_INITIALIZED" != "true" ]] && { _gqi_error "未初期化"; return 1; }

    _gqi_log "品質パターン注入開始"

    local prompt=""

    prompt+="# === Generation Quality Rules (v250.0) ===\n"
    prompt+="# 以下のルールに必ず従ってコードを生成すること。\n\n"

    # 各モジュールのプロンプト注入
    if [[ "$GQI_USE_DARK_MODE" == "true" ]] && type -t _dmg_inject_prompt &>/dev/null; then
        prompt+="$(_dmg_inject_prompt)\n\n"
        GQI_INJECTIONS_MADE=$((GQI_INJECTIONS_MADE + 1))
    fi

    if [[ "$GQI_USE_A11Y" == "true" ]] && type -t _ae_inject_prompt &>/dev/null; then
        prompt+="$(_ae_inject_prompt)\n\n"
        GQI_INJECTIONS_MADE=$((GQI_INJECTIONS_MADE + 1))
    fi

    if [[ "$GQI_USE_SEO" == "true" ]] && type -t _so_inject_prompt &>/dev/null; then
        prompt+="$(_so_inject_prompt)\n\n"
        GQI_INJECTIONS_MADE=$((GQI_INJECTIONS_MADE + 1))
    fi

    if [[ "$GQI_USE_PERF_BUDGET" == "true" ]] && type -t _pbe_inject_prompt &>/dev/null; then
        prompt+="$(_pbe_inject_prompt)\n\n"
        GQI_INJECTIONS_MADE=$((GQI_INJECTIONS_MADE + 1))
    fi

    if [[ "$GQI_USE_CODE_SPLIT" == "true" ]] && type -t _cso_inject_prompt &>/dev/null; then
        prompt+="$(_cso_inject_prompt)\n\n"
        GQI_INJECTIONS_MADE=$((GQI_INJECTIONS_MADE + 1))
    fi

    if [[ "$GQI_USE_IMAGE_OPT" == "true" ]] && type -t _iop_inject_prompt &>/dev/null; then
        prompt+="$(_iop_inject_prompt)\n\n"
        GQI_INJECTIONS_MADE=$((GQI_INJECTIONS_MADE + 1))
    fi

    if [[ "$GQI_USE_CACHE" == "true" ]] && type -t _csg_inject_prompt &>/dev/null; then
        prompt+="$(_csg_inject_prompt)\n\n"
        GQI_INJECTIONS_MADE=$((GQI_INJECTIONS_MADE + 1))
    fi

    if [[ "$GQI_USE_RATE_LIMIT" == "true" ]] && type -t _rls_inject_prompt &>/dev/null; then
        prompt+="$(_rls_inject_prompt)\n\n"
        GQI_INJECTIONS_MADE=$((GQI_INJECTIONS_MADE + 1))
    fi

    if [[ "$GQI_USE_LOGGING" == "true" ]] && type -t _lms_inject_prompt &>/dev/null; then
        prompt+="$(_lms_inject_prompt)\n\n"
        GQI_INJECTIONS_MADE=$((GQI_INJECTIONS_MADE + 1))
    fi

    _gqi_success "品質パターン注入完了: ${GQI_INJECTIONS_MADE}モジュール"

    echo -e "$prompt"
    return 0
}

# =============================================================================
# 生成コード品質検証
# =============================================================================
# 選択されたモジュールの検証ロジックを実行し、
# 生成されたコードが品質基準を満たすか確認する。
#
# 使い方: _gqi_validate_output [project_dir]
# =============================================================================
_gqi_validate_output() {
    local project_dir="${1:-${GQI_PROJECT_DIR}}"
    local total_issues=0

    [[ "$GQI_INITIALIZED" != "true" ]] && { _gqi_error "未初期化"; return 1; }

    _gqi_log "=== 生成コード品質検証開始 ==="

    # ダークモードチェック
    if [[ "$GQI_USE_DARK_MODE" == "true" ]] && type -t _dmg_check_dark_mode_support &>/dev/null; then
        GQI_VALIDATIONS_RUN=$((GQI_VALIDATIONS_RUN + 1))
        local issues
        issues=$(_dmg_check_dark_mode_support "$project_dir")
        total_issues=$((total_issues + issues))
        [[ $issues -eq 0 ]] && GQI_VALIDATION_PASS=$((GQI_VALIDATION_PASS + 1)) || GQI_VALIDATION_FAIL=$((GQI_VALIDATION_FAIL + 1))
    fi

    # アクセシビリティチェック
    if [[ "$GQI_USE_A11Y" == "true" ]] && type -t _ae_check_aria &>/dev/null; then
        GQI_VALIDATIONS_RUN=$((GQI_VALIDATIONS_RUN + 1))
        local aria_issues keyboard_issues contrast_issues sr_issues
        aria_issues=$(_ae_check_aria "$project_dir")
        keyboard_issues=$(_ae_check_keyboard "$project_dir")
        contrast_issues=$(_ae_check_contrast "$project_dir")
        sr_issues=$(_ae_check_screen_reader "$project_dir")
        local a11y_total=$((aria_issues + keyboard_issues + contrast_issues + sr_issues))
        total_issues=$((total_issues + a11y_total))
        [[ $a11y_total -eq 0 ]] && GQI_VALIDATION_PASS=$((GQI_VALIDATION_PASS + 1)) || GQI_VALIDATION_FAIL=$((GQI_VALIDATION_FAIL + 1))
    fi

    # SEO チェック
    if [[ "$GQI_USE_SEO" == "true" ]] && type -t _so_check_seo_issues &>/dev/null; then
        GQI_VALIDATIONS_RUN=$((GQI_VALIDATIONS_RUN + 1))
        local seo_issues
        seo_issues=$(_so_check_seo_issues "$project_dir")
        total_issues=$((total_issues + seo_issues))
        [[ $seo_issues -eq 0 ]] && GQI_VALIDATION_PASS=$((GQI_VALIDATION_PASS + 1)) || GQI_VALIDATION_FAIL=$((GQI_VALIDATION_FAIL + 1))
    fi

    # パフォーマンスバジェットチェック
    if [[ "$GQI_USE_PERF_BUDGET" == "true" ]] && type -t _pbe_check_budgets &>/dev/null; then
        GQI_VALIDATIONS_RUN=$((GQI_VALIDATIONS_RUN + 1))
        local perf_issues
        perf_issues=$(_pbe_check_budgets "$project_dir")
        total_issues=$((total_issues + perf_issues))
        [[ $perf_issues -eq 0 ]] && GQI_VALIDATION_PASS=$((GQI_VALIDATION_PASS + 1)) || GQI_VALIDATION_FAIL=$((GQI_VALIDATION_FAIL + 1))
    fi

    # コード分割チェック
    if [[ "$GQI_USE_CODE_SPLIT" == "true" ]] && type -t _cso_find_split_points &>/dev/null; then
        GQI_VALIDATIONS_RUN=$((GQI_VALIDATIONS_RUN + 1))
        local split_issues
        split_issues=$(_cso_find_split_points "$project_dir")
        # 分割ポイントがある = 最適化余地あり（問題としてカウント）
        total_issues=$((total_issues + split_issues))
        [[ $split_issues -eq 0 ]] && GQI_VALIDATION_PASS=$((GQI_VALIDATION_PASS + 1)) || GQI_VALIDATION_FAIL=$((GQI_VALIDATION_FAIL + 1))
    fi

    # 画像最適化チェック
    if [[ "$GQI_USE_IMAGE_OPT" == "true" ]] && type -t _iop_find_unoptimized &>/dev/null; then
        GQI_VALIDATIONS_RUN=$((GQI_VALIDATIONS_RUN + 1))
        local img_issues
        img_issues=$(_iop_find_unoptimized "$project_dir")
        total_issues=$((total_issues + img_issues))
        [[ $img_issues -eq 0 ]] && GQI_VALIDATION_PASS=$((GQI_VALIDATION_PASS + 1)) || GQI_VALIDATION_FAIL=$((GQI_VALIDATION_FAIL + 1))
    fi

    # 品質スコア計算
    local quality_score=100
    if [[ $GQI_VALIDATIONS_RUN -gt 0 ]]; then
        quality_score=$((GQI_VALIDATION_PASS * 100 / GQI_VALIDATIONS_RUN))
    fi

    if [[ $total_issues -eq 0 ]]; then
        _gqi_success "=== 品質検証完了: PASS (スコア: ${quality_score}/100) ==="
    else
        _gqi_warn "=== 品質検証完了: ${total_issues}件の問題 (スコア: ${quality_score}/100) ==="
    fi

    echo "$total_issues"
    return 0
}

# =============================================================================
# 統合品質レポート生成
# =============================================================================
_gqi_report_full() {
    local output_file="${1:-${GQI_PROJECT_DIR}/generation-quality-report.json}"

    [[ "$GQI_INITIALIZED" != "true" ]] && { _gqi_error "未初期化"; return 1; }

    _gqi_log "統合品質レポート生成中"

    mkdir -p "$(dirname "$output_file")" 2>/dev/null || true

    local quality_score=0
    if [[ $GQI_VALIDATIONS_RUN -gt 0 ]]; then
        quality_score=$((GQI_VALIDATION_PASS * 100 / GQI_VALIDATIONS_RUN))
    fi

    local status="PASS"
    [[ $quality_score -lt 70 ]] && status="FAIL"
    [[ $quality_score -ge 70 && $quality_score -lt 90 ]] && status="WARN"

    cat > "$output_file" <<EOF
{
  "report": "Generation Quality Integration Report",
  "version": "${GQI_VERSION}",
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "status": "${status}",
  "quality_score": ${quality_score},
  "summary": {
    "modules_available": ${GQI_MODULES_AVAILABLE},
    "modules_selected": ${GQI_MODULES_SELECTED},
    "injections_made": ${GQI_INJECTIONS_MADE},
    "validations_run": ${GQI_VALIDATIONS_RUN},
    "validations_pass": ${GQI_VALIDATION_PASS},
    "validations_fail": ${GQI_VALIDATION_FAIL}
  },
  "modules": {
    "dark_mode": ${GQI_USE_DARK_MODE},
    "accessibility": ${GQI_USE_A11Y},
    "seo": ${GQI_USE_SEO},
    "performance_budget": ${GQI_USE_PERF_BUDGET},
    "code_splitting": ${GQI_USE_CODE_SPLIT},
    "image_optimization": ${GQI_USE_IMAGE_OPT},
    "caching": ${GQI_USE_CACHE},
    "rate_limiting": ${GQI_USE_RATE_LIMIT},
    "logging_monitoring": ${GQI_USE_LOGGING}
  }
}
EOF

    if [[ -f "$output_file" ]]; then
        _gqi_success "統合レポート生成完了: ${output_file}"
        return 0
    fi
    return 1
}

# =============================================================================
# フルパイプライン実行
# =============================================================================
# 分析 → モジュール選択 → 品質注入 → コード生成後検証 の全工程を実行。
#
# 使い方: _gqi_run_pipeline <prompt> [project_dir]
# =============================================================================
_gqi_run_pipeline() {
    local prompt="${1:-}"
    local project_dir="${2:-${GQI_PROJECT_DIR}}"

    [[ "$GQI_INITIALIZED" != "true" ]] && { _gqi_error "未初期化"; return 1; }

    _gqi_log "=== Generation Quality Pipeline 開始 ==="

    # Step 1: 要件分析
    _gqi_analyze_requirements "$prompt" "$project_dir"

    # Step 2: 品質パターン注入（プロンプト生成）
    local quality_prompt
    quality_prompt=$(_gqi_inject_quality)

    # Step 3: プロンプトを返す（呼び出し元で Claude に渡す）
    echo "$quality_prompt"

    _gqi_success "=== Pipeline 完了: ${GQI_MODULES_SELECTED}モジュール適用 ==="
    return 0
}

# =============================================================================
# ポスト生成検証パイプライン
# =============================================================================
_gqi_post_generation_validate() {
    local project_dir="${1:-${GQI_PROJECT_DIR}}"

    [[ "$GQI_INITIALIZED" != "true" ]] && { _gqi_error "未初期化"; return 1; }

    _gqi_log "=== ポスト生成検証開始 ==="

    # 検証実行
    local issues
    issues=$(_gqi_validate_output "$project_dir")

    # レポート生成
    _gqi_report_full "${project_dir}/generation-quality-report.json"

    _gqi_success "=== ポスト生成検証完了: ${issues}件の問題 ==="
    echo "$issues"
    return 0
}

# =============================================================================
# レポート
# =============================================================================
gqi_report() {
    echo -e "\n  ${BOLD:-}--- Generation Quality Integration v${GQI_VERSION} ---${NC:-}"
    echo -e "  利用可能モジュール : ${GQI_MODULES_AVAILABLE}"
    echo -e "  選択モジュール     : ${GQI_MODULES_SELECTED}"
    echo -e "  品質注入回数       : ${GQI_INJECTIONS_MADE}"
    echo -e "  検証実行数         : ${GQI_VALIDATIONS_RUN}"
    echo -e "  検証 PASS          : ${GQI_VALIDATION_PASS}"
    echo -e "  検証 FAIL          : ${GQI_VALIDATION_FAIL}"
}

gqi_report_json() {
    cat <<EOF
{"module":"generation-quality-integration","version":"${GQI_VERSION}","modules_available":${GQI_MODULES_AVAILABLE},"modules_selected":${GQI_MODULES_SELECTED},"injections":${GQI_INJECTIONS_MADE},"validations_run":${GQI_VALIDATIONS_RUN},"pass":${GQI_VALIDATION_PASS},"fail":${GQI_VALIDATION_FAIL}}
EOF
}

gqi_score() {
    if [[ "$GQI_INITIALIZED" != "true" ]]; then echo 0; return; fi
    if [[ $GQI_VALIDATIONS_RUN -eq 0 ]]; then echo 70; return; fi
    echo "$((GQI_VALIDATION_PASS * 100 / GQI_VALIDATIONS_RUN))"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "generation-quality-integration" \
        --version "250.0" \
        --description "v221-v249 全Generation Quality モジュール統合オーケストレーション" \
        --init "gqi_init" \
        --report "gqi_report" \
        --score "gqi_score" \
        --enable-var "ENABLE_GQ_INTEGRATION" \
        --cli-flags "--gq-integration:--no-gq-integration"
fi

# v2003.1: source時のexit codeを確実に0にする
true
