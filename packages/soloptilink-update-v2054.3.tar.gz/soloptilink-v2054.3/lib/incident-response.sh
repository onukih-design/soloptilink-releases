#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v357.0 - Incident Response Engine
# =============================================================================
# インシデント検出×チーム通知×ポストモーテム生成
#
# 機能:
#   - インシデント自動検出（閾値ベース/異常検知）
#   - 重要度分類（SEV1-SEV4）
#   - チーム通知（Slack/Email/PagerDuty連携）
#   - インシデントタイムライン生成
#   - ポストモーテムテンプレート自動生成
#   - ランブック生成
#
# 全globals: IR_ prefix
# =============================================================================

[[ -n "${_IR_LOADED:-}" ]] && return 0; _IR_LOADED=1

IR_VERSION="357.0"
IR_GENERATED=0
IR_ERRORS=0
IR_PHASE="incident_response"
IR_FILES_CREATED=()
IR_INCIDENTS_DETECTED=0

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_ir_log() { echo -e "  ${CYAN}[IR]${NC} $*"; }
_ir_ok() { echo -e "  ${GREEN}[IR]${NC} $*"; }
_ir_err() { echo -e "  ${RED}[IR]${NC} $*"; }

_ir_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        IR_FILES_CREATED+=("$filepath")
        IR_GENERATED=$((IR_GENERATED + 1))
        _ir_ok "Created: ${filepath##*/}"
    else
        IR_ERRORS=$((IR_ERRORS + 1))
        _ir_err "Failed: ${filepath##*/}"
    fi
}

ir_init() {
    IR_GENERATED=0; IR_ERRORS=0; IR_INCIDENTS_DETECTED=0; IR_FILES_CREATED=()
    _ir_log "Incident Response Engine v${IR_VERSION} initialized"
    return 0
}

# =============================================================================
# Detect Incident
# =============================================================================
_ir_detect_incident() {
    local project_dir="${1:-.}"

    _ir_log "Generating incident detection system..."

    local ir_dir="${project_dir}/src/lib/incidents"
    mkdir -p "$ir_dir" 2>/dev/null

    _ir_write_file "${ir_dir}/detector.ts" "$(cat <<'TS'
import { z } from 'zod';

export const SeveritySchema = z.enum(['SEV1', 'SEV2', 'SEV3', 'SEV4']);
export type Severity = z.infer<typeof SeveritySchema>;

export const IncidentSchema = z.object({
  id: z.string(),
  title: z.string(),
  severity: SeveritySchema,
  status: z.enum(['detected', 'acknowledged', 'investigating', 'mitigating', 'resolved', 'postmortem']),
  detectedAt: z.string().datetime(),
  acknowledgedAt: z.string().datetime().optional(),
  resolvedAt: z.string().datetime().optional(),
  affectedServices: z.array(z.string()),
  timeline: z.array(z.object({
    timestamp: z.string().datetime(),
    action: z.string(),
    actor: z.string(),
  })),
  commander: z.string().optional(),
  slackChannel: z.string().optional(),
});

export type Incident = z.infer<typeof IncidentSchema>;

interface DetectionRule {
  name: string;
  condition: (metrics: Record<string, number>) => boolean;
  severity: Severity;
  affectedServices: string[];
}

export class IncidentDetector {
  private rules: DetectionRule[] = [];
  private activeIncidents = new Map<string, Incident>();
  private incidentCounter = 0;

  addRule(rule: DetectionRule): void {
    this.rules.push(rule);
  }

  evaluate(metrics: Record<string, number>): Incident[] {
    const newIncidents: Incident[] = [];

    for (const rule of this.rules) {
      if (rule.condition(metrics)) {
        const existing = Array.from(this.activeIncidents.values()).find(
          i => i.title === rule.name && i.status !== 'resolved'
        );
        if (existing) continue;

        this.incidentCounter++;
        const incident: Incident = {
          id: `INC-${String(this.incidentCounter).padStart(4, '0')}`,
          title: rule.name,
          severity: rule.severity,
          status: 'detected',
          detectedAt: new Date().toISOString(),
          affectedServices: rule.affectedServices,
          timeline: [{
            timestamp: new Date().toISOString(),
            action: `Incident detected: ${rule.name}`,
            actor: 'system',
          }],
        };

        this.activeIncidents.set(incident.id, incident);
        newIncidents.push(incident);
      }
    }

    return newIncidents;
  }

  acknowledge(id: string, commander: string): void {
    const incident = this.activeIncidents.get(id);
    if (!incident) return;
    incident.status = 'acknowledged';
    incident.acknowledgedAt = new Date().toISOString();
    incident.commander = commander;
    incident.timeline.push({
      timestamp: new Date().toISOString(),
      action: `Acknowledged by ${commander}`,
      actor: commander,
    });
  }

  resolve(id: string, actor: string): void {
    const incident = this.activeIncidents.get(id);
    if (!incident) return;
    incident.status = 'resolved';
    incident.resolvedAt = new Date().toISOString();
    incident.timeline.push({
      timestamp: new Date().toISOString(),
      action: 'Incident resolved',
      actor,
    });
  }

  getActive(): Incident[] {
    return Array.from(this.activeIncidents.values()).filter(i => i.status !== 'resolved');
  }
}

export const incidentDetector = new IncidentDetector();

// Default rules
incidentDetector.addRule({
  name: 'High Error Rate',
  condition: (m) => (m.error_rate ?? 0) > 0.05,
  severity: 'SEV1',
  affectedServices: ['api'],
});

incidentDetector.addRule({
  name: 'High Latency',
  condition: (m) => (m.latency_p99 ?? 0) > 3000,
  severity: 'SEV2',
  affectedServices: ['api'],
});

incidentDetector.addRule({
  name: 'Database Connection Pool Exhausted',
  condition: (m) => (m.db_pool_utilization ?? 0) > 0.95,
  severity: 'SEV1',
  affectedServices: ['database', 'api'],
});
TS
)"

    IR_INCIDENTS_DETECTED=$((IR_INCIDENTS_DETECTED + 1))
    _ir_ok "Incident detection system generated"
}

# =============================================================================
# Notify Team
# =============================================================================
_ir_notify_team() {
    local project_dir="${1:-.}"

    _ir_log "Generating team notification system..."

    local ir_dir="${project_dir}/src/lib/incidents"
    mkdir -p "$ir_dir" 2>/dev/null

    _ir_write_file "${ir_dir}/notifier.ts" "$(cat <<'TS'
import type { Incident, Severity } from './detector';

interface NotificationChannel {
  type: 'slack' | 'email' | 'pagerduty' | 'webhook';
  config: Record<string, string>;
  severities: Severity[];
}

interface EscalationPolicy {
  severity: Severity;
  acknowledgeTimeoutMinutes: number;
  escalateTo: string[];
}

export class IncidentNotifier {
  private channels: NotificationChannel[] = [];
  private escalationPolicies: EscalationPolicy[] = [];

  addChannel(channel: NotificationChannel): void {
    this.channels.push(channel);
  }

  addEscalationPolicy(policy: EscalationPolicy): void {
    this.escalationPolicies.push(policy);
  }

  async notify(incident: Incident): Promise<void> {
    const applicable = this.channels.filter(c => c.severities.includes(incident.severity));

    await Promise.allSettled(
      applicable.map(channel => this.sendToChannel(channel, incident))
    );
  }

  private async sendToChannel(channel: NotificationChannel, incident: Incident): Promise<void> {
    switch (channel.type) {
      case 'slack':
        await this.sendSlack(channel.config, incident);
        break;
      case 'email':
        await this.sendEmail(channel.config, incident);
        break;
      case 'pagerduty':
        await this.sendPagerDuty(channel.config, incident);
        break;
      case 'webhook':
        await this.sendWebhook(channel.config, incident);
        break;
    }
  }

  private async sendSlack(config: Record<string, string>, incident: Incident): Promise<void> {
    const color = { SEV1: '#FF0000', SEV2: '#FF8800', SEV3: '#FFCC00', SEV4: '#0088FF' }[incident.severity];
    await fetch(config.webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        attachments: [{
          color,
          title: `[${incident.severity}] ${incident.title}`,
          text: `Incident ${incident.id} detected\nAffected: ${incident.affectedServices.join(', ')}`,
          ts: Math.floor(Date.now() / 1000),
        }],
      }),
    });
  }

  private async sendEmail(config: Record<string, string>, incident: Incident): Promise<void> {
    console.log(`[IR] Email notification sent to ${config.to} for ${incident.id}`);
  }

  private async sendPagerDuty(config: Record<string, string>, incident: Incident): Promise<void> {
    console.log(`[IR] PagerDuty alert created for ${incident.id}`);
  }

  private async sendWebhook(config: Record<string, string>, incident: Incident): Promise<void> {
    await fetch(config.url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(incident),
    });
  }
}

export const incidentNotifier = new IncidentNotifier();
TS
)"

    _ir_ok "Team notification system generated"
}

# =============================================================================
# Generate Postmortem
# =============================================================================
_ir_generate_postmortem() {
    local project_dir="${1:-.}"

    _ir_log "Generating postmortem generator..."

    local ir_dir="${project_dir}/src/lib/incidents"
    mkdir -p "$ir_dir" 2>/dev/null

    _ir_write_file "${ir_dir}/postmortem.ts" "$(cat <<'TS'
import type { Incident } from './detector';

interface PostmortemReport {
  incidentId: string;
  title: string;
  severity: string;
  duration: string;
  summary: string;
  timeline: { time: string; event: string }[];
  rootCause: string;
  impact: string;
  mitigation: string;
  actionItems: { description: string; owner: string; dueDate: string; priority: string }[];
  lessonsLearned: string[];
}

export function generatePostmortem(incident: Incident): PostmortemReport {
  const detectedAt = new Date(incident.detectedAt);
  const resolvedAt = incident.resolvedAt ? new Date(incident.resolvedAt) : new Date();
  const durationMs = resolvedAt.getTime() - detectedAt.getTime();
  const durationMin = Math.round(durationMs / 60000);

  return {
    incidentId: incident.id,
    title: incident.title,
    severity: incident.severity,
    duration: `${durationMin} minutes`,
    summary: `${incident.severity} incident "${incident.title}" affecting ${incident.affectedServices.join(', ')}. Duration: ${durationMin} minutes.`,
    timeline: incident.timeline.map(t => ({ time: t.timestamp, event: `[${t.actor}] ${t.action}` })),
    rootCause: 'To be determined during postmortem review.',
    impact: `Services affected: ${incident.affectedServices.join(', ')}`,
    mitigation: 'To be documented during postmortem review.',
    actionItems: [
      { description: 'Add monitoring for root cause', owner: 'TBD', dueDate: 'TBD', priority: 'high' },
      { description: 'Update runbook', owner: 'TBD', dueDate: 'TBD', priority: 'medium' },
      { description: 'Add automated test for failure scenario', owner: 'TBD', dueDate: 'TBD', priority: 'medium' },
    ],
    lessonsLearned: [
      'Detection time can be improved with better alerting thresholds.',
      'Runbook should be updated to include this failure mode.',
    ],
  };
}

export function renderPostmortemMarkdown(report: PostmortemReport): string {
  let md = `# Postmortem: ${report.title}\n\n`;
  md += `**Incident ID:** ${report.incidentId}\n`;
  md += `**Severity:** ${report.severity}\n`;
  md += `**Duration:** ${report.duration}\n\n`;
  md += `## Summary\n${report.summary}\n\n`;
  md += `## Timeline\n`;
  for (const t of report.timeline) md += `- **${t.time}**: ${t.event}\n`;
  md += `\n## Root Cause\n${report.rootCause}\n\n`;
  md += `## Impact\n${report.impact}\n\n`;
  md += `## Mitigation\n${report.mitigation}\n\n`;
  md += `## Action Items\n`;
  for (const a of report.actionItems) md += `- [ ] [${a.priority}] ${a.description} (${a.owner}, due: ${a.dueDate})\n`;
  md += `\n## Lessons Learned\n`;
  for (const l of report.lessonsLearned) md += `- ${l}\n`;
  return md;
}
TS
)"

    _ir_ok "Postmortem generator created"
}

# =============================================================================
# Report / Score / Register
# =============================================================================
ir_report() {
    echo -e "\n  ${BOLD}=== Incident Response Engine v${IR_VERSION} ===${NC}"
    echo -e "  生成ファイル数   : ${IR_GENERATED}"
    echo -e "  エラー           : ${IR_ERRORS}"
    echo -e "  インシデント検出 : ${IR_INCIDENTS_DETECTED}"
    if [[ ${#IR_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${IR_FILES_CREATED[@]}"; do echo -e "    - ${f}"; done
    fi
}

ir_score() {
    if [[ ${IR_GENERATED} -ge 3 ]] && [[ ${IR_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${IR_GENERATED} -gt 0 ]] && [[ ${IR_ERRORS} -eq 0 ]]; then echo "90"
    elif [[ ${IR_GENERATED} -gt 0 ]]; then echo "70"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "incident-response" --version "357.0" \
        --description "インシデント検出×チーム通知×ポストモーテム生成" \
        --init "ir_init" --report "ir_report" --score "ir_score" \
        --enable-var "ENABLE_INCIDENT_RESPONSE" --cli-flags "--incident-response:--no-incident-response"
fi

# v2003.1: source時のexit codeを確実に0にする
true
