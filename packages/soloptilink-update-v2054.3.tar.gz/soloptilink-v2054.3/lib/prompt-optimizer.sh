#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v13.0 - Automatic Prompt Optimizer
# =============================================================================
# 過去のビルド結果とナレッジグラフデータを活用し、
# フェーズ×ドメインごとに最適なプロンプトテンプレートを自動選択・改善する。
#
# 機能:
#   1. po_init()                     - プロンプトオプティマイザーの初期化
#   2. po_analyze_prompt_effectiveness() - プロンプト実行結果の記録・分析
#   3. po_get_best_prompt_template() - 最高スコアのプロンプトテンプレート取得
#   4. po_inject_learned_context()   - 過去の学習でプロンプトを強化
#   5. po_suggest_improvements()     - 失敗レポートに基づく改善提案
#   6. po_report()                   - 最適化レポートの出力
#
# Dependencies: lib/knowledge-graph.sh (kg_* functions)
# Usage: source lib/prompt-optimizer.sh
# =============================================================================

# Load guard
[[ -n "${_PO_LOADED:-}" ]] && return 0
_PO_LOADED=1

# ---------------------------------------------------------------------------
# Color definitions (PO_ prefix to avoid collision)
# ---------------------------------------------------------------------------
PO_RED='\033[0;31m'
PO_GREEN='\033[0;32m'
PO_YELLOW='\033[0;33m'
PO_CYAN='\033[0;36m'
PO_PURPLE='\033[0;35m'
PO_BOLD='\033[1m'
PO_NC='\033[0m'

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
PO_BASE_DIR="${HOME}/.soloptilink/knowledge/prompts"
PO_TEMPLATES_DIR="${PO_BASE_DIR}/templates"
PO_HISTORY_DIR="${PO_BASE_DIR}/history"
PO_IMPROVEMENTS_DIR="${PO_BASE_DIR}/improvements"
PO_STATS_FILE="${PO_BASE_DIR}/prompt_stats.json"

# Scoring parameters
PO_EMA_ALPHA=0.3          # Exponential moving average weight for new observations
PO_MIN_SAMPLES=3          # Minimum samples before a template is considered reliable
PO_TOP_K=5                # Number of top templates to consider
PO_MAX_HISTORY_PER_PHASE=100  # Max history entries per phase

# Known phases in the SoloptiLink pipeline
PO_PHASES=("prompt_expand" "scaffold" "implement_backend" "implement_frontend" "implement_db" "validate" "heal" "security_scan" "browser_test" "deploy")

# ---------------------------------------------------------------------------
# Helper: _po_log(level, message)
# ---------------------------------------------------------------------------
_po_log() {
    local level="$1" message="$2" ts
    ts="$(date '+%Y-%m-%d %H:%M:%S')"
    case "$level" in
        INFO)     printf "${PO_CYAN}[PO %s]${PO_NC} %s\n"    "$ts" "$message" ;;
        OK)       printf "${PO_GREEN}[PO %s]${PO_NC} %s\n"    "$ts" "$message" ;;
        WARN)     printf "${PO_YELLOW}[PO %s]${PO_NC} %s\n"   "$ts" "$message" ;;
        ERROR)    printf "${PO_RED}[PO %s]${PO_NC} %s\n"      "$ts" "$message" ;;
        OPTIMIZE) printf "${PO_PURPLE}[PO %s]${PO_NC} %s\n"   "$ts" "$message" ;;
        *)        printf "[PO %s] %s\n" "$ts" "$message" ;;
    esac
}

# ---------------------------------------------------------------------------
# Helper: _po_hash(string) -> short hash for prompt identification
# ---------------------------------------------------------------------------
_po_hash() {
    local input="$1"
    if command -v md5sum &>/dev/null; then
        echo -n "$input" | md5sum | cut -c1-12
    elif command -v md5 &>/dev/null; then
        echo -n "$input" | md5 | cut -c1-12
    else
        # fallback: simple character-based hash
        printf '%s' "$input" | cksum | cut -d' ' -f1
    fi
}

# ---------------------------------------------------------------------------
# Helper: _po_timestamp()
# ---------------------------------------------------------------------------
_po_timestamp() {
    date -u '+%Y-%m-%dT%H:%M:%SZ'
}

# ---------------------------------------------------------------------------
# Helper: _po_json_read(file) -> stdout
# ---------------------------------------------------------------------------
_po_json_read() {
    local file="$1"
    [[ ! -f "$file" ]] && { echo '{}'; return; }
    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys
try:
    with open(sys.argv[1]) as f:
        print(json.dumps(json.load(f), ensure_ascii=False))
except Exception:
    print('{}')
" "$file"
    else
        cat "$file" 2>/dev/null || echo '{}'
    fi
}

# ---------------------------------------------------------------------------
# Helper: _po_json_write(file, json_string)
# ---------------------------------------------------------------------------
_po_json_write() {
    local file="$1" json_string="$2"
    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys
try:
    obj = json.loads(sys.argv[1])
    with open(sys.argv[2], 'w') as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
except Exception as e:
    with open(sys.argv[2], 'w') as f:
        f.write(sys.argv[1])
" "$json_string" "$file"
    else
        printf '%s\n' "$json_string" > "$file"
    fi
}

# =============================================================================
# po_init() - Initialize the prompt optimizer
# =============================================================================
po_init() {
    _po_log INFO "プロンプトオプティマイザーを初期化中..."

    mkdir -p "${PO_BASE_DIR}" "${PO_TEMPLATES_DIR}" "${PO_HISTORY_DIR}" "${PO_IMPROVEMENTS_DIR}" 2>/dev/null || true

    # Create per-phase directories
    for phase in "${PO_PHASES[@]}"; do
        mkdir -p "${PO_TEMPLATES_DIR}/${phase}" 2>/dev/null || true
        mkdir -p "${PO_HISTORY_DIR}/${phase}" 2>/dev/null || true
    done

    # Initialize stats file
    if [[ ! -f "${PO_STATS_FILE}" ]]; then
        _po_json_write "${PO_STATS_FILE}" '{
  "version": "17.0",
  "created_at": "'"$(_po_timestamp)"'",
  "phases": {},
  "total_analyses": 0,
  "total_improvements": 0,
  "overall_effectiveness": 0.0
}'
    fi

    _po_log OK "プロンプトオプティマイザー初期化完了: ${PO_BASE_DIR}"
    return 0
}

# =============================================================================
# po_analyze_prompt_effectiveness(phase, prompt_hash, success)
#   Records the outcome of a prompt execution for later analysis
#   - phase:       pipeline phase name (e.g. "scaffold", "implement_backend")
#   - prompt_hash: hash or ID identifying the prompt template used
#   - success:     "true" or "false"
# =============================================================================
po_analyze_prompt_effectiveness() {
    local phase="${1:?phase required}"
    local prompt_hash="${2:?prompt_hash required}"
    local success="${3:?success (true/false) required}"

    _po_log OPTIMIZE "プロンプト効果を分析中: phase=${phase}, hash=${prompt_hash}, success=${success}"

    local history_dir="${PO_HISTORY_DIR}/${phase}"
    mkdir -p "$history_dir" 2>/dev/null || true
    local history_file="${history_dir}/effectiveness.json"

    local ts
    ts="$(_po_timestamp)"

    local entry='{
  "prompt_hash": "'"${prompt_hash}"'",
  "success": '"${success}"',
  "timestamp": "'"${ts}"'"
}'

    # Append to history
    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os

history_file = sys.argv[1]
entry = json.loads(sys.argv[2])
max_entries = int(sys.argv[3])

history = []
if os.path.exists(history_file):
    try:
        with open(history_file) as f:
            history = json.load(f)
        if not isinstance(history, list):
            history = [history]
    except Exception:
        history = []

history.append(entry)

# Trim to max entries (keep most recent)
if len(history) > max_entries:
    history = history[-max_entries:]

with open(history_file, 'w') as f:
    json.dump(history, f, indent=2, ensure_ascii=False)
" "$history_file" "$entry" "${PO_MAX_HISTORY_PER_PHASE}"

        # Update template score
        _po_update_template_score "$phase" "$prompt_hash" "$success"
    else
        # bash fallback: append line to a simple log
        echo "${ts}|${prompt_hash}|${success}" >> "${history_dir}/effectiveness.log"
    fi

    # Update global stats
    _po_update_global_stats "$phase" "$success"

    _po_log OK "プロンプト効果分析完了: ${phase}/${prompt_hash}"
    return 0
}

# =============================================================================
# po_get_best_prompt_template(phase, domain)
#   Returns the highest-scoring prompt template for a given phase and domain
#   Output: JSON object with template content, score, and metadata
# =============================================================================
po_get_best_prompt_template() {
    local phase="${1:?phase required}"
    local domain="${2:-general}"

    _po_log INFO "最適プロンプトテンプレート検索: phase=${phase}, domain=${domain}"

    local templates_dir="${PO_TEMPLATES_DIR}/${phase}"
    if [[ ! -d "$templates_dir" ]]; then
        _po_log WARN "テンプレートディレクトリなし: ${templates_dir}"
        echo '{}'
        return 0
    fi

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os, glob

templates_dir = sys.argv[1]
domain = sys.argv[2]

all_templates = []
for tfile in glob.glob(os.path.join(templates_dir, '*.json')):
    try:
        with open(tfile) as f:
            tmpl = json.load(f)
        if isinstance(tmpl, list):
            all_templates.extend(tmpl)
        else:
            all_templates.append(tmpl)
    except Exception:
        continue

if not all_templates:
    print('{}')
    sys.exit(0)

# Prefer domain-specific templates
domain_specific = [t for t in all_templates if t.get('domain', 'general') == domain]
candidates = domain_specific if domain_specific else all_templates

# Sort by score descending, with usage_count as tiebreaker
candidates.sort(
    key=lambda t: (
        float(t.get('score', 0)),
        int(t.get('usage_count', 0))
    ),
    reverse=True
)

# Return the best one
best = candidates[0]
print(json.dumps(best, indent=2, ensure_ascii=False))
" "$templates_dir" "$domain"
    else
        # bash fallback: return first template found
        local first_file
        first_file="$(ls "${templates_dir}"/*.json 2>/dev/null | head -1)"
        if [[ -n "$first_file" ]]; then
            cat "$first_file"
        else
            echo '{}'
        fi
    fi
    return 0
}

# =============================================================================
# po_inject_learned_context(phase, domain, base_prompt)
#   Enriches a base prompt with context learned from past builds
#   Returns the enhanced prompt string on stdout
# =============================================================================
po_inject_learned_context() {
    local phase="${1:?phase required}"
    local domain="${2:-general}"
    local base_prompt="${3:?base_prompt required}"

    _po_log OPTIMIZE "学習コンテキスト注入: phase=${phase}, domain=${domain}"

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os, glob

phase = sys.argv[1]
domain = sys.argv[2]
base_prompt = sys.argv[3]

# Collect learned context from multiple sources
learned_sections = []

# 1. Best patterns from knowledge graph (if available)
kg_patterns_dir = os.path.expanduser('~/.soloptilink/knowledge/patterns')
domain_pattern_dir = os.path.join(kg_patterns_dir, domain)
if os.path.isdir(domain_pattern_dir):
    best_patterns = []
    for pfile in glob.glob(os.path.join(domain_pattern_dir, '*.json')):
        try:
            with open(pfile) as f:
                data = json.load(f)
            if isinstance(data, list):
                best_patterns.extend(data)
            else:
                best_patterns.append(data)
        except Exception:
            continue
    # Filter high-scoring patterns
    high_score = [p for p in best_patterns if float(p.get('success_rate', 0)) >= 0.7]
    if high_score:
        high_score.sort(key=lambda x: float(x.get('success_rate', 0)), reverse=True)
        pattern_hints = []
        for p in high_score[:3]:
            ptype = p.get('pattern_type', 'unknown')
            pdata = p.get('data', {})
            rate = p.get('success_rate', 0)
            pattern_hints.append(f'  - [{ptype}] (success: {rate:.0%}): {json.dumps(pdata, ensure_ascii=False)[:200]}')
        if pattern_hints:
            learned_sections.append('## Learned Patterns (from past successful builds)')
            learned_sections.extend(pattern_hints)

# 2. Past improvement suggestions for this phase
improvements_dir = os.path.expanduser(f'~/.soloptilink/knowledge/prompts/improvements')
imp_file = os.path.join(improvements_dir, f'{phase}_{domain}.json')
if os.path.exists(imp_file):
    try:
        with open(imp_file) as f:
            improvements = json.load(f)
        if isinstance(improvements, list) and improvements:
            latest = improvements[-1]
            suggestions = latest.get('suggestions', [])
            if suggestions:
                learned_sections.append('## Past Improvement Suggestions')
                for s in suggestions[:3]:
                    learned_sections.append(f'  - {s}')
    except Exception:
        pass

# 3. Common failure patterns to avoid
history_dir = os.path.expanduser(f'~/.soloptilink/knowledge/prompts/history/{phase}')
hist_file = os.path.join(history_dir, 'effectiveness.json')
if os.path.exists(hist_file):
    try:
        with open(hist_file) as f:
            history = json.load(f)
        if isinstance(history, list):
            failures = [h for h in history if not h.get('success', True)]
            if len(failures) > 3:
                learned_sections.append('## Warning: This phase has a history of failures')
                total = len(history)
                fail_count = len(failures)
                learned_sections.append(f'  - Failure rate: {fail_count}/{total} ({fail_count/total:.0%})')
                learned_sections.append(f'  - Pay extra attention to error handling and edge cases.')
    except Exception:
        pass

# Build enhanced prompt
if learned_sections:
    context_block = '\n'.join(learned_sections)
    enhanced = f'''{base_prompt}

---
### Auto-injected Context (SoloptiLink Prompt Optimizer v13.0)
{context_block}
---'''
    print(enhanced)
else:
    print(base_prompt)
" "$phase" "$domain" "$base_prompt"
    else
        # bash fallback: return base prompt unmodified
        _po_log WARN "python3未検出: コンテキスト注入スキップ"
        echo "$base_prompt"
    fi
    return 0
}

# =============================================================================
# po_suggest_improvements(phase, failure_report)
#   Analyzes a failure and suggests prompt improvements
#   - phase:          pipeline phase that failed
#   - failure_report: text or JSON describing what went wrong
#   Output: JSON array of improvement suggestions
# =============================================================================
po_suggest_improvements() {
    local phase="${1:?phase required}"
    local failure_report="${2:?failure_report required}"

    _po_log OPTIMIZE "改善提案を生成中: phase=${phase}"

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os, re
from datetime import datetime

phase = sys.argv[1]
failure_report = sys.argv[2]

suggestions = []
report_lower = failure_report.lower()

# ---- Rule-based improvement suggestions ----

# Syntax / compilation errors
if any(kw in report_lower for kw in ['syntax error', 'syntaxerror', 'unexpected token', 'parse error']):
    suggestions.append('Add explicit instruction: \"Ensure all generated code is syntactically valid. Double-check brackets, parentheses, and semicolons.\"')
    suggestions.append('Include a step: \"After generating each file, mentally trace through the code to verify syntax.\"')

# Import / module errors
if any(kw in report_lower for kw in ['import error', 'module not found', 'cannot find module', 'no module named']):
    suggestions.append('Add instruction: \"List all required dependencies at the start. Verify every import statement references an installed package or local module.\"')
    suggestions.append('Include: \"Generate a complete package.json/requirements.txt with all needed dependencies.\"')

# Type errors
if any(kw in report_lower for kw in ['type error', 'typeerror', 'type mismatch', 'undefined is not']):
    suggestions.append('Add instruction: \"Use TypeScript strict mode. Define interfaces for all data structures. Avoid \\'any\\' type.\"')
    suggestions.append('Include: \"Add runtime type checks at API boundaries and data parsing points.\"')

# Test failures
if any(kw in report_lower for kw in ['test fail', 'assertion', 'expect(', 'assert']):
    suggestions.append('Add instruction: \"Write tests that match the actual implementation behavior. Include edge cases.\"')
    suggestions.append('Include: \"Generate test fixtures/mock data that covers normal, boundary, and error cases.\"')

# Security issues
if any(kw in report_lower for kw in ['xss', 'sql injection', 'csrf', 'vulnerability', 'secret', 'leak']):
    suggestions.append('Add instruction: \"Follow OWASP Top 10 guidelines. Sanitize all user inputs. Use parameterized queries.\"')
    suggestions.append('Include: \"Add security headers (CSP, X-Frame-Options, HSTS). Never hardcode secrets.\"')

# Timeout / performance
if any(kw in report_lower for kw in ['timeout', 'timed out', 'slow', 'performance', 'memory']):
    suggestions.append('Add instruction: \"Optimize database queries with proper indexing. Use pagination for list endpoints.\"')
    suggestions.append('Include: \"Add connection pooling, caching strategy, and lazy loading where appropriate.\"')

# Build / compilation failures
if any(kw in report_lower for kw in ['build fail', 'compilation', 'webpack', 'vite', 'esbuild']):
    suggestions.append('Add instruction: \"Ensure build configuration matches the project structure. Verify path aliases and module resolution.\"')
    suggestions.append('Include: \"Test the build process locally before finalizing. Check for circular dependencies.\"')

# File structure issues
if any(kw in report_lower for kw in ['file not found', 'enoent', 'no such file', 'path']):
    suggestions.append('Add instruction: \"Create all referenced files. Verify file paths match the project structure diagram.\"')
    suggestions.append('Include: \"Generate a file manifest and cross-reference all imports against it.\"')

# Generic fallback
if not suggestions:
    suggestions.append(f'Review the {phase} phase prompt for ambiguity. Be more specific about expected output format.')
    suggestions.append('Add explicit success criteria that the generated code must meet.')
    suggestions.append('Include example input/output pairs to guide the generation.')

# Save suggestions for future reference
improvements_dir = os.path.expanduser('~/.soloptilink/knowledge/prompts/improvements')
os.makedirs(improvements_dir, exist_ok=True)

# Detect domain from failure report (simple heuristic)
domain = 'general'
for d in ['crm', 'ecommerce', 'chat', 'finance', 'task', 'blog', 'api', 'dashboard', 'auth', 'saas']:
    if d in report_lower:
        domain = d
        break

imp_file = os.path.join(improvements_dir, f'{phase}_{domain}.json')
history = []
if os.path.exists(imp_file):
    try:
        with open(imp_file) as f:
            history = json.load(f)
        if not isinstance(history, list):
            history = [history]
    except Exception:
        history = []

history.append({
    'timestamp': datetime.utcnow().isoformat() + 'Z',
    'phase': phase,
    'failure_summary': failure_report[:500],
    'suggestions': suggestions
})

# Keep last 50 entries
if len(history) > 50:
    history = history[-50:]

with open(imp_file, 'w') as f:
    json.dump(history, f, indent=2, ensure_ascii=False)

# Output
result = {
    'phase': phase,
    'suggestion_count': len(suggestions),
    'suggestions': suggestions,
    'generated_at': datetime.utcnow().isoformat() + 'Z'
}
print(json.dumps(result, indent=2, ensure_ascii=False))
" "$phase" "$failure_report"
    else
        # bash fallback: provide basic suggestions
        _po_log WARN "python3未検出: 基本的な改善提案のみ提供"
        echo '{'
        echo '  "phase": "'"${phase}"'",'
        echo '  "suggestions": ['
        echo '    "Review and add more specific instructions to the prompt",'
        echo '    "Include explicit error handling requirements",'
        echo '    "Add example outputs to guide code generation"'
        echo '  ]'
        echo '}'
    fi
    return 0
}

# =============================================================================
# po_report() - Output a formatted prompt optimization report
# =============================================================================
po_report() {
    _po_log INFO "プロンプト最適化レポート生成中..."

    echo ""
    echo -e "${PO_BOLD}================================================${PO_NC}"
    echo -e "${PO_BOLD}  SoloptiLink Prompt Optimizer Report v13.0${PO_NC}"
    echo -e "${PO_BOLD}================================================${PO_NC}"
    echo ""

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os, glob
from datetime import datetime

base_dir = sys.argv[1]
stats_file = sys.argv[2]
templates_dir = sys.argv[3]
history_dir = sys.argv[4]
improvements_dir = sys.argv[5]

# Load stats
stats = {}
if os.path.exists(stats_file):
    try:
        with open(stats_file) as f:
            stats = json.load(f)
    except Exception:
        stats = {}

print(f'  Generated: {datetime.utcnow().strftime(\"%Y-%m-%d %H:%M:%S UTC\")}')
print(f'  Storage:   {base_dir}')
print()

# Overall stats
print(f'  Total Analyses:     {stats.get(\"total_analyses\", 0)}')
print(f'  Total Improvements: {stats.get(\"total_improvements\", 0)}')
overall_eff = stats.get('overall_effectiveness', 0)
print(f'  Overall Effectiveness: {overall_eff:.1%}' if isinstance(overall_eff, (int, float)) else f'  Overall Effectiveness: N/A')
print()

# Per-phase breakdown
phases_stats = stats.get('phases', {})
if phases_stats:
    print('  Phase Breakdown:')
    print('  ' + '-' * 65)
    print(f'  {\"Phase\":<22} {\"Analyses\":<10} {\"Success\":<10} {\"Rate\":<10} {\"Templates\":<10}')
    print('  ' + '-' * 65)

    for phase_name, pdata in sorted(phases_stats.items()):
        analyses = pdata.get('total', 0)
        successes = pdata.get('successes', 0)
        rate = f'{successes/analyses:.0%}' if analyses > 0 else 'N/A'

        # Count templates for this phase
        phase_tmpl_dir = os.path.join(templates_dir, phase_name)
        tmpl_count = 0
        if os.path.isdir(phase_tmpl_dir):
            for tfile in glob.glob(os.path.join(phase_tmpl_dir, '*.json')):
                try:
                    with open(tfile) as f:
                        data = json.load(f)
                    tmpl_count += len(data) if isinstance(data, list) else 1
                except Exception:
                    continue

        print(f'  {phase_name:<22} {analyses:<10} {successes:<10} {rate:<10} {tmpl_count:<10}')

    print('  ' + '-' * 65)
else:
    print('  (No phase data yet)')

print()

# Recent improvements
imp_files = glob.glob(os.path.join(improvements_dir, '*.json'))
if imp_files:
    print('  Recent Improvement Suggestions:')
    print('  ' + '-' * 65)
    recent = []
    for ifile in imp_files:
        try:
            with open(ifile) as f:
                data = json.load(f)
            if isinstance(data, list) and data:
                latest = data[-1]
                latest['_file'] = os.path.basename(ifile)
                recent.append(latest)
        except Exception:
            continue

    recent.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
    for imp in recent[:5]:
        phase = imp.get('phase', '?')
        ts = imp.get('timestamp', '?')[:10]
        n_sugg = len(imp.get('suggestions', []))
        fname = imp.get('_file', '')
        print(f'  [{ts}] {phase} ({fname}): {n_sugg} suggestions')
        for s in imp.get('suggestions', [])[:2]:
            print(f'    -> {s[:80]}')

    print('  ' + '-' * 65)
else:
    print('  (No improvement suggestions yet)')

print()
" "${PO_BASE_DIR}" "${PO_STATS_FILE}" "${PO_TEMPLATES_DIR}" "${PO_HISTORY_DIR}" "${PO_IMPROVEMENTS_DIR}"
    else
        # bash fallback
        echo "  Stats file: ${PO_STATS_FILE}"
        if [[ -f "${PO_STATS_FILE}" ]]; then
            cat "${PO_STATS_FILE}"
        else
            echo "  (No data yet)"
        fi
        echo ""
        echo "  (Install python3 for detailed report)"
    fi

    echo -e "${PO_BOLD}================================================${PO_NC}"
    echo ""
    return 0
}

# =============================================================================
# Internal helpers
# =============================================================================

# ---------------------------------------------------------------------------
# _po_update_template_score(phase, prompt_hash, success)
#   Updates the score for a specific prompt template
# ---------------------------------------------------------------------------
_po_update_template_score() {
    local phase="$1" prompt_hash="$2" success="$3"

    local templates_dir="${PO_TEMPLATES_DIR}/${phase}"
    mkdir -p "$templates_dir" 2>/dev/null || true
    local template_file="${templates_dir}/${prompt_hash}.json"

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os
from datetime import datetime

template_file = sys.argv[1]
prompt_hash = sys.argv[2]
success = sys.argv[3] == 'true'
ema_alpha = float(sys.argv[4])

template = {}
if os.path.exists(template_file):
    try:
        with open(template_file) as f:
            template = json.load(f)
    except Exception:
        template = {}

if not template:
    template = {
        'prompt_hash': prompt_hash,
        'domain': 'general',
        'score': 0.5,
        'usage_count': 0,
        'success_count': 0,
        'failure_count': 0,
        'created_at': datetime.utcnow().isoformat() + 'Z'
    }

# Update counts
template['usage_count'] = template.get('usage_count', 0) + 1
if success:
    template['success_count'] = template.get('success_count', 0) + 1
else:
    template['failure_count'] = template.get('failure_count', 0) + 1

# Update score with exponential moving average
old_score = float(template.get('score', 0.5))
observation = 1.0 if success else 0.0
new_score = old_score * (1 - ema_alpha) + observation * ema_alpha
template['score'] = round(new_score, 4)
template['updated_at'] = datetime.utcnow().isoformat() + 'Z'

with open(template_file, 'w') as f:
    json.dump(template, f, indent=2, ensure_ascii=False)
" "$template_file" "$prompt_hash" "$success" "${PO_EMA_ALPHA}"
    fi
}

# ---------------------------------------------------------------------------
# _po_update_global_stats(phase, success)
# ---------------------------------------------------------------------------
_po_update_global_stats() {
    local phase="$1" success="$2"

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os
from datetime import datetime

stats_file = sys.argv[1]
phase = sys.argv[2]
success = sys.argv[3] == 'true'

stats = {}
if os.path.exists(stats_file):
    try:
        with open(stats_file) as f:
            stats = json.load(f)
    except Exception:
        stats = {}

# Update phase stats
if 'phases' not in stats:
    stats['phases'] = {}

if phase not in stats['phases']:
    stats['phases'][phase] = {
        'total': 0,
        'successes': 0,
        'failures': 0
    }

ps = stats['phases'][phase]
ps['total'] = ps.get('total', 0) + 1
if success:
    ps['successes'] = ps.get('successes', 0) + 1
else:
    ps['failures'] = ps.get('failures', 0) + 1

# Update global counters
stats['total_analyses'] = stats.get('total_analyses', 0) + 1
stats['last_updated'] = datetime.utcnow().isoformat() + 'Z'

# Recalculate overall effectiveness
total_all = sum(p.get('total', 0) for p in stats['phases'].values())
success_all = sum(p.get('successes', 0) for p in stats['phases'].values())
stats['overall_effectiveness'] = round(success_all / total_all, 4) if total_all > 0 else 0.0

with open(stats_file, 'w') as f:
    json.dump(stats, f, indent=2, ensure_ascii=False)
" "${PO_STATS_FILE}" "$phase" "$success"
    fi
}
