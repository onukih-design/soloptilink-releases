#!/usr/bin/env bash
# ============================================================
# SoloptiLink Chain v24.0 - Continuous Self-Healing System
# ============================================================
# v8.0: Continuous healing loop, prioritized errors, cascade detection
# v11.0: Diff-based fixes, multi-strategy healing, healing analytics,
#         parallel healing, smart rollback
# v24.0: エラーの平易な日本語翻訳 + わかりやすい修復レポート
#         ITリテラシーが低い人でもエラー状況を理解できるように
# ============================================================

[[ -n "${_HEALER_LOADED:-}" ]] && return 0
_HEALER_LOADED=1

# カラー定義
readonly HEAL_GREEN='\033[0;32m'  HEAL_YELLOW='\033[0;33m' HEAL_RED='\033[0;31m'
readonly HEAL_PURPLE='\033[0;35m' HEAL_CYAN='\033[0;36m'   HEAL_BOLD='\033[1m'
readonly HEAL_NC='\033[0m'

# ヒーラー設定
MAX_HEAL_ITERATIONS="${MAX_HEAL_ITERATIONS:-50}"
MAX_FIX_ATTEMPTS_PER_ERROR=3
CLAUDE_CALL_TIMEOUT=120
HEAL_LOG_DIR="" HEAL_SESSION_ID="" HEAL_PROJECT_DIR=""
HEAL_ITERATION=0 HEAL_START_TIME=0
HEAL_TOTAL_FIXES=0 HEAL_SUCCESSFUL_FIXES=0 HEAL_FAILED_FIXES=0 HEAL_SKIPPED_ERRORS=0

# v11.0: 並列ヒーリング設定
HEAL_PARALLEL_MAX="${HEAL_PARALLEL_MAX:-4}"
HEAL_PARALLEL_ENABLED="${HEAL_PARALLEL_ENABLED:-true}"

# 修正履歴（同じ修正の繰り返しを防止）
declare -A HEAL_FIX_HISTORY=()
declare -A HEAL_BACKUP_MAP=()

# v11.0: ヒーリングアナリティクス
declare -A HEAL_ANALYTICS_BY_TYPE=()      # error_type -> "success:fail" counts
declare -A HEAL_ANALYTICS_BY_STRATEGY=()  # strategy -> "success:fail" counts
declare -A HEAL_ANALYTICS_DURATIONS=()    # error_type -> cumulative seconds

# ============================================================
# v24.0: エラー平易化 - 技術用語をわかりやすい日本語に翻訳
# ============================================================
# 技術的なエラーメッセージを、ITリテラシーが低い人でも
# 「何が起きているか」「何が問題か」を理解できる言葉に変換する。

_healer_explain_error() {
    local error_msg="$1"
    local error_sev="${2:-other}"
    local low
    low=$(echo "$error_msg" | tr '[:upper:]' '[:lower:]')

    case "$error_sev" in
        syntax)
            echo "📝 コードの書き方にミスがあります（文法エラー）"
            echo "   → カッコの閉じ忘れや、記号の間違いなどです"
            ;;
        import)
            echo "📦 必要な部品（ライブラリ）が見つかりません"
            echo "   → 使おうとした機能がインストールされていない状態です"
            ;;
        type)
            echo "🔢 データの種類が合っていません（型エラー）"
            echo "   → 数字を期待する場所に文字が入っている、などの問題です"
            ;;
        runtime)
            echo "💥 実行中にエラーが発生しました"
            echo "   → プログラムが動いている最中に予期しない問題が起きました"
            ;;
        ui)
            echo "🎨 画面表示に問題があります"
            echo "   → ボタンやレイアウトの見た目に関する問題です"
            ;;
        edge)
            echo "⚠️ 改善できる点があります"
            echo "   → 動作はしますが、より良くできる部分があります"
            ;;
        *)
            # メッセージ内容から推測
            if [[ "$low" =~ (cannot.find|not.found|no.such|missing) ]]; then
                echo "🔍 必要なファイルや設定が見つかりません"
                echo "   → ファイルの配置場所や名前を確認する必要があります"
            elif [[ "$low" =~ (permission|denied|access) ]]; then
                echo "🔒 アクセス権限がありません"
                echo "   → ファイルの読み書き権限を確認する必要があります"
            elif [[ "$low" =~ (timeout|timed.out) ]]; then
                echo "⏰ 処理に時間がかかりすぎました"
                echo "   → 通信先のサーバーが応答しない可能性があります"
            elif [[ "$low" =~ (connection|network|fetch) ]]; then
                echo "🌐 接続に失敗しました"
                echo "   → インターネットやデータベースとの通信に問題があります"
            else
                echo "❓ 技術的な問題が発生しました"
                echo "   → 自動修復を試みます"
            fi
            ;;
    esac
}

# v24.0: 修復状況をわかりやすく表示
_healer_explain_status() {
    local error_count="$1"
    local iteration="$2"
    local max_iter="$3"

    echo ""
    echo -e "${HEAL_BOLD}${HEAL_CYAN}┌─────────────────────────────────────────┐${HEAL_NC}"
    echo -e "${HEAL_BOLD}${HEAL_CYAN}│  🔧 自動修復の状況                      │${HEAL_NC}"
    echo -e "${HEAL_BOLD}${HEAL_CYAN}├─────────────────────────────────────────┤${HEAL_NC}"

    if [[ "$error_count" -eq 0 ]]; then
        echo -e "${HEAL_BOLD}${HEAL_GREEN}│  ✅ すべての問題が解決しました！       │${HEAL_NC}"
    elif [[ "$error_count" -le 3 ]]; then
        echo -e "│  あと ${HEAL_BOLD}${error_count}個${HEAL_NC} の問題が残っています       │"
        echo -e "│  もう少しで完了です！                   │"
    elif [[ "$error_count" -le 10 ]]; then
        echo -e "│  ${HEAL_BOLD}${error_count}個${HEAL_NC} の問題を修復中...               │"
        echo -e "│  順番に直しています                     │"
    else
        echo -e "│  ${HEAL_BOLD}${error_count}個${HEAL_NC} の問題があります                │"
        echo -e "│  まとめて修復を進めています             │"
    fi

    echo -e "│  進捗: ${iteration}回目 / 最大${max_iter}回        │"
    echo -e "${HEAL_BOLD}${HEAL_CYAN}└─────────────────────────────────────────┘${HEAL_NC}"
    echo ""
}

# v24.0: 修復完了時のわかりやすいサマリー
_healer_friendly_report() {
    local total="$1" success="$2" failed="$3" skipped="$4" elapsed="$5"
    local minutes=$((elapsed / 60))
    local seconds=$((elapsed % 60))

    echo ""
    echo -e "${HEAL_BOLD}${HEAL_PURPLE}┌─────────────────────────────────────────┐${HEAL_NC}"
    echo -e "${HEAL_BOLD}${HEAL_PURPLE}│  📊 修復結果レポート                    │${HEAL_NC}"
    echo -e "${HEAL_BOLD}${HEAL_PURPLE}├─────────────────────────────────────────┤${HEAL_NC}"

    if [[ "$failed" -eq 0 && "$skipped" -eq 0 ]]; then
        echo -e "│  ${HEAL_GREEN}🎉 すべての問題が解決しました！${HEAL_NC}       │"
    elif [[ "$success" -gt 0 && "$failed" -gt 0 ]]; then
        echo -e "│  ${HEAL_YELLOW}⚠️ 一部の問題は手動対応が必要です${HEAL_NC}   │"
    else
        echo -e "│  ${HEAL_RED}❌ 自動修復できない問題があります${HEAL_NC}     │"
    fi

    echo -e "│                                         │"
    echo -e "│  修復できた問題:  ${HEAL_GREEN}${success}件${HEAL_NC}                  │"

    if [[ "$failed" -gt 0 ]]; then
        echo -e "│  修復できなかった: ${HEAL_RED}${failed}件${HEAL_NC}                  │"
    fi
    if [[ "$skipped" -gt 0 ]]; then
        echo -e "│  スキップした:    ${HEAL_YELLOW}${skipped}件${HEAL_NC}                  │"
    fi

    echo -e "│  かかった時間:    ${minutes}分${seconds}秒             │"
    echo -e "${HEAL_BOLD}${HEAL_PURPLE}└─────────────────────────────────────────┘${HEAL_NC}"
}

# ============================================================
# ヘルパー関数群
# ============================================================
_healer_log() {
    local level="$1" message="$2"
    local color="${HEAL_NC}"
    case "$level" in
        INFO|SUCCESS) color="${HEAL_GREEN}" ;; WARN) color="${HEAL_YELLOW}" ;;
        ERROR|FAIL)   color="${HEAL_RED}"   ;; ESCALATE) color="${HEAL_PURPLE}" ;;
    esac
    echo -e "  ${color}[HEAL:${level}]${HEAL_NC} ${message}"
    [[ -n "$HEAL_LOG_DIR" ]] && \
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${level}] ${message}" >> "${HEAL_LOG_DIR}/healer.log" 2>/dev/null || true
}

_healer_backup_file() {
    local filepath="$1"
    [[ ! -f "$filepath" ]] && return 1
    local backup_path="${HEAL_LOG_DIR}/backups/$(basename "$filepath").$(date +%s).bak"
    cp "$filepath" "$backup_path" 2>/dev/null || { _healer_log "ERROR" "バックアップ失敗: ${filepath}"; return 1; }
    HEAL_BACKUP_MAP[$filepath]="$backup_path"
    return 0
}

_healer_revert_file() {
    local filepath="$1" backup_path="${HEAL_BACKUP_MAP[$1]:-}"
    if [[ -n "$backup_path" && -f "$backup_path" ]]; then
        cp "$backup_path" "$filepath" 2>/dev/null && return 0
    fi
    _healer_log "WARN" "リバート失敗: ${filepath}"
    return 1
}

_healer_error_hash() {
    local input="${1}:${2:0:60}"
    if command -v md5sum &>/dev/null; then
        echo "$input" | md5sum | cut -d' ' -f1
    elif command -v md5 &>/dev/null; then
        echo "$input" | md5 -q
    else
        echo "$input"
    fi
}

_healer_count_errors() {
    local report="$1"
    [[ -z "$report" ]] && { echo "0"; return; }
    [[ -f "$report" ]] && report=$(cat "$report")
    local count
    count=$(echo "$report" | grep -icE '(error|fail|critical)' 2>/dev/null | head -1 || echo "0")
    echo "${count:-0}"
}

# Claude CLI呼び出し（リトライ付き、タイムアウト120秒）
_healer_call_claude() {
    local prompt="$1" retry=0
    while [[ "$retry" -lt 3 ]]; do
        retry=$((retry + 1))
        local result
        # v23.0: macOS対応 - timeout コマンドの有無を動的判定
        local _heal_claude_cmd
        if command -v timeout &>/dev/null; then
            _heal_claude_cmd="timeout ${CLAUDE_CALL_TIMEOUT} claude"
        else
            _heal_claude_cmd="claude"
        fi
        result=$(${_heal_claude_cmd} -p --dangerously-skip-permissions \
            --output-format text "$prompt" 2>/dev/null || echo "")
        [[ -n "$result" ]] && { echo "$result"; return 0; }
        _healer_log "WARN" "Claude CLI応答なし (試行 ${retry}/3)"
        sleep $((retry * 2))
    done
    _healer_log "ERROR" "Claude CLI: 全リトライ失敗"
    return 1
}

# ============================================================
# 初期化
# ============================================================
healer_init() {
    local session_id="$1" project_dir="$2"
    HEAL_SESSION_ID="$session_id"
    HEAL_PROJECT_DIR="$project_dir"
    HEAL_LOG_DIR="docs/chain-logs/heal_${session_id}"
    HEAL_ITERATION=0 HEAL_START_TIME=$(date +%s)
    HEAL_TOTAL_FIXES=0 HEAL_SUCCESSFUL_FIXES=0 HEAL_FAILED_FIXES=0 HEAL_SKIPPED_ERRORS=0
    HEAL_FIX_HISTORY=() HEAL_BACKUP_MAP=()
    HEAL_ANALYTICS_BY_TYPE=() HEAL_ANALYTICS_BY_STRATEGY=() HEAL_ANALYTICS_DURATIONS=()
    mkdir -p "${HEAL_LOG_DIR}/backups" "${HEAL_LOG_DIR}/fixes" "${HEAL_LOG_DIR}/diffs" "${HEAL_LOG_DIR}/analytics" 2>/dev/null || true
    _healer_log "INFO" "ヒーラー初期化: ${session_id} | max=${MAX_HEAL_ITERATIONS}"
    echo -e "${HEAL_BOLD}${HEAL_PURPLE}[HEALER] 自動修復システム初期化完了 (v11.0)${HEAL_NC}"
    echo -e "  セッション: ${HEAL_CYAN}${session_id}${HEAL_NC} | 最大: ${MAX_HEAL_ITERATIONS}回 | 並列: ${HEAL_PARALLEL_MAX}スロット"
}

# ============================================================
# v11.0: ヒーリングアナリティクス
# ============================================================

# アナリティクス記録
_healer_analytics_record() {
    local error_type="$1" strategy="$2" success="$3" duration="${4:-0}"

    # エラータイプ別統計
    local current_type="${HEAL_ANALYTICS_BY_TYPE[$error_type]:-0:0}"
    local type_ok type_ng
    type_ok=$(echo "$current_type" | cut -d':' -f1)
    type_ng=$(echo "$current_type" | cut -d':' -f2)
    if [[ "$success" == "true" ]]; then
        type_ok=$((type_ok + 1))
    else
        type_ng=$((type_ng + 1))
    fi
    HEAL_ANALYTICS_BY_TYPE[$error_type]="${type_ok}:${type_ng}"

    # 戦略別統計
    local current_strat="${HEAL_ANALYTICS_BY_STRATEGY[$strategy]:-0:0}"
    local strat_ok strat_ng
    strat_ok=$(echo "$current_strat" | cut -d':' -f1)
    strat_ng=$(echo "$current_strat" | cut -d':' -f2)
    if [[ "$success" == "true" ]]; then
        strat_ok=$((strat_ok + 1))
    else
        strat_ng=$((strat_ng + 1))
    fi
    HEAL_ANALYTICS_BY_STRATEGY[$strategy]="${strat_ok}:${strat_ng}"

    # 所要時間
    local cumulative="${HEAL_ANALYTICS_DURATIONS[$error_type]:-0}"
    HEAL_ANALYTICS_DURATIONS[$error_type]=$((cumulative + duration))
}

# アナリティクスサマリー表示
healer_analytics_summary() {
    echo -e "\n${HEAL_BOLD}${HEAL_CYAN}[ANALYTICS] ヒーリング分析レポート${HEAL_NC}"

    # エラータイプ別
    echo -e "\n  ${HEAL_BOLD}エラータイプ別 修復成功率:${HEAL_NC}"
    echo -e "  %-16s  %6s  %6s  %8s  %10s" "TYPE" "OK" "NG" "RATE" "AVG_SEC"
    for etype in "${!HEAL_ANALYTICS_BY_TYPE[@]}"; do
        local counts="${HEAL_ANALYTICS_BY_TYPE[$etype]}"
        local ok ng total rate avg_dur
        ok=$(echo "$counts" | cut -d':' -f1)
        ng=$(echo "$counts" | cut -d':' -f2)
        total=$((ok + ng))
        rate=0
        [[ "$total" -gt 0 ]] && rate=$(( (ok * 100) / total ))
        local dur="${HEAL_ANALYTICS_DURATIONS[$etype]:-0}"
        avg_dur=0
        [[ "$total" -gt 0 ]] && avg_dur=$((dur / total))
        local color="${HEAL_GREEN}"
        [[ "$rate" -lt 50 ]] && color="${HEAL_RED}"
        [[ "$rate" -ge 50 && "$rate" -lt 80 ]] && color="${HEAL_YELLOW}"
        echo -e "  ${color}%-16s  %6d  %6d  %7d%%  %9ds${HEAL_NC}" "$etype" "$ok" "$ng" "$rate" "$avg_dur"
    done

    # 戦略別
    echo -e "\n  ${HEAL_BOLD}戦略別 修復成功率:${HEAL_NC}"
    echo -e "  %-20s  %6s  %6s  %8s" "STRATEGY" "OK" "NG" "RATE"
    for strat in "${!HEAL_ANALYTICS_BY_STRATEGY[@]}"; do
        local counts="${HEAL_ANALYTICS_BY_STRATEGY[$strat]}"
        local ok ng total rate
        ok=$(echo "$counts" | cut -d':' -f1)
        ng=$(echo "$counts" | cut -d':' -f2)
        total=$((ok + ng))
        rate=0
        [[ "$total" -gt 0 ]] && rate=$(( (ok * 100) / total ))
        local color="${HEAL_GREEN}"
        [[ "$rate" -lt 50 ]] && color="${HEAL_RED}"
        [[ "$rate" -ge 50 && "$rate" -lt 80 ]] && color="${HEAL_YELLOW}"
        echo -e "  ${color}%-20s  %6d  %6d  %7d%%${HEAL_NC}" "$strat" "$ok" "$ng" "$rate"
    done

    # JSON保存
    _healer_save_analytics
}

# アナリティクスJSON保存
_healer_save_analytics() {
    [[ -z "$HEAL_LOG_DIR" ]] && return
    local analytics_file="${HEAL_LOG_DIR}/analytics/healing_analytics.json"
    {
        echo "{"
        echo '  "timestamp": "'"$(date -u +%Y-%m-%dT%H:%M:%SZ)"'",'
        echo '  "session_id": "'"${HEAL_SESSION_ID}"'",'
        echo '  "by_error_type": {'
        local first=true
        for etype in "${!HEAL_ANALYTICS_BY_TYPE[@]}"; do
            local counts="${HEAL_ANALYTICS_BY_TYPE[$etype]}"
            local ok ng
            ok=$(echo "$counts" | cut -d':' -f1)
            ng=$(echo "$counts" | cut -d':' -f2)
            local dur="${HEAL_ANALYTICS_DURATIONS[$etype]:-0}"
            [[ "$first" == "true" ]] && first=false || echo ","
            printf '    "%s": {"success": %d, "fail": %d, "duration_sec": %d}' "$etype" "$ok" "$ng" "$dur"
        done
        echo ""
        echo "  },"
        echo '  "by_strategy": {'
        first=true
        for strat in "${!HEAL_ANALYTICS_BY_STRATEGY[@]}"; do
            local counts="${HEAL_ANALYTICS_BY_STRATEGY[$strat]}"
            local ok ng
            ok=$(echo "$counts" | cut -d':' -f1)
            ng=$(echo "$counts" | cut -d':' -f2)
            [[ "$first" == "true" ]] && first=false || echo ","
            printf '    "%s": {"success": %d, "fail": %d}' "$strat" "$ok" "$ng"
        done
        echo ""
        echo "  }"
        echo "}"
    } > "$analytics_file" 2>/dev/null
    _healer_log "INFO" "アナリティクス保存: ${analytics_file}"
}

# 最も修復困難なエラータイプを取得
healer_analytics_hardest() {
    local worst_type="" worst_rate=101
    for etype in "${!HEAL_ANALYTICS_BY_TYPE[@]}"; do
        local counts="${HEAL_ANALYTICS_BY_TYPE[$etype]}"
        local ok ng total rate
        ok=$(echo "$counts" | cut -d':' -f1)
        ng=$(echo "$counts" | cut -d':' -f2)
        total=$((ok + ng))
        [[ "$total" -lt 2 ]] && continue
        rate=0
        [[ "$total" -gt 0 ]] && rate=$(( (ok * 100) / total ))
        if [[ "$rate" -lt "$worst_rate" ]]; then
            worst_rate=$rate
            worst_type=$etype
        fi
    done
    if [[ -n "$worst_type" ]]; then
        echo -e "  ${HEAL_RED}最も修復困難: ${worst_type} (成功率: ${worst_rate}%)${HEAL_NC}"
        echo "$worst_type"
    fi
}

# ============================================================
# v11.0: Diff-Based Fix Generation
# ============================================================

# 最小限のdiffを生成してファイルに適用
_healer_generate_diff() {
    local error_file="$1" error_msg="$2" error_severity="${3:-unknown}"
    [[ ! -f "$error_file" ]] && return 1

    local file_content
    file_content=$(cat "$error_file" 2>/dev/null || echo "")
    [[ -z "$file_content" ]] && return 1

    local prompt="以下のファイルにエラーがあります。最小限のunified diffパッチのみを生成してください。
ファイル全体を書き直さないでください。変更が必要な行だけのdiffを出力してください。

エラー: ${error_msg} (重要度: ${error_severity})
ファイル: ${error_file}

--- 現在のコード ---
${file_content}

--- 出力フォーマット ---
--- a/${error_file##*/}
+++ b/${error_file##*/}
@@ ... @@
(unified diff形式のみ、説明不要)"

    local diff_output
    diff_output=$(_healer_call_claude "$prompt")
    [[ -z "$diff_output" ]] && return 1

    # diffらしい内容か検証
    if echo "$diff_output" | grep -qE '^[-+@]{1,3}'; then
        echo "$diff_output"
        return 0
    fi
    return 1
}

# diffパッチを適用
_healer_apply_diff() {
    local error_file="$1" diff_content="$2"
    [[ ! -f "$error_file" || -z "$diff_content" ]] && return 1

    local diff_file="${HEAL_LOG_DIR}/diffs/patch_$(date +%s)_${RANDOM}.diff"
    echo "$diff_content" > "$diff_file" 2>/dev/null

    # patchコマンドで適用を試みる
    if command -v patch &>/dev/null; then
        if patch --dry-run "$error_file" < "$diff_file" &>/dev/null; then
            patch "$error_file" < "$diff_file" &>/dev/null
            if [[ $? -eq 0 ]]; then
                _healer_log "SUCCESS" "Diffパッチ適用成功: ${error_file##*/}"
                return 0
            fi
        fi
    fi

    # patchが失敗した場合、手動で行置換を試みる
    _healer_manual_diff_apply "$error_file" "$diff_content"
}

# patch不可時の手動diff適用
_healer_manual_diff_apply() {
    local error_file="$1" diff_content="$2"
    local tmpfile="${error_file}.heal_tmp"
    cp "$error_file" "$tmpfile" 2>/dev/null || return 1

    # 簡易的にdiffの-行を+行に置換する
    local applied=false
    while IFS= read -r line; do
        if [[ "$line" =~ ^-[^-] ]]; then
            local old_line="${line:1}"
            local next_plus=""
            # 次の+行を探す
            next_plus=$(echo "$diff_content" | grep -A1 "^-${old_line:0:40}" | grep '^+' | head -1)
            if [[ -n "$next_plus" ]]; then
                local new_line="${next_plus:1}"
                # sedで置換（最初の1つだけ）
                local escaped_old escaped_new
                escaped_old=$(printf '%s\n' "$old_line" | sed 's/[&/\]/\\&/g; s/[[\.*^$()+?{|]/\\&/g')
                escaped_new=$(printf '%s\n' "$new_line" | sed 's/[&/\]/\\&/g')
                sed -i.bak "0,/${escaped_old}/s//${escaped_new}/" "$tmpfile" 2>/dev/null && applied=true
                rm -f "${tmpfile}.bak" 2>/dev/null
            fi
        fi
    done <<< "$diff_content"

    if [[ "$applied" == "true" ]]; then
        mv "$tmpfile" "$error_file" 2>/dev/null
        _healer_log "SUCCESS" "手動Diff適用成功: ${error_file##*/}"
        return 0
    fi

    rm -f "$tmpfile" 2>/dev/null
    return 1
}

# ============================================================
# v11.0: Multi-Strategy Healing
# ============================================================

# 複数の修復戦略を順番に試す
healer_multi_strategy_fix() {
    local error_file="$1" error_msg="$2" error_severity="${3:-unknown}" attempt="${4:-0}"
    local fix_start_time
    fix_start_time=$(date +%s)

    # エラータイプ分類
    local error_type="unknown"
    local low=$(echo "$error_msg" | tr '[:upper:]' '[:lower:]')
    [[ "$low" =~ (syntax.error|syntaxerror|parse.error|unexpected.token) ]] && error_type="syntax"
    [[ "$low" =~ (import.error|module.not.found|cannot.find.module|no.module.named) ]] && error_type="import"
    [[ "$low" =~ (type.error|typeerror|type.mismatch) ]] && error_type="type"
    [[ "$low" =~ (runtime.error|reference.error|null.pointer|undefined.is.not) ]] && error_type="runtime"
    [[ "$low" =~ (warning|style|css|layout|render) ]] && error_type="ui"

    _healer_log "INFO" "マルチ戦略修復開始: ${error_file##*/} [${error_type}] (試行${attempt})"

    # 戦略1: Regex-based quick fix (構文エラー等の単純な修正)
    if [[ "$attempt" -eq 0 ]]; then
        _healer_log "INFO" "戦略1: Regex Quick Fix"
        if _healer_regex_fix "$error_file" "$error_msg" "$error_type"; then
            local duration=$(( $(date +%s) - fix_start_time ))
            _healer_analytics_record "$error_type" "regex_fix" "true" "$duration"
            echo "${error_file}|[regex-fix][${error_severity}] ${error_msg:0:80}|INLINE"
            return 0
        fi
        _healer_analytics_record "$error_type" "regex_fix" "false" "0"
    fi

    # 戦略2: Diff-based targeted fix (最小限の変更)
    if [[ "$attempt" -le 1 ]]; then
        _healer_log "INFO" "戦略2: Diff-Based Targeted Fix"
        local diff_output
        diff_output=$(_healer_generate_diff "$error_file" "$error_msg" "$error_severity")
        if [[ -n "$diff_output" ]]; then
            _healer_backup_file "$error_file"
            if _healer_apply_diff "$error_file" "$diff_output"; then
                local duration=$(( $(date +%s) - fix_start_time ))
                _healer_analytics_record "$error_type" "diff_fix" "true" "$duration"
                echo "${error_file}|[diff-fix][${error_severity}] ${error_msg:0:80}|INLINE"
                return 0
            fi
            _healer_revert_file "$error_file"
        fi
        _healer_analytics_record "$error_type" "diff_fix" "false" "0"
    fi

    # 戦略3: Claude targeted fix (該当部分のみ書き換え)
    if [[ "$attempt" -le 2 ]]; then
        _healer_log "INFO" "戦略3: Claude Targeted Fix"
        local fix_info
        fix_info=$(_healer_claude_targeted_fix "$error_file" "$error_msg" "$error_severity")
        if [[ -n "$fix_info" ]]; then
            local duration=$(( $(date +%s) - fix_start_time ))
            _healer_analytics_record "$error_type" "claude_targeted" "true" "$duration"
            echo "$fix_info"
            return 0
        fi
        _healer_analytics_record "$error_type" "claude_targeted" "false" "0"
    fi

    # 戦略4: Full rewrite (最後の手段 - ファイル全体を書き直す)
    _healer_log "INFO" "戦略4: Full Rewrite (最後の手段)"
    local fix_info
    fix_info=$(healer_generate_fix "$error_file" "$error_msg" "$error_severity" "$attempt")
    if [[ -n "$fix_info" ]]; then
        local duration=$(( $(date +%s) - fix_start_time ))
        _healer_analytics_record "$error_type" "full_rewrite" "true" "$duration"
        echo "$fix_info"
        return 0
    fi
    local duration=$(( $(date +%s) - fix_start_time ))
    _healer_analytics_record "$error_type" "full_rewrite" "false" "$duration"
    return 1
}

# Regex Quick Fix: よくあるパターンを正規表現で即座に修正
_healer_regex_fix() {
    local error_file="$1" error_msg="$2" error_type="$3"
    local ext="${error_file##*.}"
    local fixed=false

    _healer_backup_file "$error_file"

    case "$error_type" in
        syntax)
            # 末尾セミコロン欠落 (JS/TS)
            if [[ "$ext" =~ ^(js|ts|jsx|tsx)$ ]] && echo "$error_msg" | grep -qi "semicolon"; then
                # 全行末にセミコロンを追加するのではなく、エラー行のみ修正
                local line_num
                line_num=$(echo "$error_msg" | grep -oE ':[0-9]+:' | head -1 | tr -d ':')
                if [[ -n "$line_num" ]]; then
                    sed -i.bak "${line_num}s/[[:space:]]*$/;/" "$error_file" 2>/dev/null && fixed=true
                    rm -f "${error_file}.bak" 2>/dev/null
                fi
            fi
            # 括弧不一致
            if echo "$error_msg" | grep -qi "unexpected.*}"; then
                # 余分な閉じ括弧を検出 - 単純な場合のみ
                local line_num
                line_num=$(echo "$error_msg" | grep -oE ':[0-9]+:' | head -1 | tr -d ':')
                if [[ -n "$line_num" ]]; then
                    _healer_log "INFO" "Regexでは修正困難: 括弧不一致 (行${line_num})"
                fi
            fi
            # Python: インデントエラー
            if [[ "$ext" == "py" ]] && echo "$error_msg" | grep -qi "indentation"; then
                _healer_log "INFO" "Regexでは修正困難: Pythonインデント"
            fi
            ;;
        import)
            # 相対パスの './' 欠落 (JS/TS)
            if [[ "$ext" =~ ^(js|ts|jsx|tsx)$ ]] && echo "$error_msg" | grep -qi "cannot find module"; then
                local module_name
                module_name=$(echo "$error_msg" | grep -oE "'[^']+'" | head -1 | tr -d "'")
                if [[ -n "$module_name" && ! "$module_name" =~ ^[.@] ]]; then
                    # node_modulesにないローカルモジュールなら ./ を追加
                    if [[ ! -d "node_modules/${module_name}" ]]; then
                        sed -i.bak "s|from ['\"]${module_name}['\"]|from './${module_name}'|g" "$error_file" 2>/dev/null && fixed=true
                        rm -f "${error_file}.bak" 2>/dev/null
                    fi
                fi
            fi
            ;;
        type)
            # TypeScript any型でのクイック回避
            if [[ "$ext" =~ ^(ts|tsx)$ ]] && echo "$error_msg" | grep -qi "type.*is not assignable"; then
                _healer_log "INFO" "Regex: 型エラーはClaude修正が必要"
            fi
            ;;
    esac

    if [[ "$fixed" == "true" ]]; then
        _healer_log "SUCCESS" "Regex Quick Fix 成功: ${error_file##*/}"
        return 0
    fi

    _healer_revert_file "$error_file"
    return 1
}

# Claude Targeted Fix: エラー周辺のコードのみをClaudeに修正させる
_healer_claude_targeted_fix() {
    local error_file="$1" error_msg="$2" error_severity="$3"
    [[ ! -f "$error_file" ]] && return 1

    # エラー行番号を抽出
    local line_num
    line_num=$(echo "$error_msg" | grep -oE ':[0-9]+:' | head -1 | tr -d ':')
    line_num="${line_num:-1}"

    # エラー周辺30行を抽出
    local start_line end_line total_lines context
    total_lines=$(wc -l < "$error_file" | tr -d ' ')
    start_line=$((line_num - 15))
    [[ "$start_line" -lt 1 ]] && start_line=1
    end_line=$((line_num + 15))
    [[ "$end_line" -gt "$total_lines" ]] && end_line=$total_lines

    context=$(sed -n "${start_line},${end_line}p" "$error_file" 2>/dev/null)
    [[ -z "$context" ]] && return 1

    local prompt="ファイル ${error_file} の ${start_line}-${end_line} 行目付近にエラーがあります。
エラー: ${error_msg} (重要度: ${error_severity})

--- エラー周辺のコード (行${start_line}-${end_line}) ---
${context}

この部分だけの修正後コードを返してください。行${start_line}から${end_line}の範囲のみ。説明不要。"

    local fixed_section
    fixed_section=$(_healer_call_claude "$prompt")
    [[ -z "$fixed_section" ]] && return 1

    # コードブロックマーカー除去
    fixed_section=$(echo "$fixed_section" | sed '/^```[a-zA-Z]*/d; /^```$/d')

    # 修正コードを一時ファイルに保存
    local fix_id="fix_targeted_$(date +%s)_${RANDOM}_$$"
    local fix_file="${HEAL_LOG_DIR}/fixes/${fix_id}.tmp"
    mkdir -p "${HEAL_LOG_DIR}/fixes" 2>/dev/null || true

    # ファイル全体を再構成: 前半 + 修正部分 + 後半
    {
        [[ "$start_line" -gt 1 ]] && sed -n "1,$((start_line - 1))p" "$error_file"
        echo "$fixed_section"
        [[ "$end_line" -lt "$total_lines" ]] && sed -n "$((end_line + 1)),\$p" "$error_file"
    } > "$fix_file"

    echo "${error_file}|[targeted][${error_severity}] ${error_msg:0:80}|${fix_file}"
}

# ============================================================
# v11.0: Smart Rollback
# ============================================================

# 修復前後のエラー数を比較し、悪化していたらロールバック
_healer_smart_rollback_check() {
    local project_dir="$1" error_count_before="$2"
    local error_count_after

    # 現在のエラー数を取得
    if type -t validator_run_all &>/dev/null; then
        local report
        report=$(validator_run_all "$project_dir" 2>/dev/null || echo "")
        error_count_after=$(_healer_count_errors "$report")
    else
        local report
        report=$(_healer_basic_validate "$project_dir")
        error_count_after=$(_healer_count_errors "$report")
    fi

    if [[ "$error_count_after" -gt "$error_count_before" ]]; then
        local increase=$((error_count_after - error_count_before))
        _healer_log "WARN" "Smart Rollback: エラー増加検出 (${error_count_before} -> ${error_count_after}, +${increase})"
        return 1  # ロールバックが必要
    fi

    _healer_log "INFO" "Smart Rollback: エラー改善 (${error_count_before} -> ${error_count_after})"
    return 0  # 問題なし
}

# ロールバック実行: 直前のgitコミットに戻す
_healer_smart_rollback_execute() {
    local files_to_rollback="$1"

    if command -v git &>/dev/null && git rev-parse --is-inside-work-tree &>/dev/null 2>&1; then
        # ファイルリストが指定されていればファイル単位でロールバック
        if [[ -n "$files_to_rollback" ]]; then
            while IFS= read -r f; do
                [[ -z "$f" || ! -f "$f" ]] && continue
                # バックアップからリバート
                if _healer_revert_file "$f"; then
                    git checkout -- "$f" 2>/dev/null || true
                    _healer_log "INFO" "Smart Rollback: ${f##*/} をリバート"
                fi
            done <<< "$files_to_rollback"
        else
            # 全体ロールバック
            git reset --hard HEAD~1 2>/dev/null || true
            _healer_log "WARN" "Smart Rollback: 前のコミットにリセット"
        fi
    fi
}

# ============================================================
# v11.0: Parallel Healing (独立ファイルの同時修復)
# ============================================================

# 独立ファイルを特定し並列で修復
healer_parallel_fix() {
    local error_lines="$1" project_dir="$2"
    [[ "$HEAL_PARALLEL_ENABLED" != "true" ]] && return 1

    # ファイル別にエラーをグループ化
    declare -A file_errors=()
    while IFS='|' read -r f m s; do
        [[ -z "$f" ]] && continue
        file_errors[$f]+="${f}|${m}|${s}\n"
    done <<< "$error_lines"

    local unique_files=("${!file_errors[@]}")
    local num_files=${#unique_files[@]}

    # 2ファイル未満なら並列は不要
    [[ "$num_files" -lt 2 ]] && return 1

    _healer_log "INFO" "並列ヒーリング: ${num_files}ファイル (最大${HEAL_PARALLEL_MAX}並列)"

    local pids=() results_dir="${HEAL_LOG_DIR}/parallel_$$"
    mkdir -p "$results_dir" 2>/dev/null || true

    local slot=0
    for file in "${unique_files[@]}"; do
        # スロット制限
        while [[ "$slot" -ge "$HEAL_PARALLEL_MAX" ]]; do
            # 終了したプロセスを回収
            local new_pids=()
            for pid in "${pids[@]}"; do
                if kill -0 "$pid" 2>/dev/null; then
                    new_pids+=("$pid")
                else
                    slot=$((slot - 1))
                fi
            done
            pids=("${new_pids[@]}")
            [[ "$slot" -ge "$HEAL_PARALLEL_MAX" ]] && sleep 1
        done

        # サブシェルで修復実行
        (
            local first_error
            first_error=$(echo -e "${file_errors[$file]}" | head -1)
            local e_file e_msg e_sev
            e_file=$(echo "$first_error" | cut -d'|' -f1)
            e_msg=$(echo "$first_error" | cut -d'|' -f2)
            e_sev=$(echo "$first_error" | cut -d'|' -f3)

            local result
            result=$(healer_multi_strategy_fix "$e_file" "$e_msg" "$e_sev" 0)
            if [[ -n "$result" ]]; then
                echo "OK|${result}" > "${results_dir}/$(basename "$file").result"
            else
                echo "NG|${file}" > "${results_dir}/$(basename "$file").result"
            fi
        ) &
        pids+=($!)
        slot=$((slot + 1))
    done

    # 全プロセス完了待ち
    for pid in "${pids[@]}"; do
        wait "$pid" 2>/dev/null || true
    done

    # 結果集計
    local parallel_ok=0 parallel_ng=0
    for rfile in "$results_dir"/*.result; do
        [[ -f "$rfile" ]] || continue
        local status
        status=$(head -1 "$rfile" | cut -d'|' -f1)
        if [[ "$status" == "OK" ]]; then
            parallel_ok=$((parallel_ok + 1))
            local fix_info
            fix_info=$(head -1 "$rfile" | cut -d'|' -f2-)
            # 適用
            if [[ -n "$fix_info" && "$fix_info" != *"INLINE"* ]]; then
                healer_apply_fix "$fix_info" 2>/dev/null || true
            fi
        else
            parallel_ng=$((parallel_ng + 1))
        fi
    done

    rm -rf "$results_dir" 2>/dev/null
    _healer_log "INFO" "並列ヒーリング完了: 成功=${parallel_ok}, 失敗=${parallel_ng}"
    echo "${parallel_ok}"
    return 0
}

# ============================================================
# メイン修復ループ - エラーゼロまで繰り返す (v11.0 enhanced)
# ============================================================
healer_run() {
    local project_dir="$1" validation_report="$2"
    echo -e "\n${HEAL_BOLD}${HEAL_PURPLE}[HEALER v11.0] 自動修復ループ開始${HEAL_NC}"
    echo -e "  モード: マルチ戦略 | Diff-Based | 並列: ${HEAL_PARALLEL_ENABLED} | Smart Rollback: ON"

    local iteration=0 current_report="$validation_report"
    local error_count
    error_count=$(_healer_count_errors "$current_report")

    while [[ "$error_count" -gt 0 && "$iteration" -lt "$MAX_HEAL_ITERATIONS" ]]; do
        iteration=$((iteration + 1))
        HEAL_ITERATION=$iteration
        local error_count_before=$error_count

        # v24.0: わかりやすい状況表示
        _healer_explain_status "$error_count" "$iteration" "$MAX_HEAL_ITERATIONS"
        echo -e "${HEAL_BOLD}── 修復 ${iteration}/${MAX_HEAL_ITERATIONS} (残エラー: ${error_count}) ──${HEAL_NC}"

        # 優先度ソート -> カスケード検出
        local prioritized cascade_groups
        prioritized=$(healer_prioritize_errors "$current_report")
        cascade_groups=$(healer_detect_cascade "$prioritized")

        # v11.0: 独立ファイルが複数ある場合は並列ヒーリング試行
        local parallel_result=""
        if [[ "$HEAL_PARALLEL_ENABLED" == "true" ]]; then
            local unique_file_count
            unique_file_count=$(echo "$cascade_groups" | cut -d'|' -f1 | sort -u | grep -c . 2>/dev/null || echo "0")
            if [[ "$unique_file_count" -ge 2 ]]; then
                parallel_result=$(healer_parallel_fix "$cascade_groups" "$project_dir" 2>/dev/null || echo "")
            fi
        fi

        # 並列で処理されなかった、もしくは並列が無効の場合はシーケンシャル
        local fixed_count=0
        if [[ -z "$parallel_result" ]]; then
            while IFS= read -r error_line; do
                [[ -z "$error_line" ]] && continue
                local e_file e_msg e_sev
                e_file=$(echo "$error_line" | cut -d'|' -f1)
                e_msg=$(echo "$error_line" | cut -d'|' -f2)
                e_sev=$(echo "$error_line" | cut -d'|' -f3)

                # v24.0: エラーをわかりやすく表示
                echo -e "  ${HEAL_CYAN}━━ ファイル: $(basename "$e_file") ━━${HEAL_NC}"
                _healer_explain_error "$e_msg" "$e_sev" 2>/dev/null || true

                # 試行回数チェック（同一エラー3回で諦め）
                local ehash attempts
                ehash=$(_healer_error_hash "$e_file" "$e_msg")
                attempts="${HEAL_FIX_HISTORY[$ehash]:-0}"
                if [[ "$attempts" -ge "$MAX_FIX_ATTEMPTS_PER_ERROR" ]]; then
                    echo -e "  ${HEAL_YELLOW}→ 3回試しましたが解決できませんでした。スキップします${HEAL_NC}"
                    HEAL_SKIPPED_ERRORS=$((HEAL_SKIPPED_ERRORS + 1)); continue
                fi

                # v15.5: Plugin hook - on_error
                type -t pl_fire_hook &>/dev/null && pl_fire_hook "on_error" "$e_sev" 2>/dev/null || true

                # v11.0: マルチ戦略修復
                local fix_info
                fix_info=$(healer_multi_strategy_fix "$e_file" "$e_msg" "$e_sev" "$attempts")
                if [[ -z "$fix_info" ]]; then
                    HEAL_FIX_HISTORY[$ehash]=$((attempts + 1)); continue
                fi

                # INLINE修正は既に適用済み
                if [[ "$fix_info" == *"|INLINE" ]]; then
                    if healer_verify_fix "$e_file" "$e_msg" "$fix_info"; then
                        fixed_count=$((fixed_count + 1))
                        HEAL_SUCCESSFUL_FIXES=$((HEAL_SUCCESSFUL_FIXES + 1))
                        type -t rt_capture_success &>/dev/null && \
                            rt_capture_success "HEAL" "auto-fix" "修復成功: ${e_file##*/}" "${e_msg:0:80}"
                        # v15.5: Plugin hook - on_heal
                        type -t pl_fire_hook &>/dev/null && pl_fire_hook "on_heal" "$e_sev" 2>/dev/null || true
                    else
                        HEAL_FAILED_FIXES=$((HEAL_FAILED_FIXES + 1))
                        HEAL_FIX_HISTORY[$ehash]=$((attempts + 1))
                    fi
                elif healer_apply_fix "$fix_info" && healer_verify_fix "$e_file" "$e_msg" "$fix_info"; then
                    fixed_count=$((fixed_count + 1))
                    HEAL_SUCCESSFUL_FIXES=$((HEAL_SUCCESSFUL_FIXES + 1))
                    type -t rt_capture_success &>/dev/null && \
                        rt_capture_success "HEAL" "auto-fix" "修復成功: ${e_file##*/}" "${e_msg:0:80}"
                    # v15.5: Plugin hook - on_heal
                    type -t pl_fire_hook &>/dev/null && pl_fire_hook "on_heal" "$e_sev" 2>/dev/null || true
                else
                    HEAL_FAILED_FIXES=$((HEAL_FAILED_FIXES + 1))
                    HEAL_FIX_HISTORY[$ehash]=$((attempts + 1))
                fi
                HEAL_TOTAL_FIXES=$((HEAL_TOTAL_FIXES + 1))
            done <<< "$cascade_groups"
        else
            fixed_count="${parallel_result:-0}"
            HEAL_SUCCESSFUL_FIXES=$((HEAL_SUCCESSFUL_FIXES + fixed_count))
        fi

        # 進展なし -> ループ脱出
        if [[ "$fixed_count" -eq 0 ]]; then
            _healer_log "WARN" "進展なし - ループ終了"
            break
        fi

        # 再バリデーション
        echo -e "  ${HEAL_CYAN}再バリデーション...${HEAL_NC}"
        if type -t validator_run_all &>/dev/null; then
            current_report=$(validator_run_all "$project_dir" 2>/dev/null || echo "")
        else
            current_report=$(_healer_basic_validate "$project_dir")
        fi
        error_count=$(_healer_count_errors "$current_report")

        # v11.0: Smart Rollback - エラーが増えていたらロールバック
        if [[ "$error_count" -gt "$error_count_before" ]]; then
            local increase=$((error_count - error_count_before))
            _healer_log "WARN" "Smart Rollback: エラー${increase}個増加 (${error_count_before} -> ${error_count})"
            _healer_smart_rollback_execute ""
            # ロールバック後に再検証
            if type -t validator_run_all &>/dev/null; then
                current_report=$(validator_run_all "$project_dir" 2>/dev/null || echo "")
            else
                current_report=$(_healer_basic_validate "$project_dir")
            fi
            error_count=$(_healer_count_errors "$current_report")
            _healer_log "INFO" "ロールバック後エラー数: ${error_count}"
        fi

        # チェックポイント
        type -t checkpoint_save &>/dev/null && checkpoint_save "$iteration" 2>/dev/null || true
        _healer_save_checkpoint "$iteration" "$error_count" "$fixed_count"
        echo -e "  完了: 修正=${fixed_count}, 残エラー=${error_count}"
    done

    # 終了処理
    if [[ "$error_count" -gt 0 ]]; then
        echo -e "\n${HEAL_YELLOW}[HEALER] 最大イテレーション到達。残: ${error_count}${HEAL_NC}"
        healer_escalate "$current_report"
    else
        echo -e "\n${HEAL_GREEN}[HEALER] 全エラー修復完了!${HEAL_NC}"
    fi
    healer_report
    healer_analytics_summary
    echo "$current_report"
}

# ============================================================
# 修正生成 - Claude CLIでエラーを修復 (v8.0 legacy, full rewrite strategy)
# ============================================================
healer_generate_fix() {
    local error_file="$1" error_msg="$2" error_severity="${3:-unknown}" attempt="${4:-0}"
    [[ ! -f "$error_file" ]] && return 1

    local file_content
    file_content=$(cat "$error_file" 2>/dev/null || echo "")
    [[ -z "$file_content" ]] && return 1

    # 試行回数に応じてプロンプト変更（繰り返し回避）
    local prompt
    case "$attempt" in
        0) prompt="以下のファイルにエラーがあります:
エラー: ${error_msg} (重要度: ${error_severity})

${file_content}

修正後のコード全体のみを返してください。説明不要。" ;;
        1) prompt="前回の修正が失敗。別アプローチで修正してください。
エラー: ${error_msg}

${file_content}

根本原因を分析し異なるアプローチで。コード全体のみ返してください。" ;;
        *) prompt="${attempt}回修正失敗。完全に異なる解決策で修正してください。
エラー: ${error_msg}

${file_content}

ロジック再構築も検討。コード全体のみ返してください。" ;;
    esac

    local fixed_code
    fixed_code=$(_healer_call_claude "$prompt" "$error_file")
    [[ -z "$fixed_code" ]] && return 1

    # コードブロックマーカー除去
    fixed_code=$(echo "$fixed_code" | sed '/^```[a-zA-Z]*/d; /^```$/d')

    # 修正コードをファイル保存（ユニークID付きで競合防止）
    local fix_id="fix_$(date +%s)_${RANDOM}_$$"
    local fix_file="${HEAL_LOG_DIR}/fixes/${fix_id}.tmp"
    mkdir -p "${HEAL_LOG_DIR}/fixes" 2>/dev/null || true
    printf '%s\n' "$fixed_code" > "$fix_file"

    # 修正情報を返却（パイプ区切り：ファイル|説明|修正コードパス）
    echo "${error_file}|[${error_severity}] ${error_msg:0:80}|${fix_file}"
}

# ============================================================
# 修正適用 - バックアップ -> 書き込み -> Gitコミット
# ============================================================
healer_apply_fix() {
    local fix_info="$1"
    local target_file fix_desc fix_code_path
    target_file=$(echo "$fix_info" | cut -d'|' -f1)
    fix_desc=$(echo "$fix_info" | cut -d'|' -f2)
    fix_code_path=$(echo "$fix_info" | cut -d'|' -f3)
    [[ ! -f "$target_file" ]] && return 1

    # INLINEは既に適用済み
    [[ "$fix_code_path" == "INLINE" ]] && return 0

    _healer_backup_file "$target_file"

    [[ -z "$fix_code_path" || ! -f "$fix_code_path" ]] && return 1

    cp "$fix_code_path" "$target_file" 2>/dev/null || {
        _healer_revert_file "$target_file"; return 1
    }

    # 個別コミット（ロールバック容易化）
    if command -v git &>/dev/null && git rev-parse --is-inside-work-tree &>/dev/null 2>&1; then
        git add "$target_file" 2>/dev/null || true
        git commit -m "fix(healer): ${fix_desc}" 2>/dev/null || true
    fi

    echo "[$(date '+%Y-%m-%d %H:%M:%S')] APPLIED | ${target_file} | ${fix_desc}" \
        >> "${HEAL_LOG_DIR}/fix_history.log"
    echo -e "  ${HEAL_GREEN}適用: ${target_file##*/}${HEAL_NC}"
    return 0
}

# ============================================================
# 修正検証 - 構文チェック + バリデータ
# ============================================================
healer_verify_fix() {
    local error_file="$1" error_msg="$2" fix_info="$3"
    local target_file
    target_file=$(echo "$fix_info" | cut -d'|' -f1)
    local ext="${target_file##*.}" ok=true

    # 言語別構文チェック
    case "$ext" in
        py)       python3 -c "import ast,sys; ast.parse(open(sys.argv[1]).read())" "$target_file" 2>/dev/null || ok=false ;;
        js|jsx)   command -v node &>/dev/null && { node --check "$target_file" 2>/dev/null || ok=false; } ;;
        ts|tsx)   [[ -f "node_modules/.bin/tsc" ]] && { npx tsc --noEmit "$target_file" 2>/dev/null || ok=false; } ;;
        sh|bash)  bash -n "$target_file" 2>/dev/null || ok=false ;;
        rb)       command -v ruby &>/dev/null && { ruby -c "$target_file" 2>/dev/null || ok=false; } ;;
        go)       command -v gofmt &>/dev/null && { gofmt -e "$target_file" >/dev/null 2>&1 || ok=false; } ;;
    esac

    # バリデータ連携
    [[ "$ok" == "true" ]] && type -t validator_check_file &>/dev/null && \
        { validator_check_file "$target_file" 2>/dev/null || ok=false; }

    if [[ "$ok" == "true" ]]; then
        echo -e "  ${HEAL_GREEN}検証OK${HEAL_NC}"
        return 0
    fi

    # 失敗 -> ロールバック
    echo -e "  ${HEAL_RED}検証NG - ロールバック${HEAL_NC}"
    _healer_revert_file "$target_file"
    command -v git &>/dev/null && git checkout -- "$target_file" 2>/dev/null || true
    type -t rt_capture_error &>/dev/null && \
        rt_capture_error "HEAL" "fix-failed" "修復失敗: ${target_file##*/}" "${error_msg:0:80}"
    return 1
}

# ============================================================
# エラー優先度ソート（構文>依存>型>ランタイム>UI>エッジ）
# ============================================================
healer_prioritize_errors() {
    local input="$1"
    [[ -f "$input" ]] && input=$(cat "$input")

    echo "$input" | while IFS= read -r line; do
        [[ -z "$line" || "$line" =~ ^# ]] && continue
        local p=99 low=$(echo "$line" | tr '[:upper:]' '[:lower:]')

        [[ "$low" =~ (syntax.error|syntaxerror|parse.error|unexpected.token) ]] && p=1
        [[ "$low" =~ (import.error|module.not.found|cannot.find.module|no.module.named) ]] && p=2
        [[ "$low" =~ (type.error|typeerror|type.mismatch) ]] && p=3
        [[ "$low" =~ (runtime.error|reference.error|null.pointer|undefined.is.not) ]] && p=4
        [[ "$low" =~ (warning|style|css|layout|render) ]] && p=5
        [[ "$low" =~ (potential|edge.case|deprecated|unused) ]] && p=6

        # ファイルパスの抽出
        local fpath="unknown" msg="$line"
        [[ "$line" =~ ^([^:]+):[0-9]+: ]] && fpath="${BASH_REMATCH[1]}"
        [[ "$line" =~ ^([^|]+)\| ]] && fpath="${BASH_REMATCH[1]}"

        local sev="other"
        case "$p" in 1) sev="syntax";; 2) sev="import";; 3) sev="type";;
                     4) sev="runtime";; 5) sev="ui";; 6) sev="edge";; esac

        echo "${p}|${fpath}|${msg}|${sev}"
    done | sort -t'|' -k1 -n | while IFS='|' read -r _ f m s; do
        echo "${f}|${m}|${s}"
    done
}

# ============================================================
# カスケード検出 - 同一ファイル5+エラーは根本原因のみ修正
# ============================================================
healer_detect_cascade() {
    local input="$1"
    declare -A counts=() firsts=() seen=()

    # 1パス: ファイル別カウント
    while IFS='|' read -r f m s; do
        [[ -z "$f" ]] && continue
        counts[$f]=$(( ${counts[$f]:-0} + 1 ))
        [[ -z "${firsts[$f]:-}" ]] && firsts[$f]="${f}|${m}|${s}"
    done <<< "$input"

    # 2パス: カスケードグループまたは個別出力
    while IFS='|' read -r f m s; do
        [[ -z "$f" ]] && continue
        local c="${counts[$f]:-0}"
        if [[ "$c" -ge 5 && -z "${seen[$f]:-}" ]]; then
            _healer_log "INFO" "カスケード: ${f} (${c}エラー)"
            echo "${firsts[$f]}"
            seen[$f]=1
        elif [[ "$c" -lt 5 && -z "${seen[${f}:${m}]:-}" ]]; then
            echo "${f}|${m}|${s}"
            seen["${f}:${m}"]=1
        fi
    done <<< "$input"
}

# ============================================================
# エスカレーション - 修復限界到達時のレポート生成
# ============================================================
healer_escalate() {
    local remaining="$1"
    mkdir -p "docs/chain-logs" 2>/dev/null || true
    local rpt="docs/chain-logs/escalation_report.md"
    local mins=$(( ($(date +%s) - HEAL_START_TIME) / 60 ))

    {
        echo "# Escalation Report - 自動修復限界到達"
        echo ""
        echo "**セッション**: ${HEAL_SESSION_ID} | **経過**: ${mins}分 | **イテレーション**: ${HEAL_ITERATION}/${MAX_HEAL_ITERATIONS}"
        echo ""
        echo "## 統計"
        echo "| 項目 | 値 |"
        echo "|------|---:|"
        echo "| 総修正試行 | ${HEAL_TOTAL_FIXES} |"
        echo "| 成功 | ${HEAL_SUCCESSFUL_FIXES} |"
        echo "| 失敗 | ${HEAL_FAILED_FIXES} |"
        echo "| スキップ | ${HEAL_SKIPPED_ERRORS} |"
        echo ""
        echo "## v11.0 戦略別分析"
        for strat in "${!HEAL_ANALYTICS_BY_STRATEGY[@]}"; do
            local counts="${HEAL_ANALYTICS_BY_STRATEGY[$strat]}"
            local ok ng
            ok=$(echo "$counts" | cut -d':' -f1)
            ng=$(echo "$counts" | cut -d':' -f2)
            echo "- **${strat}**: 成功${ok} / 失敗${ng}"
        done
        echo ""
        echo "## 未解決エラー"
        echo '```'
        echo "$remaining"
        echo '```'
        echo ""
        echo "## 推奨手動対応"
        local guide
        guide=$(_healer_call_claude "以下のエラーの手動修正方法を簡潔に提案:
${remaining}" "")
        echo "${guide:-エラーメッセージを確認して手動対応してください。}"
    } > "$rpt"

    _healer_log "ESCALATE" "レポート: ${rpt}"
    echo -e "  ${HEAL_YELLOW}エスカレーション: ${rpt}${HEAL_NC}"
}

# ============================================================
# 修復サマリーレポート (v11.0 enhanced)
# ============================================================
healer_report() {
    local elapsed=$(( $(date +%s) - HEAL_START_TIME ))
    local rate=0
    [[ "$HEAL_TOTAL_FIXES" -gt 0 ]] && rate=$(( (HEAL_SUCCESSFUL_FIXES * 100) / HEAL_TOTAL_FIXES ))

    echo ""
    echo -e "${HEAL_BOLD}${HEAL_PURPLE}+=============================================+${HEAL_NC}"
    echo -e "${HEAL_BOLD}${HEAL_PURPLE}|      Self-Healing Report (v11.0)            |${HEAL_NC}"
    echo -e "${HEAL_BOLD}${HEAL_PURPLE}+=============================================+${HEAL_NC}"
    echo -e "  イテレーション: ${HEAL_ITERATION}/${MAX_HEAL_ITERATIONS}"
    echo -e "  修正試行: ${HEAL_TOTAL_FIXES} | 成功: ${HEAL_GREEN}${HEAL_SUCCESSFUL_FIXES}${HEAL_NC} | 失敗: ${HEAL_RED}${HEAL_FAILED_FIXES}${HEAL_NC} | Skip: ${HEAL_YELLOW}${HEAL_SKIPPED_ERRORS}${HEAL_NC}"
    echo -e "  成功率: ${rate}% | 経過: $((elapsed/60))分$((elapsed%60))秒"
    echo -e "  並列ヒーリング: ${HEAL_PARALLEL_ENABLED} | Smart Rollback: ON"

    # v11.0: 戦略別サマリー
    echo -e "  ${HEAL_BOLD}戦略別:${HEAL_NC}"
    for strat in regex_fix diff_fix claude_targeted full_rewrite; do
        local counts="${HEAL_ANALYTICS_BY_STRATEGY[$strat]:-0:0}"
        local ok ng
        ok=$(echo "$counts" | cut -d':' -f1)
        ng=$(echo "$counts" | cut -d':' -f2)
        [[ "$ok" -eq 0 && "$ng" -eq 0 ]] && continue
        echo -e "    ${strat}: ${HEAL_GREEN}${ok}ok${HEAL_NC} / ${HEAL_RED}${ng}ng${HEAL_NC}"
    done

    local status="HEALING FAILED"
    [[ "$HEAL_FAILED_FIXES" -eq 0 && "$HEAL_SKIPPED_ERRORS" -eq 0 ]] && status="FULLY HEALED"
    [[ "$HEAL_SUCCESSFUL_FIXES" -gt 0 && "$status" == "HEALING FAILED" ]] && status="PARTIALLY HEALED"
    local sc="${HEAL_RED}"
    [[ "$status" == "FULLY HEALED" ]] && sc="${HEAL_GREEN}"
    [[ "$status" == "PARTIALLY HEALED" ]] && sc="${HEAL_YELLOW}"
    echo -e "  ステータス: ${sc}${status}${HEAL_NC}"
    echo -e "${HEAL_BOLD}${HEAL_PURPLE}+=============================================+${HEAL_NC}"

    # v24.0: わかりやすい修復レポート
    _healer_friendly_report "$HEAL_TOTAL_FIXES" "$HEAL_SUCCESSFUL_FIXES" "$HEAL_FAILED_FIXES" "$HEAL_SKIPPED_ERRORS" "$elapsed"

    _healer_save_report "$elapsed" "$rate"
}

# ============================================================
# 内部: 簡易バリデーション（validator未定義時フォールバック）
# ============================================================
_healer_basic_validate() {
    local dir="$1" errors=""
    # Python
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        python3 -c "import ast,sys; ast.parse(open(sys.argv[1]).read())" "$f" 2>/dev/null || \
            errors+="${f}|SyntaxError|syntax\n"
    done < <(find "$dir" -name "*.py" -not -path "*/node_modules/*" -not -path "*/.venv/*" 2>/dev/null)
    # JavaScript
    if command -v node &>/dev/null; then
        while IFS= read -r f; do
            [[ -z "$f" ]] && continue
            node --check "$f" 2>/dev/null || errors+="${f}|SyntaxError: JS|syntax\n"
        done < <(find "$dir" -name "*.js" -not -path "*/node_modules/*" 2>/dev/null)
    fi
    # Shell
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        bash -n "$f" 2>/dev/null || errors+="${f}|SyntaxError: Bash|syntax\n"
    done < <(find "$dir" -name "*.sh" -not -path "*/node_modules/*" 2>/dev/null)
    echo -e "$errors"
}

# チェックポイント・レポートJSON保存
_healer_save_checkpoint() {
    [[ -z "$HEAL_LOG_DIR" ]] && return
    cat > "${HEAL_LOG_DIR}/checkpoint_${1}.json" <<EOF
{"iteration":${1},"timestamp":"$(date -u +%Y-%m-%dT%H:%M:%SZ)","remaining_errors":${2},"fixes_this_round":${3},"total":${HEAL_TOTAL_FIXES},"ok":${HEAL_SUCCESSFUL_FIXES},"ng":${HEAL_FAILED_FIXES},"skip":${HEAL_SKIPPED_ERRORS}}
EOF
}

_healer_save_report() {
    [[ -z "$HEAL_LOG_DIR" ]] && return
    cat > "${HEAL_LOG_DIR}/heal_report.json" <<EOF
{"session_id":"${HEAL_SESSION_ID}","version":"11.0","timestamp":"$(date -u +%Y-%m-%dT%H:%M:%SZ)","iterations":${HEAL_ITERATION},"max":${MAX_HEAL_ITERATIONS},"elapsed_sec":${1},"total":${HEAL_TOTAL_FIXES},"ok":${HEAL_SUCCESSFUL_FIXES},"ng":${HEAL_FAILED_FIXES},"skip":${HEAL_SKIPPED_ERRORS},"rate":${2},"project":"${HEAL_PROJECT_DIR}","parallel":"${HEAL_PARALLEL_ENABLED}","strategies":["regex_fix","diff_fix","claude_targeted","full_rewrite"]}
EOF
    _healer_log "INFO" "レポート保存: ${HEAL_LOG_DIR}/heal_report.json"
}

# ============================================================
# エクスポート（chain.shから source して使用）
# ============================================================
#   source lib/healer.sh
#   healer_init "session_001" "/path/to/project"
#   healer_run "/path/to/project" "validation_report.txt"
#   healer_report
#   healer_analytics_summary              # v11.0: アナリティクス
#   healer_analytics_hardest              # v11.0: 最も困難なエラータイプ
#   healer_multi_strategy_fix file msg    # v11.0: マルチ戦略修復
#   healer_parallel_fix errors dir        # v11.0: 並列修復

# ============================================================
# v2043 L8 refiner 連結部 (検証閉ループ橋渡し・opt-in・既存挙動不変・末尾追加のみ)
# ------------------------------------------------------------
# 既存 healer は test 結果ベースの修復ループ。本連結部はゲートが吐く refiner.json
# (構造的欠落指示) を診断分類し専用 fixer へ当てて差分のみ再検証する閉ループ
# (lib/refiner-to-healer.sh) を healer から呼べるようにする。SOLOPTILINK_REFINER_LOOP=on の
# ときだけ作動 (既定 off=従来の healer 挙動を一切変えない)。refiner-to-healer 不在でも安全に no-op。
# ============================================================
healer_refiner_loop() {
    local proj="${1:?project_dir required}"; local mode="${2:-plan}"
    [[ "${SOLOPTILINK_REFINER_LOOP:-off}" == "on" ]] || { _healer_log "INFO" "refiner 閉ループ無効 (SOLOPTILINK_REFINER_LOOP!=on) → skip" 2>/dev/null || true; return 0; }
    local r2h="${SOLOPTILINK_HOME:-$HOME/.soloptilink}/lib/refiner-to-healer.sh"
    [[ -f "$r2h" ]] || { _healer_log "WARN" "refiner-to-healer.sh 不在 → no-op" 2>/dev/null || true; return 0; }
    _healer_log "INFO" "refiner 閉ループ起動 (mode=$mode): $proj" 2>/dev/null || true
    bash "$r2h" run "$proj" $([[ "$mode" == "apply" ]] && echo "--apply") 2>&1
}
