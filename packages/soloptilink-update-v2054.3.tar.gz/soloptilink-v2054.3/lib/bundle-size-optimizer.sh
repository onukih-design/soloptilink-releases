#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v431.0 - Bundle Size Optimizer
# =============================================================================
# フロントエンドバンドルサイズの分析・最適化。大きな依存の特定、
# 代替パッケージの提案、tree-shaking/code-splitting設定の最適化を行う。
#
# Functions:
#   _bso_init()                  - 初期化
#   _bso_analyze_bundle()        - バンドルサイズ分析
#   _bso_find_large_deps()       - 大きな依存の特定
#   _bso_suggest_alternatives()  - 軽量代替の提案
#   _bso_report() / _bso_score()
#
# All globals use the BSO_ prefix.
# =============================================================================

[[ -n "${_BSO_LOADED:-}" ]] && return 0; _BSO_LOADED=1

declare -g BSO_VERSION="431.0"
declare -g BSO_GENERATED=0
declare -g BSO_ERRORS=0
declare -g BSO_TOTAL_BUNDLE_KB=0
declare -g BSO_LARGE_DEPS_COUNT=0
declare -g BSO_ALTERNATIVES_FOUND=0
declare -g BSO_POTENTIAL_SAVINGS_KB=0
declare -g BSO_THRESHOLD_KB="${BSO_THRESHOLD_KB:-100}"

declare -gA _BSO_DEP_SIZES=()
declare -gA _BSO_ALTERNATIVES=()

_BSO_GREEN="${GREEN:-\033[0;32m}"
_BSO_RED="${RED:-\033[0;31m}"
_BSO_YELLOW="${YELLOW:-\033[0;33m}"
_BSO_CYAN="${CYAN:-\033[0;36m}"
_BSO_BOLD="${BOLD:-\033[1m}"
_BSO_NC="${NC:-\033[0m}"

_bso_init() {
    BSO_GENERATED=0; BSO_ERRORS=0; BSO_TOTAL_BUNDLE_KB=0
    BSO_LARGE_DEPS_COUNT=0; BSO_ALTERNATIVES_FOUND=0; BSO_POTENTIAL_SAVINGS_KB=0
    _BSO_DEP_SIZES=(); _BSO_ALTERNATIVES=()

    # 既知の軽量代替マッピング
    _BSO_ALTERNATIVES["moment"]="dayjs (2KB vs 67KB)"
    _BSO_ALTERNATIVES["lodash"]="lodash-es or native (tree-shakeable)"
    _BSO_ALTERNATIVES["axios"]="fetch API (native, 0KB)"
    _BSO_ALTERNATIVES["uuid"]="crypto.randomUUID() (native)"
    _BSO_ALTERNATIVES["classnames"]="clsx (228B vs 1KB)"
    _BSO_ALTERNATIVES["date-fns"]="already tree-shakeable, import specific functions"
    _BSO_ALTERNATIVES["validator"]="zod (type-safe validation)"
    _BSO_ALTERNATIVES["numeral"]="Intl.NumberFormat (native)"
    _BSO_ALTERNATIVES["chalk"]="picocolors (3.8KB vs 44KB)"
    _BSO_ALTERNATIVES["request"]="node-fetch or native fetch"
    return 0
}

_bso_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_BSO_CYAN}[BSO]${_BSO_NC} $*" >&2 ;;
        ok)    echo -e "  ${_BSO_GREEN}[BSO]${_BSO_NC} $*" >&2 ;;
        warn)  echo -e "  ${_BSO_YELLOW}[BSO]${_BSO_NC} $*" >&2 ;;
        error) echo -e "  ${_BSO_RED}[BSO]${_BSO_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _bso_analyze_bundle - バンドルサイズ分析
# =============================================================================
_bso_analyze_bundle() {
    local project_dir="${1:-.}"
    _bso_log info "バンドルサイズ分析: ${project_dir}"

    BSO_TOTAL_BUNDLE_KB=0

    # .next/static 分析 (Next.js)
    local next_static="${project_dir}/.next/static"
    if [[ -d "$next_static" ]]; then
        BSO_TOTAL_BUNDLE_KB=$(du -sk "$next_static" 2>/dev/null | cut -f1 || echo 0)
        _bso_log info "Next.js staticバンドル: ${BSO_TOTAL_BUNDLE_KB}KB"
    fi

    # dist/ 分析
    local dist_dir="${project_dir}/dist"
    if [[ -d "$dist_dir" ]]; then
        local dist_size
        dist_size=$(du -sk "$dist_dir" 2>/dev/null | cut -f1 || echo 0)
        BSO_TOTAL_BUNDLE_KB=$((BSO_TOTAL_BUNDLE_KB + dist_size))
        _bso_log info "dist/バンドル: ${dist_size}KB"
    fi

    # build/ 分析
    local build_dir="${project_dir}/build"
    if [[ -d "$build_dir" ]]; then
        local build_size
        build_size=$(du -sk "$build_dir" 2>/dev/null | cut -f1 || echo 0)
        BSO_TOTAL_BUNDLE_KB=$((BSO_TOTAL_BUNDLE_KB + build_size))
    fi

    # 個別JSファイルサイズ分析
    local large_files=0
    while IFS= read -r -d '' file; do
        local size_kb
        size_kb=$(du -k "$file" 2>/dev/null | cut -f1 || echo 0)
        if [[ $size_kb -gt $BSO_THRESHOLD_KB ]]; then
            local rel="${file#${project_dir}/}"
            _bso_log warn "大きなバンドルファイル: ${rel} (${size_kb}KB)"
            large_files=$((large_files + 1))
        fi
    done < <(find "$project_dir" \( -path "*/.next/static/chunks/*.js" -o -path "*/dist/*.js" \) \
             -not -path "*/node_modules/*" -print0 2>/dev/null)

    BSO_GENERATED=$((BSO_GENERATED + 1))
    local mb=$((BSO_TOTAL_BUNDLE_KB / 1024))
    _bso_log ok "バンドル分析完了: 合計${mb}MB, 大きなファイル${large_files}個"

    echo "${BSO_TOTAL_BUNDLE_KB}"
    return 0
}

# =============================================================================
# _bso_find_large_deps - 大きな依存の特定
# =============================================================================
_bso_find_large_deps() {
    local project_dir="${1:-.}"
    local threshold_kb="${2:-$BSO_THRESHOLD_KB}"

    _bso_log info "大きな依存の特定 (閾値: ${threshold_kb}KB)"

    _BSO_DEP_SIZES=()
    BSO_LARGE_DEPS_COUNT=0

    local node_modules="${project_dir}/node_modules"
    [[ ! -d "$node_modules" ]] && { _bso_log warn "node_modules未検出"; return 1; }

    while IFS= read -r -d '' dep_dir; do
        local dep_name
        dep_name=$(basename "$dep_dir")
        [[ "$dep_name" == "."* ]] && continue

        local size_kb
        size_kb=$(du -sk "$dep_dir" 2>/dev/null | cut -f1 || echo 0)

        if [[ $size_kb -gt $threshold_kb ]]; then
            _BSO_DEP_SIZES["$dep_name"]="$size_kb"
            BSO_LARGE_DEPS_COUNT=$((BSO_LARGE_DEPS_COUNT + 1))

            local mb=$((size_kb / 1024))
            _bso_log warn "大きな依存: ${dep_name} (${mb}MB)"
        fi
    done < <(find "$node_modules" -maxdepth 1 -mindepth 1 -type d -print0 2>/dev/null)

    # @scope付きパッケージ
    while IFS= read -r -d '' scope_dir; do
        local scope
        scope=$(basename "$scope_dir")
        while IFS= read -r -d '' pkg_dir; do
            local pkg_name="${scope}/$(basename "$pkg_dir")"
            local size_kb
            size_kb=$(du -sk "$pkg_dir" 2>/dev/null | cut -f1 || echo 0)
            if [[ $size_kb -gt $threshold_kb ]]; then
                _BSO_DEP_SIZES["$pkg_name"]="$size_kb"
                BSO_LARGE_DEPS_COUNT=$((BSO_LARGE_DEPS_COUNT + 1))
            fi
        done < <(find "$scope_dir" -maxdepth 1 -mindepth 1 -type d -print0 2>/dev/null)
    done < <(find "$node_modules" -maxdepth 1 -mindepth 1 -name "@*" -type d -print0 2>/dev/null)

    BSO_GENERATED=$((BSO_GENERATED + 1))
    _bso_log ok "大きな依存: ${BSO_LARGE_DEPS_COUNT}個検出"

    return 0
}

# =============================================================================
# _bso_suggest_alternatives - 軽量代替の提案
# =============================================================================
_bso_suggest_alternatives() {
    local project_dir="${1:-.}"
    _bso_log info "軽量代替パッケージ提案"

    BSO_ALTERNATIVES_FOUND=0
    BSO_POTENTIAL_SAVINGS_KB=0

    local pkg_json="${project_dir}/package.json"
    [[ ! -f "$pkg_json" ]] && { _bso_log warn "package.json未検出"; return 1; }

    for dep in "${!_BSO_ALTERNATIVES[@]}"; do
        local found
        found=$(grep -c "\"${dep}\"" "$pkg_json" 2>/dev/null || echo 0)
        if [[ $found -gt 0 ]]; then
            local alt="${_BSO_ALTERNATIVES[$dep]}"
            local dep_size="${_BSO_DEP_SIZES[$dep]:-0}"

            BSO_ALTERNATIVES_FOUND=$((BSO_ALTERNATIVES_FOUND + 1))
            BSO_POTENTIAL_SAVINGS_KB=$((BSO_POTENTIAL_SAVINGS_KB + dep_size / 2))

            _bso_log warn "代替提案: ${dep} → ${alt}"
            echo "  ${dep} → ${alt} (現在${dep_size}KB)"
        fi
    done

    # tree-shakingの確認
    local has_sideeffects
    has_sideeffects=$(grep -c '"sideEffects"' "$pkg_json" 2>/dev/null || echo 0)
    if [[ $has_sideeffects -eq 0 ]]; then
        _bso_log warn "package.json: sideEffects: false 追加でtree-shaking改善"
    fi

    # dynamic import の提案
    local static_imports
    static_imports=$(grep -r "^import.*from" "${project_dir}/app/" "${project_dir}/src/" "${project_dir}/pages/" 2>/dev/null | \
                     grep -E "(chart|editor|markdown|highlight|pdf)" | wc -l || echo 0)
    if [[ $static_imports -gt 0 ]]; then
        _bso_log warn "重いライブラリを${static_imports}箇所で静的import: dynamic import推奨"
    fi

    BSO_GENERATED=$((BSO_GENERATED + 1))
    local savings_mb=$((BSO_POTENTIAL_SAVINGS_KB / 1024))
    _bso_log ok "代替提案: ${BSO_ALTERNATIVES_FOUND}件, 推定${savings_mb}MB削減可能"

    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_bso_report() {
    local mb=$((BSO_TOTAL_BUNDLE_KB / 1024))
    echo -e "\n  ${_BSO_BOLD}=== bundle-size-optimizer v${BSO_VERSION} ===${_BSO_NC}"
    echo -e "  総バンドルサイズ: ${mb}MB (${BSO_TOTAL_BUNDLE_KB}KB)"
    echo -e "  大きな依存      : ${BSO_LARGE_DEPS_COUNT}個"
    echo -e "  代替提案        : ${BSO_ALTERNATIVES_FOUND}件"
    echo -e "  削減可能        : $((BSO_POTENTIAL_SAVINGS_KB / 1024))MB"
    echo -e "  エラー          : ${BSO_ERRORS}"
}

_bso_score() {
    local score=50
    [[ ${BSO_TOTAL_BUNDLE_KB} -gt 0 ]] && score=$((score + 10))
    [[ ${BSO_LARGE_DEPS_COUNT} -gt 0 ]] && score=$((score + 10))
    [[ ${BSO_ALTERNATIVES_FOUND} -gt 0 ]] && score=$((score + 15))
    [[ ${BSO_POTENTIAL_SAVINGS_KB} -gt 0 ]] && score=$((score + 10))
    [[ ${BSO_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "bundle-size-optimizer" --version "${BSO_VERSION}" \
        --description "バンドルサイズ分析×大きな依存検出×軽量代替提案 (v431)" \
        --init "_bso_init" --report "_bso_report" --score "_bso_score" \
        --enable-var "ENABLE_BUNDLE_OPT" --cli-flags "--bundle-opt:--no-bundle-opt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
