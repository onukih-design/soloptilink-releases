#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v438.0 - Request Deduplication Engine
# =============================================================================
# 重複リクエスト検出・排除エンジン。同一APIへの重複呼び出しの検出、
# デデュプリケーション層の追加、インフライトキャッシュの実装を支援する。
#
# Functions:
#   _rd_init()                        - 初期化
#   _rd_detect_duplicate_requests()   - 重複リクエスト検出
#   _rd_add_dedup_layer()             - デデュプリケーション層追加
#   _rd_cache_inflight()              - インフライトキャッシュ設定
#   _rd_report() / _rd_score()
#
# All globals use the RD_ prefix.
# =============================================================================

[[ -n "${_RD_LOADED:-}" ]] && return 0; _RD_LOADED=1

declare -g RD_VERSION="438.0"
declare -g RD_GENERATED=0
declare -g RD_ERRORS=0
declare -g RD_DUPLICATES_FOUND=0
declare -g RD_DEDUP_ADDED=0
declare -g RD_INFLIGHT_CONFIGURED=false
declare -g RD_FILES_SCANNED=0

declare -ga _RD_FINDINGS=()

_RD_GREEN="${GREEN:-\033[0;32m}"
_RD_RED="${RED:-\033[0;31m}"
_RD_YELLOW="${YELLOW:-\033[0;33m}"
_RD_CYAN="${CYAN:-\033[0;36m}"
_RD_BOLD="${BOLD:-\033[1m}"
_RD_NC="${NC:-\033[0m}"

_rd_init() {
    RD_GENERATED=0; RD_ERRORS=0; RD_DUPLICATES_FOUND=0
    RD_DEDUP_ADDED=0; RD_INFLIGHT_CONFIGURED=false; RD_FILES_SCANNED=0
    _RD_FINDINGS=()
    return 0
}

_rd_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_RD_CYAN}[RD]${_RD_NC} $*" >&2 ;;
        ok)    echo -e "  ${_RD_GREEN}[RD]${_RD_NC} $*" >&2 ;;
        warn)  echo -e "  ${_RD_YELLOW}[RD]${_RD_NC} $*" >&2 ;;
        error) echo -e "  ${_RD_RED}[RD]${_RD_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _rd_detect_duplicate_requests - 重複リクエスト検出
# =============================================================================
_rd_detect_duplicate_requests() {
    local project_dir="${1:-.}"
    _rd_log info "重複リクエスト検出"

    RD_DUPLICATES_FOUND=0
    RD_FILES_SCANNED=0

    local -A api_calls=()

    # fetchとaxios呼び出しを収集
    while IFS= read -r -d '' file; do
        RD_FILES_SCANNED=$((RD_FILES_SCANNED + 1))
        local rel="${file#${project_dir}/}"

        # fetch URL抽出
        while IFS= read -r line; do
            local url=""
            if [[ "$line" =~ fetch\([\"\'](\/api[^\"\']+)[\"\'] ]]; then
                url="${BASH_REMATCH[1]}"
            elif [[ "$line" =~ fetch\(\`(\/api[^\`]+)\` ]]; then
                url="${BASH_REMATCH[1]}"
            elif [[ "$line" =~ axios\.(get|post|put|delete)\([\"\'](\/api[^\"\']+) ]]; then
                url="${BASH_REMATCH[2]}"
            fi

            if [[ -n "$url" ]]; then
                local key="${url}"
                local prev="${api_calls[$key]:-}"
                if [[ -n "$prev" ]] && [[ "$prev" != "$rel" ]]; then
                    RD_DUPLICATES_FOUND=$((RD_DUPLICATES_FOUND + 1))
                    _RD_FINDINGS+=("DUPLICATE:${url}:called in ${prev} and ${rel}")
                    _rd_log warn "重複API呼出: ${url} (${prev} & ${rel})"
                fi
                api_calls["$key"]="$rel"
            fi
        done < "$file"
    done < <(find "$project_dir" \( -name "*.tsx" -o -name "*.jsx" -o -name "*.ts" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" \
             -not -path "*/api/*" -print0 2>/dev/null)

    # useEffectでの重複fetch（同一コンポーネント内）
    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"
        local fetch_in_effect
        fetch_in_effect=$(grep -c "useEffect.*fetch\|fetch.*useEffect" "$file" 2>/dev/null || echo 0)

        if [[ $fetch_in_effect -gt 2 ]]; then
            RD_DUPLICATES_FOUND=$((RD_DUPLICATES_FOUND + 1))
            _RD_FINDINGS+=("EFFECT_FETCH:${rel}:${fetch_in_effect}x fetch in useEffect - consider SWR/React Query")
        fi
    done < <(find "$project_dir" \( -name "*.tsx" -o -name "*.jsx" \) \
             -not -path "*/node_modules/*" -print0 2>/dev/null)

    # SWR/React Query使用チェック
    local has_data_lib=false
    if [[ -f "${project_dir}/package.json" ]]; then
        if grep -qE '"swr"|"@tanstack/react-query"|"react-query"' "${project_dir}/package.json" 2>/dev/null; then
            has_data_lib=true
            _rd_log ok "データフェッチライブラリ検出: 自動デデュプリケーション有効"
        else
            _RD_FINDINGS+=("NO_DATA_LIB:install swr or @tanstack/react-query for automatic request deduplication")
        fi
    fi

    RD_GENERATED=$((RD_GENERATED + 1))
    _rd_log ok "重複検出: ${RD_DUPLICATES_FOUND}件 (${RD_FILES_SCANNED}ファイル)"
    return 0
}

# =============================================================================
# _rd_add_dedup_layer - デデュプリケーション層追加
# =============================================================================
_rd_add_dedup_layer() {
    local project_dir="${1:-.}"
    _rd_log info "デデュプリケーション層推奨"

    RD_DEDUP_ADDED=0

    # カスタムfetchラッパー推奨
    local snippet
    snippet=$(cat <<'DEDUP_SNIPPET'
// lib/api-client.ts - Request Deduplication Layer
const inflight = new Map<string, Promise<any>>();

export async function dedupFetch<T>(url: string, options?: RequestInit): Promise<T> {
  const key = `${options?.method || 'GET'}:${url}:${JSON.stringify(options?.body || '')}`;

  const existing = inflight.get(key);
  if (existing) return existing;

  const promise = fetch(url, options)
    .then(res => {
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.json() as Promise<T>;
    })
    .finally(() => {
      inflight.delete(key);
    });

  inflight.set(key, promise);
  return promise;
}
DEDUP_SNIPPET
)

    RD_DEDUP_ADDED=$((RD_DEDUP_ADDED + 1))
    _RD_FINDINGS+=("DEDUP_LAYER:recommended api-client.ts with request deduplication")

    # SWR設定推奨
    _RD_FINDINGS+=("SWR_CONFIG:SWRConfig dedupingInterval=2000 for automatic dedup")

    RD_GENERATED=$((RD_GENERATED + 1))
    _rd_log ok "デデュプリケーション層推奨: ${RD_DEDUP_ADDED}件"

    echo "$snippet"
    return 0
}

# =============================================================================
# _rd_cache_inflight - インフライトキャッシュ設定
# =============================================================================
_rd_cache_inflight() {
    local project_dir="${1:-.}"
    _rd_log info "インフライトキャッシュ設定"

    RD_INFLIGHT_CONFIGURED=false

    # Next.js fetch cacheチェック
    if [[ -f "${project_dir}/next.config.js" ]] || [[ -f "${project_dir}/next.config.mjs" ]]; then
        local has_fetch_cache
        has_fetch_cache=$(grep -r "cache:\|revalidate:" "${project_dir}/app/" 2>/dev/null | wc -l || echo 0)
        if [[ $has_fetch_cache -gt 0 ]]; then
            RD_INFLIGHT_CONFIGURED=true
            _rd_log ok "Next.js fetchキャッシュ設定済み"
        else
            _RD_FINDINGS+=("NEXT_CACHE:Add cache/revalidate options to server-side fetch calls")
        fi
    fi

    # API routeのキャッシュヘッダー
    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"
        local has_cache_header
        has_cache_header=$(grep -c "Cache-Control\|cache-control\|ETag\|etag" "$file" 2>/dev/null || echo 0)
        if [[ $has_cache_header -eq 0 ]]; then
            local is_get
            is_get=$(grep -c "GET" "$file" 2>/dev/null || echo 0)
            if [[ $is_get -gt 0 ]]; then
                _RD_FINDINGS+=("NO_CACHE_HEADER:${rel}:GET endpoint without Cache-Control header")
            fi
        fi
    done < <(find "$project_dir" -name "route.ts" -path "*/api/*" \
             -not -path "*/node_modules/*" -print0 2>/dev/null)

    RD_GENERATED=$((RD_GENERATED + 1))
    _rd_log ok "インフライトキャッシュ: configured=${RD_INFLIGHT_CONFIGURED}"
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_rd_report() {
    echo -e "\n  ${_RD_BOLD}=== request-deduplication v${RD_VERSION} ===${_RD_NC}"
    echo -e "  走査ファイル    : ${RD_FILES_SCANNED}"
    echo -e "  重複リクエスト  : ${RD_DUPLICATES_FOUND}"
    echo -e "  デデュプ層追加  : ${RD_DEDUP_ADDED}"
    echo -e "  インフライト    : ${RD_INFLIGHT_CONFIGURED}"
    echo -e "  エラー          : ${RD_ERRORS}"
}

_rd_score() {
    local score=50
    [[ ${RD_FILES_SCANNED} -gt 0 ]] && score=$((score + 10))
    [[ ${RD_DUPLICATES_FOUND} -eq 0 ]] && score=$((score + 15))
    [[ ${RD_DEDUP_ADDED} -gt 0 ]] && score=$((score + 10))
    [[ "$RD_INFLIGHT_CONFIGURED" == "true" ]] && score=$((score + 10))
    [[ ${RD_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "request-deduplication" --version "${RD_VERSION}" \
        --description "リクエスト重複排除×インフライトキャッシュ×SWR推奨 (v438)" \
        --init "_rd_init" --report "_rd_report" --score "_rd_score" \
        --enable-var "ENABLE_REQ_DEDUP" --cli-flags "--req-dedup:--no-req-dedup"
fi

# v2003.1: source時のexit codeを確実に0にする
true
