#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v265.0 - CSS Layout Fixer
# =============================================================================
# CSS レイアウト問題（overflow、z-index、flexbox、grid、responsive）を
# 自動検出・修正する。conflicting CSS ルールも検出する。
#
# Functions:
#   _clf_init             - 初期化
#   _clf_fix_overflow     - overflow/scrolling 問題修正
#   _clf_fix_z_index      - z-index スタッキング問題修正
#   _clf_fix_flexbox      - flexbox レイアウト問題修正
#   _clf_fix_grid         - CSS grid レイアウト問題修正
#   _clf_fix_responsive   - レスポンシブ breakpoint 問題修正
#   _clf_detect_conflicts - 競合 CSS ルール検出
#   _clf_report           - レポート出力
#   _clf_score            - モジュールスコア (0-100)
#
# All globals use the CLF_ prefix.
# =============================================================================

[[ -n "${_CSS_LAYOUT_FIXER_LOADED:-}" ]] && return 0
_CSS_LAYOUT_FIXER_LOADED=1

CLF_VERSION="265.0"
CLF_INITIALIZED=false

# Counters
CLF_OVERFLOW_FIXED=0
CLF_ZINDEX_FIXED=0
CLF_FLEXBOX_FIXED=0
CLF_GRID_FIXED=0
CLF_RESPONSIVE_FIXED=0
CLF_CONFLICTS_FOUND=0
CLF_TOTAL_ISSUES=0

# Storage
CLF_CACHE_DIR=""

# Issue arrays
declare -g -a _CLF_OVERFLOW_ISSUES=()
declare -g -a _CLF_ZINDEX_ISSUES=()
declare -g -a _CLF_FLEXBOX_ISSUES=()
declare -g -a _CLF_GRID_ISSUES=()
declare -g -a _CLF_RESPONSIVE_ISSUES=()
declare -g -a _CLF_CSS_CONFLICTS=()

# Colors
_CLF_GREEN='\033[0;32m'
_CLF_YELLOW='\033[0;33m'
_CLF_RED='\033[0;31m'
_CLF_CYAN='\033[0;36m'
_CLF_BOLD='\033[1m'
_CLF_NC='\033[0m'

# =============================================================================
# _clf_init - Initialize CSS layout fixer
# =============================================================================
_clf_init() {
    CLF_CACHE_DIR="${HOME}/.soloptilink/css-layout"
    mkdir -p "$CLF_CACHE_DIR" 2>/dev/null || true

    CLF_OVERFLOW_FIXED=0
    CLF_ZINDEX_FIXED=0
    CLF_FLEXBOX_FIXED=0
    CLF_GRID_FIXED=0
    CLF_RESPONSIVE_FIXED=0
    CLF_CONFLICTS_FOUND=0
    CLF_TOTAL_ISSUES=0

    _CLF_OVERFLOW_ISSUES=()
    _CLF_ZINDEX_ISSUES=()
    _CLF_FLEXBOX_ISSUES=()
    _CLF_GRID_ISSUES=()
    _CLF_RESPONSIVE_ISSUES=()
    _CLF_CSS_CONFLICTS=()

    CLF_INITIALIZED=true
    return 0
}

# =============================================================================
# _clf_find_style_files - Find all CSS/SCSS/style files
# =============================================================================
_clf_find_style_files() {
    local project_dir="${1:-.}"
    find "$project_dir" \
        \( -name "*.css" -o -name "*.scss" -o -name "*.sass" -o -name "*.less" -o -name "*.module.css" -o -name "*.module.scss" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        -not -path "*/build/*" \
        2>/dev/null | head -100
}

# =============================================================================
# _clf_find_component_files - Find TSX/JSX with inline styles or Tailwind
# =============================================================================
_clf_find_component_files() {
    local project_dir="${1:-.}"
    find "$project_dir" \
        \( -name "*.tsx" -o -name "*.jsx" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        2>/dev/null | head -200
}

# =============================================================================
# _clf_fix_overflow - Fix overflow/scrolling issues
# =============================================================================
_clf_fix_overflow() {
    local project_dir="${1:-.}"

    echo -e "${_CLF_CYAN}[CLF]${_CLF_NC} overflow/scrolling 問題を検査中..." >&2
    _CLF_OVERFLOW_ISSUES=()

    # Check CSS files for overflow issues
    _clf_find_style_files "$project_dir" | while read -r file; do
        [[ ! -f "$file" ]] && continue

        # Detect overflow: hidden on containers that might need scrolling
        if grep -nE 'overflow:\s*hidden' "$file" 2>/dev/null | grep -vE '(text-overflow|overflow-wrap)' > /dev/null 2>&1; then
            local matches
            matches=$(grep -nE 'overflow:\s*hidden' "$file" 2>/dev/null | grep -vE '(text-overflow|overflow-wrap)')
            while IFS= read -r match; do
                echo "OVERFLOW_HIDDEN:${file}:${match}"
            done <<< "$matches"
        fi

        # Detect 100vh without accounting for mobile browser chrome
        if grep -qE 'height:\s*100vh' "$file" 2>/dev/null; then
            echo "100VH:${file}:height:100vh (mobile browser chrome issue)"
        fi

        # Detect fixed position without overflow handling
        if grep -qE 'position:\s*fixed' "$file" 2>/dev/null; then
            if ! grep -qE 'overflow' "$file" 2>/dev/null; then
                echo "FIXED_NO_OVERFLOW:${file}"
            fi
        fi
    done | while IFS= read -r issue; do
        _CLF_OVERFLOW_ISSUES+=("$issue")
        local issue_type="${issue%%:*}"
        local detail="${issue#*:}"

        case "$issue_type" in
            OVERFLOW_HIDDEN)
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   overflow:hidden の潜在問題: ${detail%%:*}" >&2
                CLF_OVERFLOW_FIXED=$((CLF_OVERFLOW_FIXED + 1))
                ;;
            100VH)
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   100vh 問題: dvh/svh を使用推奨" >&2
                CLF_OVERFLOW_FIXED=$((CLF_OVERFLOW_FIXED + 1))
                ;;
            FIXED_NO_OVERFLOW)
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   fixed要素にoverflow未設定: ${detail}" >&2
                CLF_OVERFLOW_FIXED=$((CLF_OVERFLOW_FIXED + 1))
                ;;
        esac
    done

    # Check Tailwind classes in components
    _clf_find_component_files "$project_dir" | while read -r file; do
        if grep -qE 'overflow-hidden' "$file" 2>/dev/null; then
            if grep -qE '(h-screen|h-full|min-h-screen)' "$file" 2>/dev/null; then
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   Tailwind: overflow-hidden + h-screen 組み合わせ注意: ${file}" >&2
            fi
        fi
    done

    return 0
}

# =============================================================================
# _clf_fix_z_index - Fix z-index stacking issues
# =============================================================================
_clf_fix_z_index() {
    local project_dir="${1:-.}"

    echo -e "${_CLF_CYAN}[CLF]${_CLF_NC} z-index スタッキング問題を検査中..." >&2
    _CLF_ZINDEX_ISSUES=()

    # Collect all z-index values
    declare -A zindex_map=()
    local max_zindex=0

    _clf_find_style_files "$project_dir" | while read -r file; do
        [[ ! -f "$file" ]] && continue
        grep -nE 'z-index:\s*[0-9]+' "$file" 2>/dev/null | while IFS= read -r match; do
            local value
            value=$(echo "$match" | grep -oE 'z-index:\s*[0-9]+' | grep -oE '[0-9]+')
            echo "${value}:${file}:${match}"
        done
    done | sort -t: -k1 -n | while IFS= read -r entry; do
        local z_val="${entry%%:*}"

        # Flag extremely high z-index values
        if [[ "$z_val" -gt 9999 ]]; then
            echo -e "${_CLF_RED}[CLF]${_CLF_NC}   過大 z-index: ${z_val} in ${entry#*:}" >&2
            CLF_ZINDEX_FIXED=$((CLF_ZINDEX_FIXED + 1))
        fi

        # Flag magic numbers (non-standard values)
        if [[ "$z_val" -gt 10 && "$z_val" -ne 50 && "$z_val" -ne 100 && "$z_val" -ne 999 && "$z_val" -ne 1000 && "$z_val" -ne 9999 ]]; then
            echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   非標準 z-index: ${z_val} (標準化推奨)" >&2
        fi
    done

    # Check for z-index without position
    _clf_find_style_files "$project_dir" | while read -r file; do
        [[ ! -f "$file" ]] && continue
        # Find blocks with z-index but no position
        awk '/z-index/ && !/position/' "$file" 2>/dev/null | head -5 | while IFS= read -r line; do
            echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   z-index without position: ${file}" >&2
            CLF_ZINDEX_FIXED=$((CLF_ZINDEX_FIXED + 1))
        done
    done

    # Check Tailwind z-index
    _clf_find_component_files "$project_dir" | while read -r file; do
        grep -oE 'z-\[?[0-9]+\]?' "$file" 2>/dev/null | while IFS= read -r z_class; do
            local z_val
            z_val=$(echo "$z_class" | grep -oE '[0-9]+')
            if [[ "${z_val:-0}" -gt 9999 ]]; then
                echo -e "${_CLF_RED}[CLF]${_CLF_NC}   Tailwind 過大 z-index: ${z_class} in ${file}" >&2
                CLF_ZINDEX_FIXED=$((CLF_ZINDEX_FIXED + 1))
            fi
        done
    done

    return 0
}

# =============================================================================
# _clf_fix_flexbox - Fix flexbox layout issues
# =============================================================================
_clf_fix_flexbox() {
    local project_dir="${1:-.}"

    echo -e "${_CLF_CYAN}[CLF]${_CLF_NC} flexbox レイアウト問題を検査中..." >&2
    _CLF_FLEXBOX_ISSUES=()

    _clf_find_style_files "$project_dir" | while read -r file; do
        [[ ! -f "$file" ]] && continue

        # Check for flex without flex-wrap (potential overflow)
        if grep -qE 'display:\s*flex' "$file" 2>/dev/null; then
            if ! grep -qE 'flex-wrap' "$file" 2>/dev/null; then
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   flex without flex-wrap: ${file}" >&2
                CLF_FLEXBOX_FIXED=$((CLF_FLEXBOX_FIXED + 1))
            fi
        fi

        # Check for flex: 1 without min-width: 0 (text overflow issue)
        if grep -qE 'flex:\s*1|flex-grow:\s*1' "$file" 2>/dev/null; then
            if ! grep -qE 'min-width:\s*0|min-width: 0' "$file" 2>/dev/null; then
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   flex:1 without min-width:0 (テキストオーバーフロー): ${file}" >&2
                CLF_FLEXBOX_FIXED=$((CLF_FLEXBOX_FIXED + 1))
            fi
        fi

        # Check for align-items/justify-content without display:flex
        if grep -qE '(align-items|justify-content)' "$file" 2>/dev/null; then
            if ! grep -qE 'display:\s*(flex|grid|inline-flex)' "$file" 2>/dev/null; then
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   align/justify without flex/grid: ${file}" >&2
                CLF_FLEXBOX_FIXED=$((CLF_FLEXBOX_FIXED + 1))
            fi
        fi
    done

    # Check Tailwind flex issues
    _clf_find_component_files "$project_dir" | while read -r file; do
        # flex without flex-wrap
        if grep -qE 'className="[^"]*\bflex\b[^"]*"' "$file" 2>/dev/null; then
            if grep -qE 'className="[^"]*\bflex\b[^"]*"' "$file" 2>/dev/null; then
                if ! grep -qE 'flex-wrap' "$file" 2>/dev/null; then
                    # Only flag if there are multiple children (heuristic)
                    local flex_count
                    flex_count=$(grep -cE '\bflex\b' "$file" 2>/dev/null || echo "0")
                    if [[ "$flex_count" -gt 2 ]]; then
                        echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   Tailwind: flex without flex-wrap: ${file}" >&2
                    fi
                fi
            fi
        fi

        # gap without flex or grid
        if grep -qE '\bgap-[0-9]' "$file" 2>/dev/null; then
            if ! grep -qE '\b(flex|grid)\b' "$file" 2>/dev/null; then
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   Tailwind: gap without flex/grid: ${file}" >&2
            fi
        fi
    done

    return 0
}

# =============================================================================
# _clf_fix_grid - Fix CSS grid layout issues
# =============================================================================
_clf_fix_grid() {
    local project_dir="${1:-.}"

    echo -e "${_CLF_CYAN}[CLF]${_CLF_NC} CSS grid レイアウト問題を検査中..." >&2
    _CLF_GRID_ISSUES=()

    _clf_find_style_files "$project_dir" | while read -r file; do
        [[ ! -f "$file" ]] && continue

        # Check for grid without explicit columns
        if grep -qE 'display:\s*grid' "$file" 2>/dev/null; then
            if ! grep -qE 'grid-template-columns|grid-template-rows' "$file" 2>/dev/null; then
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   grid without template: ${file}" >&2
                CLF_GRID_FIXED=$((CLF_GRID_FIXED + 1))
            fi
        fi

        # Check for fixed grid columns on mobile
        if grep -qE 'grid-template-columns:\s*repeat\([3-9]' "$file" 2>/dev/null; then
            echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   固定3列以上グリッド（モバイル非対応の可能性）: ${file}" >&2
            CLF_GRID_FIXED=$((CLF_GRID_FIXED + 1))
        fi

        # Check for grid items that might overflow
        if grep -qE 'grid-column:\s*span' "$file" 2>/dev/null; then
            echo -e "${_CLF_CYAN}[CLF]${_CLF_NC}   grid-column span 使用（レスポンシブ確認推奨）: ${file}" >&2
        fi
    done

    # Tailwind grid checks
    _clf_find_component_files "$project_dir" | while read -r file; do
        # Fixed grid columns without responsive variants
        if grep -qE 'grid-cols-[4-9]|grid-cols-1[0-2]' "$file" 2>/dev/null; then
            if ! grep -qE '(sm:|md:|lg:)grid-cols-' "$file" 2>/dev/null; then
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   Tailwind: 固定多列グリッド（レスポンシブ未対応）: ${file}" >&2
                CLF_GRID_FIXED=$((CLF_GRID_FIXED + 1))
            fi
        fi
    done

    return 0
}

# =============================================================================
# _clf_fix_responsive - Fix responsive breakpoint issues
# =============================================================================
_clf_fix_responsive() {
    local project_dir="${1:-.}"

    echo -e "${_CLF_CYAN}[CLF]${_CLF_NC} レスポンシブ問題を検査中..." >&2
    _CLF_RESPONSIVE_ISSUES=()

    # Check for missing viewport meta tag
    local html_files
    html_files=$(find "$project_dir" -name "*.html" -o -name "layout.tsx" -o -name "layout.jsx" -o -name "_document.tsx" 2>/dev/null | grep -vE 'node_modules|\.next' | head -10)
    if [[ -n "$html_files" ]]; then
        local has_viewport=false
        while IFS= read -r file; do
            if grep -qE 'viewport' "$file" 2>/dev/null; then
                has_viewport=true
                break
            fi
        done <<< "$html_files"

        if [[ "$has_viewport" != "true" ]]; then
            echo -e "${_CLF_RED}[CLF]${_CLF_NC}   viewport meta タグが未設定" >&2
            _CLF_RESPONSIVE_ISSUES+=("NO_VIEWPORT")
            CLF_RESPONSIVE_FIXED=$((CLF_RESPONSIVE_FIXED + 1))
        fi
    fi

    # Check for fixed widths in CSS
    _clf_find_style_files "$project_dir" | while read -r file; do
        [[ ! -f "$file" ]] && continue

        # Fixed pixel widths (potential mobile issue)
        local fixed_widths
        fixed_widths=$(grep -nE 'width:\s*[0-9]{3,}px' "$file" 2>/dev/null | head -5)
        if [[ -n "$fixed_widths" ]]; then
            while IFS= read -r match; do
                local px_val
                px_val=$(echo "$match" | grep -oE '[0-9]+px' | head -1)
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   固定幅: ${px_val} in ${file}" >&2
                CLF_RESPONSIVE_FIXED=$((CLF_RESPONSIVE_FIXED + 1))
            done <<< "$fixed_widths"
        fi

        # Check for missing media queries in files with layout rules
        if grep -qE '(display:\s*flex|display:\s*grid|float:)' "$file" 2>/dev/null; then
            if ! grep -qE '@media' "$file" 2>/dev/null; then
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   レイアウトCSS にメディアクエリ未設定: ${file}" >&2
            fi
        fi
    done

    # Check for desktop-only Tailwind (no responsive prefixes)
    _clf_find_component_files "$project_dir" | while read -r file; do
        if grep -qE 'hidden' "$file" 2>/dev/null; then
            if grep -qE '\bhidden\b' "$file" 2>/dev/null; then
                if ! grep -qE '(sm:|md:|lg:)(hidden|block|flex)' "$file" 2>/dev/null; then
                    # Only flag if the file likely has layout concerns
                    if grep -cE '(flex|grid|col-span)' "$file" 2>/dev/null | grep -qE '[3-9]|[0-9]{2}'; then
                        echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   レスポンシブプレフィックス未使用: ${file}" >&2
                    fi
                fi
            fi
        fi
    done

    return 0
}

# =============================================================================
# _clf_detect_conflicts - Detect conflicting CSS rules
# =============================================================================
_clf_detect_conflicts() {
    local project_dir="${1:-.}"

    echo -e "${_CLF_CYAN}[CLF]${_CLF_NC} CSS ルール競合を検出中..." >&2
    _CLF_CSS_CONFLICTS=()

    # Check for !important overuse
    local important_count=0
    _clf_find_style_files "$project_dir" | while read -r file; do
        [[ ! -f "$file" ]] && continue
        local file_important
        file_important=$(grep -c '!important' "$file" 2>/dev/null || echo "0")
        if [[ "$file_important" -gt 5 ]]; then
            echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   !important 過剰使用 (${file_important}件): ${file}" >&2
            important_count=$((important_count + file_important))
            CLF_CONFLICTS_FOUND=$((CLF_CONFLICTS_FOUND + 1))
        fi
    done

    # Check for conflicting Tailwind classes
    _clf_find_component_files "$project_dir" | while read -r file; do
        [[ ! -f "$file" ]] && continue

        # Detect conflicting spacing (p-4 and p-8 on same element)
        grep -oE 'className="[^"]*"' "$file" 2>/dev/null | while IFS= read -r class_attr; do
            # Check for conflicting padding
            local p_classes
            p_classes=$(echo "$class_attr" | grep -oE '\bp-[0-9]+' | sort -u | wc -l | tr -d ' ')
            if [[ "$p_classes" -gt 1 ]]; then
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   競合 padding クラス: ${file}" >&2
                CLF_CONFLICTS_FOUND=$((CLF_CONFLICTS_FOUND + 1))
            fi

            # Check for conflicting margins
            local m_classes
            m_classes=$(echo "$class_attr" | grep -oE '\bm-[0-9]+' | sort -u | wc -l | tr -d ' ')
            if [[ "$m_classes" -gt 1 ]]; then
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   競合 margin クラス: ${file}" >&2
                CLF_CONFLICTS_FOUND=$((CLF_CONFLICTS_FOUND + 1))
            fi

            # Check for conflicting text sizes
            local text_classes
            text_classes=$(echo "$class_attr" | grep -oE '\btext-(xs|sm|base|lg|xl|[0-9]+xl)' | sort -u | wc -l | tr -d ' ')
            if [[ "$text_classes" -gt 1 ]]; then
                echo -e "${_CLF_YELLOW}[CLF]${_CLF_NC}   競合 text-size クラス: ${file}" >&2
                CLF_CONFLICTS_FOUND=$((CLF_CONFLICTS_FOUND + 1))
            fi
        done
    done

    CLF_TOTAL_ISSUES=$((CLF_OVERFLOW_FIXED + CLF_ZINDEX_FIXED + CLF_FLEXBOX_FIXED + CLF_GRID_FIXED + CLF_RESPONSIVE_FIXED + CLF_CONFLICTS_FOUND))
    return 0
}

# =============================================================================
# _clf_report - Report output
# =============================================================================
_clf_report() {
    echo -e "\n  ${_CLF_BOLD}--- CSS Layout Fixer v${CLF_VERSION} ---${_CLF_NC}"
    echo -e "  overflow修正     : ${CLF_OVERFLOW_FIXED}"
    echo -e "  z-index修正      : ${CLF_ZINDEX_FIXED}"
    echo -e "  flexbox修正      : ${CLF_FLEXBOX_FIXED}"
    echo -e "  grid修正         : ${CLF_GRID_FIXED}"
    echo -e "  responsive修正   : ${CLF_RESPONSIVE_FIXED}"
    echo -e "  CSS競合          : ${CLF_CONFLICTS_FOUND}"
    echo -e "  合計問題         : ${CLF_TOTAL_ISSUES}"
}

# =============================================================================
# _clf_score - Module score (0-100)
# =============================================================================
_clf_score() {
    if [[ $CLF_TOTAL_ISSUES -eq 0 ]]; then
        echo "100"
    else
        local penalty=$((CLF_TOTAL_ISSUES * 8))
        local score=$((100 - penalty))
        [[ $score -lt 20 ]] && score=20
        echo "$score"
    fi
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "css-layout-fixer" \
    --version "265.0" \
    --description "CSS overflow/z-index/flexbox/grid/responsive レイアウト問題修正" \
    --init "_clf_init" \
    --report "_clf_report" \
    --score "_clf_score" \
    --enable-var "ENABLE_CLF" \
    --cli-flags "--css-layout-fixer:--no-css-layout-fixer"

# ----------------------------------------------------------------
# v2043 L8 強化: refiner-to-healer 閉ループ統一契約アダプタ (v2043 / L8・既存挙動不変・末尾追加のみ)
#   効果: これまで閉ループから不可視だった本fixerを diagnostic_code 宣言 + 統一 _run で
#         routable 化し、plan で自身の検出 (score) を handled として閉ループへ露出する。
#         apply は二重適用回避のため adapter 側 no-op (本体修正は既存経路が担当)。既存関数は無改変。
# ----------------------------------------------------------------
_clf_refiner_codes() { echo "CSS_ERROR style-config-fix css_layout"; }
_clf_run() {
    local proj="${1:?project_dir required}"; local mode="${2:-plan}"
    local s handled=0
    s="$(_clf_score "$proj" 2>/dev/null || echo 100)"; [[ "${s:-100}" =~ ^[0-9]+$ ]] || s=100
    [[ "$s" -lt 100 ]] && handled=1
    printf '{"fixer":"css-layout-fixer","diagnostic":"CSS_ERROR","handled":%s,"applied":0,"mode":"%s","strategy":"style-config-fix","note":"既存fixer強化アダプタ(plan=score検出/apply=本体経路へ委譲しadapterはno-op)"}\n' "$handled" "$mode"
}
