#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v469.0 - Performance Report Generator
# =============================================================================
# パフォーマンスレポート生成: メトリクス収集、HTMLレポート、改善提案。
#
# Functions:
#   _prgen_init()                     - Initialize
#   _prgen_collect_metrics()          - Collect performance metrics
#   _prgen_generate_html()            - Generate HTML report
#   _prgen_generate_recommendations() - Generate improvement recommendations
#   _prgen_report() / _prgen_score()
# =============================================================================

[[ -n "${_PRGEN_LOADED:-}" ]] && return 0; _PRGEN_LOADED=1

declare -g PRGEN_VERSION="469.0"
PRGEN_GENERATED=0; PRGEN_ERRORS=0; PRGEN_FILES_WRITTEN=0
PRGEN_METRICS_OK=false; PRGEN_HTML_OK=false; PRGEN_RECOMMENDATIONS_OK=false

_prgen_init() {
    PRGEN_GENERATED=0; PRGEN_ERRORS=0; PRGEN_FILES_WRITTEN=0
    PRGEN_METRICS_OK=false; PRGEN_HTML_OK=false; PRGEN_RECOMMENDATIONS_OK=false
    return 0
}

_prgen_log() { echo -e "  ${CYAN:-\033[0;36m}[perf-report]${NC:-\033[0m} $*" >&2; }
_prgen_ok()  { echo -e "  ${GREEN:-\033[0;32m}✅ [perf-report]${NC:-\033[0m} $*" >&2; }
_prgen_err() { echo -e "  ${RED:-\033[0;31m}❌ [perf-report]${NC:-\033[0m} $*" >&2; PRGEN_ERRORS=$((PRGEN_ERRORS + 1)); }

_prgen_write_file() {
    local filepath="$1" content="$2"
    local dir; dir="$(dirname "$filepath")"
    [[ -d "$dir" ]] || mkdir -p "$dir"
    echo "$content" > "$filepath" 2>/dev/null || { _prgen_err "Failed to write $filepath"; return 1; }
    PRGEN_FILES_WRITTEN=$((PRGEN_FILES_WRITTEN + 1))
    return 0
}

_prgen_collect_metrics() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/perf-report/metrics-collector.ts"
    _prgen_log "Generating metrics collector..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v469.0 - Performance Metrics Collector

export interface PerformanceMetrics {
  webVitals: { lcp: number; fid: number; cls: number; ttfb: number; fcp: number; inp: number };
  bundle: { totalSizeBytes: number; jsSizeBytes: number; cssSizeBytes: number; imageSizeBytes: number; chunkCount: number };
  api: { avgLatencyMs: number; p95LatencyMs: number; p99LatencyMs: number; errorRate: number; requestsPerMinute: number };
  database: { avgQueryMs: number; slowQueries: number; connectionPoolUsage: number; totalQueries: number };
  runtime: { memoryUsageMb: number; cpuUsagePercent: number; eventLoopDelayMs: number; gcPauseMs: number };
  timestamp: number;
}

export class MetricsCollector {
  private history: PerformanceMetrics[] = [];
  private readonly maxHistory = 100;

  record(metrics: PerformanceMetrics): void {
    this.history.push(metrics);
    if (this.history.length > this.maxHistory) this.history.shift();
  }

  getLatest(): PerformanceMetrics | null {
    return this.history[this.history.length - 1] ?? null;
  }

  getHistory(count?: number): PerformanceMetrics[] {
    return count ? this.history.slice(-count) : [...this.history];
  }

  calculateTrends(): Record<string, 'improving' | 'stable' | 'degrading'> {
    if (this.history.length < 3) return {};
    const recent = this.history.slice(-5);
    const older = this.history.slice(-10, -5);
    if (older.length === 0) return {};

    const avgRecent = recent.reduce((sum, m) => sum + m.webVitals.lcp, 0) / recent.length;
    const avgOlder = older.reduce((sum, m) => sum + m.webVitals.lcp, 0) / older.length;
    const delta = ((avgRecent - avgOlder) / avgOlder) * 100;

    return {
      lcp: delta < -5 ? 'improving' : delta > 5 ? 'degrading' : 'stable',
      overall: delta < -5 ? 'improving' : delta > 5 ? 'degrading' : 'stable',
    };
  }

  getScorecard(): { score: number; grade: string; details: Record<string, string> } {
    const latest = this.getLatest();
    if (!latest) return { score: 0, grade: 'N/A', details: {} };
    let score = 100;
    const details: Record<string, string> = {};
    if (latest.webVitals.lcp > 2500) { score -= 15; details.lcp = 'Needs improvement'; }
    if (latest.webVitals.fid > 100) { score -= 10; details.fid = 'Needs improvement'; }
    if (latest.webVitals.cls > 0.1) { score -= 10; details.cls = 'Needs improvement'; }
    if (latest.api.p95LatencyMs > 500) { score -= 15; details.api = 'Slow API responses'; }
    if (latest.bundle.totalSizeBytes > 500000) { score -= 10; details.bundle = 'Large bundle'; }
    const grade = score >= 90 ? 'A' : score >= 80 ? 'B' : score >= 70 ? 'C' : score >= 60 ? 'D' : 'F';
    return { score, grade, details };
  }
}

export const metricsCollector = new MetricsCollector();
TYPESCRIPT
)
    _prgen_write_file "$outfile" "$content" || return 1
    PRGEN_METRICS_OK=true
    PRGEN_GENERATED=$((PRGEN_GENERATED + 1))
    _prgen_ok "Metrics collector generated"
    return 0
}

_prgen_generate_html() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/perf-report/html-generator.ts"
    _prgen_log "Generating HTML report generator..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v469.0 - Performance HTML Report Generator

import type { PerformanceMetrics } from './metrics-collector';

export class HTMLReportGenerator {
  generate(metrics: PerformanceMetrics, title = 'Performance Report'): string {
    const scorecard = this.getGrade(metrics);
    return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}body{font-family:system-ui,-apple-system,sans-serif;background:#f8fafc;color:#334155;padding:2rem}
.container{max-width:1200px;margin:0 auto}.header{text-align:center;margin-bottom:2rem}
.grade{font-size:4rem;font-weight:bold;color:${scorecard.color}}.score{font-size:1.5rem;color:#64748b}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:1.5rem}
.card{background:white;border-radius:12px;padding:1.5rem;box-shadow:0 1px 3px rgba(0,0,0,0.1)}
.card h3{font-size:1rem;color:#64748b;margin-bottom:1rem}.metric{display:flex;justify-content:space-between;padding:0.5rem 0;border-bottom:1px solid #f1f5f9}
.metric-name{font-weight:500}.metric-value{font-weight:bold}.good{color:#22c55e}.warn{color:#f59e0b}.bad{color:#ef4444}
</style></head>
<body><div class="container">
<div class="header"><h1>${title}</h1><div class="grade">${scorecard.grade}</div><div class="score">Score: ${scorecard.score}/100</div><p>${new Date(metrics.timestamp).toLocaleString()}</p></div>
<div class="grid">
<div class="card"><h3>Web Vitals</h3>
${this.metricRow('LCP', metrics.webVitals.lcp, 'ms', 2500, 4000)}
${this.metricRow('FID', metrics.webVitals.fid, 'ms', 100, 300)}
${this.metricRow('CLS', metrics.webVitals.cls, '', 0.1, 0.25)}
${this.metricRow('TTFB', metrics.webVitals.ttfb, 'ms', 200, 600)}
${this.metricRow('FCP', metrics.webVitals.fcp, 'ms', 1800, 3000)}
</div>
<div class="card"><h3>API Performance</h3>
${this.metricRow('Avg Latency', metrics.api.avgLatencyMs, 'ms', 200, 500)}
${this.metricRow('P95 Latency', metrics.api.p95LatencyMs, 'ms', 500, 1000)}
${this.metricRow('Error Rate', metrics.api.errorRate * 100, '%', 1, 5)}
</div>
<div class="card"><h3>Bundle Size</h3>
${this.metricRow('Total', Math.round(metrics.bundle.totalSizeBytes / 1024), 'KB', 300, 500)}
${this.metricRow('JavaScript', Math.round(metrics.bundle.jsSizeBytes / 1024), 'KB', 200, 400)}
${this.metricRow('Chunks', metrics.bundle.chunkCount, '', 20, 50)}
</div>
<div class="card"><h3>Database</h3>
${this.metricRow('Avg Query', metrics.database.avgQueryMs, 'ms', 50, 200)}
${this.metricRow('Slow Queries', metrics.database.slowQueries, '', 5, 20)}
${this.metricRow('Pool Usage', metrics.database.connectionPoolUsage * 100, '%', 70, 90)}
</div>
</div></div></body></html>`;
  }

  private metricRow(name: string, value: number, unit: string, good: number, bad: number): string {
    const cls = value <= good ? 'good' : value <= bad ? 'warn' : 'bad';
    return `<div class="metric"><span class="metric-name">${name}</span><span class="metric-value ${cls}">${typeof value === 'number' ? value.toFixed(value < 1 ? 3 : 0) : value}${unit}</span></div>`;
  }

  private getGrade(metrics: PerformanceMetrics): { grade: string; score: number; color: string } {
    let score = 100;
    if (metrics.webVitals.lcp > 2500) score -= 15;
    if (metrics.webVitals.fid > 100) score -= 10;
    if (metrics.webVitals.cls > 0.1) score -= 10;
    if (metrics.api.p95LatencyMs > 500) score -= 15;
    if (metrics.bundle.totalSizeBytes > 500000) score -= 10;
    const grade = score >= 90 ? 'A' : score >= 80 ? 'B' : score >= 70 ? 'C' : score >= 60 ? 'D' : 'F';
    const color = score >= 90 ? '#22c55e' : score >= 70 ? '#f59e0b' : '#ef4444';
    return { grade, score, color };
  }
}

export const htmlReportGenerator = new HTMLReportGenerator();
TYPESCRIPT
)
    _prgen_write_file "$outfile" "$content" || return 1
    PRGEN_HTML_OK=true
    PRGEN_GENERATED=$((PRGEN_GENERATED + 1))
    _prgen_ok "HTML report generator generated"
    return 0
}

_prgen_generate_recommendations() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/perf-report/recommendation-engine.ts"
    _prgen_log "Generating recommendation engine..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v469.0 - Performance Recommendation Engine

import type { PerformanceMetrics } from './metrics-collector';

export interface Recommendation {
  id: string;
  metric: string;
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  effort: 'low' | 'medium' | 'high';
  actionItems: string[];
}

export class RecommendationEngine {
  analyze(metrics: PerformanceMetrics): Recommendation[] {
    const recs: Recommendation[] = [];
    if (metrics.webVitals.lcp > 2500) {
      recs.push({ id: 'lcp-optimize', metric: 'LCP', title: 'Optimize Largest Contentful Paint', description: `Current LCP: ${metrics.webVitals.lcp}ms (target: <2500ms)`, impact: 'high', effort: 'medium',
        actionItems: ['Preload hero images', 'Use next/image with priority', 'Enable streaming SSR', 'Minimize render-blocking resources'] });
    }
    if (metrics.webVitals.cls > 0.1) {
      recs.push({ id: 'cls-fix', metric: 'CLS', title: 'Reduce Layout Shifts', description: `Current CLS: ${metrics.webVitals.cls} (target: <0.1)`, impact: 'high', effort: 'low',
        actionItems: ['Add explicit width/height to images', 'Reserve space for dynamic content', 'Avoid inserting content above fold', 'Use font-display: swap'] });
    }
    if (metrics.bundle.totalSizeBytes > 400000) {
      recs.push({ id: 'bundle-reduce', metric: 'Bundle', title: 'Reduce Bundle Size', description: `Current: ${Math.round(metrics.bundle.totalSizeBytes / 1024)}KB (target: <300KB)`, impact: 'medium', effort: 'medium',
        actionItems: ['Implement code splitting', 'Lazy load below-fold components', 'Remove unused dependencies', 'Use tree-shaking'] });
    }
    if (metrics.api.p95LatencyMs > 500) {
      recs.push({ id: 'api-speed', metric: 'API', title: 'Improve API Response Times', description: `P95 latency: ${metrics.api.p95LatencyMs}ms (target: <500ms)`, impact: 'high', effort: 'medium',
        actionItems: ['Add query result caching', 'Optimize database queries', 'Add database indexes', 'Use connection pooling'] });
    }
    if (metrics.database.slowQueries > 5) {
      recs.push({ id: 'slow-queries', metric: 'Database', title: 'Fix Slow Queries', description: `${metrics.database.slowQueries} slow queries detected`, impact: 'high', effort: 'medium',
        actionItems: ['Add missing indexes', 'Optimize N+1 queries with includes', 'Use query result caching', 'Consider read replicas'] });
    }
    return recs.sort((a, b) => {
      const impactOrder = { high: 0, medium: 1, low: 2 };
      return impactOrder[a.impact] - impactOrder[b.impact];
    });
  }

  prioritize(recs: Recommendation[]): Recommendation[] {
    return recs.sort((a, b) => {
      const effortOrder = { low: 0, medium: 1, high: 2 };
      const impactOrder = { high: 0, medium: 1, low: 2 };
      return (impactOrder[a.impact] + effortOrder[a.effort]) - (impactOrder[b.impact] + effortOrder[b.effort]);
    });
  }
}

export const recommendationEngine = new RecommendationEngine();
TYPESCRIPT
)
    _prgen_write_file "$outfile" "$content" || return 1
    PRGEN_RECOMMENDATIONS_OK=true
    PRGEN_GENERATED=$((PRGEN_GENERATED + 1))
    _prgen_ok "Recommendation engine generated"
    return 0
}

_prgen_generate_all() {
    local project_dir="${1:-.}"
    _prgen_collect_metrics "$project_dir"
    _prgen_generate_html "$project_dir"
    _prgen_generate_recommendations "$project_dir"
    _prgen_ok "Performance report generation complete: ${PRGEN_GENERATED} components, ${PRGEN_ERRORS} errors"
}

_prgen_report() {
    echo -e "\n  ${BOLD:-\033[1m}═══ Performance Report Generator v${PRGEN_VERSION} ═══${NC:-\033[0m}"
    echo -e "  Generated       : ${PRGEN_GENERATED}"
    echo -e "  Errors          : ${PRGEN_ERRORS}"
    echo -e "  Metrics         : ${PRGEN_METRICS_OK}"
    echo -e "  HTML Report     : ${PRGEN_HTML_OK}"
    echo -e "  Recommendations : ${PRGEN_RECOMMENDATIONS_OK}"
}

_prgen_score() {
    local score=50
    ${PRGEN_METRICS_OK} && score=$((score + 15))
    ${PRGEN_HTML_OK} && score=$((score + 15))
    ${PRGEN_RECOMMENDATIONS_OK} && score=$((score + 15))
    [[ ${PRGEN_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "performance-report-generator" --version "469.0" \
        --description "パフォーマンスレポート: メトリクス収集×HTMLレポート×改善提案" \
        --init "_prgen_init" --report "_prgen_report" --score "_prgen_score" \
        --enable-var "ENABLE_PERF_REPORT" --cli-flags "--perf-report:--no-perf-report"
fi

# v2003.1: source時のexit codeを確実に0にする
true
