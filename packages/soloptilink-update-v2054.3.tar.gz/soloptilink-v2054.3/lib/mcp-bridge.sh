#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v63.0 - MCP Integration Bridge
#
# Claude CLI の --mcp-config フラグを活用し、
# MCP (Model Context Protocol) サーバーを通じて
# 外部サービスとClaudeを直接接続する。
#
# MCP対応サービス例:
# - filesystem: ファイルシステムの高度な操作
# - postgres/mysql: データベース直接クエリ
# - github: リポジトリ操作、PR作成
# - slack: メッセージ送信
# - brave-search: Web検索
#
# Claude CLI:
#   claude -p --mcp-config ./mcp-config.json "prompt"
#
# メリット:
# - Claudeが直接DBスキーマを確認してコード生成
# - GitHub連携でPR自動作成
# - 外部APIの仕様を読み取って正確なクライアント生成
# ============================================================

[[ -n "${_MCP_BRIDGE_LOADED:-}" ]] && return 0
_MCP_BRIDGE_LOADED=1

# --- Configuration ---
MB_ENABLE="${MB_ENABLE:-true}"
MB_CONFIG_DIR="${MB_CONFIG_DIR:-.soloptilink/mcp}"
MB_DEFAULT_SERVERS="${MB_DEFAULT_SERVERS:-filesystem}"

# --- State ---
MB_CALL_COUNT=0
MB_SERVERS_CONFIGURED=0
MB_CONFIG_FILE=""

# ============================================================
# 初期化
# ============================================================
mb_init() {
    MB_CALL_COUNT=0
    MB_SERVERS_CONFIGURED=0
    MB_CONFIG_FILE=""
    mkdir -p "${MB_CONFIG_DIR}" 2>/dev/null || true
    return 0
}

# ============================================================
# MCP設定ファイル生成
# プロジェクト種別に応じて適切なMCPサーバー構成を生成
# ============================================================
mb_generate_config() {
    local project_dir="$1"
    local project_type="${2:-fullstack}"
    local db_type="${3:-sqlite}"

    local config_file="${MB_CONFIG_DIR}/mcp-config.json"

    # ベースのMCPサーバー設定
    local servers='{'

    # Filesystem Server（常に有効）
    servers+='"filesystem": {'
    servers+='"command": "npx",'
    servers+='"args": ["-y", "@anthropic/mcp-server-filesystem", "'"${project_dir}"'"]'
    servers+='}'
    MB_SERVERS_CONFIGURED=$((MB_SERVERS_CONFIGURED + 1))

    # Database Server（プロジェクト種別に応じて）
    case "$db_type" in
        postgres|postgresql)
            servers+=',"postgres": {'
            servers+='"command": "npx",'
            servers+='"args": ["-y", "@anthropic/mcp-server-postgres"],'
            servers+='"env": {"DATABASE_URL": "postgresql://localhost:5432/app"}'
            servers+='}'
            MB_SERVERS_CONFIGURED=$((MB_SERVERS_CONFIGURED + 1))
            ;;
        sqlite)
            servers+=',"sqlite": {'
            servers+='"command": "npx",'
            servers+='"args": ["-y", "@anthropic/mcp-server-sqlite", "'"${project_dir}/db.sqlite"'"]'
            servers+='}'
            MB_SERVERS_CONFIGURED=$((MB_SERVERS_CONFIGURED + 1))
            ;;
    esac

    # GitHub Server（deploy/CI設定がある場合）
    if [[ -d "${project_dir}/.git" ]] || [[ "${project_type}" == "saas" ]]; then
        servers+=',"github": {'
        servers+='"command": "npx",'
        servers+='"args": ["-y", "@anthropic/mcp-server-github"]'
        servers+='}'
        MB_SERVERS_CONFIGURED=$((MB_SERVERS_CONFIGURED + 1))
    fi

    servers+='}'

    # MCP設定ファイル
    cat > "$config_file" << EOF
{
  "mcpServers": ${servers}
}
EOF

    MB_CONFIG_FILE="$config_file"
    echo "$config_file"
}

# ============================================================
# MCP付きClaude実行
# --mcp-config フラグでMCPサーバーを注入
# ============================================================
mb_call_with_mcp() {
    local prompt="$1"
    local output_file="${2:-}"
    local config_file="${3:-$MB_CONFIG_FILE}"

    MB_CALL_COUNT=$((MB_CALL_COUNT + 1))

    # PFP-068 v2037.x: Desktop(CLAUDECODE=1)では claude -p が Keychain制限で動かない。
    # 300秒タイムアウトを空振りするより、即フォールバックして決定論経路を促す。
    if [[ "${CLAUDECODE:-}" == "1" || "${CLAUDE_CODE_ENTRYPOINT:-}" == "claude-desktop" ]]; then
        echo "  [mcp-bridge] Desktop環境のため claude -p 経路は使用しません。外部連携は mb_connect_external (Connector Forge) を利用してください。" >&2
        if type -t cb2_call &>/dev/null; then cb2_call "$prompt" "$output_file" "implementation" "general"; return $?; fi
        return 1
    fi

    if [[ -z "$config_file" ]] || [[ ! -f "$config_file" ]]; then
        echo "WARNING: MCP config not found, falling back to standard call" >&2
        if type -t cb2_call &>/dev/null; then
            cb2_call "$prompt" "$output_file" "implementation" "general"
            return $?
        fi
        return 1
    fi

    # コマンド構築
    local -a cmd_args=()
    cmd_args+=("claude" "-p" "--dangerously-skip-permissions")
    cmd_args+=("--mcp-config" "$config_file")  # ← 核心
    cmd_args+=("--output-format" "text")
    cmd_args+=("--fallback-model" "claude-sonnet-4-20250514")
    cmd_args+=("--max-budget-usd" "${MB_BUDGET:-3.00}")

    # System Prompt
    if type -t cb2_build_system_prompt &>/dev/null; then
        local sys_prompt
        sys_prompt=$(cb2_build_system_prompt "implementation" 2>/dev/null || true)
        if [[ -n "$sys_prompt" ]]; then
            cmd_args+=("--system-prompt" "$sys_prompt")
        fi
    fi

    cmd_args+=("$prompt")

    local result
    result=$(timeout 300 "${cmd_args[@]}" 2>/dev/null) || true

    if [[ -n "$output_file" ]]; then
        echo "$result" > "$output_file"
    fi

    echo "$result"
    return 0
}

# ============================================================
# DB-Aware コード生成
# MCPでデータベーススキーマを読み取り、それに基づいてコード生成
# ============================================================
mb_db_aware_generate() {
    local task_desc="$1"
    local project_dir="$2"
    local db_type="${3:-sqlite}"

    # MCP設定生成
    local config
    config=$(mb_generate_config "$project_dir" "fullstack" "$db_type")

    local prompt
    prompt=$(cat << PROMPT
# Database-Aware Code Generation

## Task
${task_desc}

## Instructions
1. First, use the database MCP server to examine the current schema
2. Based on the actual schema, generate TypeScript types that match exactly
3. Generate Prisma schema that matches the database
4. Generate API routes with proper database queries
5. Generate frontend components that display the data correctly

## Quality Rules
- Types must match the actual database schema exactly
- All database queries must use parameterized statements
- Handle null/undefined values based on actual column nullability
- Include proper indexes for frequently queried columns
PROMPT
    )

    mb_call_with_mcp "$prompt" "" "$config"
}

# ============================================================
# レポート / スコア
# ============================================================
mb_report() {
    echo -e "\n  ${BOLD:-}═══ MCP Integration v63.0 レポート ═══${NC:-}"
    echo -e "  MCP呼び出し数      : ${MB_CALL_COUNT}"
    echo -e "  設定済みサーバー数 : ${MB_SERVERS_CONFIGURED}"
    echo -e "  設定ファイル       : ${MB_CONFIG_FILE:-未生成}"
}

mb_score() {
    if [[ $MB_CALL_COUNT -eq 0 ]]; then
        echo "50"
    elif [[ $MB_SERVERS_CONFIGURED -gt 2 ]]; then
        echo "95"
    elif [[ $MB_SERVERS_CONFIGURED -gt 0 ]]; then
        echo "85"
    else
        echo "70"
    fi
}

# ============================================================
# v2037.x PFP-068: Desktop対応の外部サービス連携経路
#   claude -p 依存を断ち、Desktop でも外部連携が開通する経路を提供する。
#   第一選択 = Connector Forge(IBL辞書駆動・決定論・claude -p非依存)。
# ============================================================

# 実行環境を判定する (desktop / terminal)
mb_runtime_mode() {
    if [[ "${CLAUDECODE:-}" == "1" || "${CLAUDE_CODE_ENTRYPOINT:-}" == "claude-desktop" ]]; then
        echo "desktop"
    else
        echo "terminal"
    fi
}

# claude -p が実際に使えるか (Desktopでは不可)
mb_claude_p_available() {
    [[ "$(mb_runtime_mode)" == "terminal" ]] && command -v claude >/dev/null 2>&1
}

# 外部サービス連携を「Desktopでも動く経路」で配線する。
#   使い方: mb_connect_external "Zoom連携を追加して" "/path/to/project"
#           mb_connect_external "zoom" "/path/to/project"
# 第一選択は Connector Forge(決定論)。端末モードでForge未対応のときのみMCP経由へ。
mb_connect_external() {
    local request="$1"
    local project_dir="${2:-$PWD}"
    [[ -z "$request" ]] && { echo "ERROR: 連携依頼が空です" >&2; return 1; }

    if [[ -f "${HOME}/.soloptilink/lib/connector-forge.sh" ]]; then
        source "${HOME}/.soloptilink/lib/connector-forge.sh" 2>/dev/null
        type -t cf_init &>/dev/null && cf_init 2>/dev/null || true
        local out rc
        if [[ -f "${HOME}/.soloptilink/integrations/${request}.json" ]]; then
            out=$(cf_forge_connector "$request" "$project_dir"); rc=$?
        else
            out=$(cf_forge "$request" "$project_dir"); rc=$?
        fi
        if [[ ${rc:-1} -eq 0 ]]; then
            echo "$out"; return 0
        fi
        # rc=2 (IBL未登録) のときだけ次の手段へ
    fi

    # フォールバック: 端末モードかつ claude -p 利用可能なら MCP経由(DB-Aware)
    if mb_claude_p_available; then
        echo "  [mcp-bridge] Forge未対応のため MCP経由(claude -p)で試行します" >&2
        mb_db_aware_generate "$request" "$project_dir"
        return $?
    fi

    echo "この連携先はまだ IBL 辞書に未登録です。対応している連携先:" >&2
    if [[ -f "${HOME}/.soloptilink/lib/ibl.sh" ]]; then
        source "${HOME}/.soloptilink/lib/ibl.sh" 2>/dev/null
        type -t ibl_init &>/dev/null && ibl_init 2>/dev/null
        type -t ibl_list &>/dev/null && ibl_list >&2
    fi
    return 2
}

# ============================================================
# v59.0: Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "mcp-bridge" \
        --version "63.0" \
        --description "--mcp-config外部サービス直接接続×DB-Aware生成" \
        --init "mb_init" \
        --report "mb_report" \
        --score "mb_score" \
        --enable-var "ENABLE_MCP_BRIDGE" \
        --cli-flags "--mcp-bridge:--no-mcp-bridge"
fi

# v2003.1: source時のexit codeを確実に0にする
true
