#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v28.0 - Follow-up Context Manager
# =============================================================================
# Follow-up Intelligence のオーケストレーター。
# プロジェクトGenome管理・リクエスト分類・フェーズスキップ判定を担う。
#
# 機能:
#   - Follow-up検出（既存プロジェクト + 保存済みGenome有無）
#   - Genomeロード/セーブ（Memory Manager長期記憶経由）
#   - リクエスト分類（error_fix/feature_add/modification/refactor/optimization）
#   - フェーズスキップ判定（Follow-up時に不要フェーズを自動スキップ）
#   - プロジェクトハッシュ計算
#
# 依存: lib/memory-manager.sh (Genome永続化), lib/code-scanner.sh (スキャン)
# =============================================================================

[[ -n "${_FOLLOWUP_CONTEXT_LOADED:-}" ]] && return 0
_FOLLOWUP_CONTEXT_LOADED=1

# =============================================================================
# 設定
# =============================================================================
FUC_VERSION="28.0"
FUC_ENABLED="false"
FUC_SESSION_ID=""
FUC_IS_FOLLOWUP="false"
FUC_REQUEST_TYPE="new_build"    # new_build|error_fix|feature_add|modification|refactor|optimization
FUC_GENOME_LOADED="false"
FUC_GENOME_PATH=""
FUC_GENOME_JSON=""
FUC_PROJECT_HASH=""
FUC_PROJECT_DIR=""
FUC_WORK_DIR="${HOME}/.soloptilink/followup-context"
FUC_GENOME_DIR="${HOME}/.soloptilink/memory/long-term/genome"

# リクエスト分類キーワード
declare -g -A FUC_CLASSIFY_KEYWORDS=(
    [error_fix]="エラー|バグ|修正して|直して|fix|bug|error|壊れ|動かない|表示されない|crash|TypeError|SyntaxError|failed|失敗|おかしい|問題"
    [feature_add]="追加|新しい|機能|作って|add|create|implement|new|新規|つけて|増やして|生成|対応|導入"
    [modification]="変更|変えて|修正|更新|update|change|modify|alter|改善|直して|入れ替え|差し替え|切り替え"
    [refactor]="リファクタ|整理|構造|分割|統合|refactor|restructure|cleanup|clean up|最適化|シンプル"
    [optimization]="高速化|軽量化|速く|パフォーマンス|optimize|performance|improve|改善|キャッシュ|cache|遅い|重い"
)

# フェーズスキップマッピング（リクエストタイプごとにスキップするフェーズ）
declare -g -A FUC_SKIP_PHASES_ERROR_FIX=(
    [data_import]=1 [domain_knowledge]=1 [scaffold]=1 [blueprint]=1 [prompt_compile]=1
    [saas_architecture]=1 [ai_integration]=1
)
declare -g -A FUC_SKIP_PHASES_FEATURE_ADD=(
    [data_import]=1 [scaffold]=1
)
declare -g -A FUC_SKIP_PHASES_MODIFICATION=(
    [data_import]=1 [domain_knowledge]=1 [scaffold]=1 [blueprint]=1 [prompt_compile]=1
    [saas_architecture]=1 [ai_integration]=1
)
declare -g -A FUC_SKIP_PHASES_REFACTOR=(
    [data_import]=1 [domain_knowledge]=1 [scaffold]=1 [saas_architecture]=1 [ai_integration]=1
)
declare -g -A FUC_SKIP_PHASES_OPTIMIZATION=(
    [data_import]=1 [domain_knowledge]=1 [scaffold]=1 [blueprint]=1 [prompt_compile]=1
    [saas_architecture]=1 [ai_integration]=1
)

# カラー
FUC_GREEN='\033[0;32m'
FUC_YELLOW='\033[0;33m'
FUC_RED='\033[0;31m'
FUC_CYAN='\033[0;36m'
FUC_BOLD='\033[1m'
FUC_DIM='\033[2m'
FUC_NC='\033[0m'

# =============================================================================
# 初期化
# =============================================================================
fuc_init() {
    local session_id="${1:-}"
    FUC_SESSION_ID="$session_id"
    FUC_ENABLED="true"
    FUC_IS_FOLLOWUP="false"
    FUC_REQUEST_TYPE="new_build"
    FUC_GENOME_LOADED="false"
    FUC_GENOME_PATH=""
    FUC_GENOME_JSON=""
    FUC_PROJECT_HASH=""
    FUC_PROJECT_DIR=""
    mkdir -p "${FUC_WORK_DIR}" "${FUC_GENOME_DIR}" 2>/dev/null || true
    echo -e "  ${FUC_GREEN}OK${FUC_NC} Follow-up Context v${FUC_VERSION}"
}

# =============================================================================
# ログ
# =============================================================================
_fuc_log() {
    local level="$1" msg="$2"
    local color="${FUC_NC}"
    case "$level" in
        INFO)    color="${FUC_GREEN}" ;;
        WARN)    color="${FUC_YELLOW}" ;;
        ERROR)   color="${FUC_RED}" ;;
        DEBUG)   color="${FUC_DIM}" ;;
    esac
    echo -e "  ${color}[FUC/${level}]${FUC_NC} ${msg}" >&2
}

# =============================================================================
# プロジェクトハッシュ計算
# =============================================================================
fuc_compute_project_hash() {
    local project_dir="${1:-.}"
    # Normalize path and compute MD5 hash
    local normalized
    normalized=$(cd "$project_dir" 2>/dev/null && pwd || echo "$project_dir")
    if command -v md5sum &>/dev/null; then
        echo -n "$normalized" | md5sum | cut -d' ' -f1
    elif command -v md5 &>/dev/null; then
        echo -n "$normalized" | md5
    else
        # Fallback: simple hash from basename + parent
        echo -n "$normalized" | cksum | cut -d' ' -f1
    fi
}

# =============================================================================
# Follow-up検出
# =============================================================================
fuc_detect_followup() {
    local project_dir="${1:-.}"
    local task_desc="${2:-}"

    FUC_PROJECT_DIR="$project_dir"

    # Check 1: Does the project directory have source code?
    local has_source="false"
    if [[ -f "${project_dir}/package.json" ]] || \
       [[ -f "${project_dir}/requirements.txt" ]] || \
       [[ -f "${project_dir}/pyproject.toml" ]] || \
       [[ -f "${project_dir}/go.mod" ]] || \
       [[ -f "${project_dir}/Cargo.toml" ]]; then
        has_source="true"
    fi

    # Check 2: Does a saved genome exist for this project?
    local hash
    hash=$(fuc_compute_project_hash "$project_dir")
    FUC_PROJECT_HASH="$hash"
    local genome_file="${FUC_GENOME_DIR}/${hash}.json"

    if [[ "$has_source" == "true" && -f "$genome_file" ]]; then
        FUC_IS_FOLLOWUP="true"
        _fuc_log "INFO" "Follow-up検出: 既存プロジェクト + 保存済みGenome"

        # Classify the request
        fuc_classify_request "$task_desc" ""
        return 0
    fi

    # Check 3: Even without genome, if project has many source files,
    # it's likely a follow-up (genome wasn't saved yet)
    if [[ "$has_source" == "true" ]]; then
        local src_count
        src_count=$(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" -o -name "*.py" \) \
            -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/venv/*" 2>/dev/null | wc -l | tr -d ' ')
        if [[ "$src_count" -gt 5 ]]; then
            FUC_IS_FOLLOWUP="true"
            _fuc_log "INFO" "Follow-up検出: 既存ソースコード ${src_count} ファイル（Genomeなし）"
            fuc_classify_request "$task_desc" ""
            return 0
        fi
    fi

    FUC_IS_FOLLOWUP="false"
    FUC_REQUEST_TYPE="new_build"
    _fuc_log "INFO" "新規ビルドとして処理"
    return 0
}

# =============================================================================
# リクエスト分類
# =============================================================================
fuc_classify_request() {
    local task_desc="${1:-}"
    local genome_json="${2:-}"

    # Keyword-based classification (fast path)
    local best_type="modification"
    local best_score=0

    for req_type in error_fix feature_add modification refactor optimization; do
        local keywords="${FUC_CLASSIFY_KEYWORDS[$req_type]}"
        local score=0

        # Count matching keywords
        while IFS='|' read -ra kw_array; do
            for kw in "${kw_array[@]}"; do
                if echo "$task_desc" | grep -qi "$kw" 2>/dev/null; then
                    score=$((score + 1))
                fi
            done
        done <<< "$keywords"

        if [[ "$score" -gt "$best_score" ]]; then
            best_score=$score
            best_type=$req_type
        fi
    done

    # If no keywords matched at all, default to modification
    if [[ "$best_score" -eq 0 ]]; then
        best_type="modification"
    fi

    FUC_REQUEST_TYPE="$best_type"
    _fuc_log "INFO" "リクエスト分類: ${FUC_REQUEST_TYPE} (スコア: ${best_score})"
    echo "$FUC_REQUEST_TYPE"
}

# =============================================================================
# Genomeロード
# =============================================================================
fuc_load_genome() {
    local project_dir="${1:-.}"

    local hash
    hash=$(fuc_compute_project_hash "$project_dir")
    FUC_PROJECT_HASH="$hash"
    local genome_file="${FUC_GENOME_DIR}/${hash}.json"

    if [[ -f "$genome_file" ]]; then
        FUC_GENOME_PATH="$genome_file"
        FUC_GENOME_JSON=$(cat "$genome_file" 2>/dev/null || echo "")
        FUC_GENOME_LOADED="true"
        _fuc_log "INFO" "Genome ロード成功: ${genome_file}"
        return 0
    fi

    # Memory Manager fallback
    if type -t mm_recall_long &>/dev/null; then
        local mm_genome
        mm_genome=$(mm_recall_long "genome" "$hash" 2>/dev/null || echo "")
        if [[ -n "$mm_genome" ]]; then
            FUC_GENOME_JSON="$mm_genome"
            FUC_GENOME_LOADED="true"
            _fuc_log "INFO" "Genome ロード成功（Memory Manager経由）"
            return 0
        fi
    fi

    FUC_GENOME_LOADED="false"
    _fuc_log "WARN" "Genome未検出: ${genome_file}"
    return 1
}

# =============================================================================
# Genome保存
# =============================================================================
fuc_save_genome() {
    local project_dir="${1:-.}"
    local genome_json="${2:-}"

    [[ -z "$genome_json" ]] && {
        _fuc_log "WARN" "Genome JSONが空 → 保存スキップ"
        return 1
    }

    local hash
    hash=$(fuc_compute_project_hash "$project_dir")
    FUC_PROJECT_HASH="$hash"
    mkdir -p "${FUC_GENOME_DIR}" 2>/dev/null || true

    local genome_file="${FUC_GENOME_DIR}/${hash}.json"
    echo "$genome_json" > "$genome_file"
    FUC_GENOME_PATH="$genome_file"
    FUC_GENOME_JSON="$genome_json"
    FUC_GENOME_LOADED="true"

    # Also store via Memory Manager if available
    if type -t mm_store_long &>/dev/null; then
        mm_store_long "genome" "$hash" "$genome_json" "genome,project" 2>/dev/null || true
    fi

    _fuc_log "INFO" "Genome 保存完了: ${genome_file}"
    return 0
}

# =============================================================================
# フェーズスキップ判定
# =============================================================================
fuc_should_skip_phase() {
    local phase_name="${1:-}"
    local request_type="${2:-${FUC_REQUEST_TYPE}}"

    # Never skip implementation or core validation phases
    case "$phase_name" in
        prompt_expand|implementation|validation|security|knowledge_save)
            return 1  # Do NOT skip
            ;;
        followup_detect|code_scan|incremental_analysis|targeted_compile|delta_apply)
            return 1  # Do NOT skip (these are Follow-up phases)
            ;;
    esac

    # Check skip map based on request type
    case "$request_type" in
        error_fix)
            [[ -n "${FUC_SKIP_PHASES_ERROR_FIX[$phase_name]+_}" ]] && return 0
            ;;
        feature_add)
            [[ -n "${FUC_SKIP_PHASES_FEATURE_ADD[$phase_name]+_}" ]] && return 0
            ;;
        modification)
            [[ -n "${FUC_SKIP_PHASES_MODIFICATION[$phase_name]+_}" ]] && return 0
            ;;
        refactor)
            [[ -n "${FUC_SKIP_PHASES_REFACTOR[$phase_name]+_}" ]] && return 0
            ;;
        optimization)
            [[ -n "${FUC_SKIP_PHASES_OPTIMIZATION[$phase_name]+_}" ]] && return 0
            ;;
    esac

    return 1  # Do NOT skip (default)
}

# =============================================================================
# Follow-upコンテキスト構築
# =============================================================================
fuc_get_followup_context() {
    local project_dir="${1:-.}"
    local task_desc="${2:-}"
    local request_type="${3:-${FUC_REQUEST_TYPE}}"

    local context=""
    context+="# Follow-up Context (v28.0)\n"
    context+="## Request Type: ${request_type}\n"
    context+="## Task: ${task_desc}\n"
    context+="## Project: ${project_dir}\n"

    if [[ "$FUC_GENOME_LOADED" == "true" && -n "$FUC_GENOME_JSON" ]]; then
        # Extract key info from genome
        local framework language schema_type
        framework=$(echo "$FUC_GENOME_JSON" | python3 -c "import sys,json; d=json.loads(sys.stdin.read()); print(d.get('framework','unknown'))" 2>/dev/null || echo "unknown")
        language=$(echo "$FUC_GENOME_JSON" | python3 -c "import sys,json; d=json.loads(sys.stdin.read()); print(d.get('language','unknown'))" 2>/dev/null || echo "unknown")
        schema_type=$(echo "$FUC_GENOME_JSON" | python3 -c "import sys,json; d=json.loads(sys.stdin.read()); print(d.get('schema',{}).get('type','none'))" 2>/dev/null || echo "none")

        context+="## Framework: ${framework}\n"
        context+="## Language: ${language}\n"
        context+="## Schema: ${schema_type}\n"
        context+="## Genome Loaded: true\n"
    else
        context+="## Genome Loaded: false\n"
    fi

    echo -e "$context"
}

# =============================================================================
# レポート
# =============================================================================
fuc_report() {
    echo -e "\n  ${FUC_BOLD}${FUC_CYAN}[Follow-up Context Report]${FUC_NC}"
    echo -e "  Version:      ${FUC_VERSION}"
    echo -e "  Is Follow-up: ${FUC_IS_FOLLOWUP}"
    echo -e "  Request Type: ${FUC_REQUEST_TYPE}"
    echo -e "  Genome:       ${FUC_GENOME_LOADED}"
    echo -e "  Project Hash: ${FUC_PROJECT_HASH}"
}
