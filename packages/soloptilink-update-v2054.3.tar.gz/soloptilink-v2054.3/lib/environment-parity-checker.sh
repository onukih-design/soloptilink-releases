#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v418.0 - Environment Parity Checker
# =============================================================================
# 開発/ステージング/本番環境の一貫性チェック・ドリフト検出・修正生成。
# 環境変数・パッケージバージョン・設定ファイルの差分を自動検出する。
#
# Functions:
#   _epc_init           - 初期化
#   _epc_compare_envs   - 環境間比較
#   _epc_detect_drift   - ドリフト検出
#   _epc_generate_fix   - 修正提案生成
#   _epc_report         - レポート出力
#   _epc_score          - モジュールスコア(0-100)
#
# All globals use the EPC_ prefix.
# =============================================================================

[[ -n "${_ENV_PARITY_CHECKER_LOADED:-}" ]] && return 0
_ENV_PARITY_CHECKER_LOADED=1

declare -g EPC_VERSION="418.0"
declare -g EPC_INITIALIZED=false
declare -g EPC_STORE_DIR=""
declare -g EPC_COMPARE_COUNT=0
declare -g EPC_DRIFT_COUNT=0
declare -g EPC_FIX_COUNT=0

declare -g -A _EPC_ENV_VARS=()         # "env:var_name" → value_or_presence
declare -g -A _EPC_ENV_FILES=()        # env_name → file_path
declare -g -a _EPC_DRIFTS=()           # drift descriptions
declare -g -A _EPC_REQUIRED_VARS=()    # var_name → "description"

# =============================================================================
_epc_init() {
    local project_dir="${PROJECT_DIR:-.}"
    EPC_STORE_DIR="${project_dir}/.soloptilink/env-parity"
    mkdir -p "${EPC_STORE_DIR}/snapshots" "${EPC_STORE_DIR}/reports"

    # Detect environment files
    for env_file in \
        "${project_dir}/.env" \
        "${project_dir}/.env.local" \
        "${project_dir}/.env.development" \
        "${project_dir}/.env.staging" \
        "${project_dir}/.env.production" \
        "${project_dir}/.env.test" \
        "${project_dir}/.env.example" \
        "${project_dir}/admin-dashboard/.env" \
        "${project_dir}/admin-dashboard/.env.local"; do
        if [[ -f "$env_file" ]]; then
            local env_name
            env_name=$(basename "$env_file" | sed 's/^\.env\.\?//' )
            [[ -z "$env_name" ]] && env_name="default"
            _EPC_ENV_FILES["$env_name"]="$env_file"

            # Parse env vars (names only for security)
            while IFS= read -r line; do
                [[ -z "$line" || "$line" == \#* ]] && continue
                local var_name="${line%%=*}"
                [[ -n "$var_name" ]] && _EPC_ENV_VARS["${env_name}:${var_name}"]="present"
            done < "$env_file"
        fi
    done

    # Common required variables
    _EPC_REQUIRED_VARS["DATABASE_URL"]="Database connection string"
    _EPC_REQUIRED_VARS["NEXTAUTH_SECRET"]="NextAuth.js secret key"
    _EPC_REQUIRED_VARS["NEXTAUTH_URL"]="NextAuth.js URL"
    _EPC_REQUIRED_VARS["NODE_ENV"]="Runtime environment"

    EPC_INITIALIZED=true
    return 0
}

# =============================================================================
# _epc_compare_envs - Compare two environments
# =============================================================================
_epc_compare_envs() {
    local env_a="${1:-default}"
    local env_b="${2:-production}"

    [[ "$EPC_INITIALIZED" != "true" ]] && { echo "ERROR: EPC not initialized" >&2; return 1; }
    EPC_COMPARE_COUNT=$((EPC_COMPARE_COUNT + 1))

    local only_a=() only_b=() common=()

    # Collect vars for each env
    local -A vars_a=() vars_b=()
    for key in "${!_EPC_ENV_VARS[@]}"; do
        local env="${key%%:*}"
        local var="${key#*:}"
        if [[ "$env" == "$env_a" ]]; then
            vars_a["$var"]=1
        elif [[ "$env" == "$env_b" ]]; then
            vars_b["$var"]=1
        fi
    done

    # Compare
    for var in "${!vars_a[@]}"; do
        if [[ -n "${vars_b[$var]:-}" ]]; then
            common+=("$var")
        else
            only_a+=("$var")
        fi
    done

    for var in "${!vars_b[@]}"; do
        if [[ -z "${vars_a[$var]:-}" ]]; then
            only_b+=("$var")
        fi
    done

    cat <<CMPEOF
{"env_a":"${env_a}","env_b":"${env_b}","common":${#common[@]},"only_a":${#only_a[@]},"only_b":${#only_b[@]}}
CMPEOF

    # Detail output
    if [[ ${#only_a[@]} -gt 0 ]]; then
        echo "  Only in ${env_a}:" >&2
        for v in "${only_a[@]}"; do
            echo "    - ${v}" >&2
        done
    fi

    if [[ ${#only_b[@]} -gt 0 ]]; then
        echo "  Only in ${env_b}:" >&2
        for v in "${only_b[@]}"; do
            echo "    - ${v}" >&2
        done
    fi

    return 0
}

# =============================================================================
# _epc_detect_drift - Detect environment configuration drift
# =============================================================================
_epc_detect_drift() {
    local project_dir="${1:-${PROJECT_DIR:-.}}"

    [[ "$EPC_INITIALIZED" != "true" ]] && { echo "ERROR: EPC not initialized" >&2; return 1; }

    _EPC_DRIFTS=()

    # Check 1: Missing required vars across environments
    for req_var in "${!_EPC_REQUIRED_VARS[@]}"; do
        for env_name in "${!_EPC_ENV_FILES[@]}"; do
            if [[ -z "${_EPC_ENV_VARS[${env_name}:${req_var}]:-}" ]]; then
                _EPC_DRIFTS+=("missing_required:${env_name}:${req_var}:${_EPC_REQUIRED_VARS[$req_var]}")
                EPC_DRIFT_COUNT=$((EPC_DRIFT_COUNT + 1))
            fi
        done
    done

    # Check 2: .env.example vs actual env files
    local example_file="${_EPC_ENV_FILES[example]:-}"
    if [[ -n "$example_file" && -f "$example_file" ]]; then
        local -A example_vars=()
        while IFS= read -r line; do
            [[ -z "$line" || "$line" == \#* ]] && continue
            local var_name="${line%%=*}"
            [[ -n "$var_name" ]] && example_vars["$var_name"]=1
        done < "$example_file"

        for env_name in "${!_EPC_ENV_FILES[@]}"; do
            [[ "$env_name" == "example" ]] && continue
            for var in "${!example_vars[@]}"; do
                if [[ -z "${_EPC_ENV_VARS[${env_name}:${var}]:-}" ]]; then
                    _EPC_DRIFTS+=("missing_from_example:${env_name}:${var}")
                    EPC_DRIFT_COUNT=$((EPC_DRIFT_COUNT + 1))
                fi
            done
        done
    fi

    # Check 3: Node.js version consistency
    local nvmrc_version=""
    local pkg_engine_version=""
    if [[ -f "${project_dir}/.nvmrc" ]]; then
        nvmrc_version=$(cat "${project_dir}/.nvmrc" | tr -d '\n')
    fi
    if [[ -f "${project_dir}/package.json" ]]; then
        pkg_engine_version=$(grep '"node"' "${project_dir}/package.json" 2>/dev/null | grep -oE '[0-9]+\.[0-9]+' | head -1)
    fi
    if [[ -n "$nvmrc_version" && -n "$pkg_engine_version" ]]; then
        if [[ "$nvmrc_version" != *"$pkg_engine_version"* ]]; then
            _EPC_DRIFTS+=("version_mismatch:node:.nvmrc=${nvmrc_version}:package.json=${pkg_engine_version}")
            EPC_DRIFT_COUNT=$((EPC_DRIFT_COUNT + 1))
        fi
    fi

    # Check 4: Lockfile consistency
    if [[ -f "${project_dir}/package-lock.json" && -f "${project_dir}/yarn.lock" ]]; then
        _EPC_DRIFTS+=("dual_lockfile:both_package-lock_and_yarn.lock_exist")
        EPC_DRIFT_COUNT=$((EPC_DRIFT_COUNT + 1))
    fi

    # Check 5: TypeScript config consistency
    local tsconfigs
    tsconfigs=$(find "$project_dir" -name "tsconfig.json" -not -path "*/node_modules/*" 2>/dev/null | head -5)
    local strict_count=0 non_strict_count=0
    while IFS= read -r tsconfig; do
        [[ -z "$tsconfig" ]] && continue
        if grep -q '"strict": true' "$tsconfig" 2>/dev/null; then
            strict_count=$((strict_count + 1))
        else
            non_strict_count=$((non_strict_count + 1))
        fi
    done <<< "$tsconfigs"
    if [[ $strict_count -gt 0 && $non_strict_count -gt 0 ]]; then
        _EPC_DRIFTS+=("tsconfig_drift:mixed_strict_modes:strict=${strict_count}:non-strict=${non_strict_count}")
        EPC_DRIFT_COUNT=$((EPC_DRIFT_COUNT + 1))
    fi

    cat <<DRIFTEOF
{"total_drifts":${#_EPC_DRIFTS[@]},"environments":${#_EPC_ENV_FILES[@]}}
DRIFTEOF

    for drift in "${_EPC_DRIFTS[@]}"; do
        echo "  DRIFT: ${drift}" >&2
    done

    return 0
}

# =============================================================================
# _epc_generate_fix - Generate fixes for detected drift
# =============================================================================
_epc_generate_fix() {
    [[ "$EPC_INITIALIZED" != "true" ]] && return 1

    EPC_FIX_COUNT=$((EPC_FIX_COUNT + 1))
    echo "=== Environment Parity Fixes ==="

    for drift in "${_EPC_DRIFTS[@]}"; do
        local drift_type="${drift%%:*}"
        local rest="${drift#*:}"

        case "$drift_type" in
            missing_required)
                local env="${rest%%:*}"
                local var_rest="${rest#*:}"
                local var="${var_rest%%:*}"
                local desc="${var_rest#*:}"
                echo ""
                echo "FIX: Add ${var} to .env.${env}"
                echo "  ${var}=  # ${desc}"
                ;;
            missing_from_example)
                local env="${rest%%:*}"
                local var="${rest#*:}"
                echo ""
                echo "FIX: Add ${var} to .env.${env} (defined in .env.example)"
                echo "  ${var}="
                ;;
            dual_lockfile)
                echo ""
                echo "FIX: Remove one lockfile. Choose either npm or yarn:"
                echo "  rm yarn.lock   # if using npm"
                echo "  rm package-lock.json  # if using yarn"
                ;;
            version_mismatch)
                echo ""
                echo "FIX: Align Node.js versions across config files"
                ;;
            tsconfig_drift)
                echo ""
                echo "FIX: Ensure all tsconfig.json files use strict: true"
                ;;
        esac
    done

    [[ ${#_EPC_DRIFTS[@]} -eq 0 ]] && echo "No drift detected. All environments are in sync."
    return 0
}

# =============================================================================
# Report / Score
# =============================================================================
_epc_report() {
    echo -e "\n  ${BOLD:-}=== Environment Parity Checker v${EPC_VERSION} ===${NC:-}"
    echo -e "  Environments Found : ${#_EPC_ENV_FILES[@]}"
    echo -e "  Comparisons Run    : ${EPC_COMPARE_COUNT}"
    echo -e "  Drifts Detected    : ${EPC_DRIFT_COUNT}"
    echo -e "  Fixes Generated    : ${EPC_FIX_COUNT}"
}

_epc_score() {
    local score=30
    [[ "$EPC_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ ${#_EPC_ENV_FILES[@]} -gt 0 ]] && score=$((score + 15))
    [[ $EPC_DRIFT_COUNT -eq 0 && $EPC_COMPARE_COUNT -gt 0 ]] && score=$((score + 25))
    [[ $EPC_DRIFT_COUNT -gt 0 && $EPC_FIX_COUNT -gt 0 ]] && score=$((score + 10))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "environment-parity-checker" \
        --version "418.0" \
        --description "環境間一貫性チェック・ドリフト検出・修正提案" \
        --init "_epc_init" \
        --report "_epc_report" \
        --score "_epc_score" \
        --enable-var "ENABLE_EPC" \
        --cli-flags "--env-parity:--no-env-parity"
fi

# v2003.1: source時のexit codeを確実に0にする
true
