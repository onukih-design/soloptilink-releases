#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v30.0 - Governance Engine (ガバナンスエンジン)
# =============================================================================
# プロジェクトのコーディング規約・アーキテクチャ整合性・技術的負債を
# 自律的にチェックし、品質ガバナンスを自動強制するエンジン。
#
# v30.0: 初版 - Autonomous Governance（自律ガバナンス）
#
# 機能:
#   ag_init                   - ガバナンスルールの初期化
#   ag_load_rules             - プロジェクト規約の自動検出・読み込み
#   ag_check_architecture     - アーキテクチャ整合性チェック
#   ag_check_naming           - 命名規約の強制
#   ag_check_tech_debt        - 技術的負債の検出
#   ag_check_dependency_policy - 依存関係ガバナンス
#   ag_enforce                - 全ガバナンスチェックの一括実行
#   ag_report                 - ガバナンスレポート出力
#   ag_score                  - ガバナンススコア（0-100）
#   ag_report_json            - JSON形式レポート
#
# All globals use the AG_ prefix.
# =============================================================================

[[ -n "${_GOVERNANCE_ENGINE_LOADED:-}" ]] && return 0
_GOVERNANCE_ENGINE_LOADED=1

# ============================================================
# State
# ============================================================
declare -g AG_VERSION="30.0"
declare -g AG_ENABLED="false"
declare -g AG_SESSION_ID=""
declare -g AG_PROJECT_DIR=""
declare -g AG_SCORE=0

# Rule detection results
declare -g AG_HAS_ESLINT="false"
declare -g AG_HAS_PRETTIER="false"
declare -g AG_HAS_TSCONFIG="false"
declare -g AG_HAS_EDITORCONFIG="false"
declare -g AG_RULES_LOADED=0

# Architecture check results
declare -g AG_ARCH_VIOLATIONS=0
declare -g AG_CIRCULAR_DEPS=0
declare -g AG_LAYER_VIOLATIONS=0

# Naming check results
declare -g AG_NAMING_VIOLATIONS=0
declare -g AG_FILE_NAMING_VIOLATIONS=0
declare -g AG_FUNC_NAMING_VIOLATIONS=0

# Tech debt results
declare -g AG_TODO_COUNT=0
declare -g AG_FIXME_COUNT=0
declare -g AG_HACK_COUNT=0
declare -g AG_LARGE_FILES=0
declare -g AG_DUPLICATE_PATTERNS=0
declare -g AG_DEPRECATED_USAGE=0
declare -g AG_TECH_DEBT_TOTAL=0

# Dependency policy results
declare -g AG_TOTAL_DEPS=0
declare -g AG_MAX_DEPS_THRESHOLD=100
declare -g AG_LICENSE_ISSUES=0
declare -g AG_BLOATED_PACKAGES=0

# Collected issues
declare -g -a AG_ISSUES=()
declare -g -a AG_RECOMMENDATIONS=()

# ============================================================
# Internal logger
# ============================================================
_ag_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[GOVERNANCE]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize
# ============================================================
ag_init() {
    local session_id="${1:-${SESSION_ID:-unknown}}"

    AG_SESSION_ID="$session_id"
    AG_ENABLED="true"
    AG_PROJECT_DIR=""
    AG_SCORE=0

    AG_HAS_ESLINT="false"
    AG_HAS_PRETTIER="false"
    AG_HAS_TSCONFIG="false"
    AG_HAS_EDITORCONFIG="false"
    AG_RULES_LOADED=0

    AG_ARCH_VIOLATIONS=0
    AG_CIRCULAR_DEPS=0
    AG_LAYER_VIOLATIONS=0
    AG_NAMING_VIOLATIONS=0
    AG_FILE_NAMING_VIOLATIONS=0
    AG_FUNC_NAMING_VIOLATIONS=0
    AG_TODO_COUNT=0
    AG_FIXME_COUNT=0
    AG_HACK_COUNT=0
    AG_LARGE_FILES=0
    AG_DUPLICATE_PATTERNS=0
    AG_DEPRECATED_USAGE=0
    AG_TECH_DEBT_TOTAL=0
    AG_TOTAL_DEPS=0
    AG_LICENSE_ISSUES=0
    AG_BLOATED_PACKAGES=0
    AG_ISSUES=()
    AG_RECOMMENDATIONS=()

    _ag_log "SUCCESS" "Governance Engine v${AG_VERSION} 初期化完了 (session=${session_id})"
    return 0
}

# ============================================================
# Auto-detect and load project coding standards
# ============================================================
ag_load_rules() {
    local project_dir="${1:-.}"
    AG_PROJECT_DIR="$project_dir"
    local rules_found=0

    _ag_log "SUCCESS" "プロジェクト規約の自動検出開始: ${project_dir}"

    # Detect ESLint configuration
    if [[ -f "${project_dir}/.eslintrc" || -f "${project_dir}/.eslintrc.js" || \
          -f "${project_dir}/.eslintrc.json" || -f "${project_dir}/.eslintrc.yml" || \
          -f "${project_dir}/.eslintrc.cjs" || -f "${project_dir}/eslint.config.js" || \
          -f "${project_dir}/eslint.config.mjs" ]]; then
        AG_HAS_ESLINT="true"
        rules_found=$((rules_found + 1))
        _ag_log "SUCCESS" "  ESLint 設定を検出"
    fi

    # Detect Prettier configuration
    if [[ -f "${project_dir}/.prettierrc" || -f "${project_dir}/.prettierrc.js" || \
          -f "${project_dir}/.prettierrc.json" || -f "${project_dir}/.prettierrc.yml" || \
          -f "${project_dir}/prettier.config.js" || -f "${project_dir}/prettier.config.mjs" ]]; then
        AG_HAS_PRETTIER="true"
        rules_found=$((rules_found + 1))
        _ag_log "SUCCESS" "  Prettier 設定を検出"
    fi

    # Detect TypeScript configuration
    if [[ -f "${project_dir}/tsconfig.json" || -f "${project_dir}/tsconfig.base.json" ]]; then
        AG_HAS_TSCONFIG="true"
        rules_found=$((rules_found + 1))
        _ag_log "SUCCESS" "  TypeScript 設定を検出"
    fi

    # Detect EditorConfig
    if [[ -f "${project_dir}/.editorconfig" ]]; then
        AG_HAS_EDITORCONFIG="true"
        rules_found=$((rules_found + 1))
        _ag_log "SUCCESS" "  EditorConfig を検出"
    fi

    AG_RULES_LOADED=$rules_found

    # Report missing recommended configs
    if [[ "$AG_HAS_ESLINT" == "false" ]]; then
        AG_ISSUES+=("[RULES] ESLint 設定が未検出 - コードスタイルの一貫性が保証されません")
        AG_RECOMMENDATIONS+=("ESLint を導入してコードスタイルを統一してください: npx eslint --init")
    fi
    if [[ "$AG_HAS_PRETTIER" == "false" ]]; then
        AG_ISSUES+=("[RULES] Prettier 設定が未検出 - フォーマットの一貫性が保証されません")
        AG_RECOMMENDATIONS+=("Prettier を導入してフォーマットを統一してください: npm install -D prettier")
    fi
    if [[ "$AG_HAS_TSCONFIG" == "false" ]]; then
        # Only warn for JS/TS projects
        if [[ -f "${project_dir}/package.json" ]]; then
            AG_ISSUES+=("[RULES] TypeScript 設定が未検出 - 型安全性が保証されません")
        fi
    fi

    _ag_log "SUCCESS" "規約検出完了: ${rules_found}件の設定ファイルを検出"
    echo "$rules_found"
    return 0
}

# ============================================================
# Architecture consistency check
# ============================================================
ag_check_architecture() {
    local project_dir="${1:-$AG_PROJECT_DIR}"
    local violations=0
    local circular=0
    local layer_viol=0

    _ag_log "SUCCESS" "アーキテクチャ整合性チェック開始..."

    local src_dir="${project_dir}/src"
    [[ ! -d "$src_dir" ]] && src_dir="${project_dir}/app"
    [[ ! -d "$src_dir" ]] && { _ag_log "WARN" "ソースディレクトリが見つかりません"; echo "0"; return 0; }

    # Check 1: Layer separation violations
    # Common layers: components should not import from pages, utils should not import from components
    local layer_order=("utils" "lib" "hooks" "components" "pages" "app")

    for ((i=0; i<${#layer_order[@]}; i++)); do
        local lower_layer="${layer_order[$i]}"
        local lower_dir="${src_dir}/${lower_layer}"
        [[ ! -d "$lower_dir" ]] && continue

        for ((j=i+1; j<${#layer_order[@]}; j++)); do
            local upper_layer="${layer_order[$j]}"
            # Check if lower layer imports from upper layer (violation)
            local import_count
            import_count=$(grep -rl "from.*['\"].*/${upper_layer}/" "$lower_dir" 2>/dev/null | wc -l | tr -d ' ' || echo "0")
            if [[ "$import_count" -gt 0 ]]; then
                violations=$((violations + import_count))
                layer_viol=$((layer_viol + import_count))
                AG_ISSUES+=("[ARCH] レイヤー違反: ${lower_layer} が ${upper_layer} をインポート (${import_count}箇所)")
            fi
        done
    done

    # Check 2: Circular dependencies between modules
    # Build a simple import graph and detect cycles
    local -A import_graph=()
    while IFS= read -r -d '' file; do
        local relpath="${file#$src_dir/}"
        local dir_name
        dir_name=$(dirname "$relpath" | cut -d'/' -f1)
        local imports
        imports=$(grep -oE "from ['\"]\.\.?/[^'\"]*['\"]" "$file" 2>/dev/null | \
                  sed "s/from ['\"]//;s/['\"]//g" | \
                  while read -r imp; do
                      # Extract the top-level directory of the import target
                      echo "$imp" | sed 's|^\.\./||;s|^\./||' | cut -d'/' -f1
                  done | sort -u || true)
        for imp_dir in $imports; do
            [[ "$imp_dir" == "$dir_name" ]] && continue
            [[ -z "$imp_dir" ]] && continue
            local key="${dir_name}->${imp_dir}"
            local reverse="${imp_dir}->${dir_name}"
            import_graph["$key"]=1
            if [[ -n "${import_graph[$reverse]:-}" ]]; then
                circular=$((circular + 1))
            fi
        done
    done < <(find "$src_dir" -maxdepth 3 -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/dist/*" \
        -print0 2>/dev/null)

    if [[ $circular -gt 0 ]]; then
        violations=$((violations + circular))
        AG_ISSUES+=("[ARCH] 循環依存: ${circular}組のモジュール間循環依存を検出")
        AG_RECOMMENDATIONS+=("循環依存を解消してください。共通部分を別モジュールに抽出するか、依存注入パターンを使用してください")
    fi

    # Check 3: Directory structure conventions
    if [[ -f "${project_dir}/package.json" ]]; then
        # Next.js should have app/ or pages/
        if [[ -f "${project_dir}/next.config.js" || -f "${project_dir}/next.config.mjs" || -f "${project_dir}/next.config.ts" ]]; then
            if [[ ! -d "${project_dir}/app" && ! -d "${project_dir}/pages" && ! -d "${project_dir}/src/app" && ! -d "${project_dir}/src/pages" ]]; then
                violations=$((violations + 1))
                AG_ISSUES+=("[ARCH] Next.js プロジェクトに app/ または pages/ ディレクトリがありません")
            fi
        fi
    fi

    AG_ARCH_VIOLATIONS=$violations
    AG_CIRCULAR_DEPS=$circular
    AG_LAYER_VIOLATIONS=$layer_viol

    _ag_log "SUCCESS" "アーキテクチャチェック完了: 違反=${violations}件 (レイヤー=${layer_viol}, 循環=${circular})"
    echo "$violations"
    return 0
}

# ============================================================
# Naming convention enforcement
# ============================================================
ag_check_naming() {
    local project_dir="${1:-$AG_PROJECT_DIR}"
    local naming_violations=0
    local file_violations=0
    local func_violations=0

    _ag_log "SUCCESS" "命名規約チェック開始..."

    local src_dir="${project_dir}/src"
    [[ ! -d "$src_dir" ]] && src_dir="${project_dir}/app"
    [[ ! -d "$src_dir" ]] && { _ag_log "WARN" "ソースディレクトリが見つかりません"; echo "0"; return 0; }

    # Check 1: File naming conventions
    # Component files: PascalCase (.tsx/.jsx) or kebab-case
    # Utility files: camelCase or kebab-case
    while IFS= read -r -d '' file; do
        local basename
        basename=$(basename "$file")
        local relpath="${file#$project_dir/}"

        # Skip config and special files
        [[ "$basename" =~ ^(index|layout|page|loading|error|not-found|middleware|route)\. ]] && continue
        [[ "$basename" =~ ^\. ]] && continue
        [[ "$basename" =~ ^_ ]] && continue

        # Check component files for PascalCase
        if [[ "$basename" =~ \.(tsx|jsx)$ ]]; then
            local name_part="${basename%%.*}"
            # PascalCase: starts with uppercase, no hyphens unless kebab-case
            if [[ ! "$name_part" =~ ^[A-Z] && ! "$name_part" =~ ^[a-z]+(-[a-z]+)*$ ]]; then
                file_violations=$((file_violations + 1))
                naming_violations=$((naming_violations + 1))
            fi
        fi

        # Check utility/lib files for camelCase or kebab-case
        if [[ "$relpath" =~ (utils|lib|helpers|hooks)/ && "$basename" =~ \.(ts|js)$ ]]; then
            local name_part="${basename%%.*}"
            # Should be camelCase or kebab-case (not UPPER_SNAKE or random)
            if [[ "$name_part" =~ ^[A-Z][A-Z_]+$ ]]; then
                file_violations=$((file_violations + 1))
                naming_violations=$((naming_violations + 1))
            fi
        fi
    done < <(find "$src_dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/dist/*" \
        -print0 2>/dev/null)

    # Check 2: Function naming conventions in source files
    local file_count=0
    local max_files=50
    while IFS= read -r -d '' file; do
        [[ $file_count -ge $max_files ]] && break
        file_count=$((file_count + 1))

        local content
        content=$(cat "$file" 2>/dev/null) || continue

        # Detect exported functions that don't follow conventions
        # React components should be PascalCase: export function MyComponent
        # Regular functions should be camelCase: export function myFunction

        # Check for UPPER_SNAKE function names (should be constants, not functions)
        local bad_funcs
        bad_funcs=$(echo "$content" | grep -cE 'function\s+[A-Z][A-Z_]+\s*\(' 2>/dev/null || echo "0")
        bad_funcs="${bad_funcs%%[!0-9]*}"
        bad_funcs="${bad_funcs:-0}"
        if [[ "$bad_funcs" -gt 0 ]]; then
            func_violations=$((func_violations + bad_funcs))
            naming_violations=$((naming_violations + bad_funcs))
        fi

        # Check for constants that aren't UPPER_SNAKE_CASE
        # Look for: export const myVar = "hardcoded" (should be UPPER_SNAKE if it's a constant)
        local non_const_exports
        non_const_exports=$(echo "$content" | grep -cE 'export\s+const\s+[a-z][a-zA-Z]*\s*=\s*["\x27]' 2>/dev/null || echo "0")
        non_const_exports="${non_const_exports%%[!0-9]*}"
        non_const_exports="${non_const_exports:-0}"
        # This is a softer check - only flag if many occur
        if [[ "$non_const_exports" -gt 5 ]]; then
            func_violations=$((func_violations + 1))
            naming_violations=$((naming_violations + 1))
            AG_ISSUES+=("[NAMING] 多数のcamelCase定数エクスポートを検出 - UPPER_SNAKE_CASEの使用を検討してください")
        fi

    done < <(find "$src_dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/dist/*" \
        -print0 2>/dev/null)

    if [[ $file_violations -gt 0 ]]; then
        AG_ISSUES+=("[NAMING] ファイル命名規約違反: ${file_violations}件")
        AG_RECOMMENDATIONS+=("コンポーネントファイルはPascalCase、ユーティリティファイルはcamelCaseまたはkebab-caseで命名してください")
    fi
    if [[ $func_violations -gt 0 ]]; then
        AG_ISSUES+=("[NAMING] 関数命名規約違反: ${func_violations}件")
        AG_RECOMMENDATIONS+=("関数はcamelCase、コンポーネントはPascalCase、定数はUPPER_SNAKE_CASEで命名してください")
    fi

    AG_NAMING_VIOLATIONS=$naming_violations
    AG_FILE_NAMING_VIOLATIONS=$file_violations
    AG_FUNC_NAMING_VIOLATIONS=$func_violations

    _ag_log "SUCCESS" "命名規約チェック完了: 違反=${naming_violations}件 (ファイル=${file_violations}, 関数=${func_violations})"
    echo "$naming_violations"
    return 0
}

# ============================================================
# Technical debt detection
# ============================================================
ag_check_tech_debt() {
    local project_dir="${1:-$AG_PROJECT_DIR}"
    local total_debt=0

    _ag_log "SUCCESS" "技術的負債検出開始..."

    local src_dir="${project_dir}/src"
    [[ ! -d "$src_dir" ]] && src_dir="${project_dir}/app"
    [[ ! -d "$src_dir" ]] && src_dir="$project_dir"

    # Check 1: Count TODO/FIXME/HACK/XXX comments
    local todo_count=0
    local fixme_count=0
    local hack_count=0

    if [[ -d "$src_dir" ]]; then
        todo_count=$(grep -rl "TODO" "$src_dir" \
            --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.py" \
            2>/dev/null | wc -l | tr -d ' ' || echo "0")
        fixme_count=$(grep -rl "FIXME" "$src_dir" \
            --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.py" \
            2>/dev/null | wc -l | tr -d ' ' || echo "0")
        hack_count=$(grep -rl "HACK\|XXX" "$src_dir" \
            --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.py" \
            2>/dev/null | wc -l | tr -d ' ' || echo "0")
    fi

    AG_TODO_COUNT=$todo_count
    AG_FIXME_COUNT=$fixme_count
    AG_HACK_COUNT=$hack_count
    total_debt=$((todo_count + fixme_count + hack_count))

    if [[ $todo_count -gt 5 ]]; then
        AG_ISSUES+=("[DEBT] TODO コメント: ${todo_count}ファイル - 未完了のタスクが多数残存")
    fi
    if [[ $fixme_count -gt 0 ]]; then
        AG_ISSUES+=("[DEBT] FIXME コメント: ${fixme_count}ファイル - 修正が必要な箇所が残存")
    fi
    if [[ $hack_count -gt 0 ]]; then
        AG_ISSUES+=("[DEBT] HACK/XXX コメント: ${hack_count}ファイル - 応急処置コードが残存")
        AG_RECOMMENDATIONS+=("HACK/XXXコメントの箇所を正式な実装に置き換えてください")
    fi

    # Check 2: Detect large files (>500 lines)
    local large_files=0
    while IFS= read -r -d '' file; do
        local line_count
        line_count=$(wc -l < "$file" 2>/dev/null || echo "0")
        line_count=$(echo "$line_count" | tr -d ' ')
        if [[ "$line_count" -gt 500 ]]; then
            large_files=$((large_files + 1))
        fi
    done < <(find "$src_dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" -o -name "*.py" \) \
        -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/dist/*" \
        -print0 2>/dev/null)

    AG_LARGE_FILES=$large_files
    total_debt=$((total_debt + large_files))
    if [[ $large_files -gt 0 ]]; then
        AG_ISSUES+=("[DEBT] 巨大ファイル: ${large_files}件が500行超 - 分割を検討してください")
        AG_RECOMMENDATIONS+=("500行を超えるファイルを機能単位で分割してください。単一責任の原則に従ってリファクタリングしてください")
    fi

    # Check 3: Find duplicated code patterns (simple hash-based detection)
    local duplicate_patterns=0
    if [[ -d "$src_dir" ]]; then
        # Simple: check for files with very similar content by looking for repeated blocks
        local -A seen_blocks=()
        local max_check=30
        local checked=0
        while IFS= read -r -d '' file; do
            [[ $checked -ge $max_check ]] && break
            checked=$((checked + 1))
            # Hash the first 20 non-empty lines as a signature
            local sig
            sig=$(grep -v '^\s*$' "$file" 2>/dev/null | head -20 | md5sum 2>/dev/null | awk '{print $1}' || echo "")
            [[ -z "$sig" ]] && continue
            if [[ -n "${seen_blocks[$sig]:-}" ]]; then
                duplicate_patterns=$((duplicate_patterns + 1))
            fi
            seen_blocks["$sig"]="$file"
        done < <(find "$src_dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
            -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/dist/*" \
            -print0 2>/dev/null)
    fi

    AG_DUPLICATE_PATTERNS=$duplicate_patterns
    total_debt=$((total_debt + duplicate_patterns))
    if [[ $duplicate_patterns -gt 0 ]]; then
        AG_ISSUES+=("[DEBT] 重複コードパターン: ${duplicate_patterns}件 - 共通化を検討してください")
    fi

    # Check 4: Deprecated API usage patterns
    local deprecated_count=0
    if [[ -d "$src_dir" ]]; then
        # React deprecated patterns
        deprecated_count=$((deprecated_count + $(grep -rl "componentWillMount\|componentWillReceiveProps\|componentWillUpdate" "$src_dir" \
            --include="*.tsx" --include="*.jsx" --include="*.ts" --include="*.js" \
            2>/dev/null | wc -l | tr -d ' ' || echo "0")))
        # Node.js deprecated patterns
        deprecated_count=$((deprecated_count + $(grep -rl "new Buffer(" "$src_dir" \
            --include="*.ts" --include="*.js" \
            2>/dev/null | wc -l | tr -d ' ' || echo "0")))
        # Express deprecated patterns
        deprecated_count=$((deprecated_count + $(grep -rl "res\.send(status)" "$src_dir" \
            --include="*.ts" --include="*.js" \
            2>/dev/null | wc -l | tr -d ' ' || echo "0")))
    fi

    AG_DEPRECATED_USAGE=$deprecated_count
    total_debt=$((total_debt + deprecated_count))
    if [[ $deprecated_count -gt 0 ]]; then
        AG_ISSUES+=("[DEBT] 非推奨API使用: ${deprecated_count}ファイル - 最新APIへ移行してください")
        AG_RECOMMENDATIONS+=("非推奨APIを最新版に移行してください: componentWillMount -> useEffect, new Buffer -> Buffer.from 等")
    fi

    AG_TECH_DEBT_TOTAL=$total_debt
    _ag_log "SUCCESS" "技術的負債検出完了: 合計=${total_debt}件 (TODO=${todo_count}, FIXME=${fixme_count}, HACK=${hack_count}, 巨大ファイル=${large_files}, 重複=${duplicate_patterns}, 非推奨=${deprecated_count})"
    echo "$total_debt"
    return 0
}

# ============================================================
# Dependency governance
# ============================================================
ag_check_dependency_policy() {
    local project_dir="${1:-$AG_PROJECT_DIR}"
    local issues=0

    _ag_log "SUCCESS" "依存関係ガバナンスチェック開始..."

    # Only applicable to Node.js projects
    if [[ ! -f "${project_dir}/package.json" ]]; then
        _ag_log "WARN" "package.json が見つかりません - スキップ"
        echo "0"
        return 0
    fi

    # Check 1: Total dependency count
    local total_deps
    total_deps=$(python3 -c "
import json
try:
    d = json.load(open('${project_dir}/package.json'))
    deps = len(d.get('dependencies', {}))
    dev_deps = len(d.get('devDependencies', {}))
    print(deps + dev_deps)
except: print(0)
" 2>/dev/null || echo "0")

    AG_TOTAL_DEPS=$total_deps

    if [[ "$total_deps" -gt "$AG_MAX_DEPS_THRESHOLD" ]]; then
        issues=$((issues + 1))
        AG_ISSUES+=("[DEP] 依存関係が多すぎます: ${total_deps}個 (閾値: ${AG_MAX_DEPS_THRESHOLD})")
        AG_RECOMMENDATIONS+=("不要な依存関係を削除し、類似機能のパッケージを統合してください")
    fi

    # Check 2: License compatibility (detect copyleft licenses)
    local license_issues=0
    if [[ -d "${project_dir}/node_modules" ]]; then
        # Quick scan for GPL-licensed packages
        local gpl_count
        gpl_count=$(find "${project_dir}/node_modules" -maxdepth 2 -name "package.json" -print0 2>/dev/null | \
            xargs -0 grep -l '"GPL\|"AGPL\|"LGPL' 2>/dev/null | wc -l | tr -d ' ' || echo "0")
        if [[ "$gpl_count" -gt 0 ]]; then
            license_issues=$gpl_count
            issues=$((issues + 1))
            AG_ISSUES+=("[DEP] GPL/AGPL ライセンスの依存関係: ${gpl_count}件 - ライセンス互換性を確認してください")
        fi
    fi

    AG_LICENSE_ISSUES=$license_issues

    # Check 3: Detect bloated packages (known heavy dependencies)
    local bloated=0
    local heavy_packages=("moment" "lodash" "aws-sdk" "firebase" "rxjs")
    for pkg in "${heavy_packages[@]}"; do
        if grep -q "\"${pkg}\"" "${project_dir}/package.json" 2>/dev/null; then
            # Check if it's in dependencies (not devDependencies)
            local in_prod
            in_prod=$(python3 -c "
import json
try:
    d = json.load(open('${project_dir}/package.json'))
    deps = d.get('dependencies', {})
    print('1' if '${pkg}' in deps else '0')
except: print('0')
" 2>/dev/null || echo "0")
            if [[ "$in_prod" == "1" ]]; then
                bloated=$((bloated + 1))
            fi
        fi
    done

    AG_BLOATED_PACKAGES=$bloated
    if [[ $bloated -gt 0 ]]; then
        issues=$((issues + 1))
        AG_ISSUES+=("[DEP] 重量級パッケージ: ${bloated}件 - 軽量代替を検討してください")
        AG_RECOMMENDATIONS+=("moment -> dayjs, lodash -> lodash-es, aws-sdk -> @aws-sdk/client-* に置き換えてください")
    fi

    _ag_log "SUCCESS" "依存関係ガバナンス完了: 問題=${issues}件 (総依存=${total_deps}, ライセンス=${license_issues}, 重量級=${bloated})"
    echo "$issues"
    return 0
}

# ============================================================
# Run all governance checks
# ============================================================
ag_enforce() {
    local project_dir="${1:-$AG_PROJECT_DIR}"

    if [[ "$AG_ENABLED" != "true" ]]; then
        _ag_log "WARN" "Governance Engine 無効"
        return 1
    fi

    _ag_log "SUCCESS" "=== Governance Enforcement 開始 ==="

    ag_load_rules "$project_dir"
    ag_check_architecture "$project_dir"
    ag_check_naming "$project_dir"
    ag_check_tech_debt "$project_dir"
    ag_check_dependency_policy "$project_dir"
    ag_score

    _ag_log "SUCCESS" "=== Governance Enforcement 完了: スコア=${AG_SCORE}/100 ==="
    echo "$AG_SCORE"
    return 0
}

# ============================================================
# Score (0-100)
# ============================================================
ag_score() {
    local score=100

    # Rules loaded bonus/penalty
    if [[ $AG_RULES_LOADED -eq 0 ]]; then
        score=$((score - 10))
    fi

    # Architecture violations penalty
    if [[ $AG_ARCH_VIOLATIONS -gt 0 ]]; then
        local arch_penalty=$((AG_ARCH_VIOLATIONS * 5))
        [[ $arch_penalty -gt 25 ]] && arch_penalty=25
        score=$((score - arch_penalty))
    fi

    # Naming violations penalty
    if [[ $AG_NAMING_VIOLATIONS -gt 0 ]]; then
        local naming_penalty=$((AG_NAMING_VIOLATIONS * 2))
        [[ $naming_penalty -gt 15 ]] && naming_penalty=15
        score=$((score - naming_penalty))
    fi

    # Tech debt penalty
    if [[ $AG_TECH_DEBT_TOTAL -gt 20 ]]; then
        score=$((score - 20))
    elif [[ $AG_TECH_DEBT_TOTAL -gt 10 ]]; then
        score=$((score - 15))
    elif [[ $AG_TECH_DEBT_TOTAL -gt 5 ]]; then
        score=$((score - 10))
    elif [[ $AG_TECH_DEBT_TOTAL -gt 0 ]]; then
        score=$((score - 5))
    fi

    # Large files penalty
    if [[ $AG_LARGE_FILES -gt 5 ]]; then
        score=$((score - 10))
    elif [[ $AG_LARGE_FILES -gt 0 ]]; then
        score=$((score - 5))
    fi

    # Dependency policy penalty
    if [[ $AG_TOTAL_DEPS -gt $AG_MAX_DEPS_THRESHOLD ]]; then
        score=$((score - 10))
    fi
    if [[ $AG_LICENSE_ISSUES -gt 0 ]]; then
        local lic_penalty=$((AG_LICENSE_ISSUES * 3))
        [[ $lic_penalty -gt 10 ]] && lic_penalty=10
        score=$((score - lic_penalty))
    fi
    if [[ $AG_BLOATED_PACKAGES -gt 0 ]]; then
        local bloat_penalty=$((AG_BLOATED_PACKAGES * 2))
        [[ $bloat_penalty -gt 10 ]] && bloat_penalty=10
        score=$((score - bloat_penalty))
    fi

    [[ $score -lt 0 ]] && score=0
    AG_SCORE=$score

    echo "$score"
    return 0
}

# ============================================================
# Report
# ============================================================
ag_report() {
    echo -e "  ${BOLD:-}${CYAN:-}+============================================+${NC:-}"
    echo -e "  ${BOLD:-}${CYAN:-}|  Governance Engine Report (v30.0)           |${NC:-}"
    echo -e "  ${BOLD:-}${CYAN:-}+============================================+${NC:-}"
    echo -e "  プロジェクト:         ${AG_PROJECT_DIR}"
    echo -e "  検出ルール数:         ${AG_RULES_LOADED}"
    echo -e "    ESLint:             ${AG_HAS_ESLINT}"
    echo -e "    Prettier:           ${AG_HAS_PRETTIER}"
    echo -e "    TypeScript:         ${AG_HAS_TSCONFIG}"
    echo -e "    EditorConfig:       ${AG_HAS_EDITORCONFIG}"
    echo ""
    echo -e "  ${BOLD:-}アーキテクチャ:${NC:-}"
    echo -e "    違反数:             ${AG_ARCH_VIOLATIONS}"
    echo -e "    レイヤー違反:       ${AG_LAYER_VIOLATIONS}"
    echo -e "    循環依存:           ${AG_CIRCULAR_DEPS}"
    echo ""
    echo -e "  ${BOLD:-}命名規約:${NC:-}"
    echo -e "    違反数:             ${AG_NAMING_VIOLATIONS}"
    echo -e "    ファイル名:         ${AG_FILE_NAMING_VIOLATIONS}"
    echo -e "    関数名:             ${AG_FUNC_NAMING_VIOLATIONS}"
    echo ""
    echo -e "  ${BOLD:-}技術的負債:${NC:-}"
    echo -e "    TODO:               ${AG_TODO_COUNT} ファイル"
    echo -e "    FIXME:              ${AG_FIXME_COUNT} ファイル"
    echo -e "    HACK/XXX:           ${AG_HACK_COUNT} ファイル"
    echo -e "    巨大ファイル:       ${AG_LARGE_FILES}"
    echo -e "    重複パターン:       ${AG_DUPLICATE_PATTERNS}"
    echo -e "    非推奨API:          ${AG_DEPRECATED_USAGE}"
    echo ""
    echo -e "  ${BOLD:-}依存関係ガバナンス:${NC:-}"
    echo -e "    総依存数:           ${AG_TOTAL_DEPS}"
    echo -e "    ライセンス問題:     ${AG_LICENSE_ISSUES}"
    echo -e "    重量級パッケージ:   ${AG_BLOATED_PACKAGES}"
    echo ""

    local score_color="${GREEN:-}"
    [[ "$AG_SCORE" -lt 80 ]] && score_color="${YELLOW:-}"
    [[ "$AG_SCORE" -lt 60 ]] && score_color="${RED:-}"
    echo -e "  ガバナンススコア: ${score_color}${AG_SCORE}/100${NC:-}"

    if [[ ${#AG_ISSUES[@]} -gt 0 ]]; then
        echo ""
        echo -e "  ${BOLD:-}検出事項:${NC:-}"
        for issue in "${AG_ISSUES[@]}"; do
            echo -e "    ${YELLOW:-}${issue}${NC:-}"
        done
    fi

    if [[ ${#AG_RECOMMENDATIONS[@]} -gt 0 ]]; then
        echo ""
        echo -e "  ${BOLD:-}改善提案:${NC:-}"
        local i=1
        for rec in "${AG_RECOMMENDATIONS[@]}"; do
            echo -e "    ${CYAN:-}${i}.${NC:-} ${rec}"
            i=$((i + 1))
        done
    fi
}

# ============================================================
# JSON Report
# ============================================================
ag_report_json() {
    local issues_json="["
    local first=1
    for issue in "${AG_ISSUES[@]}"; do
        [[ $first -eq 0 ]] && issues_json+=","
        first=0
        local escaped
        escaped=$(echo "$issue" | sed 's/\\/\\\\/g; s/"/\\"/g')
        issues_json+="\"${escaped}\""
    done
    issues_json+="]"

    local recs_json="["
    first=1
    for rec in "${AG_RECOMMENDATIONS[@]}"; do
        [[ $first -eq 0 ]] && recs_json+=","
        first=0
        local escaped
        escaped=$(echo "$rec" | sed 's/\\/\\\\/g; s/"/\\"/g')
        recs_json+="\"${escaped}\""
    done
    recs_json+="]"

    cat <<EOF
{
    "module": "governance-engine",
    "version": "${AG_VERSION}",
    "session_id": "${AG_SESSION_ID}",
    "project_dir": "${AG_PROJECT_DIR}",
    "rules_loaded": ${AG_RULES_LOADED},
    "rules": {
        "eslint": ${AG_HAS_ESLINT},
        "prettier": ${AG_HAS_PRETTIER},
        "tsconfig": ${AG_HAS_TSCONFIG},
        "editorconfig": ${AG_HAS_EDITORCONFIG}
    },
    "architecture": {
        "violations": ${AG_ARCH_VIOLATIONS},
        "layer_violations": ${AG_LAYER_VIOLATIONS},
        "circular_deps": ${AG_CIRCULAR_DEPS}
    },
    "naming": {
        "violations": ${AG_NAMING_VIOLATIONS},
        "file_violations": ${AG_FILE_NAMING_VIOLATIONS},
        "func_violations": ${AG_FUNC_NAMING_VIOLATIONS}
    },
    "tech_debt": {
        "total": ${AG_TECH_DEBT_TOTAL},
        "todo": ${AG_TODO_COUNT},
        "fixme": ${AG_FIXME_COUNT},
        "hack": ${AG_HACK_COUNT},
        "large_files": ${AG_LARGE_FILES},
        "duplicates": ${AG_DUPLICATE_PATTERNS},
        "deprecated": ${AG_DEPRECATED_USAGE}
    },
    "dependency_policy": {
        "total_deps": ${AG_TOTAL_DEPS},
        "license_issues": ${AG_LICENSE_ISSUES},
        "bloated_packages": ${AG_BLOATED_PACKAGES}
    },
    "score": ${AG_SCORE},
    "issues": ${issues_json},
    "recommendations": ${recs_json}
}
EOF
}
