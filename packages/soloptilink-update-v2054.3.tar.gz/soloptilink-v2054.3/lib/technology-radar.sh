#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v485.0 - Technology Radar Engine
# =============================================================================
# 技術トレンドの追跡・評価・推薦を行うエンジン。
# Adopt/Trial/Assess/Hold の4象限で技術を分類し、
# プロジェクト要件に最適な技術スタックを推薦する。
#
# Functions:
#   _tr_init                - 初期化
#   _tr_track_trends        - 技術トレンド追跡
#   _tr_evaluate_technology - 技術の評価
#   _tr_recommend_stack     - スタック推薦
#   _tr_compare             - 技術比較
#   _tr_report              - レポート出力
#   _tr_score               - モジュールスコア(0-100)
#
# Globals: TR_ prefix
# =============================================================================

[[ -n "${_TECHNOLOGY_RADAR_LOADED:-}" ]] && return 0
_TECHNOLOGY_RADAR_LOADED=1

TR_VERSION="485.0"
TR_INITIALIZED=false

# --- Storage ---
TR_DATA_DIR=""
TR_RADAR_FILE=""
TR_EVALUATION_LOG=""

# --- State ---
TR_TOTAL_TECHNOLOGIES=0
TR_EVALUATIONS_DONE=0
TR_RECOMMENDATIONS_MADE=0

# --- Radar Categories ---
declare -g -A _TR_ADOPT=()
declare -g -A _TR_TRIAL=()
declare -g -A _TR_ASSESS=()
declare -g -A _TR_HOLD=()
declare -g -A _TR_TECH_SCORES=()
declare -g -A _TR_TECH_CATEGORY=()

# =============================================================================
# 初期化
# =============================================================================
_tr_init() {
    local project_dir="${PROJECT_DIR:-.}"
    TR_DATA_DIR="${project_dir}/.soloptilink/tr"
    TR_RADAR_FILE="${TR_DATA_DIR}/radar.json"
    TR_EVALUATION_LOG="${TR_DATA_DIR}/evaluations.jsonl"

    mkdir -p "$TR_DATA_DIR"

    # テクノロジーレーダーの構築
    _tr_build_radar

    TR_TOTAL_TECHNOLOGIES=$(( ${#_TR_ADOPT[@]} + ${#_TR_TRIAL[@]} + ${#_TR_ASSESS[@]} + ${#_TR_HOLD[@]} ))

    TR_INITIALIZED=true
    return 0
}

_tr_build_radar() {
    # === ADOPT (推奨・本番利用) ===
    _TR_ADOPT["nextjs"]="Next.js 15: App Router/RSC/ISR、フルスタックReactフレームワーク"
    _TR_ADOPT["typescript"]="TypeScript 5.x: 型安全の標準"
    _TR_ADOPT["prisma"]="Prisma ORM: 型安全なデータベースアクセス"
    _TR_ADOPT["tailwindcss"]="Tailwind CSS 4: ユーティリティファーストCSS"
    _TR_ADOPT["zod"]="Zod: ランタイム型バリデーション"
    _TR_ADOPT["react"]="React 19: UIライブラリの標準"
    _TR_ADOPT["postgresql"]="PostgreSQL 16: リレーショナルDB"
    _TR_ADOPT["vitest"]="Vitest: 高速テストランナー"
    _TR_ADOPT["eslint"]="ESLint 9: コード品質"
    _TR_ADOPT["docker"]="Docker: コンテナ化"
    _TR_TECH_CATEGORY["nextjs"]="framework"
    _TR_TECH_CATEGORY["typescript"]="language"
    _TR_TECH_CATEGORY["prisma"]="orm"
    _TR_TECH_CATEGORY["tailwindcss"]="styling"
    _TR_TECH_CATEGORY["zod"]="validation"
    _TR_TECH_CATEGORY["react"]="ui"
    _TR_TECH_CATEGORY["postgresql"]="database"
    _TR_TECH_CATEGORY["vitest"]="testing"
    _TR_TECH_CATEGORY["eslint"]="quality"
    _TR_TECH_CATEGORY["docker"]="infra"

    # === TRIAL (試験的利用推奨) ===
    _TR_TRIAL["drizzle"]="Drizzle ORM: 軽量・高性能ORM"
    _TR_TRIAL["trpc"]="tRPC: 型安全なAPI通信"
    _TR_TRIAL["turbo"]="Turborepo: モノレポツール"
    _TR_TRIAL["bun"]="Bun: 高速JSランタイム"
    _TR_TRIAL["shadcn"]="shadcn/ui: コピペ可能なUIコンポーネント"
    _TR_TRIAL["playwright"]="Playwright: E2Eテスト"
    _TR_TRIAL["zustand"]="Zustand: 軽量状態管理"
    _TR_TECH_CATEGORY["drizzle"]="orm"
    _TR_TECH_CATEGORY["trpc"]="api"
    _TR_TECH_CATEGORY["turbo"]="tooling"
    _TR_TECH_CATEGORY["bun"]="runtime"
    _TR_TECH_CATEGORY["shadcn"]="ui"
    _TR_TECH_CATEGORY["playwright"]="testing"
    _TR_TECH_CATEGORY["zustand"]="state"

    # === ASSESS (評価中) ===
    _TR_ASSESS["htmx"]="HTMX: サーバーサイドレンダリング拡張"
    _TR_ASSESS["effect"]="Effect-TS: 関数型エラーハンドリング"
    _TR_ASSESS["rspack"]="Rspack: Rust製バンドラ"
    _TR_ASSESS["biome"]="Biome: Rust製リンター/フォーマッタ"
    _TR_ASSESS["hono"]="Hono: 軽量Webフレームワーク"
    _TR_TECH_CATEGORY["htmx"]="framework"
    _TR_TECH_CATEGORY["effect"]="library"
    _TR_TECH_CATEGORY["rspack"]="tooling"
    _TR_TECH_CATEGORY["biome"]="quality"
    _TR_TECH_CATEGORY["hono"]="framework"

    # === HOLD (非推奨) ===
    _TR_HOLD["cra"]="Create React App: メンテ終了、Next.js/Viteに移行"
    _TR_HOLD["moment"]="Moment.js: メンテモード、date-fns/Day.jsに移行"
    _TR_HOLD["express_alone"]="Express単体: Next.jsのAPI Routeで代替可能"
    _TR_HOLD["typeorm"]="TypeORM: 型安全性不足、Prisma/Drizzleに移行"
    _TR_HOLD["enzyme"]="Enzyme: React 18+非対応、Testing Libraryに移行"
    _TR_TECH_CATEGORY["cra"]="framework"
    _TR_TECH_CATEGORY["moment"]="library"
    _TR_TECH_CATEGORY["express_alone"]="framework"
    _TR_TECH_CATEGORY["typeorm"]="orm"
    _TR_TECH_CATEGORY["enzyme"]="testing"
}

# =============================================================================
# 技術トレンド追跡
# =============================================================================
_tr_track_trends() {
    [[ "$TR_INITIALIZED" != "true" ]] && _tr_init

    echo "=== Technology Radar v${TR_VERSION} ==="
    echo "ADOPT (${#_TR_ADOPT[@]} technologies):"
    for tech in "${!_TR_ADOPT[@]}"; do
        echo "  [ADOPT] ${tech}: ${_TR_ADOPT[$tech]}"
    done
    echo "TRIAL (${#_TR_TRIAL[@]} technologies):"
    for tech in "${!_TR_TRIAL[@]}"; do
        echo "  [TRIAL] ${tech}: ${_TR_TRIAL[$tech]}"
    done
    echo "ASSESS (${#_TR_ASSESS[@]} technologies):"
    for tech in "${!_TR_ASSESS[@]}"; do
        echo "  [ASSESS] ${tech}: ${_TR_ASSESS[$tech]}"
    done
    echo "HOLD (${#_TR_HOLD[@]} technologies):"
    for tech in "${!_TR_HOLD[@]}"; do
        echo "  [HOLD] ${tech}: ${_TR_HOLD[$tech]}"
    done
}

# =============================================================================
# 技術の評価
# =============================================================================
_tr_evaluate_technology() {
    local tech="$1"
    local criteria="${2:-all}"

    [[ "$TR_INITIALIZED" != "true" ]] && _tr_init

    local score=50
    local quadrant="unknown"

    if [[ -n "${_TR_ADOPT[$tech]:-}" ]]; then
        quadrant="adopt"
        score=90
    elif [[ -n "${_TR_TRIAL[$tech]:-}" ]]; then
        quadrant="trial"
        score=70
    elif [[ -n "${_TR_ASSESS[$tech]:-}" ]]; then
        quadrant="assess"
        score=50
    elif [[ -n "${_TR_HOLD[$tech]:-}" ]]; then
        quadrant="hold"
        score=20
    fi

    _TR_TECH_SCORES["$tech"]=$score
    TR_EVALUATIONS_DONE=$((TR_EVALUATIONS_DONE + 1))

    echo "${quadrant}:${score}"
    return 0
}

# =============================================================================
# スタック推薦
# =============================================================================
_tr_recommend_stack() {
    local domain="$1"
    local scale="${2:-small}"
    local priority="${3:-balanced}"

    [[ "$TR_INITIALIZED" != "true" ]] && _tr_init

    TR_RECOMMENDATIONS_MADE=$((TR_RECOMMENDATIONS_MADE + 1))

    local stack=""

    # フレームワーク
    stack+="framework:nextjs "

    # 言語
    stack+="language:typescript "

    # ORM
    case "$scale" in
        enterprise) stack+="orm:prisma " ;;
        small)
            case "$priority" in
                performance) stack+="orm:drizzle " ;;
                *) stack+="orm:prisma " ;;
            esac
            ;;
        *) stack+="orm:prisma " ;;
    esac

    # データベース
    case "$scale" in
        small)
            case "$domain" in
                blog|portfolio) stack+="db:sqlite " ;;
                *) stack+="db:postgresql " ;;
            esac
            ;;
        *) stack+="db:postgresql " ;;
    esac

    # スタイリング
    stack+="styling:tailwindcss "

    # UIコンポーネント
    stack+="ui:shadcn "

    # 状態管理
    case "$domain" in
        chat|saas|crm) stack+="state:zustand " ;;
        *) stack+="state:react-state " ;;
    esac

    # テスト
    stack+="testing:vitest "
    case "$scale" in
        enterprise|medium) stack+="e2e:playwright " ;;
    esac

    # バリデーション
    stack+="validation:zod "

    echo "${stack% }"
    return 0
}

# =============================================================================
# 技術比較
# =============================================================================
_tr_compare() {
    local tech_a="$1"
    local tech_b="$2"

    [[ "$TR_INITIALIZED" != "true" ]] && _tr_init

    _tr_evaluate_technology "$tech_a" >/dev/null
    _tr_evaluate_technology "$tech_b" >/dev/null

    local score_a="${_TR_TECH_SCORES[$tech_a]:-0}"
    local score_b="${_TR_TECH_SCORES[$tech_b]:-0}"

    if [[ $score_a -gt $score_b ]]; then
        echo "${tech_a} (${score_a}) > ${tech_b} (${score_b})"
    elif [[ $score_b -gt $score_a ]]; then
        echo "${tech_b} (${score_b}) > ${tech_a} (${score_a})"
    else
        echo "${tech_a} (${score_a}) = ${tech_b} (${score_b})"
    fi
}

# =============================================================================
# レポート
# =============================================================================
_tr_report() {
    echo -e "\n  ${BOLD:-}═══ Technology Radar v${TR_VERSION} ═══${NC:-}"
    echo -e "  総技術数           : ${TR_TOTAL_TECHNOLOGIES}"
    echo -e "  ADOPT              : ${#_TR_ADOPT[@]}"
    echo -e "  TRIAL              : ${#_TR_TRIAL[@]}"
    echo -e "  ASSESS             : ${#_TR_ASSESS[@]}"
    echo -e "  HOLD               : ${#_TR_HOLD[@]}"
    echo -e "  評価実行数         : ${TR_EVALUATIONS_DONE}"
    echo -e "  推薦実行数         : ${TR_RECOMMENDATIONS_MADE}"
}

_tr_score() {
    [[ "$TR_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=70
    [[ $TR_EVALUATIONS_DONE -gt 0 ]] && s=$((s + 10))
    [[ $TR_RECOMMENDATIONS_MADE -gt 0 ]] && s=$((s + 10))
    [[ $TR_TOTAL_TECHNOLOGIES -gt 20 ]] && s=$((s + 10))
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_tr_init_message() {
    echo -e "  ${GREEN:-}✅ v${TR_VERSION} technology-radar: テクノロジーレーダー (${TR_TOTAL_TECHNOLOGIES} technologies)${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "technology-radar" \
    --version "$TR_VERSION" \
    --description "テクノロジーレーダー" \
    --init "_tr_init" \
    --report "_tr_report" \
    --score "_tr_score" \
    --enable-var "ENABLE_TECHNOLOGY_RADAR" \
    --cli-flags "--technology-radar:--no-technology-radar" \
    --init-msg "_tr_init_message"
