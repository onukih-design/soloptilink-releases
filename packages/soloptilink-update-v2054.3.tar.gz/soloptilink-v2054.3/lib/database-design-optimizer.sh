#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v222.0 - Database Design Optimizer
# =============================================================================
# Generates optimal database schemas from natural language requirements.
# Applies normalization, suggests indexes, and outputs Prisma schema.
#
# Functions:
#   _ddo_design_schema()    - Design DB schema from requirements
#   _ddo_optimize_indexes() - Suggest optimal indexes for query patterns
#   _ddo_normalize()        - Apply normalization rules (1NF->3NF)
#   _ddo_generate_prisma()  - Generate Prisma schema from design
#   _ddo_detect_antipatterns() - Detect DB design anti-patterns
#   _ddo_suggest_relations()   - Suggest entity relationships
#
# All globals: DDO_ prefix
# =============================================================================

[[ -n "${_DDO_LOADED:-}" ]] && return 0
_DDO_LOADED=1

# --- Colors ---
readonly DDO_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly DDO_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly DDO_RED="${CLR_RED:-\033[0;31m}"
readonly DDO_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly DDO_BOLD="${CLR_BOLD:-\033[1m}"
readonly DDO_NC="${CLR_NC:-\033[0m}"

# --- State ---
declare -g DDO_VERSION="222.0"
declare -g DDO_INITIALIZED=false
declare -g DDO_SCHEMAS_DESIGNED=0
declare -g DDO_INDEXES_SUGGESTED=0
declare -g DDO_ANTIPATTERNS_FOUND=0
declare -g DDO_PRISMA_GENERATED=0

# =============================================================================
# Logging
# =============================================================================
_ddo_log()  { echo -e "  ${DDO_CYAN}[DDO]${DDO_NC} $*" >&2; }
_ddo_ok()   { echo -e "  ${DDO_GREEN}[DDO] OK${DDO_NC} $*" >&2; }
_ddo_warn() { echo -e "  ${DDO_YELLOW}[DDO] WARN${DDO_NC} $*" >&2; }
_ddo_err()  { echo -e "  ${DDO_RED}[DDO] ERR${DDO_NC} $*" >&2; }

# =============================================================================
# Init
# =============================================================================
ddo_init() {
    DDO_INITIALIZED=true
    DDO_SCHEMAS_DESIGNED=0
    DDO_INDEXES_SUGGESTED=0
    DDO_ANTIPATTERNS_FOUND=0
    DDO_PRISMA_GENERATED=0
    return 0
}

# =============================================================================
# _ddo_design_schema - Design database schema from natural language
# Usage: _ddo_design_schema "User management with roles and permissions"
# Output: JSON-like schema definition
# =============================================================================
_ddo_design_schema() {
    local requirements="${1:-}"
    local domain="${2:-${DOMAIN_TYPE:-general}}"
    [[ -z "$requirements" ]] && { _ddo_err "Requirements text required"; return 1; }

    _ddo_log "Designing schema for: ${requirements:0:60}..."

    local entities=()
    local req_lower
    req_lower=$(echo "$requirements" | tr '[:upper:]' '[:lower:]')

    # Entity extraction from requirements
    if echo "$req_lower" | grep -qE 'user|auth|login|account'; then
        entities+=("User")
    fi
    if echo "$req_lower" | grep -qE 'product|item|goods|inventory'; then
        entities+=("Product")
    fi
    if echo "$req_lower" | grep -qE 'order|purchase|cart|checkout'; then
        entities+=("Order" "OrderItem")
    fi
    if echo "$req_lower" | grep -qE 'post|article|blog|content'; then
        entities+=("Post" "Category")
    fi
    if echo "$req_lower" | grep -qE 'task|todo|project|ticket'; then
        entities+=("Task" "Project")
    fi
    if echo "$req_lower" | grep -qE 'message|chat|conversation'; then
        entities+=("Message" "Conversation")
    fi
    if echo "$req_lower" | grep -qE 'comment|review|feedback'; then
        entities+=("Comment")
    fi
    if echo "$req_lower" | grep -qE 'tag|label|category'; then
        entities+=("Tag")
    fi
    if echo "$req_lower" | grep -qE 'file|upload|attachment|image'; then
        entities+=("File")
    fi
    if echo "$req_lower" | grep -qE 'notification|alert'; then
        entities+=("Notification")
    fi
    if echo "$req_lower" | grep -qE 'invoice|billing|payment|subscription'; then
        entities+=("Invoice" "Payment")
    fi
    if echo "$req_lower" | grep -qE 'company|organization|tenant|team'; then
        entities+=("Company" "Team")
    fi
    if echo "$req_lower" | grep -qE 'role|permission|rbac'; then
        entities+=("Role" "Permission")
    fi
    if echo "$req_lower" | grep -qE 'setting|config|preference'; then
        entities+=("Setting")
    fi
    if echo "$req_lower" | grep -qE 'session|device'; then
        entities+=("Session")
    fi

    # Domain-based additions
    case "$domain" in
        crm)  entities+=("Contact" "Deal" "Activity") ;;
        ec)   entities+=("Product" "Cart" "Wishlist") ;;
        saas) entities+=("Tenant" "Subscription" "Plan") ;;
        blog) entities+=("Post" "Category" "Tag" "Comment") ;;
    esac

    # Deduplicate
    local unique_entities=()
    local seen=""
    for e in "${entities[@]}"; do
        if [[ ! "$seen" == *"|${e}|"* ]]; then
            unique_entities+=("$e")
            seen="${seen}|${e}|"
        fi
    done

    # Always include User if not present
    if [[ ! "$seen" == *"|User|"* ]]; then
        unique_entities=("User" "${unique_entities[@]}")
    fi

    # Output schema design
    echo "{"
    echo "  \"version\": \"${DDO_VERSION}\","
    echo "  \"domain\": \"${domain}\","
    echo "  \"entities\": ["
    local idx=0
    for entity in "${unique_entities[@]}"; do
        local fields
        fields=$(_ddo_entity_fields "$entity")
        [[ $idx -gt 0 ]] && echo ","
        echo "    {"
        echo "      \"name\": \"${entity}\","
        echo "      \"fields\": ${fields}"
        echo -n "    }"
        idx=$((idx + 1))
    done
    echo ""
    echo "  ],"
    echo "  \"relations\": ["
    _ddo_suggest_relations_json "${unique_entities[@]}"
    echo "  ]"
    echo "}"

    DDO_SCHEMAS_DESIGNED=$((DDO_SCHEMAS_DESIGNED + 1))
    _ddo_ok "Schema designed with ${#unique_entities[@]} entities"
}

# =============================================================================
# Entity field definitions
# =============================================================================
_ddo_entity_fields() {
    local entity="${1:-}"

    case "$entity" in
        User)
            echo '[{"name":"id","type":"String","attrs":"@id @default(cuid())"},{"name":"email","type":"String","attrs":"@unique"},{"name":"name","type":"String","attrs":""},{"name":"passwordHash","type":"String","attrs":""},{"name":"role","type":"String","attrs":"@default(\"user\")"},{"name":"emailVerified","type":"Boolean","attrs":"@default(false)"},{"name":"createdAt","type":"DateTime","attrs":"@default(now())"},{"name":"updatedAt","type":"DateTime","attrs":"@updatedAt"}]'
            ;;
        Product)
            echo '[{"name":"id","type":"String","attrs":"@id @default(cuid())"},{"name":"name","type":"String","attrs":""},{"name":"description","type":"String?","attrs":""},{"name":"price","type":"Decimal","attrs":""},{"name":"stock","type":"Int","attrs":"@default(0)"},{"name":"sku","type":"String","attrs":"@unique"},{"name":"status","type":"String","attrs":"@default(\"active\")"},{"name":"categoryId","type":"String?","attrs":""},{"name":"createdAt","type":"DateTime","attrs":"@default(now())"},{"name":"updatedAt","type":"DateTime","attrs":"@updatedAt"}]'
            ;;
        Order)
            echo '[{"name":"id","type":"String","attrs":"@id @default(cuid())"},{"name":"userId","type":"String","attrs":""},{"name":"status","type":"String","attrs":"@default(\"pending\")"},{"name":"total","type":"Decimal","attrs":""},{"name":"shippingAddress","type":"String?","attrs":""},{"name":"createdAt","type":"DateTime","attrs":"@default(now())"},{"name":"updatedAt","type":"DateTime","attrs":"@updatedAt"}]'
            ;;
        OrderItem)
            echo '[{"name":"id","type":"String","attrs":"@id @default(cuid())"},{"name":"orderId","type":"String","attrs":""},{"name":"productId","type":"String","attrs":""},{"name":"quantity","type":"Int","attrs":""},{"name":"price","type":"Decimal","attrs":""}]'
            ;;
        Post)
            echo '[{"name":"id","type":"String","attrs":"@id @default(cuid())"},{"name":"title","type":"String","attrs":""},{"name":"content","type":"String","attrs":""},{"name":"slug","type":"String","attrs":"@unique"},{"name":"published","type":"Boolean","attrs":"@default(false)"},{"name":"authorId","type":"String","attrs":""},{"name":"categoryId","type":"String?","attrs":""},{"name":"createdAt","type":"DateTime","attrs":"@default(now())"},{"name":"updatedAt","type":"DateTime","attrs":"@updatedAt"}]'
            ;;
        Task)
            echo '[{"name":"id","type":"String","attrs":"@id @default(cuid())"},{"name":"title","type":"String","attrs":""},{"name":"description","type":"String?","attrs":""},{"name":"status","type":"String","attrs":"@default(\"todo\")"},{"name":"priority","type":"String","attrs":"@default(\"medium\")"},{"name":"dueDate","type":"DateTime?","attrs":""},{"name":"assigneeId","type":"String?","attrs":""},{"name":"projectId","type":"String?","attrs":""},{"name":"createdAt","type":"DateTime","attrs":"@default(now())"},{"name":"updatedAt","type":"DateTime","attrs":"@updatedAt"}]'
            ;;
        *)
            echo '[{"name":"id","type":"String","attrs":"@id @default(cuid())"},{"name":"name","type":"String","attrs":""},{"name":"description","type":"String?","attrs":""},{"name":"status","type":"String","attrs":"@default(\"active\")"},{"name":"createdAt","type":"DateTime","attrs":"@default(now())"},{"name":"updatedAt","type":"DateTime","attrs":"@updatedAt"}]'
            ;;
    esac
}

# =============================================================================
# _ddo_suggest_relations_json - Output relations as JSON
# =============================================================================
_ddo_suggest_relations_json() {
    local entities=("$@")
    local first=true
    local has_user=false has_product=false has_order=false has_post=false has_task=false has_project=false

    for e in "${entities[@]}"; do
        case "$e" in
            User) has_user=true ;;
            Product) has_product=true ;;
            Order) has_order=true ;;
            Post) has_post=true ;;
            Task) has_task=true ;;
            Project) has_project=true ;;
        esac
    done

    if $has_user && $has_order; then
        $first || echo ","
        echo -n '    {"from":"Order","to":"User","type":"many-to-one","field":"userId"}'
        first=false
    fi
    if $has_user && $has_post; then
        $first || echo ","
        echo -n '    {"from":"Post","to":"User","type":"many-to-one","field":"authorId"}'
        first=false
    fi
    if $has_user && $has_task; then
        $first || echo ","
        echo -n '    {"from":"Task","to":"User","type":"many-to-one","field":"assigneeId"}'
        first=false
    fi
    if $has_task && $has_project; then
        $first || echo ","
        echo -n '    {"from":"Task","to":"Project","type":"many-to-one","field":"projectId"}'
        first=false
    fi
    if $has_order && $has_product; then
        $first || echo ","
        echo -n '    {"from":"OrderItem","to":"Order","type":"many-to-one","field":"orderId"}'
        $first || echo ","
        echo -n '    {"from":"OrderItem","to":"Product","type":"many-to-one","field":"productId"}'
        first=false
    fi
    echo ""
}

# =============================================================================
# _ddo_optimize_indexes - Suggest optimal indexes based on query patterns
# Usage: _ddo_optimize_indexes "/path/to/project"
# =============================================================================
_ddo_optimize_indexes() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local suggestions=()
    local score=100

    _ddo_log "Analyzing query patterns for index optimization..."

    # Find Prisma schema
    local schema_file
    schema_file=$(find "$project_dir" -name "schema.prisma" -not -path "*/node_modules/*" 2>/dev/null | head -1)

    if [[ -z "$schema_file" ]]; then
        _ddo_warn "No Prisma schema found in ${project_dir}"
        echo "[]"
        return 1
    fi

    # Scan for common query patterns in source
    local source_files
    source_files=$(find "$project_dir" -name "*.ts" -not -path "*/node_modules/*" 2>/dev/null)

    echo "["

    local idx=0
    # Check for findMany with where clauses
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue

        # Detect unindexed findMany with where
        if echo "$content" | grep -qE '\.findMany\(\s*\{[^}]*where.*email'; then
            [[ $idx -gt 0 ]] && echo ","
            echo "  {\"model\":\"User\",\"field\":\"email\",\"type\":\"unique\",\"reason\":\"Frequent email lookups\"}"
            idx=$((idx + 1))
        fi
        if echo "$content" | grep -qE '\.findMany\(\s*\{[^}]*where.*status'; then
            [[ $idx -gt 0 ]] && echo ","
            echo "  {\"model\":\"*\",\"field\":\"status\",\"type\":\"index\",\"reason\":\"Status filtering\"}"
            idx=$((idx + 1))
        fi
        if echo "$content" | grep -qE '\.findMany\(\s*\{[^}]*orderBy.*createdAt'; then
            [[ $idx -gt 0 ]] && echo ","
            echo "  {\"model\":\"*\",\"field\":\"createdAt\",\"type\":\"index\",\"reason\":\"Chronological ordering\"}"
            idx=$((idx + 1))
        fi
        if echo "$content" | grep -qE 'where.*userId'; then
            [[ $idx -gt 0 ]] && echo ","
            echo "  {\"model\":\"*\",\"field\":\"userId\",\"type\":\"index\",\"reason\":\"User-scoped queries\"}"
            idx=$((idx + 1))
        fi
    done <<< "$source_files"

    # Default index suggestions
    if [[ $idx -eq 0 ]]; then
        echo "  {\"model\":\"*\",\"field\":\"createdAt\",\"type\":\"index\",\"reason\":\"Default chronological ordering\"},"
        echo "  {\"model\":\"*\",\"field\":\"status\",\"type\":\"index\",\"reason\":\"Default status filtering\"}"
    fi

    echo "]"

    DDO_INDEXES_SUGGESTED=$((DDO_INDEXES_SUGGESTED + idx))
    _ddo_ok "Suggested ${idx} index optimizations"
}

# =============================================================================
# _ddo_normalize - Apply normalization rules (1NF -> 3NF)
# Usage: _ddo_normalize "/path/to/schema.prisma"
# =============================================================================
_ddo_normalize() {
    local schema_file="${1:-}"
    local issues=()
    local score=100

    if [[ -z "$schema_file" || ! -f "$schema_file" ]]; then
        _ddo_err "Schema file required"
        return 1
    fi

    _ddo_log "Checking normalization of ${schema_file}..."

    local content
    content=$(cat "$schema_file" 2>/dev/null)

    # 1NF: Check for array-like string fields (comma-separated values)
    if echo "$content" | grep -qE 'tags\s+String|categories\s+String|roles\s+String'; then
        issues+=("1NF_VIOLATION: String field likely stores multiple values (should be relation table)")
        score=$((score - 20))
    fi

    # 1NF: Check for JSON fields used for structured data
    local json_count
    json_count=$(echo "$content" | grep -cE '^\s+\w+\s+Json' || true)
    if [[ "$json_count" -gt 2 ]]; then
        issues+=("1NF_WARNING: ${json_count} JSON fields found (consider normalizing to separate tables)")
        score=$((score - 10))
    fi

    # 2NF: Check for composite-key-like patterns with redundant data
    if echo "$content" | grep -qE 'productName.*orderId|orderName.*productId'; then
        issues+=("2NF_VIOLATION: Redundant data in junction table (store only foreign keys)")
        score=$((score - 20))
    fi

    # 3NF: Check for transitive dependencies
    if echo "$content" | grep -qE 'cityName.*zipCode|stateName.*cityId'; then
        issues+=("3NF_VIOLATION: Transitive dependency detected (separate address components)")
        score=$((score - 15))
    fi

    # Check for missing timestamps
    local model_count
    model_count=$(echo "$content" | grep -c "^model " || true)
    local timestamp_count
    timestamp_count=$(echo "$content" | grep -c "createdAt" || true)
    if [[ "$timestamp_count" -lt "$model_count" ]]; then
        issues+=("BEST_PRACTICE: Not all models have createdAt/updatedAt timestamps")
        score=$((score - 5))
    fi

    # Check for missing soft delete
    if ! echo "$content" | grep -qE 'deletedAt'; then
        issues+=("RECOMMENDATION: Consider adding soft delete (deletedAt) for auditable models")
    fi

    # Check for missing indexes on foreign keys
    local fk_count
    fk_count=$(echo "$content" | grep -cE '\w+Id\s+String' || true)
    local idx_count
    idx_count=$(echo "$content" | grep -c "@@index" || true)
    if [[ "$fk_count" -gt "$idx_count" ]]; then
        issues+=("PERFORMANCE: ${fk_count} foreign keys but only ${idx_count} explicit indexes")
        score=$((score - 10))
    fi

    [[ $score -lt 0 ]] && score=0

    echo "{"
    echo "  \"score\": ${score},"
    echo "  \"normalization_level\": \"$(( score >= 80 ? 3 : score >= 60 ? 2 : 1 ))NF\","
    echo "  \"issues\": ["
    local first=true
    for issue in "${issues[@]}"; do
        $first || echo ","
        echo -n "    \"${issue}\""
        first=false
    done
    echo ""
    echo "  ]"
    echo "}"

    DDO_ANTIPATTERNS_FOUND=$((DDO_ANTIPATTERNS_FOUND + ${#issues[@]}))
    if [[ ${#issues[@]} -eq 0 ]]; then
        _ddo_ok "Schema is well-normalized (score: ${score})"
    else
        _ddo_warn "Found ${#issues[@]} normalization issues (score: ${score})"
    fi
}

# =============================================================================
# _ddo_generate_prisma - Generate Prisma schema from design
# Usage: _ddo_generate_prisma "User management with tasks" "general"
# =============================================================================
_ddo_generate_prisma() {
    local requirements="${1:-}"
    local domain="${2:-${DOMAIN_TYPE:-general}}"
    local db_provider="${3:-postgresql}"

    [[ -z "$requirements" ]] && { _ddo_err "Requirements required"; return 1; }

    _ddo_log "Generating Prisma schema..."

    local req_lower
    req_lower=$(echo "$requirements" | tr '[:upper:]' '[:lower:]')

    # Header
    cat <<EOF
// Generated by SoloptiLinkAI Database Design Optimizer v${DDO_VERSION}
// Domain: ${domain}

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "${db_provider}"
  url      = env("DATABASE_URL")
}

EOF

    # Always generate User model
    cat <<'EOF'
model User {
  id            String    @id @default(cuid())
  email         String    @unique
  name          String
  passwordHash  String
  role          String    @default("user")
  emailVerified Boolean   @default(false)
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt

EOF

    # Add User relations based on domain
    if echo "$req_lower" | grep -qE 'post|blog|article'; then
        echo "  posts         Post[]"
    fi
    if echo "$req_lower" | grep -qE 'task|todo|project'; then
        echo "  tasks         Task[]"
    fi
    if echo "$req_lower" | grep -qE 'order|purchase'; then
        echo "  orders        Order[]"
    fi
    if echo "$req_lower" | grep -qE 'comment|review'; then
        echo "  comments      Comment[]"
    fi
    if echo "$req_lower" | grep -qE 'notification'; then
        echo "  notifications Notification[]"
    fi

    echo ""
    echo "  @@index([email])"
    echo "  @@index([role])"
    echo "}"
    echo ""

    # Task/Project models
    if echo "$req_lower" | grep -qE 'task|todo'; then
        cat <<'EOF'
model Task {
  id          String    @id @default(cuid())
  title       String
  description String?
  status      String    @default("todo")
  priority    String    @default("medium")
  dueDate     DateTime?
  assigneeId  String?
  assignee    User?     @relation(fields: [assigneeId], references: [id])
  projectId   String?
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt

  @@index([assigneeId])
  @@index([status])
  @@index([projectId])
}

EOF
    fi

    # Post model
    if echo "$req_lower" | grep -qE 'post|blog|article'; then
        cat <<'EOF'
model Post {
  id         String    @id @default(cuid())
  title      String
  content    String
  slug       String    @unique
  published  Boolean   @default(false)
  authorId   String
  author     User      @relation(fields: [authorId], references: [id])
  createdAt  DateTime  @default(now())
  updatedAt  DateTime  @updatedAt

  @@index([authorId])
  @@index([published])
  @@index([slug])
}

EOF
    fi

    # Order models
    if echo "$req_lower" | grep -qE 'order|purchase|ec'; then
        cat <<'EOF'
model Order {
  id              String      @id @default(cuid())
  userId          String
  user            User        @relation(fields: [userId], references: [id])
  status          String      @default("pending")
  total           Decimal
  shippingAddress String?
  items           OrderItem[]
  createdAt       DateTime    @default(now())
  updatedAt       DateTime    @updatedAt

  @@index([userId])
  @@index([status])
}

model OrderItem {
  id        String  @id @default(cuid())
  orderId   String
  order     Order   @relation(fields: [orderId], references: [id], onDelete: Cascade)
  productId String
  quantity  Int
  price     Decimal

  @@index([orderId])
  @@index([productId])
}

model Product {
  id          String   @id @default(cuid())
  name        String
  description String?
  price       Decimal
  stock       Int      @default(0)
  sku         String   @unique
  status      String   @default("active")
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  @@index([status])
  @@index([sku])
}

EOF
    fi

    # Notification model
    if echo "$req_lower" | grep -qE 'notification|alert'; then
        cat <<'EOF'
model Notification {
  id        String   @id @default(cuid())
  userId    String
  user      User     @relation(fields: [userId], references: [id])
  title     String
  message   String
  read      Boolean  @default(false)
  type      String   @default("info")
  createdAt DateTime @default(now())

  @@index([userId, read])
  @@index([createdAt])
}

EOF
    fi

    DDO_PRISMA_GENERATED=$((DDO_PRISMA_GENERATED + 1))
    _ddo_ok "Prisma schema generated"
}

# =============================================================================
# _ddo_detect_antipatterns - Detect database design anti-patterns
# =============================================================================
_ddo_detect_antipatterns() {
    local schema_file="${1:-}"
    [[ -z "$schema_file" || ! -f "$schema_file" ]] && { _ddo_err "Schema file required"; return 1; }

    local content
    content=$(cat "$schema_file" 2>/dev/null)
    local issues=()

    # God table (too many fields)
    while IFS= read -r model_name; do
        [[ -z "$model_name" ]] && continue
        local field_count
        field_count=$(echo "$content" | awk "/^model ${model_name}/,/^}/" | grep -cE '^\s+\w+\s+\w+' || true)
        if [[ "$field_count" -gt 20 ]]; then
            issues+=("GOD_TABLE: ${model_name} has ${field_count} fields (consider splitting)")
        fi
    done < <(echo "$content" | grep -oP '(?<=^model )\w+')

    # Missing cascade deletes
    if echo "$content" | grep -q "@relation" && ! echo "$content" | grep -q "onDelete"; then
        issues+=("MISSING_CASCADE: Relations without explicit onDelete behavior")
    fi

    # No unique constraints besides id
    local unique_count
    unique_count=$(echo "$content" | grep -c "@unique" || true)
    local model_count
    model_count=$(echo "$content" | grep -c "^model " || true)
    if [[ "$unique_count" -lt "$model_count" ]]; then
        issues+=("WEAK_CONSTRAINTS: Some models lack unique constraints beyond id")
    fi

    # String type for enum-like fields
    if echo "$content" | grep -qE '(status|type|role|priority)\s+String'; then
        issues+=("STRING_ENUM: Consider using Prisma enum for status/type/role/priority fields")
    fi

    # Missing @@map for table naming
    if ! echo "$content" | grep -q "@@map"; then
        issues+=("NAMING: No @@map directives (consider snake_case table names)")
    fi

    echo "{"
    echo "  \"antipattern_count\": ${#issues[@]},"
    echo "  \"issues\": ["
    local first=true
    for issue in "${issues[@]}"; do
        $first || echo ","
        echo -n "    \"${issue}\""
        first=false
    done
    echo ""
    echo "  ]"
    echo "}"

    DDO_ANTIPATTERNS_FOUND=$((DDO_ANTIPATTERNS_FOUND + ${#issues[@]}))
    [[ ${#issues[@]} -gt 0 ]] && _ddo_warn "Found ${#issues[@]} anti-patterns" || _ddo_ok "No anti-patterns detected"
}

# =============================================================================
# Report / Score
# =============================================================================
ddo_report() {
    echo -e "\n  ${DDO_BOLD}=== Database Design Optimizer v${DDO_VERSION} ===${DDO_NC}"
    echo -e "  Schemas designed   : ${DDO_SCHEMAS_DESIGNED}"
    echo -e "  Indexes suggested  : ${DDO_INDEXES_SUGGESTED}"
    echo -e "  Antipatterns found : ${DDO_ANTIPATTERNS_FOUND}"
    echo -e "  Prisma generated   : ${DDO_PRISMA_GENERATED}"
}

ddo_score() {
    [[ "$DDO_INITIALIZED" == "true" ]] && echo 100 || echo 0
}

# =============================================================================
# v59.0: Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "database-design-optimizer" \
        --version "222.0" \
        --description "Optimal DB design from requirements (schema/indexes/normalization/Prisma)" \
        --init "ddo_init" \
        --report "ddo_report" \
        --score "ddo_score" \
        --enable-var "ENABLE_DB_DESIGN_OPTIMIZER" \
        --cli-flags "--db-design-optimizer:--no-db-design-optimizer"
fi

# v2003.1: source時のexit codeを確実に0にする
true
