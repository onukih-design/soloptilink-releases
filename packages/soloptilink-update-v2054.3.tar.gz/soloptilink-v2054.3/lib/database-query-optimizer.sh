#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v432.0 - Database Query Optimizer
# =============================================================================
# データベースクエリの静的解析・最適化。遅いクエリパターンの検出、
# インデックス提案、N+1問題の自動修正を行う。
#
# Functions:
#   _dqo_init()                - 初期化
#   _dqo_detect_slow_queries() - 遅いクエリパターン検出
#   _dqo_suggest_indexes()     - インデックス提案
#   _dqo_fix_n_plus_one()      - N+1問題の検出・修正
#   _dqo_report() / _dqo_score()
#
# All globals use the DQO_ prefix.
# =============================================================================

[[ -n "${_DQO_LOADED:-}" ]] && return 0; _DQO_LOADED=1

declare -g DQO_VERSION="432.0"
declare -g DQO_GENERATED=0
declare -g DQO_ERRORS=0
declare -g DQO_SLOW_QUERIES=0
declare -g DQO_INDEX_SUGGESTIONS=0
declare -g DQO_N_PLUS_ONE=0
declare -g DQO_FILES_SCANNED=0
declare -g DQO_OPTIMIZATIONS=0

declare -ga _DQO_FINDINGS=()
declare -gA _DQO_INDEX_MAP=()

_DQO_GREEN="${GREEN:-\033[0;32m}"
_DQO_RED="${RED:-\033[0;31m}"
_DQO_YELLOW="${YELLOW:-\033[0;33m}"
_DQO_CYAN="${CYAN:-\033[0;36m}"
_DQO_BOLD="${BOLD:-\033[1m}"
_DQO_NC="${NC:-\033[0m}"

_dqo_init() {
    DQO_GENERATED=0; DQO_ERRORS=0; DQO_SLOW_QUERIES=0
    DQO_INDEX_SUGGESTIONS=0; DQO_N_PLUS_ONE=0
    DQO_FILES_SCANNED=0; DQO_OPTIMIZATIONS=0
    _DQO_FINDINGS=(); _DQO_INDEX_MAP=()
    return 0
}

_dqo_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_DQO_CYAN}[DQO]${_DQO_NC} $*" >&2 ;;
        ok)    echo -e "  ${_DQO_GREEN}[DQO]${_DQO_NC} $*" >&2 ;;
        warn)  echo -e "  ${_DQO_YELLOW}[DQO]${_DQO_NC} $*" >&2 ;;
        error) echo -e "  ${_DQO_RED}[DQO]${_DQO_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _dqo_detect_slow_queries - 遅いクエリパターン検出
# =============================================================================
_dqo_detect_slow_queries() {
    local project_dir="${1:-.}"
    _dqo_log info "遅いクエリパターン検出: ${project_dir}"

    DQO_SLOW_QUERIES=0
    DQO_FILES_SCANNED=0

    # パターン定義: Prisma/SQL の非効率パターン
    local -a slow_patterns=(
        "findMany.*without.*take"    # ページネーションなし
        "SELECT \*"                  # SELECT * (全カラム取得)
        "\.findMany()"              # 制限なしfindMany
        "LIKE '%"                   # 前方一致なしLIKE
        "OR.*OR.*OR"               # 過剰OR条件
        "NOT IN.*SELECT"           # サブクエリNOT IN
    )

    while IFS= read -r -d '' file; do
        DQO_FILES_SCANNED=$((DQO_FILES_SCANNED + 1))
        local rel="${file#${project_dir}/}"

        # findManyでtake/limit未指定
        local unbounded
        unbounded=$(grep -n "findMany" "$file" 2>/dev/null | grep -v "take" | grep -v "limit" | head -5)
        if [[ -n "$unbounded" ]]; then
            while IFS= read -r match; do
                local line_num="${match%%:*}"
                DQO_SLOW_QUERIES=$((DQO_SLOW_QUERIES + 1))
                _DQO_FINDINGS+=("UNBOUNDED_QUERY:${rel}:${line_num}:findMany without take/limit")
                _dqo_log warn "制限なしクエリ: ${rel}:${line_num}"
            done <<< "$unbounded"
        fi

        # SELECT * 検出
        local select_star
        select_star=$(grep -n "SELECT \*\|select: {}" "$file" 2>/dev/null | head -5)
        if [[ -n "$select_star" ]]; then
            while IFS= read -r match; do
                local line_num="${match%%:*}"
                DQO_SLOW_QUERIES=$((DQO_SLOW_QUERIES + 1))
                _DQO_FINDINGS+=("SELECT_ALL:${rel}:${line_num}:SELECT * or empty select")
            done <<< "$select_star"
        fi

        # 非効率な集約
        local count_all
        count_all=$(grep -n "\.count()" "$file" 2>/dev/null | head -5)
        while IFS= read -r match; do
            [[ -z "$match" ]] && continue
            local line_num="${match%%:*}"
            # countの後にfindManyがある場合→別クエリで取得可能
            local next_lines
            next_lines=$(sed -n "$((line_num)),$((line_num + 5))p" "$file" 2>/dev/null)
            if [[ "$next_lines" == *"findMany"* ]]; then
                DQO_SLOW_QUERIES=$((DQO_SLOW_QUERIES + 1))
                _DQO_FINDINGS+=("SEPARATE_COUNT:${rel}:${line_num}:count+findMany should use _count include")
            fi
        done <<< "$count_all"

        # orderByなしのページネーション
        local paginated
        paginated=$(grep -n "skip\|offset" "$file" 2>/dev/null | head -5)
        while IFS= read -r match; do
            [[ -z "$match" ]] && continue
            local line_num="${match%%:*}"
            local context
            context=$(sed -n "$((line_num > 3 ? line_num - 3 : 1)),$((line_num + 3))p" "$file" 2>/dev/null)
            if [[ "$context" != *"orderBy"* ]] && [[ "$context" != *"ORDER BY"* ]]; then
                DQO_SLOW_QUERIES=$((DQO_SLOW_QUERIES + 1))
                _DQO_FINDINGS+=("UNORDERED_PAGINATION:${rel}:${line_num}:pagination without orderBy")
            fi
        done <<< "$paginated"
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" \
             -path "*/*api*" -o -path "*/*service*" -o -path "*/*repository*" -o -path "*/*query*" \
             -print0 2>/dev/null)

    DQO_GENERATED=$((DQO_GENERATED + 1))
    _dqo_log ok "遅いクエリ検出: ${DQO_SLOW_QUERIES}件 (${DQO_FILES_SCANNED}ファイル走査)"
    return 0
}

# =============================================================================
# _dqo_suggest_indexes - インデックス提案
# =============================================================================
_dqo_suggest_indexes() {
    local project_dir="${1:-.}"
    _dqo_log info "インデックス提案分析"

    DQO_INDEX_SUGGESTIONS=0
    _DQO_INDEX_MAP=()

    # Prisma schema分析
    local schema="${project_dir}/prisma/schema.prisma"
    [[ ! -f "$schema" ]] && schema=$(find "$project_dir" -name "schema.prisma" -not -path "*/node_modules/*" 2>/dev/null | head -1)

    if [[ -f "$schema" ]]; then
        # where条件で使われるフィールドを特定
        local -A where_fields=()

        while IFS= read -r -d '' file; do
            while IFS= read -r line; do
                # where: { field: value } パターン
                if [[ "$line" =~ where.*\{.*([a-zA-Z_]+): ]]; then
                    local field="${BASH_REMATCH[1]}"
                    where_fields["$field"]=$(( ${where_fields["$field"]:-0} + 1 ))
                fi
            done < <(grep -E "where\s*:" "$file" 2>/dev/null)
        done < <(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" \) \
                 -not -path "*/node_modules/*" -print0 2>/dev/null)

        # @@indexが存在するか確認
        local indexed_fields=""
        indexed_fields=$(grep -E "@@index|@@unique" "$schema" 2>/dev/null || echo "")

        for field in "${!where_fields[@]}"; do
            local count="${where_fields[$field]}"
            if [[ $count -ge 2 ]] && [[ "$indexed_fields" != *"$field"* ]]; then
                DQO_INDEX_SUGGESTIONS=$((DQO_INDEX_SUGGESTIONS + 1))
                _DQO_INDEX_MAP["$field"]="$count"
                _dqo_log warn "インデックス推奨: ${field} (${count}箇所でWHERE使用)"
            fi
        done
    fi

    # 複合インデックス提案
    for finding in "${_DQO_FINDINGS[@]}"; do
        if [[ "$finding" == "UNORDERED_PAGINATION"* ]]; then
            DQO_INDEX_SUGGESTIONS=$((DQO_INDEX_SUGGESTIONS + 1))
            _dqo_log warn "ページネーション用ソートインデックス推奨"
        fi
    done

    DQO_GENERATED=$((DQO_GENERATED + 1))
    _dqo_log ok "インデックス提案: ${DQO_INDEX_SUGGESTIONS}件"
    return 0
}

# =============================================================================
# _dqo_fix_n_plus_one - N+1問題の検出・修正
# =============================================================================
_dqo_fix_n_plus_one() {
    local project_dir="${1:-.}"
    _dqo_log info "N+1問題検出"

    DQO_N_PLUS_ONE=0

    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"
        local line_num=0

        while IFS= read -r line; do
            line_num=$((line_num + 1))

            # forループ内のfindUnique/findFirst検出
            if [[ "$line" =~ for.*\( ]] || [[ "$line" =~ \.map\( ]] || [[ "$line" =~ \.forEach\( ]]; then
                # 次の20行をチェック
                local block
                block=$(sed -n "${line_num},$((line_num + 20))p" "$file" 2>/dev/null)

                if [[ "$block" == *"findUnique"* ]] || [[ "$block" == *"findFirst"* ]] || \
                   [[ "$block" == *"findMany"* ]] || [[ "$block" == *"$query"* ]]; then
                    DQO_N_PLUS_ONE=$((DQO_N_PLUS_ONE + 1))
                    _DQO_FINDINGS+=("N_PLUS_ONE:${rel}:${line_num}:query inside loop")
                    _dqo_log warn "N+1検出: ${rel}:${line_num} (ループ内クエリ)"
                fi
            fi
        done < "$file"
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" \
             -path "*/*api*" -o -path "*/*service*" -o -path "*/*route*" \
             -print0 2>/dev/null)

    DQO_OPTIMIZATIONS=$((DQO_N_PLUS_ONE))
    DQO_GENERATED=$((DQO_GENERATED + 1))
    _dqo_log ok "N+1問題: ${DQO_N_PLUS_ONE}件検出 → include/joinで解決推奨"
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_dqo_report() {
    echo -e "\n  ${_DQO_BOLD}=== database-query-optimizer v${DQO_VERSION} ===${_DQO_NC}"
    echo -e "  走査ファイル    : ${DQO_FILES_SCANNED}"
    echo -e "  遅いクエリ      : ${DQO_SLOW_QUERIES}"
    echo -e "  インデックス提案: ${DQO_INDEX_SUGGESTIONS}"
    echo -e "  N+1問題         : ${DQO_N_PLUS_ONE}"
    echo -e "  検出総数        : ${#_DQO_FINDINGS[@]}"
    echo -e "  エラー          : ${DQO_ERRORS}"
}

_dqo_score() {
    local score=50
    [[ ${DQO_FILES_SCANNED} -gt 0 ]] && score=$((score + 10))
    [[ ${DQO_SLOW_QUERIES} -eq 0 ]] && score=$((score + 15)) || score=$((score + 5))
    [[ ${DQO_N_PLUS_ONE} -eq 0 ]] && score=$((score + 15)) || score=$((score + 5))
    [[ ${DQO_ERRORS} -eq 0 ]] && score=$((score + 10))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "database-query-optimizer" --version "${DQO_VERSION}" \
        --description "DBクエリ最適化×N+1検出×インデックス提案 (v432)" \
        --init "_dqo_init" --report "_dqo_report" --score "_dqo_score" \
        --enable-var "ENABLE_QUERY_OPT" --cli-flags "--query-opt:--no-query-opt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
