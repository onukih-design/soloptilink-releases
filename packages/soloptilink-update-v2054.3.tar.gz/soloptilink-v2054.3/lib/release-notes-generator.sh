#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v419.0 - Release Notes Generator
# =============================================================================
# Gitコミット分析・リリースノート自動生成・CHANGELOG整形を統合。
# Conventional Commits解析・カテゴリ分類・マークダウン出力を自動化する。
#
# Functions:
#   _rng_init             - 初期化
#   _rng_analyze_commits  - コミット履歴分析
#   _rng_generate_notes   - リリースノート生成
#   _rng_format_changelog - CHANGELOG.md整形
#   _rng_report           - レポート出力
#   _rng_score            - モジュールスコア(0-100)
#
# All globals use the RNG_ prefix.
# =============================================================================

[[ -n "${_RELEASE_NOTES_GEN_LOADED:-}" ]] && return 0
_RELEASE_NOTES_GEN_LOADED=1

declare -g RNG_VERSION="419.0"
declare -g RNG_INITIALIZED=false
declare -g RNG_STORE_DIR=""
declare -g RNG_ANALYZE_COUNT=0
declare -g RNG_NOTES_GENERATED=0
declare -g RNG_TOTAL_COMMITS_ANALYZED=0

declare -g -A _RNG_COMMIT_TYPES=()     # type → count
declare -g -A _RNG_SCOPES=()           # scope → count
declare -g -a _RNG_FEATURES=()
declare -g -a _RNG_FIXES=()
declare -g -a _RNG_BREAKING=()
declare -g -a _RNG_OTHER=()

# =============================================================================
_rng_init() {
    local project_dir="${PROJECT_DIR:-.}"
    RNG_STORE_DIR="${project_dir}/.soloptilink/release-notes"
    mkdir -p "${RNG_STORE_DIR}/releases" "${RNG_STORE_DIR}/history"

    RNG_INITIALIZED=true
    return 0
}

# =============================================================================
# _rng_analyze_commits - Analyze commits since last tag/release
# =============================================================================
_rng_analyze_commits() {
    local project_dir="${1:-${PROJECT_DIR:-.}}"
    local since="${2:-}"  # tag, hash, or date

    [[ "$RNG_INITIALIZED" != "true" ]] && { echo "ERROR: RNG not initialized" >&2; return 1; }
    RNG_ANALYZE_COUNT=$((RNG_ANALYZE_COUNT + 1))

    # Reset categories
    _RNG_FEATURES=()
    _RNG_FIXES=()
    _RNG_BREAKING=()
    _RNG_OTHER=()
    _RNG_COMMIT_TYPES=()
    _RNG_SCOPES=()

    [[ ! -d "${project_dir}/.git" ]] && { echo "ERROR: Not a git repository" >&2; return 1; }

    # Determine range
    local range=""
    if [[ -n "$since" ]]; then
        range="${since}..HEAD"
    else
        # Try last tag
        local last_tag
        last_tag=$(cd "$project_dir" && git describe --tags --abbrev=0 2>/dev/null)
        if [[ -n "$last_tag" ]]; then
            range="${last_tag}..HEAD"
        else
            range="HEAD~50..HEAD"  # Last 50 commits
        fi
    fi

    local commit_count=0

    while IFS= read -r commit_msg; do
        [[ -z "$commit_msg" ]] && continue
        commit_count=$((commit_count + 1))

        # Parse conventional commit: type(scope): description
        local commit_type="" scope="" description=""
        if echo "$commit_msg" | grep -qE '^[a-z]+(\([^)]+\))?!?: '; then
            commit_type=$(echo "$commit_msg" | sed 's/^\([a-z]*\).*/\1/')
            scope=$(echo "$commit_msg" | grep -oE '\([^)]+\)' | tr -d '()')
            description=$(echo "$commit_msg" | sed 's/^[^:]*: //')
        else
            commit_type="other"
            description="$commit_msg"
        fi

        # Track type counts
        _RNG_COMMIT_TYPES["$commit_type"]=$(( ${_RNG_COMMIT_TYPES[$commit_type]:-0} + 1 ))
        [[ -n "$scope" ]] && _RNG_SCOPES["$scope"]=$(( ${_RNG_SCOPES[$scope]:-0} + 1 ))

        # Categorize
        local entry="${description}"
        [[ -n "$scope" ]] && entry="**${scope}:** ${description}"

        # Check for breaking changes
        if echo "$commit_msg" | grep -q '!:' || echo "$commit_msg" | grep -qi 'BREAKING CHANGE'; then
            _RNG_BREAKING+=("$entry")
        fi

        case "$commit_type" in
            feat) _RNG_FEATURES+=("$entry") ;;
            fix) _RNG_FIXES+=("$entry") ;;
            feat|fix) ;; # already handled
            *) _RNG_OTHER+=("$entry") ;;
        esac
    done < <(cd "$project_dir" && git log ${range} --pretty=format:"%s" 2>/dev/null)

    RNG_TOTAL_COMMITS_ANALYZED=$((RNG_TOTAL_COMMITS_ANALYZED + commit_count))

    cat <<ANALYZEEOF
{"total_commits":${commit_count},"features":${#_RNG_FEATURES[@]},"fixes":${#_RNG_FIXES[@]},"breaking":${#_RNG_BREAKING[@]},"other":${#_RNG_OTHER[@]}}
ANALYZEEOF
    return 0
}

# =============================================================================
# _rng_generate_notes - Generate release notes markdown
# =============================================================================
_rng_generate_notes() {
    local version="${1:-Unreleased}"
    local date_str="${2:-$(date +%Y-%m-%d 2>/dev/null || echo '2026-01-01')}"

    [[ "$RNG_INITIALIZED" != "true" ]] && { echo "ERROR: RNG not initialized" >&2; return 1; }
    RNG_NOTES_GENERATED=$((RNG_NOTES_GENERATED + 1))

    cat <<NOTESEOF
# Release Notes - ${version}

**Date:** ${date_str}

NOTESEOF

    # Breaking Changes
    if [[ ${#_RNG_BREAKING[@]} -gt 0 ]]; then
        echo "## Breaking Changes"
        echo ""
        for item in "${_RNG_BREAKING[@]}"; do
            echo "- ${item}"
        done
        echo ""
    fi

    # Features
    if [[ ${#_RNG_FEATURES[@]} -gt 0 ]]; then
        echo "## New Features"
        echo ""
        for item in "${_RNG_FEATURES[@]}"; do
            echo "- ${item}"
        done
        echo ""
    fi

    # Bug Fixes
    if [[ ${#_RNG_FIXES[@]} -gt 0 ]]; then
        echo "## Bug Fixes"
        echo ""
        for item in "${_RNG_FIXES[@]}"; do
            echo "- ${item}"
        done
        echo ""
    fi

    # Other Changes
    if [[ ${#_RNG_OTHER[@]} -gt 0 ]]; then
        echo "## Other Changes"
        echo ""
        local shown=0
        for item in "${_RNG_OTHER[@]}"; do
            [[ $shown -ge 20 ]] && { echo "- ... and more"; break; }
            echo "- ${item}"
            shown=$((shown + 1))
        done
        echo ""
    fi

    # Statistics
    echo "---"
    echo ""
    echo "**Stats:** ${RNG_TOTAL_COMMITS_ANALYZED} commits analyzed"
    if [[ ${#_RNG_SCOPES[@]} -gt 0 ]]; then
        echo -n "**Scopes:** "
        for scope in "${!_RNG_SCOPES[@]}"; do
            echo -n "${scope}(${_RNG_SCOPES[$scope]}) "
        done
        echo ""
    fi

    # Save to file
    local notes_file="${RNG_STORE_DIR}/releases/${version}_${date_str}.md"
    _rng_generate_notes "$version" "$date_str" > "$notes_file" 2>/dev/null

    return 0
}

# =============================================================================
# _rng_format_changelog - Format/update CHANGELOG.md
# =============================================================================
_rng_format_changelog() {
    local project_dir="${1:-${PROJECT_DIR:-.}}"
    local version="${2:-Unreleased}"
    local changelog_file="${project_dir}/CHANGELOG.md"

    [[ "$RNG_INITIALIZED" != "true" ]] && return 1

    local new_entry=""
    new_entry=$(_rng_generate_notes "$version")

    if [[ -f "$changelog_file" ]]; then
        # Prepend new entry after header
        local existing
        existing=$(cat "$changelog_file")
        local header="# Changelog"
        if echo "$existing" | grep -q "^# Changelog"; then
            # Insert after first line
            echo "$header"
            echo ""
            echo "$new_entry"
            echo ""
            echo "$existing" | tail -n +2
        else
            echo "$header"
            echo ""
            echo "$new_entry"
            echo ""
            echo "$existing"
        fi
    else
        echo "# Changelog"
        echo ""
        echo "All notable changes to this project will be documented in this file."
        echo ""
        echo "$new_entry"
    fi

    return 0
}

# =============================================================================
# Report / Score
# =============================================================================
_rng_report() {
    echo -e "\n  ${BOLD:-}=== Release Notes Generator v${RNG_VERSION} ===${NC:-}"
    echo -e "  Analyses Run      : ${RNG_ANALYZE_COUNT}"
    echo -e "  Notes Generated   : ${RNG_NOTES_GENERATED}"
    echo -e "  Commits Analyzed  : ${RNG_TOTAL_COMMITS_ANALYZED}"
    echo -e "  Features Found    : ${#_RNG_FEATURES[@]}"
    echo -e "  Fixes Found       : ${#_RNG_FIXES[@]}"
    echo -e "  Breaking Changes  : ${#_RNG_BREAKING[@]}"
}

_rng_score() {
    local score=30
    [[ "$RNG_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ $RNG_ANALYZE_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $RNG_NOTES_GENERATED -gt 0 ]] && score=$((score + 15))
    [[ $RNG_TOTAL_COMMITS_ANALYZED -gt 0 ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "release-notes-generator" \
        --version "419.0" \
        --description "Gitコミット分析・リリースノート・CHANGELOG自動生成" \
        --init "_rng_init" \
        --report "_rng_report" \
        --score "_rng_score" \
        --enable-var "ENABLE_RNG" \
        --cli-flags "--release-notes:--no-release-notes"
fi

# v2003.1: source時のexit codeを確実に0にする
true
