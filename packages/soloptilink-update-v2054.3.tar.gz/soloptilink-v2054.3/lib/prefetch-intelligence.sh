#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v458.0 - Prefetch Intelligence Engine
# =============================================================================
# プリフェッチ知能: ナビゲーション予測、プリフェッチ生成、リソースヒント最適化。
#
# Functions:
#   _pi2_init()                - Initialize
#   _pi2_predict_navigation()  - Navigation prediction based on patterns
#   _pi2_generate_prefetch()   - Prefetch link generation
#   _pi2_optimize_hints()      - Resource hint optimization
#   _pi2_report() / _pi2_score()
# =============================================================================

[[ -n "${_PI2_LOADED:-}" ]] && return 0; _PI2_LOADED=1

declare -g PI2_VERSION="458.0"
PI2_GENERATED=0; PI2_ERRORS=0; PI2_FILES_WRITTEN=0
PI2_PREDICT_OK=false; PI2_PREFETCH_OK=false; PI2_HINTS_OK=false

_pi2_init() {
    PI2_GENERATED=0; PI2_ERRORS=0; PI2_FILES_WRITTEN=0
    PI2_PREDICT_OK=false; PI2_PREFETCH_OK=false; PI2_HINTS_OK=false
    return 0
}

_pi2_log() { echo -e "  ${CYAN:-\033[0;36m}[prefetch]${NC:-\033[0m} $*" >&2; }
_pi2_ok()  { echo -e "  ${GREEN:-\033[0;32m}✅ [prefetch]${NC:-\033[0m} $*" >&2; }
_pi2_err() { echo -e "  ${RED:-\033[0;31m}❌ [prefetch]${NC:-\033[0m} $*" >&2; PI2_ERRORS=$((PI2_ERRORS + 1)); }

_pi2_write_file() {
    local filepath="$1" content="$2"
    local dir; dir="$(dirname "$filepath")"
    [[ -d "$dir" ]] || mkdir -p "$dir"
    echo "$content" > "$filepath" 2>/dev/null || { _pi2_err "Failed to write $filepath"; return 1; }
    PI2_FILES_WRITTEN=$((PI2_FILES_WRITTEN + 1))
    return 0
}

_pi2_predict_navigation() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/performance/navigation-predictor.ts"
    _pi2_log "Generating navigation predictor..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v458.0 - Navigation Prediction Engine

export interface NavigationPattern {
  fromPath: string;
  toPath: string;
  probability: number;       // 0-1
  avgTimeToNavigateMs: number;
}

export class NavigationPredictor {
  private patterns: NavigationPattern[] = [];
  private history: Array<{ path: string; timestamp: number }> = [];
  private readonly maxHistory = 500;

  recordNavigation(path: string): void {
    this.history.push({ path, timestamp: Date.now() });
    if (this.history.length > this.maxHistory) this.history.shift();
    this.updatePatterns();
  }

  private updatePatterns(): void {
    const transitions: Map<string, Map<string, number>> = new Map();
    const fromCounts: Map<string, number> = new Map();
    for (let i = 0; i < this.history.length - 1; i++) {
      const from = this.history[i].path;
      const to = this.history[i + 1].path;
      if (!transitions.has(from)) transitions.set(from, new Map());
      transitions.get(from)!.set(to, (transitions.get(from)!.get(to) ?? 0) + 1);
      fromCounts.set(from, (fromCounts.get(from) ?? 0) + 1);
    }
    this.patterns = [];
    for (const [from, targets] of transitions) {
      const total = fromCounts.get(from)!;
      for (const [to, count] of targets) {
        this.patterns.push({ fromPath: from, toPath: to, probability: count / total, avgTimeToNavigateMs: 2000 });
      }
    }
  }

  predict(currentPath: string, minProbability = 0.3): NavigationPattern[] {
    return this.patterns
      .filter(p => p.fromPath === currentPath && p.probability >= minProbability)
      .sort((a, b) => b.probability - a.probability);
  }

  getTopPredictions(currentPath: string, count = 3): string[] {
    return this.predict(currentPath).slice(0, count).map(p => p.toPath);
  }
}

export const navigationPredictor = new NavigationPredictor();
TYPESCRIPT
)
    _pi2_write_file "$outfile" "$content" || return 1
    PI2_PREDICT_OK=true
    PI2_GENERATED=$((PI2_GENERATED + 1))
    _pi2_ok "Navigation predictor generated"
    return 0
}

_pi2_generate_prefetch() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/performance/prefetch-manager.ts"
    _pi2_log "Generating prefetch manager..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v458.0 - Prefetch Link Manager

export type PrefetchStrategy = 'hover' | 'viewport' | 'idle' | 'immediate';

export interface PrefetchConfig {
  strategy: PrefetchStrategy;
  maxConcurrent: number;
  minProbability: number;
  networkAware: boolean;      // Respect slow connections
}

const DEFAULT_CONFIG: PrefetchConfig = {
  strategy: 'hover',
  maxConcurrent: 3,
  minProbability: 0.3,
  networkAware: true,
};

export class PrefetchManager {
  private config: PrefetchConfig;
  private prefetched: Set<string> = new Set();
  private activePrefetches = 0;

  constructor(config?: Partial<PrefetchConfig>) { this.config = { ...DEFAULT_CONFIG, ...config }; }

  canPrefetch(): boolean {
    if (this.activePrefetches >= this.config.maxConcurrent) return false;
    if (this.config.networkAware && typeof navigator !== 'undefined') {
      const conn = (navigator as any).connection;
      if (conn?.saveData || conn?.effectiveType === 'slow-2g' || conn?.effectiveType === '2g') return false;
    }
    return true;
  }

  async prefetch(url: string): Promise<boolean> {
    if (this.prefetched.has(url) || !this.canPrefetch()) return false;
    this.activePrefetches++;
    try {
      const link = document.createElement('link');
      link.rel = 'prefetch';
      link.href = url;
      document.head.appendChild(link);
      this.prefetched.add(url);
      return true;
    } finally {
      this.activePrefetches--;
    }
  }

  isPrefetched(url: string): boolean { return this.prefetched.has(url); }
  getStats() { return { prefetched: this.prefetched.size, active: this.activePrefetches }; }
}

export const prefetchManager = new PrefetchManager();
TYPESCRIPT
)
    _pi2_write_file "$outfile" "$content" || return 1
    PI2_PREFETCH_OK=true
    PI2_GENERATED=$((PI2_GENERATED + 1))
    _pi2_ok "Prefetch manager generated"
    return 0
}

_pi2_optimize_hints() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/performance/resource-hints.ts"
    _pi2_log "Generating resource hints optimizer..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v458.0 - Resource Hint Optimizer

export type HintType = 'dns-prefetch' | 'preconnect' | 'prefetch' | 'preload' | 'prerender';

export interface ResourceHint {
  type: HintType;
  href: string;
  as?: string;
  crossOrigin?: 'anonymous' | 'use-credentials';
  importance?: 'high' | 'low' | 'auto';
}

const COMMON_HINTS: ResourceHint[] = [
  { type: 'preconnect', href: 'https://fonts.googleapis.com', crossOrigin: 'anonymous' },
  { type: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous' },
  { type: 'dns-prefetch', href: 'https://cdn.jsdelivr.net' },
  { type: 'dns-prefetch', href: 'https://api.segment.io' },
];

export class ResourceHintOptimizer {
  private hints: ResourceHint[] = [...COMMON_HINTS];

  addHint(hint: ResourceHint): void { this.hints.push(hint); }

  generateHeadElements(): string[] {
    return this.hints.map(hint => {
      const attrs = [`rel="${hint.type}"`, `href="${hint.href}"`];
      if (hint.as) attrs.push(`as="${hint.as}"`);
      if (hint.crossOrigin) attrs.push(`crossorigin="${hint.crossOrigin}"`);
      return `<link ${attrs.join(' ')} />`;
    });
  }

  optimizeForPage(pageType: 'landing' | 'dashboard' | 'detail' | 'form'): ResourceHint[] {
    const extra: ResourceHint[] = [];
    if (pageType === 'dashboard') {
      extra.push({ type: 'preload', href: '/api/dashboard/overview', as: 'fetch', importance: 'high' });
    } else if (pageType === 'landing') {
      extra.push({ type: 'preload', href: '/hero-image.webp', as: 'image', importance: 'high' });
    }
    return [...this.hints, ...extra];
  }
}

export const resourceHints = new ResourceHintOptimizer();
TYPESCRIPT
)
    _pi2_write_file "$outfile" "$content" || return 1
    PI2_HINTS_OK=true
    PI2_GENERATED=$((PI2_GENERATED + 1))
    _pi2_ok "Resource hints generated"
    return 0
}

_pi2_generate_all() {
    local project_dir="${1:-.}"
    _pi2_predict_navigation "$project_dir"
    _pi2_generate_prefetch "$project_dir"
    _pi2_optimize_hints "$project_dir"
    _pi2_ok "Prefetch intelligence complete: ${PI2_GENERATED} components, ${PI2_ERRORS} errors"
}

_pi2_report() {
    echo -e "\n  ${BOLD:-\033[1m}═══ Prefetch Intelligence v${PI2_VERSION} ═══${NC:-\033[0m}"
    echo -e "  Generated  : ${PI2_GENERATED}"
    echo -e "  Errors     : ${PI2_ERRORS}"
    echo -e "  Prediction : ${PI2_PREDICT_OK}"
    echo -e "  Prefetch   : ${PI2_PREFETCH_OK}"
    echo -e "  Hints      : ${PI2_HINTS_OK}"
}

_pi2_score() {
    local score=50
    ${PI2_PREDICT_OK} && score=$((score + 15))
    ${PI2_PREFETCH_OK} && score=$((score + 15))
    ${PI2_HINTS_OK} && score=$((score + 15))
    [[ ${PI2_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "prefetch-intelligence" --version "458.0" \
        --description "プリフェッチ知能: ナビゲーション予測×プリフェッチ×リソースヒント" \
        --init "_pi2_init" --report "_pi2_report" --score "_pi2_score" \
        --enable-var "ENABLE_PREFETCH" --cli-flags "--prefetch:--no-prefetch"
fi

# v2003.1: source時のexit codeを確実に0にする
true
