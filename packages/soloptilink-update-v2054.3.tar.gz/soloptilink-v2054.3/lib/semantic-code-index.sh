#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v205.0 - Semantic Code Index
# プロジェクト全体の関数/クラス/型を意味的にインデックス化し、
# セマンティッククエリで検索可能にする。
#
# 問題: 大規模プロジェクトで「認証ハンドラはどこ？」「型定義の依存は？」
# といった質問に即座に答えられない。grepだけでは意味的な検索ができない。
#
# 解決: ソースコードを解析して関数シグネチャ、JSDocコメント、
# 型定義をインデックス化。セマンティッククエリで関連コードを特定。
# ============================================================

[[ -n "${_SCI_LOADED:-}" ]] && return 0
_SCI_LOADED=1

SCI_VERSION="205.0"
SCI_INITIALIZED=false

# Index state
SCI_INDEX_FILE=""
SCI_FUNCTION_COUNT=0
SCI_TYPE_COUNT=0
SCI_CLASS_COUNT=0
SCI_INTERFACE_COUNT=0
SCI_TOTAL_FILES=0
SCI_INDEX_TIMESTAMP=""
SCI_CACHE_DIR=""
SCI_PROJECT_DIR=""

# Search results
SCI_LAST_QUERY=""
SCI_LAST_RESULTS_COUNT=0

# ============================================================
# Init: Set up cache directory and state
# ============================================================
sci_init() {
    SCI_FUNCTION_COUNT=0
    SCI_TYPE_COUNT=0
    SCI_CLASS_COUNT=0
    SCI_INTERFACE_COUNT=0
    SCI_TOTAL_FILES=0
    SCI_INDEX_TIMESTAMP=""
    SCI_LAST_QUERY=""
    SCI_LAST_RESULTS_COUNT=0

    SCI_CACHE_DIR="${PROJECT_DIR:-.}/.soloptilink/cache"
    SCI_INDEX_FILE="${SCI_CACHE_DIR}/semantic-index.json"
    SCI_PROJECT_DIR="${PROJECT_DIR:-.}"

    # Ensure cache directory exists
    mkdir -p "$SCI_CACHE_DIR" 2>/dev/null || true

    SCI_INITIALIZED=true
    return 0
}

# ============================================================
# Internal: Collect source files for indexing
# ============================================================
_sci_collect_files() {
    local project_dir="${1:-$SCI_PROJECT_DIR}"
    [[ ! -d "$project_dir" ]] && return 1

    find "$project_dir" \
        -type f \( \
            -name "*.ts" -o -name "*.tsx" -o \
            -name "*.js" -o -name "*.jsx" -o \
            -name "*.sh" -o -name "*.py" -o \
            -name "*.go" \
        \) \
        ! -path "*/node_modules/*" \
        ! -path "*/.next/*" \
        ! -path "*/.git/*" \
        ! -path "*/dist/*" \
        ! -path "*/build/*" \
        ! -path "*/.soloptilink/*" \
        ! -path "*/vendor/*" \
        ! -path "*/__pycache__/*" \
        2>/dev/null | sort
}

# ============================================================
# Internal: Extract JSDoc/comment block above a line
# ============================================================
_sci_extract_jsdoc() {
    local file="$1"
    local line_num="$2"

    [[ ! -f "$file" ]] && return 0
    [[ "$line_num" -le 1 ]] && return 0

    local start=$((line_num - 20))
    [[ $start -lt 1 ]] && start=1

    local block=""
    local in_comment=false
    local found_end=false

    # Read lines above the target in reverse to find the nearest comment block
    local lines_above
    lines_above=$(sed -n "${start},$((line_num - 1))p" "$file" 2>/dev/null)

    local comment_lines=()
    local prev_line=""
    while IFS= read -r line; do
        prev_line="$line"
    done <<< "$lines_above"

    # Look for /** ... */ block or // comments immediately above
    local -a reversed_lines=()
    while IFS= read -r line; do
        reversed_lines+=("$line")
    done <<< "$lines_above"

    local collecting=false
    local collected=""
    local i=${#reversed_lines[@]}

    while [[ $i -gt 0 ]]; do
        i=$((i - 1))
        local line="${reversed_lines[$i]}"
        local trimmed
        trimmed=$(echo "$line" | sed 's/^[[:space:]]*//')

        if [[ "$collecting" == true ]]; then
            if echo "$trimmed" | grep -q '^\*/' 2>/dev/null; then
                continue
            elif echo "$trimmed" | grep -q '^/\*\*' 2>/dev/null; then
                local clean
                clean=$(echo "$trimmed" | sed 's|^/\*\*\s*||; s|\s*\*/$||')
                [[ -n "$clean" ]] && collected="${clean}\n${collected}"
                break
            elif echo "$trimmed" | grep -q '^\*' 2>/dev/null; then
                local clean
                clean=$(echo "$trimmed" | sed 's|^\*\s*||')
                [[ -n "$clean" ]] && collected="${clean}\n${collected}"
            else
                break
            fi
        else
            # Start from the line just above the function
            if echo "$trimmed" | grep -q '^\*/' 2>/dev/null; then
                collecting=true
            elif echo "$trimmed" | grep -qE '^//' 2>/dev/null; then
                local clean
                clean=$(echo "$trimmed" | sed 's|^//\s*||')
                collected="${clean}"
            elif [[ -z "$trimmed" ]]; then
                continue
            else
                break
            fi
        fi
    done

    echo -e "$collected" | head -5 | tr '\n' ' ' | sed 's/[[:space:]]*$//'
}

# ============================================================
# Internal: Extract functions from TypeScript/JavaScript files
# ============================================================
_sci_extract_ts_functions() {
    local file="$1"
    local rel_path="$2"
    [[ ! -f "$file" ]] && return 0

    local line_num=0

    # Pattern 1: export function name(params): returnType
    # Pattern 2: export const name = (params) =>
    # Pattern 3: async function name(params)
    # Pattern 4: class methods: name(params): returnType {
    # Pattern 5: export default function

    while IFS= read -r match; do
        [[ -z "$match" ]] && continue
        line_num=$(echo "$match" | cut -d: -f1)
        local line_content
        line_content=$(echo "$match" | cut -d: -f2-)

        # Extract function name
        local func_name=""
        local func_sig=""
        local is_async=false
        local is_exported=false
        local func_kind="function"

        # Check export/async
        echo "$line_content" | grep -q "export" 2>/dev/null && is_exported=true
        echo "$line_content" | grep -q "async" 2>/dev/null && is_async=true

        # Extract name from various patterns
        if echo "$line_content" | grep -qE '(export\s+)?(async\s+)?function\s+\w+' 2>/dev/null; then
            func_name=$(echo "$line_content" | grep -oE 'function\s+\w+' | sed 's/function\s*//')
            func_sig=$(echo "$line_content" | sed 's/^[[:space:]]*//' | sed 's/{[[:space:]]*$//')
        elif echo "$line_content" | grep -qE '(export\s+)?(const|let|var)\s+\w+\s*=\s*(async\s*)?\(' 2>/dev/null; then
            func_name=$(echo "$line_content" | grep -oE '(const|let|var)\s+\w+' | sed 's/\(const\|let\|var\)\s*//')
            func_sig=$(echo "$line_content" | sed 's/^[[:space:]]*//' | sed 's/{[[:space:]]*$//')
            func_kind="arrow"
        elif echo "$line_content" | grep -qE '^\s*(public|private|protected|static|async)\s+\w+\s*\(' 2>/dev/null; then
            func_name=$(echo "$line_content" | grep -oE '(public|private|protected|static|async)\s+\w+\s*\(' | grep -oE '\w+\s*\(' | sed 's/\s*(//')
            func_sig=$(echo "$line_content" | sed 's/^[[:space:]]*//' | sed 's/{[[:space:]]*$//')
            func_kind="method"
        fi

        [[ -z "$func_name" ]] && continue

        # Extract JSDoc comment
        local jsdoc
        jsdoc=$(_sci_extract_jsdoc "$file" "$line_num")

        # Extract parameters
        local params=""
        params=$(echo "$func_sig" | grep -oE '\([^)]*\)' | head -1 | sed 's/^(//;s/)$//')

        # Extract return type
        local return_type=""
        return_type=$(echo "$func_sig" | grep -oE '\):\s*\w+' | sed 's/):\s*//' | head -1)

        # Build JSON entry (escaped for safety)
        local safe_name safe_sig safe_doc safe_params safe_return safe_rel
        safe_name=$(echo "$func_name" | tr -d '"\\')
        safe_sig=$(echo "$func_sig" | tr -d '"\\' | head -c 200)
        safe_doc=$(echo "$jsdoc" | tr -d '"\\' | head -c 300)
        safe_params=$(echo "$params" | tr -d '"\\' | head -c 200)
        safe_return=$(echo "$return_type" | tr -d '"\\')
        safe_rel=$(echo "$rel_path" | tr -d '"\\')

        echo "{\"name\":\"${safe_name}\",\"file\":\"${safe_rel}\",\"line\":${line_num},\"kind\":\"${func_kind}\",\"signature\":\"${safe_sig}\",\"doc\":\"${safe_doc}\",\"params\":\"${safe_params}\",\"returnType\":\"${safe_return}\",\"async\":${is_async},\"exported\":${is_exported}}"

        SCI_FUNCTION_COUNT=$((SCI_FUNCTION_COUNT + 1))
    done < <(grep -nE '(export\s+)?(async\s+)?function\s+\w+|^\s*(export\s+)?(const|let|var)\s+\w+\s*=\s*(async\s*)?\(|^\s*(public|private|protected|static|async)\s+\w+\s*\(' "$file" 2>/dev/null | head -200)
}

# ============================================================
# Internal: Extract TypeScript types and interfaces
# ============================================================
_sci_extract_ts_types() {
    local file="$1"
    local rel_path="$2"
    [[ ! -f "$file" ]] && return 0

    # Extract type aliases: (export)? type Name = ...
    while IFS= read -r match; do
        [[ -z "$match" ]] && continue
        local line_num
        line_num=$(echo "$match" | cut -d: -f1)
        local line_content
        line_content=$(echo "$match" | cut -d: -f2-)

        local type_name
        type_name=$(echo "$line_content" | grep -oE 'type\s+\w+' | sed 's/type\s*//')
        [[ -z "$type_name" ]] && continue

        local is_exported=false
        echo "$line_content" | grep -q "export" 2>/dev/null && is_exported=true

        local jsdoc
        jsdoc=$(_sci_extract_jsdoc "$file" "$line_num")

        # Try to extract the type definition (up to 200 chars)
        local definition
        definition=$(echo "$line_content" | sed 's/^[[:space:]]*//' | head -c 200 | tr -d '"\\')

        local safe_name safe_doc safe_def safe_rel
        safe_name=$(echo "$type_name" | tr -d '"\\')
        safe_doc=$(echo "$jsdoc" | tr -d '"\\' | head -c 300)
        safe_def=$(echo "$definition" | tr -d '"\\')
        safe_rel=$(echo "$rel_path" | tr -d '"\\')

        echo "{\"name\":\"${safe_name}\",\"file\":\"${safe_rel}\",\"line\":${line_num},\"kind\":\"type\",\"definition\":\"${safe_def}\",\"doc\":\"${safe_doc}\",\"exported\":${is_exported}}"
        SCI_TYPE_COUNT=$((SCI_TYPE_COUNT + 1))
    done < <(grep -nE '(export\s+)?type\s+\w+\s*=' "$file" 2>/dev/null | head -100)

    # Extract interfaces: (export)? interface Name { ... }
    while IFS= read -r match; do
        [[ -z "$match" ]] && continue
        local line_num
        line_num=$(echo "$match" | cut -d: -f1)
        local line_content
        line_content=$(echo "$match" | cut -d: -f2-)

        local iface_name
        iface_name=$(echo "$line_content" | grep -oE 'interface\s+\w+' | sed 's/interface\s*//')
        [[ -z "$iface_name" ]] && continue

        local is_exported=false
        echo "$line_content" | grep -q "export" 2>/dev/null && is_exported=true

        # Extract extends
        local extends=""
        extends=$(echo "$line_content" | grep -oE 'extends\s+[\w,\s]+' | sed 's/extends\s*//' | tr -d '"\\')

        # Extract interface members (next few lines)
        local members=""
        local member_start=$((line_num + 1))
        local member_end=$((line_num + 30))
        local member_lines
        member_lines=$(sed -n "${member_start},${member_end}p" "$file" 2>/dev/null)
        local member_list=()
        while IFS= read -r mline; do
            local trimmed
            trimmed=$(echo "$mline" | sed 's/^[[:space:]]*//')
            [[ "$trimmed" == "}" ]] && break
            [[ "$trimmed" == "};" ]] && break
            [[ -z "$trimmed" ]] && continue
            # Extract member name
            local member_name
            member_name=$(echo "$trimmed" | grep -oE '^\w+' | head -1)
            [[ -n "$member_name" ]] && member_list+=("$member_name")
        done <<< "$member_lines"
        members=$(printf '%s,' "${member_list[@]}" | sed 's/,$//')

        local jsdoc
        jsdoc=$(_sci_extract_jsdoc "$file" "$line_num")

        local safe_name safe_doc safe_ext safe_mem safe_rel
        safe_name=$(echo "$iface_name" | tr -d '"\\')
        safe_doc=$(echo "$jsdoc" | tr -d '"\\' | head -c 300)
        safe_ext=$(echo "$extends" | tr -d '"\\')
        safe_mem=$(echo "$members" | tr -d '"\\' | head -c 500)
        safe_rel=$(echo "$rel_path" | tr -d '"\\')

        echo "{\"name\":\"${safe_name}\",\"file\":\"${safe_rel}\",\"line\":${line_num},\"kind\":\"interface\",\"extends\":\"${safe_ext}\",\"members\":\"${safe_mem}\",\"doc\":\"${safe_doc}\",\"exported\":${is_exported}}"
        SCI_INTERFACE_COUNT=$((SCI_INTERFACE_COUNT + 1))
    done < <(grep -nE '(export\s+)?interface\s+\w+' "$file" 2>/dev/null | head -100)
}

# ============================================================
# Internal: Extract classes
# ============================================================
_sci_extract_classes() {
    local file="$1"
    local rel_path="$2"
    [[ ! -f "$file" ]] && return 0

    while IFS= read -r match; do
        [[ -z "$match" ]] && continue
        local line_num
        line_num=$(echo "$match" | cut -d: -f1)
        local line_content
        line_content=$(echo "$match" | cut -d: -f2-)

        local class_name
        class_name=$(echo "$line_content" | grep -oE 'class\s+\w+' | sed 's/class\s*//')
        [[ -z "$class_name" ]] && continue

        local is_exported=false
        echo "$line_content" | grep -q "export" 2>/dev/null && is_exported=true

        local extends=""
        extends=$(echo "$line_content" | grep -oE 'extends\s+\w+' | sed 's/extends\s*//')

        local implements=""
        implements=$(echo "$line_content" | grep -oE 'implements\s+[\w,\s]+' | sed 's/implements\s*//' | tr -d '"\\')

        local jsdoc
        jsdoc=$(_sci_extract_jsdoc "$file" "$line_num")

        # Count methods in class (rough scan for next 200 lines)
        local method_count=0
        local class_end=$((line_num + 200))
        method_count=$(sed -n "$((line_num + 1)),${class_end}p" "$file" 2>/dev/null | \
            grep -cE '^\s*(public|private|protected|static|async|get|set)?\s*\w+\s*\(' 2>/dev/null || echo "0")

        local safe_name safe_doc safe_ext safe_impl safe_rel
        safe_name=$(echo "$class_name" | tr -d '"\\')
        safe_doc=$(echo "$jsdoc" | tr -d '"\\' | head -c 300)
        safe_ext=$(echo "$extends" | tr -d '"\\')
        safe_impl=$(echo "$implements" | tr -d '"\\')
        safe_rel=$(echo "$rel_path" | tr -d '"\\')

        echo "{\"name\":\"${safe_name}\",\"file\":\"${safe_rel}\",\"line\":${line_num},\"kind\":\"class\",\"extends\":\"${safe_ext}\",\"implements\":\"${safe_impl}\",\"methods\":${method_count},\"doc\":\"${safe_doc}\",\"exported\":${is_exported}}"
        SCI_CLASS_COUNT=$((SCI_CLASS_COUNT + 1))
    done < <(grep -nE '(export\s+)?(default\s+)?class\s+\w+' "$file" 2>/dev/null | head -50)
}

# ============================================================
# Internal: Extract bash functions
# ============================================================
_sci_extract_bash_functions() {
    local file="$1"
    local rel_path="$2"
    [[ ! -f "$file" ]] && return 0

    while IFS= read -r match; do
        [[ -z "$match" ]] && continue
        local line_num
        line_num=$(echo "$match" | cut -d: -f1)
        local line_content
        line_content=$(echo "$match" | cut -d: -f2-)

        local func_name=""
        # Pattern: function name() or name() {
        func_name=$(echo "$line_content" | grep -oE '(function\s+)?\w+\s*\(\)' | sed 's/function\s*//;s/\s*()//')
        [[ -z "$func_name" ]] && continue
        # Skip common false positives
        [[ "$func_name" == "if" || "$func_name" == "while" || "$func_name" == "for" ]] && continue

        # Extract comment above
        local comment=""
        local prev_start=$((line_num - 5))
        [[ $prev_start -lt 1 ]] && prev_start=1
        local above
        above=$(sed -n "${prev_start},$((line_num - 1))p" "$file" 2>/dev/null)
        while IFS= read -r cline; do
            local trimmed
            trimmed=$(echo "$cline" | sed 's/^[[:space:]]*//')
            if echo "$trimmed" | grep -qE '^#[^!]' 2>/dev/null; then
                local clean
                clean=$(echo "$trimmed" | sed 's/^#\s*//')
                [[ -n "$clean" ]] && comment="$clean"
            fi
        done <<< "$above"

        local safe_name safe_doc safe_rel
        safe_name=$(echo "$func_name" | tr -d '"\\')
        safe_doc=$(echo "$comment" | tr -d '"\\' | head -c 300)
        safe_rel=$(echo "$rel_path" | tr -d '"\\')

        echo "{\"name\":\"${safe_name}\",\"file\":\"${safe_rel}\",\"line\":${line_num},\"kind\":\"bash_function\",\"signature\":\"${safe_name}()\",\"doc\":\"${safe_doc}\",\"params\":\"\",\"returnType\":\"\",\"async\":false,\"exported\":false}"
        SCI_FUNCTION_COUNT=$((SCI_FUNCTION_COUNT + 1))
    done < <(grep -nE '^\s*(function\s+)?\w+\s*\(\)\s*\{?' "$file" 2>/dev/null | head -200)
}

# ============================================================
# Build semantic index of all functions/classes/types
# ============================================================
_sci_build_index() {
    local project_dir="${1:-$SCI_PROJECT_DIR}"
    [[ ! -d "$project_dir" ]] && { echo "[SCI] Error: project directory not found: $project_dir" >&2; return 1; }
    [[ "$SCI_INITIALIZED" != "true" ]] && sci_init

    SCI_PROJECT_DIR="$project_dir"
    SCI_CACHE_DIR="${project_dir}/.soloptilink/cache"
    SCI_INDEX_FILE="${SCI_CACHE_DIR}/semantic-index.json"
    mkdir -p "$SCI_CACHE_DIR" 2>/dev/null

    # Reset counters
    SCI_FUNCTION_COUNT=0
    SCI_TYPE_COUNT=0
    SCI_CLASS_COUNT=0
    SCI_INTERFACE_COUNT=0
    SCI_TOTAL_FILES=0

    echo "[SCI] Building semantic index for: $project_dir" >&2

    local files_list
    files_list=$(_sci_collect_files "$project_dir")
    local file_count=0
    file_count=$(echo "$files_list" | grep -c '.' 2>/dev/null || echo "0")
    SCI_TOTAL_FILES=$file_count

    echo "[SCI] Scanning $file_count files..." >&2

    # Start JSON structure
    local tmp_functions="${SCI_CACHE_DIR}/.tmp_functions.json"
    local tmp_types="${SCI_CACHE_DIR}/.tmp_types.json"
    local tmp_classes="${SCI_CACHE_DIR}/.tmp_classes.json"

    : > "$tmp_functions"
    : > "$tmp_types"
    : > "$tmp_classes"

    local processed=0
    while IFS= read -r filepath; do
        [[ -z "$filepath" ]] && continue
        [[ ! -f "$filepath" ]] && continue

        local rel_path="${filepath#$project_dir/}"
        local ext="${filepath##*.}"

        case "$ext" in
            ts|tsx|js|jsx)
                _sci_extract_ts_functions "$filepath" "$rel_path" >> "$tmp_functions"
                _sci_extract_ts_types "$filepath" "$rel_path" >> "$tmp_types"
                _sci_extract_classes "$filepath" "$rel_path" >> "$tmp_classes"
                ;;
            sh)
                _sci_extract_bash_functions "$filepath" "$rel_path" >> "$tmp_functions"
                ;;
        esac

        processed=$((processed + 1))
        if [[ $((processed % 50)) -eq 0 ]]; then
            echo "[SCI] Processed $processed / $file_count files..." >&2
        fi
    done <<< "$files_list"

    # Build final JSON index
    SCI_INDEX_TIMESTAMP=$(date '+%Y-%m-%dT%H:%M:%S')

    {
        echo "{"
        echo "  \"version\": \"${SCI_VERSION}\","
        echo "  \"project\": \"${project_dir}\","
        echo "  \"timestamp\": \"${SCI_INDEX_TIMESTAMP}\","
        echo "  \"stats\": {"
        echo "    \"files\": ${SCI_TOTAL_FILES},"
        echo "    \"functions\": ${SCI_FUNCTION_COUNT},"
        echo "    \"types\": ${SCI_TYPE_COUNT},"
        echo "    \"interfaces\": ${SCI_INTERFACE_COUNT},"
        echo "    \"classes\": ${SCI_CLASS_COUNT}"
        echo "  },"

        # Functions array
        echo "  \"functions\": ["
        if [[ -s "$tmp_functions" ]]; then
            sed '$!s/$/,/' "$tmp_functions"
        fi
        echo "  ],"

        # Types array
        echo "  \"types\": ["
        if [[ -s "$tmp_types" ]]; then
            sed '$!s/$/,/' "$tmp_types"
        fi
        echo "  ],"

        # Classes array
        echo "  \"classes\": ["
        if [[ -s "$tmp_classes" ]]; then
            sed '$!s/$/,/' "$tmp_classes"
        fi
        echo "  ]"
        echo "}"
    } > "$SCI_INDEX_FILE"

    # Cleanup temp files
    rm -f "$tmp_functions" "$tmp_types" "$tmp_classes" 2>/dev/null

    local total=$((SCI_FUNCTION_COUNT + SCI_TYPE_COUNT + SCI_INTERFACE_COUNT + SCI_CLASS_COUNT))
    echo "[SCI] Index built: ${total} symbols from ${SCI_TOTAL_FILES} files" >&2
    echo "[SCI] Index saved to: $SCI_INDEX_FILE" >&2

    return 0
}

# ============================================================
# Search index by semantic query
# ============================================================
_sci_search() {
    local query="$1"
    local max_results="${2:-20}"
    [[ -z "$query" ]] && { echo "[SCI] Error: query required" >&2; return 1; }

    if [[ ! -f "$SCI_INDEX_FILE" ]]; then
        echo "[SCI] Error: index not built. Run _sci_build_index first." >&2
        return 1
    fi

    SCI_LAST_QUERY="$query"
    SCI_LAST_RESULTS_COUNT=0

    # Tokenize the query into search terms
    local -a terms=()
    local lower_query
    lower_query=$(echo "$query" | tr '[:upper:]' '[:lower:]')

    for word in $lower_query; do
        # Skip common stop words
        case "$word" in
            the|a|an|is|are|was|were|be|been|being|have|has|had|do|does|did|will|shall|would|should|can|could|may|might|must|of|in|to|for|with|on|at|by|from|as|into|about|that|this|it|and|or|but|not|all|any|each|every|no|such)
                continue ;;
            *)
                terms+=("$word") ;;
        esac
    done

    [[ ${#terms[@]} -eq 0 ]] && terms=("$lower_query")

    echo "[SCI] Searching for: ${terms[*]}" >&2

    # Search through the index file using grep-based scoring
    local results=""
    local count=0

    # Search functions
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        local lower_line
        lower_line=$(echo "$line" | tr '[:upper:]' '[:lower:]')

        local score=0
        for term in "${terms[@]}"; do
            # Name match (highest weight)
            if echo "$lower_line" | grep -qE "\"name\":\"[^\"]*${term}" 2>/dev/null; then
                score=$((score + 10))
            fi
            # Doc match
            if echo "$lower_line" | grep -qE "\"doc\":\"[^\"]*${term}" 2>/dev/null; then
                score=$((score + 5))
            fi
            # Signature match
            if echo "$lower_line" | grep -qE "\"signature\":\"[^\"]*${term}" 2>/dev/null; then
                score=$((score + 3))
            fi
            # File path match
            if echo "$lower_line" | grep -qE "\"file\":\"[^\"]*${term}" 2>/dev/null; then
                score=$((score + 2))
            fi
            # Members match
            if echo "$lower_line" | grep -qE "\"members\":\"[^\"]*${term}" 2>/dev/null; then
                score=$((score + 3))
            fi
            # Generic content match
            if echo "$lower_line" | grep -q "$term" 2>/dev/null; then
                score=$((score + 1))
            fi
        done

        if [[ $score -gt 0 ]]; then
            results+="${score}|${line}\n"
            count=$((count + 1))
        fi
    done < <(grep -E '^\{' "$SCI_INDEX_FILE" 2>/dev/null)

    SCI_LAST_RESULTS_COUNT=$count

    if [[ $count -eq 0 ]]; then
        echo "[SCI] No results found for: $query" >&2
        return 0
    fi

    # Sort by score (descending) and limit results
    echo -e "$results" | sort -t'|' -k1 -rn | head -n "$max_results" | while IFS='|' read -r score entry; do
        [[ -z "$entry" ]] && continue
        local name file line_n kind
        name=$(echo "$entry" | grep -oE '"name":"[^"]*"' | head -1 | sed 's/"name":"//;s/"//')
        file=$(echo "$entry" | grep -oE '"file":"[^"]*"' | head -1 | sed 's/"file":"//;s/"//')
        line_n=$(echo "$entry" | grep -oE '"line":[0-9]+' | head -1 | sed 's/"line"://')
        kind=$(echo "$entry" | grep -oE '"kind":"[^"]*"' | head -1 | sed 's/"kind":"//;s/"//')
        echo "  [score=${score}] ${kind}: ${name} @ ${file}:${line_n}"
    done

    echo "[SCI] Found $count result(s) for: $query" >&2
    return 0
}

# ============================================================
# Get detailed function information
# ============================================================
_sci_get_function_info() {
    local func_name="$1"
    [[ -z "$func_name" ]] && { echo "[SCI] Error: function name required" >&2; return 1; }

    if [[ ! -f "$SCI_INDEX_FILE" ]]; then
        echo "[SCI] Error: index not built. Run _sci_build_index first." >&2
        return 1
    fi

    # Search for exact function name
    local matches
    matches=$(grep -E "\"name\":\"${func_name}\"" "$SCI_INDEX_FILE" 2>/dev/null)

    if [[ -z "$matches" ]]; then
        # Try partial match
        matches=$(grep -E "\"name\":\"[^\"]*${func_name}[^\"]*\"" "$SCI_INDEX_FILE" 2>/dev/null | head -10)
    fi

    if [[ -z "$matches" ]]; then
        echo "[SCI] Function not found: $func_name" >&2
        return 1
    fi

    echo "=== Function Info: $func_name ==="
    while IFS= read -r entry; do
        [[ -z "$entry" ]] && continue
        # Remove trailing comma if present
        entry=$(echo "$entry" | sed 's/,$//')

        local name file line_n kind sig doc params ret is_async is_exported
        name=$(echo "$entry" | grep -oE '"name":"[^"]*"' | head -1 | sed 's/"name":"//;s/"//')
        file=$(echo "$entry" | grep -oE '"file":"[^"]*"' | head -1 | sed 's/"file":"//;s/"//')
        line_n=$(echo "$entry" | grep -oE '"line":[0-9]+' | head -1 | sed 's/"line"://')
        kind=$(echo "$entry" | grep -oE '"kind":"[^"]*"' | head -1 | sed 's/"kind":"//;s/"//')
        sig=$(echo "$entry" | grep -oE '"signature":"[^"]*"' | head -1 | sed 's/"signature":"//;s/"//')
        doc=$(echo "$entry" | grep -oE '"doc":"[^"]*"' | head -1 | sed 's/"doc":"//;s/"//')
        params=$(echo "$entry" | grep -oE '"params":"[^"]*"' | head -1 | sed 's/"params":"//;s/"//')
        ret=$(echo "$entry" | grep -oE '"returnType":"[^"]*"' | head -1 | sed 's/"returnType":"//;s/"//')
        is_async=$(echo "$entry" | grep -oE '"async":(true|false)' | head -1 | sed 's/"async"://')
        is_exported=$(echo "$entry" | grep -oE '"exported":(true|false)' | head -1 | sed 's/"exported"://')

        echo "  Name:       $name"
        echo "  File:       $file:$line_n"
        echo "  Kind:       $kind"
        echo "  Signature:  $sig"
        echo "  Params:     $params"
        echo "  Returns:    ${ret:-unknown}"
        echo "  Async:      ${is_async:-false}"
        echo "  Exported:   ${is_exported:-false}"
        [[ -n "$doc" ]] && echo "  Doc:        $doc"

        # Find files that reference this function (dependencies)
        if [[ -n "$SCI_PROJECT_DIR" ]] && [[ -d "$SCI_PROJECT_DIR" ]]; then
            local deps
            deps=$(grep -rl "$name" "$SCI_PROJECT_DIR" \
                --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.sh" \
                --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=.git --exclude-dir=.soloptilink \
                2>/dev/null | grep -v "$file" | head -10)
            if [[ -n "$deps" ]]; then
                echo "  Referenced by:"
                while IFS= read -r dep; do
                    echo "    - ${dep#$SCI_PROJECT_DIR/}"
                done <<< "$deps"
            fi
        fi

        echo "  ---"
    done <<< "$matches"

    return 0
}

# ============================================================
# Map all TypeScript types/interfaces and their relationships
# ============================================================
_sci_get_type_map() {
    local project_dir="${1:-$SCI_PROJECT_DIR}"

    if [[ ! -f "$SCI_INDEX_FILE" ]]; then
        echo "[SCI] Error: index not built. Run _sci_build_index first." >&2
        return 1
    fi

    echo "=== Type Map ==="

    # List all types
    local types_section=false
    local type_count=0
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        local name file kind extends members
        name=$(echo "$line" | grep -oE '"name":"[^"]*"' | head -1 | sed 's/"name":"//;s/"//')
        file=$(echo "$line" | grep -oE '"file":"[^"]*"' | head -1 | sed 's/"file":"//;s/"//')
        kind=$(echo "$line" | grep -oE '"kind":"[^"]*"' | head -1 | sed 's/"kind":"//;s/"//')
        extends=$(echo "$line" | grep -oE '"extends":"[^"]*"' | head -1 | sed 's/"extends":"//;s/"//')
        members=$(echo "$line" | grep -oE '"members":"[^"]*"' | head -1 | sed 's/"members":"//;s/"//')

        [[ -z "$name" ]] && continue
        [[ "$kind" != "type" && "$kind" != "interface" ]] && continue

        type_count=$((type_count + 1))
        echo "  [${kind}] ${name} @ ${file}"
        [[ -n "$extends" ]] && echo "    extends: $extends"
        [[ -n "$members" ]] && echo "    members: $members"
    done < <(grep -E '"kind":"(type|interface)"' "$SCI_INDEX_FILE" 2>/dev/null)

    # List classes with inheritance
    echo ""
    echo "=== Class Hierarchy ==="
    local class_count=0
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        local name file extends implements methods
        name=$(echo "$line" | grep -oE '"name":"[^"]*"' | head -1 | sed 's/"name":"//;s/"//')
        file=$(echo "$line" | grep -oE '"file":"[^"]*"' | head -1 | sed 's/"file":"//;s/"//')
        extends=$(echo "$line" | grep -oE '"extends":"[^"]*"' | head -1 | sed 's/"extends":"//;s/"//')
        implements=$(echo "$line" | grep -oE '"implements":"[^"]*"' | head -1 | sed 's/"implements":"//;s/"//')
        methods=$(echo "$line" | grep -oE '"methods":[0-9]+' | head -1 | sed 's/"methods"://')

        [[ -z "$name" ]] && continue
        class_count=$((class_count + 1))
        echo "  [class] ${name} @ ${file} (${methods:-0} methods)"
        [[ -n "$extends" ]] && echo "    extends: $extends"
        [[ -n "$implements" ]] && echo "    implements: $implements"
    done < <(grep -E '"kind":"class"' "$SCI_INDEX_FILE" 2>/dev/null)

    echo ""
    echo "Total: ${type_count} types/interfaces, ${class_count} classes"
    return 0
}

# ============================================================
# Score
# ============================================================
sci_score() {
    local total=$((SCI_FUNCTION_COUNT + SCI_TYPE_COUNT + SCI_INTERFACE_COUNT + SCI_CLASS_COUNT))
    if [[ $total -eq 0 ]]; then
        echo "30"
        return 0
    fi

    local score=50
    # Bonus for having a rich index
    [[ $total -gt 10 ]] && score=$((score + 10))
    [[ $total -gt 50 ]] && score=$((score + 10))
    [[ $total -gt 100 ]] && score=$((score + 10))
    [[ $total -gt 500 ]] && score=$((score + 10))
    [[ $SCI_TOTAL_FILES -gt 20 ]] && score=$((score + 10))
    [[ $score -gt 100 ]] && score=100

    echo "$score"
}

# ============================================================
# Report
# ============================================================
sci_report() {
    echo -e "\n  ${BOLD:-}=== Semantic Code Index v${SCI_VERSION} ===${NC:-}"
    echo -e "  Files scanned:   ${SCI_TOTAL_FILES}"
    echo -e "  Functions:       ${SCI_FUNCTION_COUNT}"
    echo -e "  Types:           ${SCI_TYPE_COUNT}"
    echo -e "  Interfaces:      ${SCI_INTERFACE_COUNT}"
    echo -e "  Classes:         ${SCI_CLASS_COUNT}"
    echo -e "  Index timestamp: ${SCI_INDEX_TIMESTAMP:-not built}"
    echo -e "  Score:           $(sci_score)/100"
}

# ============================================================
# Module Registry self-registration
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "semantic-code-index" \
        --version "$SCI_VERSION" \
        --description "セマンティックコードインデックス - 関数/型/クラスの意味検索" \
        --init "sci_init" \
        --report "sci_report" \
        --score "sci_score" \
        --enable-var "ENABLE_SCI" \
        --cli-flags "--semantic-index:--no-semantic-index"
fi

# v2003.1: source時のexit codeを確実に0にする
true
