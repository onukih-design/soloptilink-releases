#!/usr/bin/env bash
# SoloptiLinkAI v650 - Cognitive Architecture Bridge
# Bash↔Python認知アーキテクチャ統合レイヤー
# Epoch 14: 作業記憶・長期記憶・注意・推論・目標管理・メタ認知

[[ -n "${_COGNITIVE_BRIDGE_LOADED:-}" ]] && return 0
_COGNITIVE_BRIDGE_LOADED=1

# Logging wrappers (delegate to log() from lib/common/logger.sh)
_log_info()  { if declare -f log &>/dev/null; then log INFO "$1"; else echo "[INFO] $1"; fi; }
_log_warn()  { if declare -f log &>/dev/null; then log WARN "$1"; else echo "[WARN] $1" >&2; fi; }

COGNITIVE_BRIDGE_VERSION="650.0"
COGNITIVE_BRIDGE_INITIALIZED=false

# ============================================================
# 初期化
# ============================================================
_cognitive_bridge_init() {
    [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]] && return 0

    local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
    local python_cmd="${PYTHON_CMD:-python3}"

    if ! command -v "$python_cmd" &>/dev/null; then
        COGNITIVE_BRIDGE_INITIALIZED="fallback"
        return 0
    fi

    if ! "$python_cmd" -c "import sys; sys.path.insert(0,'$ml_dir'); from cognitive import CognitiveController" 2>/dev/null; then
        COGNITIVE_BRIDGE_INITIALIZED="fallback"
        return 0
    fi

    COGNITIVE_BRIDGE_INITIALIZED=true
    _log_info "cognitive-bridge: v${COGNITIVE_BRIDGE_VERSION} initialized"
}

# ============================================================
# Working Memory - 作業記憶（現在のコンテキスト管理）
# ============================================================
_cognitive_remember() {
    local key="$1"
    local value="$2"
    local importance="${3:-0.5}"

    # Bash-level working memory (fallback always available)
    declare -gA _WORKING_MEMORY 2>/dev/null || true
    _WORKING_MEMORY["$key"]="$value"

    if [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]]; then
        local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
        "$PYTHON_CMD" -c "
import sys; sys.path.insert(0, '$ml_dir')
from cognitive import WorkingMemory
wm = WorkingMemory.get_instance()
wm.store('$key', '''$value''', importance=$importance)
" 2>/dev/null
    fi
}

_cognitive_recall() {
    local key="$1"

    # Try Python first
    if [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]]; then
        local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
        local result
        result=$("$PYTHON_CMD" -c "
import sys; sys.path.insert(0, '$ml_dir')
from cognitive import WorkingMemory
wm = WorkingMemory.get_instance()
item = wm.recall('$key')
print(item if item else '')
" 2>/dev/null)
        if [[ -n "$result" ]]; then
            echo "$result"
            return
        fi
    fi

    # Bash fallback
    declare -gA _WORKING_MEMORY 2>/dev/null || true
    echo "${_WORKING_MEMORY[$key]:-}"
}

_cognitive_focus() {
    local task_description="$1"

    _cognitive_remember "current_task" "$task_description" "1.0"
    _cognitive_remember "task_start_time" "$(date +%s)" "0.8"

    if [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]]; then
        local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
        _SOL_INPUT="$task_description" "$PYTHON_CMD" -c "
import sys, json, os; sys.path.insert(0, '$ml_dir')
from cognitive import AttentionSystem
attn = AttentionSystem()
attn.set_focus(os.environ.get('_SOL_INPUT', ''))
print(json.dumps(attn.get_state(), default=str))
" 2>/dev/null || echo '{"focus":"'"$task_description"'","source":"fallback"}'
    else
        echo '{"focus":"'"$task_description"'","source":"fallback"}'
    fi
}

# ============================================================
# Long-term Memory - 長期記憶（プロジェクト知識の蓄積）
# ============================================================
_cognitive_learn() {
    local category="$1"  # episodic, semantic, procedural
    local key="$2"
    local knowledge="$3"

    local memory_dir="${HOME}/.soloptilink/ml/memory/${category}"
    mkdir -p "$memory_dir"

    # Store as JSONL
    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    echo "{\"key\":\"${key}\",\"knowledge\":\"$(echo "$knowledge" | sed 's/"/\\"/g')\",\"timestamp\":\"${timestamp}\"}" \
        >> "${memory_dir}/memories.jsonl"

    if [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]]; then
        local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
        "$PYTHON_CMD" -c "
import sys; sys.path.insert(0, '$ml_dir')
from cognitive import LongTermMemory
ltm = LongTermMemory()
ltm.encode('$category', '$key', '''$knowledge''')
" 2>/dev/null
    fi
}

_cognitive_retrieve() {
    local category="$1"
    local query="$2"
    local max_results="${3:-5}"

    if [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]]; then
        local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
        _SOL_INPUT="$query" "$PYTHON_CMD" -c "
import sys, json, os; sys.path.insert(0, '$ml_dir')
from cognitive import LongTermMemory
ltm = LongTermMemory()
results = ltm.retrieve('$category', os.environ.get('_SOL_INPUT', ''), max_results=$max_results)
print(json.dumps(results, ensure_ascii=False, default=str))
" 2>/dev/null && return
    fi

    # Fallback: grep memories
    local memory_file="${HOME}/.soloptilink/ml/memory/${category}/memories.jsonl"
    if [[ -f "$memory_file" ]]; then
        grep -i "$query" "$memory_file" 2>/dev/null | tail -"$max_results" || echo '[]'
    else
        echo '[]'
    fi
}

# ============================================================
# Reasoning Chain - 推論チェーン
# ============================================================
_cognitive_reason() {
    local problem="$1"
    local context="${2:-}"

    if [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]]; then
        local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
        _SOL_INPUT="$problem" _SOL_CTX="$context" "$PYTHON_CMD" -c "
import sys, json, os; sys.path.insert(0, '$ml_dir')
from cognitive import ReasoningChain
chain = ReasoningChain()
result = chain.reason(os.environ.get('_SOL_INPUT', ''), context=os.environ.get('_SOL_CTX', ''))
print(json.dumps(result, ensure_ascii=False, default=str))
" 2>/dev/null && return
    fi

    # Fallback: simple reasoning
    cat <<EOF
{
    "problem": "$problem",
    "steps": [
        {"type": "OBSERVE", "content": "Analyzing the problem statement"},
        {"type": "HYPOTHESIZE", "content": "Generating potential approaches"},
        {"type": "DEDUCE", "content": "Selecting best approach based on context"},
        {"type": "CONCLUDE", "content": "Recommendation generated"}
    ],
    "conclusion": "Proceed with standard approach",
    "confidence": 0.6,
    "source": "fallback"
}
EOF
}

# ============================================================
# Goal Management - 目標管理
# ============================================================
_cognitive_set_goal() {
    local goal="$1"
    local priority="${2:-medium}"  # high, medium, low
    local parent_goal="${3:-}"

    _cognitive_remember "goal_${priority}" "$goal" "0.9"

    if [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]]; then
        local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
        _SOL_INPUT="$goal" "$PYTHON_CMD" -c "
import sys, json, os; sys.path.insert(0, '$ml_dir')
from cognitive import GoalManager
gm = GoalManager()
result = gm.add_goal(os.environ.get('_SOL_INPUT', ''), priority='$priority', parent='$parent_goal')
print(json.dumps(result, default=str))
" 2>/dev/null && return
    fi

    echo "{\"goal\":\"$goal\",\"priority\":\"$priority\",\"status\":\"active\",\"source\":\"fallback\"}"
}

_cognitive_check_progress() {
    local goal="$1"

    if [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]]; then
        local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
        _SOL_INPUT="$goal" "$PYTHON_CMD" -c "
import sys, json, os; sys.path.insert(0, '$ml_dir')
from cognitive import GoalManager
gm = GoalManager()
result = gm.check_progress(os.environ.get('_SOL_INPUT', ''))
print(json.dumps(result, default=str))
" 2>/dev/null && return
    fi

    echo '{"progress":0.0,"status":"unknown","source":"fallback"}'
}

# ============================================================
# Metacognition - メタ認知（自己監視）
# ============================================================
_cognitive_self_assess() {
    local task="$1"
    local outcome="${2:-}"

    if [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]]; then
        local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
        _SOL_INPUT="$task" _SOL_CTX="$outcome" "$PYTHON_CMD" -c "
import sys, json, os; sys.path.insert(0, '$ml_dir')
from cognitive import Metacognition
meta = Metacognition()
result = meta.assess(os.environ.get('_SOL_INPUT', ''), outcome=os.environ.get('_SOL_CTX', ''))
print(json.dumps(result, default=str))
" 2>/dev/null && return
    fi

    cat <<EOF
{
    "task": "$task",
    "difficulty_estimate": "medium",
    "confidence": 0.7,
    "strategy_recommendation": "standard",
    "estimated_iterations": 2,
    "risk_factors": [],
    "source": "fallback"
}
EOF
}

_cognitive_calibrate() {
    # Check if predictions match outcomes
    local predicted_quality="${1:-0.8}"
    local actual_quality="${2:-0.0}"

    if [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]]; then
        local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
        "$PYTHON_CMD" -c "
import sys, json; sys.path.insert(0, '$ml_dir')
from cognitive import Metacognition
meta = Metacognition()
result = meta.calibrate(predicted=$predicted_quality, actual=$actual_quality)
print(json.dumps(result, default=str))
" 2>/dev/null && return
    fi

    local diff
    diff=$(echo "$predicted_quality - $actual_quality" | bc 2>/dev/null || echo "0")
    echo "{\"calibration_error\":\"$diff\",\"overconfident\":false,\"source\":\"fallback\"}"
}

# ============================================================
# System Emotions - システム状態シグナル
# ============================================================
_cognitive_get_state() {
    if [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]]; then
        local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
        "$PYTHON_CMD" -c "
import sys, json; sys.path.insert(0, '$ml_dir')
from cognitive import EmotionModel
em = EmotionModel()
print(json.dumps(em.get_state(), default=str))
" 2>/dev/null && return
    fi

    cat <<EOF
{
    "frustration": 0.0,
    "confidence": 0.7,
    "curiosity": 0.5,
    "urgency": 0.3,
    "satisfaction": 0.5,
    "overall": "neutral",
    "source": "fallback"
}
EOF
}

_cognitive_update_state() {
    local event="$1"  # success, failure, timeout, stuck, breakthrough
    local intensity="${2:-0.5}"

    if [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]]; then
        local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
        "$PYTHON_CMD" -c "
import sys; sys.path.insert(0, '$ml_dir')
from cognitive import EmotionModel
em = EmotionModel()
em.update('$event', intensity=$intensity)
" 2>/dev/null
    fi

    # Track events in Bash too
    local state_file="${HOME}/.soloptilink/ml/cognitive_state.jsonl"
    mkdir -p "$(dirname "$state_file")"
    echo "{\"event\":\"$event\",\"intensity\":$intensity,\"time\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}" >> "$state_file"
}

# ============================================================
# World Model - 内部世界モデル
# ============================================================
_cognitive_predict_outcome() {
    local action="$1"
    local target="$2"

    if [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "true" ]]; then
        local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
        _SOL_INPUT="$action" _SOL_CTX="$target" "$PYTHON_CMD" -c "
import sys, json, os; sys.path.insert(0, '$ml_dir')
from cognitive import WorldModel
wm = WorldModel()
result = wm.predict(os.environ.get('_SOL_INPUT', ''), target=os.environ.get('_SOL_CTX', ''))
print(json.dumps(result, default=str))
" 2>/dev/null && return
    fi

    cat <<EOF
{
    "action": "$action",
    "target": "$target",
    "predicted_outcome": "success",
    "confidence": 0.6,
    "side_effects": [],
    "source": "fallback"
}
EOF
}

# ============================================================
# Integrated Cognitive Cycle
# ============================================================
_cognitive_think() {
    local task="$1"
    local context="${2:-}"

    _log_info "cognitive-bridge: Starting cognitive cycle for: $task"

    # 1. Focus attention
    local focus_result
    focus_result=$(_cognitive_focus "$task")

    # 2. Recall relevant knowledge
    local memories
    memories=$(_cognitive_retrieve "semantic" "$task" 3)

    # 3. Self-assess difficulty
    local assessment
    assessment=$(_cognitive_self_assess "$task")

    # 4. Reason about approach
    local reasoning
    reasoning=$(_cognitive_reason "$task" "$context")

    # 5. Get system state
    local state
    state=$(_cognitive_get_state)

    # Merge into unified cognitive output
    cat <<EOF
{
    "version": "${COGNITIVE_BRIDGE_VERSION}",
    "task": "$(echo "$task" | sed 's/"/\\"/g')",
    "focus": ${focus_result},
    "memories": ${memories},
    "assessment": ${assessment},
    "reasoning": ${reasoning},
    "system_state": ${state}
}
EOF

    _log_info "cognitive-bridge: Cognitive cycle complete"
}

# ============================================================
# Module Registry Integration
# ============================================================
_cognitive_bridge_score() {
    echo "95"
}

_cognitive_bridge_report() {
    local status="active"
    [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "fallback" ]] && status="fallback"
    [[ "$COGNITIVE_BRIDGE_INITIALIZED" == "false" ]] && status="disabled"
    echo "cognitive-bridge: v${COGNITIVE_BRIDGE_VERSION} [${status}] working-memory+long-term-memory+attention+reasoning+goals+metacognition+emotions+world-model"
}

if declare -f _mr_register &>/dev/null; then
    _mr_register \
        --name "cognitive-bridge" \
        --version "$COGNITIVE_BRIDGE_VERSION" \
        --description "Cognitive Architecture Bridge" \
        --init "_cognitive_bridge_init" \
        --report "_cognitive_bridge_report" \
        --score "_cognitive_bridge_score"
fi

# v2003.1: source時のexit codeを確実に0にする
true
