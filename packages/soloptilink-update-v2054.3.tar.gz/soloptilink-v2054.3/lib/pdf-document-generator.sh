#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v297.0 - PDF Document Generator
# =============================================================================
# PDF生成サービス自動構築。請求書PDF、レポートPDFのテンプレートと
# 生成サービスを自動生成する。
#
# 機能一覧:
#   _pdg_generate_pdf_service      - PDF生成サービス
#   _pdg_generate_invoice_template - 請求書PDFテンプレート
#   _pdg_generate_report_template  - レポートPDFテンプレート
#
# 全globals: PDG_ prefix
# =============================================================================

[[ -n "${_PDG_LOADED:-}" ]] && return 0; _PDG_LOADED=1

declare -g PDG_VERSION="297.0"
declare -g PDG_GENERATED=0
declare -g PDG_ERRORS=0
declare -g PDG_FILES_WRITTEN=0

pdg_init() { PDG_GENERATED=0; PDG_ERRORS=0; PDG_FILES_WRITTEN=0; return 0; }

_pdg_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then PDG_FILES_WRITTEN=$((PDG_FILES_WRITTEN + 1)); echo "  [pdg] wrote: $filepath" >&2
    else PDG_ERRORS=$((PDG_ERRORS + 1)); fi
}

_pdg_log() { echo -e "  ${GREEN:-\033[0;32m}[PDG]${NC:-\033[0m} $*" >&2; }

# =============================================================================
# _pdg_generate_pdf_service
# =============================================================================
_pdg_generate_pdf_service() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _pdg_log "Generating PDF service..."

    local pdf_ts
    pdf_ts=$(cat <<'PDFEOF'
// =============================================================================
// PDF Generation Service
// Uses Puppeteer for HTML-to-PDF conversion with template rendering
// =============================================================================

export interface PdfOptions {
  format?: 'A4' | 'Letter' | 'A3';
  landscape?: boolean;
  margin?: { top?: string; right?: string; bottom?: string; left?: string };
  headerTemplate?: string;
  footerTemplate?: string;
  displayHeaderFooter?: boolean;
}

export interface PdfResult {
  buffer: Buffer;
  pages: number;
  size: number;
}

export async function generatePdfFromHtml(html: string, options: PdfOptions = {}): Promise<PdfResult> {
  const puppeteer = await import('puppeteer');
  const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] });

  try {
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });

    const pdfBuffer = await page.pdf({
      format: options.format || 'A4',
      landscape: options.landscape || false,
      margin: options.margin || { top: '20mm', right: '15mm', bottom: '20mm', left: '15mm' },
      printBackground: true,
      displayHeaderFooter: options.displayHeaderFooter || false,
      headerTemplate: options.headerTemplate,
      footerTemplate: options.footerTemplate || '<div style="font-size:8px;text-align:center;width:100%;"><span class="pageNumber"></span> / <span class="totalPages"></span></div>',
    });

    const buffer = Buffer.from(pdfBuffer);
    // Estimate pages (rough: ~3000 bytes per page for text-heavy docs)
    const pages = Math.max(1, Math.ceil(buffer.length / 3000));

    return { buffer, pages, size: buffer.length };
  } finally {
    await browser.close();
  }
}

// --- Template Rendering ---
export function renderHtmlTemplate(template: string, data: Record<string, unknown>): string {
  let html = template;
  for (const [key, value] of Object.entries(data)) {
    const replacement = typeof value === 'object' ? JSON.stringify(value) : String(value ?? '');
    html = html.replace(new RegExp(`\\{\\{\\s*${key}\\s*\\}\\}`, 'g'), replacement);
  }
  // Handle {{#each items}}...{{/each}}
  html = html.replace(/\{\{#each\s+(\w+)\}\}([\s\S]*?)\{\{\/each\}\}/g, (_, arrayKey, innerTemplate) => {
    const arr = data[arrayKey];
    if (!Array.isArray(arr)) return '';
    return arr.map((item: any) => {
      let row = innerTemplate;
      for (const [k, v] of Object.entries(item)) {
        row = row.replace(new RegExp(`\\{\\{\\s*${k}\\s*\\}\\}`, 'g'), String(v ?? ''));
      }
      return row;
    }).join('');
  });
  return html;
}

// --- API Route Helper ---
export async function handlePdfRequest(templateName: string, data: Record<string, unknown>, options?: PdfOptions): Promise<Response> {
  const templates: Record<string, string> = {};
  // Templates would be loaded from filesystem or database
  const template = templates[templateName];
  if (!template) {
    return new Response(JSON.stringify({ error: 'Template not found' }), { status: 404 });
  }
  const html = renderHtmlTemplate(template, data);
  const result = await generatePdfFromHtml(html, options);
  return new Response(result.buffer, {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="${templateName}-${Date.now()}.pdf"`,
      'Content-Length': result.size.toString(),
    },
  });
}
PDFEOF
)
    _pdg_write_file "${project_dir}/src/lib/pdf/service.ts" "$pdf_ts"
    PDG_GENERATED=$((PDG_GENERATED + 1))
    return 0
}

# =============================================================================
# _pdg_generate_invoice_template
# =============================================================================
_pdg_generate_invoice_template() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _pdg_log "Generating invoice PDF template..."

    local inv_html
    inv_html=$(cat <<'INVEOF'
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
  body { font-family: 'Helvetica Neue', sans-serif; margin: 0; padding: 40px; color: #333; }
  .header { display: flex; justify-content: space-between; margin-bottom: 40px; }
  .title { font-size: 28px; font-weight: bold; color: #1a1a1a; }
  .invoice-number { font-size: 14px; color: #666; }
  .parties { display: flex; justify-content: space-between; margin-bottom: 30px; }
  .party { width: 45%; }
  .party-label { font-size: 11px; text-transform: uppercase; color: #999; margin-bottom: 5px; }
  .party-name { font-size: 16px; font-weight: bold; }
  .party-detail { font-size: 12px; color: #666; line-height: 1.6; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
  th { background: #f5f5f5; text-align: left; padding: 10px; font-size: 11px; text-transform: uppercase; color: #666; border-bottom: 2px solid #ddd; }
  td { padding: 10px; border-bottom: 1px solid #eee; font-size: 13px; }
  .amount { text-align: right; }
  .totals { margin-left: auto; width: 250px; }
  .total-row { display: flex; justify-content: space-between; padding: 5px 0; font-size: 13px; }
  .total-final { font-size: 18px; font-weight: bold; border-top: 2px solid #333; padding-top: 8px; margin-top: 5px; }
  .notes { margin-top: 30px; font-size: 11px; color: #999; }
  .footer { position: fixed; bottom: 20px; width: 100%; text-align: center; font-size: 10px; color: #ccc; }
</style></head><body>
  <div class="header">
    <div><div class="title">INVOICE</div><div class="invoice-number">#{{invoiceNumber}}</div></div>
    <div style="text-align:right"><div>Issue: {{issueDate}}</div><div>Due: {{dueDate}}</div></div>
  </div>
  <div class="parties">
    <div class="party"><div class="party-label">From</div><div class="party-name">{{fromName}}</div><div class="party-detail">{{fromAddress}}<br>{{fromEmail}}</div></div>
    <div class="party"><div class="party-label">To</div><div class="party-name">{{toName}}</div><div class="party-detail">{{toAddress}}<br>{{toEmail}}</div></div>
  </div>
  <table><thead><tr><th>Description</th><th>Qty</th><th class="amount">Unit Price</th><th class="amount">Amount</th></tr></thead>
    <tbody>{{#each items}}<tr><td>{{description}}</td><td>{{quantity}}</td><td class="amount">{{unitPrice}}</td><td class="amount">{{lineTotal}}</td></tr>{{/each}}</tbody>
  </table>
  <div class="totals">
    <div class="total-row"><span>Subtotal</span><span>{{subtotal}}</span></div>
    <div class="total-row"><span>Tax (10%)</span><span>{{tax}}</span></div>
    <div class="total-row total-final"><span>Total</span><span>{{total}}</span></div>
  </div>
  <div class="notes">{{notes}}</div>
</body></html>
INVEOF
)
    _pdg_write_file "${project_dir}/src/lib/pdf/templates/invoice.html" "$inv_html"
    PDG_GENERATED=$((PDG_GENERATED + 1))
    return 0
}

# =============================================================================
# _pdg_generate_report_template
# =============================================================================
_pdg_generate_report_template() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _pdg_log "Generating report PDF template..."

    local rpt_html
    rpt_html=$(cat <<'RPTEOF'
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
  body { font-family: 'Helvetica Neue', sans-serif; margin: 0; padding: 40px; color: #333; }
  .cover { text-align: center; padding: 100px 0; }
  .cover-title { font-size: 36px; font-weight: bold; color: #1a1a1a; }
  .cover-subtitle { font-size: 18px; color: #666; margin-top: 10px; }
  .cover-date { font-size: 14px; color: #999; margin-top: 30px; }
  .section { margin-top: 40px; page-break-inside: avoid; }
  .section-title { font-size: 20px; font-weight: bold; border-bottom: 2px solid #2563eb; padding-bottom: 5px; margin-bottom: 15px; }
  .metric-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin: 15px 0; }
  .metric { background: #f8f9fa; border-radius: 8px; padding: 15px; text-align: center; }
  .metric-value { font-size: 28px; font-weight: bold; color: #2563eb; }
  .metric-label { font-size: 11px; color: #666; text-transform: uppercase; }
  table { width: 100%; border-collapse: collapse; margin: 15px 0; }
  th { background: #2563eb; color: white; padding: 8px; text-align: left; font-size: 12px; }
  td { padding: 8px; border-bottom: 1px solid #eee; font-size: 12px; }
  tr:nth-child(even) { background: #f9f9f9; }
  .footer { margin-top: 40px; padding-top: 15px; border-top: 1px solid #ddd; font-size: 10px; color: #999; text-align: center; }
</style></head><body>
  <div class="cover">
    <div class="cover-title">{{reportTitle}}</div>
    <div class="cover-subtitle">{{reportSubtitle}}</div>
    <div class="cover-date">Generated: {{generatedDate}}</div>
  </div>
  <div class="section">
    <div class="section-title">Summary</div>
    <div class="metric-grid">
      <div class="metric"><div class="metric-value">{{totalUsers}}</div><div class="metric-label">Total Users</div></div>
      <div class="metric"><div class="metric-value">{{totalRevenue}}</div><div class="metric-label">Revenue</div></div>
      <div class="metric"><div class="metric-value">{{growthRate}}</div><div class="metric-label">Growth</div></div>
    </div>
  </div>
  <div class="section">
    <div class="section-title">Details</div>
    <table><thead><tr><th>Period</th><th>Users</th><th>Revenue</th><th>Orders</th></tr></thead>
      <tbody>{{#each rows}}<tr><td>{{period}}</td><td>{{users}}</td><td>{{revenue}}</td><td>{{orders}}</td></tr>{{/each}}</tbody>
    </table>
  </div>
  <div class="footer">Confidential - {{companyName}} - {{generatedDate}}</div>
</body></html>
RPTEOF
)
    _pdg_write_file "${project_dir}/src/lib/pdf/templates/report.html" "$rpt_html"
    PDG_GENERATED=$((PDG_GENERATED + 1))
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
pdg_report() {
    echo -e "\n  ${BOLD:-}=== pdf-document-generator v${PDG_VERSION} ===${NC:-}"
    echo -e "  生成数: ${PDG_GENERATED}"; echo -e "  エラー: ${PDG_ERRORS}"
}

pdg_score() {
    if [[ ${PDG_GENERATED} -ge 3 ]] && [[ ${PDG_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${PDG_GENERATED} -gt 0 ]] && [[ ${PDG_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "pdf-document-generator" --version "${PDG_VERSION}" \
        --description "PDF生成×請求書テンプレート×レポートテンプレート" \
        --init "pdg_init" --report "pdg_report" --score "pdg_score" \
        --enable-var "ENABLE_PDF_GENERATOR" --cli-flags "--pdf-generator:--no-pdf-generator"
fi

# v2003.1: source時のexit codeを確実に0にする
true
