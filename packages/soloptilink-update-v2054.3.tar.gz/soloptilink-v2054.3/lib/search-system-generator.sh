#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v238.0 - Search System Generator
# =============================================================================
# 全文検索システムの自動生成。
# 検索API/検索UI/インデキシング/サジェスト機能を一貫生成。
#
# 機能:
#   SSG-001: 検索APIエンドポイント生成（フィルタ付き）
#   SSG-002: 検索UI生成（オートコンプリート、ハイライト、ファセット）
#   SSG-003: インデキシング生成（SQLite FTS / Meilisearch）
#   SSG-004: サジェスト/Did-You-Mean生成
#   SSG-005: プロジェクト検索品質スキャン
#
# 全globals: SSG_ prefix
# =============================================================================

[[ -n "${_SEARCH_SYSTEM_GENERATOR_LOADED:-}" ]] && return 0
_SEARCH_SYSTEM_GENERATOR_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g SSG_VERSION="238.0"
declare -g SSG_INITIALIZED=false
declare -g SSG_GENERATED_COUNT=0
declare -g SSG_SCAN_SCORE=100
declare -g SSG_ISSUES=""
declare -g SSG_ISSUE_COUNT=0

declare -g ENABLE_SSG="${ENABLE_SSG:-true}"

# =============================================================================
# 初期化
# =============================================================================
ssg_init() {
    SSG_INITIALIZED=true
    SSG_GENERATED_COUNT=0
    SSG_SCAN_SCORE=100
    SSG_ISSUES=""
    SSG_ISSUE_COUNT=0
    return 0
}

ssg_init_message() {
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Search System Generator v${SSG_VERSION} (API/UI/Index/Suggest)" >&2
}

# =============================================================================
# SSG-001: 検索APIエンドポイント生成
# =============================================================================
_ssg_generate_search_api() {
    local output_dir="${1:-.}"
    local searchable_models="${2:-}"

    echo -e "  ${CYAN:-\033[0;36m}[SSG]${NC:-\033[0m} Generating search API..." >&2

    local api_file="${output_dir}/app/api/search/route.ts"
    mkdir -p "$(dirname "$api_file")"

    cat > "$api_file" <<'SEARCH_API'
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';

const searchSchema = z.object({
  q: z.string().min(1).max(200),
  type: z.enum(['all', 'posts', 'users', 'comments']).optional().default('all'),
  page: z.coerce.number().int().min(1).optional().default(1),
  limit: z.coerce.number().int().min(1).max(50).optional().default(10),
  sort: z.enum(['relevance', 'date', 'name']).optional().default('relevance'),
  filters: z.record(z.string()).optional(),
});

interface SearchResult {
  id: string;
  type: string;
  title: string;
  description: string;
  url: string;
  score: number;
  highlights: Record<string, string>;
  createdAt: string;
}

function highlightMatch(text: string, query: string): string {
  if (!text || !query) return text;
  const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`(${escaped})`, 'gi');
  return text.replace(regex, '<mark>$1</mark>');
}

export async function GET(req: NextRequest) {
  try {
    const params = Object.fromEntries(req.nextUrl.searchParams);
    const { q, type, page, limit, sort } = searchSchema.parse(params);
    const offset = (page - 1) * limit;
    const results: SearchResult[] = [];
    let total = 0;

    // Search posts
    if (type === 'all' || type === 'posts') {
      const posts = await prisma.post?.findMany({
        where: { OR: [{ title: { contains: q, mode: 'insensitive' } }, { content: { contains: q, mode: 'insensitive' } }] },
        take: limit, skip: offset,
        orderBy: sort === 'date' ? { createdAt: 'desc' } : { title: 'asc' },
      }).catch(() => []) ?? [];

      for (const post of posts) {
        results.push({
          id: post.id, type: 'post', title: post.title ?? '',
          description: (post.content ?? '').slice(0, 200),
          url: `/posts/${post.id}`, score: 1.0,
          highlights: { title: highlightMatch(post.title ?? '', q), content: highlightMatch((post.content ?? '').slice(0, 200), q) },
          createdAt: post.createdAt?.toISOString() ?? '',
        });
      }
    }

    // Search users
    if (type === 'all' || type === 'users') {
      const users = await prisma.user?.findMany({
        where: { OR: [{ name: { contains: q, mode: 'insensitive' } }, { email: { contains: q, mode: 'insensitive' } }] },
        take: limit, skip: offset, select: { id: true, name: true, email: true, createdAt: true },
      }).catch(() => []) ?? [];

      for (const user of users) {
        results.push({
          id: user.id, type: 'user', title: user.name ?? user.email,
          description: user.email, url: `/users/${user.id}`, score: 0.8,
          highlights: { name: highlightMatch(user.name ?? '', q) },
          createdAt: user.createdAt?.toISOString() ?? '',
        });
      }
    }

    // Sort by relevance (simple keyword frequency)
    if (sort === 'relevance') {
      results.sort((a, b) => b.score - a.score);
    }

    total = results.length; // In production, use count queries

    return NextResponse.json({
      results: results.slice(0, limit),
      total,
      page, limit,
      totalPages: Math.ceil(total / limit),
      query: q,
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ message: '検索パラメータが不正です' }, { status: 400 });
    }
    console.error('[SEARCH] Error:', err);
    return NextResponse.json({ message: 'サーバーエラー' }, { status: 500 });
  }
}
SEARCH_API

    SSG_GENERATED_COUNT=$((SSG_GENERATED_COUNT + 1))
    echo -e "  ${GREEN:-\033[0;32m}[SSG]${NC:-\033[0m} Generated: search API" >&2
}

# =============================================================================
# SSG-002: 検索UI生成
# =============================================================================
_ssg_generate_search_ui() {
    local output_dir="${1:-.}"

    echo -e "  ${CYAN:-\033[0;36m}[SSG]${NC:-\033[0m} Generating search UI..." >&2

    local search_ui="${output_dir}/components/SearchDialog.tsx"
    mkdir -p "$(dirname "$search_ui")"

    cat > "$search_ui" <<'SEARCH_UI'
'use client';
import { useState, useCallback, useRef, useEffect } from 'react';

interface SearchResult {
  id: string;
  type: string;
  title: string;
  description: string;
  url: string;
  highlights: Record<string, string>;
}

interface SearchDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SearchDialog({ isOpen, onClose }: SearchDialogProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (isOpen) { inputRef.current?.focus(); setQuery(''); setResults([]); }
  }, [isOpen]);

  // Keyboard shortcut: Cmd+K
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); isOpen ? onClose() : {}; }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [isOpen, onClose]);

  const search = useCallback((q: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!q.trim()) { setResults([]); return; }
    debounceRef.current = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(q)}&limit=10`);
        const data = await res.json();
        setResults(data.results ?? []);
        setSelectedIndex(-1);
      } catch { setResults([]); }
      finally { setLoading(false); }
    }, 300);
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setSelectedIndex(i => Math.min(i + 1, results.length - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setSelectedIndex(i => Math.max(i - 1, -1)); }
    else if (e.key === 'Enter' && selectedIndex >= 0) {
      e.preventDefault();
      const item = results[selectedIndex];
      if (item) { window.location.href = item.url; onClose(); }
    }
    else if (e.key === 'Escape') onClose();
  };

  if (!isOpen) return null;

  const typeIcons: Record<string, string> = { post: '\u{1F4DD}', user: '\u{1F464}', comment: '\u{1F4AC}' };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-[15vh]">
      <div className="fixed inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-white rounded-xl shadow-2xl overflow-hidden">
        {/* Search Input */}
        <div className="flex items-center gap-3 px-4 border-b">
          <svg className="w-5 h-5 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          <input ref={inputRef} type="text" value={query} onChange={e => { setQuery(e.target.value); search(e.target.value); }} onKeyDown={handleKeyDown} placeholder="検索 (Ctrl+K)" className="flex-1 py-3 text-sm outline-none" />
          {loading && <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />}
          <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-xs border rounded bg-gray-50 text-gray-400">ESC</kbd>
        </div>

        {/* Results */}
        <div className="max-h-80 overflow-y-auto">
          {results.length === 0 && query && !loading && (
            <p className="p-4 text-center text-sm text-gray-400">検索結果がありません</p>
          )}
          {results.map((r, i) => (
            <a key={r.id} href={r.url} onClick={onClose} className={`flex items-start gap-3 px-4 py-3 hover:bg-gray-50 ${i === selectedIndex ? 'bg-blue-50' : ''}`}>
              <span className="text-lg mt-0.5">{typeIcons[r.type] ?? '\u{1F50D}'}</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900" dangerouslySetInnerHTML={{ __html: r.highlights.title ?? r.title }} />
                <p className="text-xs text-gray-500 truncate" dangerouslySetInnerHTML={{ __html: r.highlights.content ?? r.description }} />
              </div>
              <span className="text-xs text-gray-300 capitalize">{r.type}</span>
            </a>
          ))}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-4 py-2 border-t bg-gray-50 text-xs text-gray-400">
          <span><kbd className="px-1 border rounded bg-white">&uarr;</kbd> <kbd className="px-1 border rounded bg-white">&darr;</kbd> で移動</span>
          <span><kbd className="px-1 border rounded bg-white">Enter</kbd> で開く</span>
        </div>
      </div>
    </div>
  );
}

// Hook: useSearch
export function useSearch() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); setIsOpen(v => !v); }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  return { isOpen, open: () => setIsOpen(true), close: () => setIsOpen(false) };
}
SEARCH_UI

    SSG_GENERATED_COUNT=$((SSG_GENERATED_COUNT + 1))
    echo -e "  ${GREEN:-\033[0;32m}[SSG]${NC:-\033[0m} Generated: search dialog UI" >&2
}

# =============================================================================
# SSG-003: インデキシング生成
# =============================================================================
_ssg_generate_indexing() {
    local output_dir="${1:-.}"
    local engine="${2:-prisma}"

    echo -e "  ${CYAN:-\033[0;36m}[SSG]${NC:-\033[0m} Generating search indexing (${engine})..." >&2

    local index_file="${output_dir}/lib/search-index.ts"
    mkdir -p "$(dirname "$index_file")"

    cat > "$index_file" <<'SEARCH_INDEX'
// Search Indexing Service - Auto-generated by SoloptiLinkAI v238.0
import { prisma } from '@/lib/prisma';

interface IndexableDocument {
  id: string;
  type: string;
  title: string;
  content: string;
  metadata: Record<string, any>;
  updatedAt: Date;
}

// Simple in-memory search index (for small datasets)
let searchIndex: IndexableDocument[] = [];
let lastIndexTime: Date | null = null;

export async function rebuildIndex(): Promise<number> {
  const docs: IndexableDocument[] = [];

  // Index posts
  const posts = await prisma.post?.findMany({ select: { id: true, title: true, content: true, updatedAt: true } }).catch(() => []) ?? [];
  for (const p of posts) {
    docs.push({ id: p.id, type: 'post', title: p.title ?? '', content: (p.content ?? '').slice(0, 5000), metadata: {}, updatedAt: p.updatedAt });
  }

  // Index users
  const users = await prisma.user?.findMany({ select: { id: true, name: true, email: true, updatedAt: true } }).catch(() => []) ?? [];
  for (const u of users) {
    docs.push({ id: u.id, type: 'user', title: u.name ?? u.email, content: u.email, metadata: {}, updatedAt: u.updatedAt });
  }

  searchIndex = docs;
  lastIndexTime = new Date();
  return docs.length;
}

export function searchIndex_query(query: string, type?: string, limit: number = 10): IndexableDocument[] {
  const q = query.toLowerCase();
  let results = searchIndex.filter(doc => {
    if (type && doc.type !== type) return false;
    return doc.title.toLowerCase().includes(q) || doc.content.toLowerCase().includes(q);
  });

  // Score by match position (earlier = better)
  results.sort((a, b) => {
    const aIdx = Math.min(a.title.toLowerCase().indexOf(q), a.content.toLowerCase().indexOf(q));
    const bIdx = Math.min(b.title.toLowerCase().indexOf(q), b.content.toLowerCase().indexOf(q));
    return (aIdx === -1 ? 999 : aIdx) - (bIdx === -1 ? 999 : bIdx);
  });

  return results.slice(0, limit);
}

export function getIndexStats(): { count: number; lastIndexTime: string | null } {
  return { count: searchIndex.length, lastIndexTime: lastIndexTime?.toISOString() ?? null };
}
SEARCH_INDEX

    SSG_GENERATED_COUNT=$((SSG_GENERATED_COUNT + 1))
    echo -e "  ${GREEN:-\033[0;32m}[SSG]${NC:-\033[0m} Generated: search indexing" >&2
}

# =============================================================================
# SSG-004: サジェスト生成
# =============================================================================
_ssg_generate_suggestions() {
    local output_dir="${1:-.}"

    echo -e "  ${CYAN:-\033[0;36m}[SSG]${NC:-\033[0m} Generating search suggestions..." >&2

    local suggest_file="${output_dir}/lib/search-suggest.ts"
    mkdir -p "$(dirname "$suggest_file")"

    cat > "$suggest_file" <<'SEARCH_SUGGEST'
// Search Suggestions & Did-You-Mean - Auto-generated by SoloptiLinkAI v238.0

// Levenshtein distance for typo detection
function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, (_, i) => Array(n + 1).fill(0).map((_, j) => (i === 0 ? j : j === 0 ? i : 0)));
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = a[i - 1] === b[j - 1] ? dp[i - 1][j - 1] : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[m][n];
}

// Popular search terms (should be populated from analytics)
let popularTerms: Map<string, number> = new Map();

export function recordSearchTerm(term: string): void {
  const lower = term.toLowerCase().trim();
  if (lower.length < 2) return;
  popularTerms.set(lower, (popularTerms.get(lower) ?? 0) + 1);
}

export function getSuggestions(query: string, limit: number = 5): string[] {
  const q = query.toLowerCase().trim();
  if (!q) return [];

  // Prefix match
  const prefixMatches = [...popularTerms.entries()]
    .filter(([term]) => term.startsWith(q))
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([term]) => term);

  if (prefixMatches.length >= limit) return prefixMatches;

  // Fuzzy match for remaining slots
  const fuzzyMatches = [...popularTerms.entries()]
    .filter(([term]) => !term.startsWith(q) && levenshtein(q, term) <= 2)
    .sort((a, b) => levenshtein(q, a[0]) - levenshtein(q, b[0]))
    .slice(0, limit - prefixMatches.length)
    .map(([term]) => term);

  return [...prefixMatches, ...fuzzyMatches];
}

export function getDidYouMean(query: string): string | null {
  const q = query.toLowerCase().trim();
  if (!q || popularTerms.has(q)) return null;

  let bestMatch = '';
  let bestDistance = Infinity;
  for (const [term, count] of popularTerms) {
    if (count < 3) continue; // Only suggest popular terms
    const dist = levenshtein(q, term);
    if (dist > 0 && dist <= 2 && dist < bestDistance) {
      bestDistance = dist;
      bestMatch = term;
    }
  }

  return bestMatch || null;
}

export function getPopularSearches(limit: number = 10): string[] {
  return [...popularTerms.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([term]) => term);
}
SEARCH_SUGGEST

    SSG_GENERATED_COUNT=$((SSG_GENERATED_COUNT + 1))
    echo -e "  ${GREEN:-\033[0;32m}[SSG]${NC:-\033[0m} Generated: search suggestions" >&2
}

# =============================================================================
# SSG-005: プロジェクト検索品質スキャン
# =============================================================================
_ssg_scan_project() {
    local project_dir="${1:-.}"

    [[ "$SSG_INITIALIZED" != "true" ]] && ssg_init

    echo -e "  ${CYAN:-\033[0;36m}[SSG]${NC:-\033[0m} Scanning search system..." >&2

    local checks=0 passed=0

    # 検索API存在
    checks=$((checks + 1))
    if find "$project_dir" -type f -name "route.ts" -path "*search*" -not -path "*/node_modules/*" 2>/dev/null | head -1 | grep -q .; then
        passed=$((passed + 1))
    else
        SSG_ISSUES+="[NO_SEARCH_API] 検索APIが見つかりません\n"
        SSG_ISSUE_COUNT=$((SSG_ISSUE_COUNT + 1))
    fi

    # 検索UI存在
    checks=$((checks + 1))
    if find "$project_dir" -type f \( -name "*.tsx" -o -name "*.jsx" \) -not -path "*/node_modules/*" -exec grep -l 'SearchDialog\|SearchBar\|search.*input\|useSearch' {} \; 2>/dev/null | head -1 | grep -q .; then
        passed=$((passed + 1))
    else
        SSG_ISSUES+="[NO_SEARCH_UI] 検索UIが見つかりません\n"
        SSG_ISSUE_COUNT=$((SSG_ISSUE_COUNT + 1))
    fi

    # Zodバリデーション（検索パラメータ）
    checks=$((checks + 1))
    local search_apis
    search_apis=$(find "$project_dir" -type f -name "route.ts" -path "*search*" -not -path "*/node_modules/*" 2>/dev/null)
    if [[ -n "$search_apis" ]]; then
        if echo "$search_apis" | xargs grep -l 'z\.\|zod' 2>/dev/null | head -1 | grep -q .; then
            passed=$((passed + 1))
        else
            SSG_ISSUES+="[NO_SEARCH_VALIDATION] 検索APIにバリデーションがありません\n"
            SSG_ISSUE_COUNT=$((SSG_ISSUE_COUNT + 1))
        fi
    else
        passed=$((passed + 1))  # No search API = skip
    fi

    SSG_SCAN_SCORE=$(( checks > 0 ? passed * 100 / checks : 100 ))
    echo -e "  ${CYAN:-\033[0;36m}[SSG]${NC:-\033[0m} Search score: ${SSG_SCAN_SCORE}/100" >&2
}

# =============================================================================
# レポート
# =============================================================================
ssg_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Search System Generator v${SSG_VERSION} ===${NC:-\033[0m}"
    echo -e "  Generated     : ${SSG_GENERATED_COUNT}"
    echo -e "  Score         : ${SSG_SCAN_SCORE}/100"
    [[ "$SSG_ISSUE_COUNT" -gt 0 ]] && echo -e "  Issues        : ${SSG_ISSUE_COUNT}"
}

ssg_report_json() {
    cat <<EOF
{"module":"search-system-generator","version":"${SSG_VERSION}","generated":${SSG_GENERATED_COUNT},"score":${SSG_SCAN_SCORE},"issues":${SSG_ISSUE_COUNT}}
EOF
}

ssg_score() {
    echo "${SSG_SCAN_SCORE:-100}"
}

# =============================================================================
# v59.0: Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "search-system-generator" \
        --version "238.0" \
        --description "全文検索システム自動生成（API/UI/インデックス/サジェスト）" \
        --init "ssg_init" \
        --report "ssg_report" \
        --score "ssg_score" \
        --enable-var "ENABLE_SSG" \
        --cli-flags "--search-system:--no-search-system" \
        --init-msg "ssg_init_message"
fi

# v2003.1: source時のexit codeを確実に0にする
true
