#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v480.0 - Architecture Evolution Engine
# =============================================================================
# アプリケーションの成長に伴うアーキテクチャの自然な進化を検出し、
# 最適なリファクタリング・移行戦略を提案するエンジン。
# モノリス→マイクロサービス、CSR→SSR等の段階的移行を支援。
#
# Functions:
#   _aev_init               - 初期化
#   _aev_detect_growth      - 成長パターンの検出
#   _aev_suggest_evolution   - アーキテクチャ進化の提案
#   _aev_generate_migration  - マイグレーションプラン生成
#   _aev_assess_complexity  - 複雑度アセスメント
#   _aev_report             - レポート出力
#   _aev_score              - モジュールスコア(0-100)
#
# Globals: AEV_ prefix
# =============================================================================

[[ -n "${_ARCHITECTURE_EVOLUTION_LOADED:-}" ]] && return 0
_ARCHITECTURE_EVOLUTION_LOADED=1

AEV_VERSION="480.0"
AEV_INITIALIZED=false

# --- Storage ---
AEV_DATA_DIR=""
AEV_ANALYSIS_FILE=""
AEV_EVOLUTION_LOG=""
AEV_MIGRATION_PLAN=""

# --- State ---
AEV_TOTAL_FILES=0
AEV_TOTAL_LINES=0
AEV_COMPLEXITY_SCORE=0
AEV_EVOLUTION_STAGE="initial"
AEV_SUGGESTIONS_COUNT=0

# --- Analysis ---
declare -g -A _AEV_FILE_COUNTS=()
declare -g -A _AEV_DIR_SIZES=()
declare -g -A _AEV_GROWTH_INDICATORS=()
declare -g -a _AEV_SUGGESTIONS=()
declare -g -A _AEV_MIGRATION_STEPS=()

# Evolution stages
declare -g -A _AEV_STAGES=(
    ["initial"]="初期プロトタイプ (0-500行)"
    ["growing"]="成長段階 (500-5000行)"
    ["mature"]="成熟段階 (5000-20000行)"
    ["complex"]="複雑化段階 (20000-50000行)"
    ["enterprise"]="エンタープライズ段階 (50000行+)"
)

# =============================================================================
# 初期化
# =============================================================================
_aev_init() {
    local project_dir="${PROJECT_DIR:-.}"
    AEV_DATA_DIR="${project_dir}/.soloptilink/aev"
    AEV_ANALYSIS_FILE="${AEV_DATA_DIR}/analysis.json"
    AEV_EVOLUTION_LOG="${AEV_DATA_DIR}/evolution.jsonl"
    AEV_MIGRATION_PLAN="${AEV_DATA_DIR}/migration.md"

    mkdir -p "$AEV_DATA_DIR"

    AEV_INITIALIZED=true
    return 0
}

# =============================================================================
# 成長パターンの検出
# =============================================================================
_aev_detect_growth() {
    local project_dir="${1:-.}"

    [[ "$AEV_INITIALIZED" != "true" ]] && _aev_init
    [[ ! -d "$project_dir" ]] && return 1

    # ファイル数カウント
    _AEV_FILE_COUNTS["ts"]=$(find "$project_dir" -name "*.ts" -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | wc -l)
    _AEV_FILE_COUNTS["tsx"]=$(find "$project_dir" -name "*.tsx" -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | wc -l)
    _AEV_FILE_COUNTS["css"]=$(find "$project_dir" -name "*.css" -not -path "*/node_modules/*" 2>/dev/null | wc -l)
    _AEV_FILE_COUNTS["test"]=$(find "$project_dir" -name "*.test.*" -o -name "*.spec.*" 2>/dev/null | grep -v node_modules | wc -l)

    AEV_TOTAL_FILES=$(( ${_AEV_FILE_COUNTS["ts"]:-0} + ${_AEV_FILE_COUNTS["tsx"]:-0} ))

    # 行数カウント
    AEV_TOTAL_LINES=0
    local ts_lines
    ts_lines=$(find "$project_dir" -name "*.ts" -o -name "*.tsx" 2>/dev/null | grep -v node_modules | grep -v ".next" | head -200 | xargs wc -l 2>/dev/null | tail -1 | awk '{print $1}')
    AEV_TOTAL_LINES=${ts_lines:-0}

    # 進化段階の判定
    if [[ $AEV_TOTAL_LINES -lt 500 ]]; then
        AEV_EVOLUTION_STAGE="initial"
    elif [[ $AEV_TOTAL_LINES -lt 5000 ]]; then
        AEV_EVOLUTION_STAGE="growing"
    elif [[ $AEV_TOTAL_LINES -lt 20000 ]]; then
        AEV_EVOLUTION_STAGE="mature"
    elif [[ $AEV_TOTAL_LINES -lt 50000 ]]; then
        AEV_EVOLUTION_STAGE="complex"
    else
        AEV_EVOLUTION_STAGE="enterprise"
    fi

    # 成長指標の検出
    local api_routes
    api_routes=$(find "$project_dir" -path "*/api/*" -name "route.ts" 2>/dev/null | grep -v node_modules | wc -l)
    _AEV_GROWTH_INDICATORS["api_routes"]=$api_routes

    local components
    components=$(find "$project_dir" -name "*.tsx" -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | wc -l)
    _AEV_GROWTH_INDICATORS["components"]=$components

    local prisma_models=0
    if [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
        prisma_models=$(grep -c "^model " "${project_dir}/prisma/schema.prisma" 2>/dev/null || echo "0")
    fi
    _AEV_GROWTH_INDICATORS["prisma_models"]=$prisma_models

    # ディレクトリ構造の深さ
    local max_depth
    max_depth=$(find "$project_dir" -type f -name "*.ts" -not -path "*/node_modules/*" 2>/dev/null | awk -F/ '{print NF}' | sort -n | tail -1)
    _AEV_GROWTH_INDICATORS["max_depth"]=${max_depth:-0}

    # 複雑度スコア算出
    AEV_COMPLEXITY_SCORE=$(( (AEV_TOTAL_FILES * 2) + (api_routes * 5) + (prisma_models * 8) + (${max_depth:-0} * 3) ))
    [[ $AEV_COMPLEXITY_SCORE -gt 100 ]] && AEV_COMPLEXITY_SCORE=100

    # ログ記録
    local timestamp
    timestamp=$(date +%s)
    echo "{\"ts\":${timestamp},\"stage\":\"${AEV_EVOLUTION_STAGE}\",\"files\":${AEV_TOTAL_FILES},\"lines\":${AEV_TOTAL_LINES},\"complexity\":${AEV_COMPLEXITY_SCORE}}" >> "$AEV_EVOLUTION_LOG" 2>/dev/null

    echo "${AEV_EVOLUTION_STAGE}:${AEV_COMPLEXITY_SCORE}"
    return 0
}

# =============================================================================
# アーキテクチャ進化の提案
# =============================================================================
_aev_suggest_evolution() {
    [[ "$AEV_INITIALIZED" != "true" ]] && _aev_init

    _AEV_SUGGESTIONS=()

    case "$AEV_EVOLUTION_STAGE" in
        initial)
            _AEV_SUGGESTIONS+=("現段階では単純な構造を維持（過度な抽象化を避ける）")
            _AEV_SUGGESTIONS+=("基本的なディレクトリ構造の確立を推奨")
            ;;
        growing)
            if [[ ${_AEV_GROWTH_INDICATORS["api_routes"]:-0} -gt 10 ]]; then
                _AEV_SUGGESTIONS+=("APIルートのグループ化: /api/v1/[resource] パターンへ移行")
            fi
            if [[ ${_AEV_GROWTH_INDICATORS["components"]:-0} -gt 20 ]]; then
                _AEV_SUGGESTIONS+=("コンポーネントの分類: ui/feature/layout ディレクトリへの整理")
            fi
            _AEV_SUGGESTIONS+=("Service層の導入: ビジネスロジックをAPIルートから分離")
            ;;
        mature)
            _AEV_SUGGESTIONS+=("Repository パターンの導入: データアクセスの抽象化")
            _AEV_SUGGESTIONS+=("依存性注入(DI)の検討: テスタビリティ向上")
            if [[ ${_AEV_GROWTH_INDICATORS["prisma_models"]:-0} -gt 15 ]]; then
                _AEV_SUGGESTIONS+=("データベーススキーマの正規化レビュー")
            fi
            _AEV_SUGGESTIONS+=("モジュール境界の明確化: Barrel exports(index.ts)の活用")
            ;;
        complex)
            _AEV_SUGGESTIONS+=("マイクロフロントエンド検討: 独立デプロイ可能なモジュール分割")
            _AEV_SUGGESTIONS+=("APIゲートウェイの導入: 複数APIの統合管理")
            _AEV_SUGGESTIONS+=("イベント駆動アーキテクチャの検討: サービス間の疎結合化")
            _AEV_SUGGESTIONS+=("CQRSパターン: 読み取りと書き込みの分離")
            ;;
        enterprise)
            _AEV_SUGGESTIONS+=("マイクロサービス分割: ドメイン駆動設計(DDD)に基づく境界設定")
            _AEV_SUGGESTIONS+=("メッセージキュー導入: 非同期処理の分離")
            _AEV_SUGGESTIONS+=("分散トレーシング: OpenTelemetry導入")
            _AEV_SUGGESTIONS+=("マルチリージョンデプロイの検討")
            _AEV_SUGGESTIONS+=("データメッシュ: 分散データガバナンス")
            ;;
    esac

    AEV_SUGGESTIONS_COUNT=${#_AEV_SUGGESTIONS[@]}

    for s in "${_AEV_SUGGESTIONS[@]}"; do
        echo "  [AEV] $s" >&2
    done

    echo "$AEV_SUGGESTIONS_COUNT"
    return 0
}

# =============================================================================
# マイグレーションプラン生成
# =============================================================================
_aev_generate_migration() {
    local target_stage="${1:-}"

    [[ "$AEV_INITIALIZED" != "true" ]] && _aev_init

    [[ -z "$target_stage" ]] && {
        # 次の段階を自動判定
        case "$AEV_EVOLUTION_STAGE" in
            initial) target_stage="growing" ;;
            growing) target_stage="mature" ;;
            mature) target_stage="complex" ;;
            complex) target_stage="enterprise" ;;
            enterprise) target_stage="enterprise" ;;
        esac
    }

    local plan_content="# Architecture Evolution Migration Plan\n\n"
    plan_content+="## Current: ${AEV_EVOLUTION_STAGE} -> Target: ${target_stage}\n\n"
    plan_content+="### Phase 1: Assessment\n"
    plan_content+="- Total files: ${AEV_TOTAL_FILES}\n"
    plan_content+="- Total lines: ${AEV_TOTAL_LINES}\n"
    plan_content+="- Complexity: ${AEV_COMPLEXITY_SCORE}/100\n\n"

    plan_content+="### Phase 2: Refactoring Steps\n"
    local step=1
    for suggestion in "${_AEV_SUGGESTIONS[@]}"; do
        plan_content+="${step}. ${suggestion}\n"
        _AEV_MIGRATION_STEPS["step_${step}"]="$suggestion"
        step=$((step + 1))
    done

    plan_content+="\n### Phase 3: Verification\n"
    plan_content+="- All existing tests must pass\n"
    plan_content+="- No regression in functionality\n"
    plan_content+="- Performance benchmarks maintained\n"

    echo -e "$plan_content" > "$AEV_MIGRATION_PLAN" 2>/dev/null
    echo -e "$plan_content"
    return 0
}

# =============================================================================
# 複雑度アセスメント
# =============================================================================
_aev_assess_complexity() {
    local project_dir="${1:-.}"

    [[ "$AEV_INITIALIZED" != "true" ]] && _aev_init

    local cyclomatic=0
    local coupling=0
    local cohesion=0

    # インポート依存数（結合度の近似）
    coupling=$(find "$project_dir" -name "*.ts" -o -name "*.tsx" 2>/dev/null | grep -v node_modules | grep -v ".next" | head -100 | xargs grep -c "^import " 2>/dev/null | awk '{sum+=$1}END{print sum+0}')

    # エクスポート数（凝集度の近似）
    cohesion=$(find "$project_dir" -name "*.ts" -o -name "*.tsx" 2>/dev/null | grep -v node_modules | grep -v ".next" | head -100 | xargs grep -c "^export " 2>/dev/null | awk '{sum+=$1}END{print sum+0}')

    # 条件分岐数（循環的複雑度の近似）
    cyclomatic=$(find "$project_dir" -name "*.ts" -o -name "*.tsx" 2>/dev/null | grep -v node_modules | grep -v ".next" | head -100 | xargs grep -cE "if |switch |case |\? " 2>/dev/null | awk '{sum+=$1}END{print sum+0}')

    echo "coupling=${coupling},cohesion=${cohesion},cyclomatic=${cyclomatic}"
    return 0
}

# =============================================================================
# レポート
# =============================================================================
_aev_report() {
    echo -e "\n  ${BOLD:-}═══ Architecture Evolution v${AEV_VERSION} ═══${NC:-}"
    echo -e "  進化段階           : ${AEV_EVOLUTION_STAGE} - ${_AEV_STAGES[$AEV_EVOLUTION_STAGE]:-}"
    echo -e "  総ファイル数       : ${AEV_TOTAL_FILES}"
    echo -e "  総行数             : ${AEV_TOTAL_LINES}"
    echo -e "  複雑度             : ${AEV_COMPLEXITY_SCORE}/100"
    echo -e "  提案数             : ${AEV_SUGGESTIONS_COUNT}"
}

_aev_score() {
    [[ "$AEV_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=60
    [[ $AEV_SUGGESTIONS_COUNT -gt 0 ]] && s=$((s + 15))
    [[ $AEV_COMPLEXITY_SCORE -lt 70 ]] && s=$((s + 15))
    [[ $AEV_TOTAL_FILES -gt 0 ]] && s=$((s + 10))
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_aev_init_message() {
    echo -e "  ${GREEN:-}✅ v${AEV_VERSION} architecture-evolution: アーキテクチャ進化エンジン (stage: ${AEV_EVOLUTION_STAGE})${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "architecture-evolution" \
    --version "$AEV_VERSION" \
    --description "アーキテクチャ進化エンジン" \
    --init "_aev_init" \
    --report "_aev_report" \
    --score "_aev_score" \
    --enable-var "ENABLE_ARCHITECTURE_EVOLUTION" \
    --cli-flags "--architecture-evolution:--no-architecture-evolution" \
    --init-msg "_aev_init_message"
