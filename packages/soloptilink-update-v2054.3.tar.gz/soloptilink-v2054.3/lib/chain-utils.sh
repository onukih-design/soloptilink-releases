#!/usr/bin/env bash
# SoloptiLink Chain v55.0 - Utility Functions
# chain.shから分離されたユーティリティ関数群


# ============================================================
# v52.0: エラー記録ヘルパー（握りつぶし防止）
# 使い方: _warn_on_fail "モジュール名" "操作名" コマンド args...
# 失敗時にerr_degradeに記録し、ユーザーにも警告表示。プロセスは続行。
# ============================================================
_warn_on_fail() {
    local _wof_module="$1" _wof_op="$2"
    shift 2
    if "$@" 2>/dev/null; then
        return 0
    else
        local _wof_rc=$?
        if type -t err_degrade &>/dev/null; then
            err_degrade "$_wof_module" "${_wof_op} failed (rc=${_wof_rc})" 2>/dev/null || true
        fi
        echo -e "  ${YELLOW:-}⚠️ ${_wof_module}: ${_wof_op} 失敗 (rc=${_wof_rc}) - 続行${NC:-}" >&2
        return $_wof_rc
    fi
}


# ============================================================
# Claude Code CLI 呼び出し（lib/core/phase-executor.sh + lib/core/permissions.sh に委譲）
# ============================================================
_call_claude() {
    local prompt="$1"
    local output_file="${2:-}"
    local phase_name="${3:-}"  # オプション: フェーズ名（権限レベル自動判定用）

    # ================================================================
    # v55.1: プロンプト品質バリデーター — 送信前に品質を担保
    # ================================================================
    local _pq_len=${#prompt}
    local _pq_phase="${phase_name:-unknown}"

    # 実装系フェーズで極端に短いプロンプトを検出（品質劣化の兆候）
    case "$_pq_phase" in
        implementation|backend|frontend|api|database)
            if [[ $_pq_len -lt 500 ]]; then
                echo -e "  ${YELLOW}⚠️ v55.1 Prompt QA: ${_pq_phase}フェーズのプロンプトが短すぎます (${_pq_len}文字) → 品質劣化リスク${NC}"
                # コンテキスト不足を補完: 基本ルールを強制注入
                prompt+="

=== 品質ルール自動注入（v55.1 Prompt QA） ===
- 全データはDB永続化必須（モックデータ/インメモリ配列禁止）
- 全APIエンドポイントにzodバリデーション必須
- 全async関数にtry-catch + 適切なエラーレスポンス必須
- TypeScript strict mode必須
- サービス層分離必須（APIハンドラにビジネスロジックを書かない）"
            fi
            ;;
    esac

    # v52.0: Enterprise Patterns をフェーズに応じて自動注入（常に有効 — v55.1で必須化）
    # PFP-112: セッション内同一フェーズ2回目以降は1行参照に圧縮（端末経路トークン上限対策）
    if [[ -n "$phase_name" ]] && type -t ep_inject_for_phase &>/dev/null; then
        if type -t ctx_is_injected &>/dev/null && ctx_is_injected "enterprise_patterns_${phase_name}"; then
            prompt+="

## Enterprise Patterns: このセッション(${phase_name}フェーズ)で既に提示済みのエンタープライズ実装パターン・アンチパターン禁止則に引き続き全て従うこと"
        else
            local _ep_len_before=${#prompt}
            prompt=$(ep_inject_for_phase "$prompt" "$phase_name" 2>/dev/null || echo "$prompt")
            # 実際に注入が行われた場合のみ「提示済み」として記録（未注入の誤記録を防止）
            if (( ${#prompt} > _ep_len_before )) && type -t ctx_mark_injected &>/dev/null; then
                ctx_mark_injected "enterprise_patterns_${phase_name}"
            fi
        fi
    fi

    # v53.0: Cross-Session Intelligence - 過去セッションの知見をプロンプトに注入
    if type -t cs_inject_warnings &>/dev/null && [[ $CS_TOTAL_SESSIONS -gt 0 ]] 2>/dev/null; then
        prompt=$(cs_inject_warnings "$prompt" "${DOMAIN_TYPE:-general}" 2>/dev/null || echo "$prompt")
    fi
    if type -t cs_inject_best_practices &>/dev/null && [[ $CS_TOTAL_SESSIONS -gt 2 ]] 2>/dev/null; then
        prompt=$(cs_inject_best_practices "$prompt" "${DOMAIN_TYPE:-general}" 2>/dev/null || echo "$prompt")
    fi

    # v55.0: Prompt Evolution - 学習済みパターンの自動適用
    if type -t pev_mutate_prompt &>/dev/null && [[ "${PEV_ENABLED:-false}" == "true" ]]; then
        prompt=$(pev_mutate_prompt "$prompt" "${DOMAIN_TYPE:-general}" "$phase_name" 2>/dev/null || echo "$prompt")
    fi

    # v2028.2: Learning Pipeline - 中央DB の Predictive Foresight を Claude プロンプトに注入
    # 「他の顧客が直近30日に踏んだエラーパターン」を Top10 で先回りで回避させる
    if type -t pc_inject_predictive_foresight &>/dev/null; then
        prompt=$(pc_inject_predictive_foresight "$prompt" "${DOMAIN_TYPE:-general}" "${phase_name:-}" 10 2>/dev/null || echo "$prompt")
    fi

    # v2035.0: Strategic Planning Engine - 熟考済み戦略計画を全フェーズのプロンプトに注入
    if type -t pc_inject_strategic_plan &>/dev/null; then
        prompt=$(pc_inject_strategic_plan "$prompt" 2>/dev/null || echo "$prompt")
    fi

    # v52.0: エージェントファイルの自動解決
    local _agent_file=""
    if [[ -n "$phase_name" && "${AR_ENABLED:-false}" == "true" ]] && type -t ar_map_phase_to_agents &>/dev/null; then
        local _agent_id
        _agent_id=$(ar_map_phase_to_agents "$phase_name" 2>/dev/null || echo "")
        if [[ -n "$_agent_id" ]]; then
            local _agents_dir="${AR_AGENTS_DIR:-${SCRIPT_DIR:-.}/.claude/agents}"
            if [[ -f "${_agents_dir}/${_agent_id}.md" ]]; then
                _agent_file="${_agents_dir}/${_agent_id}.md"
            fi
        fi
    fi

    # v52.0: Structured Output v2 を優先使用
    if [[ "${SO2_ENABLED:-false}" == "true" ]] && type -t so2_call_claude_structured &>/dev/null; then
        so2_call_claude_structured "$prompt" "$output_file" "$_agent_file" "$phase_name"
        return $?
    fi

    # v52.0: エージェントランタイム経由実行（-a フラグ付き）
    if [[ -n "$_agent_file" && -n "$phase_name" ]] && type -t ar_execute_phase &>/dev/null; then
        ar_execute_phase "$phase_name" "$prompt" "$output_file"
        return $?
    fi

    # v11.0: permissions.shの段階的権限モデルを優先使用
    if [[ -n "$phase_name" ]] && type -t perm_call_claude &>/dev/null; then
        local level
        level=$(perm_level_for_phase "$phase_name" 2>/dev/null || echo "SCOPED")
        perm_call_claude "$level" "$prompt" "$output_file"
        return $?
    fi

    # phase-executor.shのcall_claude()に委譲
    if type -t call_claude &>/dev/null; then
        call_claude "$prompt" "$output_file"
        return $?
    fi

    # フォールバック: 直接Claude CLI呼び出し（v52.0: Smart Retry統合）
    local max_retries="${SR_MAX_RETRIES:-3}"
    local timeout_sec=300

    for ((i=1; i<=max_retries; i++)); do
        local result
        local claude_err_log="${SESSION_LOG_DIR:-/tmp}/claude_stderr.log"
        mkdir -p "$(dirname "$claude_err_log")" 2>/dev/null || true
        # v23.0: timeout コマンド未検出時はtimeoutなしで実行（macOS対応）
        local _fb_claude_cmd
        if command -v timeout &>/dev/null; then
            _fb_claude_cmd="timeout ${timeout_sec} claude"
        else
            _fb_claude_cmd="claude"
        fi
        if result=$(${_fb_claude_cmd} -p \
            --dangerously-skip-permissions \
            --output-format text \
            "${prompt}" 2>>"$claude_err_log"); then
            if [[ -n "$result" ]]; then
                if [[ -n "$output_file" ]]; then
                    mkdir -p "$(dirname "$output_file")" 2>/dev/null || true
                    printf '%s\n' "$result" > "$output_file"
                else
                    printf '%s\n' "$result"
                fi
                # v52.0: Smart Retry成功記録
                if type -t sr_record_outcome &>/dev/null; then
                    _warn_on_fail "SmartRetry" "record_success" sr_record_outcome "success" "true" "$i" || true
                fi
                return 0
            fi
        fi

        # v52.0: Smart Retry統合 - エラー分類→最適リトライ戦略
        local _sr_error_type="unknown"
        local _sr_err_output=""
        if [[ -f "$claude_err_log" ]]; then
            _sr_err_output=$(tail -5 "$claude_err_log" 2>/dev/null || echo "")
        fi

        if type -t sr_classify_error &>/dev/null; then
            _sr_error_type=$(sr_classify_error "$_sr_err_output" "$?" 2>/dev/null || echo "unknown")
            echo -e "${YELLOW}  ⚠️ Claude呼び出し失敗 (試行 ${i}/${max_retries}, エラー種別: ${_sr_error_type})${NC}" >&2

            # v52.0: Error Chain記録
            if type -t ec_record_error &>/dev/null; then
                _warn_on_fail "ErrorChain" "record_claude_fail" ec_record_error "Claude CLI failure: ${_sr_error_type}" "${phase_name:-unknown}" "" || true
            fi

            # Smart Retryでリトライ判定
            if type -t sr_execute_retry &>/dev/null; then
                if ! sr_execute_retry "$_sr_error_type" "$i" "$max_retries" 2>/dev/null; then
                    echo -e "${RED}  ❌ Smart Retry: リトライ中止 (${_sr_error_type})${NC}" >&2
                    _warn_on_fail "SmartRetry" "record_abort" sr_record_outcome "$_sr_error_type" "false" "$i" || true
                    break
                fi
                _warn_on_fail "SmartRetry" "record_retry" sr_record_outcome "$_sr_error_type" "false" "$i" || true
                # Smart Retryのstrategyに基づきtimeout延長
                local _sr_strategy
                _sr_strategy=$(sr_get_strategy "$_sr_error_type" "$i" 2>/dev/null || echo "")
                if echo "$_sr_strategy" | grep -q "timeout_multiplier=2" 2>/dev/null; then
                    timeout_sec=$((timeout_sec * 2))
                fi
                continue
            fi
        else
            echo -e "${YELLOW}  ⚠️ Claude呼び出し失敗 (試行 ${i}/${max_retries})${NC}" >&2
        fi
        sleep $((i * 3))
    done
    echo -e "${RED}  ❌ Claude呼び出し失敗（全リトライ失敗）${NC}" >&2
    return 1
}


# ============================================================
# Claude出力→ファイルライターブリッジ（lib/core/phase-executor.sh に委譲）
# ============================================================
_write_claude_output_to_files() {
    local output_file="$1"
    local expected_file="${2:-}"

    # v52.0: Structured Output v2 を最優先使用
    # JSON構造化出力がある場合、直接ファイルを抽出・書き込み
    if [[ "${SO2_ENABLED:-false}" == "true" ]] && type -t so2_process_output &>/dev/null; then
        local _so2_content=""
        if [[ -f "$output_file" ]]; then
            _so2_content="$(cat "$output_file" 2>/dev/null)"
        fi
        if [[ -n "$_so2_content" ]]; then
            local _project_dir
            _project_dir="$(_detect_project_dir 2>/dev/null || echo ".")"
            if so2_process_output "$_so2_content" "$_project_dir" 2>/dev/null; then
                _so2_log_success="true"
                echo -e "  ${GREEN}📁 Structured Output v2 でファイルを書き出しました${NC}"

                # v52.0: Code Validator 書き込み後検証
                if [[ "${ENABLE_CODE_VALIDATOR:-true}" == "true" ]] && type -t cv_validate_project &>/dev/null; then
                    if ! _warn_on_fail "CodeValidator" "post_write_validate" cv_validate_project "$_project_dir"; then
                        _so2_log "WARN" "Code Validator: 書き込み後検証で問題検出"
                    fi
                fi

                return 0
            fi
            _so2_log "WARN" "Structured Output v2 処理失敗 → 従来のパーサーにフォールバック"
        fi
    fi

    # phase-executor.shのwrite_claude_output_to_files()に委譲
    if type -t write_claude_output_to_files &>/dev/null; then
        write_claude_output_to_files "$output_file" "$expected_file"
        local _write_rc=$?

        # v52.0: Follow-up時はDelta Applierで追加検証+ロールバック対応
        if [[ "${FUC_IS_FOLLOWUP:-false}" == "true" ]] && type -t da_validate_delta &>/dev/null; then
            local _project_dir
            _project_dir="$(_detect_project_dir 2>/dev/null || echo ".")"
            if ! _warn_on_fail "DeltaApplier" "post_write_validate" da_validate_delta "$_project_dir"; then
                echo -e "  ${YELLOW}⚠️ Delta検証FAIL → ロールバック可能（da_rollback_delta）${NC}"
                if type -t ec_record_error &>/dev/null; then
                    _warn_on_fail "ErrorChain" "record_delta_fail" ec_record_error "Delta validation failed after file write" "file_write" "$output_file" || true
                fi
            fi
        fi
        return $_write_rc
    fi

    [[ ! -f "$output_file" ]] && return 0
    local content
    content="$(cat "$output_file" 2>/dev/null)" || return 0
    [[ -z "$content" ]] && return 0

    local written=0

    # v52.0: Follow-up時はDelta Applierを優先使用（バックアップ→適用→検証）
    if [[ "${FUC_IS_FOLLOWUP:-false}" == "true" ]] && type -t da_apply_delta &>/dev/null; then
        local _project_dir
        _project_dir="$(_detect_project_dir 2>/dev/null || echo ".")"

        # バックアップポイント作成
        if type -t da_create_backup_point &>/dev/null; then
            DA_BACKUP_POINT=$(da_create_backup_point "$_project_dir" 2>/dev/null || echo "")
            if [[ -z "$DA_BACKUP_POINT" ]]; then
                echo -e "  ${YELLOW}⚠️ DeltaApplier: バックアップ作成失敗 → ロールバック不可${NC}" >&2
                if type -t err_degrade &>/dev/null; then
                    err_degrade "DeltaApplier" "backup_point creation failed" 2>/dev/null || true
                fi
            fi
        fi

        # Delta適用
        if ! _warn_on_fail "DeltaApplier" "apply_delta" da_apply_delta "$content" "$_project_dir"; then
            echo -e "  ${YELLOW}⚠️ Delta適用失敗 → FileWriter v2にフォールバック${NC}" >&2
        fi
        written="${DA_FILES_APPLIED:-0}"

        if [[ "${written:-0}" -gt 0 ]]; then
            # 検証
            if type -t da_validate_delta &>/dev/null && ! _warn_on_fail "DeltaApplier" "validate_delta" da_validate_delta "$_project_dir"; then
                echo -e "  ${YELLOW}⚠️ Delta検証失敗 → ロールバック実行${NC}"
                if [[ -n "${DA_BACKUP_POINT:-}" ]] && type -t da_rollback_delta &>/dev/null; then
                    if ! _warn_on_fail "DeltaApplier" "rollback_delta" da_rollback_delta "$_project_dir" "$DA_BACKUP_POINT"; then
                        echo -e "  ${RED}❌ ロールバック失敗 → 手動確認が必要${NC}" >&2
                    fi
                fi
                written=0
            else
                echo -e "  ${GREEN}📁 ${written}ファイルをDelta適用しました (Follow-up)${NC}"
                return 0
            fi
        fi
    fi

    # v12.0: FileWriter v2を優先使用
    if [[ "${written:-0}" -eq 0 ]] && type -t fw2_parse_and_write &>/dev/null; then
        written=$(fw2_parse_and_write "$content" "." 2>/dev/null) || {
            echo -e "  ${YELLOW}⚠️ FileWriter v2: 書き込み失敗 → v1にフォールバック${NC}" >&2
            if type -t err_degrade &>/dev/null; then
                err_degrade "FileWriterV2" "parse_and_write failed" 2>/dev/null || true
            fi
            written=0
        }
        if [[ "${written:-0}" -gt 0 ]]; then
            echo -e "  ${GREEN}📁 ${written}ファイルをプロジェクトに書き出しました (FW2)${NC}"
            return 0
        fi
    fi

    # v1フォールバック
    if type -t fw_smart_write &>/dev/null; then
        written=$(fw_smart_write "$content" "." "$expected_file" 2>/dev/null) || {
            echo -e "  ${YELLOW}⚠️ FileWriter v1: 書き込み失敗${NC}" >&2
            if type -t err_degrade &>/dev/null; then
                err_degrade "FileWriterV1" "smart_write failed" 2>/dev/null || true
            fi
            written=0
        }
        if [[ "${written:-0}" -gt 0 ]]; then
            echo -e "  ${GREEN}📁 ${written}ファイルをプロジェクトに書き出しました${NC}"
        fi
    fi
}


# ============================================================
# フェーズ後バリデーション＆ヒーリング（lib/core/phase-executor.sh に委譲）
# ============================================================
_post_phase_validate_and_heal() {
    local phase_name="$1"
    local project_dir="${2:-.}"

    if type -t post_phase_validate_and_heal &>/dev/null; then
        post_phase_validate_and_heal "$phase_name" "$project_dir"
    else
        echo -e "  ${YELLOW}⚠️ phase-executor未ロード → バリデーションスキップ${NC}"
    fi
}


# フェーズ後チェックポイント保存（lib/core/phase-executor.sh に委譲）
_post_phase_checkpoint() {
    local phase_name="$1"
    if type -t post_phase_checkpoint &>/dev/null; then
        post_phase_checkpoint "$phase_name"
    elif type -t checkpoint_auto_save &>/dev/null; then
        checkpoint_auto_save "$SESSION_ID" "$phase_name" 2>/dev/null || true
        echo -e "  ${GREEN}💾 チェックポイント保存: ${phase_name}${NC}"
    fi

    # v28.0: メモリマネージャにフェーズ完了を自動記録
    if type -t mm_auto_record_phase &>/dev/null; then
        mm_auto_record_phase "$phase_name" "success" "" "" 2>/dev/null || true
    fi

    # v28.0: ナレッジグラフにもフェーズ完了を記録
    if type -t kg_auto_record &>/dev/null; then
        kg_auto_record "${DK_DETECTED_DOMAIN:-general}" "$phase_name" "success" "" "" 2>/dev/null || true
    fi
}


# 経過時間表示（lib/core/session.sh に委譲）
_elapsed_time() {
    if type -t session_elapsed &>/dev/null; then
        session_elapsed
    else
        local now
        now=$(date +%s)
        local elapsed=$((now - SESSION_START))
        echo "$((elapsed / 60))分$((elapsed % 60))秒"
    fi
}


# フォールバック: 従来の単体hotfix（Deep Fix Engine未ロード時）
_phase_hotfix_fallback() {
    local session_id="$1"
    local task_desc="$2"

    local rag_content=""
    [[ -f "${SESSION_LOG_DIR}/rag_results.txt" ]] && rag_content="$(cat "${SESSION_LOG_DIR}/rag_results.txt")"

    # v55.1: エラーコンテキストを収集してプロンプトに注入
    local error_context=""
    local project_dir
    project_dir="$(_detect_project_dir 2>/dev/null || echo ".")"

    # 直近のビルドエラー/テストエラーを取得
    for log_file in "${SESSION_LOG_DIR}/quality_gate_report.md" \
                    "${SESSION_LOG_DIR}/smoke_test_report.md" \
                    "${SESSION_LOG_DIR}/build_errors.log" \
                    "${SESSION_LOG_DIR}/test_errors.log"; do
        if [[ -f "$log_file" ]]; then
            error_context+="
--- $(basename "$log_file") ---
$(tail -50 "$log_file" 2>/dev/null)"
        fi
    done

    # TypeScript/ESLintエラーを取得
    if [[ -d "$project_dir" ]]; then
        local _tsc_errors
        _tsc_errors=$(cd "$project_dir" && npx tsc --noEmit 2>&1 | tail -30 || echo "")
        [[ -n "$_tsc_errors" && "$_tsc_errors" != *"not found"* ]] && error_context+="
--- TypeScript Errors ---
${_tsc_errors}"
    fi

    # Error Chain履歴を取得
    if type -t ec_get_recent &>/dev/null; then
        local _ec_recent
        _ec_recent=$(ec_get_recent 5 2>/dev/null || echo "")
        [[ -n "$_ec_recent" ]] && error_context+="
--- Error Chain (直近5件) ---
${_ec_recent}"
    fi

    local prompt="あなたはデバッグのエキスパートです。以下の問題を特定し修正してください。

=== 問題の説明 ===
${task_desc}

=== エラーコンテキスト（実際のエラー情報） ===
${error_context:-(エラーログなし → プロジェクト内のファイルを読んで問題を特定すること)}

=== 関連する過去の知見 ===
${rag_content:-（なし）}

=== 修正手順（厳守） ===
1. エラーメッセージから根本原因を特定（推測ではなくエラーログに基づく）
2. 影響を受けるファイルを全て特定（import依存を辿る）
3. 修正の実装（実際にファイルを書き換えること）
4. 修正後にTypeScriptコンパイルエラーがないことを確認
5. 関連するテストが通ることを確認

実際にファイルを修正してください。修正理由をコメントで残すこと。"

    local output_file="${SESSION_LOG_DIR}/hotfix_report.md"
    if _call_claude "$prompt" "$output_file"; then
        echo -e "  ${GREEN}✅ バグ修正完了${NC}"
        _write_claude_output_to_files "$output_file"
    else
        echo -e "  ${RED}❌ バグ修正失敗${NC}"
    fi
}


# ============================================================
# URL駆動開発モード
# ============================================================
_url_driven_development() {
    local url1="$1"
    local url2="${2:-}"
    local task_desc="$3"

    echo -e "\n${BOLD}${PURPLE}╔═══════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${PURPLE}║       URL駆動開発モード                    ║${NC}"
    echo -e "${BOLD}${PURPLE}╚═══════════════════════════════════════════╝${NC}\n"

    if ! type -t url_init &>/dev/null; then
        echo -e "  ${RED}❌ URL Analyzerモジュールが未ロードです${NC}"
        echo -e "  ${YELLOW}lib/url-analyzer.sh を確認してください${NC}"
        return 1
    fi

    # Phase 1: URL分析セッション初期化
    echo -e "  ${BOLD}[Phase 1/3] URL分析${NC}"
    url_init "$SESSION_ID"

    url_analyze "$url1" "${UA_SESSION_DIR}/analyses"
    echo -e "  ${GREEN}✅ URL1分析完了: ${url1}${NC}"

    if [[ -n "$url2" ]]; then
        url_analyze "$url2" "${UA_SESSION_DIR}/analyses"
        echo -e "  ${GREEN}✅ URL2分析完了: ${url2}${NC}"
    fi

    # デザイントークン抽出
    if type -t url_extract_design_tokens &>/dev/null; then
        url_extract_design_tokens "$url1" "${UA_SESSION_DIR}/design" 2>/dev/null || true
    fi

    _post_phase_checkpoint "url_analysis"

    # Phase 2: 統合要件生成
    echo -e "\n  ${BOLD}[Phase 2/3] 統合要件・仕様書生成${NC}"
    if [[ -n "$url2" ]]; then
        url_combine_requirements "${UA_SESSION_DIR}/analyses" "$task_desc"
    else
        # URL1つの場合は単独分析から要件生成
        local analysis_file="${UA_SESSION_DIR}/analyses/url_analysis_1.md"
        if [[ -f "$analysis_file" ]]; then
            local analysis_content
            analysis_content="$(cat "$analysis_file")"
            local req_prompt="以下のサイト分析に基づいて要件定義書を作成してください。

サイト分析:
${analysis_content}

タスク: ${task_desc}

Markdown形式で要件定義書を作成。"
            _call_claude "$req_prompt" "${UA_SESSION_DIR}/analyses/combined_requirements.md" || true
        fi
    fi

    # 技術仕様書生成
    local combined_req="${UA_SESSION_DIR}/analyses/combined_requirements.md"
    if [[ -f "$combined_req" ]]; then
        url_generate_spec "$combined_req" "${UA_SESSION_DIR}/spec" 2>/dev/null || true
    fi

    _post_phase_checkpoint "url_spec_generation"

    # Phase 3: DAGパイプラインへの橋渡し
    echo -e "\n  ${BOLD}[Phase 3/3] DAGパイプラインへ接続${NC}"
    REQUIREMENTS_FILE="${UA_SESSION_DIR}/analyses/combined_requirements.md"
    SPEC_DIR="${UA_SESSION_DIR}/spec"

    echo -e "  ${GREEN}✅ URL駆動分析完了 → DAGパイプライン実行へ${NC}"
}


# ============================================================
# バリデーションのみモード
# ============================================================
_validate_mode() {
    local target_dir="$1"
    local auto_fix="${2:-false}"

    echo -e "\n${BOLD}${CYAN}╔═══════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${CYAN}║       バリデーション専用モード              ║${NC}"
    echo -e "${BOLD}${CYAN}╚═══════════════════════════════════════════╝${NC}\n"

    if ! type -t validator_init &>/dev/null; then
        echo -e "  ${RED}❌ バリデータモジュールが未ロードです${NC}"
        return 1
    fi

    validator_init "$target_dir"
    local report
    report=$(validator_run_all "$target_dir")
    local error_count
    error_count=$(validator_count_errors "$report" 2>/dev/null || echo "0")

    echo -e "\n  ${BOLD}検出エラー数: ${error_count}${NC}"

    if [[ "$auto_fix" == "true" && "$error_count" -gt 0 ]]; then
        echo -e "  ${PURPLE}自動修正モード有効 → ヒーリング開始${NC}"
        if type -t healer_init &>/dev/null; then
            healer_init "$SESSION_ID" "$target_dir"
            healer_run "$target_dir" "$report"

            # 再バリデーション
            echo -e "\n  ${BOLD}修正後再バリデーション:${NC}"
            local re_report
            re_report=$(validator_run_all "$target_dir")
            local re_error_count
            re_error_count=$(validator_count_errors "$re_report" 2>/dev/null || echo "0")
            echo -e "  残存エラー数: ${re_error_count}"
        else
            echo -e "  ${RED}❌ ヒーラーモジュール未ロード${NC}"
        fi
    fi

    if type -t validator_report &>/dev/null; then
        validator_report "$report"
    fi

    return $((error_count > 0 ? 1 : 0))
}


# ============================================================
# チェックポイントからの再開
# ============================================================
_resume_from_checkpoint() {
    echo -e "\n${BOLD}${CYAN}╔═══════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${CYAN}║       チェックポイント再開モード            ║${NC}"
    echo -e "${BOLD}${CYAN}╚═══════════════════════════════════════════╝${NC}\n"

    if ! type -t checkpoint_latest &>/dev/null; then
        echo -e "  ${RED}❌ チェックポイントモジュールが未ロードです${NC}"
        return 1
    fi

    local latest_info
    latest_info=$(checkpoint_latest 2>/dev/null || echo "")

    if [[ -z "$latest_info" ]]; then
        echo -e "  ${YELLOW}チェックポイントが見つかりません${NC}"
        return 1
    fi

    echo -e "  ${GREEN}最新チェックポイント情報:${NC}"
    echo "$latest_info"

    # セッションIDとステージを抽出
    local ckp_session ckp_stage
    ckp_session=$(echo "$latest_info" | grep -o '"stage"[^,]*' | head -1 | sed 's/.*: *"\([^"]*\)".*/\1/' || echo "")

    echo -e "\n  ${CYAN}チェックポイントから復帰しました。DAGパイプラインを再開してください。${NC}"
    return 0
}


# ============================================================
# シンプル実行モード（DAGモジュールがない場合のフォールバック）
# ============================================================
_simple_execution() {
    local task_desc="$1"

    echo -e "${YELLOW}⚠️ DAGモジュール未検出 → シンプルモードで実行${NC}"

    # v52.0: Follow-upフェーズスキップヘルパー
    _should_skip() {
        local phase_name="$1"
        if [[ "${FUC_IS_FOLLOWUP:-false}" == "true" ]] && type -t fuc_should_skip_phase &>/dev/null; then
            if fuc_should_skip_phase "$phase_name" "${FUC_REQUEST_TYPE:-modification}"; then
                echo -e "  ${DIM}⏭️ フェーズスキップ: ${phase_name} (Follow-up: ${FUC_REQUEST_TYPE})${NC}"
                return 0
            fi
        fi
        return 1
    }

    # NOTE: phase_prompt_expand, phase_data_import, phase_scaffold は main() 側で既に実行済み
    # ここでは従来フェーズのみ実行する（二重実行防止）

    # フェーズ完了カウンター更新ヘルパー
    _phase_done() { (( _COMPLETED_PHASE_COUNT++ )) || true; }

    # 従来フェーズ（v52.0: Follow-upスキップ対応）
    _should_skip "requirements" || { phase_requirements "$SESSION_ID" "$task_desc"; _phase_done; }
    _should_skip "rag_search"   || { phase_rag_search "$SESSION_ID" "$task_desc"; _phase_done; }

    # v18.0: SaaSアーキテクチャ（DB設計後、バックエンド実装前）
    _should_skip "saas_architecture" || { phase_saas_architecture "$SESSION_ID" "$task_desc"; _phase_done; }

    # v52.0: Micro-Task Engine による分割実装（medium以上の複雑度で使用）
    if [[ "${MT_ENABLED:-false}" == "true" ]] && type -t mt_should_decompose &>/dev/null && \
       mt_should_decompose "$task_desc" "${PIPELINE_MODE:-standard}" 2>/dev/null; then
        _mt_log_info="${CYAN}[MICRO-TASK]${NC}"
        echo -e "  ${_mt_log_info} マイクロタスク分割モードで実装を実行"

        local _mt_domain_knowledge=""
        local _mt_blueprint=""

        # ドメイン知識を取得（Domain Knowledge Injectorから）
        if type -t dk_get_knowledge_text &>/dev/null; then
            _mt_domain_knowledge=$(dk_get_knowledge_text 2>/dev/null || echo "")
        fi
        # 設計図を取得（Blueprint Generatorから）
        if [[ -f "${SESSION_LOG_DIR:-/tmp}/blueprint.md" ]]; then
            _mt_blueprint=$(cat "${SESSION_LOG_DIR:-/tmp}/blueprint.md" 2>/dev/null || echo "")
        fi

        mt_decompose_task "$task_desc" "${EP_DOMAIN:-}" "${EP_TECH_STACK:-nextjs}"
        mt_execute_pipeline "$task_desc" "$(_detect_project_dir 2>/dev/null || echo ".")" \
            "$_mt_domain_knowledge" "$_mt_blueprint"
    else
        # 従来の単一実装フェーズ
        phase_implementation "$SESSION_ID" "$task_desc"
    fi
    _phase_done

    # v20.0: Quality Fortress - 品質ゲート→機能修復ループ
    if ! phase_quality_gate "$SESSION_ID" "$task_desc"; then
        phase_functional_healing "$SESSION_ID" "$task_desc"

        # v52.0: Phase C-11: 修正適用後の自動スモークテスト検証
        if [[ "${ENABLE_SMOKE_TEST:-true}" == "true" ]] && type -t str_run_smoke_tests &>/dev/null; then
            echo -e "  ${CYAN}🧪 修正後スモークテスト（自動検証）${NC}"
            local _post_heal_dir
            _post_heal_dir="$(_detect_project_dir 2>/dev/null || echo ".")"
            if str_run_smoke_tests "$_post_heal_dir" 2>/dev/null; then
                echo -e "  ${GREEN}✅ 修正後スモークテストPASS - 修復を確認${NC}"
            else
                echo -e "  ${YELLOW}⚠️ 修正後スモークテストFAIL - 追加修正が必要な可能性${NC}"
                if type -t ec_record_error &>/dev/null; then
                    _warn_on_fail "ErrorChain" "record_smoke_fail" ec_record_error "Post-healing smoke test FAIL" "smoke_test_post_heal" "$_post_heal_dir" || true
                fi
            fi
        fi
    fi
    _phase_done

    # v18.0: AI統合レイヤー（フロントエンド実装後、品質チェック前）
    _should_skip "ai_integration" || phase_ai_integration "$SESSION_ID" "$task_desc"

    phase_quality_check "$SESSION_ID" "$task_desc"

    # v53.0: ガバナンス検証（閾値ベースゲート制御 - || true 廃止）
    if [[ "${ENABLE_GOVERNANCE:-true}" == "true" ]]; then
        local _gov_project_dir
        _gov_project_dir="$(_detect_project_dir 2>/dev/null || echo ".")"

        if type -t ge_enforce_governance &>/dev/null; then
            # v53.0: 新しい閾値ベースゲート
            local _gov_rc=0
            ge_enforce_governance "$_gov_project_dir" "${GOVERNANCE_PASS_THRESHOLD:-80}" "${GOVERNANCE_WARN_THRESHOLD:-60}" || _gov_rc=$?

            case $_gov_rc in
                0) ;; # PASS - 続行
                1) # WARNING - 警告して続行
                    echo -e "  ${YELLOW}⚠️ ガバナンス警告あり。品質改善を検討してください${NC}" >&2
                    ;;
                2) # FAIL - 修復を試行
                    echo -e "  ${RED}❌ ガバナンスFAIL。Functional Healerで修復を試行...${NC}" >&2
                    if type -t phase_functional_healing &>/dev/null; then
                        phase_functional_healing "$SESSION_ID" "ガバナンス違反の修復: ${AG_ISSUES[*]:0:3}"
                        # 再チェック
                        ge_enforce_governance "$_gov_project_dir" "${GOVERNANCE_PASS_THRESHOLD:-80}" "${GOVERNANCE_WARN_THRESHOLD:-60}" || true
                    fi
                    ;;
            esac
        elif type -t pe_execute_governance_check &>/dev/null; then
            # フォールバック: 旧方式
            pe_execute_governance_check "$_gov_project_dir"
        fi
        _GOVERNANCE_EXECUTED="true"
    fi

    # v53.0: Voting Engine（実効化 - 品質判定に投票結果を反映）
    if [[ "${ENABLE_SWARM:-true}" == "true" ]] && type -t pe_execute_swarm_vote &>/dev/null; then
        pe_execute_swarm_vote "$(_detect_project_dir 2>/dev/null || echo ".")" "quality_decision"
        # v53.0: 投票結果をQuality Gateスコアに統合
        if type -t vt_score &>/dev/null; then
            local _vote_health
            _vote_health=$(vt_score 2>/dev/null || echo "0")
            if [[ "${_vote_health}" -lt 50 ]]; then
                echo -e "  ${YELLOW}⚠️ [v53.0 Swarm] エージェント投票の健全性が低い(${_vote_health}/100) - 品質閾値を引き上げ${NC}"
                export QUALITY_THRESHOLD=$(( ${QUALITY_THRESHOLD:-80} > 85 ? ${QUALITY_THRESHOLD:-80} : 85 ))
            fi
        fi
    fi

    phase_testing "$SESSION_ID" "$task_desc"

    # NOTE: セキュリティ監査・ブラウザテスト・自動デプロイはmain()側で実行されるため、
    # ここでは実行しない（二重実行防止）

    phase_documentation "$SESSION_ID" "$task_desc"
    phase_knowledge_save "$SESSION_ID" "$task_desc"

    return 0
}


# ============================================================
# 自動複雑度判定（lib/core/phase-executor.sh に委譲）
# ============================================================
_auto_detect_complexity() {
    local task="$1"
    if type -t auto_detect_complexity &>/dev/null; then
        auto_detect_complexity "$task"
    else
        local task_lower
        task_lower=$(echo "$task" | tr '[:upper:]' '[:lower:]')
        if [[ "$task_lower" =~ (エラー|error|crash|壊れ|動かない|broken|障害) ]]; then echo "hotfix"
        elif [[ "$task_lower" =~ (修正|fix|バグ|bug|typo|リファクタ) ]]; then echo "quick"
        else echo "deep"; fi
    fi
}


# ============================================================
# タイムアウト監視（lib/core/session.sh に委譲）
# ============================================================
_start_timeout_watchdog() {
    if type -t session_start_watchdog &>/dev/null; then
        session_start_watchdog
        WATCHDOG_PID="${SESSION_WATCHDOG_PID:-}"
        return $?
    fi

    # フォールバック: 簡易ウォッチドッグ（v13.0強化）
    local timeout=$SESSION_TIMEOUT
    local parent_pid=$$
    (
        # 残り5分警告
        sleep $((timeout - 300)) 2>/dev/null && \
            echo -e "\n${YELLOW}⏰ 残り5分 (推定コスト: \$${CLAUDE_ESTIMATED_COST:-0.00})${NC}" 2>/dev/null || true
        # 残り1分警告
        sleep 240 2>/dev/null && \
            echo -e "\n${RED}⏰ 残り1分${NC}" 2>/dev/null || true
        sleep 60 2>/dev/null
        # タイムアウト時にチェックポイント保存
        type -t checkpoint_auto_save &>/dev/null && \
            checkpoint_auto_save "$SESSION_ID" "timeout_autosave" 2>/dev/null || true
        # コスト情報をログに記録
        if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
            printf '[%s] SESSION_TIMEOUT calls=%s cost=$%s\n' \
                "$(date '+%Y-%m-%d %H:%M:%S')" "${CLAUDE_CALL_COUNT:-0}" "${CLAUDE_ESTIMATED_COST:-0.00}" \
                >> "${SESSION_LOG_DIR}/claude_calls.log" 2>/dev/null || true
        fi
        kill -0 "$parent_pid" 2>/dev/null && kill -TERM "$parent_pid" 2>/dev/null || true
    ) &
    WATCHDOG_PID=$!
    disown "$WATCHDOG_PID" 2>/dev/null || true
}


# ============================================================
# 実行後処理（lib/core/report.sh に委譲）
# ============================================================
_post_execution() {
    if type -t post_execution &>/dev/null; then
        post_execution "$SESSION_ID"
    else
        echo -e "\n${BOLD}${CYAN}━━━ 実行後処理 ━━━${NC}"
        [[ "$NO_LEARN" != "1" ]] && type -t rt_sync_to_global &>/dev/null && \
            rt_sync_to_global "$SESSION_ID" 2>/dev/null || true
        [[ "$NO_RAG" != "1" ]] && type -t rt_index_session_knowledge &>/dev/null && \
            rt_index_session_knowledge "$SESSION_ID" 2>/dev/null || true
        type -t checkpoint_cleanup &>/dev/null && \
            checkpoint_cleanup "$SESSION_ID" 5 2>/dev/null || true
        echo -e "  ${GREEN}✅ 実行後処理完了${NC}"
    fi

    # v15.0: セッション状態保存
    if type -t ss_save_state &>/dev/null; then
        ss_save_state 2>/dev/null || true
        echo -e "  ${CYAN}📋 セッション状態保存完了${NC}"
    fi

    # v15.0: post_session フック発火
    if type -t pl_fire_hook &>/dev/null; then
        pl_fire_hook "post_session" "$SESSION_ID" 2>/dev/null || true
    fi

    # v15.0: ログローテーション
    if type -t lr_rotate_events &>/dev/null; then
        lr_rotate_events "${SESSION_LOG_DIR}/observatory/events.jsonl" 2>/dev/null || true
    fi

    # v15.5: Compress old rotated logs and cleanup old sessions
    if type -t lr_compress_old_logs &>/dev/null; then
        lr_compress_old_logs "${SESSION_LOG_DIR:-}" 2>/dev/null || true
    fi
    if type -t lr_cleanup_sessions &>/dev/null; then
        lr_cleanup_sessions "${SCRIPT_DIR}/docs/chain-logs" 2>/dev/null || true
    fi

    # v15.0: エージェントランタイムレポート
    if [[ "${ENABLE_AGENTS:-true}" == "true" ]] && type -t ar_report &>/dev/null; then
        ar_report 2>/dev/null || true
    fi

    # v15.0: プラグインレポート
    if [[ "${PL_TOTAL_PLUGINS:-0}" -gt 0 ]] && type -t pl_report &>/dev/null; then
        pl_report 2>/dev/null || true
    fi

    # v16.0: モデルルーターレポート
    if [[ "${MR_ENABLED:-false}" == "true" ]] && type -t mr_report &>/dev/null; then
        mr_report 2>/dev/null || true
        type -t mr_export_json &>/dev/null && mr_export_json 2>/dev/null || true
    fi

    # v16.0: コンテキスト予算レポート
    if [[ "${CB_ENABLED:-false}" == "true" ]] && type -t cb_report &>/dev/null; then
        cb_report 2>/dev/null || true
        type -t cb_export_json &>/dev/null && cb_export_json 2>/dev/null || true
    fi

    # v16.0: Planner-Judgeレポート
    if [[ "${PJ_ENABLED:-false}" == "true" ]] && type -t pj_report &>/dev/null; then
        pj_report 2>/dev/null || true
        type -t pj_export_json &>/dev/null && pj_export_json 2>/dev/null || true
    fi

    # v16.0: メモリマネージャレポート
    if [[ "${MM_ENABLED:-false}" == "true" ]] && type -t mm_report &>/dev/null; then
        mm_report 2>/dev/null || true
        type -t mm_export_json &>/dev/null && mm_export_json 2>/dev/null || true
    fi

    # v16.0: コンテキスト予算再配分（完了フェーズの余剰を解放）
    if [[ "${CB_ENABLED:-false}" == "true" ]] && type -t cb_rebalance &>/dev/null; then
        cb_rebalance "" 2>/dev/null || true
    fi

    # v16.0: メモリ減衰（古いエピソードの関連度を下げる）
    if [[ "${MM_ENABLED:-false}" == "true" ]] && type -t mm_decay &>/dev/null; then
        mm_decay 0.95 2>/dev/null || true
    fi
}


# ============================================================
# 最終レポート（lib/core/report.sh に委譲）
# ============================================================
_final_report() {
    local task_desc="$1"
    local exit_code="${2:-0}"

    if type -t final_report &>/dev/null; then
        final_report "$task_desc" "$exit_code"
    else
        # フォールバック: 簡易レポート
        local session_end
        session_end=$(date +%s)
        local duration=$((session_end - SESSION_START))
        echo ""
        echo -e "${BOLD}╔═══════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BOLD}║              最終レポート (v${VERSION})                         ║${NC}"
        echo -e "${BOLD}╠═══════════════════════════════════════════════════════════╣${NC}"
        echo -e "║ タスク      : ${task_desc:0:45}"
        echo -e "║ セッション  : ${SESSION_ID}"
        echo -e "║ 実行時間    : $((duration / 60))分$((duration % 60))秒"
        echo -e "║ ステータス  : $([ "$exit_code" == "0" ] && echo "${GREEN}✅ SUCCESS${NC}" || echo "${RED}❌ FAILED${NC}")"
        echo -e "${BOLD}╚═══════════════════════════════════════════════════════════╝${NC}"
    fi

    # v18.0 Intelligent Platform メトリクス
    if [[ "${ENABLE_DATA_IMPORT}" == "true" ]]; then
        echo -e "  ${PURPLE}📊 データインポート: ${DIN_TABLE_COUNT:-0}テーブル, ${DIN_COLUMN_COUNT:-0}カラム${NC}"
    fi
    if [[ "${ENABLE_SAAS}" == "true" ]]; then
        echo -e "  ${PURPLE}🏢 SaaS: テナント分離=${TENANT_STRATEGY:-auto}, 認証=${AUTH_METHODS:-jwt}${NC}"
    fi
    if [[ "${ENABLE_AI}" == "true" ]]; then
        echo -e "  ${PURPLE}🤖 AI統合: プロバイダー=${LLM_PROVIDERS:-auto}, RAG=${ENABLE_RAG}${NC}"
    fi

    # v23.0: Error Guardian レポート
    if type -t err_report &>/dev/null && [[ "$(err_count TOTAL)" -gt 0 ]]; then
        err_report
    fi

    # v11.0: permissions.shレポート
    if type -t perm_report &>/dev/null; then
        perm_report
    fi

    # v28.0: セッション総合記録（メモリマネージャ）
    if type -t mm_record_session_summary &>/dev/null; then
        mm_record_session_summary "$SESSION_ID" "$task_desc" "${DK_DETECTED_DOMAIN:-general}" \
            "${TOTAL_PHASES:-0}" "${SUCCESS_PHASES:-0}" "${TOTAL_ERRORS:-0}" "${TOTAL_HEALS:-0}" \
            "${QG_SCORE:-0}" 2>/dev/null || true
    fi

    # v28.0: ナレッジグラフにセッション完了を記録
    if type -t kg_auto_record &>/dev/null; then
        local _kg_outcome="success"
        [[ "$exit_code" -ne 0 ]] && _kg_outcome="failure"
        kg_auto_record "${DK_DETECTED_DOMAIN:-general}" "session_end" "$_kg_outcome" \
            "$task_desc" "${QG_SCORE:-0}" 2>/dev/null || true
    fi
}


# ============================================================
# クリーンアップ（lib/core/session.sh に委譲）
# ============================================================
_cleanup() {
    if type -t session_cleanup &>/dev/null; then
        session_cleanup
    else
        # フォールバック
        if [[ -n "${WATCHDOG_PID:-}" ]] && kill -0 "$WATCHDOG_PID" 2>/dev/null; then
            kill "$WATCHDOG_PID" 2>/dev/null || true
            wait "$WATCHDOG_PID" 2>/dev/null || true
        fi
        rm -f "$LOCK_FILE" 2>/dev/null || true
    fi
}


# ============================================================
# コマンド実装（lib/core/cli-parser.sh に委譲）
# フォールバック用: cli-parser.sh未ロード時のみ使用
# ============================================================
_cmd_rag_search() {
    if type -t _cli_cmd_rag_search &>/dev/null; then
        _cli_cmd_rag_search "$1"; return $?
    fi
    local query="$1"
    [[ -z "$query" ]] && { echo "Usage: ./chain.sh --rag-search \"検索クエリ\""; exit 1; }
    echo -e "${BOLD}${PURPLE}[RAG] ナレッジ検索${NC}"
    [[ -f "tools/rag-engine.py" ]] && python3 tools/rag-engine.py search "$query" || \
        echo -e "${RED}RAGエンジンが見つかりません。${NC}"
}


_cmd_rag_index() {
    if type -t _cli_cmd_rag_index &>/dev/null; then
        _cli_cmd_rag_index; return $?
    fi
    echo -e "${BOLD}${PURPLE}[RAG] インデックス再構築${NC}"
    [[ -f "tools/rag-engine.py" ]] && python3 tools/rag-engine.py index || \
        echo -e "${RED}RAGエンジンが見つかりません。${NC}"
}


_cmd_metrics() {
    if type -t _cli_cmd_metrics &>/dev/null; then
        _cli_cmd_metrics; return $?
    fi
    echo -e "${BOLD}${PURPLE}[METRICS] 学習メトリクス${NC}"
    type -t rt_print_metrics &>/dev/null && rt_print_metrics || \
        echo -e "${YELLOW}学習モジュールが見つかりません。${NC}"
    [[ -f "tools/rag-engine.py" ]] && { echo ""; python3 tools/rag-engine.py stats 2>/dev/null || true; }
}


# ============================================================
# ヘルプ（lib/core/cli-parser.sh に委譲）
# ============================================================
_show_help() {
    if type -t show_help &>/dev/null; then
        show_help
    else
        echo "SoloptiLink Chain v${VERSION}"
        echo "Usage: ./chain.sh \"タスク説明\" [--pipeline quick|deep|hotfix] [--parallel] [--deploy]"
        echo "       ./chain.sh --help  詳細ヘルプ"
    fi
}


# ---- ヘルパー: プロジェクトディレクトリ検出 ----
_detect_project_dir() {
    if [[ -n "${SCAFFOLD_OUTPUT_DIR:-}" && -d "$SCAFFOLD_OUTPUT_DIR" ]]; then
        echo "$SCAFFOLD_OUTPUT_DIR"
    else
        echo "."
    fi
}


# ============================================================
# セキュリティスキャン共通ヘルパー (v11.0 - 重複除去)
# _security_gate() と phase_security_audit() の共通ロジック
# ============================================================
_run_security_scans() {
    local project_dir="${1:-.}"

    # OWASPセキュリティガード実行
    _SEC_SG_REPORT=""
    _SEC_SG_ISSUES=0
    if type -t sg_run_all &>/dev/null; then
        echo -e "  ${BOLD}[OWASP] セキュリティスキャン実行中...${NC}"
        _SEC_SG_REPORT=$(sg_run_all "$project_dir" 2>/dev/null || echo "")
        if [[ -n "$_SEC_SG_REPORT" ]]; then
            _SEC_SG_ISSUES=$(echo "$_SEC_SG_REPORT" | grep -ciE '(CRITICAL|HIGH|critical|high)' 2>/dev/null || true)
            _SEC_SG_ISSUES="${_SEC_SG_ISSUES//[^0-9]/}"
            _SEC_SG_ISSUES="${_SEC_SG_ISSUES:-0}"
        fi
        echo -e "  ${BOLD}  OWASPスキャン結果: ${_SEC_SG_ISSUES}件のCritical/High問題${NC}"
    else
        echo -e "  ${YELLOW}⚠️ security-guard.sh 未ロード（OWASPスキャンスキップ）${NC}"
    fi

    # 依存関係セキュリティ監査実行
    _SEC_DEP_REPORT=""
    _SEC_DEP_ISSUES=0
    if type -t dep_audit_run_all &>/dev/null; then
        echo -e "  ${BOLD}[DEP] 依存関係セキュリティ監査実行中...${NC}"
        _SEC_DEP_REPORT=$(dep_audit_run_all "$project_dir" 2>/dev/null || echo "")
        if [[ -n "$_SEC_DEP_REPORT" ]]; then
            _SEC_DEP_ISSUES=$(echo "$_SEC_DEP_REPORT" | grep -ciE '(CRITICAL|HIGH|critical|high)' 2>/dev/null || true)
            _SEC_DEP_ISSUES="${_SEC_DEP_ISSUES//[^0-9]/}"
            _SEC_DEP_ISSUES="${_SEC_DEP_ISSUES:-0}"
        fi
        echo -e "  ${BOLD}  依存関係監査結果: ${_SEC_DEP_ISSUES}件のCritical/High脆弱性${NC}"
    else
        echo -e "  ${YELLOW}⚠️ dep-audit.sh 未ロード（依存関係監査スキップ）${NC}"
    fi

    _SEC_TOTAL_ISSUES=$((_SEC_SG_ISSUES + _SEC_DEP_ISSUES))
}


# セキュリティスコア計算ヘルパー
_calculate_security_score() {
    local total_issues="${1:-0}"
    if [[ "$total_issues" -eq 0 ]]; then   echo "100"
    elif [[ "$total_issues" -le 2 ]]; then  echo "80"
    elif [[ "$total_issues" -le 5 ]]; then  echo "60"
    elif [[ "$total_issues" -le 10 ]]; then echo "40"
    else echo "20"; fi
}


# セキュリティレポート生成ヘルパー
_generate_security_report() {
    local report_file="$1" title="$2" context="$3"
    cat > "$report_file" <<EOF
# ${title} (v${VERSION})
- セッション: ${SESSION_ID}
- 日時: $(date '+%Y-%m-%d %H:%M:%S')
${context}

## OWASPセキュリティスキャン
- Critical/High問題数: ${_SEC_SG_ISSUES}
${_SEC_SG_REPORT:-（スキャン未実行）}

## 依存関係セキュリティ監査
- Critical/High脆弱性数: ${_SEC_DEP_ISSUES}
${_SEC_DEP_REPORT:-（監査未実行）}

## 総合
- 合計問題数: ${_SEC_TOTAL_ISSUES}
- ステータス: $([ "${_SEC_TOTAL_ISSUES}" -eq 0 ] && echo "PASS" || echo "ISSUES FOUND")
EOF
    echo -e "  ${GREEN}📄 レポート: ${report_file}${NC}"
}


# セキュリティ自動修復ヘルパー
_auto_fix_security_issues() {
    local project_dir="${1:-.}"

    if [[ "${_SEC_TOTAL_ISSUES}" -eq 0 ]]; then
        echo -e "  ${GREEN}✅ セキュリティチェック通過: Critical/High問題なし${NC}"
        return 0
    fi

    echo -e "  ${RED}🚨 ${_SEC_TOTAL_ISSUES}件のセキュリティ問題を検出 → 自動修復開始${NC}"
    if type -t healer_init &>/dev/null; then
        healer_init "$SESSION_ID" "$project_dir" 2>/dev/null || true
        healer_run "$project_dir" "== OWASP ==
${_SEC_SG_REPORT}

== 依存関係 ==
${_SEC_DEP_REPORT}" 2>/dev/null || true
    else
        local fix_prompt="セキュリティエンジニアとして以下の問題を修正してください。

OWASPスキャン結果:
${_SEC_SG_REPORT:-問題なし}

依存関係脆弱性:
${_SEC_DEP_REPORT:-問題なし}

全てのCritical/High問題を修正し、全ファイルを実際に書き換えてください。"
        local fix_output="${SESSION_LOG_DIR:-/tmp}/security_fix_output.md"
        if _call_claude "$fix_prompt" "$fix_output" "security_fix"; then
            echo -e "  ${GREEN}✅ セキュリティ修復完了${NC}"
            _write_claude_output_to_files "$fix_output"
        else
            echo -e "  ${RED}❌ セキュリティ修復失敗（手動対応が必要）${NC}"
        fi
    fi
}


# ============================================================
# セキュリティゲート (v11.0) - 共通ヘルパー使用版
# ============================================================
_security_gate() {
    local project_dir="${1:-.}"
    echo -e "  ${CYAN}🛡️ セキュリティゲート実行中... (v11.0)${NC}"

    _run_security_scans "$project_dir"
    _auto_fix_security_issues "$project_dir"
    _generate_security_report "${SESSION_LOG_DIR}/security_report.md" "セキュリティレポート" "- プロジェクト: ${project_dir}"
    SECURITY_SCORE=$(_calculate_security_score "${_SEC_TOTAL_ISSUES}")

    return 0
}

# ============================================================
# _init_all_modules - chain.sh main() から抽出されたモジュール初期化ブロック
# グローバル変数を直接参照: SESSION_ID, TASK_DESC, DOMAIN_TYPE, etc.
# ============================================================
_init_all_modules() {
    # ============ v40.0: Living System 初期化 ============
    # Smart Retry (v36.0)
    if type -t sr_init &>/dev/null; then
        sr_init "$SESSION_ID" 2>/dev/null || true
    fi
    # Prompt Memory (v37.0)
    if type -t pm_init &>/dev/null; then
        pm_init "$SESSION_ID" 2>/dev/null || true
    fi
    # Phase Optimizer (v38.0)
    if type -t po_init &>/dev/null; then
        po_init "$TASK_DESC" 2>/dev/null || true
    fi
    # Output Analyzer (v39.0)
    if type -t oa_init &>/dev/null; then
        oa_init "$SESSION_ID" 2>/dev/null || true
    fi
    # Living System (v40.0)
    if type -t ls_init &>/dev/null; then
        ls_init "$SESSION_ID" 2>/dev/null || true
    fi

    # ============ v45.0: Unified Intelligence 初期化 ============
    # Dependency Sync (v41.0)
    if type -t ds_init &>/dev/null; then
        ds_init "$(pwd)" 2>/dev/null || true
    fi
    # Prompt Fusion (v42.0)
    if type -t pf_init &>/dev/null; then
        pf_init "$SESSION_ID" 2>/dev/null || true
    fi
    # Health Monitor (v43.0)
    if type -t hm_init &>/dev/null; then
        hm_init "$SESSION_ID" 2>/dev/null || true
    fi
    # Cross-Session Intelligence (v44.0)
    if type -t cs_init &>/dev/null; then
        cs_init "$SESSION_ID" 2>/dev/null || true
    fi
    # Unified Dashboard (v45.0)
    if type -t ud_init &>/dev/null; then
        ud_init "$SESSION_ID" 2>/dev/null || true
    fi

    # ============ v50.0: Grand Unification 初期化 ============
    # Scaffolder v2 (v46.0)
    if type -t sv2_init &>/dev/null; then
        sv2_init "${PO_PROJECT_TYPE:-nextjs}" "${PO_COMPLEXITY:-medium}" 2>/dev/null || true
    fi
    # Error Chain (v47.0)
    if type -t ec_init &>/dev/null; then
        ec_init "$SESSION_ID" 2>/dev/null || true
    fi
    # Agent Protocol v2 (v48.0)
    if type -t ap2_init &>/dev/null; then
        ap2_init "$SESSION_ID" 2>/dev/null || true
    fi
    # Self-Tuning (v49.0)
    if type -t st_init &>/dev/null; then
        st_init "${DOMAIN_TYPE:-general}" 2>/dev/null || true
    fi
    # Grand Unifier (v50.0)
    if type -t gu_init &>/dev/null; then
        gu_init "$SESSION_ID" 2>/dev/null || true
    fi

    # ============ v54.0: Dashboard Connector 初期化 ============
    if type -t dc_init &>/dev/null; then
        dc_init "${DASHBOARD_URL:-}" 2>/dev/null || true
        # セッション開始をダッシュボードに通知
        if type -t dc_session_start &>/dev/null && dc_is_connected 2>/dev/null; then
            dc_session_start \
                "$SESSION_ID" \
                "$TASK_DESC" \
                "${DOMAIN_TYPE:-general}" \
                "${PIPELINE_MODE:-full}" \
                "${MODEL_TIER:-auto}" \
                "${COST_LIMIT:-10.00}" 2>/dev/null || true
        fi
    fi

    # v12.0: FileWriter v2 初期化
    if type -t fw2_init &>/dev/null; then
        fw2_init "."
    fi

    # v14.0: Observatory 初期化 (trace_init → obs_init の順で trace_id を共有)
    if [[ "${ENABLE_TRACE:-false}" == "true" ]] && type -t trace_init &>/dev/null; then
        trace_init "$SESSION_ID"
    fi
    if type -t obs_init &>/dev/null; then
        obs_init "$SESSION_ID"
    fi
    if type -t cost_init &>/dev/null; then
        cost_init
    fi

    # v31.0: Cost Gate 初期化
    if type -t cg_init &>/dev/null; then
        CG_ENABLED="true"
        CG_AUTO_APPROVE="${CLI_AUTO_APPROVE:-false}"
        CG_ESTIMATE_ONLY="${CLI_COST_ESTIMATE_ONLY:-false}"
        [[ -n "${CLI_HARD_BUDGET:-}" ]] && CG_HARD_BUDGET="${CLI_HARD_BUDGET}"
        cg_init "$SESSION_ID" "${CG_HARD_BUDGET:-10.00}"

        # セッション全体のコスト見積もり
        cg_estimate_session "${PIPELINE_MODE:-full}" > /dev/null 2>&1
        cg_render_estimate

        # ユーザー承認
        if ! cg_request_approval; then
            echo -e "${YELLOW:-}  実行を中止しました${NC:-}"
            exit 0
        fi
    fi

    # v31.0: Enterprise Patterns 初期化
    if [[ "${CLI_ENABLE_ENTERPRISE_PATTERNS:-true}" == "true" ]] && type -t ep_init &>/dev/null; then
        ep_init "nextjs" "${DETECTED_DOMAIN:-}" "." 2>/dev/null || true
    fi

    # v31.0: Code Validator 初期化
    if [[ "${CLI_ENABLE_CODE_VALIDATOR:-true}" == "true" ]] && type -t cv2_init &>/dev/null; then
        cv2_init "." 2>/dev/null || true
    fi
    if [[ -n "${PERF_BASELINE_DIR:-}" ]] && type -t perf_baseline_init &>/dev/null; then
        perf_baseline_init "${PERF_BASELINE_DIR}"
    fi
    if [[ -n "${COVERAGE_THRESHOLD:-}" ]] && type -t covgate_init &>/dev/null; then
        covgate_init "$COVERAGE_THRESHOLD"
    fi
    if type -t fw3_init &>/dev/null; then
        fw3_init "."
    fi

    echo -e "${BOLD}タスク: ${CYAN}${TASK_DESC}${NC}"
    echo ""

    # ============ サブシステム初期化 ============

    # リアルタイム学習初期化
    if [[ "$NO_LEARN" != "1" ]] && type -t rt_learn_init &>/dev/null; then
        rt_learn_init "$SESSION_ID" 2>/dev/null || true
    fi

    # チェックポイント初期化
    if type -t checkpoint_init &>/dev/null; then
        checkpoint_init "$SESSION_ID" 2>/dev/null || true
    fi

    # v11.0: セキュリティモジュール初期化
    if [[ "${ENABLE_SECURITY}" == "true" ]]; then
        if type -t sg_init &>/dev/null; then
            sg_init 2>/dev/null || true
        fi
        if type -t dep_audit_init &>/dev/null; then
            dep_audit_init 2>/dev/null || true
        fi
    fi

    # v13.0: マルチエージェントオーケストレーター初期化
    if type -t ao_init &>/dev/null; then
        ao_init "$SESSION_ID" 2>/dev/null || true
        # 7専門エージェントを登録
        local agents_dir="${SCRIPT_DIR}/.claude/agents"
        if [[ -d "$agents_dir" ]]; then
            for agent_md in "$agents_dir"/*.md; do
                [[ ! -f "$agent_md" ]] && continue
                local agent_name
                agent_name=$(basename "$agent_md" .md)
                ao_register_agent "$agent_name" "$agent_md" "$agent_name" 2>/dev/null || true
            done
            echo -e "  ${GREEN}🤖 エージェント登録完了: $(ls "$agents_dir"/*.md 2>/dev/null | wc -l | tr -d ' ')名${NC}"
        fi
    fi

    # v15.0: セッション状態復元
    if [[ -n "${SESSION_RESTORE:-}" ]] && type -t ss_restore_state &>/dev/null; then
        ss_restore_state "$SESSION_RESTORE" 2>/dev/null || true
        echo -e "  ${CYAN}📋 セッション状態復元完了${NC}"
    fi

    # v15.0: Session State 初期化
    if type -t ss_init &>/dev/null; then
        ss_init "$SESSION_ID" 2>/dev/null || true
    fi

    # v15.0: プラグインシステム初期化
    if [[ "${ENABLE_PLUGINS:-true}" == "true" ]] && type -t pl_init &>/dev/null; then
        pl_init "${SCRIPT_DIR}/plugins" 2>/dev/null || true
    fi

    # v15.0: エージェントランタイム初期化
    if [[ "${ENABLE_AGENTS:-true}" == "true" ]] && type -t ar_init &>/dev/null; then
        ar_init "$SESSION_ID" 2>/dev/null || true
        echo -e "  ${GREEN}🧠 エージェントランタイム: ${BOLD}ACTIVE${NC}"
    fi

    # v15.0: 構造化出力モード
    if [[ "${ENABLE_STRUCTURED_OUTPUT:-false}" == "true" ]] && type -t so_init &>/dev/null; then
        so_init 2>/dev/null || true
    fi

    # v52.0: Structured Output v2 初期化（デフォルト有効）
    if [[ "${ENABLE_STRUCTURED_OUTPUT_V2:-true}" == "true" ]] && type -t so2_init &>/dev/null; then
        so2_init 2>/dev/null || true
    fi

    # v52.0: Micro-Task Engine 初期化
    if type -t mt_init &>/dev/null; then
        mt_init 2>/dev/null || true
    fi

    # v55.0: Prompt Evolution Engine 初期化
    if type -t pev_init &>/dev/null; then
        pev_init "$SESSION_ID" 2>/dev/null || true
    fi

    # v55.0: Parallel Execution v2 初期化
    if type -t pe2_init &>/dev/null; then
        pe2_init "$SESSION_ID" "${PE2_MAX_PARALLEL:-3}" 2>/dev/null || true
    fi

    # v15.0: ログローテーション初期化
    if type -t lr_init &>/dev/null; then
        lr_init "${SESSION_LOG_DIR}" 10 5 2>/dev/null || true
    fi

    # v16.0: コンテキスト予算管理初期化
    if type -t cb_init &>/dev/null; then
        local cb_budget="${CONTEXT_BUDGET:-200000}"
        cb_init "$SESSION_ID" "$cb_budget" 2>/dev/null || true
    fi

    # v16.0: メモリマネージャ初期化
    if type -t mm_init &>/dev/null; then
        mm_init "$SESSION_ID" "${MEMORY_MODE:-full}" 2>/dev/null || true
    fi

    # v16.0: モデルルーター初期化
    if type -t mr_init &>/dev/null; then
        mr_init "$SESSION_ID" "${MODEL_TIER:-auto}" 2>/dev/null || true
        echo -e "  ${GREEN}🧠 モデルルーター: ${BOLD}${MODEL_TIER:-auto}${NC}"
    fi

    # v16.0: Planner-Judge初期化
    if [[ "${ENABLE_PLANNER_JUDGE:-true}" == "true" ]] && type -t pj_init &>/dev/null; then
        pj_init "$SESSION_ID" "${CONFIDENCE_THRESHOLD:-0.7}" 2>/dev/null || true
        echo -e "  ${GREEN}⚖️  Planner-Judge: ${BOLD}ACTIVE${NC} (閾値=${CONFIDENCE_THRESHOLD:-0.7})"
    fi

    # v17.0: データ整合性エンジン初期化
    if [[ "${ENABLE_DATA_INTEGRITY:-true}" == "true" ]] && type -t di_init &>/dev/null; then
        di_init "$SESSION_ID" 2>/dev/null || true
        echo -e "  ${GREEN}🔒 データ整合性エンジン: ${BOLD}ACTIVE${NC}"
    fi

    # v17.0: 監査ログエンジン初期化
    if [[ "${ENABLE_AUDIT_LOG:-true}" == "true" ]] && type -t al_init &>/dev/null; then
        al_init "$SESSION_ID" 2>/dev/null || true
        echo -e "  ${GREEN}📋 監査ログエンジン: ${BOLD}ACTIVE${NC}"
    fi

    # v17.0: E2Eパイプライン初期化
    if type -t e2e_init &>/dev/null; then
        e2e_init "$SESSION_ID" 2>/dev/null || true
    fi

    # v17.0: エージェントスケーラー初期化
    if type -t as_init &>/dev/null; then
        as_init "$SESSION_ID" 2>/dev/null || true
        echo -e "  ${GREEN}📈 エージェントスケーラー: ${BOLD}ACTIVE${NC} ($(as_list_agents 2>/dev/null | wc -l | tr -d ' ')エージェント)"
    fi

    # v18.0: Data Intelligence Engine init
    if [[ "${ENABLE_DATA_IMPORT:-auto}" != "false" ]] && type -t din_init &>/dev/null; then
        echo -e "  ${GREEN}📊 データインテリジェンス: ${BOLD}READY${NC}"
    fi

    # v18.0: SaaS Builder init
    if [[ "${ENABLE_SAAS:-auto}" != "false" ]] && type -t sb_init &>/dev/null; then
        echo -e "  ${GREEN}🏢 SaaSビルダー: ${BOLD}READY${NC}"
    fi

    # v18.0: AI Integration Layer init
    if [[ "${ENABLE_AI:-auto}" != "false" ]] && type -t ai_init &>/dev/null; then
        echo -e "  ${GREEN}🤖 AI統合レイヤー: ${BOLD}READY${NC}"
    fi

    # v15.0: pre_session フック発火
    if type -t pl_fire_hook &>/dev/null; then
        pl_fire_hook "pre_session" "$SESSION_ID" 2>/dev/null || true
    fi

    # タイムアウト監視（lib/core/session.sh に委譲）
    if type -t session_start_watchdog &>/dev/null; then
        session_start_watchdog
        WATCHDOG_PID="${SESSION_WATCHDOG_PID:-}"
    else
        _start_timeout_watchdog
    fi

}

# ============================================================
# _save_session_data - chain.sh main() から抽出されたセッション学習データ永続化ブロック
# グローバル変数を直接参照: SESSION_ID, DOMAIN_TYPE, QG_SCORE, dag_exit, etc.
# ============================================================
_save_session_data() {
    # ============ v40.0: Living System セッション学習データ永続化 ============
    # Smart Retry 統計保存 (v36.0)
    if type -t sr_save_history &>/dev/null; then
        _warn_on_fail "SmartRetry" "save_history" sr_save_history || true
    fi
    # Prompt Memory 保存 (v37.0)
    if type -t pm_save &>/dev/null; then
        _warn_on_fail "PromptMemory" "save" pm_save || true
    fi
    # Output Analyzer 履歴保存 (v39.0)
    if type -t oa_save_history &>/dev/null; then
        _warn_on_fail "OutputAnalyzer" "save_history" oa_save_history || true
    fi
    # Living System セッション保存 (v40.0)
    if type -t ls_save_session &>/dev/null; then
        _warn_on_fail "LivingSystem" "save_session" ls_save_session "${DOMAIN_TYPE:-general}" "${QG_SCORE:-0}" "${COST_TOTAL:-0}" "${PO_PHASES_EXECUTED:-0}" "${PO_PHASES_SKIPPED:-0}" || true
    fi

    # v55.0: Prompt Evolution - セッション品質データを学習
    if type -t pev_analyze_output_quality &>/dev/null && [[ "${PEV_ENABLED:-false}" == "true" ]]; then
        local _pev_features=""
        [[ "${SO2_ENABLED:-false}" == "true" ]] && _pev_features="json_format"
        [[ "${MT_ENABLED:-false}" == "true" ]] && _pev_features="${_pev_features:+${_pev_features},}micro_task"
        [[ "${ENABLE_ENTERPRISE_PATTERNS:-true}" == "true" ]] && _pev_features="${_pev_features:+${_pev_features},}enterprise_patterns"
        pev_analyze_output_quality "${QG_SCORE:-0}" "session" "$_pev_features" "${DOMAIN_TYPE:-general}" 2>/dev/null || true
        if type -t pev_report &>/dev/null; then
            pev_report 2>/dev/null || true
        fi
    fi

    # ============ v45.0: Unified Intelligence セッション学習データ永続化 ============
    # Dependency Sync 履歴保存 (v41.0)
    if type -t ds_save_history &>/dev/null; then
        ds_save_history 2>/dev/null || true
    fi
    # Prompt Fusion 履歴保存 (v42.0)
    if type -t pf_save_history &>/dev/null; then
        pf_save_history 2>/dev/null || true
    fi
    # Health Monitor 履歴保存 (v43.0)
    if type -t hm_save_history &>/dev/null; then
        hm_save_history 2>/dev/null || true
    fi
    # Cross-Session 分析結果保存 (v44.0)
    if type -t cs_save &>/dev/null; then
        cs_save 2>/dev/null || true
    fi
    # Unified Dashboard レポート保存 (v45.0)
    if type -t ud_save_report &>/dev/null; then
        ud_save_report 2>/dev/null || true
    fi
    # Unified Dashboard サマリー表示 (v45.0)
    if type -t ud_render_summary &>/dev/null; then
        ud_render_summary 2>/dev/null || true
    fi

    # ============ v50.0: Grand Unification セッション学習データ永続化 ============
    # Scaffolder v2 履歴保存 (v46.0)
    if type -t sv2_save_history &>/dev/null; then
        sv2_save_history 2>/dev/null || true
    fi
    # Error Chain 履歴保存 (v47.0)
    if type -t ec_save_history &>/dev/null; then
        _warn_on_fail "ErrorChain" "save_history" ec_save_history || true
    fi
    # v52.0: Error Chain→Cross-Session統合 - エラーパターンをセッション横断DBに蓄積
    if type -t ec_get_stats &>/dev/null; then
        local _ec_stats
        _ec_stats=$(ec_get_stats 2>/dev/null || echo "")
        if [[ -n "$_ec_stats" && "$_ec_stats" != *"total=0"* ]]; then
            local _ec_cs_file="${HOME}/.soloptilink/knowledge/error_chain_cross_session.jsonl"
            mkdir -p "$(dirname "$_ec_cs_file")" 2>/dev/null || true
            echo "{\"session\":\"${SESSION_ID:-unknown}\",\"timestamp\":$(date +%s),\"stats\":\"${_ec_stats}\",\"domain\":\"${DOMAIN_TYPE:-general}\"}" >> "$_ec_cs_file" 2>/dev/null || true
        fi
    fi
    # Agent Protocol v2 履歴保存 (v48.0)
    if type -t ap2_save_history &>/dev/null; then
        ap2_save_history 2>/dev/null || true
    fi
    # Self-Tuning 設定保存 (v49.0)
    if type -t st_save &>/dev/null; then
        st_save 2>/dev/null || true
    fi
    # Grand Unifier セッションサマリー + 保存 (v50.0)
    if type -t gu_get_session_summary &>/dev/null; then
        gu_get_session_summary 2>/dev/null || true
    fi
    if type -t gu_save &>/dev/null; then
        gu_save 2>/dev/null || true
    fi

    # ============ v52.0: Phase C-12: ユーザーフィードバックループ ============
    # セッション結果を記録し、修正戦略の最適化データとして蓄積
    local _fb_file="${HOME}/.soloptilink/knowledge/session_feedback.jsonl"
    mkdir -p "$(dirname "$_fb_file")" 2>/dev/null || true
    local _fb_result="unknown"
    if [[ "$dag_exit" -eq 0 ]]; then
        _fb_result="success"
    else
        _fb_result="failure"
    fi
    local _fb_healing_count="${_FH_HEALED_COUNT:-0}"
    local _fb_error_count="${EC_TOTAL_ERRORS:-0}"
    local _fb_retry_count="${SR_TOTAL_RETRIES:-0}"
    local _fb_dfe_used="false"
    [[ -n "${DFE_REQUEST:-}" ]] && _fb_dfe_used="true"
    local _fb_followup="${FUC_IS_FOLLOWUP:-false}"
    local _fb_request_type="${FUC_REQUEST_TYPE:-new_build}"
    local _fb_genome_drift="${GENOME_DRIFT_DETECTED:-false}"

    echo "{\"session\":\"${SESSION_ID:-unknown}\",\"timestamp\":$(date +%s),\"result\":\"${_fb_result}\",\"domain\":\"${DOMAIN_TYPE:-general}\",\"quality_score\":${QG_SCORE:-0},\"healing_count\":${_fb_healing_count},\"error_count\":${_fb_error_count},\"retry_count\":${_fb_retry_count},\"dfe_used\":${_fb_dfe_used},\"followup\":${_fb_followup},\"request_type\":\"${_fb_request_type}\",\"genome_drift\":${_fb_genome_drift}}" >> "$_fb_file" 2>/dev/null || true

    # フィードバック学習: 過去5セッションの成功率→Self-Tuning連携で自動調整
    if [[ -f "$_fb_file" ]]; then
        local _fb_recent_total _fb_recent_success _fb_success_rate
        _fb_recent_total=$(tail -5 "$_fb_file" 2>/dev/null | wc -l | tr -d '[:space:]')
        _fb_recent_success=$(tail -5 "$_fb_file" 2>/dev/null | grep -c '"result":"success"' || echo "0")
        if [[ "${_fb_recent_total:-0}" -gt 0 ]]; then
            _fb_success_rate=$(( (_fb_recent_success * 100) / _fb_recent_total ))

            # v52.0: Self-Tuning連携 - 成功率に基づく自動パラメータ調整
            if type -t st_tune_quality &>/dev/null; then
                local _fb_avg_heals
                _fb_avg_heals=$(tail -5 "$_fb_file" 2>/dev/null | grep -o '"healing_count":[0-9]*' | grep -o '[0-9]*' | awk '{s+=$1}END{print int(s/NR)}' 2>/dev/null || echo "0")
                st_tune_quality "${QG_SCORE:-80}" "${_fb_avg_heals}" 2>/dev/null || true
            fi
            if type -t st_tune_retries &>/dev/null; then
                st_tune_retries "${_fb_success_rate}" 2>/dev/null || true
            fi
            if type -t st_tune_timeout &>/dev/null; then
                local _fb_timeout_rate
                _fb_timeout_rate=$(tail -5 "$_fb_file" 2>/dev/null | grep -c '"retry_count":[1-9]' || echo "0")
                st_tune_timeout "${_fb_timeout_rate}" 2>/dev/null || true
            fi

            if [[ $_fb_success_rate -lt 60 ]]; then
                echo -e "  ${YELLOW}📊 セッション成功率: ${_fb_success_rate}% (直近${_fb_recent_total}件) - Self-Tuningで自動調整済${NC}"
            elif [[ $_fb_success_rate -lt 80 ]]; then
                echo -e "  ${CYAN}📊 セッション成功率: ${_fb_success_rate}% (直近${_fb_recent_total}件)${NC}"
            fi
        fi
    fi

}

# ============================================================
# _write_telemetry_file - ランチャー向けテレメトリJSON出力
# chain.sh実行結果をJSONファイルに書き出し、ランチャーがサーバーに送信する
# ============================================================
_write_telemetry_file() {
    local _exit_code="${1:-0}"
    local _tel_file="${SOLOPTILINK_TELEMETRY_FILE}"
    [[ -z "$_tel_file" ]] && return 0

    local _status="completed"
    [[ "$_exit_code" -ne 0 ]] && _status="failed"

    # フェーズ実行詳細の収集
    local _phases_json="{}"
    if [[ -n "${PO_PHASES_EXECUTED:-}" || -n "${PO_PHASES_SKIPPED:-}" ]]; then
        _phases_json="{\"executed\":${PO_PHASES_EXECUTED:-0},\"skipped\":${PO_PHASES_SKIPPED:-0}}"
    fi

    # コストデータの収集
    local _cost_json="{}"
    if [[ -n "${COST_CALLS_TOTAL:-}" || -n "${COST_USD_TOTAL:-}" ]]; then
        _cost_json="{\"claude_calls\":${COST_CALLS_TOTAL:-0},\"estimated_cost\":\"${COST_USD_TOTAL:-0.00}\",\"model_tier\":\"${MODEL_TIER:-auto}\"}"
    fi

    # 品質スコアの収集
    local _quality_json="{}"
    local _qg="${QG_SCORE:-0}"
    local _sec="${SEC_SCORE:-0}"
    local _di="${DI_SCORE:-0}"
    local _pp="${PP_SCORE:-0}"
    local _acv="${ACV_SCORE:-0}"
    local _dr="${DR_SCORE:-0}"
    local _gov="${GOV_SCORE:-0}"
    _quality_json="{\"quality_gate\":${_qg},\"security\":${_sec},\"data_integrity\":${_di},\"performance\":${_pp},\"api_contract\":${_acv},\"dependency\":${_dr},\"governance\":${_gov}}"

    # エラーサマリーの収集
    local _error_summary=""
    if [[ "${EC_TOTAL_ERRORS:-0}" -gt 0 ]]; then
        _error_summary="errors=${EC_TOTAL_ERRORS:-0},heals=${_FH_HEALED_COUNT:-0},retries=${SR_TOTAL_RETRIES:-0}"
    fi

    # フォローアップ/リクエストタイプ情報
    local _request_type="${FUC_REQUEST_TYPE:-new_build}"
    local _is_followup="${FUC_IS_FOLLOWUP:-false}"

    # ドメイン情報
    local _domain="${DOMAIN_TYPE:-general}"

    # 使用されたCLIフラグの収集
    local _cli_flags=""
    [[ "${ENABLE_PARALLEL:-false}" == "true" ]] && _cli_flags="parallel"
    [[ "${ENABLE_BROWSER_TEST:-false}" == "true" ]] && _cli_flags="${_cli_flags:+${_cli_flags},}browser-test"
    [[ "${ENABLE_DEPLOY:-false}" == "true" ]] && _cli_flags="${_cli_flags:+${_cli_flags},}deploy"
    [[ "${ENABLE_SWARM:-true}" == "true" ]] && _cli_flags="${_cli_flags:+${_cli_flags},}swarm"
    [[ "${ENABLE_GOVERNANCE:-true}" == "true" ]] && _cli_flags="${_cli_flags:+${_cli_flags},}governance"
    [[ "${ENABLE_SAAS:-false}" == "true" ]] && _cli_flags="${_cli_flags:+${_cli_flags},}saas"
    [[ "${ENABLE_AI_INTEGRATION:-false}" == "true" ]] && _cli_flags="${_cli_flags:+${_cli_flags},}ai-integration"

    # セッション学習インサイト（AIをより賢くするための高感度データ）
    local _insights_json="{}"
    local _healing_count="${_FH_HEALED_COUNT:-0}"
    local _dfe_used="false"
    [[ -n "${DFE_REQUEST:-}" ]] && _dfe_used="true"
    local _genome_drift="${GENOME_DRIFT_DETECTED:-false}"
    local _voting_consensus="${VE_CONSENSUS_REACHED:-false}"
    local _code_validator_rejects="${CV_REJECT_COUNT:-0}"
    local _enterprise_patterns_injected="${EP_INJECT_COUNT:-0}"
    _insights_json="{\"healing_count\":${_healing_count},\"dfe_used\":${_dfe_used},\"genome_drift\":${_genome_drift},\"voting_consensus\":${_voting_consensus},\"code_validator_rejects\":${_code_validator_rejects},\"enterprise_patterns_injected\":${_enterprise_patterns_injected},\"request_type\":\"${_request_type}\",\"is_followup\":${_is_followup},\"domain\":\"${_domain}\"}"

    # JSON出力
    cat > "$_tel_file" <<TELEOF
{
  "session_id": "${SOLOPTILINK_SESSION_ID:-}",
  "status": "${_status}",
  "version": "${VERSION}",
  "model_tier": "${MODEL_TIER:-auto}",
  "phases_completed": ${PO_PHASES_EXECUTED:-0},
  "duration_seconds": ${SECONDS:-0},
  "task_type": "${DOMAIN_TYPE:-general}",
  "cli_flags": "${_cli_flags}",
  "phases_detail": ${_phases_json},
  "cost_data": ${_cost_json},
  "quality_scores": ${_quality_json},
  "error_summary": "${_error_summary}",
  "insights": ${_insights_json}
}
TELEOF
}
