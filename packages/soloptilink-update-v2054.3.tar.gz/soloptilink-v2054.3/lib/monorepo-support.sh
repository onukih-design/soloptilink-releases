#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v428.0 - Monorepo Support
# =============================================================================
# モノレポ構成の自動検出・分析・最適化。Turborepo/Nx/Lerna/pnpm workspaces
# の検出、パッケージ間依存解析、最適なビルド設定の生成を行う。
#
# Functions:
#   _ms_init()                - 初期化
#   _ms_detect_monorepo()     - モノレポ構成検出
#   _ms_analyze_packages()    - パッケージ間依存分析
#   _ms_generate_config()     - 最適設定生成
#   _ms_report() / _ms_score()
#
# All globals use the MS_ prefix.
# =============================================================================

[[ -n "${_MS_LOADED:-}" ]] && return 0; _MS_LOADED=1

declare -g MS_VERSION="428.0"
declare -g MS_GENERATED=0
declare -g MS_ERRORS=0
declare -g MS_TOOL=""
declare -g MS_PACKAGE_COUNT=0
declare -g MS_SHARED_DEPS=0
declare -g MS_IS_MONOREPO=false
declare -g MS_CONFIG_GENERATED=false

declare -ga _MS_PACKAGES=()
declare -gA _MS_PACKAGE_DEPS=()
declare -gA _MS_PACKAGE_SCRIPTS=()

_MS_GREEN="${GREEN:-\033[0;32m}"
_MS_RED="${RED:-\033[0;31m}"
_MS_YELLOW="${YELLOW:-\033[0;33m}"
_MS_CYAN="${CYAN:-\033[0;36m}"
_MS_BOLD="${BOLD:-\033[1m}"
_MS_NC="${NC:-\033[0m}"

_ms_init() {
    MS_GENERATED=0; MS_ERRORS=0; MS_TOOL=""; MS_PACKAGE_COUNT=0
    MS_SHARED_DEPS=0; MS_IS_MONOREPO=false; MS_CONFIG_GENERATED=false
    _MS_PACKAGES=(); _MS_PACKAGE_DEPS=(); _MS_PACKAGE_SCRIPTS=()
    return 0
}

_ms_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_MS_CYAN}[MS]${_MS_NC} $*" >&2 ;;
        ok)    echo -e "  ${_MS_GREEN}[MS]${_MS_NC} $*" >&2 ;;
        warn)  echo -e "  ${_MS_YELLOW}[MS]${_MS_NC} $*" >&2 ;;
        error) echo -e "  ${_MS_RED}[MS]${_MS_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _ms_detect_monorepo - モノレポ構成検出
# =============================================================================
_ms_detect_monorepo() {
    local project_dir="${1:-.}"

    _ms_log info "モノレポ検出: ${project_dir}"

    MS_IS_MONOREPO=false
    MS_TOOL=""

    # Turborepo 検出
    if [[ -f "${project_dir}/turbo.json" ]]; then
        MS_TOOL="turborepo"
        MS_IS_MONOREPO=true
        _ms_log ok "Turborepo検出"
    fi

    # Nx 検出
    if [[ -f "${project_dir}/nx.json" ]]; then
        MS_TOOL="nx"
        MS_IS_MONOREPO=true
        _ms_log ok "Nx検出"
    fi

    # Lerna 検出
    if [[ -f "${project_dir}/lerna.json" ]]; then
        MS_TOOL="${MS_TOOL:+${MS_TOOL}+}lerna"
        MS_IS_MONOREPO=true
        _ms_log ok "Lerna検出"
    fi

    # pnpm workspace 検出
    if [[ -f "${project_dir}/pnpm-workspace.yaml" ]]; then
        MS_TOOL="${MS_TOOL:+${MS_TOOL}+}pnpm-workspaces"
        MS_IS_MONOREPO=true
        _ms_log ok "pnpm workspaces検出"
    fi

    # package.json workspaces 検出
    if [[ -f "${project_dir}/package.json" ]]; then
        local has_workspaces
        has_workspaces=$(grep -c '"workspaces"' "${project_dir}/package.json" 2>/dev/null || echo 0)
        if [[ $has_workspaces -gt 0 ]]; then
            MS_TOOL="${MS_TOOL:-npm-workspaces}"
            MS_IS_MONOREPO=true
            _ms_log ok "npm/yarn workspaces検出"
        fi
    fi

    # パッケージディレクトリの検出
    _MS_PACKAGES=()
    local pkg_dirs=("packages" "apps" "libs" "services" "modules")
    for dir in "${pkg_dirs[@]}"; do
        if [[ -d "${project_dir}/${dir}" ]]; then
            while IFS= read -r -d '' pkg; do
                local pkg_name
                pkg_name=$(basename "$pkg")
                if [[ -f "${pkg}/package.json" ]]; then
                    _MS_PACKAGES+=("${dir}/${pkg_name}")
                    MS_PACKAGE_COUNT=$((MS_PACKAGE_COUNT + 1))
                fi
            done < <(find "${project_dir}/${dir}" -maxdepth 1 -mindepth 1 -type d -print0 2>/dev/null)
        fi
    done

    if [[ "$MS_IS_MONOREPO" != "true" ]] && [[ $MS_PACKAGE_COUNT -gt 1 ]]; then
        MS_IS_MONOREPO=true
        MS_TOOL="implicit"
    fi

    MS_GENERATED=$((MS_GENERATED + 1))
    _ms_log ok "検出完了: monorepo=${MS_IS_MONOREPO}, tool=${MS_TOOL}, packages=${MS_PACKAGE_COUNT}"

    echo "${MS_TOOL}"
    return 0
}

# =============================================================================
# _ms_analyze_packages - パッケージ間依存分析
# =============================================================================
_ms_analyze_packages() {
    local project_dir="${1:-.}"

    _ms_log info "パッケージ間依存分析"

    _MS_PACKAGE_DEPS=()
    _MS_PACKAGE_SCRIPTS=()
    MS_SHARED_DEPS=0

    local -A all_deps=()

    for pkg in "${_MS_PACKAGES[@]}"; do
        local pkg_json="${project_dir}/${pkg}/package.json"
        [[ ! -f "$pkg_json" ]] && continue

        # 依存関係を読み取り
        local deps=""
        while IFS= read -r line; do
            if [[ "$line" =~ \"(@[^\"]+|[a-z][^\"]+)\" ]]; then
                local dep="${BASH_REMATCH[1]}"
                deps="${deps}${deps:+,}${dep}"
                all_deps["$dep"]=$(( ${all_deps["$dep"]:-0} + 1 ))
            fi
        done < <(sed -n '/"dependencies"/,/}/p' "$pkg_json" 2>/dev/null)

        _MS_PACKAGE_DEPS["$pkg"]="$deps"

        # スクリプト一覧
        local scripts=""
        while IFS= read -r line; do
            if [[ "$line" =~ \"([a-z][^\"]+)\":\ \" ]]; then
                scripts="${scripts}${scripts:+,}${BASH_REMATCH[1]}"
            fi
        done < <(sed -n '/"scripts"/,/}/p' "$pkg_json" 2>/dev/null)
        _MS_PACKAGE_SCRIPTS["$pkg"]="$scripts"
    done

    # 共有依存カウント
    for dep in "${!all_deps[@]}"; do
        if [[ ${all_deps["$dep"]} -gt 1 ]]; then
            MS_SHARED_DEPS=$((MS_SHARED_DEPS + 1))
        fi
    done

    MS_GENERATED=$((MS_GENERATED + 1))
    _ms_log ok "依存分析完了: 共有依存${MS_SHARED_DEPS}個"

    return 0
}

# =============================================================================
# _ms_generate_config - 最適設定生成
# =============================================================================
_ms_generate_config() {
    local project_dir="${1:-.}"
    local output_dir="${2:-${project_dir}}"

    _ms_log info "最適設定生成: ${MS_TOOL}"

    case "$MS_TOOL" in
        turborepo*)
            cat > "${output_dir}/turbo.json.recommended" <<'TURBO'
{
  "$schema": "https://turbo.build/schema.json",
  "globalDependencies": ["**/.env.*local"],
  "pipeline": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": [".next/**", "!.next/cache/**", "dist/**"]
    },
    "lint": {},
    "test": {
      "dependsOn": ["build"]
    },
    "dev": {
      "cache": false,
      "persistent": true
    }
  }
}
TURBO
            _ms_log ok "turbo.json.recommended 生成"
            ;;
        nx*)
            cat > "${output_dir}/nx.json.recommended" <<'NX'
{
  "targetDefaults": {
    "build": {
      "dependsOn": ["^build"],
      "cache": true
    },
    "lint": {
      "cache": true
    },
    "test": {
      "cache": true
    }
  },
  "defaultBase": "main",
  "namedInputs": {
    "default": ["{projectRoot}/**/*", "sharedGlobals"],
    "sharedGlobals": ["{workspaceRoot}/.github/workflows/*"]
  }
}
NX
            _ms_log ok "nx.json.recommended 生成"
            ;;
        *)
            # 汎用 workspace 設定
            cat > "${output_dir}/.workspace-config.recommended.json" <<'WS'
{
  "packages": ["packages/*", "apps/*"],
  "hoisting": true,
  "sharedDependencies": true,
  "buildOrder": "topological"
}
WS
            _ms_log ok ".workspace-config.recommended.json 生成"
            ;;
    esac

    MS_CONFIG_GENERATED=true
    MS_GENERATED=$((MS_GENERATED + 1))
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_ms_report() {
    echo -e "\n  ${_MS_BOLD}=== monorepo-support v${MS_VERSION} ===${_MS_NC}"
    echo -e "  モノレポ        : ${MS_IS_MONOREPO}"
    echo -e "  ツール          : ${MS_TOOL:-none}"
    echo -e "  パッケージ数    : ${MS_PACKAGE_COUNT}"
    echo -e "  共有依存        : ${MS_SHARED_DEPS}"
    echo -e "  設定生成        : ${MS_CONFIG_GENERATED}"
    echo -e "  エラー          : ${MS_ERRORS}"
}

_ms_score() {
    local score=50
    [[ "$MS_IS_MONOREPO" == "true" ]] && score=$((score + 10))
    [[ ${MS_PACKAGE_COUNT} -gt 0 ]] && score=$((score + 15))
    [[ "$MS_CONFIG_GENERATED" == "true" ]] && score=$((score + 15))
    [[ ${MS_ERRORS} -eq 0 ]] && score=$((score + 10))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "monorepo-support" --version "${MS_VERSION}" \
        --description "モノレポ検出×パッケージ依存分析×Turborepo/Nx/Lerna対応 (v428)" \
        --init "_ms_init" --report "_ms_report" --score "_ms_score" \
        --enable-var "ENABLE_MONOREPO" --cli-flags "--monorepo:--no-monorepo"
fi

# v2003.1: source時のexit codeを確実に0にする
true
