#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v16.0 - Memory Manager
# =============================================================================
# 3-tier memory architecture for cross-session intelligence:
#   Tier 1 (Short-term): Current session context, phase outputs, live state
#   Tier 2 (Long-term):  Persistent cross-session memory (~/.soloptilink/memory/)
#   Tier 3 (Episodic):   Success/failure patterns, learned heuristics
#
# Features:
#   1. Short-term memory (session-scoped, fast key-value store)
#   2. Long-term memory (file-based, persists across sessions)
#   3. Episodic memory (pattern-based learning from outcomes)
#   4. Memory search (keyword + fuzzy matching)
#   5. Memory decay (old entries get lower relevance)
#   6. Memory export/import (JSON format)
#
# Functions:
#   mm_init              - Initialize memory manager
#   mm_store             - Store to specified tier
#   mm_recall            - Recall from specified tier (or auto-search all)
#   mm_store_short       - Store short-term memory
#   mm_recall_short      - Recall short-term memory
#   mm_store_long        - Persist long-term memory
#   mm_recall_long       - Recall long-term memory
#   mm_record_episode    - Record success/failure episode
#   mm_recall_episodes   - Recall relevant episodes
#   mm_search            - Search across all memory tiers
#   mm_build_context     - Build memory-enhanced context for a phase
#   mm_decay             - Apply time-based decay to episodic memory
#   mm_report            - Print memory usage report
#   mm_export_json       - Export memory state as JSON
#
# All globals use the MM_ prefix.
# =============================================================================

[[ -n "${_MEMORY_MANAGER_LOADED:-}" ]] && return 0
_MEMORY_MANAGER_LOADED=1

# ============================================================
# State
# ============================================================
declare -g MM_ENABLED="false"
declare -g MM_SESSION_ID=""
declare -g MM_MODE="full"           # full | session | off
declare -g MM_BASE_DIR=""           # ~/.soloptilink/memory/
declare -g MM_LONG_TERM_DIR=""      # long-term storage
declare -g MM_EPISODIC_DIR=""       # episodic storage
declare -g MM_SHORT_TERM_COUNT=0
declare -g MM_LONG_TERM_COUNT=0
declare -g MM_EPISODIC_COUNT=0

# Short-term memory (session-scoped associative array)
declare -g -A MM_SHORT_TERM=()

# ============================================================
# Internal logger
# ============================================================
_mm_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[MEMORY]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize memory manager
# ============================================================
mm_init() {
    local session_id="${1:-${SESSION_ID:-unknown}}"
    local mode="${2:-${MM_MODE}}"

    MM_SESSION_ID="$session_id"
    MM_MODE="$mode"
    MM_SHORT_TERM=()
    MM_SHORT_TERM_COUNT=0
    MM_LONG_TERM_COUNT=0
    MM_EPISODIC_COUNT=0

    if [[ "$mode" == "off" ]]; then
        MM_ENABLED="false"
        _mm_log "INFO" "メモリマネージャ無効"
        return 0
    fi

    MM_ENABLED="true"

    # Setup persistent storage directories
    MM_BASE_DIR="${HOME}/.soloptilink/memory"
    MM_LONG_TERM_DIR="${MM_BASE_DIR}/long-term"
    MM_EPISODIC_DIR="${MM_BASE_DIR}/episodic"

    mkdir -p "$MM_LONG_TERM_DIR" 2>/dev/null || true
    mkdir -p "$MM_EPISODIC_DIR" 2>/dev/null || true

    # Count existing long-term entries
    if [[ -d "$MM_LONG_TERM_DIR" ]]; then
        MM_LONG_TERM_COUNT=$(find "$MM_LONG_TERM_DIR" -name "*.json" 2>/dev/null | wc -l | tr -d ' ')
    fi

    # Count existing episodic entries
    if [[ -d "$MM_EPISODIC_DIR" ]]; then
        MM_EPISODIC_COUNT=$(find "$MM_EPISODIC_DIR" -name "*.json" 2>/dev/null | wc -l | tr -d ' ')
    fi

    _mm_log "SUCCESS" "メモリマネージャ v16.0 初期化: mode=${mode}, 長期=${MM_LONG_TERM_COUNT}件, エピソード=${MM_EPISODIC_COUNT}件"
    return 0
}

# ============================================================
# Short-term memory (session-scoped, fast)
# ============================================================
mm_store_short() {
    local key="${1:?mm_store_short: key required}"
    local value="${2:?mm_store_short: value required}"

    MM_SHORT_TERM["$key"]="$value"
    MM_SHORT_TERM_COUNT=${#MM_SHORT_TERM[@]}
}

mm_recall_short() {
    local key="${1:?mm_recall_short: key required}"
    echo "${MM_SHORT_TERM[$key]:-}"
}

# ============================================================
# Long-term memory (file-based, cross-session)
# ============================================================
mm_store_long() {
    local category="${1:?mm_store_long: category required}"
    local key="${2:?mm_store_long: key required}"
    local value="${3:?mm_store_long: value required}"
    local tags="${4:-}"

    [[ "$MM_MODE" == "session" ]] && return 0

    local category_dir="${MM_LONG_TERM_DIR}/${category}"
    mkdir -p "$category_dir" 2>/dev/null || true

    # Sanitize key for filename
    local safe_key
    safe_key=$(echo "$key" | tr -cs 'a-zA-Z0-9_-' '_' | head -c 100)

    local entry_file="${category_dir}/${safe_key}.json"

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os
entry = {
    'key': sys.argv[1],
    'category': sys.argv[2],
    'value': sys.argv[3],
    'tags': sys.argv[4].split(',') if sys.argv[4] else [],
    'created_at': sys.argv[5],
    'access_count': 0,
    'last_accessed': sys.argv[5]
}

# Merge with existing if present
filepath = sys.argv[6]
if os.path.isfile(filepath):
    try:
        with open(filepath, 'r') as f:
            old = json.load(f)
        entry['access_count'] = old.get('access_count', 0)
        entry['created_at'] = old.get('created_at', entry['created_at'])
    except: pass

with open(filepath, 'w') as f:
    json.dump(entry, f, ensure_ascii=False, indent=2)
" "$key" "$category" "$value" "$tags" "$(date '+%Y-%m-%dT%H:%M:%S')" "$entry_file" 2>/dev/null
    else
        # Fallback: simple JSON write
        cat > "$entry_file" <<JSONEOF
{
  "key": "$key",
  "category": "$category",
  "value": $(echo "$value" | python3 -c "import json,sys; print(json.dumps(sys.stdin.read()))" 2>/dev/null || echo "\"${value//\"/\\\"}\""),
  "tags": [],
  "created_at": "$(date '+%Y-%m-%dT%H:%M:%S')",
  "access_count": 0
}
JSONEOF
    fi

    MM_LONG_TERM_COUNT=$((MM_LONG_TERM_COUNT + 1))
}

mm_recall_long() {
    local category="${1:?mm_recall_long: category required}"
    local key="${2:?mm_recall_long: key required}"

    [[ "$MM_MODE" == "session" ]] && return 0

    local safe_key
    safe_key=$(echo "$key" | tr -cs 'a-zA-Z0-9_-' '_' | head -c 100)
    local entry_file="${MM_LONG_TERM_DIR}/${category}/${safe_key}.json"

    if [[ ! -f "$entry_file" ]]; then
        return 1
    fi

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys
filepath = sys.argv[1]
with open(filepath, 'r') as f:
    entry = json.load(f)

# Update access tracking
entry['access_count'] = entry.get('access_count', 0) + 1
entry['last_accessed'] = sys.argv[2]
with open(filepath, 'w') as f:
    json.dump(entry, f, ensure_ascii=False, indent=2)

print(entry.get('value', ''))
" "$entry_file" "$(date '+%Y-%m-%dT%H:%M:%S')" 2>/dev/null
    else
        # Fallback: basic jq or grep
        if command -v jq &>/dev/null; then
            jq -r '.value // ""' "$entry_file" 2>/dev/null
        else
            grep -o '"value"[[:space:]]*:[[:space:]]*"[^"]*"' "$entry_file" 2>/dev/null | sed 's/"value"[[:space:]]*:[[:space:]]*"//' | sed 's/"$//'
        fi
    fi
}

# ============================================================
# Episodic memory (success/failure pattern learning)
# ============================================================
mm_record_episode() {
    local phase="${1:?mm_record_episode: phase required}"
    local outcome="${2:?mm_record_episode: outcome required}"  # success | failure | partial
    local details="${3:-}"
    local task_type="${4:-general}"

    [[ "$MM_MODE" == "session" ]] && return 0

    local ts
    ts=$(date '+%Y%m%d_%H%M%S')
    local episode_file="${MM_EPISODIC_DIR}/${phase}_${ts}.json"

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys
episode = {
    'phase': sys.argv[1],
    'outcome': sys.argv[2],
    'details': sys.argv[3],
    'task_type': sys.argv[4],
    'session_id': sys.argv[5],
    'timestamp': sys.argv[6],
    'relevance_score': 1.0
}
with open(sys.argv[7], 'w') as f:
    json.dump(episode, f, ensure_ascii=False, indent=2)
" "$phase" "$outcome" "$details" "$task_type" "$MM_SESSION_ID" "$(date '+%Y-%m-%dT%H:%M:%S')" "$episode_file" 2>/dev/null
    fi

    MM_EPISODIC_COUNT=$((MM_EPISODIC_COUNT + 1))
}

mm_recall_episodes() {
    local phase="${1:?mm_recall_episodes: phase required}"
    local limit="${2:-5}"

    [[ "$MM_MODE" == "session" ]] && return 0

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os, glob

episodic_dir = sys.argv[1]
target_phase = sys.argv[2]
limit = int(sys.argv[3])

episodes = []
for f in glob.glob(os.path.join(episodic_dir, f'{target_phase}_*.json')):
    try:
        with open(f, 'r') as fh:
            ep = json.load(fh)
        episodes.append(ep)
    except: pass

# Sort by timestamp descending, take limit
episodes.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
episodes = episodes[:limit]

for ep in episodes:
    outcome = ep.get('outcome', 'unknown')
    details = ep.get('details', '')[:200]
    ts = ep.get('timestamp', '')
    print(f'  [{outcome}] {ts}: {details}')
" "$MM_EPISODIC_DIR" "$phase" "$limit" 2>/dev/null
    fi
}

# ============================================================
# Search across all memory tiers
# ============================================================
mm_search() {
    local query="${1:?mm_search: query required}"
    local max_results="${2:-10}"

    local results=""

    # 1. Search short-term memory
    for key in "${!MM_SHORT_TERM[@]}"; do
        if [[ "$key" == *"$query"* || "${MM_SHORT_TERM[$key]}" == *"$query"* ]]; then
            results+="[short-term] ${key}: ${MM_SHORT_TERM[$key]:0:200}\n"
        fi
    done

    # 2. Search long-term memory
    if [[ -d "$MM_LONG_TERM_DIR" && "$MM_MODE" != "session" ]]; then
        if command -v python3 &>/dev/null; then
            local lt_results
            lt_results=$(python3 -c "
import json, sys, os, glob

base_dir = sys.argv[1]
query = sys.argv[2].lower()
limit = int(sys.argv[3])
count = 0

for f in glob.glob(os.path.join(base_dir, '**', '*.json'), recursive=True):
    if count >= limit:
        break
    try:
        with open(f, 'r') as fh:
            entry = json.load(fh)
        key = entry.get('key', '')
        value = str(entry.get('value', ''))
        tags = ' '.join(entry.get('tags', []))
        if query in key.lower() or query in value.lower() or query in tags.lower():
            print(f'[long-term/{entry.get(\"category\",\"\")}] {key}: {value[:200]}')
            count += 1
    except: pass
" "$MM_LONG_TERM_DIR" "$query" "$max_results" 2>/dev/null)
            [[ -n "$lt_results" ]] && results+="${lt_results}\n"
        fi
    fi

    # 3. Search episodic memory
    if [[ -d "$MM_EPISODIC_DIR" && "$MM_MODE" != "session" ]]; then
        if command -v python3 &>/dev/null; then
            local ep_results
            ep_results=$(python3 -c "
import json, sys, os, glob

ep_dir = sys.argv[1]
query = sys.argv[2].lower()
limit = int(sys.argv[3])
count = 0

for f in sorted(glob.glob(os.path.join(ep_dir, '*.json')), reverse=True):
    if count >= limit:
        break
    try:
        with open(f, 'r') as fh:
            ep = json.load(fh)
        details = str(ep.get('details', ''))
        phase = ep.get('phase', '')
        if query in details.lower() or query in phase.lower():
            print(f'[episodic/{phase}] {ep.get(\"outcome\",\"\")}: {details[:200]}')
            count += 1
    except: pass
" "$MM_EPISODIC_DIR" "$query" "$max_results" 2>/dev/null)
            [[ -n "$ep_results" ]] && results+="${ep_results}\n"
        fi
    fi

    echo -e "$results"
}

# ============================================================
# Build memory-enhanced context for a phase
# ============================================================
mm_build_context() {
    local phase="${1:?mm_build_context: phase required}"
    local task_type="${2:-general}"

    local context=""

    # 1. Recall relevant short-term memory
    local phase_ctx="${MM_SHORT_TERM[phase_${phase}]:-}"
    if [[ -n "$phase_ctx" ]]; then
        context+="## セッション内メモリ (${phase})\n${phase_ctx}\n\n"
    fi

    # 2. Recall relevant long-term memory
    if [[ "$MM_MODE" == "full" ]]; then
        local lt_ctx
        lt_ctx=$(mm_recall_long "phase_patterns" "${phase}_${task_type}" 2>/dev/null) || lt_ctx=""
        if [[ -n "$lt_ctx" ]]; then
            context+="## 長期記憶 (${phase}/${task_type})\n${lt_ctx}\n\n"
        fi
    fi

    # 3. Recall relevant episodic memory (past successes/failures)
    if [[ "$MM_MODE" == "full" ]]; then
        local episodes
        episodes=$(mm_recall_episodes "$phase" 3 2>/dev/null) || episodes=""
        if [[ -n "$episodes" ]]; then
            context+="## 過去の経験 (${phase})\n${episodes}\n\n"
        fi
    fi

    echo -e "$context"
}

# ============================================================
# Apply time-based decay to episodic memory relevance
# ============================================================
mm_decay() {
    local decay_rate="${1:-0.95}"  # Multiply relevance by this factor

    [[ "$MM_MODE" == "session" ]] && return 0
    [[ ! -d "$MM_EPISODIC_DIR" ]] && return 0

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os, glob

ep_dir = sys.argv[1]
decay = float(sys.argv[2])
min_relevance = 0.1
removed = 0
decayed = 0

for f in glob.glob(os.path.join(ep_dir, '*.json')):
    try:
        with open(f, 'r') as fh:
            ep = json.load(fh)
        score = ep.get('relevance_score', 1.0) * decay
        if score < min_relevance:
            os.remove(f)
            removed += 1
        else:
            ep['relevance_score'] = round(score, 4)
            with open(f, 'w') as fh:
                json.dump(ep, fh, ensure_ascii=False, indent=2)
            decayed += 1
    except: pass

print(f'減衰処理: {decayed}件更新, {removed}件削除')
" "$MM_EPISODIC_DIR" "$decay_rate" 2>/dev/null
    fi
}

# ============================================================
# Memory usage report (ASCII)
# ============================================================
mm_report() {
    echo ""
    echo -e "  ${BOLD:-}${CYAN:-}[Memory Manager Report] v16.0${NC:-}"
    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo -e "  モード:           ${MM_MODE}"
    echo -e "  短期メモリ:       ${MM_SHORT_TERM_COUNT}件"
    echo -e "  長期メモリ:       ${MM_LONG_TERM_COUNT}件"
    echo -e "  エピソード記憶:   ${MM_EPISODIC_COUNT}件"
    echo -e "  ストレージ:       ${MM_BASE_DIR:-N/A}"
    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo ""
}

# ============================================================
# Export memory state as JSON
# ============================================================
mm_export_json() {
    local output_file="${1:-${SESSION_LOG_DIR:-/tmp}/observatory/memory_report.json}"

    {
        echo "{"
        echo "  \"version\": \"16.0\","
        echo "  \"session_id\": \"${MM_SESSION_ID}\","
        echo "  \"mode\": \"${MM_MODE}\","
        echo "  \"short_term_count\": ${MM_SHORT_TERM_COUNT},"
        echo "  \"long_term_count\": ${MM_LONG_TERM_COUNT},"
        echo "  \"episodic_count\": ${MM_EPISODIC_COUNT},"
        echo "  \"storage_dir\": \"${MM_BASE_DIR}\""
        echo "}"
    } > "$output_file" 2>/dev/null || true
}

# ============================================================
# mm_auto_record_phase(phase_name, status, details, score)
#   Thin wrapper around mm_record_episode() for phase-level
#   recording with a normalized interface.
#   - phase_name: e.g. "backend", "frontend", "quality_gate"
#   - status:     "success" | "failure" | "partial"
#   - details:    free-text description of what happened
#   - score:      numeric quality score (appended to details)
# ============================================================
mm_auto_record_phase() {
    local phase_name="${1:?mm_auto_record_phase: phase_name required}"
    local status="${2:?mm_auto_record_phase: status required}"
    local details="${3:-}"
    local score="${4:-}"

    # Normalize status to mm_record_episode outcome format
    local outcome="$status"
    case "$status" in
        success|completed|pass) outcome="success" ;;
        failure|failed|fail)    outcome="failure" ;;
        partial|warning|warn)   outcome="partial" ;;
    esac

    # Append score to details if provided
    local full_details="$details"
    if [[ -n "$score" ]]; then
        full_details="${details:+${details} | }score=${score}"
    fi

    # Delegate to mm_record_episode
    mm_record_episode "$phase_name" "$outcome" "$full_details" "phase_record"
}

# ============================================================
# mm_record_session_summary(session_id, task, domain, total_phases,
#                           success_phases, errors, heals, qg_score)
#   Records a complete session summary as long-term memory.
#   Stores a JSON object via mm_store_long() for cross-session
#   intelligence and trend analysis.
# ============================================================
mm_record_session_summary() {
    local session_id="${1:?mm_record_session_summary: session_id required}"
    local task="${2:-}"
    local domain="${3:-general}"
    local total_phases="${4:-0}"
    local success_phases="${5:-0}"
    local errors="${6:-0}"
    local heals="${7:-0}"
    local qg_score="${8:-0}"

    _mm_log "INFO" "セッションサマリー記録: ${session_id} (domain=${domain})"

    # Build JSON summary
    local safe_task
    safe_task="$(echo "$task" | sed 's/"/\\"/g' | head -c 200)"
    local ts
    ts="$(date '+%Y-%m-%dT%H:%M:%S')"

    local summary_json="{\"session_id\":\"${session_id}\",\"task\":\"${safe_task}\",\"domain\":\"${domain}\",\"total_phases\":${total_phases},\"success_phases\":${success_phases},\"errors\":${errors},\"heals\":${heals},\"qg_score\":${qg_score},\"timestamp\":\"${ts}\"}"

    # Store as long-term memory under "session_summaries" category
    mm_store_long "session_summaries" "session_${session_id}" "$summary_json" "session,summary,${domain}"
}
