#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v105.0 - Solution Index
# =============================================================================
# 「エラー → 修正 → 成功率」の検索可能インデックス。
# 過去のセッションでどのエラーにどの修正が適用され、
# 成功したかを蓄積し、同じエラー再発時に最適な修正を即座に提供。
#
# Functions:
#   si_init            - ロード・ディレクトリ準備
#   si_index_solution  - ソリューションを登録
#   si_search          - エラー署名でトップ3検索
#   si_inject_solution - 既知エラーの最適修正を返す
#   si_prune           - 低成功率ソリューションを削除
#   si_report          - レポート出力
#   si_score           - モジュールスコア(0-100)
#
# All globals use the SI_ prefix.
# =============================================================================

[[ -n "${_SOLUTION_INDEX_LOADED:-}" ]] && return 0
_SOLUTION_INDEX_LOADED=1

SI_VERSION="105.0"
SI_INITIALIZED=false

# Storage
SI_LEARN_DIR=""
SI_INDEX_FILE=""

# Counters
SI_TOTAL_SOLUTIONS=0
SI_TOTAL_SEARCHES=0
SI_TOTAL_HITS=0
SI_PRUNED_COUNT=0

# In-memory index
# Key: "error_signature::domain::fix_hash"  (fix_hash = diff hash or fix description hash)
declare -g -A _SI_SUCCESS_COUNT=()     # key → successful applications
declare -g -A _SI_FAIL_COUNT=()        # key → failed applications
declare -g -A _SI_FIX_DESC=()          # key → fix description
declare -g -A _SI_LAST_USED=()         # key → timestamp of last use

# Reverse lookup: error_signature::domain → space-separated list of fix keys
declare -g -A _SI_ERROR_FIXES=()

# =============================================================================
# si_init - Load from disk, prepare directories
# =============================================================================
si_init() {
    SI_LEARN_DIR="${HOME}/.soloptilink/learning/solutions"
    mkdir -p "$SI_LEARN_DIR" 2>/dev/null || true

    SI_INDEX_FILE="${SI_LEARN_DIR}/index.jsonl"

    # Reset
    SI_TOTAL_SOLUTIONS=0
    SI_TOTAL_SEARCHES=0
    SI_TOTAL_HITS=0
    SI_PRUNED_COUNT=0
    _SI_SUCCESS_COUNT=()
    _SI_FAIL_COUNT=()
    _SI_FIX_DESC=()
    _SI_LAST_USED=()
    _SI_ERROR_FIXES=()

    # Load existing index
    if [[ -f "$SI_INDEX_FILE" ]]; then
        _si_load_index
    fi

    SI_INITIALIZED=true
    return 0
}

# =============================================================================
# _si_json_val - Extract value from JSON (no jq)
# =============================================================================
_si_json_val() {
    local json="$1" key="$2"
    echo "$json" | grep -o "\"${key}\":[^,}]*" | head -1 | sed "s/\"${key}\"://;s/^\"//;s/\"$//;s/^[[:space:]]*//;s/[[:space:]]*$//"
}

# =============================================================================
# _si_escape_json - Escape string for JSON
# =============================================================================
_si_escape_json() {
    local s="$1"
    s="${s//\\/\\\\}"
    s="${s//\"/\\\"}"
    s="${s//$'\n'/\\n}"
    s="${s//$'\t'/\\t}"
    echo "$s"
}

# =============================================================================
# _si_simple_hash - Generate a simple hash from a string (no external deps)
# =============================================================================
_si_simple_hash() {
    local input="$1"
    # Use cksum for a portable hash, fall back to character sum
    if command -v cksum &>/dev/null; then
        echo "$input" | cksum | cut -d' ' -f1
    else
        local sum=0 i
        for (( i=0; i<${#input}; i++ )); do
            local char="${input:$i:1}"
            local ord
            ord=$(printf '%d' "'$char" 2>/dev/null || echo 0)
            sum=$(( (sum * 31 + ord) % 2147483647 ))
        done
        echo "$sum"
    fi
}

# =============================================================================
# _si_load_index - Load persisted solutions from JSONL
# =============================================================================
_si_load_index() {
    [[ ! -f "$SI_INDEX_FILE" ]] && return 0

    local line
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue

        local esig domain fix_hash fix_desc succ_count fail_count last_used
        esig=$(_si_json_val "$line" "error_signature")
        domain=$(_si_json_val "$line" "domain")
        fix_hash=$(_si_json_val "$line" "fix_hash")
        fix_desc=$(_si_json_val "$line" "fix_description")
        succ_count=$(_si_json_val "$line" "success_count")
        fail_count=$(_si_json_val "$line" "fail_count")
        last_used=$(_si_json_val "$line" "last_used")

        [[ -z "$esig" || -z "$fix_hash" ]] && continue
        [[ -z "$domain" ]] && domain="general"
        [[ -z "$succ_count" || ! "$succ_count" =~ ^[0-9]+$ ]] && succ_count=0
        [[ -z "$fail_count" || ! "$fail_count" =~ ^[0-9]+$ ]] && fail_count=0

        local key="${esig}::${domain}::${fix_hash}"
        _SI_SUCCESS_COUNT["$key"]="$succ_count"
        _SI_FAIL_COUNT["$key"]="$fail_count"
        _SI_FIX_DESC["$key"]="$fix_desc"
        _SI_LAST_USED["$key"]="${last_used:-}"

        # Build reverse lookup
        local err_key="${esig}::${domain}"
        local existing="${_SI_ERROR_FIXES[$err_key]:-}"
        if [[ -z "$existing" ]]; then
            _SI_ERROR_FIXES["$err_key"]="$key"
        elif [[ "$existing" != *"$key"* ]]; then
            _SI_ERROR_FIXES["$err_key"]="${existing} ${key}"
        fi

        SI_TOTAL_SOLUTIONS=$((SI_TOTAL_SOLUTIONS + 1))
    done < "$SI_INDEX_FILE"

    return 0
}

# =============================================================================
# _si_save_index - Persist current index to JSONL (full rewrite)
# =============================================================================
_si_save_index() {
    [[ -z "$SI_INDEX_FILE" ]] && return 1

    local tmp_file="${SI_INDEX_FILE}.tmp.$$"

    local key
    for key in "${!_SI_SUCCESS_COUNT[@]}"; do
        # Parse key components
        local remainder="${key}"
        local esig="${remainder%%::*}"
        remainder="${remainder#*::}"
        local domain="${remainder%%::*}"
        local fix_hash="${remainder##*::}"

        local succ="${_SI_SUCCESS_COUNT[$key]:-0}"
        local fail="${_SI_FAIL_COUNT[$key]:-0}"
        local desc="${_SI_FIX_DESC[$key]:-}"
        local last="${_SI_LAST_USED[$key]:-}"
        local total=$((succ + fail))
        local rate=0
        [[ $total -gt 0 ]] && rate=$(( (succ * 100) / total ))

        echo "{\"error_signature\":\"${esig}\",\"domain\":\"${domain}\",\"fix_hash\":\"${fix_hash}\",\"fix_description\":\"${desc}\",\"success_count\":${succ},\"fail_count\":${fail},\"success_rate\":${rate},\"last_used\":\"${last}\"}" >> "$tmp_file"
    done

    if [[ -f "$tmp_file" ]]; then
        mv "$tmp_file" "$SI_INDEX_FILE" 2>/dev/null
    fi

    return 0
}

# =============================================================================
# si_index_solution - Record a solution
# =============================================================================
# Args: error_signature, fix_description, fix_diff_hash, success (true/false), domain
si_index_solution() {
    local error_signature="${1:-}"
    local fix_description="${2:-}"
    local fix_diff_hash="${3:-}"
    local success="${4:-false}"
    local domain="${5:-general}"

    [[ "$SI_INITIALIZED" != "true" ]] && return 1
    [[ -z "$error_signature" ]] && return 1

    # Generate fix hash if not provided
    if [[ -z "$fix_diff_hash" ]]; then
        fix_diff_hash=$(_si_simple_hash "$fix_description")
    fi

    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date +"%Y-%m-%d")

    local key="${error_signature}::${domain}::${fix_diff_hash}"

    # Initialize if first time
    if [[ -z "${_SI_SUCCESS_COUNT[$key]:-}" ]]; then
        _SI_SUCCESS_COUNT["$key"]=0
        _SI_FAIL_COUNT["$key"]=0
        SI_TOTAL_SOLUTIONS=$((SI_TOTAL_SOLUTIONS + 1))
    fi

    # Update counts
    if [[ "$success" == "true" ]]; then
        local prev="${_SI_SUCCESS_COUNT[$key]:-0}"
        _SI_SUCCESS_COUNT["$key"]=$((prev + 1))
    else
        local prev="${_SI_FAIL_COUNT[$key]:-0}"
        _SI_FAIL_COUNT["$key"]=$((prev + 1))
    fi

    local escaped_desc
    escaped_desc=$(_si_escape_json "$fix_description")
    _SI_FIX_DESC["$key"]="$escaped_desc"
    _SI_LAST_USED["$key"]="$timestamp"

    # Update reverse lookup
    local err_key="${error_signature}::${domain}"
    local existing="${_SI_ERROR_FIXES[$err_key]:-}"
    if [[ -z "$existing" ]]; then
        _SI_ERROR_FIXES["$err_key"]="$key"
    elif [[ "$existing" != *"$key"* ]]; then
        _SI_ERROR_FIXES["$err_key"]="${existing} ${key}"
    fi

    # Persist
    _si_save_index

    return 0
}

# =============================================================================
# si_search - Return top-3 solutions by success rate for an error
# =============================================================================
# Args: error_signature, domain
# Output: lines of "success_rate|fix_description|success_count|total_attempts"
si_search() {
    local error_signature="${1:-}"
    local domain="${2:-general}"

    [[ "$SI_INITIALIZED" != "true" ]] && return 1

    SI_TOTAL_SEARCHES=$((SI_TOTAL_SEARCHES + 1))

    local err_key="${error_signature}::${domain}"
    local fix_keys="${_SI_ERROR_FIXES[$err_key]:-}"

    # Also check "general" domain if specific domain has no results
    if [[ -z "$fix_keys" && "$domain" != "general" ]]; then
        err_key="${error_signature}::general"
        fix_keys="${_SI_ERROR_FIXES[$err_key]:-}"
    fi

    [[ -z "$fix_keys" ]] && return 0

    # Build ranked list
    local entries=""
    local fk
    for fk in $fix_keys; do
        local succ="${_SI_SUCCESS_COUNT[$fk]:-0}"
        local fail="${_SI_FAIL_COUNT[$fk]:-0}"
        local total=$((succ + fail))
        [[ $total -eq 0 ]] && continue

        local rate=$(( (succ * 100) / total ))
        local desc="${_SI_FIX_DESC[$fk]:-}"

        entries="${entries}${rate}|${desc}|${succ}|${total}"$'\n'
    done

    # Sort by success rate descending, take top 3
    local results
    results=$(echo "$entries" | sort -t'|' -k1 -rn | head -3)

    local hit_count=0
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        echo "$line"
        hit_count=$((hit_count + 1))
    done <<< "$results"

    [[ $hit_count -gt 0 ]] && SI_TOTAL_HITS=$((SI_TOTAL_HITS + 1))

    return 0
}

# =============================================================================
# si_inject_solution - Return best fix for a known error (for prompt injection)
# =============================================================================
# Args: error_signature, domain
# Output: fix description of highest success rate solution, or empty
si_inject_solution() {
    local error_signature="${1:-}"
    local domain="${2:-general}"

    [[ "$SI_INITIALIZED" != "true" ]] && return 1

    local best_line
    best_line=$(si_search "$error_signature" "$domain" | head -1)

    [[ -z "$best_line" ]] && return 0

    local rate="${best_line%%|*}"
    local rest="${best_line#*|}"
    local desc="${rest%%|*}"

    # Only inject if success rate is reasonable (>= 40%)
    if [[ $rate -ge 40 ]]; then
        echo "$desc"
    fi

    return 0
}

# =============================================================================
# si_prune - Remove solutions with <20% success rate after 5+ attempts
# =============================================================================
si_prune() {
    [[ "$SI_INITIALIZED" != "true" ]] && return 1

    local pruned=0
    local keys_to_remove=()

    local key
    for key in "${!_SI_SUCCESS_COUNT[@]}"; do
        local succ="${_SI_SUCCESS_COUNT[$key]:-0}"
        local fail="${_SI_FAIL_COUNT[$key]:-0}"
        local total=$((succ + fail))

        [[ $total -lt 5 ]] && continue  # Not enough data

        local rate=$(( (succ * 100) / total ))
        if [[ $rate -lt 20 ]]; then
            keys_to_remove+=("$key")
            pruned=$((pruned + 1))
        fi
    done

    # Remove pruned keys
    local rk
    for rk in "${keys_to_remove[@]}"; do
        unset '_SI_SUCCESS_COUNT[$rk]'
        unset '_SI_FAIL_COUNT[$rk]'
        unset '_SI_FIX_DESC[$rk]'
        unset '_SI_LAST_USED[$rk]'
        SI_TOTAL_SOLUTIONS=$((SI_TOTAL_SOLUTIONS - 1))
    done

    # Rebuild reverse lookup
    _SI_ERROR_FIXES=()
    for key in "${!_SI_SUCCESS_COUNT[@]}"; do
        local remainder="${key}"
        local esig="${remainder%%::*}"
        remainder="${remainder#*::}"
        local domain="${remainder%%::*}"

        local err_key="${esig}::${domain}"
        local existing="${_SI_ERROR_FIXES[$err_key]:-}"
        if [[ -z "$existing" ]]; then
            _SI_ERROR_FIXES["$err_key"]="$key"
        else
            _SI_ERROR_FIXES["$err_key"]="${existing} ${key}"
        fi
    done

    SI_PRUNED_COUNT=$((SI_PRUNED_COUNT + pruned))

    # Save updated index
    _si_save_index

    echo "$pruned"
    return 0
}

# =============================================================================
# si_report - Stats
# =============================================================================
si_report() {
    echo -e "\n  ${BOLD:-}--- Solution Index v${SI_VERSION} ---${NC:-}"
    echo -e "  Total solutions    : ${SI_TOTAL_SOLUTIONS}"
    echo -e "  Searches performed : ${SI_TOTAL_SEARCHES}"
    echo -e "  Search hits        : ${SI_TOTAL_HITS}"
    echo -e "  Pruned (low rate)  : ${SI_PRUNED_COUNT}"

    # Show success rate distribution
    local high=0 mid=0 low=0
    local key
    for key in "${!_SI_SUCCESS_COUNT[@]}"; do
        local succ="${_SI_SUCCESS_COUNT[$key]:-0}"
        local fail="${_SI_FAIL_COUNT[$key]:-0}"
        local total=$((succ + fail))
        [[ $total -eq 0 ]] && continue
        local rate=$(( (succ * 100) / total ))
        if [[ $rate -ge 70 ]]; then
            high=$((high + 1))
        elif [[ $rate -ge 40 ]]; then
            mid=$((mid + 1))
        else
            low=$((low + 1))
        fi
    done
    echo -e "  Quality: high=${high} mid=${mid} low=${low}"
}

# =============================================================================
# si_score - Module health score (0-100)
# =============================================================================
si_score() {
    local score=50

    # +15 if solutions are indexed
    [[ $SI_TOTAL_SOLUTIONS -gt 0 ]] && score=$((score + 15))

    # +15 if searches have been performed with hits
    [[ $SI_TOTAL_HITS -gt 0 ]] && score=$((score + 15))

    # +10 if high success rate solutions exist
    local has_high=false
    local key
    for key in "${!_SI_SUCCESS_COUNT[@]}"; do
        local succ="${_SI_SUCCESS_COUNT[$key]:-0}"
        local fail="${_SI_FAIL_COUNT[$key]:-0}"
        local total=$((succ + fail))
        [[ $total -lt 2 ]] && continue
        local rate=$(( (succ * 100) / total ))
        [[ $rate -ge 70 ]] && has_high=true && break
    done
    [[ "$has_high" == "true" ]] && score=$((score + 10))

    # +10 if pruning has been done (maintenance)
    [[ $SI_PRUNED_COUNT -gt 0 ]] && score=$((score + 10))

    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "solution-index" \
    --version "105.0" \
    --description "エラー→修正→成功率の検索可能ソリューションインデックス" \
    --init "si_init" \
    --report "si_report" \
    --score "si_score" \
    --enable-var "ENABLE_SI" \
    --cli-flags "--solution-index:--no-solution-index"
