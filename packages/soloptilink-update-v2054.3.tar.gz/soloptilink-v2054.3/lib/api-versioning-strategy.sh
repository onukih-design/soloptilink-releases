#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v464.0 - API Versioning Strategy Engine
# =============================================================================
# APIバージョニング戦略: バージョン設計、マイグレーションガイド、非推奨管理。
#
# Functions:
#   _avs_init()                  - Initialize
#   _avs_design_versioning()     - Design versioning strategy
#   _avs_generate_migration()    - Generate version migration helpers
#   _avs_generate_deprecation()  - Generate deprecation management
#   _avs_report() / _avs_score()
# =============================================================================

[[ -n "${_AVS_LOADED:-}" ]] && return 0; _AVS_LOADED=1

declare -g AVS_VERSION="464.0"
AVS_GENERATED=0; AVS_ERRORS=0; AVS_FILES_WRITTEN=0
AVS_DESIGN_OK=false; AVS_MIGRATION_OK=false; AVS_DEPRECATION_OK=false

_avs_init() {
    AVS_GENERATED=0; AVS_ERRORS=0; AVS_FILES_WRITTEN=0
    AVS_DESIGN_OK=false; AVS_MIGRATION_OK=false; AVS_DEPRECATION_OK=false
    return 0
}

_avs_log() { echo -e "  ${CYAN:-\033[0;36m}[api-versioning]${NC:-\033[0m} $*" >&2; }
_avs_ok()  { echo -e "  ${GREEN:-\033[0;32m}✅ [api-versioning]${NC:-\033[0m} $*" >&2; }
_avs_err() { echo -e "  ${RED:-\033[0;31m}❌ [api-versioning]${NC:-\033[0m} $*" >&2; AVS_ERRORS=$((AVS_ERRORS + 1)); }

_avs_write_file() {
    local filepath="$1" content="$2"
    local dir; dir="$(dirname "$filepath")"
    [[ -d "$dir" ]] || mkdir -p "$dir"
    echo "$content" > "$filepath" 2>/dev/null || { _avs_err "Failed to write $filepath"; return 1; }
    AVS_FILES_WRITTEN=$((AVS_FILES_WRITTEN + 1))
    return 0
}

_avs_design_versioning() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/api-version/versioning-engine.ts"
    _avs_log "Generating API versioning engine..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v464.0 - API Versioning Engine

export type VersioningStrategy = 'url-path' | 'header' | 'query-param' | 'content-type';

export interface APIVersion {
  version: string;           // e.g., "v1", "v2"
  status: 'active' | 'deprecated' | 'sunset';
  sunsetDate?: string;
  releaseDate: string;
  changelog: string[];
  breakingChanges: string[];
}

export interface VersioningConfig {
  strategy: VersioningStrategy;
  currentVersion: string;
  supportedVersions: APIVersion[];
  defaultVersion: string;
  headerName?: string;       // for header strategy
  queryParam?: string;       // for query-param strategy
}

const DEFAULT_CONFIG: VersioningConfig = {
  strategy: 'url-path',
  currentVersion: 'v1',
  defaultVersion: 'v1',
  supportedVersions: [
    { version: 'v1', status: 'active', releaseDate: '2026-01-01', changelog: ['Initial release'], breakingChanges: [] },
  ],
};

export class APIVersioningEngine {
  private config: VersioningConfig;

  constructor(config?: Partial<VersioningConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  extractVersion(request: { url: string; headers: Record<string, string> }): string {
    switch (this.config.strategy) {
      case 'url-path': {
        const match = request.url.match(/\/api\/(v\d+)\//);
        return match?.[1] ?? this.config.defaultVersion;
      }
      case 'header':
        return request.headers[this.config.headerName ?? 'api-version'] ?? this.config.defaultVersion;
      case 'query-param': {
        const url = new URL(request.url, 'http://localhost');
        return url.searchParams.get(this.config.queryParam ?? 'version') ?? this.config.defaultVersion;
      }
      default:
        return this.config.defaultVersion;
    }
  }

  isSupported(version: string): boolean {
    return this.config.supportedVersions.some(v => v.version === version && v.status !== 'sunset');
  }

  getDeprecationHeaders(version: string): Record<string, string> {
    const v = this.config.supportedVersions.find(sv => sv.version === version);
    if (!v || v.status !== 'deprecated') return {};
    return {
      'Deprecation': 'true',
      'Sunset': v.sunsetDate ?? '',
      'Link': `</api/${this.config.currentVersion}/>; rel="successor-version"`,
    };
  }

  getConfig(): VersioningConfig { return this.config; }
}

export const apiVersioning = new APIVersioningEngine();
TYPESCRIPT
)
    _avs_write_file "$outfile" "$content" || return 1
    AVS_DESIGN_OK=true
    AVS_GENERATED=$((AVS_GENERATED + 1))
    _avs_ok "API versioning engine generated"
    return 0
}

_avs_generate_migration() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/api-version/migration-helper.ts"
    _avs_log "Generating version migration helper..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v464.0 - API Version Migration Helper

export interface MigrationStep {
  fromVersion: string;
  toVersion: string;
  transform: (data: Record<string, unknown>) => Record<string, unknown>;
  description: string;
}

export class VersionMigrationHelper {
  private steps: MigrationStep[] = [];

  addStep(step: MigrationStep): void { this.steps.push(step); }

  migrate(data: Record<string, unknown>, fromVersion: string, toVersion: string): Record<string, unknown> {
    const path = this.findMigrationPath(fromVersion, toVersion);
    let current = { ...data };
    for (const step of path) {
      current = step.transform(current);
    }
    return current;
  }

  private findMigrationPath(from: string, to: string): MigrationStep[] {
    const path: MigrationStep[] = [];
    let current = from;
    while (current !== to) {
      const nextStep = this.steps.find(s => s.fromVersion === current);
      if (!nextStep) throw new Error(`No migration path from ${current} to ${to}`);
      path.push(nextStep);
      current = nextStep.toVersion;
    }
    return path;
  }

  canMigrate(from: string, to: string): boolean {
    try { this.findMigrationPath(from, to); return true; } catch { return false; }
  }
}

export const migrationHelper = new VersionMigrationHelper();
TYPESCRIPT
)
    _avs_write_file "$outfile" "$content" || return 1
    AVS_MIGRATION_OK=true
    AVS_GENERATED=$((AVS_GENERATED + 1))
    _avs_ok "Migration helper generated"
    return 0
}

_avs_generate_deprecation() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/api-version/deprecation-manager.ts"
    _avs_log "Generating deprecation manager..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v464.0 - API Deprecation Manager

export interface DeprecatedEndpoint {
  path: string;
  method: string;
  deprecatedSince: string;
  sunsetDate: string;
  replacement?: string;
  reason: string;
}

export class DeprecationManager {
  private endpoints: DeprecatedEndpoint[] = [];

  deprecate(endpoint: DeprecatedEndpoint): void { this.endpoints.push(endpoint); }

  isDeprecated(path: string, method: string): DeprecatedEndpoint | null {
    return this.endpoints.find(e => e.path === path && e.method === method) ?? null;
  }

  isSunset(path: string, method: string): boolean {
    const ep = this.isDeprecated(path, method);
    if (!ep) return false;
    return new Date(ep.sunsetDate) < new Date();
  }

  getHeaders(path: string, method: string): Record<string, string> {
    const ep = this.isDeprecated(path, method);
    if (!ep) return {};
    const headers: Record<string, string> = { 'Deprecation': `date="${ep.deprecatedSince}"`, 'Sunset': ep.sunsetDate };
    if (ep.replacement) headers['Link'] = `<${ep.replacement}>; rel="successor-version"`;
    return headers;
  }

  getAll(): DeprecatedEndpoint[] { return [...this.endpoints]; }
  getUpcoming(days = 30): DeprecatedEndpoint[] {
    const cutoff = new Date(); cutoff.setDate(cutoff.getDate() + days);
    return this.endpoints.filter(e => new Date(e.sunsetDate) <= cutoff && new Date(e.sunsetDate) > new Date());
  }
}

export const deprecationManager = new DeprecationManager();
TYPESCRIPT
)
    _avs_write_file "$outfile" "$content" || return 1
    AVS_DEPRECATION_OK=true
    AVS_GENERATED=$((AVS_GENERATED + 1))
    _avs_ok "Deprecation manager generated"
    return 0
}

_avs_generate_all() {
    local project_dir="${1:-.}"
    _avs_design_versioning "$project_dir"
    _avs_generate_migration "$project_dir"
    _avs_generate_deprecation "$project_dir"
    _avs_ok "API versioning complete: ${AVS_GENERATED} components, ${AVS_ERRORS} errors"
}

_avs_report() {
    echo -e "\n  ${BOLD:-\033[1m}═══ API Versioning Strategy v${AVS_VERSION} ═══${NC:-\033[0m}"
    echo -e "  Generated    : ${AVS_GENERATED}"
    echo -e "  Errors       : ${AVS_ERRORS}"
    echo -e "  Design       : ${AVS_DESIGN_OK}"
    echo -e "  Migration    : ${AVS_MIGRATION_OK}"
    echo -e "  Deprecation  : ${AVS_DEPRECATION_OK}"
}

_avs_score() {
    local score=50
    ${AVS_DESIGN_OK} && score=$((score + 15))
    ${AVS_MIGRATION_OK} && score=$((score + 15))
    ${AVS_DEPRECATION_OK} && score=$((score + 15))
    [[ ${AVS_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "api-versioning-strategy" --version "464.0" \
        --description "APIバージョニング戦略: バージョン設計×マイグレーション×非推奨管理" \
        --init "_avs_init" --report "_avs_report" --score "_avs_score" \
        --enable-var "ENABLE_API_VERSIONING_STRATEGY" --cli-flags "--api-versioning-strategy:--no-api-versioning-strategy"
fi

# v2003.1: source時のexit codeを確実に0にする
true
