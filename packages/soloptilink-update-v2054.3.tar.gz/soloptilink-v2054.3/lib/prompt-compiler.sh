#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v31.0 - Prompt Compiler
# =============================================================================
# Blueprint + Domain Knowledge + セキュリティ要件 + テンプレートを
# 1つの最適化されたプロンプトにコンパイルする。
#
# 機能:
#   - 構造化セクション分割（CONTEXT / TASK / CONSTRAINTS / OUTPUT_FORMAT）
#   - 重複排除（複数ソースからの注入内容の統合）
#   - 優先度ベース切り詰め（トークン上限対応）
#   - アンチパターン明示的注入
#   - 出力形式の厳密な規定
#
# 依存: lib/domain-knowledge.sh, lib/blueprint-generator.sh
# =============================================================================

[[ -n "${_PROMPT_COMPILER_LOADED:-}" ]] && return 0
_PROMPT_COMPILER_LOADED=1

# =============================================================================
# 設定
# =============================================================================
PC_VERSION="31.0"
PC_WORK_DIR="${HOME}/.soloptilink/prompt-compiler"

# トークン制限（文字数ベース推定: 1トークン ≈ 4文字）
PC_MAX_CHARS=480000        # ~120K tokens
PC_PRIORITY_CUTOFF=360000  # 90K tokens: ここを超えたら低優先度を削除

# アンチパターンリスト（プロンプトに必ず含める「やってはいけないこと」）
PC_ANTI_PATTERNS=(
    "モックデータ禁止: useState([{id: 1, name: \"John\"}]) のようなハードコードデータは絶対に使わない。全データはPrisma ORM経由でDBから取得する"
    "空イベントハンドラ禁止: onClick={() => {}} は禁止。必ずAPI呼び出し+状態更新+エラーハンドリングを実装する"
    "any型禁止: TypeScript strict modeで型安全を保つ。as キャストも禁止。型推論またはジェネリクスで解決する"
    "console.log禁止: 本番コードにconsole.logを残さない。エラーログはconsole.errorのみ許可"
    "TODO/FIXME禁止: 未実装部分を残さない。すべて完全に実装する"
    "ハードコードURL禁止: APIのURLはprocess.env.NEXT_PUBLIC_API_URLまたは相対パス(/api/...)を使用"
    "Date.now()でID生成禁止: IDはcuid()またはDB自動生成を使用"
    "localStorage/sessionStorageをDB代替として使用禁止: データの永続化は必ずDBを使用"
    "import * 禁止: 名前付きインポートのみ使用（バンドルサイズ最適化）"
    "インラインスタイル禁止: Tailwind CSSクラスのみ使用"
    # v31.0: Enterprise Forge アンチパターン追加
    "トランザクション未使用禁止: 複数テーブル操作は必ず prisma.\$transaction() で囲む"
    "エラーバウンダリ未実装禁止: 全ページにErrorBoundaryコンポーネントを設置"
    "サービス層欠如禁止: ビジネスロジックをAPIルートに直書きしない。services/ディレクトリに分離する"
    "監査ログ未実装禁止: CRUD操作には必ず操作者・操作内容・タイムスタンプの記録を実装"
    "入力サニタイズ未実装禁止: 全APIエンドポイントの入力はzodスキーマで検証。未検証データのDB書き込み禁止"
    "統一エラーレスポンス未実装禁止: APIエラーは { error: string, code: string, details?: unknown } 形式で統一"
)

# カラー
PC_GREEN='\033[0;32m'
PC_YELLOW='\033[0;33m'
PC_RED='\033[0;31m'
PC_CYAN='\033[0;36m'
PC_BOLD='\033[1m'
PC_DIM='\033[2m'
PC_NC='\033[0m'

# =============================================================================
# 初期化
# =============================================================================
pc_init() {
    mkdir -p "${PC_WORK_DIR}" 2>/dev/null || true
    echo -e "  ${PC_GREEN}OK${PC_NC} Prompt Compiler v${PC_VERSION}"
}

# =============================================================================
# ログ
# =============================================================================
_pc_log() {
    local level="$1" msg="$2"
    local color="${PC_NC}"
    case "$level" in
        INFO)  color="${PC_GREEN}" ;;
        WARN)  color="${PC_YELLOW}" ;;
        ERROR) color="${PC_RED}" ;;
    esac
    # v2041: ログは stderr へ。従来は stdout に出していたため、コンパイル済みプロンプト
    # (関数の標準出力)の先頭に [PC/INFO] ログ行が混入し LLM プロンプトを汚染していた。
    # stderr 化でプロンプトが綺麗になり、プロンプトキャッシュの HIT/MISS 出力も byte 一致する。
    echo -e "  ${color}[PC/${level}]${PC_NC} ${msg}" >&2
}

# =============================================================================
# 文字数カウント（トークン数推定用）
# =============================================================================
_pc_char_count() {
    echo -n "$1" | wc -c | tr -d ' '
}

# v2041: プロンプトサイズ超過時の安全な切り詰め。
# 旧実装(head -c PC_MAX_CHARS)は末尾に積まれた CONSTRAINTS(アンチパターン+セキュリティ要件)を
# まるごと削除し、かつバイト単位切断で和文(マルチバイト)境界を破壊していた。
# 本実装は CONSTRAINTS と OUTPUT_FORMAT を必ず末尾温存し、本体のみを
# バイト上限内に UTF-8 文字境界安全(末尾の不完全バイトは捨てる)で切り詰める。
# python3 失敗時は従来挙動(バイト切り詰め+OUTPUT_FORMAT)へフォールバックしプロンプト全欠落を防ぐ。
_pc_truncate_keep_constraints() {
    local full="$1"
    local tail notice out
    tail="# CONSTRAINTS\n\n$(pc_get_anti_patterns)\n$(pc_get_security_requirements)\n$(pc_get_output_format)"
    notice="\n\n(※ サイズ超過のため本体の一部を切り詰めました。残りは既存パターンに従って実装してください)\n\n"
    out=$(printf '%s' "$full" | TAIL="$tail" NOTICE="$notice" MAXC="${PC_MAX_CHARS:-480000}" python3 -c '
import os, sys
full = sys.stdin.buffer.read()
tail = os.environ.get("TAIL", "")
notice = os.environ.get("NOTICE", "")
try:
    maxc = int(os.environ.get("MAXC", "480000") or 480000)
except Exception:
    maxc = 480000
budget = maxc - len(tail.encode("utf-8")) - len(notice.encode("utf-8"))
if budget < 1000:
    raise SystemExit(1)
body = full[:budget].decode("utf-8", "ignore")
sys.stdout.write(body + notice + tail)
' 2>/dev/null)
    if [[ -n "$out" ]]; then
        printf '%s' "$out"
    else
        # フォールバック(python3不在/失敗時): 従来挙動
        printf '%s\n\n%s' "$(printf '%s' "$full" | head -c "${PC_MAX_CHARS:-480000}")" "$(pc_get_output_format)"
    fi
}

# =============================================================================
# アンチパターン注入テキスト生成
# =============================================================================
pc_get_anti_patterns() {
    local text=""
    text+="## 禁止事項（違反したらQuality Gate不合格）\n\n"
    local idx=1
    for pattern in "${PC_ANTI_PATTERNS[@]}"; do
        text+="${idx}. **${pattern}**\n"
        idx=$((idx + 1))
    done
    echo -e "$text"
}

# =============================================================================
# 出力形式テンプレート生成
# =============================================================================
pc_get_output_format() {
    local format=""
    format+="## 出力形式（厳密に従うこと）\n\n"
    format+="各ファイルを以下の形式で出力してください:\n\n"
    format+="\`\`\`\n"
    format+="--- FILE: src/app/api/example/route.ts ---\n"
    format+="import { NextRequest, NextResponse } from 'next/server';\n"
    format+="import { prisma } from '@/lib/prisma';\n"
    format+="// ... ファイル全体のコード ...\n"
    format+="--- END FILE ---\n"
    format+="\n"
    format+="--- FILE: src/app/page.tsx ---\n"
    format+="'use client';\n"
    format+="// ... ファイル全体のコード ...\n"
    format+="--- END FILE ---\n"
    format+="\`\`\`\n\n"
    format+="ルール:\n"
    format+="- 必ず \`--- FILE: [パス] ---\` で開始し \`--- END FILE ---\` で終了する\n"
    format+="- パスは \`src/\` から始まる相対パス（例: src/app/api/users/route.ts）\n"
    format+="- prisma/schema.prisma や .env.example 等の設定ファイルも同形式で出力可\n"
    format+="- **省略禁止**: Blueprintのファイルマニフェストにある全ファイルを出力すること\n"
    format+="- **コメントで省略禁止**: \`// ... 残りの実装 ...\` のような省略は禁止。全行を出力\n"
    format+="- 各ファイルは完全で自己完結的であること（他ファイル参照のimportパスは正確に）\n"
    echo -e "$format"
}

# =============================================================================
# セキュリティ要件テキスト生成
# =============================================================================
pc_get_security_requirements() {
    local text=""
    text+="## セキュリティ要件（必須実装）\n\n"
    text+="- パスワード: bcryptでハッシュ化（saltRounds=12）\n"
    text+="- JWT: RS256またはHS256、有効期限15分、リフレッシュトークン7日\n"
    text+="- CORS: 明示的オリジンホワイトリスト（本番URL + localhost:3000）\n"
    text+="- 入力バリデーション: 全APIエンドポイントにzodスキーマ\n"
    text+="- SQLインジェクション: Prisma ORM経由のみ（raw SQL禁止）\n"
    text+="- XSS: React自動エスケープ + dangerouslySetInnerHTML禁止\n"
    text+="- エラーレスポンス: 内部エラー詳細をクライアントに露出しない\n"
    text+="- 環境変数: シークレットは.envに配置、コードにハードコードしない\n"
    echo -e "$text"
}

# =============================================================================
# v31.0: REFERENCE IMPLEMENTATION注入テキスト生成
# Enterprise Patternsモジュールが生成した参照実装コードを注入
# =============================================================================
pc_get_reference_implementation() {
    local ep_dir="${EP_WORK_DIR:-${HOME}/.soloptilink/enterprise-patterns}"
    local section="$1"  # "backend" or "frontend" or "all"

    local text=""
    text+="## 参照実装（REFERENCE IMPLEMENTATION）\n\n"
    text+="以下のコードテンプレートは**お手本**です。このパターン・構造に正確に従って全モデルに展開してください。\n"
    text+="変数名・モデル名は適宜変更しますが、パターン（トランザクション・zod検証・エラーハンドリング等）は変更禁止。\n\n"

    if [[ "$section" == "backend" ]] || [[ "$section" == "all" ]]; then
        if [[ -f "${ep_dir}/api_route_template.ts" ]]; then
            text+="### API Route テンプレート（この構造に従うこと）\n"
            text+="\`\`\`typescript\n"
            text+=$(cat "${ep_dir}/api_route_template.ts")
            text+="\n\`\`\`\n\n"
        fi

        if [[ -f "${ep_dir}/service_template.ts" ]]; then
            text+="### サービス層テンプレート（ビジネスロジックはここに）\n"
            text+="\`\`\`typescript\n"
            text+=$(cat "${ep_dir}/service_template.ts")
            text+="\n\`\`\`\n\n"
        fi

        if [[ -f "${ep_dir}/prisma_client_template.ts" ]]; then
            text+="### Prismaクライアント（シングルトン・コネクションプーリング）\n"
            text+="\`\`\`typescript\n"
            text+=$(cat "${ep_dir}/prisma_client_template.ts")
            text+="\n\`\`\`\n\n"
        fi

        if [[ -f "${ep_dir}/middleware_template.ts" ]]; then
            text+="### ミドルウェアテンプレート（認証・レート制限・セキュリティヘッダー）\n"
            text+="\`\`\`typescript\n"
            text+=$(cat "${ep_dir}/middleware_template.ts")
            text+="\n\`\`\`\n\n"
        fi
    fi

    if [[ "$section" == "frontend" ]] || [[ "$section" == "all" ]]; then
        if [[ -f "${ep_dir}/react_crud_template.tsx" ]]; then
            text+="### React CRUDページテンプレート（この構造に従うこと）\n"
            text+="\`\`\`tsx\n"
            text+=$(cat "${ep_dir}/react_crud_template.tsx")
            text+="\n\`\`\`\n\n"
        fi

        if [[ -f "${ep_dir}/error_boundary_template.tsx" ]]; then
            text+="### ErrorBoundaryテンプレート（全ページに必須）\n"
            text+="\`\`\`tsx\n"
            text+=$(cat "${ep_dir}/error_boundary_template.tsx")
            text+="\n\`\`\`\n\n"
        fi
    fi

    echo -e "$text"
}

# =============================================================================
# v2041 性能P2: 再利用可能プロンプトのキャッシュ層 (context-cache-engine バックエンド)
# -----------------------------------------------------------------------------
# 同一入力(種別/タスク/ドメイン/技術/関連env/DK・Blueprint内容/プロジェクトsrc構成)の
# コンパイル結果をメモ化し、再コンパイル(ファイル再読+大規模文字列の再組立)を省く。
# キーは入力の「内容ハッシュ」なので、入力が1バイトでも変われば自動でミス=常に正しい出力。
# context-cache-engine.sh の TTL/サイズ制限/無効化をそのまま継承(当ファイルは呼ぶだけ)。
# キルスイッチ: PROMPT_CACHE=off / エンジン未ロードや project_dir 不在時は透過的に無効。
# キャッシュ世代: コンパイルロジックを変えたら PC_CACHE_VER を上げて全体無効化。
# =============================================================================
PC_CACHE_CATEGORY="prompt_compile"
PC_CACHE_VER="1"
_PC_CACHE_BASE=""

# 移植性のあるハッシュ (sha256→shasum→cksum)
_pc_hash() {
    if command -v sha256sum &>/dev/null; then sha256sum | cut -d' ' -f1
    elif command -v shasum &>/dev/null; then shasum -a 256 | cut -d' ' -f1
    else cksum | tr -d ' '; fi
}

# ファイル署名 = mtime:size (BSD/GNU両stat対応・内容を読まず安価)。
# これでキー計算コストをコンパイルより十分軽くし、ヒットを必ず net-positive にする。
# (mtime+size はビルドキャッシュの標準手法。生成物は変更時に必ず再書込=mtime更新のため実用上安全)
_pc_sig1() { stat -f '%m:%z' "$1" 2>/dev/null || stat -c '%Y:%s' "$1" 2>/dev/null || echo '?'; }

# キャッシュ利用可否 + 遅延 init (project_dir 配下に閉じる=cwd汚染なし)
# ★既定OFF (opt-in): プロンプト「コンパイル」自体は軽量で、キャッシュ機構の
#   オーバーヘッドが節約分を上回りうる(net-negativeを実測)。既定OFFなら最初の判定で
#   即 return=オーバーヘッド完全ゼロ=既定フロー不変。重いコンパイル(大規模blueprint/DK)を
#   持つ案件のみ PROMPT_CACHE=on で有効化する。LLM応答そのもののキャッシュ(本命の高速化)は
#   exec経路(chain.sh=L9領域)が必要なため本層では扱わない(L9へ設計申し送り)。
_pc_cache_ready() {
    local pdir="$1"
    [[ "${PROMPT_CACHE:-off}" == "on" ]] || return 1
    [[ -n "$pdir" && -d "$pdir" ]] || return 1
    type -t _cce_init &>/dev/null && type -t _cce_store &>/dev/null && type -t _cce_retrieve &>/dev/null || return 1
    if [[ "${CCE_INITIALIZED:-}" != "true" || "${_PC_CACHE_BASE:-}" != "$pdir" ]]; then
        _cce_init "$pdir" >/dev/null 2>&1 || return 1
        _PC_CACHE_BASE="$pdir"
    fi
    [[ "${CCE_INITIALIZED:-}" == "true" ]]
}

# 入力群から決定論的キーを生成 (mtime+size署名ベース=変更で自動無効化・安価)
# 引数: kind task domain tech blueprint_dir dk_dir project_dir
_pc_cache_key() {
    {
        printf 'v%s\037%s\037%s\037%s\037%s\037ep=%s\037mx=%s\n' \
            "$PC_CACHE_VER" "$1" "$2" "$3" "$4" \
            "${CLI_ENABLE_ENTERPRISE_PATTERNS:-true}" "${PC_MAX_CHARS:-480000}"
        local d f
        for d in "$5" "$6"; do
            [[ -d "$d" ]] || continue
            while IFS= read -r f; do
                printf '%s|%s\n' "$f" "$(_pc_sig1 "$f")"
            done < <(find "$d" -type f \( -name '*.md' -o -name '*.prisma' -o -name '*.json' -o -name '*.txt' \) 2>/dev/null | LC_ALL=C sort)
        done
        [[ -n "$7" && -d "$7/src" ]] && find "$7/src" -type f \( -name '*.ts' -o -name '*.tsx' \) 2>/dev/null | LC_ALL=C sort
    } | _pc_hash
}

# =============================================================================
# バックエンド実装プロンプトのコンパイル
# =============================================================================
pc_compile_backend_prompt() {
    local task_desc="$1"
    local domain="${2:-generic}"
    local tech_stack="${3:-nextjs}"
    local blueprint_dir="${4:-${BG_WORK_DIR:-${HOME}/.soloptilink/blueprint}}"
    local dk_dir="${5:-${DK_WORK_DIR:-${HOME}/.soloptilink/domain-knowledge}}"
    local project_dir="${6:-}"
    local output_file="${7:-${PC_WORK_DIR}/compiled_backend_prompt.md}"

    _pc_log "INFO" "バックエンドプロンプトコンパイル中..."

    # v2041 P2: プロンプトキャッシュ照会 (ヒットなら再コンパイルを省く)
    local _pc_ck=""
    if _pc_cache_ready "$project_dir"; then
        _pc_ck=$(_pc_cache_key "backend" "$task_desc" "$domain" "$tech_stack" "$blueprint_dir" "$dk_dir" "$project_dir")
        local _pc_hit
        _pc_hit=$(_cce_retrieve "$PC_CACHE_CATEGORY" "$_pc_ck" 2>/dev/null || true)
        if [[ -n "$_pc_hit" ]]; then
            _pc_log "INFO" "プロンプトキャッシュHIT (backend / ${_pc_ck:0:12})"
            printf '%s\n' "$_pc_hit" > "$output_file" 2>/dev/null || true
            printf '%s\n' "$_pc_hit"
            return 0
        fi
    fi

    local prompt=""

    # SECTION 1: CONTEXT (最高優先度)
    prompt+="# CONTEXT\n\n"
    prompt+="あなたはシニアフルスタックエンジニアです。以下のプロジェクトのバックエンドAPIを実装します。\n\n"
    prompt+="## プロジェクト概要\n"
    prompt+="- タスク: ${task_desc}\n"
    prompt+="- ドメイン: ${domain}\n"
    prompt+="- 技術スタック: Next.js 15 App Router + Prisma + PostgreSQL + zod + Tailwind CSS\n\n"

    # 既存プロジェクト構造
    if [[ -n "$project_dir" ]] && [[ -d "$project_dir" ]]; then
        prompt+="## 既存ファイル構造\n"
        prompt+="\`\`\`\n"
        prompt+=$(find "$project_dir/src" -type f -name "*.ts" -o -name "*.tsx" 2>/dev/null | head -50 | sed "s|$project_dir/||")
        prompt+="\n\`\`\`\n\n"
    fi

    # SECTION 2: DOMAIN KNOWLEDGE (高優先度)
    if [[ -f "${dk_dir}/domain_prisma_schema.prisma" ]]; then
        prompt+="# DOMAIN KNOWLEDGE\n\n"
        prompt+="## 確定済みPrismaスキーマ（そのまま使用。変更禁止）\n"
        prompt+="\`\`\`prisma\n"
        prompt+=$(cat "${dk_dir}/domain_prisma_schema.prisma")
        prompt+="\n\`\`\`\n\n"
    fi

    if [[ -f "${dk_dir}/domain_api_spec.md" ]]; then
        prompt+=$(cat "${dk_dir}/domain_api_spec.md")
        prompt+="\n\n"
    fi

    if [[ -f "${dk_dir}/domain_business_rules.md" ]]; then
        prompt+=$(cat "${dk_dir}/domain_business_rules.md")
        prompt+="\n\n"
    fi

    # SECTION 3: BLUEPRINT (高優先度)
    if [[ -f "${blueprint_dir}/backend_blueprint.md" ]]; then
        prompt+="# IMPLEMENTATION BLUEPRINT\n\n"
        prompt+="以下のBlueprintに従って正確に実装してください。\n"
        prompt+="関数シグネチャ・ロジック手順・バリデーションはすべて確定済みです。\n\n"
        prompt+=$(cat "${blueprint_dir}/backend_blueprint.md")
        prompt+="\n\n"
    fi

    # SECTION 4: SHARED TYPES (中優先度)
    if [[ -f "${blueprint_dir}/shared_blueprint.md" ]]; then
        prompt+="# SHARED TYPES & UTILITIES\n\n"
        prompt+="以下の型定義・ユーティリティをそのまま使用してください。\n\n"
        prompt+=$(cat "${blueprint_dir}/shared_blueprint.md")
        prompt+="\n\n"
    fi

    # SECTION 4.5: REFERENCE IMPLEMENTATION (v31.0 Enterprise Forge)
    if [[ "${CLI_ENABLE_ENTERPRISE_PATTERNS:-true}" == "true" ]] && type -t ep_init &>/dev/null; then
        local ref_impl
        ref_impl=$(pc_get_reference_implementation "backend")
        if [[ -n "$ref_impl" ]]; then
            prompt+="# REFERENCE IMPLEMENTATION (v31.0)\n\n"
            prompt+="$ref_impl\n"
        fi
    fi

    # SECTION 5: CONSTRAINTS (必須)
    prompt+="# CONSTRAINTS\n\n"
    prompt+=$(pc_get_anti_patterns)
    prompt+="\n"
    prompt+=$(pc_get_security_requirements)
    prompt+="\n"

    # v31.0: Enterprise Patterns アンチパターン追加注入
    if [[ "${CLI_ENABLE_ENTERPRISE_PATTERNS:-true}" == "true" ]] && type -t ep_get_anti_patterns &>/dev/null; then
        local ep_anti
        ep_anti=$(ep_get_anti_patterns 2>/dev/null)
        if [[ -n "$ep_anti" ]]; then
            prompt+="## エンタープライズ品質要件（v31.0追加）\n\n"
            prompt+="${ep_anti}\n\n"
        fi
    fi

    # SECTION 6: OUTPUT FORMAT (必須)
    prompt+=$(pc_get_output_format)

    # トークン制限チェック
    local char_count
    char_count=$(_pc_char_count "$prompt")
    if (( char_count > PC_MAX_CHARS )); then
        _pc_log "WARN" "プロンプトサイズ超過 (${char_count} chars)。本体を切り詰め、CONSTRAINTS/OUTPUTを末尾温存します"
        prompt=$(_pc_truncate_keep_constraints "$prompt")
    fi

    _pc_log "INFO" "コンパイル完了 (${char_count} chars / ~$(( char_count / 4 )) tokens)"

    # v2041 P2: コンパイル結果をキャッシュへ保存 (ミス時のみ・キー算出済の場合)
    [[ -n "${_pc_ck:-}" ]] && _cce_store "$PC_CACHE_CATEGORY" "$_pc_ck" "$prompt" 2>/dev/null || true
    echo "$prompt" > "$output_file"
    echo "$prompt"
}

# =============================================================================
# フロントエンド実装プロンプトのコンパイル
# =============================================================================
pc_compile_frontend_prompt() {
    local task_desc="$1"
    local domain="${2:-generic}"
    local tech_stack="${3:-nextjs}"
    local blueprint_dir="${4:-${BG_WORK_DIR:-${HOME}/.soloptilink/blueprint}}"
    local dk_dir="${5:-${DK_WORK_DIR:-${HOME}/.soloptilink/domain-knowledge}}"
    local project_dir="${6:-}"
    local output_file="${7:-${PC_WORK_DIR}/compiled_frontend_prompt.md}"

    _pc_log "INFO" "フロントエンドプロンプトコンパイル中..."

    # v2041 P2: プロンプトキャッシュ照会 (ヒットなら再コンパイルを省く)
    local _pc_ck=""
    if _pc_cache_ready "$project_dir"; then
        _pc_ck=$(_pc_cache_key "frontend" "$task_desc" "$domain" "$tech_stack" "$blueprint_dir" "$dk_dir" "$project_dir")
        local _pc_hit
        _pc_hit=$(_cce_retrieve "$PC_CACHE_CATEGORY" "$_pc_ck" 2>/dev/null || true)
        if [[ -n "$_pc_hit" ]]; then
            _pc_log "INFO" "プロンプトキャッシュHIT (frontend / ${_pc_ck:0:12})"
            printf '%s\n' "$_pc_hit" > "$output_file" 2>/dev/null || true
            printf '%s\n' "$_pc_hit"
            return 0
        fi
    fi

    local prompt=""

    # SECTION 1: CONTEXT
    prompt+="# CONTEXT\n\n"
    prompt+="あなたはシニアフロントエンドエンジニアです。以下のプロジェクトのフロントエンドUIを実装します。\n\n"
    prompt+="## プロジェクト概要\n"
    prompt+="- タスク: ${task_desc}\n"
    prompt+="- ドメイン: ${domain}\n"
    prompt+="- 技術スタック: Next.js 15 App Router + Tailwind CSS v3 + shadcn/ui + React Hook Form + zod + Lucide React\n\n"

    # 既存ファイル構造
    if [[ -n "$project_dir" ]] && [[ -d "$project_dir" ]]; then
        prompt+="## 既存ファイル構造\n"
        prompt+="\`\`\`\n"
        prompt+=$(find "$project_dir/src" -type f \( -name "*.ts" -o -name "*.tsx" \) 2>/dev/null | head -60 | sed "s|$project_dir/||")
        prompt+="\n\`\`\`\n\n"

        # 既存のバックエンドAPI一覧（frontend がどのAPIを呼ぶか知る必要がある）
        local api_routes
        api_routes=$(find "$project_dir/src/app/api" -name "route.ts" 2>/dev/null | sed "s|$project_dir/src/app||" | sed 's|/route.ts||' | sort)
        if [[ -n "$api_routes" ]]; then
            prompt+="## 実装済みバックエンドAPI\n"
            prompt+="\`\`\`\n"
            prompt+="${api_routes}\n"
            prompt+="\`\`\`\n\n"
        fi
    fi

    # SECTION 2: DOMAIN KNOWLEDGE
    if [[ -f "${dk_dir}/domain_page_spec.md" ]]; then
        prompt+="# DOMAIN KNOWLEDGE\n\n"
        prompt+=$(cat "${dk_dir}/domain_page_spec.md")
        prompt+="\n\n"
    fi

    if [[ -f "${dk_dir}/domain_features_spec.md" ]]; then
        prompt+=$(cat "${dk_dir}/domain_features_spec.md")
        prompt+="\n\n"
    fi

    if [[ -f "${dk_dir}/domain_business_rules.md" ]]; then
        prompt+=$(cat "${dk_dir}/domain_business_rules.md")
        prompt+="\n\n"
    fi

    # SECTION 3: BLUEPRINT
    if [[ -f "${blueprint_dir}/frontend_blueprint.md" ]]; then
        prompt+="# IMPLEMENTATION BLUEPRINT\n\n"
        prompt+="以下のBlueprintに従って正確に実装してください。\n"
        prompt+="コンポーネント構造・props・状態・ハンドラはすべて確定済みです。\n\n"
        prompt+=$(cat "${blueprint_dir}/frontend_blueprint.md")
        prompt+="\n\n"
    fi

    # SECTION 4: SHARED TYPES
    if [[ -f "${blueprint_dir}/shared_blueprint.md" ]]; then
        prompt+="# SHARED TYPES & UTILITIES\n\n"
        prompt+=$(cat "${blueprint_dir}/shared_blueprint.md")
        prompt+="\n\n"
    fi

    # SECTION 4.5: REFERENCE IMPLEMENTATION (v31.0 Enterprise Forge)
    if [[ "${CLI_ENABLE_ENTERPRISE_PATTERNS:-true}" == "true" ]] && type -t ep_init &>/dev/null; then
        local ref_impl
        ref_impl=$(pc_get_reference_implementation "frontend")
        if [[ -n "$ref_impl" ]]; then
            prompt+="# REFERENCE IMPLEMENTATION (v31.0)\n\n"
            prompt+="$ref_impl\n"
        fi
    fi

    # SECTION 5: CONSTRAINTS
    prompt+="# CONSTRAINTS\n\n"
    prompt+=$(pc_get_anti_patterns)
    prompt+="\n"

    # v31.0: Enterprise Patterns アンチパターン追加注入
    if [[ "${CLI_ENABLE_ENTERPRISE_PATTERNS:-true}" == "true" ]] && type -t ep_get_anti_patterns &>/dev/null; then
        local ep_anti
        ep_anti=$(ep_get_anti_patterns 2>/dev/null)
        if [[ -n "$ep_anti" ]]; then
            prompt+="## エンタープライズ品質要件（v31.0追加）\n\n"
            prompt+="${ep_anti}\n\n"
        fi
    fi

    # フロントエンド固有ルール
    prompt+="## フロントエンド固有ルール\n\n"
    prompt+="- Server Component を優先。'use client' は状態管理/イベントハンドラが必要な場合のみ\n"
    prompt+="- shadcn/ui コンポーネントを最大限活用（Button, Dialog, Table, Form, Card, etc.）\n"
    prompt+="- Lucide React アイコンを使用（heroiconsやreact-iconsは使わない）\n"
    prompt+="- レスポンシブ: sm: / md: / lg: ブレークポイントを適切に使用\n"
    prompt+="- ダークモード: dark: バリアントを全コンポーネントに対応\n"
    prompt+="- ローディング状態: Skeleton コンポーネントまたは Spinner を表示\n"
    prompt+="- エラー状態: ユーザーフレンドリーなエラーメッセージ + リトライボタン\n"
    prompt+="- 空状態: EmptyState コンポーネント + 作成ボタン\n"
    prompt+="- 確認ダイアログ: 削除操作には必ず AlertDialog で確認\n"
    prompt+="- トースト通知: 作成/更新/削除の成功/失敗時に表示\n"
    prompt+="- フォームバリデーション: React Hook Form + zodResolver\n\n"

    # SECTION 6: OUTPUT FORMAT
    prompt+=$(pc_get_output_format)

    # トークン制限チェック
    local char_count
    char_count=$(_pc_char_count "$prompt")
    if (( char_count > PC_MAX_CHARS )); then
        _pc_log "WARN" "プロンプトサイズ超過 (${char_count} chars)。本体を切り詰め、CONSTRAINTS/OUTPUTを末尾温存します"
        prompt=$(_pc_truncate_keep_constraints "$prompt")
    fi

    _pc_log "INFO" "コンパイル完了 (${char_count} chars / ~$(( char_count / 4 )) tokens)"

    # v2041 P2: コンパイル結果をキャッシュへ保存 (ミス時のみ・キー算出済の場合)
    [[ -n "${_pc_ck:-}" ]] && _cce_store "$PC_CACHE_CATEGORY" "$_pc_ck" "$prompt" 2>/dev/null || true
    echo "$prompt" > "$output_file"
    echo "$prompt"
}

# =============================================================================
# 共有層プロンプトのコンパイル
# =============================================================================
pc_compile_shared_prompt() {
    local task_desc="$1"
    local domain="${2:-generic}"
    local blueprint_dir="${3:-${BG_WORK_DIR:-${HOME}/.soloptilink/blueprint}}"
    local dk_dir="${4:-${DK_WORK_DIR:-${HOME}/.soloptilink/domain-knowledge}}"
    local output_file="${5:-${PC_WORK_DIR}/compiled_shared_prompt.md}"

    _pc_log "INFO" "共有層プロンプトコンパイル中..."

    local prompt=""
    prompt+="# CONTEXT\n\n"
    prompt+="あなたはTypeScriptアーキテクトです。プロジェクトの共有層（型定義、ユーティリティ、設定ファイル）を実装します。\n\n"
    prompt+="## プロジェクト: ${task_desc}\n"
    prompt+="## ドメイン: ${domain}\n\n"

    # Prismaスキーマ
    if [[ -f "${dk_dir}/domain_prisma_schema.prisma" ]]; then
        prompt+="## Prismaスキーマ\n"
        prompt+="\`\`\`prisma\n"
        prompt+=$(cat "${dk_dir}/domain_prisma_schema.prisma")
        prompt+="\n\`\`\`\n\n"
    fi

    # Blueprint
    if [[ -f "${blueprint_dir}/shared_blueprint.md" ]]; then
        prompt+="# BLUEPRINT\n\n"
        prompt+=$(cat "${blueprint_dir}/shared_blueprint.md")
        prompt+="\n\n"
    fi

    # 出力形式
    prompt+=$(pc_get_output_format)

    echo "$prompt" > "$output_file"
    _pc_log "INFO" "共有層コンパイル完了"
    echo "$prompt"
}

# =============================================================================
# 統合コンパイル（3層まとめてコンパイル）
# =============================================================================
pc_compile_all() {
    local task_desc="$1"
    local domain="${2:-generic}"
    local tech_stack="${3:-nextjs}"
    local blueprint_dir="${4:-${BG_WORK_DIR:-${HOME}/.soloptilink/blueprint}}"
    local dk_dir="${5:-${DK_WORK_DIR:-${HOME}/.soloptilink/domain-knowledge}}"
    local project_dir="${6:-}"

    mkdir -p "${PC_WORK_DIR}" 2>/dev/null || true

    _pc_log "INFO" "全プロンプト統合コンパイル開始"

    pc_compile_shared_prompt "$task_desc" "$domain" "$blueprint_dir" "$dk_dir" >/dev/null
    pc_compile_backend_prompt "$task_desc" "$domain" "$tech_stack" "$blueprint_dir" "$dk_dir" "$project_dir" >/dev/null
    pc_compile_frontend_prompt "$task_desc" "$domain" "$tech_stack" "$blueprint_dir" "$dk_dir" "$project_dir" >/dev/null

    _pc_log "INFO" "全プロンプト統合コンパイル完了"
    _pc_log "INFO" "出力先: ${PC_WORK_DIR}/"

    echo "${PC_WORK_DIR}"
}

# =============================================================================
# v2028.2: Learning Pipeline - Predictive Foresight 自動注入
# =============================================================================
# 既存の pc_compile_*_prompt() の戻り値に対して、中央DBから取得した
# 「他の顧客が踏んだエラーパターン Top N」を Predictive Foresight として
# 追記する。学習データキャッシュ無し or fetcher 未配線時はサイレントに元プロンプトを返す。
#
# 使い方:
#   prompt=$(pc_compile_backend_prompt ...)
#   prompt=$(pc_inject_predictive_foresight "$prompt" "${DOMAIN_TYPE:-}" "${PHASE_NAME:-}" 10)
# =============================================================================
pc_inject_predictive_foresight() {
    local prompt="${1:-}"
    local domain="${2:-}"
    local phase="${3:-}"
    local n="${4:-10}"

    # Learning Fetcher 未配線時はそのまま返す
    if ! type -t lf_inject_into_prompt &>/dev/null; then
        if [[ -f "${HOME}/.soloptilink/lib/learning-pipeline/learning-fetcher.sh" ]]; then
            # shellcheck source=/dev/null
            source "${HOME}/.soloptilink/lib/learning-pipeline/learning-fetcher.sh" 2>/dev/null || true
            type -t lf_init &>/dev/null && lf_init 2>/dev/null || true
        fi
    fi

    if type -t lf_inject_into_prompt &>/dev/null; then
        lf_inject_into_prompt "$prompt" "$domain" "$phase" "$n"
    else
        # フォールバック: 元プロンプトをそのまま
        echo -n "$prompt"
    fi
}

# =============================================================================
# v2035.0: Strategic Planning Engine - 戦略計画の自動注入
# =============================================================================
# spe_run が確定した戦略計画(ゴール/サブタスク/アーキ決定/リスク対策/戦略)を、
# 各フェーズのコード生成プロンプトに合流させる。SPE 未稼働時は元プロンプトを返す。
#   prompt=$(pc_inject_strategic_plan "$prompt")
# =============================================================================
pc_inject_strategic_plan() {
    local prompt="${1:-}"
    if type -t spe_get_plan_context &>/dev/null; then
        local plan_ctx; plan_ctx=$(spe_get_plan_context 2>/dev/null || true)
        if [[ -n "$plan_ctx" ]]; then
            printf '%s\n%s' "$prompt" "$plan_ctx"
            return 0
        fi
    fi
    printf '%s' "$prompt"
}

# =============================================================================
# バージョン情報
# =============================================================================
pc_version() {
    echo "Prompt Compiler v${PC_VERSION}+LearningPipeline"
}
