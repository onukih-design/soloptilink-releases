#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v502.0 - ML Bridge
# Bash-Python ML連携ブリッジ: bashモジュールからPython MLレイヤーへの
# ゼロコンフィグ接続を提供
#
# 機能:
#   1. Python3/MLパッケージの自動検出・可用性チェック
#   2. JSON-RPCによるbash→Python双方向通信
#   3. 品質予測/エラー分類/モデル学習のショートハンド
#   4. MLレイヤー非利用時のグレースフルフォールバック
#   5. Module Registry自己登録
#
# アーキテクチャ:
#   Bash caller → _ml_bridge_call() → JSON-RPC stdin →
#     tools/ml/server.py → JSON-RPC stdout → Bash result
#
# v502.0: Bash-Python Bridge
# ============================================================

[[ -n "${_MLB_LOADED:-}" ]] && return 0
_MLB_LOADED=1

# --- グローバル状態 ---
MLB_VERSION="502.0"
MLB_INITIALIZED=false
MLB_PYTHON_AVAILABLE=false
MLB_ML_AVAILABLE=false
MLB_CALL_COUNT=0
MLB_CALL_OK=0
MLB_CALL_FAIL=0
MLB_FALLBACK_COUNT=0

# --- パス ---
MLB_TOOLS_DIR=""
MLB_SERVER_SCRIPT=""
MLB_PYTHON_BIN=""

# --- 設定 ---
MLB_TIMEOUT="${MLB_TIMEOUT:-30}"
MLB_ENABLE_CACHE="${MLB_ENABLE_CACHE:-true}"
MLB_CACHE_TTL="${MLB_CACHE_TTL:-300}"
MLB_MODEL_DIR="${MLB_MODEL_DIR:-${HOME}/.soloptilink/ml/models}"
MLB_LOG_DIR="${MLB_LOG_DIR:-${HOME}/.soloptilink/ml/logs}"

# --- 内部キャッシュ ---
declare -A _MLB_CACHE=()
declare -A _MLB_CACHE_TS=()

# ============================================================
# ログ
# ============================================================
_mlb_log() {
    local level="$1"; shift
    local msg="$*"
    local ts
    ts=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "unknown")
    echo "[${ts}] [ML-Bridge] [${level}] ${msg}" >&2

    # ファイルログ (ディレクトリ存在時のみ)
    if [[ -d "$MLB_LOG_DIR" ]]; then
        echo "[${ts}] [${level}] ${msg}" >> "${MLB_LOG_DIR}/bridge.log" 2>/dev/null || true
    fi
}

# ============================================================
# 初期化
# ============================================================
_ml_bridge_init() {
    if [[ "$MLB_INITIALIZED" == "true" ]]; then
        return 0
    fi

    # パス解決
    local script_dir="${SCRIPT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
    MLB_TOOLS_DIR="${script_dir}/tools/ml"
    MLB_SERVER_SCRIPT="${MLB_TOOLS_DIR}/server.py"

    # ディレクトリ作成
    mkdir -p "$MLB_MODEL_DIR" 2>/dev/null || true
    mkdir -p "$MLB_LOG_DIR" 2>/dev/null || true

    # Python3検出
    MLB_PYTHON_BIN=""
    MLB_PYTHON_AVAILABLE=false
    MLB_ML_AVAILABLE=false

    local candidates=("python3" "python")
    for cmd in "${candidates[@]}"; do
        if command -v "$cmd" &>/dev/null; then
            local ver
            ver=$("$cmd" --version 2>&1 | sed -n 's/Python \([0-9]*\)\.\([0-9]*\).*/\1.\2/p')
            local major minor
            major=$(echo "$ver" | cut -d. -f1)
            minor=$(echo "$ver" | cut -d. -f2)
            if [[ "${major:-0}" -ge 3 ]] && [[ "${minor:-0}" -ge 8 ]]; then
                MLB_PYTHON_BIN="$cmd"
                MLB_PYTHON_AVAILABLE=true
                _mlb_log "INFO" "Python検出: $cmd (${ver})"
                break
            fi
        fi
    done

    if [[ "$MLB_PYTHON_AVAILABLE" != "true" ]]; then
        _mlb_log "WARN" "Python3.8+が見つかりません - MLブリッジはフォールバックモードで動作します"
        MLB_INITIALIZED=true
        return 0
    fi

    # MLパッケージ検証
    local ml_check
    ml_check=$("$MLB_PYTHON_BIN" -c "
import sys
try:
    import json
    available = []
    try:
        import numpy; available.append('numpy')
    except ImportError: pass
    try:
        import sklearn; available.append('sklearn')
    except ImportError: pass
    print(json.dumps({'ok': True, 'packages': available}))
except Exception as e:
    print(json.dumps({'ok': False, 'error': str(e)}))
" 2>/dev/null)

    if echo "$ml_check" | grep -q '"ok": true\|"ok":true'; then
        MLB_ML_AVAILABLE=true
        local pkgs
        pkgs=$(echo "$ml_check" | sed -n 's/.*"packages": \[\([^]]*\)\].*/\1/p' | tr -d '"' | tr ',' ' ')
        _mlb_log "INFO" "MLパッケージ検出: ${pkgs:-json-only}"
    else
        _mlb_log "WARN" "MLパッケージが利用不可 - 基本JSON処理のみ使用可能"
    fi

    # サーバースクリプト検証
    if [[ ! -f "$MLB_SERVER_SCRIPT" ]]; then
        _mlb_log "WARN" "MLサーバースクリプトが見つかりません: ${MLB_SERVER_SCRIPT}"
    fi

    MLB_INITIALIZED=true
    _mlb_log "INFO" "ML Bridge初期化完了 (python=${MLB_PYTHON_AVAILABLE}, ml=${MLB_ML_AVAILABLE})"
    return 0
}

# ============================================================
# JSON-RPC通信コア
# ============================================================

# _ml_bridge_call <method> <params_json> [timeout]
# JSON-RPCリクエストをPython MLサーバーに送信し結果を返す
# 戻り値: 成功=0 (stdout にresult JSON), 失敗=1 (stdout にerror JSON)
_ml_bridge_call() {
    local method="${1:?method required}"
    local params="$2"
    [[ -z "$params" ]] && params='{}'
    local timeout="${3:-$MLB_TIMEOUT}"

    ((MLB_CALL_COUNT++))

    # Python非利用時のフォールバック
    if [[ "$MLB_PYTHON_AVAILABLE" != "true" ]] || [[ ! -f "$MLB_SERVER_SCRIPT" ]]; then
        ((MLB_FALLBACK_COUNT++))
        _mlb_fallback "$method" "$params"
        return $?
    fi

    # キャッシュチェック
    if [[ "$MLB_ENABLE_CACHE" == "true" ]]; then
        local cache_key="${method}:${params}"
        local cached="${_MLB_CACHE[$cache_key]:-}"
        local cached_ts="${_MLB_CACHE_TS[$cache_key]:-0}"
        local now
        now=$(date +%s 2>/dev/null || echo 0)

        if [[ -n "$cached" ]] && [[ $((now - cached_ts)) -lt $MLB_CACHE_TTL ]]; then
            _mlb_log "DEBUG" "キャッシュヒット: ${method}"
            echo "$cached"
            ((MLB_CALL_OK++))
            return 0
        fi
    fi

    # JSON-RPCリクエスト構築
    local request_id=$((RANDOM % 100000))
    local rpc_request
    # Build JSON-RPC: put params BEFORE method so the closing } is unambiguous
    # Or simply: don't put a trailing } since params already closes itself,
    # but the outer object needs it. Solution: use explicit string concat.
    local json_prefix='{"jsonrpc":"2.0","id":'"${request_id}"',"method":"'"${method}"'","params":'
    rpc_request="${json_prefix}${params}}"

    # 一時ファイルを使った通信
    local tmp_out tmp_err
    tmp_out=$(mktemp "${TMPDIR:-/tmp}/mlb_out.XXXXXX") || {
        _mlb_log "ERROR" "一時ファイル作成失敗"
        ((MLB_CALL_FAIL++))
        _mlb_fallback "$method" "$params"
        return $?
    }
    tmp_err=$(mktemp "${TMPDIR:-/tmp}/mlb_err.XXXXXX") || {
        rm -f "$tmp_out"
        _mlb_log "ERROR" "一時ファイル作成失敗"
        ((MLB_CALL_FAIL++))
        _mlb_fallback "$method" "$params"
        return $?
    }

    # Python MLサーバー呼び出し (タイムアウト付き)
    local exit_code=0
    if command -v timeout &>/dev/null; then
        echo "$rpc_request" | timeout "${timeout}" "$MLB_PYTHON_BIN" "$MLB_SERVER_SCRIPT" \
            > "$tmp_out" 2> "$tmp_err" || exit_code=$?
    elif command -v gtimeout &>/dev/null; then
        echo "$rpc_request" | gtimeout "${timeout}" "$MLB_PYTHON_BIN" "$MLB_SERVER_SCRIPT" \
            > "$tmp_out" 2> "$tmp_err" || exit_code=$?
    else
        echo "$rpc_request" | "$MLB_PYTHON_BIN" "$MLB_SERVER_SCRIPT" \
            > "$tmp_out" 2> "$tmp_err" || exit_code=$?
    fi

    local result
    result=$(cat "$tmp_out" 2>/dev/null)
    local stderr_out
    stderr_out=$(cat "$tmp_err" 2>/dev/null)

    rm -f "$tmp_out" "$tmp_err"

    # エラーログ (stderr出力があれば)
    if [[ -n "$stderr_out" ]]; then
        _mlb_log "DEBUG" "Python stderr: ${stderr_out:0:200}"
    fi

    # タイムアウトまたはエラー
    if [[ $exit_code -ne 0 ]] || [[ -z "$result" ]]; then
        _mlb_log "WARN" "MLサーバー呼び出し失敗 (method=${method}, exit=${exit_code})"
        ((MLB_CALL_FAIL++))
        _mlb_fallback "$method" "$params"
        return $?
    fi

    # JSON-RPCエラー応答チェック
    if echo "$result" | grep -q '"error"'; then
        local err_msg
        err_msg=$(echo "$result" | sed -n 's/.*"message":"\([^"]*\)".*/\1/p')
        _mlb_log "WARN" "MLサーバーエラー: ${err_msg:-unknown}"
        ((MLB_CALL_FAIL++))
        echo "$result"
        return 1
    fi

    # 成功
    ((MLB_CALL_OK++))

    # キャッシュ保存
    if [[ "$MLB_ENABLE_CACHE" == "true" ]]; then
        local cache_key="${method}:${params}"
        _MLB_CACHE[$cache_key]="$result"
        _MLB_CACHE_TS[$cache_key]=$(date +%s 2>/dev/null || echo 0)
    fi

    echo "$result"
    return 0
}

# ============================================================
# フォールバック (Python/ML非利用時のデフォルト値返却)
# ============================================================
_mlb_fallback() {
    local method="$1"
    local params="$2"

    case "$method" in
        predict_quality)
            echo '{"jsonrpc":"2.0","id":0,"result":{"score":75,"confidence":0.0,"source":"fallback","message":"ML unavailable - using default score"}}'
            ;;
        classify_error)
            echo '{"jsonrpc":"2.0","id":0,"result":{"category":"unknown","confidence":0.0,"source":"fallback","message":"ML unavailable - classification not performed"}}'
            ;;
        train_model)
            echo '{"jsonrpc":"2.0","id":0,"result":{"status":"skipped","source":"fallback","message":"ML unavailable - training skipped"}}'
            ;;
        get_metrics)
            echo '{"jsonrpc":"2.0","id":0,"result":{"metrics":{},"source":"fallback","message":"ML unavailable - no metrics"}}'
            ;;
        health_check)
            echo '{"jsonrpc":"2.0","id":0,"result":{"status":"degraded","python":false,"ml":false,"source":"fallback"}}'
            ;;
        *)
            echo '{"jsonrpc":"2.0","id":0,"result":{"source":"fallback","message":"ML unavailable - method not handled"}}'
            ;;
    esac
    return 0
}

# ============================================================
# ショートハンド関数
# ============================================================

# _ml_bridge_predict <domain> <features_json>
# 品質スコアを予測する
# 出力: JSON結果 (score, confidence, source)
_ml_bridge_predict() {
    local domain="${1:-general}"
    local features="$2"
    [[ -z "$features" ]] && features='{}'

    local params
    params=$(printf '{"domain":"%s","features":%s}' "$domain" "$features")

    _ml_bridge_call "predict_quality" "$params"
}

# _ml_bridge_train <model_type> <data_json>
# MLモデルを学習データで訓練する
# 出力: JSON結果 (status, metrics)
_ml_bridge_train() {
    local model_type="${1:-quality}"
    local data="$2"
    [[ -z "$data" ]] && data='{}'

    local params
    params=$(printf '{"model_type":"%s","data":%s}' "$model_type" "$data")

    _ml_bridge_call "train_model" "$params"
}

# _ml_bridge_classify <error_text> [context_json]
# エラーテキストを分類する
# 出力: JSON結果 (category, confidence, suggested_fix)
_ml_bridge_classify() {
    local error_text="${1:-}"
    local context="$2"
    [[ -z "$context" ]] && context='{}'

    # エラーテキストのJSONエスケープ
    local escaped_text
    escaped_text=$(printf '%s' "$error_text" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\t/\\t/g; s/\n/\\n/g')

    local params
    params=$(printf '{"error_text":"%s","context":%s}' "$escaped_text" "$context")

    _ml_bridge_call "classify_error" "$params"
}

# _ml_bridge_health
# MLブリッジのヘルスチェック
# 出力: JSON結果 (status, python, ml, server)
_ml_bridge_health() {
    _ml_bridge_call "health_check" '{}' 10
}

# ============================================================
# ユーティリティ
# ============================================================

# JSON結果からフィールドを抽出 (jq不要)
_mlb_extract() {
    local json="$1"
    local field="$2"
    echo "$json" | sed -n "s/.*\"${field}\":\s*\"\{0,1\}\([^,\"}\]*\)\"\{0,1\}.*/\1/p" | head -1
}

# 品質スコアのみ取得 (数値)
_ml_bridge_get_score() {
    local domain="${1:-general}"
    local features="$2"
    [[ -z "$features" ]] && features='{}'
    local result
    result=$(_ml_bridge_predict "$domain" "$features")
    local score
    score=$(_mlb_extract "$result" "score")
    echo "${score:-75}"
}

# ============================================================
# レポート
# ============================================================
_ml_bridge_report() {
    echo "=== ML Bridge Report ==="
    echo "  Version:        ${MLB_VERSION}"
    echo "  Python:         ${MLB_PYTHON_AVAILABLE} (${MLB_PYTHON_BIN:-none})"
    echo "  ML Packages:    ${MLB_ML_AVAILABLE}"
    echo "  Total Calls:    ${MLB_CALL_COUNT}"
    echo "  Success:        ${MLB_CALL_OK}"
    echo "  Failures:       ${MLB_CALL_FAIL}"
    echo "  Fallbacks:      ${MLB_FALLBACK_COUNT}"
    if [[ $MLB_CALL_COUNT -gt 0 ]]; then
        local success_rate=$(( (MLB_CALL_OK * 100) / MLB_CALL_COUNT ))
        echo "  Success Rate:   ${success_rate}%"
    fi
    echo "========================"
}

# スコア (Module Registry用)
_ml_bridge_score() {
    if [[ $MLB_CALL_COUNT -eq 0 ]]; then
        echo 100
        return
    fi
    local score=$(( (MLB_CALL_OK * 100) / MLB_CALL_COUNT ))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# ============================================================
# Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "ml-bridge" \
        --version "$MLB_VERSION" \
        --description "Bash-Python ML連携ブリッジ - 品質予測/エラー分類/モデル学習" \
        --init "_ml_bridge_init" \
        --report "_ml_bridge_report" \
        --score "_ml_bridge_score" \
        --enable-var "ENABLE_MLB" \
        --cli-flags "--ml-bridge:--no-ml-bridge"
fi

# v2003.1: source時のexit codeを確実に0にする
true
