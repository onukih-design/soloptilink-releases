#!/usr/bin/env bash
# SoloptiLinkAI v2003.1 - Core Development Phase Functions
# Prompt/Design/Scaffold/Implementation phases + Smart Generation Pipeline

# ============================================================
# v2003.1: Smart Generation 統合フェーズ
# DAGから呼ばれ、DB→型→BE→API→FEを段階的に生成する
# 各ステップ間でビルド検証+成果物注入により高品質を実現
# ============================================================
phase_smart_generation() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "smart_generation" 2>/dev/null || true

    echo -e "\n${BOLD:-}${CYAN:-}╔═══════════════════════════════════════════════════════════╗${NC:-}"
    echo -e "${BOLD:-}${CYAN:-}║  v2003.1: Smart Generation Pipeline（段階生成）            ║${NC:-}"
    echo -e "${BOLD:-}${CYAN:-}║  schema → 型定義 → Backend → API → Frontend              ║${NC:-}"
    echo -e "${BOLD:-}${CYAN:-}║  各ステップ間でビルド検証 + 成果物コンテキスト注入          ║${NC:-}"
    echo -e "${BOLD:-}${CYAN:-}╚═══════════════════════════════════════════════════════════╝${NC:-}\n"

    # プロジェクトタイプ自動検出
    local project_type="fullstack"
    if type -t sg_detect_project_type &>/dev/null; then
        project_type=$(sg_detect_project_type "$task_desc" 2>/dev/null || echo "fullstack")
    fi
    local domain="${DETECTED_DOMAIN:-general}"

    echo -e "  📋 プロジェクトタイプ: ${project_type}, ドメイン: ${domain}"

    # Enterprise Patterns をSG内の各ステップに注入できるよう環境変数で渡す
    export SG_ENTERPRISE_PATTERNS=""
    if type -t ep_inject_into_prompt &>/dev/null; then
        SG_ENTERPRISE_PATTERNS=$(ep_inject_into_prompt "backend" 2>/dev/null || echo "")
    fi

    # v2003.1: Generation Quality Integration - 品質パターン注入
    export SG_QUALITY_PATTERNS=""
    if type -t _gqi_run_pipeline &>/dev/null; then
        gqi_init 2>/dev/null || true
        SG_QUALITY_PATTERNS=$(_gqi_run_pipeline "$task_desc" "$(_detect_project_dir 2>/dev/null || echo ".")" 2>/dev/null || echo "")
        echo -e "  📐 [v2003.1] Generation Quality注入: ${#SG_QUALITY_PATTERNS}文字"
    fi

    # Cross-Session Learning注入
    export SG_CROSS_SESSION=""
    if type -t cs_predictive_inject &>/dev/null; then
        SG_CROSS_SESSION=$(cs_predictive_inject "${domain}" 2>/dev/null || echo "")
    fi

    # v2048: 可変開発層数 — Scale Planner が決めた規模層(業務サブシステム構成)を
    #   コンパクト要約にして生成プロンプトへ渡す(sg_build_step_prompt が SG_LAYER_PLAN を読む)。
    #   Scale Planner 未稼働(env 無し)なら空=従来挙動を1ミリも変えない(回帰ゼロ)。
    export SG_LAYER_PLAN=""
    if [[ -n "${SOLOPTILINK_LAYER_PLAN:-}" ]] && command -v python3 &>/dev/null; then
        SG_LAYER_PLAN="$(printf '%s' "$SOLOPTILINK_LAYER_PLAN" | python3 -c 'import sys,json
try:
    d=json.load(sys.stdin)
    names=" / ".join("SL%d:%s"%(l["sl"],l["name"]) for l in d.get("layers",[]))
    print("規模層=%d (%s・%s)。生成すべき業務サブシステム: %s"%(d["target_layers"],d["mode"],d["architecture"],names))
except Exception: pass' 2>/dev/null || echo "")"
        [[ -n "$SG_LAYER_PLAN" ]] && echo -e "  🧩 [可変層数] 規模層注入: ${SOLOPTILINK_TARGET_LAYERS:-?}層"
    fi

    # v2003.2: 設計契約情報をSmart Generationに環境変数で渡す（設計→実装トレーサビリティ）
    export SG_BLUEPRINT_CONTENT=""
    export SG_REQUIREMENTS_CONTENT=""
    if [[ -n "${BLUEPRINT_FILE:-}" && -f "$BLUEPRINT_FILE" ]]; then
        SG_BLUEPRINT_CONTENT="$(cat "$BLUEPRINT_FILE" 2>/dev/null | head -c 100000)"
        echo -e "  📋 [v2003.2] 設計書注入: ${#SG_BLUEPRINT_CONTENT}文字"
    fi
    if [[ -n "${REQUIREMENTS_FILE:-}" && -f "$REQUIREMENTS_FILE" ]]; then
        SG_REQUIREMENTS_CONTENT="$(cat "$REQUIREMENTS_FILE" 2>/dev/null | head -c 100000)"
        echo -e "  📋 [v2003.2] 要件書注入: ${#SG_REQUIREMENTS_CONTENT}文字"
    fi
    # SESSION_LOG_DIR内のblueprint/requirementsファイルもフォールバックで読み込み
    if [[ -z "$SG_BLUEPRINT_CONTENT" && -f "${SESSION_LOG_DIR:-/tmp}/blueprint_shared.md" ]]; then
        SG_BLUEPRINT_CONTENT="$(cat "${SESSION_LOG_DIR}/blueprint_shared.md" 2>/dev/null | head -c 100000)"
        echo -e "  📋 [v2003.2] 設計書フォールバック注入: ${#SG_BLUEPRINT_CONTENT}文字"
    fi
    if [[ -z "$SG_REQUIREMENTS_CONTENT" && -f "${SESSION_LOG_DIR:-/tmp}/requirements.md" ]]; then
        SG_REQUIREMENTS_CONTENT="$(cat "${SESSION_LOG_DIR}/requirements.md" 2>/dev/null | head -c 100000)"
        echo -e "  📋 [v2003.2] 要件書フォールバック注入: ${#SG_REQUIREMENTS_CONTENT}文字"
    fi

    # Smart Generation Pipeline 実行
    # v2048 可変開発層数: staged モードのとき群分割で段階生成する(HIGH-1/HIGH-2 根治=予算ガードを
    #   echo でなく実機構化)。ENABLE_SCALE_STAGED=auto(既定): ≥11層(staged-mandatory)のみ段階実行
    #   (≤10層は従来の一発生成=挙動不変)。on: staged-* を段階実行 / off: 常に一発(従来)。
    #   ssg_execute は内部で sg_execute_pipeline を群ごとに呼び、群別予算(全層合計÷群数)を env へ渡す。
    #   LAYER_PLAN 不在等は ssg_execute 側で一発生成へグレースフル・フォールバック。
    local sg_output=""
    local _ssg_lib="${SOLOPTILINK_HOME:-$HOME/.soloptilink}/lib/scale-staged-generator.sh"
    local _use_staged=0
    case "${ENABLE_SCALE_STAGED:-auto}" in
        off) _use_staged=0 ;;
        on)  [[ "${SOLOPTILINK_SCALE_MODE:-}" == staged-* ]] && _use_staged=1 ;;
        *)   [[ "${SOLOPTILINK_SCALE_MODE:-}" == "staged-mandatory" ]] && _use_staged=1 ;;
    esac
    if (( _use_staged == 1 )) && [[ -f "$_ssg_lib" ]]; then
        # shellcheck disable=SC1091
        source "$_ssg_lib" 2>/dev/null || true
        if type -t ssg_execute &>/dev/null; then
            echo -e "  🧩 [可変層数] 段階生成(群分割)で実行: ${SOLOPTILINK_TARGET_LAYERS:-?}層"
            sg_output=$(PROJECT_DIR="$(_detect_project_dir 2>/dev/null || echo "$PWD")" ssg_execute "$task_desc" "$project_type" "$domain")
        else
            sg_output=$(sg_execute_pipeline "$task_desc" "$project_type" "$domain")
        fi
    else
        sg_output=$(sg_execute_pipeline "$task_desc" "$project_type" "$domain")
    fi

    if [[ -n "$sg_output" ]]; then
        echo -e "  ${GREEN:-}✅ Smart Generation Pipeline 完了${NC:-}"

        # 出力をファイルに書き出し（sg_execute_pipeline内で各ステップ毎に書出し済みだが、
        # 漏れがあった場合のフォールバック）
        local output_file="${SESSION_LOG_DIR:-/tmp}/smart_generation_output.md"
        echo "$sg_output" > "$output_file"
        _write_claude_output_to_files "$output_file" 2>/dev/null || true

        type -t ctx_save &>/dev/null && ctx_save "smart_generation" "output_file" "$output_file"
        type -t ctx_save_phase_status &>/dev/null && ctx_save_phase_status "smart_generation" "completed"
    else
        echo -e "  ${RED:-}❌ Smart Generation Pipeline 失敗 → 従来フェーズにフォールバック${NC:-}"
        # フォールバック: 従来のphase_backend → phase_api → phase_frontend
        phase_backend "$session_id" "$task_desc"
        phase_api "$session_id" "$task_desc"
        phase_frontend "$session_id" "$task_desc"
    fi

    _post_phase_validate_and_heal "SG" 2>/dev/null || true

    # v2003.2: Spec Tracer早期実行 — 初回実装直後に全機能実装チェック
    # （従来はPhase 5.xでしか実行されず、初期実装の機能抜けを検出できなかった）
    if type -t st_extract_features &>/dev/null && [[ "${ENABLE_SPEC_TRACER:-true}" == "true" ]]; then
        echo -e "  📋 [v2003.2] 初回Spec Tracer: 設計→実装トレーサビリティ検証..."
        st_extract_features "$task_desc" 2>/dev/null || true
        local _project_dir
        _project_dir="$(_detect_project_dir 2>/dev/null || echo ".")"
        st_verify_features "$_project_dir" 2>/dev/null || true
        local _st_missing_early
        _st_missing_early=$(st_get_missing_features 2>/dev/null || echo "")
        if [[ -n "$_st_missing_early" ]]; then
            echo -e "  ⚠️ [v2003.2] 未実装機能を検出（初回チェック）:"
            echo "$_st_missing_early" | head -10
            local _st_fix_early
            _st_fix_early=$(st_generate_fix_prompt 2>/dev/null || echo "")
            if [[ -n "$_st_fix_early" ]]; then
                echo -e "  🔄 [v2003.2] 未実装機能の追加実装中..."
                _call_claude "$_st_fix_early" "" "spec_fix_early" 2>/dev/null || true
            fi
        else
            echo -e "  ✅ [v2003.2] 全設計機能が実装済み"
        fi
    fi

    _post_phase_checkpoint "smart_generation" 2>/dev/null || true
    return 0
}

# ---- Phase 3.5: AI統合レイヤー (v18.0) ----
phase_ai_integration() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "ai_integration" 2>/dev/null || true

    echo -e "\n${BOLD}${CYAN}╔═══════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${CYAN}║  Phase 3.5: AI統合レイヤー (v18.0)             ║${NC}"
    echo -e "${BOLD}${CYAN}╚═══════════════════════════════════════════════╝${NC}\n"

    if [[ "$ENABLE_AI" == "auto" ]]; then
        if [[ "$task_desc" =~ (AI[^a-z]|[^a-zA-Z]ai[^a-z]|LLM|llm|ChatGPT|chatgpt|Claude[^[:space:]]*API|GPT-[0-9]|gpt-[0-9]|RAG|rag|ベクトル|embedding|チャットボット|chatbot|AIチャット|AI搭載|AI分析) ]]; then
            ENABLE_AI="true"
        else
            echo -e "  ${YELLOW}⚠️ AI統合要件未検出 → スキップ${NC}"
            return 0
        fi
    fi
    [[ "$ENABLE_AI" != "true" ]] && return 0

    if ! type -t ai_init &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ AI Integration Layer 未ロード → スキップ${NC}"
        return 0
    fi

    ai_init "$session_id" 2>/dev/null || return 1

    # プロバイダー検出
    local providers="$LLM_PROVIDERS"
    if [[ -z "$providers" ]]; then
        providers=$(ai_detect_llm_providers "$task_desc" 2>/dev/null || echo "openai")
    fi
    [[ -z "$providers" ]] && providers="openai"
    echo -e "  ${GREEN}🔌 LLMプロバイダー: ${providers}${NC}"

    # コネクター生成
    local IFS=','
    for provider in $providers; do
        ai_generate_llm_connector "$provider" "nodejs" >/dev/null 2>&1 && \
            echo -e "  ${GREEN}✅ ${provider} コネクター生成${NC}"
        ai_generate_streaming_handler "$provider" >/dev/null 2>&1 && \
            echo -e "  ${GREEN}📡 ${provider} ストリーミング生成${NC}"
    done
    unset IFS

    # トークンバジェット
    ai_generate_token_budget_manager >/dev/null 2>&1 && \
        echo -e "  ${GREEN}📊 トークンバジェットマネージャー生成${NC}"

    # RAG
    if [[ "$ENABLE_RAG" == "true" ]]; then
        ai_generate_rag_pipeline "$VECTOR_DB" "openai" >/dev/null 2>&1 && \
            echo -e "  ${GREEN}🔍 RAGパイプライン生成 (${VECTOR_DB})${NC}"
        ai_generate_embedding_code "openai" >/dev/null 2>&1
        ai_generate_retrieval_code "$VECTOR_DB" >/dev/null 2>&1
        ai_generate_chunking_strategy >/dev/null 2>&1
    fi

    # AI分析（データスキーマがある場合）
    local schema=""
    if type -t ctx_recall &>/dev/null; then
        schema=$(ctx_recall "data_import" "inferred_schema" 2>/dev/null || echo "")
    fi
    # ctx_recallが使えない場合、グローバル変数からフォールバック
    [[ -z "$schema" || "$schema" == "{}" ]] && schema="${DIN_INFERRED_SCHEMA:-}"
    if [[ -n "$schema" && "$schema" != "{}" ]]; then
        ai_generate_analytics_from_schema "$schema" >/dev/null 2>&1 && \
            echo -e "  ${GREEN}📈 AI分析ダッシュボード生成${NC}"
        ai_generate_insight_engine "$schema" >/dev/null 2>&1 && \
            echo -e "  ${GREEN}💡 AIインサイトエンジン生成${NC}"
    fi

    ai_report 2>/dev/null || true
    _post_phase_checkpoint "ai_integration"
    return 0
}



# ---- Phase: API実装 ----
phase_api() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "api" 2>/dev/null || true

    echo -e "  ${CYAN}🔌 API実装フェーズ${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    local output_file="${SESSION_LOG_DIR}/api_implementation.md"

    local req_content=""
    [[ -n "${REQUIREMENTS_FILE:-}" && -f "$REQUIREMENTS_FILE" ]] && req_content="$(cat "$REQUIREMENTS_FILE")"
    local be_content=""
    [[ -f "${SESSION_LOG_DIR}/backend_implementation.md" ]] && be_content="$(cat "${SESSION_LOG_DIR}/backend_implementation.md")"

    # v27.0: ドメイン知識のAPIスペックがあれば注入
    local dk_api=""
    [[ -n "${DK_API_SPEC:-}" ]] && dk_api="$DK_API_SPEC"
    [[ -z "$dk_api" && -f "${SESSION_LOG_DIR}/domain_api_spec.md" ]] && dk_api="$(cat "${SESSION_LOG_DIR}/domain_api_spec.md" 2>/dev/null || echo "")"
    local dk_rules=""
    [[ -n "${DK_BUSINESS_RULES:-}" ]] && dk_rules="$DK_BUSINESS_RULES"
    [[ -z "$dk_rules" && -f "${SESSION_LOG_DIR}/domain_business_rules.md" ]] && dk_rules="$(cat "${SESSION_LOG_DIR}/domain_business_rules.md" 2>/dev/null || echo "")"

    local prompt=""
    if [[ -n "$dk_api" ]]; then
        echo -e "  ${GREEN}📐 v27.0: ドメイン知識ベースAPI仕様を使用${NC}"
        prompt="あなたはAPIデザインのエキスパートです。以下のドメイン知識ベースのAPI仕様に忠実に従ってREST APIを実装してください。

タスク: ${task_desc}

要件:
${req_content:-（なし）}

バックエンド実装:
${be_content:-（なし）}

=== ドメイン知識ベースAPI仕様（v27.0） ===
${dk_api}
=== API仕様ここまで ===

=== ビジネスルール（v27.0） ===
${dk_rules:-（なし）}
=== ビジネスルールここまで ===

重要:
- 上記API仕様のエンドポイントパス・HTTPメソッド・レスポンス形式を忠実に実装すること
- ビジネスルールを必ずバリデーションロジックに反映すること
- 入力バリデーションはzodスキーマで定義
- エラーハンドリングは統一レスポンス形式 {success, data, error}
- 全ファイルをプロジェクトルートに実際に書き出してください。"
    else
        prompt="あなたはAPIデザインのエキスパートです。以下の要件・バックエンド実装に基づいてREST APIを完成させてください。

タスク: ${task_desc}

要件:
${req_content:-（なし）}

バックエンド実装:
${be_content:-（なし）}

以下を実装してください:
1. 全エンドポイント（CRUD操作）
2. 入力バリデーション（zod/joi等）
3. エラーハンドリング（統一レスポンス形式）
4. 認証・認可（JWT/Session）
5. レート制限
6. ページネーション
7. OpenAPI/Swagger仕様書

全ファイルをプロジェクトルートに実際に書き出してください。"
    fi

    # v12.0: セキュリティ + 出力形式指示注入 (ドメイン知識なしの場合のみ)
    if [[ -z "$dk_api" ]]; then
        if type -t ctx_get_security_prompt &>/dev/null; then
            prompt="${prompt}$(ctx_get_security_prompt)"
        fi
        if type -t ctx_get_output_format &>/dev/null; then
            prompt="${prompt}$(ctx_get_output_format)"
        fi
    fi

    # v35.0+v143.0: Enterprise Patterns — API参照実装テンプレート注入（ログ強化）
    if [[ "${CLI_ENABLE_ENTERPRISE_PATTERNS:-true}" == "true" ]] && type -t ep_inject_into_prompt &>/dev/null; then
        local _ep_ref=""
        _ep_ref=$(ep_inject_into_prompt "backend" 2>/dev/null) || {
            echo -e "  ${YELLOW}⚠️ [v143] Enterprise Patterns注入失敗 (phase=api): ep_inject_into_prompt returned error${NC}" >&2
        }
        if [[ -n "$_ep_ref" ]]; then
            echo -e "  ${GREEN}🏗️ v143.0: Enterprise Patterns 参照実装をAPIプロンプトに注入 (${#_ep_ref}文字)${NC}"
            prompt="${prompt}

${_ep_ref}"
        else
            echo -e "  ${YELLOW}⚠️ [v143] Enterprise Patterns注入: 空の結果 (phase=api)${NC}" >&2
        fi
    fi

    # v142.0: Golden Patterns injection (API)
    if type -t gp_inject_for_phase &>/dev/null && [[ "${ENABLE_GOLDEN_PATTERNS:-true}" == "true" ]]; then
        local _gp_patterns=""
        _gp_patterns=$(gp_inject_for_phase "api" "${DETECTED_DOMAIN:-general}" 2>/dev/null || echo "")
        if [[ -n "$_gp_patterns" ]]; then
            echo -e "  ${GREEN}🌟 v142.0: Golden Patterns をAPIプロンプトに注入${NC}"
            prompt+="

=== [v142.0] Golden Patterns - 必須参照実装 ===
${_gp_patterns}
=== Golden Patterns END ===
"
        fi
    fi

    # v155: Cross-Session Learning - エラー予防注入
    if type -t cs_predictive_inject &>/dev/null && [[ "${ENABLE_CROSS_SESSION:-true}" == "true" ]]; then
        local _cs_prevention=""
        _cs_prevention=$(cs_predictive_inject "${DETECTED_DOMAIN:-general}" 2>/dev/null || echo "")
        if [[ -n "$_cs_prevention" && ${#_cs_prevention} -gt 20 ]]; then
            # v2003.1: Cross-Session を最大2000文字に制限
            [[ ${#_cs_prevention} -gt 2000 ]] && _cs_prevention="${_cs_prevention:0:2000}"
            prompt+="

=== [v155] エラー予防指示（過去セッション学習） ===
${_cs_prevention}
=== エラー予防指示 END ===
"
            echo -e "  🧠 [v155] Cross-Session学習注入: ${#_cs_prevention}文字" >&2
        fi
    fi

    if _call_claude "$prompt" "$output_file"; then
        echo -e "  ${GREEN}✅ API実装完了${NC}"
        _write_claude_output_to_files "$output_file"
        type -t ctx_save &>/dev/null && ctx_save "api" "output_file" "$output_file"
        type -t ctx_save_phase_status &>/dev/null && ctx_save_phase_status "api" "completed"

        # v144: Generate API contract after API routes are defined
        if type -t cg_generate_contract &>/dev/null; then
            local _v144_pdir
            _v144_pdir="$(_detect_project_dir 2>/dev/null || echo ".")"
            echo -e "  📋 [v144] APIルート定義からAPI契約を生成中..." >&2
            cg_generate_contract "$_v144_pdir" 2>/dev/null || true
        fi
    else
        echo -e "  ${RED}❌ API実装失敗${NC}"
    fi

    _post_phase_validate_and_heal "API"

    [[ "$NO_LEARN" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "API" "api-design" "API実装完了"

    _post_phase_checkpoint "api"
    return 0
}



# ---- Phase: バックエンド実装 ----
phase_backend() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "backend" 2>/dev/null || true

    echo -e "  ${CYAN}⚙️ バックエンド実装フェーズ${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    local output_file="${SESSION_LOG_DIR}/backend_implementation.md"

    # 要件＋DB設計＋設計書を読み込み
    # PFP-112: 要件全文の無上限読込にトークン上限を設定（既定30000バイト・SOLOPTILINK_REQ_CONTENT_MAX で上書き可）
    local _req_max="${SOLOPTILINK_REQ_CONTENT_MAX:-30000}"
    [[ "$_req_max" =~ ^[0-9]+$ ]] || _req_max=30000
    local req_content=""
    [[ -n "${REQUIREMENTS_FILE:-}" && -f "$REQUIREMENTS_FILE" ]] && req_content="$(head -c "$_req_max" "$REQUIREMENTS_FILE" 2>/dev/null)"
    # v2003.2: 要件ファイルフォールバック
    if [[ -z "$req_content" && -f "${SESSION_LOG_DIR}/requirements.md" ]]; then
        req_content="$(head -c "$_req_max" "${SESSION_LOG_DIR}/requirements.md" 2>/dev/null)"
    fi
    local db_content=""
    [[ -f "${SESSION_LOG_DIR}/database_schema.md" ]] && db_content="$(cat "${SESSION_LOG_DIR}/database_schema.md")"

    # v2003.2: 設計書（Blueprint）を読み込み — 設計→実装トレーサビリティの核心
    local blueprint_content=""
    if [[ -n "${BLUEPRINT_FILE:-}" && -f "$BLUEPRINT_FILE" ]]; then
        blueprint_content="$(cat "$BLUEPRINT_FILE" 2>/dev/null | head -c 50000)"
    elif [[ -f "${SESSION_LOG_DIR}/blueprint_shared.md" ]]; then
        blueprint_content="$(cat "${SESSION_LOG_DIR}/blueprint_shared.md" 2>/dev/null | head -c 50000)"
    elif [[ -f "${SESSION_LOG_DIR}/blueprint_backend.md" ]]; then
        blueprint_content="$(cat "${SESSION_LOG_DIR}/blueprint_backend.md" 2>/dev/null | head -c 50000)"
    fi
    [[ -n "$blueprint_content" ]] && echo -e "  📋 [v2003.2] 設計書をバックエンド実装プロンプトに注入: ${#blueprint_content}文字"

    # リアルタイム学習コンテキスト注入
    local learn_ctx=""
    if [[ "$NO_LEARN" != "1" ]] && type -t rt_generate_context &>/dev/null; then
        learn_ctx=$(rt_generate_context "BE" "$task_desc" 2>/dev/null || echo "")
        [[ -n "$learn_ctx" ]] && echo "$learn_ctx" > "${SESSION_LOG_DIR}/learn_ctx_be.md"
    fi

    # v27.0: コンパイル済みプロンプトがあれば使用（一発出し精度向上）
    local compiled_be="${PC_COMPILED_BACKEND:-}"
    [[ -z "$compiled_be" && -f "${SESSION_LOG_DIR}/compiled_prompt_backend.md" ]] && \
        compiled_be="$(cat "${SESSION_LOG_DIR}/compiled_prompt_backend.md" 2>/dev/null || echo "")"

    local prompt=""
    if [[ -n "$compiled_be" ]]; then
        echo -e "  ${GREEN}📐 v27.0: コンパイル済みプロンプト使用（Precision Prompt Engine）${NC}"
        prompt="$compiled_be"
    else
        prompt="あなたはシニアバックエンドエンジニアです。以下の要件・設計書・DB設計に基づいてバックエンドを実装してください。
【重要】設計書に記載された全ての機能を必ず実装してください。設計書にある機能をスキップすることは禁止です。

タスク: ${task_desc}

=== 設計書（Blueprint） ===
${blueprint_content:-(設計書なし)}

=== 要件定義書 ===
${req_content:-(要件未定義 → タスク説明から必要なAPI・データモデルを推定して実装)}

=== DB設計 ===
${db_content:-(DB設計未定義 → タスクに必要なテーブル・リレーションをPrismaスキーマとして設計から開始)}

=== 技術スタック（固定） ===
- フレームワーク: Next.js 15 App Router (API Routes: app/api/*)
- 言語: TypeScript (strict mode)
- ORM: Prisma (SQLite開発 → PostgreSQL本番)
- バリデーション: zod
- エラーハンドリング: try-catch + NextResponse.json({ error }, { status })

=== 実装必須項目 ===
1. prisma/schema.prisma — 全データモデル定義
2. app/api/[resource]/route.ts — 各リソースのCRUDエンドポイント
3. lib/services/[resource].ts — ビジネスロジック層（APIハンドラから分離）
4. lib/validations/[resource].ts — zodスキーマ定義
5. lib/prisma.ts — Prismaクライアントシングルトン
6. .env.example — DATABASE_URL等の環境変数テンプレート
7. 全async関数にtry-catch必須、スタックトレースはクライアントに露出禁止

全ファイルをプロジェクトルートに実際に書き出してください。"
    fi

    if [[ -n "$learn_ctx" ]]; then
        prompt="${prompt}

過去の学習コンテキスト:
${learn_ctx}"
    fi

    # v12.0: セキュリティプロンプト注入 (コンパイル済みにはすでに含まれているが、フォールバック時用)
    if [[ -z "$compiled_be" ]]; then
        if type -t ctx_get_security_prompt &>/dev/null; then
            prompt="${prompt}$(ctx_get_security_prompt)"
        fi
        if type -t ctx_get_output_format &>/dev/null; then
            prompt="${prompt}$(ctx_get_output_format)"
        fi
    fi

    # v35.0+v143.0: Enterprise Patterns — 参照実装テンプレート注入（ログ強化）
    if [[ "${CLI_ENABLE_ENTERPRISE_PATTERNS:-true}" == "true" ]] && type -t ep_inject_into_prompt &>/dev/null; then
        local _ep_ref=""
        _ep_ref=$(ep_inject_into_prompt "backend" 2>/dev/null) || {
            echo -e "  ${YELLOW}⚠️ [v143] Enterprise Patterns注入失敗 (phase=backend): ep_inject_into_prompt returned error${NC}" >&2
        }
        if [[ -n "$_ep_ref" ]]; then
            # v2003.1: プロンプト肥大化防止 - Enterprise Patterns を最大5000文字に制限
            local _ep_max=5000
            if [[ ${#_ep_ref} -gt $_ep_max ]]; then
                _ep_ref="${_ep_ref:0:$_ep_max}
... (${#_ep_ref}文字中${_ep_max}文字を注入。残りは省略)"
                echo -e "  ${GREEN}🏗️ v2003.1: Enterprise Patterns 参照実装注入 (${_ep_max}/${#_ep_ref}文字, 上限制限)${NC}"
            else
                echo -e "  ${GREEN}🏗️ v143.0: Enterprise Patterns 参照実装をプロンプトに注入 (${#_ep_ref}文字)${NC}"
            fi
            prompt="${prompt}

${_ep_ref}"
        else
            echo -e "  ${YELLOW}⚠️ [v143] Enterprise Patterns注入: 空の結果 (phase=backend)${NC}" >&2
        fi
        # アンチパターンも注入
        if type -t ep_get_anti_patterns &>/dev/null; then
            local _ep_anti=""
            _ep_anti=$(ep_get_anti_patterns 2>/dev/null || echo "")
            if [[ -n "$_ep_anti" ]]; then
                prompt="${prompt}

# 禁止パターン（厳守）
${_ep_anti}"
            fi
        fi
    fi

    # v142.0: Golden Patterns injection (Backend)
    if type -t gp_inject_for_phase &>/dev/null && [[ "${ENABLE_GOLDEN_PATTERNS:-true}" == "true" ]]; then
        local _gp_patterns=""
        _gp_patterns=$(gp_inject_for_phase "backend" "${DETECTED_DOMAIN:-general}" 2>/dev/null || echo "")
        if [[ -n "$_gp_patterns" ]]; then
            # v2003.1: Golden Patterns を最大3000文字に制限
            local _gp_max=3000
            if [[ ${#_gp_patterns} -gt $_gp_max ]]; then
                _gp_patterns="${_gp_patterns:0:$_gp_max}
... (上限到達: ${_gp_max}文字に制限)"
            fi
            echo -e "  ${GREEN}🌟 v142.0: Golden Patterns をバックエンドプロンプトに注入 (${#_gp_patterns}文字)${NC}"
            prompt+="

=== [v142.0] Golden Patterns - 必須参照実装 ===
${_gp_patterns}
=== Golden Patterns END ===
"
        fi
    fi

    # v182: Domain-specific reference injection
    if type -t dr_get_reference &>/dev/null && [[ "${ENABLE_DOMAIN_REFS:-true}" == "true" ]]; then
        local _dr_ref=""
        _dr_ref=$(dr_get_reference "${DETECTED_DOMAIN:-general}" "backend" 2>/dev/null || echo "")
        if [[ -n "$_dr_ref" && ${#_dr_ref} -gt 50 ]]; then
            # v2003.1: ドメイン参照を最大3000文字に制限
            local _dr_max=3000
            if [[ ${#_dr_ref} -gt $_dr_max ]]; then
                _dr_ref="${_dr_ref:0:$_dr_max}
... (上限到達: ${_dr_max}文字に制限)"
            fi
            prompt+="

=== [v182] ドメイン参照実装 ===
${_dr_ref}
=== ドメイン参照 END ===
"
            echo -e "  📚 [v182] ドメイン参照注入: ${DETECTED_DOMAIN:-general} (${#_dr_ref}文字)" >&2
        fi
    fi

    # v186-v190: Enterprise module pattern injection
    if type -t mo_get_recommendations &>/dev/null; then
        local _mo_recs
        _mo_recs=$(mo_get_recommendations 2>/dev/null || echo "")

        # v186: Auth flow injection
        if echo "$_mo_recs" | grep -q "auth-scaffold" && type -t as_inject_auth_patterns &>/dev/null; then
            local _auth_patterns
            _auth_patterns=$(as_inject_auth_patterns "$prompt" 2>/dev/null || echo "")
            [[ -n "$_auth_patterns" ]] && prompt+="$_auth_patterns"
        fi

        # v187: Multi-tenant injection
        if echo "$_mo_recs" | grep -q "multi-tenant" && type -t mt_inject_tenant_patterns &>/dev/null; then
            local _mt_patterns
            _mt_patterns=$(mt_inject_tenant_patterns "$prompt" 2>/dev/null || echo "")
            [[ -n "$_mt_patterns" ]] && prompt+="$_mt_patterns"
        fi

        # v188: Realtime injection
        if echo "$_mo_recs" | grep -q "realtime-sync" && type -t rs_inject_realtime_patterns &>/dev/null; then
            local _rs_patterns
            _rs_patterns=$(rs_inject_realtime_patterns "$prompt" 2>/dev/null || echo "")
            [[ -n "$_rs_patterns" ]] && prompt+="$_rs_patterns"
        fi

        # v189: Search injection
        if echo "$_mo_recs" | grep -q "search-engine" && type -t ses_inject_search_patterns &>/dev/null; then
            local _ses_patterns
            _ses_patterns=$(ses_inject_search_patterns "$prompt" 2>/dev/null || echo "")
            [[ -n "$_ses_patterns" ]] && prompt+="$_ses_patterns"
        fi

        # v190: File upload injection
        if echo "$_mo_recs" | grep -q "file-upload" && type -t fu_inject_upload_patterns &>/dev/null; then
            local _fu_patterns
            _fu_patterns=$(fu_inject_upload_patterns "$prompt" 2>/dev/null || echo "")
            [[ -n "$_fu_patterns" ]] && prompt+="$_fu_patterns"
        fi
    fi

    # v155: Cross-Session Learning - エラー予防注入
    if type -t cs_predictive_inject &>/dev/null && [[ "${ENABLE_CROSS_SESSION:-true}" == "true" ]]; then
        local _cs_prevention=""
        _cs_prevention=$(cs_predictive_inject "${DETECTED_DOMAIN:-general}" 2>/dev/null || echo "")
        if [[ -n "$_cs_prevention" && ${#_cs_prevention} -gt 20 ]]; then
            # v2003.1: Cross-Session を最大2000文字に制限
            [[ ${#_cs_prevention} -gt 2000 ]] && _cs_prevention="${_cs_prevention:0:2000}"
            prompt+="

=== [v155] エラー予防指示（過去セッション学習） ===
${_cs_prevention}
=== エラー予防指示 END ===
"
            echo -e "  🧠 [v155] Cross-Session学習注入: ${#_cs_prevention}文字" >&2
        fi
    fi

    if _call_claude "$prompt" "$output_file"; then
        echo -e "  ${GREEN}✅ バックエンド実装完了${NC}"
        _write_claude_output_to_files "$output_file"
        type -t ctx_save &>/dev/null && ctx_save "backend" "output_file" "$output_file"
        type -t ctx_save_phase_status &>/dev/null && ctx_save_phase_status "backend" "completed"
    else
        echo -e "  ${RED}❌ バックエンド実装失敗${NC}"
    fi

    _post_phase_validate_and_heal "BE"

    [[ "$NO_LEARN" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "BE" "backend" "バックエンド実装完了"

    _post_phase_checkpoint "backend"
    return 0
}



# ---- Phase 0.6: 戦略計画エンジン (SPE / 熟考) v2035.0 ----
# consultation/DBL/domain知識/Quality Genome を統合し、PLAN→批判(Pre-mortem+多視点)
# →改良ループで計画を練り、確定計画を ctx_save/mm_store_short で下流へ通電する。
phase_strategic_planning() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "strategic_planning" 2>/dev/null || true

    echo -e "\n${BOLD}${CYAN}╔═══════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${CYAN}║  Phase 0.6: 戦略計画エンジン (SPE)             ║${NC}"
    echo -e "${BOLD}${CYAN}║  事業推論 × 業種 × 学習 → 批判 → 改良 → 通電  ║${NC}"
    echo -e "${BOLD}${CYAN}╚═══════════════════════════════════════════════╝${NC}\n"
    echo -e "  経過時間: $(_elapsed_time)"

    if ! type -t spe_run &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ 戦略計画エンジン未ロード → スキップ${NC}"
        return 0
    fi

    # 高速モード(quick/hotfix)ではスキップ
    if [[ "${PIPELINE_MODE:-auto}" == "quick" || "${PIPELINE_MODE:-auto}" == "hotfix" ]]; then
        echo -e "  ${YELLOW}⚠️ Pipeline=${PIPELINE_MODE} → 戦略計画スキップ${NC}"
        return 0
    fi

    local domain="${SOLOPTILINK_DETECTED_DBL:-${DOMAIN_TYPE:-general}}"
    echo -e "  ${CYAN}🧠 戦略計画を熟考中 (ドメイン: ${domain})...${NC}"
    # stdout(確定計画本文)は ctx_save 済のため破棄、stderr(信頼度の推移ログ)は表示
    spe_run "$task_desc" "$domain" >/dev/null || echo -e "  ${YELLOW}⚠️ 戦略計画に問題（続行）${NC}"

    if [[ -n "${SPE_FINAL_PLAN:-}" ]]; then
        echo -e "  ${GREEN}✅ 戦略計画 確定 (信頼度 ${SPE_FINAL_CONFIDENCE:-n/a}) → 下流フェーズへ通電${NC}"
    fi

    [[ "${NO_LEARN:-0}" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "SPE" "strategic_planning" "戦略計画確定: ${task_desc:0:50}"

    _post_phase_checkpoint "strategic_planning"
    return 0
}



# ---- Phase: ブループリント生成 (v27.0) ----
phase_blueprint() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "blueprint" 2>/dev/null || true

    echo -e "\n${BOLD}${CYAN}╔═══════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${CYAN}║  Phase 0.7: ブループリント生成 (v27.0)         ║${NC}"
    echo -e "${BOLD}${CYAN}╚═══════════════════════════════════════════════╝${NC}\n"
    echo -e "  経過時間: $(_elapsed_time)"

    if ! type -t bg_init &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ Blueprint Generator モジュール未ロード → スキップ${NC}"
        return 0
    fi

    bg_init "$session_id" 2>/dev/null || {
        echo -e "  ${YELLOW}⚠️ Blueprint Generator 初期化失敗 → スキップ${NC}"
        return 0
    }

    # 要件定義書をコンテキストとして渡す
    local req_content=""
    [[ -n "${REQUIREMENTS_FILE:-}" && -f "$REQUIREMENTS_FILE" ]] && req_content="$(cat "$REQUIREMENTS_FILE" 2>/dev/null || echo "")"

    # ドメイン知識をコンテキストとして渡す
    local domain_ctx=""
    if [[ -n "${DK_PRISMA_SCHEMA:-}" ]]; then
        domain_ctx="
=== Prisma Schema ===
${DK_PRISMA_SCHEMA}

=== API Spec ===
${DK_API_SPEC:-}

=== Page Spec ===
${DK_PAGE_SPEC:-}

=== Business Rules ===
${DK_BUSINESS_RULES:-}"
    fi

    # ブループリント生成
    echo -e "  ${CYAN}📐 フルブループリント生成中...${NC}"
    bg_generate_full_blueprint "$task_desc" "${req_content}${domain_ctx}" 2>/dev/null || {
        echo -e "  ${YELLOW}⚠️ ブループリント生成一部失敗（続行）${NC}"
    }

    # 成果物をセッションログに保存
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        mkdir -p "${SESSION_LOG_DIR}" 2>/dev/null || true
        [[ -n "${BG_SHARED_BLUEPRINT:-}" ]] && echo "$BG_SHARED_BLUEPRINT" > "${SESSION_LOG_DIR}/blueprint_shared.md"
        [[ -n "${BG_BACKEND_BLUEPRINT:-}" ]] && echo "$BG_BACKEND_BLUEPRINT" > "${SESSION_LOG_DIR}/blueprint_backend.md"
        [[ -n "${BG_FRONTEND_BLUEPRINT:-}" ]] && echo "$BG_FRONTEND_BLUEPRINT" > "${SESSION_LOG_DIR}/blueprint_frontend.md"
        [[ -n "${BG_FILE_MANIFEST:-}" ]] && echo "$BG_FILE_MANIFEST" > "${SESSION_LOG_DIR}/blueprint_manifest.md"
    fi

    # コンテキストエンジンに注入
    if type -t ctx_save &>/dev/null; then
        ctx_save "blueprint" "shared" "${BG_SHARED_BLUEPRINT:-}" 2>/dev/null || true
        ctx_save "blueprint" "backend" "${BG_BACKEND_BLUEPRINT:-}" 2>/dev/null || true
        ctx_save "blueprint" "frontend" "${BG_FRONTEND_BLUEPRINT:-}" 2>/dev/null || true
        ctx_save "blueprint" "manifest" "${BG_FILE_MANIFEST:-}" 2>/dev/null || true
    fi

    echo -e "  ${GREEN}✅ ブループリント生成完了${NC}"
    _post_phase_checkpoint "blueprint"
    return 0
}



# ---- Phase: 競合・市場調査 ----
phase_competitive_research() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "competitive_research" 2>/dev/null || true

    echo -e "  ${CYAN}🔍 競合・市場調査フェーズ${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    local output_file="${SESSION_LOG_DIR}/competitive_research.md"

    local prompt="あなたは市場調査アナリストです。以下のタスクに関連する競合・市場調査レポートを作成してください。

タスク: ${task_desc}

以下を含めてください:
1. 既存の類似サービス・ツール一覧
2. 各サービスの特徴・差別化ポイント
3. 市場トレンド
4. ベストプラクティス
5. 推奨する差別化戦略

日本語で記述。"

    if _call_claude "$prompt" "$output_file"; then
        echo -e "  ${GREEN}✅ 競合調査レポート生成完了${NC}"
    else
        echo -e "  ${YELLOW}⚠️ 競合調査レポート生成失敗（続行）${NC}"
    fi

    [[ "$NO_LEARN" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "COMP" "research" "競合調査実施"

    _post_phase_checkpoint "competitive_research"
    return 0
}



# ============================================================
# フェーズ実装 - v9.0/v10.0 新フェーズ
# ============================================================

# ---- Phase 0.1: コンサルタント対話 (v28.0) ----
# Web調査 × 目的深掘り × プロ提案 × 対話承認
phase_consultation() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "consultation" 2>/dev/null || true

    echo -e "\n${BOLD}${CYAN}╔═══════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${CYAN}║  Phase 0.1: Consultant Engine (v28.0)          ║${NC}"
    echo -e "${BOLD}${CYAN}║  Web調査 × 目的深掘り × プロ提案 × 対話承認  ║${NC}"
    echo -e "${BOLD}${CYAN}╚═══════════════════════════════════════════════╝${NC}\n"

    if ! type -t consultant_run &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ Consultant Engineモジュール未ロード → スキップ${NC}"
        return 0
    fi

    # 高速モード(quick pipeline)やFollow-upではスキップ
    if [[ "${PIPELINE_MODE:-auto}" == "quick" || "${PIPELINE_MODE:-auto}" == "hotfix" ]]; then
        echo -e "  ${YELLOW}⚠️ Pipeline=${PIPELINE_MODE} → コンサルテーションスキップ${NC}"
        return 0
    fi

    local consult_dir="${SESSION_LOG_DIR}/consultation"
    mkdir -p "$consult_dir" 2>/dev/null || true

    # 初期化
    consultant_engine_init 2>/dev/null || true

    # コンサルテーション実行
    consultant_run "$task_desc" "$consult_dir" 2>/dev/null || echo -e "  ${YELLOW}⚠️ コンサルテーション処理に問題（続行）${NC}"

    # 結果があればログ + 下流へ通電(v2035.0: 従来は表示のみで断絶していた経路を接続)
    if [[ -n "${CE_CONSULTATION_RESULT:-}" ]]; then
        echo -e "  ${GREEN}✅ コンサルテーション完了: 承認=${CE_USER_APPROVED:-unknown}${NC}"
        if type -t ctx_save &>/dev/null && type -t ce_get_consultation_context &>/dev/null; then
            ctx_save "consultation" "context" "$(ce_get_consultation_context 2>/dev/null || true)" 2>/dev/null || true
        fi
    fi

    [[ "$NO_LEARN" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "CE" "consultation" "コンサルテーション完了: ${task_desc:0:50}"

    _post_phase_checkpoint "consultation"
    return 0
}



# ---- Phase 0.3: データインポート & スキーマ推論 (v18.0) ----
phase_data_import() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "data_import" 2>/dev/null || true

    echo -e "\n${BOLD}${CYAN}╔═══════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${CYAN}║  Phase 0.3: データインポート (v18.0)           ║${NC}"
    echo -e "${BOLD}${CYAN}╚═══════════════════════════════════════════════╝${NC}\n"

    # Auto-detect: Excel/CSVキーワードまたはファイル指定がある場合のみ
    if [[ "$ENABLE_DATA_IMPORT" == "auto" ]]; then
        if [[ "$task_desc" =~ (Excel|CSV|エクセル|データ|import|インポート|xlsx|csv) ]] || \
           [[ -n "$DATA_IMPORT_FILE" ]]; then
            ENABLE_DATA_IMPORT="true"
        else
            echo -e "  ${YELLOW}⚠️ データインポート要件未検出 → スキップ${NC}"
            return 0
        fi
    fi
    [[ "$ENABLE_DATA_IMPORT" != "true" ]] && return 0

    if ! type -t din_init &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ Data Intelligence Engine 未ロード → スキップ${NC}"
        return 0
    fi

    din_init "$session_id" 2>/dev/null || return 1

    # ファイル指定がある場合はそれを使用
    if [[ -n "$DATA_IMPORT_FILE" && -f "$DATA_IMPORT_FILE" ]]; then
        echo -e "  ${CYAN}📁 指定ファイル: ${DATA_IMPORT_FILE}${NC}"
        local schema_json
        schema_json=$(din_analyze_file "$DATA_IMPORT_FILE" 2>/dev/null || echo "{}")
        if [[ "$schema_json" != "{}" ]]; then
            local inferred
            inferred=$(din_infer_schema "$schema_json" 2>/dev/null || echo "{}")
            if [[ "$inferred" != "{}" ]]; then
                DIN_INFERRED_SCHEMA="$inferred"
                local db_schema
                db_schema=$(din_generate_db_schema "$inferred" "prisma" 2>/dev/null || echo "")
                if [[ -n "$db_schema" ]]; then
                    mkdir -p "${SESSION_LOG_DIR}" 2>/dev/null || true
                    echo "$db_schema" > "${SESSION_LOG_DIR}/inferred_schema.prisma"
                    echo -e "  ${GREEN}✅ DBスキーマ生成完了${NC}"
                fi
                type -t ctx_save &>/dev/null && ctx_save "data_import" "inferred_schema" "$inferred" 2>/dev/null || true
            fi
        fi
    else
        # プロジェクトディレクトリをスキャン
        local data_files
        data_files=$(din_detect_data_files "." 2>/dev/null || echo "")
        if [[ -n "$data_files" ]]; then
            local first_file
            first_file=$(echo "$data_files" | head -1)
            echo -e "  ${CYAN}📁 検出: ${first_file}${NC}"
            local schema_json
            schema_json=$(din_analyze_file "$first_file" 2>/dev/null || echo "{}")
            if [[ "$schema_json" != "{}" ]]; then
                local inferred
                inferred=$(din_infer_schema "$schema_json" 2>/dev/null || echo "{}")
                DIN_INFERRED_SCHEMA="$inferred"
                type -t ctx_save &>/dev/null && ctx_save "data_import" "inferred_schema" "$inferred" 2>/dev/null || true
            fi
        fi
    fi

    din_report 2>/dev/null || true
    _post_phase_checkpoint "data_import"
    return 0
}



# ---- Phase: DB設計・実装 ----
phase_database() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "database" 2>/dev/null || true

    echo -e "  ${CYAN}🗄️ DB設計・実装フェーズ${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    local output_file="${SESSION_LOG_DIR}/database_schema.md"

    # 要件定義書を読み込んでコンテキストに
    local req_content=""
    if [[ -n "${REQUIREMENTS_FILE:-}" && -f "$REQUIREMENTS_FILE" ]]; then
        req_content="$(cat "$REQUIREMENTS_FILE")"
    fi

    # v27.0: ドメイン知識のPrismaスキーマがあればそれを基にDB設計
    local dk_schema=""
    [[ -n "${DK_PRISMA_SCHEMA:-}" ]] && dk_schema="$DK_PRISMA_SCHEMA"
    [[ -z "$dk_schema" && -f "${SESSION_LOG_DIR}/domain_prisma_schema.prisma" ]] && dk_schema="$(cat "${SESSION_LOG_DIR}/domain_prisma_schema.prisma" 2>/dev/null || echo "")"

    local prompt=""
    if [[ -n "$dk_schema" ]]; then
        prompt="あなたはデータベースアーキテクトです。以下のPrismaスキーマをベースにDB設計を完成させてください。
スキーマは業界標準のドメインモデルから自動生成されたものです。これを忠実に使用し、不足があれば追加してください。

タスク: ${task_desc}

要件定義書:
${req_content:-要件定義書なし - タスク説明から推定してください}

=== ドメイン知識ベースPrismaスキーマ（v27.0） ===
${dk_schema}
=== スキーマここまで ===

以下を作成してください:
1. 上記Prismaスキーマを prisma/schema.prisma に書き出し
2. シードデータ (prisma/seed.ts)
3. Prisma Client初期化 (src/lib/prisma.ts)

重要: 上記スキーマのモデル名・フィールド名・リレーションを変更しないこと。
全ファイルをプロジェクトルートに実際に書き出してください。"
    else
        prompt="あなたはデータベースアーキテクトです。以下の要件に基づいてデータベース設計を行い、マイグレーションファイルを作成してください。

タスク: ${task_desc}

要件定義書:
${req_content:-要件定義書なし - タスク説明から推定してください}

以下を作成してください:
1. ER図（テキスト記法）
2. CREATE TABLE文（PostgreSQL互換）
3. インデックス定義
4. シードデータ
5. マイグレーションファイル

テーブルには適切なPK/FK/制約/コメントを付与。
全ファイルをプロジェクトルートに実際に書き出してください。"
    fi

    if _call_claude "$prompt" "$output_file"; then
        echo -e "  ${GREEN}✅ DB設計完了: ${output_file}${NC}"
        _write_claude_output_to_files "$output_file"
        # v12.0: コンテキスト保存
        type -t ctx_save &>/dev/null && ctx_save "database" "output_file" "$output_file"
        type -t ctx_save_phase_status &>/dev/null && ctx_save_phase_status "database" "completed"
    else
        echo -e "  ${RED}❌ DB設計失敗${NC}"
    fi

    # フェーズ後バリデーション
    _post_phase_validate_and_heal "DB"

    [[ "$NO_LEARN" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "DB" "database" "DB設計完了"

    _post_phase_checkpoint "database"
    return 0
}



# ---- Phase: ドメイン知識注入 (v27.0) ----
phase_domain_knowledge() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "domain_knowledge" 2>/dev/null || true

    echo -e "\n${BOLD}${CYAN}╔═══════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${CYAN}║  Phase 0.6: ドメイン知識注入 (v27.0)           ║${NC}"
    echo -e "${BOLD}${CYAN}╚═══════════════════════════════════════════════╝${NC}\n"
    echo -e "  経過時間: $(_elapsed_time)"

    if ! type -t dk_init &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ Domain Knowledge モジュール未ロード → スキップ${NC}"
        return 0
    fi

    # ドメイン知識ディレクトリ検出
    local domains_dir=""
    local script_dir
    script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    for candidate in "${script_dir}/domains" "$(dirname "$script_dir")/domains" "${LIB_DIR:-}/../../domains"; do
        if [[ -d "$candidate" ]]; then
            domains_dir="$(cd "$candidate" && pwd)"
            break
        fi
    done

    if [[ -z "$domains_dir" ]]; then
        echo -e "  ${YELLOW}⚠️ domains/ ディレクトリ未検出 → スキップ${NC}"
        return 0
    fi

    dk_init "$domains_dir" 2>/dev/null || {
        echo -e "  ${YELLOW}⚠️ Domain Knowledge 初期化失敗 → スキップ${NC}"
        return 0
    }

    # ドメイン自動検出
    local detected_domain
    detected_domain=$(dk_detect_domain "$task_desc" 2>/dev/null || echo "")
    if [[ -n "$detected_domain" ]]; then
        echo -e "  ${GREEN}🎯 ドメイン検出: ${BOLD}${detected_domain}${NC}"
    else
        echo -e "  ${YELLOW}⚠️ ドメイン自動検出失敗 → 汎用モードで続行${NC}"
        return 0
    fi

    # フル知識生成
    dk_generate_full_knowledge "$task_desc" 2>/dev/null || {
        echo -e "  ${YELLOW}⚠️ ドメイン知識生成一部失敗（続行）${NC}"
    }

    # 成果物をセッションログに保存
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        mkdir -p "${SESSION_LOG_DIR}" 2>/dev/null || true
        [[ -n "${DK_PRISMA_SCHEMA:-}" ]] && echo "$DK_PRISMA_SCHEMA" > "${SESSION_LOG_DIR}/domain_prisma_schema.prisma"
        [[ -n "${DK_API_SPEC:-}" ]] && echo "$DK_API_SPEC" > "${SESSION_LOG_DIR}/domain_api_spec.md"
        [[ -n "${DK_PAGE_SPEC:-}" ]] && echo "$DK_PAGE_SPEC" > "${SESSION_LOG_DIR}/domain_page_spec.md"
        [[ -n "${DK_BUSINESS_RULES:-}" ]] && echo "$DK_BUSINESS_RULES" > "${SESSION_LOG_DIR}/domain_business_rules.md"
        [[ -n "${DK_SEED_DATA:-}" ]] && echo "$DK_SEED_DATA" > "${SESSION_LOG_DIR}/domain_seed_data.ts"
    fi

    # コンテキストエンジンに注入
    if type -t ctx_save &>/dev/null; then
        ctx_save "domain_knowledge" "domain" "${DK_DETECTED_DOMAIN:-}" 2>/dev/null || true
        ctx_save "domain_knowledge" "prisma_schema" "${DK_PRISMA_SCHEMA:-}" 2>/dev/null || true
        ctx_save "domain_knowledge" "api_spec" "${DK_API_SPEC:-}" 2>/dev/null || true
        ctx_save "domain_knowledge" "page_spec" "${DK_PAGE_SPEC:-}" 2>/dev/null || true
    fi

    echo -e "  ${GREEN}✅ ドメイン知識注入完了（${DK_DETECTED_DOMAIN:-unknown}）${NC}"
    _post_phase_checkpoint "domain_knowledge"
    return 0
}


# ---- Phase: E2Eパイプラインテスト (v17.0) ----
phase_e2e_test() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "e2e_test" 2>/dev/null || true

    if [[ "${ENABLE_E2E:-true}" != "true" ]]; then
        echo -e "  ${YELLOW}⚠️ E2Eテスト無効（--no-e2e）${NC}"
        return 0
    fi

    echo -e "  ${CYAN}🔄 E2Eパイプラインテストフェーズ (v17.0)${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    if ! type -t e2e_run_all &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ e2e-pipeline.sh 未ロード → スキップ${NC}"
        return 0
    fi

    local project_dir
    project_dir="$(_detect_project_dir)"

    # E2E初期化
    e2e_init "$project_dir" 2>/dev/null || true

    # E2Eテスト実行
    echo -e "  ${BOLD}[E2E] E2Eテストシナリオ実行中...${NC}"
    local e2e_exit=0
    e2e_run_all "$project_dir" "$task_desc" 2>/dev/null || e2e_exit=$?

    # 結果サマリー
    local e2e_total=$((${E2E_SCENARIOS_PASSED:-0} + ${E2E_SCENARIOS_FAILED:-0} + ${E2E_SCENARIOS_SKIPPED:-0}))
    echo -e "  ${BOLD}E2E結果: 合格=${E2E_SCENARIOS_PASSED:-0} 失敗=${E2E_SCENARIOS_FAILED:-0} スキップ=${E2E_SCENARIOS_SKIPPED:-0} 合計=${e2e_total}${NC}"

    if [[ "${E2E_SCENARIOS_FAILED:-0}" -gt 0 ]]; then
        echo -e "  ${RED}❌ E2Eテスト失敗あり${NC}"
    else
        echo -e "  ${GREEN}✅ E2Eテスト全パス${NC}"
    fi

    # Observatory イベント
    if type -t obs_emit_event &>/dev/null; then
        obs_emit_event "E2E_TEST" "{\"passed\":${E2E_SCENARIOS_PASSED:-0},\"failed\":${E2E_SCENARIOS_FAILED:-0},\"skipped\":${E2E_SCENARIOS_SKIPPED:-0}}" 2>/dev/null || true
    fi

    [[ "$NO_LEARN" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "E2E" "e2e-test" "E2Eテスト完了: pass=${E2E_SCENARIOS_PASSED:-0} fail=${E2E_SCENARIOS_FAILED:-0}" 2>/dev/null || true

    _post_phase_checkpoint "e2e_test"
    return $e2e_exit
}



# ---- Phase: フロントエンド実装 ----
phase_frontend() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "frontend" 2>/dev/null || true

    echo -e "  ${CYAN}🎨 フロントエンド実装フェーズ${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    local output_file="${SESSION_LOG_DIR}/frontend_implementation.md"

    local req_content=""
    [[ -n "${REQUIREMENTS_FILE:-}" && -f "$REQUIREMENTS_FILE" ]] && req_content="$(cat "$REQUIREMENTS_FILE")"
    # v2003.2: 要件ファイルフォールバック
    if [[ -z "$req_content" && -f "${SESSION_LOG_DIR}/requirements.md" ]]; then
        req_content="$(cat "${SESSION_LOG_DIR}/requirements.md" 2>/dev/null)"
    fi
    local api_content=""
    [[ -f "${SESSION_LOG_DIR}/api_implementation.md" ]] && api_content="$(cat "${SESSION_LOG_DIR}/api_implementation.md")"

    # v2003.2: 設計書（Blueprint）を読み込み — 設計→実装トレーサビリティの核心
    local blueprint_content=""
    if [[ -n "${BLUEPRINT_FILE:-}" && -f "$BLUEPRINT_FILE" ]]; then
        blueprint_content="$(cat "$BLUEPRINT_FILE" 2>/dev/null | head -c 50000)"
    elif [[ -f "${SESSION_LOG_DIR}/blueprint_shared.md" ]]; then
        blueprint_content="$(cat "${SESSION_LOG_DIR}/blueprint_shared.md" 2>/dev/null | head -c 50000)"
    elif [[ -f "${SESSION_LOG_DIR}/blueprint_frontend.md" ]]; then
        blueprint_content="$(cat "${SESSION_LOG_DIR}/blueprint_frontend.md" 2>/dev/null | head -c 50000)"
    fi
    [[ -n "$blueprint_content" ]] && echo -e "  📋 [v2003.2] 設計書をフロントエンド実装プロンプトに注入: ${#blueprint_content}文字"

    # スペックディレクトリからのコンテキスト
    local spec_content=""
    if [[ -n "${SPEC_DIR:-}" && -d "$SPEC_DIR" ]]; then
        for spec_file in "${SPEC_DIR}"/*.md; do
            [[ -f "$spec_file" ]] && spec_content+="$(cat "$spec_file")"$'\n\n'
        done
    fi

    # リアルタイム学習コンテキスト
    local learn_ctx=""
    if [[ "$NO_LEARN" != "1" ]] && type -t rt_generate_context &>/dev/null; then
        learn_ctx=$(rt_generate_context "FE" "$task_desc" 2>/dev/null || echo "")
        [[ -n "$learn_ctx" ]] && echo "$learn_ctx" > "${SESSION_LOG_DIR}/learn_ctx_fe.md"
    fi

    # v27.0: コンパイル済みプロンプトがあれば使用（一発出し精度向上）
    local compiled_fe="${PC_COMPILED_FRONTEND:-}"
    [[ -z "$compiled_fe" && -f "${SESSION_LOG_DIR}/compiled_prompt_frontend.md" ]] && \
        compiled_fe="$(cat "${SESSION_LOG_DIR}/compiled_prompt_frontend.md" 2>/dev/null || echo "")"

    # v144: API Contract injection - フロントエンド実装前にAPI契約を注入
    local _contract_content=""
    local _v144_fe_pdir
    _v144_fe_pdir="$(_detect_project_dir 2>/dev/null || echo ".")"
    local _contract_path="${_v144_fe_pdir}/.soloptilink/api-contract.json"
    if [[ ! -f "$_contract_path" ]] && type -t cg_generate_contract &>/dev/null; then
        echo -e "  📋 [v144] API契約を生成中..." >&2
        cg_generate_contract "$_v144_fe_pdir" 2>/dev/null || true
    fi
    if [[ -f "$_contract_path" ]]; then
        _contract_content=$(cat "$_contract_path" 2>/dev/null | head -200)
    fi

    local prompt=""
    if [[ -n "$compiled_fe" ]]; then
        echo -e "  ${GREEN}📐 v27.0: コンパイル済みプロンプト使用（Precision Prompt Engine）${NC}"
        prompt="$compiled_fe"
    else
        # v55.1: API仕様がない場合、バックエンドの実装から自動取得を試みる
        if [[ -z "$api_content" || "$api_content" == "（なし）" ]]; then
            local _be_output="${SESSION_LOG_DIR}/backend.md"
            if [[ -f "$_be_output" ]]; then
                api_content="$(grep -A 5 'route\|endpoint\|api/' "$_be_output" 2>/dev/null | head -100 || echo "")"
                [[ -n "$api_content" ]] && echo -e "  ${GREEN}📡 v55.1: バックエンド実装からAPI仕様を自動抽出${NC}"
            fi
            # Prismaスキーマからも取得
            local _prisma_dir
            _prisma_dir="$(_detect_project_dir 2>/dev/null || echo ".")"
            if [[ -f "${_prisma_dir}/prisma/schema.prisma" ]]; then
                api_content="${api_content}

--- 実装済みPrismaスキーマ（このモデルに対応するCRUD画面を作ること） ---
$(cat "${_prisma_dir}/prisma/schema.prisma" 2>/dev/null)"
            fi
        fi

        prompt="あなたはシニアフロントエンドエンジニアです。以下の要件・設計書・API仕様に基づいてフロントエンドを実装してください。
【重要】設計書に記載された全ての画面・機能を必ず実装してください。設計書にある機能をスキップすることは禁止です。

タスク: ${task_desc}

=== 設計書（Blueprint） ===
${blueprint_content:-(設計書なし)}

=== 要件 ===
${req_content:-(要件未定義 → タスク説明から必要な画面・コンポーネントを推定)}

=== API仕様（バックエンド実装済み） ===
${api_content:-(API仕様未定義 → /api/[resource] パターンでCRUDエンドポイントを想定して実装)}

=== 技術仕様 ===
${spec_content:-}

=== 技術スタック（固定） ===
- フレームワーク: Next.js 15 App Router
- 言語: TypeScript (strict mode)
- スタイル: Tailwind CSS + shadcn/ui
- データフェッチ: useSWR または fetch + useEffect
- フォーム: React Hook Form + zod
- 状態管理: React Context（グローバル状態が必要な場合のみ）

=== 実装必須項目 ===
1. app/[resource]/page.tsx — 一覧画面（テーブル + 検索 + ページネーション）
2. app/[resource]/[id]/page.tsx — 詳細画面
3. components/[resource]/ — CRUD用コンポーネント（Form, Table, Dialog）
4. lib/api/[resource].ts — API呼び出し関数（型安全、エラーハンドリング付き）
5. 全フォームにzodバリデーション必須
6. 削除時は確認ダイアログ必須
7. ローディング状態・エラー状態の表示必須
8. レスポンシブ対応（モバイル/タブレット/デスクトップ）

全ファイルをプロジェクトルートに実際に書き出してください。"
    fi

    if [[ -n "$learn_ctx" ]]; then
        prompt="${prompt}

過去の学習コンテキスト:
${learn_ctx}"
    fi

    # v12.0: セキュリティ + 出力形式指示注入 (コンパイル済みにはすでに含まれている)
    if [[ -z "$compiled_fe" ]]; then
        if type -t ctx_get_security_prompt &>/dev/null; then
            prompt="${prompt}$(ctx_get_security_prompt)"
        fi
        if type -t ctx_get_output_format &>/dev/null; then
            prompt="${prompt}$(ctx_get_output_format)"
        fi
    fi

    # v35.0+v143.0: Enterprise Patterns — フロントエンド参照実装テンプレート注入（ログ強化）
    if [[ "${CLI_ENABLE_ENTERPRISE_PATTERNS:-true}" == "true" ]] && type -t ep_inject_into_prompt &>/dev/null; then
        local _ep_ref=""
        _ep_ref=$(ep_inject_into_prompt "frontend" 2>/dev/null) || {
            echo -e "  ${YELLOW}⚠️ [v143] Enterprise Patterns注入失敗 (phase=frontend): ep_inject_into_prompt returned error${NC}" >&2
        }
        if [[ -n "$_ep_ref" ]]; then
            echo -e "  ${GREEN}🏗️ v143.0: Enterprise Patterns 参照実装をFEプロンプトに注入 (${#_ep_ref}文字)${NC}"
            prompt="${prompt}

${_ep_ref}"
        else
            echo -e "  ${YELLOW}⚠️ [v143] Enterprise Patterns注入: 空の結果 (phase=frontend)${NC}" >&2
        fi
    fi

    # v144: API Contract注入 - フロントエンドはこのAPI定義に厳密に従う
    if [[ -n "$_contract_content" ]]; then
        echo -e "  ${GREEN}📋 [v144] API Contract注入 ($(echo "$_contract_content" | wc -l | tr -d ' ')行)${NC}"
        prompt+="

=== [v144.0] API Contract - フロントエンドはこのAPI定義に厳密に従うこと ===
${_contract_content}
=== API Contract END ===
"
    fi

    # v142.0: Golden Patterns injection (Frontend)
    if type -t gp_inject_for_phase &>/dev/null && [[ "${ENABLE_GOLDEN_PATTERNS:-true}" == "true" ]]; then
        local _gp_patterns=""
        _gp_patterns=$(gp_inject_for_phase "frontend" "${DETECTED_DOMAIN:-general}" 2>/dev/null || echo "")
        if [[ -n "$_gp_patterns" ]]; then
            echo -e "  ${GREEN}🌟 v142.0: Golden Patterns をフロントエンドプロンプトに注入${NC}"
            prompt+="

=== [v142.0] Golden Patterns - 必須参照実装 ===
${_gp_patterns}
=== Golden Patterns END ===
"
        fi
    fi

    # v142.0: UI Interaction Engine patterns
    if type -t uie_inject_interaction_patterns &>/dev/null && [[ "${ENABLE_UIE:-true}" == "true" ]]; then
        local _uie_patterns=""
        _uie_patterns=$(uie_inject_interaction_patterns "$prompt" "${DETECTED_DOMAIN:-general}" 2>/dev/null || echo "")
        if [[ -n "$_uie_patterns" ]]; then
            echo -e "  ${GREEN}🎯 v142.0: UI Interaction Patterns をフロントエンドプロンプトに注入${NC}"
            prompt+="

=== [v142.0] UI Interaction Patterns - 全インタラクション要素必須 ===
${_uie_patterns}
=== UI Interaction Patterns END ===
"
        fi
    fi

    # v182: Domain-specific reference injection
    if type -t dr_get_reference &>/dev/null && [[ "${ENABLE_DOMAIN_REFS:-true}" == "true" ]]; then
        local _dr_ref=""
        _dr_ref=$(dr_get_reference "${DETECTED_DOMAIN:-general}" "frontend" 2>/dev/null || echo "")
        if [[ -n "$_dr_ref" && ${#_dr_ref} -gt 50 ]]; then
            prompt+="

=== [v182] ドメイン参照実装 ===
${_dr_ref}
=== ドメイン参照 END ===
"
            echo -e "  📚 [v182] ドメイン参照注入: ${DETECTED_DOMAIN:-general} (${#_dr_ref}文字)" >&2
        fi
    fi

    # v186-v190: Enterprise module pattern injection
    if type -t mo_get_recommendations &>/dev/null; then
        local _mo_recs
        _mo_recs=$(mo_get_recommendations 2>/dev/null || echo "")

        # v186: Auth flow injection
        if echo "$_mo_recs" | grep -q "auth-scaffold" && type -t as_inject_auth_patterns &>/dev/null; then
            local _auth_patterns
            _auth_patterns=$(as_inject_auth_patterns "$prompt" 2>/dev/null || echo "")
            [[ -n "$_auth_patterns" ]] && prompt+="$_auth_patterns"
        fi

        # v187: Multi-tenant injection
        if echo "$_mo_recs" | grep -q "multi-tenant" && type -t mt_inject_tenant_patterns &>/dev/null; then
            local _mt_patterns
            _mt_patterns=$(mt_inject_tenant_patterns "$prompt" 2>/dev/null || echo "")
            [[ -n "$_mt_patterns" ]] && prompt+="$_mt_patterns"
        fi

        # v188: Realtime injection
        if echo "$_mo_recs" | grep -q "realtime-sync" && type -t rs_inject_realtime_patterns &>/dev/null; then
            local _rs_patterns
            _rs_patterns=$(rs_inject_realtime_patterns "$prompt" 2>/dev/null || echo "")
            [[ -n "$_rs_patterns" ]] && prompt+="$_rs_patterns"
        fi

        # v189: Search injection
        if echo "$_mo_recs" | grep -q "search-engine" && type -t ses_inject_search_patterns &>/dev/null; then
            local _ses_patterns
            _ses_patterns=$(ses_inject_search_patterns "$prompt" 2>/dev/null || echo "")
            [[ -n "$_ses_patterns" ]] && prompt+="$_ses_patterns"
        fi

        # v190: File upload injection
        if echo "$_mo_recs" | grep -q "file-upload" && type -t fu_inject_upload_patterns &>/dev/null; then
            local _fu_patterns
            _fu_patterns=$(fu_inject_upload_patterns "$prompt" 2>/dev/null || echo "")
            [[ -n "$_fu_patterns" ]] && prompt+="$_fu_patterns"
        fi
    fi

    # v155: Cross-Session Learning - エラー予防注入
    if type -t cs_predictive_inject &>/dev/null && [[ "${ENABLE_CROSS_SESSION:-true}" == "true" ]]; then
        local _cs_prevention=""
        _cs_prevention=$(cs_predictive_inject "${DETECTED_DOMAIN:-general}" 2>/dev/null || echo "")
        if [[ -n "$_cs_prevention" && ${#_cs_prevention} -gt 20 ]]; then
            # v2003.1: Cross-Session を最大2000文字に制限
            [[ ${#_cs_prevention} -gt 2000 ]] && _cs_prevention="${_cs_prevention:0:2000}"
            prompt+="

=== [v155] エラー予防指示（過去セッション学習） ===
${_cs_prevention}
=== エラー予防指示 END ===
"
            echo -e "  🧠 [v155] Cross-Session学習注入: ${#_cs_prevention}文字" >&2
        fi
    fi

    if _call_claude "$prompt" "$output_file"; then
        echo -e "  ${GREEN}✅ フロントエンド実装完了${NC}"
        _write_claude_output_to_files "$output_file"
        type -t ctx_save &>/dev/null && ctx_save "frontend" "output_file" "$output_file"
        type -t ctx_save_phase_status &>/dev/null && ctx_save_phase_status "frontend" "completed"

        # v152: Checklist enforcement
        local _phase_output=""
        [[ -f "$output_file" ]] && _phase_output=$(cat "$output_file" 2>/dev/null || echo "")
        if type -t ccl_verify_output &>/dev/null && [[ -n "$_phase_output" ]]; then
            if ! ccl_verify_output "$_phase_output" "frontend" "${DETECTED_DOMAIN:-general}" 2>/dev/null; then
                echo -e "  🔄 [v152] Checklist不合格 → 再プロンプト実行" >&2
                # Re-prompt with missing items
                local _missing_prompt="以下の項目が欠落しています。必ず追加してください:\n"
                for item in "${CCL_MISSING_ITEMS[@]}"; do
                    _missing_prompt+="- ${item}\n"
                done
                # Append to original prompt and re-call
                local _retry_prompt="${prompt}\n\n=== [v152] 修正必須項目 ===\n${_missing_prompt}"
                _phase_output=$(_call_claude "$_retry_prompt" "" "frontend_retry" 2>/dev/null || echo "$_phase_output")
            fi
        fi

        # v181: Multi-turn quality convergence
        if type -t mt2_refine &>/dev/null && [[ "${ENABLE_MULTI_TURN:-true}" == "true" ]]; then
            local _mt_iteration=0
            local _mt_max=2
            while [[ $_mt_iteration -lt $_mt_max ]]; do
                # Quick quality check on output
                local _mt_score=100
                if type -t ccl_verify_output &>/dev/null; then
                    ccl_verify_output "$_phase_output" "frontend" 2>/dev/null && break
                    _mt_score=50
                fi
                [[ "$_mt_score" -ge 80 ]] && break
                echo -e "  🔄 [v181] Multi-Turn改善 ${_mt_iteration}/${_mt_max}" >&2
                local _mt_feedback="品質スコア${_mt_score}/100。以下を改善: ${CCL_MISSING_ITEMS[*]:-品質向上}"
                _phase_output=$(mt2_refine "$_phase_output" "$_mt_feedback" "frontend" 2>/dev/null || echo "$_phase_output")
                _mt_iteration=$((_mt_iteration + 1))
            done
        fi
    else
        echo -e "  ${RED}❌ フロントエンド実装失敗${NC}"
    fi

    _post_phase_validate_and_heal "FE"

    [[ "$NO_LEARN" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "FE" "frontend" "フロントエンド実装完了"

    _post_phase_checkpoint "frontend"
    return 0
}



# ---- Phase: バグ修正・追加要求（Deep Fix / Hotfix） ----
# v26.0: Deep Fix Engine 優先。
#   20体多角的調査→Judge統合→協調実装→全方位検証を自動実行。
#   dfe_run 未ロード時は従来の単体hotfix（フォールバック）で動作。
phase_hotfix() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "hotfix" 2>/dev/null || true

    echo -e "  ${CYAN}🔧 修正・追加要求フェーズ${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    # v26.1: Deep Fix Engine が使える場合は20体で深層修正
    if type -t dfe_run &>/dev/null; then
        echo -e "  ${BOLD}${PURPLE}🚀 Deep Fix Engine v26.1 起動${NC}"
        echo -e "  ${DIM}  20体エージェント × 多角的調査 × 協調実装 × 全方位検証${NC}"
        echo ""

        dfe_run \
            "$task_desc" \
            "." \
            "$session_id" \
            2>/dev/null || {
            echo -e "  ${YELLOW}⚠️ Deep Fix Engine 異常終了 → フォールバック実行${NC}"
            _phase_hotfix_fallback "$session_id" "$task_desc"
        }
    else
        # Deep Fix Engine 未ロード時: 従来の単体Claude呼び出し
        echo -e "  ${YELLOW}⚠️ Deep Fix Engine 未ロード → 従来モードで実行${NC}"
        _phase_hotfix_fallback "$session_id" "$task_desc"
    fi

    _post_phase_validate_and_heal "FIX"

    [[ "$NO_LEARN" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "FIX" "hotfix" "修正・追加要求完了"

    _post_phase_checkpoint "hotfix"
    return 0
}



# ---- Phase: 汎用実装（非Web系タスク） ----
phase_implementation() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "implementation" 2>/dev/null || true

    echo -e "  ${CYAN}🔨 実装フェーズ（汎用）${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    local req_content=""
    [[ -n "${REQUIREMENTS_FILE:-}" && -f "$REQUIREMENTS_FILE" ]] && req_content="$(cat "$REQUIREMENTS_FILE")"

    local rag_content=""
    [[ -f "${SESSION_LOG_DIR}/rag_results.txt" ]] && rag_content="$(cat "${SESSION_LOG_DIR}/rag_results.txt")"

    # v20.0: Real Data Connector必須化 - 未実行なら今ここで実行
    if type -t rdc_apply_real_data_config &>/dev/null; then
        local project_dir
    project_dir="$(_detect_project_dir)"
        local domain="general"
        type -t rdc_detect_domain &>/dev/null && domain=$(rdc_detect_domain "$task_desc")
        rdc_apply_real_data_config "$project_dir" "$task_desc" "" 2>/dev/null || true
    fi

    # v19.1: Real Data要件を取得
    local real_data_req=""
    if [[ -f "${SESSION_LOG_DIR}/real_data_requirements.md" ]]; then
        real_data_req="$(cat "${SESSION_LOG_DIR}/real_data_requirements.md" 2>/dev/null || echo "")"
    elif type -t rdc_get_real_data_requirements &>/dev/null; then
        local domain="general"
        type -t rdc_detect_domain &>/dev/null && domain=$(rdc_detect_domain "$task_desc")
        real_data_req="$(rdc_get_real_data_requirements "$domain" 2>/dev/null || echo "")"
    fi

    # v20.0: テンプレート注入 - スキャフォルダーが作ったテンプレートをClaudeプロンプトに直接注入
    local project_dir
    project_dir="$(_detect_project_dir)"
    local template_context=""

    # Prismaスキーマ注入
    local prisma_file=""
    for pf in "${project_dir}/prisma/schema.prisma" "${SESSION_LOG_DIR}/prisma_schema.prisma"; do
        [[ -f "$pf" ]] && { prisma_file="$pf"; break; }
    done
    if [[ -n "$prisma_file" ]]; then
        template_context+="
--- 既存Prismaスキーマ（必ずこのスキーマに従うこと） ---
$(cat "$prisma_file" 2>/dev/null)"
    fi

    # CRUDフックテンプレート注入
    for hook_file in "${project_dir}/lib/hooks/useCrud.ts" "${project_dir}/src/hooks/useCrud.ts" \
                     "${project_dir}/src/lib/hooks/useCrud.ts" "${project_dir}/hooks/useCrud.ts"; do
        if [[ -f "$hook_file" ]]; then
            template_context+="
--- 既存CRUDフック（全コンポーネントでこのフックをimportして使用すること） ---
$(cat "$hook_file" 2>/dev/null)"
            break
        fi
    done

    # APIルートテンプレート注入
    for api_file in "${project_dir}/routes/crud-template.js" "${project_dir}/src/routes/crud-template.js" \
                    "${project_dir}/routes/crud-template.ts" "${project_dir}/src/routes/crud-template.ts"; do
        if [[ -f "$api_file" ]]; then
            template_context+="
--- 既存APIルートテンプレート（このパターンに統一すること） ---
$(cat "$api_file" 2>/dev/null)"
            break
        fi
    done

    # Prismaクライアント注入
    for prisma_client in "${project_dir}/lib/prisma.ts" "${project_dir}/src/lib/prisma.ts" \
                         "${project_dir}/lib/prisma.js" "${project_dir}/src/lib/prisma.js"; do
        if [[ -f "$prisma_client" ]]; then
            template_context+="
--- Prismaクライアント初期化（このファイルをimportしてDB操作すること） ---
$(cat "$prisma_client" 2>/dev/null)"
            break
        fi
    done

    # v28.0: Prompt Compiler統合 - ドメイン知識/ブループリント/アンチパターンを最適化して注入
    local compiled_prompt=""
    if type -t pc_compile_backend_prompt &>/dev/null; then
        local domain="general"
        type -t rdc_detect_domain &>/dev/null && domain=$(rdc_detect_domain "$task_desc" 2>/dev/null || echo "general")
        local dk_dir="${HOME}/.soloptilink/domain-knowledge"
        local bg_dir="${HOME}/.soloptilink/blueprint"

        compiled_prompt=$(pc_compile_backend_prompt "$task_desc" "$domain" "nextjs" "$bg_dir" "$dk_dir" "$project_dir" "" 2>/dev/null || echo "")
    fi

    # ドメイン知識の直接注入（Prompt Compilerが使えない場合のフォールバック）
    local domain_context=""
    if [[ -z "$compiled_prompt" ]]; then
        local dk_dir="${HOME}/.soloptilink/domain-knowledge"
        if [[ -f "${dk_dir}/domain_prisma_schema.prisma" ]]; then
            domain_context+="
--- ドメイン知識: 確定済みPrismaスキーマ（変更禁止・そのまま使用） ---
$(cat "${dk_dir}/domain_prisma_schema.prisma" 2>/dev/null)"
        fi
        if [[ -f "${dk_dir}/domain_api_spec.md" ]]; then
            domain_context+="
--- ドメイン知識: API仕様（このエンドポイント設計に従うこと） ---
$(cat "${dk_dir}/domain_api_spec.md" 2>/dev/null)"
        fi
        if [[ -f "${dk_dir}/domain_business_rules.md" ]]; then
            domain_context+="
--- ドメイン知識: ビジネスルール（必ず実装すること） ---
$(cat "${dk_dir}/domain_business_rules.md" 2>/dev/null)"
        fi
    fi

    # ブループリント注入
    local blueprint_context=""
    local bg_dir="${HOME}/.soloptilink/blueprint"
    if [[ -f "${bg_dir}/backend_blueprint.md" ]]; then
        blueprint_context+="
--- 実装ブループリント: バックエンド（関数シグネチャ・ロジック手順に従うこと） ---
$(head -c 50000 "${bg_dir}/backend_blueprint.md" 2>/dev/null)"
    fi
    if [[ -f "${bg_dir}/frontend_blueprint.md" ]]; then
        blueprint_context+="
--- 実装ブループリント: フロントエンド（コンポーネント構成・状態管理に従うこと） ---
$(head -c 50000 "${bg_dir}/frontend_blueprint.md" 2>/dev/null)"
    fi

    # アンチパターン注入
    local anti_patterns=""
    if type -t pc_get_anti_patterns &>/dev/null; then
        anti_patterns=$(pc_get_anti_patterns 2>/dev/null || echo "")
    fi

    local prompt=""
    if [[ -n "$compiled_prompt" ]]; then
        # Prompt Compilerの最適化プロンプトを使用
        prompt="$compiled_prompt"
        # テンプレートコンテキストも追加
        [[ -n "$template_context" ]] && prompt+="

${template_context}"
    else
        # フォールバック: 従来プロンプト + ドメイン知識/ブループリント追加

        # v55.1: コンテキスト充足度チェック — 空コンテキストでの品質劣化を防止
        local _ctx_score=0
        [[ -n "$req_content" ]] && _ctx_score=$((_ctx_score + 25))
        [[ -n "$domain_context" ]] && _ctx_score=$((_ctx_score + 25))
        [[ -n "$blueprint_context" ]] && _ctx_score=$((_ctx_score + 25))
        [[ -n "$template_context" ]] && _ctx_score=$((_ctx_score + 25))

        if [[ $_ctx_score -lt 25 ]]; then
            echo -e "  ${YELLOW}⚠️ v55.1: コンテキスト不足 (${_ctx_score}/100) → 要件定義を自動生成してから実装${NC}"
            # 要件がゼロの場合、まず要件を生成させる
            local _auto_req_prompt="あなたはシニアソフトウェアアーキテクトです。以下のタスクから詳細な要件定義書を作成してください。

タスク: ${task_desc}

以下を必ず含めること:
1. 必要なデータモデル（テーブル名、カラム、型、リレーション）
2. 必要なAPIエンドポイント一覧（メソッド、パス、リクエスト/レスポンス型）
3. 必要な画面一覧（URL、コンポーネント構成、状態管理）
4. ビジネスルール（バリデーション、権限、ワークフロー）
5. 技術スタック: Next.js 15 + TypeScript + Prisma + SQLite + Tailwind CSS + shadcn/ui

具体的かつ実装可能なレベルで記述してください。"
            local _auto_req_file="${SESSION_LOG_DIR}/auto_requirements.md"
            if _call_claude "$_auto_req_prompt" "$_auto_req_file" 2>/dev/null; then
                req_content="$(cat "$_auto_req_file" 2>/dev/null || echo "")"
                echo -e "  ${GREEN}✅ 自動要件定義完了 → 実装プロンプトに注入${NC}"
            fi
        fi

        prompt="あなたはシニアソフトウェアエンジニアです。以下のタスクを完全に実装してください。

タスク: ${task_desc}

=== 要件定義 ===
${req_content:-(要件未定義のため、タスク説明から以下を推定して実装すること: データモデル、APIエンドポイント、画面構成、ビジネスルール)}

=== 関連ナレッジ ===
${rag_content:-（なし）}

${domain_context}
${blueprint_context}
${real_data_req}
${template_context}
${anti_patterns}

=== 実装ルール（厳守） ===
1. モックデータ・TODOスタブ・ハードコードされたダミー配列は絶対に使用禁止
2. 全データはORM（Prisma/SQLAlchemy）経由でDBに永続化すること
3. 開発環境はSQLite（file:./dev.db）で即起動。DATABASE_URLを変更するだけでPostgreSQLに移行可能にすること
4. 全APIエンドポイントにzodスキーマバリデーション必須
5. 全async関数にtry-catch + 適切なエラーレスポンス必須
6. サービス層を分離し、ビジネスロジックをAPIハンドラから切り離すこと
7. 全CRUDにPrismaトランザクション使用（複数テーブル更新時）
8. テストファイルを各機能に対して作成すること

=== テンプレート準拠ルール ===
- Prismaスキーマが提示されている → そのモデル定義をそのまま使用（変更禁止）
- CRUDフックが提示されている → 全コンポーネントでimportして使用
- APIルートテンプレートが提示されている → そのパターンで全エンドポイント実装
- 独自のパターンを新規に考案しないこと。提示されたテンプレートに統一すること
- ブループリントの関数シグネチャが提示されている → その通りに実装"
    fi

    local output_file="${SESSION_LOG_DIR}/implementation.md"

    # v60.0: Tool-Aware Generation - Claude に直接ファイルI/O権限を与える
    if [[ "${ENABLE_TOOL_AWARE_GEN:-false}" == "true" ]] && type -t tag_generate &>/dev/null; then
        echo -e "  ${CYAN}🔧 [v60.0] Tool-Aware Generation モード${NC}"
        tag_generate "$prompt" "$output_file" 2>/dev/null
        local _tag_rc=$?
        if [[ $_tag_rc -eq 0 ]]; then
            echo -e "  ${GREEN}✅ Tool-Aware実装完了${NC}"
            _write_claude_output_to_files "$output_file"
        else
            echo -e "  ${YELLOW}⚠️ Tool-Aware失敗 → 標準実装にフォールバック${NC}"
            if _call_claude "$prompt" "$output_file"; then
                echo -e "  ${GREEN}✅ 実装完了（フォールバック）${NC}"
                _write_claude_output_to_files "$output_file"
            else
                echo -e "  ${RED}❌ 実装失敗${NC}"
            fi
        fi
    # v63.0: MCP Bridge - DB認識生成（Prismaスキーマがある場合）
    elif [[ "${ENABLE_MCP_BRIDGE:-false}" == "true" ]] && type -t mb_db_aware_generate &>/dev/null && \
         [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
        echo -e "  ${CYAN}🔌 [v63.0] MCP Bridge - DB認識生成モード${NC}"
        mb_db_aware_generate "$prompt" "$output_file" "${project_dir}/prisma/schema.prisma" 2>/dev/null
        if [[ $? -eq 0 ]]; then
            echo -e "  ${GREEN}✅ DB認識実装完了${NC}"
            _write_claude_output_to_files "$output_file"
        else
            echo -e "  ${YELLOW}⚠️ MCP Bridge失敗 → 標準実装にフォールバック${NC}"
            _call_claude "$prompt" "$output_file" && _write_claude_output_to_files "$output_file"
        fi
    else
        # 標準実装パス
        if _call_claude "$prompt" "$output_file"; then
            echo -e "  ${GREEN}✅ 実装完了${NC}"
            _write_claude_output_to_files "$output_file"
        else
            echo -e "  ${RED}❌ 実装失敗${NC}"
        fi
    fi

    _post_phase_validate_and_heal "IMPL"

    # v68.0: Test Generator - 実装完了後にテスト自動生成
    if [[ "${ENABLE_TEST_GEN:-true}" == "true" ]] && type -t tg_generate_tests &>/dev/null; then
        echo -e "  ${CYAN}🧪 [v68.0] Test Generator - テスト自動生成${NC}"
        tg_generate_tests 2>/dev/null || true
    fi

    [[ "$NO_LEARN" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "IMPL" "implementation" "実装完了"

    _post_phase_checkpoint "implementation"
    return 0
}



# ---- Phase: プロンプトコンパイル (v27.0) ----
phase_prompt_compile() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "prompt_compile" 2>/dev/null || true

    echo -e "\n${BOLD}${CYAN}╔═══════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${CYAN}║  Phase 0.8: プロンプトコンパイル (v27.0)       ║${NC}"
    echo -e "${BOLD}${CYAN}╚═══════════════════════════════════════════════╝${NC}\n"
    echo -e "  経過時間: $(_elapsed_time)"

    if ! type -t pc_init &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ Prompt Compiler モジュール未ロード → スキップ${NC}"
        return 0
    fi

    pc_init "$session_id" 2>/dev/null || {
        echo -e "  ${YELLOW}⚠️ Prompt Compiler 初期化失敗 → スキップ${NC}"
        return 0
    }

    # 全レイヤーのプロンプトをコンパイル
    echo -e "  ${CYAN}🔧 プロンプトコンパイル中...${NC}"
    pc_compile_all "$task_desc" 2>/dev/null || {
        echo -e "  ${YELLOW}⚠️ プロンプトコンパイル一部失敗（続行）${NC}"
    }

    # 成果物をセッションログに保存
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        mkdir -p "${SESSION_LOG_DIR}" 2>/dev/null || true
        [[ -n "${PC_COMPILED_SHARED:-}" ]] && echo "$PC_COMPILED_SHARED" > "${SESSION_LOG_DIR}/compiled_prompt_shared.md"
        [[ -n "${PC_COMPILED_BACKEND:-}" ]] && echo "$PC_COMPILED_BACKEND" > "${SESSION_LOG_DIR}/compiled_prompt_backend.md"
        [[ -n "${PC_COMPILED_FRONTEND:-}" ]] && echo "$PC_COMPILED_FRONTEND" > "${SESSION_LOG_DIR}/compiled_prompt_frontend.md"
    fi

    # コンテキストエンジンに注入
    if type -t ctx_save &>/dev/null; then
        ctx_save "prompt_compile" "shared" "${PC_COMPILED_SHARED:-}" 2>/dev/null || true
        ctx_save "prompt_compile" "backend" "${PC_COMPILED_BACKEND:-}" 2>/dev/null || true
        ctx_save "prompt_compile" "frontend" "${PC_COMPILED_FRONTEND:-}" 2>/dev/null || true
    fi

    echo -e "  ${GREEN}✅ プロンプトコンパイル完了${NC}"
    # v2034.7-fix(SLB-003): PC_COMPILED_* が未設定だと ${#var} が
    # `set -u` (chain.sh は set -euo pipefail) で即死する。
    # 直前で空文字に正規化してから長さを参照する。
    PC_COMPILED_SHARED="${PC_COMPILED_SHARED:-}"
    PC_COMPILED_BACKEND="${PC_COMPILED_BACKEND:-}"
    PC_COMPILED_FRONTEND="${PC_COMPILED_FRONTEND:-}"
    echo -e "  ${CYAN}  共有型定義: ${#PC_COMPILED_SHARED} chars${NC}"
    echo -e "  ${CYAN}  バックエンド: ${#PC_COMPILED_BACKEND} chars${NC}"
    echo -e "  ${CYAN}  フロントエンド: ${#PC_COMPILED_FRONTEND} chars${NC}"
    _post_phase_checkpoint "prompt_compile"
    return 0
}



# ---- Phase: スマートプロンプト展開 (v9.0) ----
# 「CRM作って」→ ドメイン判定→競合調査→要件展開→技術選定→設計書
phase_prompt_expand() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "prompt_expand" 2>/dev/null || true

    echo -e "  ${CYAN}🧠 スマートプロンプト展開フェーズ (v24.0 - 目的ヒアリング付き)${NC}"
    echo -e "  入力: ${task_desc}"
    echo -e "  経過時間: $(_elapsed_time)"

    if ! type -t prompt_expand &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ Prompt Expanderモジュール未ロード → スキップ${NC}"
        return 0
    fi

    local expand_dir="${SESSION_LOG_DIR}/prompt_expand"
    mkdir -p "$expand_dir" 2>/dev/null || true

    # 初期化
    prompt_expand_init 2>/dev/null || true

    # 展開実行（出力の最終行がblueprint_fileパス）
    local expand_output
    expand_output=$(prompt_expand "$task_desc" "$expand_dir" 2>/dev/null || echo "")

    if [[ -n "$expand_output" ]]; then
        # 最終行がファイルパス
        BLUEPRINT_FILE=$(echo "$expand_output" | tail -1)
        if [[ -f "${BLUEPRINT_FILE:-}" ]]; then
            echo -e "  ${GREEN}✅ プロンプト展開完了: ${BLUEPRINT_FILE}${NC}"
            # 要件ファイルも設定
            local req_file="${expand_dir}/expanded_requirements.md"
            [[ -f "$req_file" ]] && REQUIREMENTS_FILE="$req_file"
            # 技術スタックファイルも設定
            local tech_file="${expand_dir}/tech_stack.md"
            [[ -f "$tech_file" ]] && TECH_STACK_FILE="$tech_file"
        else
            echo -e "  ${YELLOW}⚠️ 設計書ファイルが見つかりません → 通常要件分析にフォールバック${NC}"
        fi
    else
        echo -e "  ${YELLOW}⚠️ プロンプト展開失敗 → 通常要件分析にフォールバック${NC}"
    fi

    [[ "$NO_LEARN" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "PE" "prompt-expand" "プロンプト展開完了: ${task_desc:0:50}"

    _post_phase_checkpoint "prompt_expand"
    return 0
}



# ============================================================
# フェーズ実装 - REAL Claude Code CLI 統合
# ============================================================

# ---- Phase: 要件分析・設計 ----
phase_requirements() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "requirements" 2>/dev/null || true

    echo -e "  ${CYAN}📋 要件分析・設計フェーズ${NC}"
    echo -e "  タスク: ${task_desc}"
    echo -e "  経過時間: $(_elapsed_time)"

    local output_dir="${SESSION_LOG_DIR}"
    local output_file="${output_dir}/requirements.md"
    mkdir -p "$output_dir" 2>/dev/null || true

    # RAGコンテキスト取得
    local rag_context=""
    if [[ "$NO_RAG" != "1" && -f "tools/rag-engine.py" ]]; then
        rag_context=$(python3 tools/rag-engine.py search "$task_desc" --context 2>/dev/null || echo "")
        if [[ -n "$rag_context" ]]; then
            echo -e "  ${GREEN}📚 RAGから関連ナレッジ取得済み${NC}"
            echo "$rag_context" > "${output_dir}/rag_context_req.md"
        fi
    fi

    # URL分析結果があればコンテキストに含める
    local url_context=""
    if [[ -n "${REQUIREMENTS_FILE:-}" && -f "$REQUIREMENTS_FILE" ]]; then
        url_context="$(cat "$REQUIREMENTS_FILE")"
        echo -e "  ${GREEN}🌐 URL分析結果をコンテキストに注入${NC}"
    fi

    # Claude CLI呼び出し
    local prompt="あなたはシニアソフトウェアアーキテクトです。以下のタスクの要件定義書を作成してください。

タスク: ${task_desc}

以下のセクションを含めてください:
1. プロジェクト概要（目的、ターゲットユーザー）
2. 機能要件（Must/Should/Could、ユーザーロール別）
3. 非機能要件（パフォーマンス、セキュリティ、アクセシビリティ）
4. 技術スタック推奨
5. ファイル構造・ディレクトリ設計
6. データモデル概要
7. API設計概要
8. 画面一覧・遷移フロー

日本語で記述してください。技術用語は英語のまま使用可。"

    # RAGコンテキストがあれば追加
    if [[ -n "$rag_context" ]]; then
        prompt="${prompt}

過去の関連ナレッジ:
${rag_context}"
    fi

    # URL分析コンテキストがあれば追加
    if [[ -n "$url_context" ]]; then
        prompt="${prompt}

URL分析から得られた要件:
${url_context}"
    fi

    if _call_claude "$prompt" "$output_file"; then
        echo -e "  ${GREEN}✅ 要件定義書生成完了: ${output_file}${NC}"
        REQUIREMENTS_FILE="$output_file"
        # v12.0: コンテキストエンジンにステート保存
        type -t ctx_save &>/dev/null && ctx_save "requirements" "output_file" "$output_file"
        type -t ctx_save_phase_status &>/dev/null && ctx_save_phase_status "requirements" "completed"
    else
        echo -e "  ${RED}❌ 要件定義書の生成に失敗${NC}"
        # フォールバック: 最低限のファイルを作成
        cat > "$output_file" <<EOF
# 要件定義書
## タスク: ${task_desc}
## 作成日: $(date '+%Y-%m-%d %H:%M:%S')
## ステータス: Claude CLI呼び出し失敗 - 手動補完が必要
EOF
        REQUIREMENTS_FILE="$output_file"
    fi

    # 学習キャプチャ
    [[ "$NO_LEARN" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "REQ" "requirements" "要件分析完了: ${task_desc:0:50}"

    # チェックポイント
    _post_phase_checkpoint "requirements"

    return 0
}



# ---- Phase 2.5: SaaS アーキテクチャ (v18.0) ----
phase_saas_architecture() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "saas_architecture" 2>/dev/null || true

    echo -e "\n${BOLD}${CYAN}╔═══════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${CYAN}║  Phase 2.5: SaaS アーキテクチャ (v18.0)        ║${NC}"
    echo -e "${BOLD}${CYAN}╚═══════════════════════════════════════════════╝${NC}\n"

    if [[ "$ENABLE_SAAS" == "auto" ]]; then
        if [[ "$task_desc" =~ (SaaS|saas|multi.?tenant|マルチテナント|RBAC|rbac|サブスク|テナント) ]]; then
            ENABLE_SAAS="true"
        else
            echo -e "  ${YELLOW}⚠️ SaaS要件未検出 → スキップ${NC}"
            return 0
        fi
    fi
    [[ "$ENABLE_SAAS" != "true" ]] && return 0

    if ! type -t sb_init &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ SaaS Builder 未ロード → スキップ${NC}"
        return 0
    fi

    local strategy="$TENANT_STRATEGY"
    if [[ "$strategy" == "auto" ]]; then
        strategy=$(sb_detect_tenant_strategy "$task_desc" 2>/dev/null || echo "row-level")
    fi

    sb_init "$session_id" "$strategy" 2>/dev/null || return 1
    echo -e "  ${GREEN}🔧 テナント分離: ${strategy}${NC}"

    # テナントスキーマ生成
    local tenant_schema
    tenant_schema=$(sb_generate_tenant_schema "$strategy" "prisma" 2>/dev/null || echo "")
    if [[ -n "$tenant_schema" ]]; then
        mkdir -p "${SESSION_LOG_DIR}" 2>/dev/null || true
        echo "$tenant_schema" > "${SESSION_LOG_DIR}/tenant_schema.prisma"
        echo -e "  ${GREEN}✅ テナントスキーマ生成${NC}"
        type -t ctx_save &>/dev/null && ctx_save "saas" "tenant_schema" "$tenant_schema" 2>/dev/null || true
    fi

    # RBAC生成
    if [[ "${SB_RBAC_ENABLED:-true}" == "true" ]]; then
        local rbac_schema
        rbac_schema=$(sb_generate_rbac_schema 2>/dev/null || echo "")
        [[ -n "$rbac_schema" ]] && echo -e "  ${GREEN}🔐 RBACスキーマ生成${NC}"
    fi

    # 認証生成
    local IFS=','
    for method in $AUTH_METHODS; do
        case "$method" in
            jwt)    sb_generate_jwt_auth '{}' >/dev/null 2>&1 && echo -e "  ${GREEN}🔑 JWT認証生成${NC}" ;;
            oauth2) sb_generate_oauth2_scaffold '["google","github"]' >/dev/null 2>&1 && echo -e "  ${GREEN}🌐 OAuth2生成${NC}" ;;
            session) sb_generate_session_auth '{}' >/dev/null 2>&1 && echo -e "  ${GREEN}🍪 セッション認証生成${NC}" ;;
            saml)   sb_generate_saml_scaffold >/dev/null 2>&1 && echo -e "  ${GREEN}🏢 SAML生成${NC}" ;;
        esac
    done
    unset IFS

    # Billing
    if [[ "$ENABLE_BILLING" == "true" ]]; then
        sb_generate_billing_schema >/dev/null 2>&1 && echo -e "  ${GREEN}💳 Billingスキーマ生成${NC}"
        sb_generate_stripe_scaffold >/dev/null 2>&1 && echo -e "  ${GREEN}💰 Stripe統合生成${NC}"
    fi

    sb_report 2>/dev/null || true
    _post_phase_checkpoint "saas_architecture"
    return 0
}



# ---- Phase: プロジェクトスキャフォルド (v9.0) ----
phase_scaffold() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "scaffold" 2>/dev/null || true

    echo -e "  ${CYAN}🏗️ プロジェクトスキャフォルドフェーズ (v9.0)${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    if ! type -t scaffold_from_blueprint &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ スキャフォルダーモジュール未ロード → スキップ${NC}"
        return 0
    fi

    local blueprint="${BLUEPRINT_FILE:-}"
    local tech_stack="${TECH_STACK_FILE:-}"

    if [[ ! -f "${blueprint:-}" ]]; then
        echo -e "  ${YELLOW}⚠️ ブループリントなし → スキャフォルドスキップ${NC}"
        return 0
    fi

    # スキャフォルド実行
    if scaffold_from_blueprint "$blueprint" "$tech_stack" "." 2>/dev/null; then
        echo -e "  ${GREEN}✅ プロジェクトスキャフォルド完了${NC}"
    else
        echo -e "  ${YELLOW}⚠️ スキャフォルド一部失敗（続行）${NC}"
    fi

    # v27.0: Tech Stack Resolver - バージョン固定設定ファイル生成
    if type -t tsr_init &>/dev/null; then
        echo -e "  ${CYAN}📦 Tech Stack Resolver: バージョン固定設定を生成中...${NC}"
        tsr_init 2>/dev/null || true
        if tsr_apply_to_project "." "$task_desc" 2>/dev/null; then
            echo -e "  ${GREEN}✅ Tech Stack 設定生成完了（Next.js 15.1 / React 19 / Prisma 6.1）${NC}"
            # 依存関係インストール
            if [[ -f "./package.json" ]]; then
                tsr_install_dependencies "." 2>/dev/null && \
                    echo -e "  ${GREEN}✅ 依存関係インストール完了${NC}" || \
                    echo -e "  ${YELLOW}⚠️ 依存関係インストール一部失敗（続行）${NC}"
            fi
        else
            echo -e "  ${YELLOW}⚠️ Tech Stack 設定生成一部失敗（続行）${NC}"
        fi
    fi

    # v19.1: Real Data Connector - 実DB接続セットアップ
    if type -t rdc_apply_real_data_config &>/dev/null; then
        echo -e "  ${CYAN}🔗 Real Data Connector: 実DB接続セットアップ中...${NC}"
        local project_dir="."
        local framework="nextjs"
        # ブループリントからフレームワーク判定
        if [[ -f "${blueprint:-}" ]]; then
            if grep -qi "express\|react.*express" "$blueprint" 2>/dev/null; then
                framework="react-express"
            elif grep -qi "flask" "$blueprint" 2>/dev/null; then
                framework="python-flask"
            elif grep -qi "fastapi" "$blueprint" 2>/dev/null; then
                framework="python-fastapi"
            fi
        fi
        rdc_apply_real_data_config "$project_dir" "$task_desc" "$framework" 2>/dev/null && \
            echo -e "  ${GREEN}✅ 実DB接続セットアップ完了 (DB: ${RDC_DB_ENGINE:-sqlite})${NC}" || \
            echo -e "  ${YELLOW}⚠️ Real Data Connector セットアップ一部失敗（続行）${NC}"

        # データインポートファイルがあればシードスクリプト生成
        if [[ -n "${DATA_IMPORT_FILE:-}" && -f "${DATA_IMPORT_FILE:-}" ]] && type -t din_generate_seed_from_csv &>/dev/null; then
            local table_name
            table_name=$(basename "${DATA_IMPORT_FILE}" | sed 's/\.[^.]*$//' | tr '[:upper:]' '[:lower:]' | tr ' -' '_')
            din_generate_seed_from_csv "$DATA_IMPORT_FILE" "$project_dir" "$table_name" 2>/dev/null && \
                echo -e "  ${GREEN}✅ シードスクリプト生成完了${NC}" || true
        fi
    fi

    _post_phase_checkpoint "scaffold"
    return 0
}

# v172: Module Registry self-registration
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "phases-core" \
        --version "120.0" \
        --description "コアフェーズ実行（設計/実装/スキャフォルド/API/DB/Frontend）"
fi

# v2003.1: source時のexit codeを確実に0にする
true
