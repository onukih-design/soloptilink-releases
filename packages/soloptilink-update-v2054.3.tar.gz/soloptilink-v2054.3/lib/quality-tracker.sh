#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v104.0 - Quality Tracker
# =============================================================================
# セッション/ドメイン/フェーズごとの品質スコアを記録し、
# トレンド分析・リグレッション検出を行うエンジン。
#
# 品質スコア(0-100)を時系列で蓄積し、移動平均でトレンドを可視化。
# 現在のスコアがドメイン平均から10%以上低下した場合にアラート。
#
# Functions:
#   qt_init               - 履歴ロード・ディレクトリ準備
#   qt_record_score       - スコアを記録
#   qt_get_trend          - 移動平均トレンド取得
#   qt_detect_regression  - リグレッション検出
#   qt_get_domain_baseline- ドメインベースライン取得
#   qt_report             - レポート出力
#   qt_score              - モジュールスコア(0-100)
#
# All globals use the QT_ prefix.
# =============================================================================

[[ -n "${_QUALITY_TRACKER_LOADED:-}" ]] && return 0
_QUALITY_TRACKER_LOADED=1

QT_VERSION="104.0"
QT_INITIALIZED=false

# Storage
QT_LEARN_DIR=""
QT_SCORES_FILE=""

# Counters
QT_TOTAL_RECORDS=0
QT_SESSIONS_TRACKED=0
QT_REGRESSION_COUNT=0

# Domain baselines (associative arrays)
declare -g -A _QT_DOMAIN_TOTAL=()      # domain → cumulative score
declare -g -A _QT_DOMAIN_COUNT=()      # domain → record count
declare -g -A _QT_DOMAIN_SCORES=()     # domain → space-separated score list (recent 50)
declare -g -A _QT_DOMAIN_MODELS=()     # domain → last model used

# Session tracking
declare -g -A _QT_SESSION_SEEN=()      # session_id → 1

# =============================================================================
# qt_init - Load history, prepare directories
# =============================================================================
qt_init() {
    QT_LEARN_DIR="${HOME}/.soloptilink/learning/quality"
    mkdir -p "$QT_LEARN_DIR" 2>/dev/null || true

    QT_SCORES_FILE="${QT_LEARN_DIR}/scores.jsonl"

    # Reset in-memory state
    QT_TOTAL_RECORDS=0
    QT_SESSIONS_TRACKED=0
    QT_REGRESSION_COUNT=0
    _QT_DOMAIN_TOTAL=()
    _QT_DOMAIN_COUNT=()
    _QT_DOMAIN_SCORES=()
    _QT_DOMAIN_MODELS=()
    _QT_SESSION_SEEN=()

    # Load existing scores
    if [[ -f "$QT_SCORES_FILE" ]]; then
        _qt_load_history
    fi

    QT_INITIALIZED=true
    return 0
}

# =============================================================================
# _qt_json_val - Extract value from JSON (no jq)
# =============================================================================
_qt_json_val() {
    local json="$1" key="$2"
    echo "$json" | grep -o "\"${key}\":[^,}]*" | head -1 | sed "s/\"${key}\"://;s/^\"//;s/\"$//;s/^[[:space:]]*//;s/[[:space:]]*$//"
}

# =============================================================================
# _qt_load_history - Load persisted scores from JSONL
# =============================================================================
_qt_load_history() {
    [[ ! -f "$QT_SCORES_FILE" ]] && return 0

    local line
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue

        local sid domain phase score model
        sid=$(_qt_json_val "$line" "session_id")
        domain=$(_qt_json_val "$line" "domain")
        score=$(_qt_json_val "$line" "score")
        model=$(_qt_json_val "$line" "model")

        [[ -z "$domain" ]] && domain="general"
        [[ -z "$score" || ! "$score" =~ ^[0-9]+$ ]] && continue

        # Update domain aggregates
        local prev_total="${_QT_DOMAIN_TOTAL[$domain]:-0}"
        local prev_count="${_QT_DOMAIN_COUNT[$domain]:-0}"
        _QT_DOMAIN_TOTAL["$domain"]=$((prev_total + score))
        _QT_DOMAIN_COUNT["$domain"]=$((prev_count + 1))

        # Keep recent scores (space-separated, cap at 50)
        local existing="${_QT_DOMAIN_SCORES[$domain]:-}"
        local score_list
        if [[ -z "$existing" ]]; then
            score_list="$score"
        else
            # Count existing entries
            local wc
            wc=$(echo "$existing" | wc -w | tr -d ' ')
            if [[ $wc -ge 50 ]]; then
                # Drop oldest (first entry)
                score_list="${existing#* } ${score}"
            else
                score_list="${existing} ${score}"
            fi
        fi
        _QT_DOMAIN_SCORES["$domain"]="$score_list"

        [[ -n "$model" ]] && _QT_DOMAIN_MODELS["$domain"]="$model"

        # Track unique sessions
        if [[ -n "$sid" && -z "${_QT_SESSION_SEEN[$sid]:-}" ]]; then
            _QT_SESSION_SEEN["$sid"]=1
            QT_SESSIONS_TRACKED=$((QT_SESSIONS_TRACKED + 1))
        fi

        QT_TOTAL_RECORDS=$((QT_TOTAL_RECORDS + 1))
    done < "$QT_SCORES_FILE"

    return 0
}

# =============================================================================
# qt_record_score - Append a quality score to history
# =============================================================================
# Args: session_id, domain, phase, score (0-100), model
qt_record_score() {
    local session_id="${1:-unknown}"
    local domain="${2:-general}"
    local phase="${3:-unknown}"
    local score="${4:-0}"
    local model="${5:-default}"

    [[ "$QT_INITIALIZED" != "true" ]] && return 1

    # Validate score is 0-100
    [[ ! "$score" =~ ^[0-9]+$ ]] && score=0
    [[ $score -gt 100 ]] && score=100

    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date +"%Y-%m-%d")

    # Update in-memory
    local prev_total="${_QT_DOMAIN_TOTAL[$domain]:-0}"
    local prev_count="${_QT_DOMAIN_COUNT[$domain]:-0}"
    _QT_DOMAIN_TOTAL["$domain"]=$((prev_total + score))
    _QT_DOMAIN_COUNT["$domain"]=$((prev_count + 1))

    # Append to recent scores
    local existing="${_QT_DOMAIN_SCORES[$domain]:-}"
    if [[ -z "$existing" ]]; then
        _QT_DOMAIN_SCORES["$domain"]="$score"
    else
        local wc
        wc=$(echo "$existing" | wc -w | tr -d ' ')
        if [[ $wc -ge 50 ]]; then
            _QT_DOMAIN_SCORES["$domain"]="${existing#* } ${score}"
        else
            _QT_DOMAIN_SCORES["$domain"]="${existing} ${score}"
        fi
    fi

    _QT_DOMAIN_MODELS["$domain"]="$model"

    if [[ -z "${_QT_SESSION_SEEN[$session_id]:-}" ]]; then
        _QT_SESSION_SEEN["$session_id"]=1
        QT_SESSIONS_TRACKED=$((QT_SESSIONS_TRACKED + 1))
    fi

    QT_TOTAL_RECORDS=$((QT_TOTAL_RECORDS + 1))

    # Persist to disk
    echo "{\"timestamp\":\"${timestamp}\",\"session_id\":\"${session_id}\",\"domain\":\"${domain}\",\"phase\":\"${phase}\",\"score\":${score},\"model\":\"${model}\"}" >> "$QT_SCORES_FILE" 2>/dev/null

    return 0
}

# =============================================================================
# qt_get_trend - Return moving average over last N sessions for a domain
# =============================================================================
# Args: domain, count (default 5)
# Output: "avg|direction" where direction is up/down/stable
qt_get_trend() {
    local domain="${1:-general}"
    local count="${2:-5}"

    local scores_str="${_QT_DOMAIN_SCORES[$domain]:-}"
    [[ -z "$scores_str" ]] && echo "0|stable" && return 0

    # Get last N scores
    local all_scores=()
    local s
    for s in $scores_str; do
        all_scores+=("$s")
    done

    local total=${#all_scores[@]}
    [[ $total -eq 0 ]] && echo "0|stable" && return 0

    # Take last 'count' scores
    local start=0
    if [[ $total -gt $count ]]; then
        start=$((total - count))
    fi

    local sum=0
    local n=0
    local i
    for (( i=start; i<total; i++ )); do
        sum=$((sum + ${all_scores[$i]}))
        n=$((n + 1))
    done

    [[ $n -eq 0 ]] && echo "0|stable" && return 0
    local avg=$((sum / n))

    # Determine direction: compare first half vs second half of window
    local direction="stable"
    if [[ $n -ge 4 ]]; then
        local half=$((n / 2))
        local first_sum=0 second_sum=0
        local j=0
        for (( i=start; i<total; i++ )); do
            if [[ $j -lt $half ]]; then
                first_sum=$((first_sum + ${all_scores[$i]}))
            else
                second_sum=$((second_sum + ${all_scores[$i]}))
            fi
            j=$((j + 1))
        done
        local first_avg=$((first_sum / half))
        local second_half_count=$((n - half))
        [[ $second_half_count -eq 0 ]] && second_half_count=1
        local second_avg=$((second_sum / second_half_count))
        local diff=$((second_avg - first_avg))

        if [[ $diff -gt 5 ]]; then
            direction="up"
        elif [[ $diff -lt -5 ]]; then
            direction="down"
        fi
    fi

    echo "${avg}|${direction}"
    return 0
}

# =============================================================================
# qt_detect_regression - Alert if current score is >10% below domain average
# =============================================================================
# Args: domain, current_score
# Output: "regression|baseline|current" or "ok|baseline|current"
qt_detect_regression() {
    local domain="${1:-general}"
    local current_score="${2:-0}"

    [[ ! "$current_score" =~ ^[0-9]+$ ]] && current_score=0

    local baseline
    baseline=$(qt_get_domain_baseline "$domain")

    [[ $baseline -eq 0 ]] && echo "ok|0|${current_score}" && return 0

    local threshold=$(( (baseline * 90) / 100 ))  # 10% below baseline

    if [[ $current_score -lt $threshold ]]; then
        QT_REGRESSION_COUNT=$((QT_REGRESSION_COUNT + 1))
        echo "regression|${baseline}|${current_score}"
    else
        echo "ok|${baseline}|${current_score}"
    fi

    return 0
}

# =============================================================================
# qt_get_domain_baseline - Return expected quality score for a domain
# =============================================================================
# Args: domain
# Output: integer 0-100
qt_get_domain_baseline() {
    local domain="${1:-general}"

    local total="${_QT_DOMAIN_TOTAL[$domain]:-0}"
    local count="${_QT_DOMAIN_COUNT[$domain]:-0}"

    if [[ $count -eq 0 ]]; then
        echo "0"
        return 0
    fi

    echo "$((total / count))"
    return 0
}

# =============================================================================
# qt_report - Summary with trend indicators
# =============================================================================
qt_report() {
    echo -e "\n  ${BOLD:-}--- Quality Tracker v${QT_VERSION} ---${NC:-}"
    echo -e "  Total records      : ${QT_TOTAL_RECORDS}"
    echo -e "  Sessions tracked   : ${QT_SESSIONS_TRACKED}"
    echo -e "  Regressions found  : ${QT_REGRESSION_COUNT}"

    # Per-domain summary with trend arrows
    local domain
    for domain in "${!_QT_DOMAIN_COUNT[@]}"; do
        local baseline
        baseline=$(qt_get_domain_baseline "$domain")
        local trend_info
        trend_info=$(qt_get_trend "$domain" 5)
        local trend_avg="${trend_info%%|*}"
        local trend_dir="${trend_info##*|}"

        local arrow=""
        case "$trend_dir" in
            up)     arrow="^" ;;
            down)   arrow="v" ;;
            stable) arrow="-" ;;
        esac

        echo -e "  [${domain}] baseline=${baseline} trend=${trend_avg}${arrow} (n=${_QT_DOMAIN_COUNT[$domain]})"
    done
}

# =============================================================================
# qt_score - Module health score (0-100)
# =============================================================================
qt_score() {
    local score=50

    # +20 if we have records
    [[ $QT_TOTAL_RECORDS -gt 0 ]] && score=$((score + 20))

    # +15 if multiple sessions tracked
    [[ $QT_SESSIONS_TRACKED -ge 3 ]] && score=$((score + 15))

    # +15 if no regressions detected (or few relative to sessions)
    if [[ $QT_SESSIONS_TRACKED -gt 0 ]]; then
        local regression_rate=$(( (QT_REGRESSION_COUNT * 100) / QT_SESSIONS_TRACKED ))
        [[ $regression_rate -lt 20 ]] && score=$((score + 15))
    else
        score=$((score + 15))
    fi

    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "quality-tracker" \
    --version "104.0" \
    --description "品質スコア記録・トレンド分析・リグレッション検出" \
    --init "qt_init" \
    --report "qt_report" \
    --score "qt_score" \
    --enable-var "ENABLE_QT" \
    --cli-flags "--quality-tracker:--no-quality-tracker"
