#!/usr/bin/env bash
# dbl-detect.sh — DBL 業種自動検出エンジン (スキーマ v2 / v2040)
#
# 目的:
#   boost.md Step 0.8 (DBL Auto-Detect) の inline jq ループを置き換える正規エンジン。
#   keywords[] + synonyms[] 突合 → ヒット率正規化 → DEEP 深度ボーナス → 決定論的選択。
#   グレード判定 (DEEP/LEGACY/STUB) の正規実装もここに置く (SoT は dbl-schema-v2.md)。
#
# 使い方 (CLI 契約 — boost.md がこの契約で呼ぶため変更禁止):
#   bash ~/.soloptilink/lib/dbl-detect.sh detect "<候補テキスト>"
#       → stdout 1行JSON: {"dbl":"<name>","score":N,"grade":"DEEP|LEGACY|STUB","confident":true|false}
#         (全辞書 0 ヒット時のみ {"dbl":"unregistered","score":0,"grade":"NONE","confident":false})
#   bash ~/.soloptilink/lib/dbl-detect.sh list
#       → 全 DBL の表 (NAME/GRADE/KW/SYN/MODELS/PAGES/APIS/LOGIC/INDUSTRY)
#   bash ~/.soloptilink/lib/dbl-detect.sh audit
#       → 内部用 (dbl-validate.sh 専用): 全辞書の監査 JSON 配列
#
# 環境変数:
#   SOLOPTILINK_DOMAINS_DIR   (default: ~/.soloptilink/domains) — layered-depth-gate.sh と同一規約
#   DBL_CONFIDENT_MIN_HITS    (default: 3) — confident 判定の最小ヒット数
#   DBL_DEEP_MIN_HITS         (default: 2) — DEEP grade 時の confident 短縮閾値
#                              (2026-07-22 E2E で「介護施設のシステム」等の短文で
#                               DEEP スコア取得中でも confident:false になる問題を根治)
#
# 依存: python3 標準ライブラリのみ (jq 非依存)
# exit: 0 = 正常 / 2 = 引数・環境エラー

set -uo pipefail

DOMAINS_DIR="${SOLOPTILINK_DOMAINS_DIR:-$HOME/.soloptilink/domains}"
CONFIDENT_MIN_HITS="${DBL_CONFIDENT_MIN_HITS:-3}"
DEEP_MIN_HITS="${DBL_DEEP_MIN_HITS:-2}"
CMD="${1:-}"

usage() {
    cat >&2 <<'USAGE'
使い方:
  bash dbl-detect.sh detect "<候補テキスト>"   # 業種自動検出 → 1行JSON
  bash dbl-detect.sh list                      # 全 DBL の表
  bash dbl-detect.sh audit                     # 内部用: 監査 JSON (dbl-validate.sh 専用)
USAGE
}

if [[ ! -d "$DOMAINS_DIR" ]]; then
    echo "❌ domains ディレクトリが見つかりません: $DOMAINS_DIR" >&2
    exit 2
fi

case "$CMD" in
    detect)
        if [[ $# -lt 2 || -z "${2:-}" ]]; then
            echo "❌ detect には候補テキストが必要です" >&2
            usage
            exit 2
        fi
        ;;
    list|audit) ;;
    *)
        usage
        exit 2
        ;;
esac

# Python 側にモード/ディレクトリ/テキストを argv で渡す (シェル展開事故防止のためヒアドキュメントに変数を埋め込まない)
exec python3 - "$CMD" "$DOMAINS_DIR" "$CONFIDENT_MIN_HITS" "$DEEP_MIN_HITS" "${2:-}" <<'PYEOF'
# -*- coding: utf-8 -*-
# DBL スキーマ v2 正規実装 (SoT: ~/.soloptilink/scripts/dbl/dbl-schema-v2.md)
import json
import os
import sys
import glob

MODE = sys.argv[1]
DOMAINS_DIR = sys.argv[2]
CONFIDENT_MIN_HITS = int(sys.argv[3])
DEEP_MIN_HITS = int(sys.argv[4])   # DEEP grade 時の短縮閾値 (既定 2)
TEXT = sys.argv[5] if len(sys.argv) > 5 else ""

# ---- スキーマ v2 規約 (dbl-schema-v2.md §2/§3 と一致させること) ----
LEGACY_MARKERS = {"api_endpoints", "business_rules", "domain_features", "task_type"}
DEEP_THRESHOLDS = {"keywords": 100, "models": 15, "pages": 25, "apis": 20}
DEEP_REQUIRED = [
    "domain|name", "description", "version", "industry", "registered",
    "keywords", "models", "pages", "apis", "business_logic",
    "regulations", "seed_data", "kpi_targets", "growth_strategies",
]
STUB_REQUIRED = ["domain|name", "keywords", "models", "pages"]
LEGACY_REQUIRED = ["domain", "description", "keywords"]
RECOMMENDED = ["synonyms", "category"]
DEPTH_BONUS = {"DEEP": 2.0, "STUB": 1.0, "LEGACY": 0.0}
GRADE_RANK = {"DEEP": 0, "STUB": 1, "LEGACY": 2}
STUB_MIN_KEYWORDS = 20


def _count(v):
    """list/dict の件数 (それ以外は 0)"""
    if isinstance(v, (list, dict)):
        return len(v)
    return 0


def counts_of(j):
    """規模メトリクス算出 (pages は旧 screens キーも許容)"""
    return {
        "keywords": _count(j.get("keywords")),
        "synonyms": _count(j.get("synonyms")),
        "models": _count(j.get("models")),
        "pages": _count(j.get("pages") if j.get("pages") is not None else j.get("screens")),
        "apis": _count(j.get("apis")),
        "business_logic": _count(j.get("business_logic")),
        "regulations": _count(j.get("regulations")),
    }


def grade_of(j, c):
    """グレード判定 (決定論 / dbl-schema-v2.md §2)"""
    if (LEGACY_MARKERS & set(j.keys())) and "business_logic" not in j:
        return "LEGACY"
    if all(c[k] >= th for k, th in DEEP_THRESHOLDS.items()):
        return "DEEP"
    return "STUB"


def has_key(j, key):
    """必須キー存在判定 ('domain|name' は OR 判定)"""
    if "|" in key:
        return any(k in j for k in key.split("|"))
    return key in j


def missing_required(j, grade, c):
    """グレード別必須キー欠落 (dbl-schema-v2.md §3)"""
    req = {"DEEP": DEEP_REQUIRED, "STUB": STUB_REQUIRED, "LEGACY": LEGACY_REQUIRED}[grade]
    missing = [k for k in req if not has_key(j, k)]
    if grade == "STUB" and "keywords" not in missing and c["keywords"] < STUB_MIN_KEYWORDS:
        missing.append("keywords(>=%d)" % STUB_MIN_KEYWORDS)
    return missing


def name_of(j, path):
    return j.get("domain") or j.get("name") or os.path.splitext(os.path.basename(path))[0]


def load_all():
    """全辞書ロード (_base.json は対象外 / 破損は parse_error として保持)"""
    entries = []
    for path in sorted(glob.glob(os.path.join(DOMAINS_DIR, "*.json"))):
        base = os.path.basename(path)
        if base == "_base.json":
            continue
        entry = {"file": base, "path": path}
        try:
            with open(path, encoding="utf-8") as fp:
                j = json.load(fp)
            if not isinstance(j, dict):
                raise ValueError("トップレベルが object ではありません")
        except Exception as e:
            entry.update({"name": os.path.splitext(base)[0], "grade": "",
                          "counts": {}, "missing_required": [],
                          "warn_recommended": [], "parse_error": str(e)})
            entries.append(entry)
            continue
        c = counts_of(j)
        g = grade_of(j, c)
        entry.update({
            "name": name_of(j, path),
            "grade": g,
            "counts": c,
            "missing_required": missing_required(j, g, c),
            "warn_recommended": [k for k in RECOMMENDED if k not in j],
            "parse_error": "",
            "_json": j,
        })
        entries.append(entry)
    return entries


def terms_of(j):
    """突合語 = keywords + synonyms (重複除去・2文字未満除外)"""
    terms = set()
    for key in ("keywords", "synonyms"):
        v = j.get(key)
        if isinstance(v, list):
            for t in v:
                if isinstance(t, str):
                    t = t.strip()
                    if len(t) >= 2:
                        terms.add(t)
    return terms


def cmd_detect():
    text_l = TEXT.lower()
    best = None
    for e in load_all():
        if e["parse_error"] or "_json" not in e:
            continue  # 破損辞書は検出対象外 (dbl-validate.sh --strict が検出する)
        terms = terms_of(e["_json"])
        if not terms:
            continue
        hits = sum(1 for t in terms if t.lower() in text_l)
        coverage = hits / len(terms)
        # 深度ボーナスは confident 閾値以上ヒットした辞書のみ (低ヒットの無関係 DEEP 辞書が
        # 適合度の高い小型辞書を押しのけるのを防ぎ、同業種競合時のみ深い方を優先)
        bonus = DEPTH_BONUS[e["grade"]] if hits >= CONFIDENT_MIN_HITS else 0.0
        score = round(hits + coverage * 10 + bonus, 2)
        cand = {"dbl": e["name"], "score": score, "grade": e["grade"], "hits": hits}
        # 決定論的選択: score 降順 → グレード深い順 → 名前昇順
        if best is None or (
            (-cand["score"], GRADE_RANK[cand["grade"]], cand["dbl"])
            < (-best["score"], GRADE_RANK[best["grade"]], best["dbl"])
        ):
            best = cand
    if best is None or best["hits"] == 0:
        print(json.dumps({"dbl": "unregistered", "score": 0,
                          "grade": "NONE", "confident": False}))
        return 0
    # 2026-07-22 修理: DEEP grade で hits >= DEEP_MIN_HITS なら confident 昇格
    # (短文「介護施設のシステム」等が DEEP スコアでも confident:false になる問題を根治)
    _confident = (
        best["hits"] >= CONFIDENT_MIN_HITS
        or (best["grade"] == "DEEP" and best["hits"] >= DEEP_MIN_HITS)
    )
    print(json.dumps({"dbl": best["dbl"], "score": best["score"],
                      "grade": best["grade"],
                      "confident": _confident}))
    return 0


def cmd_list():
    entries = load_all()
    ok = [e for e in entries if not e["parse_error"]]
    broken = [e for e in entries if e["parse_error"]]
    ok.sort(key=lambda e: (GRADE_RANK[e["grade"]], e["name"]))
    fmt = "%-34s %-7s %5s %4s %4s %4s %4s %4s  %s"
    print(fmt % ("NAME", "GRADE", "KW", "SYN", "MDL", "PG", "API", "BL", "INDUSTRY"))
    print("-" * 100)
    for e in ok:
        j = e["_json"]
        c = e["counts"]
        industry = j.get("industry") or j.get("display_name") or j.get("displayName") or ""
        print(fmt % (e["name"], e["grade"], c["keywords"], c["synonyms"],
                     c["models"], c["pages"], c["apis"], c["business_logic"], industry))
    for e in broken:
        print("%-34s %-7s (JSON 破損: %s)" % (e["name"], "ERROR", e["parse_error"][:60]))
    n = {"DEEP": 0, "STUB": 0, "LEGACY": 0}
    for e in ok:
        n[e["grade"]] += 1
    print("-" * 100)
    print("合計 %d 件 (DEEP=%d / STUB=%d / LEGACY=%d / 破損=%d)"
          % (len(entries), n["DEEP"], n["STUB"], n["LEGACY"], len(broken)))
    return 0


def cmd_audit():
    out = []
    for e in load_all():
        e.pop("_json", None)
        e.pop("path", None)
        out.append(e)
    print(json.dumps(out, ensure_ascii=False))
    return 0


sys.exit({"detect": cmd_detect, "list": cmd_list, "audit": cmd_audit}[MODE]())
PYEOF
