#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v291.0 - GraphQL Federation
# =============================================================================
# GraphQLスキーマ自動生成×型安全リゾルバー×フェデレーション×クライアントフック
#
# 機能一覧:
#   _gf_generate_schema     - GraphQLスキーマ生成
#   _gf_generate_resolvers  - 型安全リゾルバー生成
#   _gf_generate_federation - フェデレーテッドスキーマ生成
#   _gf_generate_client     - GraphQLクライアントフック生成
#
# 全globals: GF_ prefix
# =============================================================================

[[ -n "${_GF_LOADED:-}" ]] && return 0; _GF_LOADED=1

declare -g GF_VERSION="291.0"
declare -g GF_GENERATED=0
declare -g GF_ERRORS=0
declare -g GF_FILES_WRITTEN=0

gf_init() { GF_GENERATED=0; GF_ERRORS=0; GF_FILES_WRITTEN=0; return 0; }

_gf_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then GF_FILES_WRITTEN=$((GF_FILES_WRITTEN + 1)); echo "  [gf] wrote: $filepath" >&2
    else GF_ERRORS=$((GF_ERRORS + 1)); fi
}

_gf_log() { echo -e "  ${GREEN:-\033[0;32m}[GF]${NC:-\033[0m} $*" >&2; }

# =============================================================================
# _gf_generate_schema
# =============================================================================
_gf_generate_schema() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _gf_log "Generating GraphQL schema..."

    local schema_gql
    schema_gql=$(cat <<'GQLEOF'
# =============================================================================
# GraphQL Schema
# Auto-generated from domain models
# =============================================================================

scalar DateTime
scalar JSON

# --- User ---
type User {
  id: ID!
  email: String!
  name: String!
  role: UserRole!
  createdAt: DateTime!
  updatedAt: DateTime!
  orders: [Order!]!
  profile: UserProfile
}

type UserProfile {
  bio: String
  avatar: String
  phone: String
}

enum UserRole {
  ADMIN
  USER
  MODERATOR
}

# --- Product ---
type Product {
  id: ID!
  name: String!
  description: String
  price: Float!
  stock: Int!
  category: Category
  images: [String!]!
  createdAt: DateTime!
}

type Category {
  id: ID!
  name: String!
  slug: String!
  products: [Product!]!
}

# --- Order ---
type Order {
  id: ID!
  user: User!
  items: [OrderItem!]!
  total: Float!
  status: OrderStatus!
  createdAt: DateTime!
  updatedAt: DateTime!
}

type OrderItem {
  id: ID!
  product: Product!
  quantity: Int!
  price: Float!
}

enum OrderStatus {
  PENDING
  CONFIRMED
  SHIPPED
  DELIVERED
  CANCELLED
}

# --- Pagination ---
type PageInfo {
  hasNextPage: Boolean!
  hasPreviousPage: Boolean!
  startCursor: String
  endCursor: String
  totalCount: Int!
}

type ProductConnection {
  edges: [ProductEdge!]!
  pageInfo: PageInfo!
}

type ProductEdge {
  node: Product!
  cursor: String!
}

# --- Queries ---
type Query {
  # Users
  me: User!
  user(id: ID!): User
  users(first: Int, after: String): [User!]!

  # Products
  product(id: ID!): Product
  products(first: Int, after: String, category: String, search: String): ProductConnection!
  categories: [Category!]!

  # Orders
  order(id: ID!): Order
  myOrders(first: Int, after: String, status: OrderStatus): [Order!]!
}

# --- Mutations ---
type Mutation {
  # Auth
  register(input: RegisterInput!): AuthPayload!
  login(input: LoginInput!): AuthPayload!

  # Products (admin)
  createProduct(input: CreateProductInput!): Product!
  updateProduct(id: ID!, input: UpdateProductInput!): Product!
  deleteProduct(id: ID!): Boolean!

  # Orders
  createOrder(input: CreateOrderInput!): Order!
  cancelOrder(id: ID!): Order!
}

# --- Inputs ---
input RegisterInput { email: String! password: String! name: String! }
input LoginInput { email: String! password: String! }
input CreateProductInput { name: String! description: String price: Float! stock: Int! categoryId: ID images: [String!] }
input UpdateProductInput { name: String description: String price: Float stock: Int }
input CreateOrderInput { items: [OrderItemInput!]! }
input OrderItemInput { productId: ID! quantity: Int! }

# --- Payloads ---
type AuthPayload { token: String! user: User! }

# --- Subscriptions ---
type Subscription {
  orderStatusChanged(orderId: ID!): Order!
  productStockUpdated(productId: ID!): Product!
}
GQLEOF
)
    _gf_write_file "${project_dir}/src/graphql/schema.graphql" "$schema_gql"
    GF_GENERATED=$((GF_GENERATED + 1))
    return 0
}

# =============================================================================
# _gf_generate_resolvers
# =============================================================================
_gf_generate_resolvers() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _gf_log "Generating resolvers..."

    local resolvers_ts
    resolvers_ts=$(cat <<'RESEOF'
// =============================================================================
// GraphQL Resolvers - Type-safe resolver implementations
// =============================================================================
import { PrismaClient } from '@prisma/client';
import { GraphQLError } from 'graphql';

const prisma = new PrismaClient();

export const resolvers = {
  Query: {
    me: async (_: any, __: any, ctx: { userId?: string }) => {
      if (!ctx.userId) throw new GraphQLError('Not authenticated', { extensions: { code: 'UNAUTHENTICATED' } });
      return prisma.user.findUniqueOrThrow({ where: { id: ctx.userId } });
    },

    user: async (_: any, { id }: { id: string }) => {
      return prisma.user.findUnique({ where: { id } });
    },

    products: async (_: any, { first = 20, after, category, search }: any) => {
      const where: any = {};
      if (category) where.category = { slug: category };
      if (search) where.name = { contains: search, mode: 'insensitive' };

      const items = await prisma.product.findMany({
        where,
        take: first + 1,
        cursor: after ? { id: after } : undefined,
        skip: after ? 1 : 0,
        orderBy: { createdAt: 'desc' },
      });

      const hasNextPage = items.length > first;
      const edges = items.slice(0, first).map((item: any) => ({
        node: item,
        cursor: item.id,
      }));

      return {
        edges,
        pageInfo: {
          hasNextPage,
          hasPreviousPage: !!after,
          startCursor: edges[0]?.cursor || null,
          endCursor: edges[edges.length - 1]?.cursor || null,
          totalCount: await prisma.product.count({ where }),
        },
      };
    },

    order: async (_: any, { id }: { id: string }, ctx: { userId?: string }) => {
      if (!ctx.userId) throw new GraphQLError('Not authenticated');
      return prisma.order.findFirst({ where: { id, userId: ctx.userId }, include: { items: true } });
    },
  },

  Mutation: {
    createProduct: async (_: any, { input }: any, ctx: { userId?: string; role?: string }) => {
      if (ctx.role !== 'admin') throw new GraphQLError('Forbidden', { extensions: { code: 'FORBIDDEN' } });
      return prisma.product.create({ data: input });
    },

    createOrder: async (_: any, { input }: any, ctx: { userId?: string }) => {
      if (!ctx.userId) throw new GraphQLError('Not authenticated');
      const items = input.items;
      let total = 0;
      for (const item of items) {
        const product = await prisma.product.findUniqueOrThrow({ where: { id: item.productId } });
        total += product.price * item.quantity;
      }
      return prisma.order.create({
        data: {
          userId: ctx.userId,
          total,
          status: 'PENDING',
          items: { create: items.map((i: any) => ({ productId: i.productId, quantity: i.quantity, price: 0 })) },
        },
        include: { items: true },
      });
    },
  },

  User: {
    orders: (parent: any) => prisma.order.findMany({ where: { userId: parent.id } }),
  },

  Order: {
    user: (parent: any) => prisma.user.findUnique({ where: { id: parent.userId } }),
    items: (parent: any) => prisma.orderItem.findMany({ where: { orderId: parent.id } }),
  },
};
RESEOF
)
    _gf_write_file "${project_dir}/src/graphql/resolvers.ts" "$resolvers_ts"
    GF_GENERATED=$((GF_GENERATED + 1))
    return 0
}

# =============================================================================
# _gf_generate_federation
# =============================================================================
_gf_generate_federation() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _gf_log "Generating federated schema..."

    local fed_ts
    fed_ts=$(cat <<'FEDEOF'
// =============================================================================
// GraphQL Federation Setup
// Apollo Federation v2 for combining multiple service schemas
// =============================================================================

export interface FederatedService {
  name: string;
  url: string;
  schema: string;
}

export const federatedServices: FederatedService[] = [
  { name: 'users', url: process.env.USER_GQL_URL || 'http://localhost:4001/graphql', schema: 'users.graphql' },
  { name: 'products', url: process.env.PRODUCT_GQL_URL || 'http://localhost:4002/graphql', schema: 'products.graphql' },
  { name: 'orders', url: process.env.ORDER_GQL_URL || 'http://localhost:4003/graphql', schema: 'orders.graphql' },
];

// Gateway configuration for Apollo Gateway / GraphQL Mesh
export function getGatewayConfig() {
  return {
    supergraphSdl: {
      type: 'IntrospectAndCompose',
      subgraphs: federatedServices.map((s) => ({ name: s.name, url: s.url })),
    },
    buildService: ({ url }: { url: string }) => {
      return {
        url,
        willSendRequest: ({ request }: any) => {
          // Forward auth headers to subgraphs
          // request.http.headers.set('x-user-id', context.userId);
        },
      };
    },
  };
}
FEDEOF
)
    _gf_write_file "${project_dir}/src/graphql/federation.ts" "$fed_ts"
    GF_GENERATED=$((GF_GENERATED + 1))
    return 0
}

# =============================================================================
# _gf_generate_client
# =============================================================================
_gf_generate_client() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _gf_log "Generating client hooks..."

    local client_ts
    client_ts=$(cat <<'CLIENTEOF'
// =============================================================================
// GraphQL Client Hooks (React)
// Type-safe hooks for querying and mutating data
// =============================================================================

// Example usage with urql or @tanstack/react-query + graphql-request

export const QUERIES = {
  GET_PRODUCTS: /* GraphQL */ `
    query GetProducts($first: Int, $after: String, $search: String) {
      products(first: $first, after: $after, search: $search) {
        edges { node { id name price stock images } cursor }
        pageInfo { hasNextPage endCursor totalCount }
      }
    }
  `,
  GET_PRODUCT: /* GraphQL */ `
    query GetProduct($id: ID!) {
      product(id: $id) { id name description price stock category { id name } images createdAt }
    }
  `,
  GET_MY_ORDERS: /* GraphQL */ `
    query GetMyOrders($first: Int, $status: OrderStatus) {
      myOrders(first: $first, status: $status) {
        id total status createdAt items { id quantity price product { id name } }
      }
    }
  `,
  ME: /* GraphQL */ `query Me { me { id email name role } }`,
};

export const MUTATIONS = {
  CREATE_ORDER: /* GraphQL */ `
    mutation CreateOrder($input: CreateOrderInput!) {
      createOrder(input: $input) { id total status }
    }
  `,
  LOGIN: /* GraphQL */ `
    mutation Login($input: LoginInput!) {
      login(input: $input) { token user { id email name role } }
    }
  `,
};

// Typed fetch helper
export async function graphqlFetch<T = any>(
  query: string,
  variables?: Record<string, unknown>,
  token?: string,
): Promise<T> {
  const url = process.env.NEXT_PUBLIC_GRAPHQL_URL || '/api/graphql';
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const resp = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify({ query, variables }),
  });

  const json = await resp.json();
  if (json.errors) throw new Error(json.errors[0].message);
  return json.data as T;
}
CLIENTEOF
)
    _gf_write_file "${project_dir}/src/graphql/client.ts" "$client_ts"
    GF_GENERATED=$((GF_GENERATED + 1))
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
gf_report() {
    echo -e "\n  ${BOLD:-}=== graphql-federation v${GF_VERSION} ===${NC:-}"
    echo -e "  生成数: ${GF_GENERATED}"; echo -e "  エラー: ${GF_ERRORS}"
}

gf_score() {
    if [[ ${GF_GENERATED} -ge 4 ]] && [[ ${GF_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${GF_GENERATED} -gt 0 ]] && [[ ${GF_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "graphql-federation" --version "${GF_VERSION}" \
        --description "GraphQLスキーマ×リゾルバー×Federation×クライアント" \
        --init "gf_init" --report "gf_report" --score "gf_score" \
        --enable-var "ENABLE_GRAPHQL" --cli-flags "--graphql:--no-graphql"
fi

# v2003.1: source時のexit codeを確実に0にする
true
