#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v482.0 - Natural Language Understanding Engine
# =============================================================================
# ユーザーの自然言語入力を解析し、意図・エンティティ・制約を抽出する。
# 曖昧な表現の解消、暗黙の要件推論、ドメイン用語の正規化を行い、
# 後続の計画・実装モジュールに構造化された要件を提供する。
#
# Functions:
#   _nlu_init               - 初期化
#   _nlu_parse_intent       - 意図解析
#   _nlu_disambiguate       - 曖昧性解消
#   _nlu_extract_entities   - エンティティ抽出
#   _nlu_normalize          - 入力正規化
#   _nlu_infer_implicit     - 暗黙の要件推論
#   _nlu_report             - レポート出力
#   _nlu_score              - モジュールスコア(0-100)
#
# Globals: NLU_ prefix
# =============================================================================

[[ -n "${_NATURAL_LANGUAGE_UNDERSTANDING_LOADED:-}" ]] && return 0
_NATURAL_LANGUAGE_UNDERSTANDING_LOADED=1

NLU_VERSION="482.0"
NLU_INITIALIZED=false

# --- Storage ---
NLU_DATA_DIR=""
NLU_PARSE_LOG=""
NLU_ENTITY_LOG=""

# --- State ---
NLU_TOTAL_PARSES=0
NLU_TOTAL_ENTITIES=0
NLU_DISAMBIGUATION_COUNT=0
NLU_CONFIDENCE=0

# --- Parse Results ---
declare -g -A _NLU_INTENTS=()
declare -g -A _NLU_ENTITIES=()
declare -g -A _NLU_CONSTRAINTS=()
declare -g -a _NLU_IMPLICIT_REQS=()
declare -g -A _NLU_DOMAIN_VOCAB=()

# Intent categories
declare -g -A _NLU_INTENT_PATTERNS=(
    ["create_app"]="作って|作成|構築|ビルド|開発|build|create|make"
    ["modify_app"]="修正|変更|更新|改善|リファクタ|modify|update|fix"
    ["add_feature"]="追加|機能追加|実装|add|implement"
    ["deploy"]="デプロイ|公開|リリース|deploy|release|publish"
    ["test"]="テスト|検証|確認|test|verify|check"
    ["analyze"]="分析|調査|レビュー|analyze|review|audit"
    ["optimize"]="最適化|高速化|改善|optimize|improve|speed up"
    ["security"]="セキュリティ|脆弱性|監査|security|vulnerability|audit"
)

# =============================================================================
# 初期化
# =============================================================================
_nlu_init() {
    local project_dir="${PROJECT_DIR:-.}"
    NLU_DATA_DIR="${project_dir}/.soloptilink/nlu"
    NLU_PARSE_LOG="${NLU_DATA_DIR}/parses.jsonl"
    NLU_ENTITY_LOG="${NLU_DATA_DIR}/entities.jsonl"

    mkdir -p "$NLU_DATA_DIR"

    # ドメイン語彙の初期化
    _NLU_DOMAIN_VOCAB["CRM"]="顧客管理 顧客関係管理 カスタマーリレーション"
    _NLU_DOMAIN_VOCAB["EC"]="eコマース 通販 ショッピング オンラインストア ECサイト"
    _NLU_DOMAIN_VOCAB["SaaS"]="サービス クラウドサービス 月額 サブスクリプション"
    _NLU_DOMAIN_VOCAB["BLOG"]="ブログ CMS コンテンツ 記事 投稿"
    _NLU_DOMAIN_VOCAB["CHAT"]="チャット メッセージ リアルタイム 会話"
    _NLU_DOMAIN_VOCAB["TASK"]="タスク管理 TODO プロジェクト管理 カンバン"
    _NLU_DOMAIN_VOCAB["DASHBOARD"]="ダッシュボード 管理画面 分析 統計"
    _NLU_DOMAIN_VOCAB["PORTFOLIO"]="ポートフォリオ LP ランディングページ 作品集"

    NLU_INITIALIZED=true
    return 0
}

# =============================================================================
# 意図解析
# =============================================================================
_nlu_parse_intent() {
    local input="$1"

    [[ "$NLU_INITIALIZED" != "true" ]] && _nlu_init

    local best_intent="create_app"
    local best_confidence=0

    for intent in "${!_NLU_INTENT_PATTERNS[@]}"; do
        local pattern="${_NLU_INTENT_PATTERNS[$intent]}"
        local matches=0

        # パターンの各キーワードとの一致をカウント
        IFS='|' read -ra keywords <<< "$pattern"
        for keyword in "${keywords[@]}"; do
            if echo "$input" | grep -qi "$keyword" 2>/dev/null; then
                matches=$((matches + 1))
            fi
        done

        if [[ $matches -gt $best_confidence ]]; then
            best_confidence=$matches
            best_intent="$intent"
        fi
    done

    # 信頼度の計算
    NLU_CONFIDENCE=$((best_confidence * 30))
    [[ $NLU_CONFIDENCE -gt 100 ]] && NLU_CONFIDENCE=100
    [[ $NLU_CONFIDENCE -lt 30 ]] && NLU_CONFIDENCE=30

    _NLU_INTENTS["primary"]="$best_intent"
    _NLU_INTENTS["confidence"]="$NLU_CONFIDENCE"

    # 複合意図の検出
    local secondary_intents=""
    for intent in "${!_NLU_INTENT_PATTERNS[@]}"; do
        [[ "$intent" == "$best_intent" ]] && continue
        local pattern="${_NLU_INTENT_PATTERNS[$intent]}"
        IFS='|' read -ra keywords <<< "$pattern"
        for keyword in "${keywords[@]}"; do
            if echo "$input" | grep -qi "$keyword" 2>/dev/null; then
                secondary_intents+="${intent} "
                break
            fi
        done
    done
    _NLU_INTENTS["secondary"]="$secondary_intents"

    NLU_TOTAL_PARSES=$((NLU_TOTAL_PARSES + 1))

    local timestamp
    timestamp=$(date +%s)
    echo "{\"ts\":${timestamp},\"input_len\":${#input},\"intent\":\"${best_intent}\",\"confidence\":${NLU_CONFIDENCE}}" >> "$NLU_PARSE_LOG" 2>/dev/null

    echo "${best_intent}:${NLU_CONFIDENCE}"
    return 0
}

# =============================================================================
# 曖昧性解消
# =============================================================================
_nlu_disambiguate() {
    local input="$1"

    [[ "$NLU_INITIALIZED" != "true" ]] && _nlu_init

    local disambiguated="$input"
    local changes=0

    # プラットフォーム曖昧性
    if echo "$input" | grep -qi "アプリ" && ! echo "$input" | grep -qiE "iOS|Android|Web|モバイル"; then
        disambiguated="${disambiguated} [推定: Webアプリケーション]"
        changes=$((changes + 1))
    fi

    # データベース曖昧性
    if echo "$input" | grep -qiE "データ|保存|管理" && ! echo "$input" | grep -qiE "PostgreSQL|MySQL|SQLite|MongoDB"; then
        disambiguated="${disambiguated} [推定DB: PostgreSQL(Prisma)]"
        changes=$((changes + 1))
    fi

    # 認証曖昧性
    if echo "$input" | grep -qiE "ログイン|ユーザー|会員" && ! echo "$input" | grep -qiE "NextAuth|JWT|OAuth|Clerk"; then
        disambiguated="${disambiguated} [推定認証: JWT+bcrypt]"
        changes=$((changes + 1))
    fi

    # スタイリング曖昧性
    if ! echo "$input" | grep -qiE "Tailwind|CSS|styled|Material|Chakra"; then
        disambiguated="${disambiguated} [推定CSS: Tailwind CSS]"
        changes=$((changes + 1))
    fi

    # 「シンプルな」の解釈
    if echo "$input" | grep -qi "シンプル"; then
        disambiguated="${disambiguated} [シンプル: MVP機能セット、クリーンUI]"
        changes=$((changes + 1))
    fi

    # 「本格的な」の解釈
    if echo "$input" | grep -qiE "本格的|プロフェッショナル|エンタープライズ"; then
        disambiguated="${disambiguated} [本格的: 認証+RBAC+監査ログ+テスト+CI/CD]"
        changes=$((changes + 1))
    fi

    NLU_DISAMBIGUATION_COUNT=$((NLU_DISAMBIGUATION_COUNT + changes))

    echo "$disambiguated"
    return 0
}

# =============================================================================
# エンティティ抽出
# =============================================================================
_nlu_extract_entities() {
    local input="$1"

    [[ "$NLU_INITIALIZED" != "true" ]] && _nlu_init

    _NLU_ENTITIES=()
    local entity_count=0

    # ドメインエンティティ
    for domain in "${!_NLU_DOMAIN_VOCAB[@]}"; do
        local vocab="${_NLU_DOMAIN_VOCAB[$domain]}"
        for term in $vocab; do
            if echo "$input" | grep -qi "$term" 2>/dev/null; then
                _NLU_ENTITIES["domain"]="$domain"
                entity_count=$((entity_count + 1))
                break 2
            fi
        done
    done

    # 直接ドメイン名の検出
    for domain in CRM EC SaaS BLOG CHAT TASK DASHBOARD PORTFOLIO; do
        if echo "$input" | grep -qi "$domain" 2>/dev/null; then
            _NLU_ENTITIES["domain"]="$domain"
            entity_count=$((entity_count + 1))
            break
        fi
    done

    # 技術スタックエンティティ
    local techs=("Next.js" "React" "Vue" "Angular" "Svelte" "Express" "FastAPI" "Django" "Rails")
    for tech in "${techs[@]}"; do
        if echo "$input" | grep -qi "$tech" 2>/dev/null; then
            _NLU_ENTITIES["framework"]="$tech"
            entity_count=$((entity_count + 1))
            break
        fi
    done

    # 機能エンティティ
    local features=""
    echo "$input" | grep -qiE "認証|ログイン" && features+="auth "
    echo "$input" | grep -qiE "検索" && features+="search "
    echo "$input" | grep -qiE "決済|支払" && features+="payment "
    echo "$input" | grep -qiE "通知|メール" && features+="notification "
    echo "$input" | grep -qiE "チャット|メッセージ" && features+="realtime "
    echo "$input" | grep -qiE "ダッシュボード|分析|グラフ" && features+="analytics "
    echo "$input" | grep -qiE "アップロード|画像" && features+="upload "
    echo "$input" | grep -qiE "API|外部連携" && features+="api_integration "

    _NLU_ENTITIES["features"]="${features% }"
    [[ -n "$features" ]] && entity_count=$((entity_count + 1))

    # 制約エンティティ
    echo "$input" | grep -qiE "高速|パフォーマンス" && _NLU_CONSTRAINTS["performance"]="high"
    echo "$input" | grep -qiE "セキュア|安全" && _NLU_CONSTRAINTS["security"]="high"
    echo "$input" | grep -qiE "スケーラブル|拡張" && _NLU_CONSTRAINTS["scalability"]="high"
    echo "$input" | grep -qiE "日本語|多言語" && _NLU_CONSTRAINTS["i18n"]="required"

    NLU_TOTAL_ENTITIES=$((NLU_TOTAL_ENTITIES + entity_count))

    local timestamp
    timestamp=$(date +%s)
    echo "{\"ts\":${timestamp},\"entities\":${entity_count},\"domain\":\"${_NLU_ENTITIES["domain"]:-unknown}\"}" >> "$NLU_ENTITY_LOG" 2>/dev/null

    echo "$entity_count"
    return 0
}

# =============================================================================
# 入力正規化
# =============================================================================
_nlu_normalize() {
    local input="$1"
    local normalized="$input"

    # 日本語の正規化
    normalized=$(echo "$normalized" | sed 's/　/ /g')  # 全角スペース
    normalized=$(echo "$normalized" | sed 's/、/, /g; s/。/. /g')  # 句読点

    echo "$normalized"
}

# =============================================================================
# 暗黙の要件推論
# =============================================================================
_nlu_infer_implicit() {
    local domain="${_NLU_ENTITIES["domain"]:-general}"

    _NLU_IMPLICIT_REQS=()

    # ドメイン固有の暗黙要件
    case "$domain" in
        CRM)
            _NLU_IMPLICIT_REQS+=("顧客一覧・詳細・検索機能")
            _NLU_IMPLICIT_REQS+=("商談/案件管理パイプライン")
            _NLU_IMPLICIT_REQS+=("活動履歴・メモ機能")
            _NLU_IMPLICIT_REQS+=("CSV/Excelインポート・エクスポート")
            ;;
        EC)
            _NLU_IMPLICIT_REQS+=("商品カタログ・カテゴリ管理")
            _NLU_IMPLICIT_REQS+=("カート・チェックアウトフロー")
            _NLU_IMPLICIT_REQS+=("注文管理・配送ステータス追跡")
            _NLU_IMPLICIT_REQS+=("レビュー・評価システム")
            ;;
        SaaS)
            _NLU_IMPLICIT_REQS+=("マルチテナント基盤")
            _NLU_IMPLICIT_REQS+=("サブスクリプション・課金管理")
            _NLU_IMPLICIT_REQS+=("管理者ダッシュボード")
            _NLU_IMPLICIT_REQS+=("オンボーディングフロー")
            ;;
        CHAT)
            _NLU_IMPLICIT_REQS+=("リアルタイムメッセージング")
            _NLU_IMPLICIT_REQS+=("チャンネル/DM管理")
            _NLU_IMPLICIT_REQS+=("既読管理・タイピングインジケータ")
            _NLU_IMPLICIT_REQS+=("ファイル共有・絵文字リアクション")
            ;;
    esac

    # 共通の暗黙要件
    _NLU_IMPLICIT_REQS+=("レスポンシブデザイン")
    _NLU_IMPLICIT_REQS+=("エラーハンドリング")
    _NLU_IMPLICIT_REQS+=("ローディング状態表示")

    echo "${#_NLU_IMPLICIT_REQS[@]}"
    return 0
}

# =============================================================================
# レポート
# =============================================================================
_nlu_report() {
    echo -e "\n  ${BOLD:-}═══ Natural Language Understanding v${NLU_VERSION} ═══${NC:-}"
    echo -e "  解析回数           : ${NLU_TOTAL_PARSES}"
    echo -e "  抽出エンティティ   : ${NLU_TOTAL_ENTITIES}"
    echo -e "  曖昧性解消         : ${NLU_DISAMBIGUATION_COUNT}"
    echo -e "  意図信頼度         : ${NLU_CONFIDENCE}%"
}

_nlu_score() {
    [[ "$NLU_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=50
    [[ $NLU_TOTAL_PARSES -gt 0 ]] && s=$((s + 15))
    [[ $NLU_TOTAL_ENTITIES -gt 2 ]] && s=$((s + 15))
    [[ $NLU_CONFIDENCE -gt 60 ]] && s=$((s + 20))
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_nlu_init_message() {
    echo -e "  ${GREEN:-}✅ v${NLU_VERSION} natural-language-understanding: 自然言語理解エンジン${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "natural-language-understanding" \
    --version "$NLU_VERSION" \
    --description "自然言語理解エンジン" \
    --init "_nlu_init" \
    --report "_nlu_report" \
    --score "_nlu_score" \
    --enable-var "ENABLE_NLU" \
    --cli-flags "--nlu:--no-nlu" \
    --init-msg "_nlu_init_message"
