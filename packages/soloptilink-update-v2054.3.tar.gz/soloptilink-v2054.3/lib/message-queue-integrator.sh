#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v284.0 - Message Queue Integrator
# =============================================================================
# メッセージキュー統合エンジン。BullMQ/SQS対応のプロデューサー、コンシューマー、
# デッドレターキューを自動生成する。
#
# 機能一覧:
#   _mqi_generate_producer    - メッセージプロデューサー生成
#   _mqi_generate_consumer    - メッセージコンシューマー生成
#   _mqi_generate_dead_letter - デッドレターキュー処理生成
#   _mqi_select_provider      - キュープロバイダー選択
#
# 全globals: MQI_ prefix
# =============================================================================

[[ -n "${_MQI_LOADED:-}" ]] && return 0; _MQI_LOADED=1

declare -g MQI_VERSION="284.0"
declare -g MQI_GENERATED=0
declare -g MQI_ERRORS=0
declare -g MQI_FILES_WRITTEN=0
declare -g MQI_PROVIDER="bullmq"

mqi_init() {
    MQI_GENERATED=0
    MQI_ERRORS=0
    MQI_FILES_WRITTEN=0
    MQI_PROVIDER="bullmq"
    return 0
}

_mqi_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then MQI_FILES_WRITTEN=$((MQI_FILES_WRITTEN + 1)); echo "  [mqi] wrote: $filepath" >&2
    else MQI_ERRORS=$((MQI_ERRORS + 1)); fi
}

_mqi_log() { echo -e "  ${GREEN:-\033[0;32m}[MQI]${NC:-\033[0m} $*" >&2; }

# =============================================================================
# _mqi_select_provider - プロバイダー選択
# =============================================================================
_mqi_select_provider() {
    local project_desc="${1:-}"
    local infra="${2:-local}"

    if [[ "$infra" == "aws" ]] || echo "$project_desc" | grep -qi "sqs\|aws\|lambda"; then
        MQI_PROVIDER="sqs"
        _mqi_log "Selected provider: Amazon SQS"
    else
        MQI_PROVIDER="bullmq"
        _mqi_log "Selected provider: BullMQ (Redis)"
    fi
    echo "$MQI_PROVIDER"
}

# =============================================================================
# _mqi_generate_producer - メッセージプロデューサー
# =============================================================================
_mqi_generate_producer() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _mqi_log "Generating message producer..."

    local producer_ts
    producer_ts=$(cat <<'PRODEOF'
// =============================================================================
// Message Queue - Producer
// Unified producer supporting BullMQ and SQS backends
// =============================================================================
import { z } from 'zod';

// --- Message Schema ---
export const MessageSchema = z.object({
  id: z.string().uuid(),
  type: z.string().min(1),
  payload: z.record(z.unknown()),
  metadata: z.object({
    source: z.string(),
    timestamp: z.string().datetime(),
    correlationId: z.string().uuid().optional(),
    retryCount: z.number().int().min(0).default(0),
  }),
});
export type Message = z.infer<typeof MessageSchema>;

// --- Producer Interface ---
export interface MessageProducer {
  send(queue: string, message: Omit<Message, 'id' | 'metadata'> & { metadata?: Partial<Message['metadata']> }): Promise<string>;
  sendBatch(queue: string, messages: Array<Omit<Message, 'id' | 'metadata'>>): Promise<string[]>;
  close(): Promise<void>;
}

// --- BullMQ Producer ---
export class BullMQProducer implements MessageProducer {
  private queues: Map<string, any> = new Map();

  private async getQueue(name: string) {
    if (!this.queues.has(name)) {
      const { Queue } = await import('bullmq');
      const queue = new Queue(name, {
        connection: {
          host: process.env.REDIS_HOST || 'localhost',
          port: parseInt(process.env.REDIS_PORT || '6379'),
          password: process.env.REDIS_PASSWORD || undefined,
          maxRetriesPerRequest: null,
        },
        defaultJobOptions: {
          removeOnComplete: { age: 3600, count: 1000 },
          removeOnFail: { age: 86400, count: 5000 },
          attempts: 3,
          backoff: { type: 'exponential', delay: 1000 },
        },
      });
      this.queues.set(name, queue);
    }
    return this.queues.get(name)!;
  }

  async send(queue: string, message: any): Promise<string> {
    const q = await this.getQueue(queue);
    const fullMessage: Message = {
      id: crypto.randomUUID(),
      type: message.type,
      payload: message.payload,
      metadata: {
        source: process.env.SERVICE_NAME || 'unknown',
        timestamp: new Date().toISOString(),
        correlationId: message.metadata?.correlationId || crypto.randomUUID(),
        retryCount: 0,
      },
    };
    const validated = MessageSchema.parse(fullMessage);
    const job = await q.add(validated.type, validated, { jobId: validated.id });
    console.log(`[mq] Sent: ${validated.type} -> ${queue} (${job.id})`);
    return job.id!;
  }

  async sendBatch(queue: string, messages: any[]): Promise<string[]> {
    const ids: string[] = [];
    for (const msg of messages) {
      const id = await this.send(queue, msg);
      ids.push(id);
    }
    return ids;
  }

  async close(): Promise<void> {
    for (const [, queue] of this.queues) {
      await queue.close();
    }
    this.queues.clear();
  }
}

// --- Factory ---
export function createProducer(provider?: string): MessageProducer {
  const p = provider || process.env.MQ_PROVIDER || 'bullmq';
  switch (p) {
    case 'bullmq': return new BullMQProducer();
    default: throw new Error(`Unsupported MQ provider: ${p}`);
  }
}
PRODEOF
)
    _mqi_write_file "${project_dir}/src/lib/mq/producer.ts" "$producer_ts"
    MQI_GENERATED=$((MQI_GENERATED + 1))
    return 0
}

# =============================================================================
# _mqi_generate_consumer - メッセージコンシューマー
# =============================================================================
_mqi_generate_consumer() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _mqi_log "Generating message consumer..."

    local consumer_ts
    consumer_ts=$(cat <<'CONSEOF'
// =============================================================================
// Message Queue - Consumer
// Unified consumer with handler registry, concurrency control, graceful shutdown
// =============================================================================
import { Message, MessageSchema } from './producer';

type MessageHandler = (message: Message) => Promise<void>;

export interface ConsumerOptions {
  queue: string;
  concurrency?: number;
  pollInterval?: number;
}

export interface MessageConsumer {
  register(messageType: string, handler: MessageHandler): void;
  start(options: ConsumerOptions): Promise<void>;
  stop(): Promise<void>;
}

export class BullMQConsumer implements MessageConsumer {
  private handlers: Map<string, MessageHandler> = new Map();
  private workers: any[] = [];
  private running = false;

  register(messageType: string, handler: MessageHandler): void {
    this.handlers.set(messageType, handler);
    console.log(`[mq-consumer] Registered handler: ${messageType}`);
  }

  async start(options: ConsumerOptions): Promise<void> {
    const { Worker } = await import('bullmq');
    const concurrency = options.concurrency || 5;

    const worker = new Worker(
      options.queue,
      async (job) => {
        const message = MessageSchema.parse(job.data);
        const handler = this.handlers.get(message.type);
        if (!handler) {
          console.warn(`[mq-consumer] No handler for: ${message.type}`);
          return;
        }
        try {
          await handler(message);
          console.log(`[mq-consumer] Processed: ${message.type} (${message.id})`);
        } catch (err) {
          console.error(`[mq-consumer] Failed: ${message.type} (${message.id})`, err);
          throw err; // Let BullMQ handle retry
        }
      },
      {
        connection: {
          host: process.env.REDIS_HOST || 'localhost',
          port: parseInt(process.env.REDIS_PORT || '6379'),
          password: process.env.REDIS_PASSWORD || undefined,
          maxRetriesPerRequest: null,
        },
        concurrency,
        limiter: { max: concurrency * 2, duration: 1000 },
      }
    );

    worker.on('failed', (job: any, err: Error) => {
      console.error(`[mq-consumer] Job failed: ${job?.id}`, err.message);
    });

    worker.on('completed', (job: any) => {
      console.log(`[mq-consumer] Job completed: ${job.id}`);
    });

    this.workers.push(worker);
    this.running = true;
    console.log(`[mq-consumer] Started on queue: ${options.queue} (concurrency=${concurrency})`);
  }

  async stop(): Promise<void> {
    this.running = false;
    for (const worker of this.workers) {
      await worker.close();
    }
    this.workers = [];
    console.log('[mq-consumer] Stopped');
  }
}

export function createConsumer(provider?: string): MessageConsumer {
  const p = provider || process.env.MQ_PROVIDER || 'bullmq';
  switch (p) {
    case 'bullmq': return new BullMQConsumer();
    default: throw new Error(`Unsupported MQ provider: ${p}`);
  }
}
CONSEOF
)
    _mqi_write_file "${project_dir}/src/lib/mq/consumer.ts" "$consumer_ts"
    MQI_GENERATED=$((MQI_GENERATED + 1))
    return 0
}

# =============================================================================
# _mqi_generate_dead_letter - デッドレターキュー
# =============================================================================
_mqi_generate_dead_letter() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _mqi_log "Generating dead letter queue handler..."

    local dlq_ts
    dlq_ts=$(cat <<'DLQEOF'
// =============================================================================
// Message Queue - Dead Letter Queue Handler
// Captures permanently failed messages for manual review and retry
// =============================================================================
import { Message } from './producer';

export interface DeadLetterEntry {
  id: string;
  originalQueue: string;
  message: Message;
  error: string;
  attempts: number;
  failedAt: string;
  retriedAt?: string;
}

const deadLetters: Map<string, DeadLetterEntry> = new Map();

export function addToDeadLetter(entry: Omit<DeadLetterEntry, 'id' | 'failedAt'>): string {
  const id = crypto.randomUUID();
  const full: DeadLetterEntry = {
    ...entry,
    id,
    failedAt: new Date().toISOString(),
  };
  deadLetters.set(id, full);
  console.error(`[DLQ] Added: ${entry.message.type} from ${entry.originalQueue} after ${entry.attempts} attempts`);
  return id;
}

export function listDeadLetters(limit = 50): DeadLetterEntry[] {
  return Array.from(deadLetters.values())
    .sort((a, b) => new Date(b.failedAt).getTime() - new Date(a.failedAt).getTime())
    .slice(0, limit);
}

export async function retryDeadLetter(id: string, producer: any): Promise<boolean> {
  const entry = deadLetters.get(id);
  if (!entry) return false;

  try {
    await producer.send(entry.originalQueue, {
      type: entry.message.type,
      payload: entry.message.payload,
      metadata: { correlationId: entry.message.metadata.correlationId },
    });
    entry.retriedAt = new Date().toISOString();
    deadLetters.delete(id);
    console.log(`[DLQ] Retried: ${id}`);
    return true;
  } catch (err) {
    console.error(`[DLQ] Retry failed: ${id}`, err);
    return false;
  }
}

export function removeDeadLetter(id: string): boolean {
  return deadLetters.delete(id);
}

export function getDeadLetterCount(): number {
  return deadLetters.size;
}

export function getDeadLetterStats(): { total: number; byQueue: Record<string, number>; byType: Record<string, number> } {
  const byQueue: Record<string, number> = {};
  const byType: Record<string, number> = {};
  for (const entry of deadLetters.values()) {
    byQueue[entry.originalQueue] = (byQueue[entry.originalQueue] || 0) + 1;
    byType[entry.message.type] = (byType[entry.message.type] || 0) + 1;
  }
  return { total: deadLetters.size, byQueue, byType };
}
DLQEOF
)
    _mqi_write_file "${project_dir}/src/lib/mq/dead-letter.ts" "$dlq_ts"
    MQI_GENERATED=$((MQI_GENERATED + 1))
    return 0
}

# =============================================================================
# パターン注入
# =============================================================================
_mqi_inject_patterns() {
    cat <<'INJECT'

## [Message Queue] メッセージキューパターン

### 必須:
- **プロデューサー**: zodバリデーション + correlationId + メタデータ
- **コンシューマー**: ハンドラレジストリ + 並行制御 + graceful shutdown
- **DLQ**: 最大リトライ超過→DLQ移動→管理画面でリトライ/削除

INJECT
    echo "${1:-}"
}

# =============================================================================
# レポート & スコア
# =============================================================================
mqi_report() {
    echo -e "\n  ${BOLD:-}=== message-queue-integrator v${MQI_VERSION} ===${NC:-}"
    echo -e "  Provider: ${MQI_PROVIDER}"
    echo -e "  生成数: ${MQI_GENERATED}"
    echo -e "  エラー: ${MQI_ERRORS}"
}

mqi_score() {
    if [[ ${MQI_GENERATED} -ge 3 ]] && [[ ${MQI_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${MQI_GENERATED} -gt 0 ]] && [[ ${MQI_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "message-queue-integrator" --version "${MQI_VERSION}" \
        --description "メッセージキュー×プロデューサー×コンシューマー×DLQ" \
        --init "mqi_init" --report "mqi_report" --score "mqi_score" \
        --enable-var "ENABLE_MESSAGE_QUEUE" --cli-flags "--message-queue:--no-message-queue"
fi

# v2003.1: source時のexit codeを確実に0にする
true
