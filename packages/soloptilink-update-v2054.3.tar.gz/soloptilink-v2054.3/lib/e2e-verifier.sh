#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2014.1 - E2E Verifier
# =============================================================================
# Actually runs the generated project and verifies endpoints respond.
#
# Problem solved:
#   SoloptiLinkAI currently only does build checks (npm run build).
#   It never starts the dev server and tests whether pages actually load.
#   This module fills that gap: start server, hit every route, run CRUD
#   smoke tests, then tear down cleanly.
#
# Supported frameworks:
#   - Next.js (npm run dev)
#   - Express / Fastify (node server.js / node index.js)
#   - Flask (flask run / python app.py)
#   - Vite / React (npm run dev)
#   - Django (python manage.py runserver)
#   - Static (npx serve / python -m http.server)
#
# Usage: source e2e-verifier.sh
#        ev_verify_all /path/to/project
# =============================================================================

[[ -n "${_E2E_VERIFIER_LOADED:-}" ]] && return 0
_E2E_VERIFIER_LOADED=1

declare -g EV_VERSION="1.0"

# --- Colour constants --------------------------------------------------------
EV_GREEN='\033[0;32m'  EV_YELLOW='\033[0;33m' EV_RED='\033[0;31m'
EV_CYAN='\033[0;36m'   EV_BOLD='\033[1m'      EV_NC='\033[0m'

# --- Global state ------------------------------------------------------------
declare -g EV_SERVER_PID=""
declare -g EV_SERVER_PORT=""
declare -g EV_PROJECT_TYPE=""
declare -g EV_PROJECT_DIR=""
declare -g EV_WORK_DIR="${HOME}/.soloptilink/e2e-verifier"
declare -g EV_LOG_FILE=""

declare -g EV_CHECKS_TOTAL=0
declare -g EV_CHECKS_PASSED=0
declare -g EV_CHECKS_FAILED=0
declare -g EV_CHECKS_SKIPPED=0
declare -g EV_RESULTS=""          # newline-separated JSON objects
declare -g EV_DISCOVERED_ROUTES="" # newline-separated route list

# --- Constants ---------------------------------------------------------------
EV_PORT_MIN=3100
EV_PORT_MAX=3199
EV_STARTUP_TIMEOUT=15
EV_REQUEST_TIMEOUT=10

# =============================================================================
# Logging
# =============================================================================
_ev_log() {
    local level="$1" msg="$2"
    local ts; ts="$(date '+%H:%M:%S')"
    case "$level" in
        PASS) printf "${EV_GREEN}[EV PASS %s]${EV_NC} %s\n" "$ts" "$msg" ;;
        FAIL) printf "${EV_RED}[EV FAIL %s]${EV_NC} %s\n"   "$ts" "$msg" ;;
        WARN) printf "${EV_YELLOW}[EV WARN %s]${EV_NC} %s\n" "$ts" "$msg" ;;
        INFO) printf "${EV_CYAN}[EV INFO %s]${EV_NC} %s\n"   "$ts" "$msg" ;;
        *)    printf "[EV %s] %s\n" "$ts" "$msg" ;;
    esac
    [[ -n "$EV_LOG_FILE" ]] && echo "[${ts}] ${level}: ${msg}" >> "$EV_LOG_FILE" 2>/dev/null
}

_ev_record() {
    local name="$1" status="$2" detail="${3:-}"
    local entry
    entry=$(printf '{"check":"%s","status":"%s","detail":"%s"}' \
        "$name" "$status" "$(echo "$detail" | sed 's/"/\\"/g')")
    if [[ -z "$EV_RESULTS" ]]; then
        EV_RESULTS="$entry"
    else
        EV_RESULTS="${EV_RESULTS}
${entry}"
    fi
    EV_CHECKS_TOTAL=$((EV_CHECKS_TOTAL + 1))
    case "$status" in
        pass) EV_CHECKS_PASSED=$((EV_CHECKS_PASSED + 1)) ;;
        fail) EV_CHECKS_FAILED=$((EV_CHECKS_FAILED + 1)) ;;
        skip) EV_CHECKS_SKIPPED=$((EV_CHECKS_SKIPPED + 1)) ;;
    esac
}

# =============================================================================
# ev_init - Detect project type, validate directory
# =============================================================================
ev_init() {
    local project_dir="${1:-.}"
    project_dir="$(cd "$project_dir" 2>/dev/null && pwd)" || {
        _ev_log FAIL "Directory not found: $1"
        return 1
    }
    EV_PROJECT_DIR="$project_dir"
    EV_PROJECT_TYPE=""
    EV_SERVER_PID=""
    EV_SERVER_PORT=""
    EV_CHECKS_TOTAL=0
    EV_CHECKS_PASSED=0
    EV_CHECKS_FAILED=0
    EV_CHECKS_SKIPPED=0
    EV_RESULTS=""
    EV_DISCOVERED_ROUTES=""

    mkdir -p "$EV_WORK_DIR" 2>/dev/null || true
    EV_LOG_FILE="${EV_WORK_DIR}/e2e-$(date '+%Y%m%d-%H%M%S').log"

    # Detect project type
    if [[ -f "$project_dir/next.config.js" ]] || [[ -f "$project_dir/next.config.mjs" ]] || [[ -f "$project_dir/next.config.ts" ]]; then
        EV_PROJECT_TYPE="nextjs"
    elif [[ -f "$project_dir/package.json" ]] && grep -q '"express"' "$project_dir/package.json" 2>/dev/null; then
        EV_PROJECT_TYPE="express"
    elif [[ -f "$project_dir/package.json" ]] && grep -q '"fastify"' "$project_dir/package.json" 2>/dev/null; then
        EV_PROJECT_TYPE="fastify"
    elif [[ -f "$project_dir/package.json" ]] && grep -q '"vite"' "$project_dir/package.json" 2>/dev/null; then
        EV_PROJECT_TYPE="vite"
    elif [[ -f "$project_dir/manage.py" ]] && grep -q "django" "$project_dir/manage.py" 2>/dev/null; then
        EV_PROJECT_TYPE="django"
    elif [[ -f "$project_dir/app.py" ]] || [[ -f "$project_dir/wsgi.py" ]]; then
        EV_PROJECT_TYPE="flask"
    elif [[ -f "$project_dir/package.json" ]]; then
        EV_PROJECT_TYPE="node"
    else
        EV_PROJECT_TYPE="unknown"
    fi

    _ev_log INFO "Project: ${EV_PROJECT_DIR}"
    _ev_log INFO "Type: ${EV_PROJECT_TYPE}"
    return 0
}

# =============================================================================
# Port allocation - find a free port in range
# =============================================================================
_ev_find_free_port() {
    local port
    for _ in $(seq 1 20); do
        port=$((EV_PORT_MIN + RANDOM % (EV_PORT_MAX - EV_PORT_MIN + 1)))
        if ! lsof -i :"$port" &>/dev/null 2>&1; then
            echo "$port"
            return 0
        fi
    done
    # Fallback: linear scan
    for port in $(seq $EV_PORT_MIN $EV_PORT_MAX); do
        if ! lsof -i :"$port" &>/dev/null 2>&1; then
            echo "$port"
            return 0
        fi
    done
    return 1
}

# =============================================================================
# ev_start_server - Start dev server in background
# =============================================================================
ev_start_server() {
    local project_dir="${1:-$EV_PROJECT_DIR}"
    [[ -z "$project_dir" ]] && { _ev_log FAIL "No project directory set"; return 1; }

    EV_SERVER_PORT=$(_ev_find_free_port) || {
        _ev_log FAIL "No free port in range ${EV_PORT_MIN}-${EV_PORT_MAX}"
        return 1
    }

    local server_log="${EV_WORK_DIR}/server-${EV_SERVER_PORT}.log"
    local start_cmd=""
    local port_env="PORT=${EV_SERVER_PORT}"

    case "$EV_PROJECT_TYPE" in
        nextjs)
            start_cmd="npx next dev -p ${EV_SERVER_PORT}"
            port_env=""  # port passed via flag
            ;;
        express|fastify|node)
            if [[ -f "$project_dir/server.js" ]]; then
                start_cmd="node server.js"
            elif [[ -f "$project_dir/index.js" ]]; then
                start_cmd="node index.js"
            elif [[ -f "$project_dir/src/index.js" ]]; then
                start_cmd="node src/index.js"
            elif [[ -f "$project_dir/src/server.js" ]]; then
                start_cmd="node src/server.js"
            elif [[ -f "$project_dir/package.json" ]] && grep -q '"start"' "$project_dir/package.json" 2>/dev/null; then
                start_cmd="npm start"
            elif [[ -f "$project_dir/package.json" ]] && grep -q '"dev"' "$project_dir/package.json" 2>/dev/null; then
                start_cmd="npm run dev"
            fi
            ;;
        vite)
            start_cmd="npx vite --port ${EV_SERVER_PORT}"
            port_env=""
            ;;
        flask)
            start_cmd="flask run --port ${EV_SERVER_PORT}"
            port_env="FLASK_APP=${project_dir}/app.py"
            ;;
        django)
            start_cmd="python manage.py runserver ${EV_SERVER_PORT}"
            port_env=""
            ;;
        *)
            # Try npm run dev as fallback
            if [[ -f "$project_dir/package.json" ]] && grep -q '"dev"' "$project_dir/package.json" 2>/dev/null; then
                start_cmd="npm run dev"
            elif [[ -f "$project_dir/package.json" ]] && grep -q '"start"' "$project_dir/package.json" 2>/dev/null; then
                start_cmd="npm start"
            fi
            ;;
    esac

    if [[ -z "$start_cmd" ]]; then
        _ev_log FAIL "Cannot determine start command for type: ${EV_PROJECT_TYPE}"
        return 1
    fi

    _ev_log INFO "Starting server: ${start_cmd} (port ${EV_SERVER_PORT})"

    # Launch in background
    (
        cd "$project_dir" || exit 1
        if [[ -n "$port_env" ]]; then
            env $port_env $start_cmd
        else
            $start_cmd
        fi
    ) > "$server_log" 2>&1 &
    EV_SERVER_PID=$!

    # Wait for server to be ready
    local waited=0
    while [[ $waited -lt $EV_STARTUP_TIMEOUT ]]; do
        # Check if process died
        if ! kill -0 "$EV_SERVER_PID" 2>/dev/null; then
            _ev_log FAIL "Server process exited prematurely (PID: ${EV_SERVER_PID})"
            _ev_log INFO "Server log tail:"
            tail -5 "$server_log" 2>/dev/null | while IFS= read -r line; do
                _ev_log INFO "  $line"
            done
            EV_SERVER_PID=""
            return 1
        fi
        # Check if port is responding
        local http_code
        http_code=$(curl -s -o /dev/null -w "%{http_code}" \
            --connect-timeout 2 --max-time 3 \
            "http://localhost:${EV_SERVER_PORT}/" 2>/dev/null) || true
        if [[ "$http_code" =~ ^(200|301|302|304|404|401|403)$ ]]; then
            _ev_log PASS "Server ready on port ${EV_SERVER_PORT} (${waited}s, HTTP ${http_code})"
            _ev_record "server_start" "pass" "port=${EV_SERVER_PORT} pid=${EV_SERVER_PID} startup=${waited}s"
            return 0
        fi
        sleep 1
        waited=$((waited + 1))
    done

    _ev_log FAIL "Server startup timeout after ${EV_STARTUP_TIMEOUT}s"
    _ev_record "server_start" "fail" "timeout after ${EV_STARTUP_TIMEOUT}s"
    ev_stop_server
    return 1
}

# =============================================================================
# ev_stop_server - Kill background server, cleanup
# =============================================================================
ev_stop_server() {
    if [[ -n "$EV_SERVER_PID" ]]; then
        if kill -0 "$EV_SERVER_PID" 2>/dev/null; then
            _ev_log INFO "Stopping server (PID: ${EV_SERVER_PID})..."
            # Graceful first, then force
            kill "$EV_SERVER_PID" 2>/dev/null || true
            local grace=0
            while kill -0 "$EV_SERVER_PID" 2>/dev/null && [[ $grace -lt 5 ]]; do
                sleep 1
                grace=$((grace + 1))
            done
            if kill -0 "$EV_SERVER_PID" 2>/dev/null; then
                kill -9 "$EV_SERVER_PID" 2>/dev/null || true
            fi
            wait "$EV_SERVER_PID" 2>/dev/null || true
            _ev_log INFO "Server stopped"
        fi
        EV_SERVER_PID=""
    fi
    # Clean up any orphaned processes on the port
    if [[ -n "$EV_SERVER_PORT" ]]; then
        local orphan_pid
        orphan_pid=$(lsof -ti :"$EV_SERVER_PORT" 2>/dev/null) || true
        if [[ -n "$orphan_pid" ]]; then
            kill "$orphan_pid" 2>/dev/null || true
            _ev_log WARN "Killed orphan process on port ${EV_SERVER_PORT}: ${orphan_pid}"
        fi
    fi
}

# Trap to ensure cleanup on script exit
trap 'ev_stop_server' EXIT INT TERM

# =============================================================================
# ev_check_health - Check /api/health endpoint
# =============================================================================
ev_check_health() {
    local port="${1:-$EV_SERVER_PORT}"
    [[ -z "$port" ]] && { _ev_log FAIL "No port specified"; return 1; }

    local url="http://localhost:${port}/api/health"
    local http_code body

    http_code=$(curl -s -o /dev/null -w "%{http_code}" \
        --connect-timeout 5 --max-time "$EV_REQUEST_TIMEOUT" \
        "$url" 2>/dev/null) || true

    if [[ "$http_code" == "200" ]]; then
        body=$(curl -s --max-time "$EV_REQUEST_TIMEOUT" "$url" 2>/dev/null) || true
        _ev_log PASS "Health check: ${url} -> ${http_code}"
        _ev_record "health_check" "pass" "${url} HTTP ${http_code}"
        return 0
    elif [[ "$http_code" == "404" ]]; then
        _ev_log WARN "Health endpoint not found: ${url} (404) - skipping"
        _ev_record "health_check" "skip" "No /api/health endpoint"
        return 0
    else
        _ev_log FAIL "Health check failed: ${url} -> ${http_code}"
        _ev_record "health_check" "fail" "${url} HTTP ${http_code}"
        return 1
    fi
}

# =============================================================================
# ev_check_pages - Check that page URLs return successful status codes
# =============================================================================
ev_check_pages() {
    local port="${1:-$EV_SERVER_PORT}"
    shift 2>/dev/null || true
    local pages_list=("$@")

    [[ -z "$port" ]] && { _ev_log FAIL "No port specified"; return 1; }

    # Default pages if none provided
    if [[ ${#pages_list[@]} -eq 0 ]]; then
        pages_list=("/")
        # Add discovered routes
        if [[ -n "$EV_DISCOVERED_ROUTES" ]]; then
            while IFS= read -r route; do
                [[ -n "$route" ]] && pages_list+=("$route")
            done <<< "$EV_DISCOVERED_ROUTES"
        fi
    fi

    local all_pass=0
    local base="http://localhost:${port}"

    for page in "${pages_list[@]}"; do
        [[ -z "$page" ]] && continue
        local url="${base}${page}"
        local http_code

        http_code=$(curl -s -o /dev/null -w "%{http_code}" \
            --connect-timeout 5 --max-time "$EV_REQUEST_TIMEOUT" \
            -L "$url" 2>/dev/null) || http_code="000"

        if [[ "$http_code" =~ ^(200|301|302|304)$ ]]; then
            _ev_log PASS "Page OK: ${page} -> ${http_code}"
            _ev_record "page:${page}" "pass" "HTTP ${http_code}"
        elif [[ "$http_code" == "401" ]] || [[ "$http_code" == "403" ]]; then
            # v2016.0: 認可ガードでも未実装か区別がつかないため、
            # EV_TREAT_AUTH_AS_FAIL=1 が設定されていれば FAIL 扱いにする
            if [[ "${EV_TREAT_AUTH_AS_FAIL:-0}" == "1" ]]; then
                _ev_log FAIL "Page auth-guarded but treated as FAIL: ${page} -> ${http_code}"
                _ev_record "page:${page}" "fail" "HTTP ${http_code} (auth required, strict mode)"
                all_pass=1
            else
                _ev_log WARN "Page auth-guarded: ${page} -> ${http_code} (expected for protected routes)"
                _ev_record "page:${page}" "pass" "HTTP ${http_code} (auth required)"
            fi
        elif [[ "$http_code" == "404" ]]; then
            # v2016.0: 404 は「ルート未実装」を意味するため確実に FAIL
            _ev_log FAIL "Page NOT FOUND: ${page} -> 404 (route not implemented)"
            _ev_record "page:${page}" "fail" "HTTP 404 (route_not_implemented)"
            all_pass=1
        else
            _ev_log FAIL "Page error: ${page} -> ${http_code}"
            _ev_record "page:${page}" "fail" "HTTP ${http_code}"
            all_pass=1
        fi
    done
    return $all_pass
}

# =============================================================================
# ev_check_api_crud - Run CRUD smoke test against a resource endpoint
# =============================================================================
ev_check_api_crud() {
    local port="${1:-$EV_SERVER_PORT}"
    local endpoint="${2:-}"
    [[ -z "$port" ]] || [[ -z "$endpoint" ]] && {
        _ev_log FAIL "Usage: ev_check_api_crud <port> <endpoint>"
        return 1
    }

    local base="http://localhost:${port}${endpoint}"
    local crud_pass=0
    local created_id=""

    # POST - Create
    local post_code post_body
    post_body=$(curl -s -w "\n%{http_code}" \
        --connect-timeout 5 --max-time "$EV_REQUEST_TIMEOUT" \
        -X POST -H "Content-Type: application/json" \
        -d '{"name":"e2e-test-item","description":"Created by E2E verifier"}' \
        "$base" 2>/dev/null) || post_body="
000"
    post_code=$(echo "$post_body" | tail -1)
    post_body=$(echo "$post_body" | sed '$d')

    if [[ "$post_code" =~ ^(200|201)$ ]]; then
        _ev_log PASS "CRUD POST ${endpoint} -> ${post_code}"
        _ev_record "crud:post:${endpoint}" "pass" "HTTP ${post_code}"
        # Extract ID from response (try common patterns)
        created_id=$(echo "$post_body" | grep -oE '"id"\s*:\s*"[^"]*"' | head -1 | grep -oE '"[^"]*"$' | tr -d '"') || true
        [[ -z "$created_id" ]] && created_id=$(echo "$post_body" | grep -oE '"id"\s*:\s*[0-9]+' | head -1 | grep -oE '[0-9]+$') || true
    else
        _ev_log FAIL "CRUD POST ${endpoint} -> ${post_code}"
        _ev_record "crud:post:${endpoint}" "fail" "HTTP ${post_code}"
        crud_pass=1
    fi

    # GET - List
    local get_code
    get_code=$(curl -s -o /dev/null -w "%{http_code}" \
        --connect-timeout 5 --max-time "$EV_REQUEST_TIMEOUT" \
        "$base" 2>/dev/null) || get_code="000"

    if [[ "$get_code" == "200" ]]; then
        _ev_log PASS "CRUD GET ${endpoint} -> ${get_code}"
        _ev_record "crud:get:${endpoint}" "pass" "HTTP ${get_code}"
    else
        _ev_log FAIL "CRUD GET ${endpoint} -> ${get_code}"
        _ev_record "crud:get:${endpoint}" "fail" "HTTP ${get_code}"
        crud_pass=1
    fi

    # If we have an ID, test single-resource operations
    if [[ -n "$created_id" ]]; then
        local item_url="${base}/${created_id}"

        # GET - Single item
        local get_one_code
        get_one_code=$(curl -s -o /dev/null -w "%{http_code}" \
            --connect-timeout 5 --max-time "$EV_REQUEST_TIMEOUT" \
            "$item_url" 2>/dev/null) || get_one_code="000"

        if [[ "$get_one_code" == "200" ]]; then
            _ev_log PASS "CRUD GET ${endpoint}/${created_id} -> ${get_one_code}"
            _ev_record "crud:get-one:${endpoint}" "pass" "HTTP ${get_one_code}"
        else
            _ev_log FAIL "CRUD GET ${endpoint}/${created_id} -> ${get_one_code}"
            _ev_record "crud:get-one:${endpoint}" "fail" "HTTP ${get_one_code}"
            crud_pass=1
        fi

        # PUT - Update
        local put_code
        put_code=$(curl -s -o /dev/null -w "%{http_code}" \
            --connect-timeout 5 --max-time "$EV_REQUEST_TIMEOUT" \
            -X PUT -H "Content-Type: application/json" \
            -d '{"name":"e2e-test-updated","description":"Updated by E2E verifier"}' \
            "$item_url" 2>/dev/null) || put_code="000"

        if [[ "$put_code" == "200" ]]; then
            _ev_log PASS "CRUD PUT ${endpoint}/${created_id} -> ${put_code}"
            _ev_record "crud:put:${endpoint}" "pass" "HTTP ${put_code}"
        else
            _ev_log FAIL "CRUD PUT ${endpoint}/${created_id} -> ${put_code}"
            _ev_record "crud:put:${endpoint}" "fail" "HTTP ${put_code}"
            crud_pass=1
        fi

        # DELETE
        local del_code
        del_code=$(curl -s -o /dev/null -w "%{http_code}" \
            --connect-timeout 5 --max-time "$EV_REQUEST_TIMEOUT" \
            -X DELETE "$item_url" 2>/dev/null) || del_code="000"

        if [[ "$del_code" =~ ^(200|204)$ ]]; then
            _ev_log PASS "CRUD DELETE ${endpoint}/${created_id} -> ${del_code}"
            _ev_record "crud:delete:${endpoint}" "pass" "HTTP ${del_code}"
        else
            _ev_log FAIL "CRUD DELETE ${endpoint}/${created_id} -> ${del_code}"
            _ev_record "crud:delete:${endpoint}" "fail" "HTTP ${del_code}"
            crud_pass=1
        fi

        # Verify deletion - GET should return 404
        local verify_code
        verify_code=$(curl -s -o /dev/null -w "%{http_code}" \
            --connect-timeout 5 --max-time "$EV_REQUEST_TIMEOUT" \
            "$item_url" 2>/dev/null) || verify_code="000"

        if [[ "$verify_code" == "404" ]]; then
            _ev_log PASS "CRUD verify-deleted ${endpoint}/${created_id} -> 404"
            _ev_record "crud:verify-deleted:${endpoint}" "pass" "HTTP 404 (correctly gone)"
        else
            _ev_log WARN "CRUD verify-deleted ${endpoint}/${created_id} -> ${verify_code} (expected 404)"
            _ev_record "crud:verify-deleted:${endpoint}" "fail" "HTTP ${verify_code} (expected 404)"
            crud_pass=1
        fi
    else
        _ev_log WARN "No ID extracted from POST response - skipping single-item CRUD"
        _ev_record "crud:single-item:${endpoint}" "skip" "No ID from POST response"
    fi

    return $crud_pass
}

# =============================================================================
# ev_auto_discover_routes - Scan project for API and page routes
# =============================================================================
ev_auto_discover_routes() {
    local project_dir="${1:-$EV_PROJECT_DIR}"
    [[ -z "$project_dir" ]] && return 1

    local routes=""

    case "$EV_PROJECT_TYPE" in
        nextjs)
            # App Router: app/**/page.{tsx,ts,jsx,js} -> page routes
            if [[ -d "$project_dir/app" ]]; then
                while IFS= read -r file; do
                    [[ -z "$file" ]] && continue
                    local route
                    route=$(echo "$file" | sed "s|^${project_dir}/app||")
                    route="${route%/page.tsx}"; route="${route%/page.ts}"
                    route="${route%/page.jsx}"; route="${route%/page.js}"
                    [[ -z "$route" ]] && route="/"
                    [[ "$route" == *"["* ]] && continue
                    routes="${routes}${route}
"
                done < <(find "$project_dir/app" \( -name "page.tsx" -o -name "page.ts" -o -name "page.jsx" -o -name "page.js" \) -type f 2>/dev/null)

                # App Router: app/api/**/route.{ts,js} -> API routes
                while IFS= read -r file; do
                    [[ -z "$file" ]] && continue
                    local route
                    route=$(echo "$file" | sed "s|^${project_dir}/app||")
                    route="${route%/route.tsx}"; route="${route%/route.ts}"
                    route="${route%/route.jsx}"; route="${route%/route.js}"
                    [[ "$route" == *"["* ]] && continue
                    routes="${routes}${route}
"
                done < <(find "$project_dir/app/api" \( -name "route.ts" -o -name "route.js" \) -type f 2>/dev/null)
            fi

            # Pages Router: pages/**/*.{tsx,ts,jsx,js}
            if [[ -d "$project_dir/pages" ]]; then
                while IFS= read -r file; do
                    [[ -z "$file" ]] && continue
                    local route
                    route=$(echo "$file" | sed "s|^${project_dir}/pages||")
                    route="${route%.tsx}"; route="${route%.ts}"
                    route="${route%.jsx}"; route="${route%.js}"
                    route="${route%/index}"
                    [[ -z "$route" ]] && route="/"
                    [[ "$route" == *"["* ]] && continue
                    [[ "$route" == *"_app"* ]] && continue
                    [[ "$route" == *"_document"* ]] && continue
                    routes="${routes}${route}
"
                done < <(find "$project_dir/pages" \( -name "*.tsx" -o -name "*.ts" -o -name "*.jsx" -o -name "*.js" \) -type f 2>/dev/null)
            fi
            ;;

        express|fastify|node)
            # Scan for route definitions: app.get('/path', ...) or router.get('/path', ...)
            local route_patterns
            route_patterns=$(grep -rhoE "(app|router)\.(get|post|put|delete|patch)\(['\"][^'\"]*['\"]" \
                "$project_dir" --include="*.js" --include="*.ts" 2>/dev/null | \
                grep -oE "['\"][^'\"]*['\"]" | tr -d "'" | tr -d '"' | sort -u) || true
            while IFS= read -r route; do
                [[ -z "$route" ]] && continue
                [[ "$route" == *":"* ]] && continue  # skip parameterized
                routes="${routes}${route}
"
            done <<< "$route_patterns"
            ;;

        flask)
            # Scan for @app.route('/path')
            local flask_routes
            flask_routes=$(grep -rhoE "@app\.route\(['\"][^'\"]*['\"]" \
                "$project_dir" --include="*.py" 2>/dev/null | \
                grep -oE "['\"][^'\"]*['\"]" | tr -d "'" | tr -d '"' | sort -u) || true
            while IFS= read -r route; do
                [[ -z "$route" ]] && continue
                [[ "$route" == *"<"* ]] && continue  # skip parameterized
                routes="${routes}${route}
"
            done <<< "$flask_routes"
            ;;

        django)
            # Scan for path('route', ...)
            local django_routes
            django_routes=$(grep -rhoE "path\(['\"][^'\"]*['\"]" \
                "$project_dir" --include="*.py" 2>/dev/null | \
                grep -oE "['\"][^'\"]*['\"]" | tr -d "'" | tr -d '"' | sort -u) || true
            while IFS= read -r route; do
                [[ -z "$route" ]] && continue
                [[ "$route" == *"<"* ]] && continue
                [[ "$route" != /* ]] && route="/${route}"
                routes="${routes}${route}
"
            done <<< "$django_routes"
            ;;
    esac

    # Deduplicate and store
    EV_DISCOVERED_ROUTES=$(echo "$routes" | sort -u | sed '/^$/d')
    local count
    count=$(echo "$EV_DISCOVERED_ROUTES" | grep -c . 2>/dev/null) || count=0

    _ev_log INFO "Discovered ${count} routes for type ${EV_PROJECT_TYPE}"
    if [[ $count -gt 0 ]]; then
        echo "$EV_DISCOVERED_ROUTES" | head -20 | while IFS= read -r r; do
            _ev_log INFO "  -> ${r}"
        done
        [[ $count -gt 20 ]] && _ev_log INFO "  ... and $((count - 20)) more"
    fi

    echo "$EV_DISCOVERED_ROUTES"
}

# =============================================================================
# ev_verify_all - Full pipeline: init -> start -> health -> pages -> API -> stop
# =============================================================================
ev_verify_all() {
    local project_dir="${1:-$EV_PROJECT_DIR}"
    [[ -z "$project_dir" ]] && { _ev_log FAIL "No project directory"; return 1; }

    echo ""
    _ev_log INFO "========================================="
    _ev_log INFO "E2E Verifier v${EV_VERSION} - Full Pipeline"
    _ev_log INFO "========================================="

    # Phase 1: Init
    _ev_log INFO "[1/5] Initializing..."
    ev_init "$project_dir" || { _ev_log FAIL "Init failed"; return 1; }

    # Phase 2: Discover routes
    _ev_log INFO "[2/5] Discovering routes..."
    ev_auto_discover_routes "$project_dir" >/dev/null

    # Phase 3: Start server
    _ev_log INFO "[3/5] Starting dev server..."
    if ! ev_start_server "$project_dir"; then
        _ev_log FAIL "Server failed to start - cannot continue E2E checks"
        ev_report
        return 1
    fi

    # Phase 4: Health check
    _ev_log INFO "[4/5] Running health & page checks..."
    ev_check_health "$EV_SERVER_PORT"
    ev_check_pages "$EV_SERVER_PORT"

    # Phase 5: API CRUD (if API routes discovered)
    _ev_log INFO "[5/5] Running API CRUD tests..."
    local api_routes
    api_routes=$(echo "$EV_DISCOVERED_ROUTES" | grep "^/api/" | grep -v "/health$" | head -5) || true
    if [[ -n "$api_routes" ]]; then
        while IFS= read -r api_route; do
            [[ -z "$api_route" ]] && continue
            _ev_log INFO "CRUD test: ${api_route}"
            ev_check_api_crud "$EV_SERVER_PORT" "$api_route" || true
        done <<< "$api_routes"
    else
        _ev_log WARN "No API routes discovered for CRUD testing"
        _ev_record "crud_discovery" "skip" "No API routes found"
    fi

    # Cleanup
    ev_stop_server

    # Report
    ev_report
    return $EV_CHECKS_FAILED
}

# =============================================================================
# ev_report - Summary of all checks as structured output
# =============================================================================
ev_report() {
    echo ""
    _ev_log INFO "========================================="
    _ev_log INFO "E2E Verification Report"
    _ev_log INFO "========================================="
    _ev_log INFO "Project: ${EV_PROJECT_DIR}"
    _ev_log INFO "Type:    ${EV_PROJECT_TYPE}"
    _ev_log INFO "Port:    ${EV_SERVER_PORT:-N/A}"
    echo ""

    if [[ $EV_CHECKS_PASSED -gt 0 ]]; then
        printf "  ${EV_GREEN}PASSED: %d${EV_NC}\n" "$EV_CHECKS_PASSED"
    fi
    if [[ $EV_CHECKS_FAILED -gt 0 ]]; then
        printf "  ${EV_RED}FAILED: %d${EV_NC}\n" "$EV_CHECKS_FAILED"
    fi
    if [[ $EV_CHECKS_SKIPPED -gt 0 ]]; then
        printf "  ${EV_YELLOW}SKIPPED: %d${EV_NC}\n" "$EV_CHECKS_SKIPPED"
    fi
    printf "  TOTAL:  %d\n" "$EV_CHECKS_TOTAL"
    echo ""

    # Emit JSON summary to stdout and log
    local json_report
    json_report=$(printf '{"version":"%s","project":"%s","type":"%s","total":%d,"passed":%d,"failed":%d,"skipped":%d,"checks":[%s]}' \
        "$EV_VERSION" \
        "$EV_PROJECT_DIR" \
        "$EV_PROJECT_TYPE" \
        "$EV_CHECKS_TOTAL" \
        "$EV_CHECKS_PASSED" \
        "$EV_CHECKS_FAILED" \
        "$EV_CHECKS_SKIPPED" \
        "$(echo "$EV_RESULTS" | paste -sd ',' -)")

    if [[ -n "$EV_LOG_FILE" ]]; then
        echo "$json_report" >> "$EV_LOG_FILE"
        _ev_log INFO "Log: ${EV_LOG_FILE}"
    fi

    # Print JSON to stdout for pipeline consumption
    echo "$json_report"

    if [[ $EV_CHECKS_FAILED -eq 0 ]] && [[ $EV_CHECKS_TOTAL -gt 0 ]]; then
        printf "\n  ${EV_GREEN}${EV_BOLD}E2E verification PASSED${EV_NC}\n\n"
    elif [[ $EV_CHECKS_TOTAL -eq 0 ]]; then
        printf "\n  ${EV_YELLOW}${EV_BOLD}No checks executed${EV_NC}\n\n"
    else
        printf "\n  ${EV_RED}${EV_BOLD}E2E verification FAILED (%d issues)${EV_NC}\n\n" "$EV_CHECKS_FAILED"
    fi
}
