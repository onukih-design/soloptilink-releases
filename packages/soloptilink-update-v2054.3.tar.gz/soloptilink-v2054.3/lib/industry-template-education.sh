#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v374.0 - Industry Template: Education
# =============================================================================
# 教育/LMS特化テンプレートエンジン。
# コース管理/進捗追跡/クイズ/証明書発行等の教育必須コンポーネントを自動生成。
#
# All globals use the ITED_ prefix.
# =============================================================================

[[ -n "${_INDUSTRY_TEMPLATE_EDUCATION_LOADED:-}" ]] && return 0
_INDUSTRY_TEMPLATE_EDUCATION_LOADED=1

declare -g ITED_VERSION="374.0"
declare -g ITED_INITIALIZED=false
declare -g ITED_GENERATED_COUNT=0
declare -g ITED_COURSE_GENERATED=false
declare -g ITED_PROGRESS_GENERATED=false
declare -g ITED_QUIZ_GENERATED=false
declare -g ITED_CERTIFICATE_GENERATED=false
declare -g ENABLE_ITED="${ENABLE_ITED:-true}"

_ited_init() {
    ITED_INITIALIZED=true
    ITED_GENERATED_COUNT=0
    return 0
}

_ited_generate_education() {
    local project_dir="${1:-.}"
    [[ "$ITED_INITIALIZED" != "true" ]] && _ited_init

    echo -e "  ${CYAN:-\033[0;36m}[ITED]${NC:-\033[0m} 教育業界テンプレート生成開始..." >&2

    _ited_generate_course "$project_dir"
    _ited_generate_progress "$project_dir"
    _ited_generate_quiz "$project_dir"
    _ited_generate_certificate "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[ITED]${NC:-\033[0m} 教育業界テンプレート生成完了: ${ITED_GENERATED_COUNT}件" >&2
    return 0
}

# =============================================================================
# コース管理テンプレート
# =============================================================================
_ited_generate_course() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITED-COURSE] コース管理テンプレート

### Prisma Schema
```prisma
model Course {
  id          String   @id @default(cuid())
  title       String
  slug        String   @unique
  description String?  @db.Text
  thumbnail   String?
  instructorId String
  instructor  User     @relation(fields: [instructorId], references: [id])
  categoryId  String?
  price       Int      @default(0)
  status      String   @default("draft")
  level       String   @default("beginner")
  sections    Section[]
  enrollments Enrollment[]
  reviews     CourseReview[]
  tags        String[]
  estimatedHours Float?
  publishedAt DateTime?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  @@index([status])
  @@index([instructorId])
}

model Section {
  id       String   @id @default(cuid())
  courseId  String
  course   Course   @relation(fields: [courseId], references: [id], onDelete: Cascade)
  title    String
  sortOrder Int
  lessons  Lesson[]
  @@index([courseId])
}

model Lesson {
  id          String   @id @default(cuid())
  sectionId   String
  section     Section  @relation(fields: [sectionId], references: [id], onDelete: Cascade)
  title       String
  type        String   @default("video")
  content     String?  @db.Text
  videoUrl    String?
  duration    Int?
  sortOrder   Int
  isFree      Boolean  @default(false)
  completions LessonCompletion[]
  @@index([sectionId])
}
```

### Course Catalog
```tsx
'use client';
export function CourseCatalog() {
  const [category, setCategory] = useState('all');
  const [level, setLevel] = useState('all');
  const { data, isLoading } = useSWR(`/api/courses?category=${category}&level=${level}`);

  if (isLoading) return <CourseCatalogSkeleton />;
  if (!data?.courses?.length) return <EmptyState message="コースが見つかりません" />;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {data.courses.map((course: Course) => (
        <CourseCard key={course.id} course={course} />
      ))}
    </div>
  );
}
```
TEMPLATE

    ITED_COURSE_GENERATED=true
    ITED_GENERATED_COUNT=$((ITED_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# 進捗追跡テンプレート
# =============================================================================
_ited_generate_progress() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITED-PROGRESS] 進捗追跡テンプレート

### Schema
```prisma
model Enrollment {
  id          String   @id @default(cuid())
  userId      String
  courseId     String
  course      Course   @relation(fields: [courseId], references: [id])
  status      String   @default("active")
  progress    Float    @default(0)
  startedAt   DateTime @default(now())
  completedAt DateTime?
  @@unique([userId, courseId])
}

model LessonCompletion {
  id        String   @id @default(cuid())
  userId    String
  lessonId  String
  lesson    Lesson   @relation(fields: [lessonId], references: [id])
  completedAt DateTime @default(now())
  @@unique([userId, lessonId])
}
```

### Progress Calculation
```typescript
export async function updateCourseProgress(userId: string, courseId: string): Promise<number> {
  const totalLessons = await prisma.lesson.count({
    where: { section: { courseId } },
  });
  const completedLessons = await prisma.lessonCompletion.count({
    where: { userId, lesson: { section: { courseId } } },
  });
  const progress = totalLessons > 0 ? (completedLessons / totalLessons) * 100 : 0;
  await prisma.enrollment.update({
    where: { userId_courseId: { userId, courseId } },
    data: {
      progress,
      completedAt: progress >= 100 ? new Date() : null,
      status: progress >= 100 ? 'completed' : 'active',
    },
  });
  if (progress >= 100) await issueCertificate(userId, courseId);
  return progress;
}
```
TEMPLATE

    ITED_PROGRESS_GENERATED=true
    ITED_GENERATED_COUNT=$((ITED_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# クイズテンプレート
# =============================================================================
_ited_generate_quiz() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITED-QUIZ] クイズテンプレート

### Schema
```prisma
model Quiz {
  id        String   @id @default(cuid())
  lessonId  String?
  title     String
  passingScore Int  @default(70)
  timeLimit Int?
  questions QuizQuestion[]
  attempts  QuizAttempt[]
}

model QuizQuestion {
  id       String @id @default(cuid())
  quizId   String
  quiz     Quiz   @relation(fields: [quizId], references: [id], onDelete: Cascade)
  type     String @default("multiple_choice")
  question String
  options  Json
  correctAnswer Json
  points   Int    @default(1)
  sortOrder Int
}

model QuizAttempt {
  id        String   @id @default(cuid())
  quizId    String
  quiz      Quiz     @relation(fields: [quizId], references: [id])
  userId    String
  answers   Json
  score     Int
  passed    Boolean
  startedAt DateTime @default(now())
  completedAt DateTime?
}
```

### Quiz Component
```tsx
'use client';
export function QuizPlayer({ quizId }: { quizId: string }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const { data: quiz, isLoading } = useSWR(`/api/quizzes/${quizId}`);

  const handleAnswer = (questionId: string, answer: any) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  const handleSubmit = async () => {
    const res = await fetch(`/api/quizzes/${quizId}/submit`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ answers }),
    });
    const result = await res.json();
    if (result.passed) toast.success(`合格！ スコア: ${result.score}%`);
    else toast.error(`不合格 スコア: ${result.score}% (合格ライン: ${quiz.passingScore}%)`);
  };

  if (isLoading) return <QuizSkeleton />;
  const question = quiz.questions[currentIndex];
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <ProgressBar current={currentIndex + 1} total={quiz.questions.length} />
      <QuestionCard question={question} answer={answers[question.id]} onAnswer={(a) => handleAnswer(question.id, a)} />
      <div className="flex justify-between">
        <Button variant="outline" onClick={() => setCurrentIndex(i => i - 1)} disabled={currentIndex === 0}>前へ</Button>
        {currentIndex < quiz.questions.length - 1
          ? <Button onClick={() => setCurrentIndex(i => i + 1)}>次へ</Button>
          : <Button onClick={handleSubmit}>提出</Button>}
      </div>
    </div>
  );
}
```
TEMPLATE

    ITED_QUIZ_GENERATED=true
    ITED_GENERATED_COUNT=$((ITED_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# 証明書発行テンプレート
# =============================================================================
_ited_generate_certificate() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITED-CERTIFICATE] 証明書発行テンプレート

### Schema
```prisma
model Certificate {
  id          String   @id @default(cuid())
  userId      String
  courseId     String
  certificateNumber String @unique
  issuedAt    DateTime @default(now())
  pdfUrl      String?
  verifyUrl   String?
  @@unique([userId, courseId])
}
```

### Certificate Generation
```typescript
export async function issueCertificate(userId: string, courseId: string) {
  const [user, course] = await Promise.all([
    prisma.user.findUniqueOrThrow({ where: { id: userId } }),
    prisma.course.findUniqueOrThrow({ where: { id: courseId } }),
  ]);
  const certNumber = `CERT-${Date.now()}-${randomBytes(4).toString('hex').toUpperCase()}`;
  const cert = await prisma.certificate.create({
    data: { userId, courseId, certificateNumber: certNumber,
      verifyUrl: `${process.env.NEXT_PUBLIC_URL}/verify/${certNumber}` },
  });
  return cert;
}
```
TEMPLATE

    ITED_CERTIFICATE_GENERATED=true
    ITED_GENERATED_COUNT=$((ITED_GENERATED_COUNT + 1))
    return 0
}

_ited_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Industry Template: Education v${ITED_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成テンプレート数 : ${ITED_GENERATED_COUNT}"
    echo -e "  Course             : ${ITED_COURSE_GENERATED}"
    echo -e "  Progress           : ${ITED_PROGRESS_GENERATED}"
    echo -e "  Quiz               : ${ITED_QUIZ_GENERATED}"
    echo -e "  Certificate        : ${ITED_CERTIFICATE_GENERATED}"
}

_ited_score() {
    local score=30
    [[ "$ITED_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$ITED_COURSE_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITED_PROGRESS_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITED_QUIZ_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITED_CERTIFICATE_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "industry-template-education" \
    --version "374.0" \
    --description "教育業界テンプレート（コース/進捗/クイズ/証明書）" \
    --init "_ited_init" \
    --report "_ited_report" \
    --score "_ited_score" \
    --enable-var "ENABLE_ITED" \
    --cli-flags "--industry-education:--no-industry-education"
