#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v372.0 - Industry Template: EC (E-Commerce)
# =============================================================================
# EC特化テンプレートエンジン。
# Product/Cart/Payment/Shipping/Review/Inventory等のEC必須コンポーネントを
# ドメイン知識ベースで自動生成する。
#
# Functions:
#   _ite_init               - 初期化
#   _ite_generate_ec        - EC全体テンプレート生成
#   _ite_generate_product   - 商品管理テンプレート
#   _ite_generate_cart      - カート/チェックアウトテンプレート
#   _ite_generate_payment   - 決済テンプレート
#   _ite_generate_shipping  - 配送管理テンプレート
#   _ite_generate_inventory - 在庫管理テンプレート
#   _ite_report             - レポート出力
#   _ite_score              - モジュールスコア(0-100)
#
# All globals use the ITE_ prefix.
# =============================================================================

[[ -n "${_INDUSTRY_TEMPLATE_EC_LOADED:-}" ]] && return 0
_INDUSTRY_TEMPLATE_EC_LOADED=1

declare -g ITE_VERSION="372.0"
declare -g ITE_INITIALIZED=false
declare -g ITE_GENERATED_COUNT=0
declare -g ITE_PRODUCT_GENERATED=false
declare -g ITE_CART_GENERATED=false
declare -g ITE_PAYMENT_GENERATED=false
declare -g ITE_SHIPPING_GENERATED=false
declare -g ITE_INVENTORY_GENERATED=false
declare -g ENABLE_ITE="${ENABLE_ITE:-true}"

_ite_init() {
    ITE_INITIALIZED=true
    ITE_GENERATED_COUNT=0
    return 0
}

# =============================================================================
# EC全体テンプレート生成
# =============================================================================
_ite_generate_ec() {
    local project_dir="${1:-.}"
    [[ "$ITE_INITIALIZED" != "true" ]] && _ite_init

    echo -e "  ${CYAN:-\033[0;36m}[ITE]${NC:-\033[0m} EC業界テンプレート生成開始..." >&2

    _ite_generate_product "$project_dir"
    _ite_generate_cart "$project_dir"
    _ite_generate_payment "$project_dir"
    _ite_generate_shipping "$project_dir"
    _ite_generate_inventory "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[ITE]${NC:-\033[0m} EC業界テンプレート生成完了: ${ITE_GENERATED_COUNT}件" >&2
    return 0
}

# =============================================================================
# 商品管理テンプレート
# =============================================================================
_ite_generate_product() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITE-PRODUCT] 商品管理テンプレート

### Prisma Schema
```prisma
model Product {
  id          String   @id @default(cuid())
  name        String
  slug        String   @unique
  description String?  @db.Text
  price       Int
  compareAtPrice Int?
  sku         String?  @unique
  barcode     String?
  weight      Float?
  status      String   @default("draft")
  categoryId  String?
  category    Category? @relation(fields: [categoryId], references: [id])
  images      ProductImage[]
  variants    ProductVariant[]
  reviews     Review[]
  cartItems   CartItem[]
  orderItems  OrderItem[]
  inventory   Inventory?
  tags        String[]
  metadata    Json     @default("{}")
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  @@index([status])
  @@index([categoryId])
  @@fulltext([name, description])
}

model ProductVariant {
  id        String @id @default(cuid())
  productId String
  product   Product @relation(fields: [productId], references: [id], onDelete: Cascade)
  name      String
  sku       String  @unique
  price     Int
  stock     Int     @default(0)
  options   Json
  @@index([productId])
}

model Category {
  id       String    @id @default(cuid())
  name     String
  slug     String    @unique
  parentId String?
  parent   Category? @relation("CategoryTree", fields: [parentId], references: [id])
  children Category[] @relation("CategoryTree")
  products Product[]
  sortOrder Int      @default(0)
}

model ProductImage {
  id        String  @id @default(cuid())
  productId String
  product   Product @relation(fields: [productId], references: [id], onDelete: Cascade)
  url       String
  alt       String?
  sortOrder Int     @default(0)
  @@index([productId])
}
```

### Product List with Filters
```tsx
'use client';
import useSWR from 'swr';
import { useState } from 'react';

export function ProductGrid({ categorySlug }: { categorySlug?: string }) {
  const [sort, setSort] = useState('newest');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100000]);
  const params = new URLSearchParams({ sort, minPrice: String(priceRange[0]), maxPrice: String(priceRange[1]) });
  if (categorySlug) params.set('category', categorySlug);

  const { data, error, isLoading } = useSWR(`/api/products?${params}`);

  if (isLoading) return <ProductGridSkeleton />;
  if (error) return <ErrorMessage message="商品の読み込みに失敗しました" />;
  if (!data?.products?.length) return <EmptyState message="商品が見つかりません" />;

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {data.products.map((product: Product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
```
TEMPLATE

    ITE_PRODUCT_GENERATED=true
    ITE_GENERATED_COUNT=$((ITE_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# カート/チェックアウトテンプレート
# =============================================================================
_ite_generate_cart() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITE-CART] カート/チェックアウトテンプレート

### Cart Context
```typescript
'use client';
import { createContext, useContext, useReducer } from 'react';

interface CartItem { productId: string; variantId?: string; quantity: number; price: number; name: string; image?: string; }
type CartAction = { type: 'ADD'; item: CartItem } | { type: 'REMOVE'; productId: string } | { type: 'UPDATE_QTY'; productId: string; quantity: number } | { type: 'CLEAR' };

function cartReducer(state: CartItem[], action: CartAction): CartItem[] {
  switch (action.type) {
    case 'ADD': {
      const existing = state.find(i => i.productId === action.item.productId);
      if (existing) return state.map(i => i.productId === action.item.productId ? { ...i, quantity: i.quantity + action.item.quantity } : i);
      return [...state, action.item];
    }
    case 'REMOVE': return state.filter(i => i.productId !== action.productId);
    case 'UPDATE_QTY': return state.map(i => i.productId === action.productId ? { ...i, quantity: action.quantity } : i).filter(i => i.quantity > 0);
    case 'CLEAR': return [];
  }
}

const CartContext = createContext<{ items: CartItem[]; dispatch: React.Dispatch<CartAction>; total: number } | null>(null);
export function useCart() { const ctx = useContext(CartContext); if (!ctx) throw new Error('useCart must be within CartProvider'); return ctx; }
```

### Checkout Flow
```typescript
export async function processCheckout(cartItems: CartItem[], shippingInfo: ShippingInfo) {
  const order = await prisma.$transaction(async (tx) => {
    // 1. 在庫確認
    for (const item of cartItems) {
      const inventory = await tx.inventory.findUnique({ where: { productId: item.productId } });
      if (!inventory || inventory.stock < item.quantity) throw new Error(`在庫不足: ${item.name}`);
    }
    // 2. 注文作成
    const order = await tx.order.create({
      data: { status: 'pending', subtotal: calcSubtotal(cartItems), tax: calcTax(cartItems), shipping: calcShipping(shippingInfo), total: calcTotal(cartItems, shippingInfo),
        items: { create: cartItems.map(i => ({ productId: i.productId, quantity: i.quantity, unitPrice: i.price, subtotal: i.price * i.quantity })) },
        shippingAddress: { create: shippingInfo },
      },
    });
    // 3. 在庫減算
    for (const item of cartItems) {
      await tx.inventory.update({ where: { productId: item.productId }, data: { stock: { decrement: item.quantity } } });
    }
    return order;
  });
  return order;
}
```
TEMPLATE

    ITE_CART_GENERATED=true
    ITE_GENERATED_COUNT=$((ITE_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# 決済テンプレート
# =============================================================================
_ite_generate_payment() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITE-PAYMENT] 決済テンプレート

### Payment Processing
```typescript
export class PaymentService {
  async createPaymentIntent(orderId: string): Promise<{ clientSecret: string }> {
    const order = await prisma.order.findUniqueOrThrow({ where: { id: orderId } });
    const intent = await stripe.paymentIntents.create({
      amount: order.total, currency: 'jpy',
      metadata: { orderId },
      automatic_payment_methods: { enabled: true },
    });
    await prisma.payment.create({
      data: { orderId, stripePaymentIntentId: intent.id, amount: order.total, status: 'pending' },
    });
    return { clientSecret: intent.client_secret! };
  }

  async handleWebhook(event: Stripe.Event) {
    if (event.type === 'payment_intent.succeeded') {
      const intent = event.data.object as Stripe.PaymentIntent;
      await prisma.$transaction([
        prisma.payment.update({ where: { stripePaymentIntentId: intent.id }, data: { status: 'completed', paidAt: new Date() } }),
        prisma.order.update({ where: { id: intent.metadata.orderId }, data: { status: 'paid' } }),
      ]);
    }
  }
}
```
TEMPLATE

    ITE_PAYMENT_GENERATED=true
    ITE_GENERATED_COUNT=$((ITE_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# 配送管理テンプレート
# =============================================================================
_ite_generate_shipping() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITE-SHIPPING] 配送管理テンプレート

### Shipping Calculation
```typescript
interface ShippingRate { carrierId: string; name: string; price: number; estimatedDays: number; }

export function calculateShipping(items: CartItem[], destination: Address): ShippingRate[] {
  const totalWeight = items.reduce((sum, i) => sum + (i.weight ?? 0) * i.quantity, 0);
  const rates: ShippingRate[] = [];
  // ヤマト運輸
  if (totalWeight <= 25000) {
    rates.push({ carrierId: 'yamato', name: 'ヤマト運輸', price: getYamatoRate(totalWeight, destination.prefecture), estimatedDays: 2 });
  }
  // 佐川急便
  rates.push({ carrierId: 'sagawa', name: '佐川急便', price: getSagawaRate(totalWeight, destination.prefecture), estimatedDays: 3 });
  // 送料無料条件
  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  if (subtotal >= 5000) {
    rates.unshift({ carrierId: 'free', name: '送料無料', price: 0, estimatedDays: 3 });
  }
  return rates;
}
```

### Order Tracking
```typescript
export async function updateTrackingStatus(orderId: string, trackingNumber: string, carrier: string) {
  await prisma.order.update({
    where: { id: orderId },
    data: { status: 'shipped', trackingNumber, carrier, shippedAt: new Date() },
  });
  await sendNotification(orderId, 'order_shipped', { trackingNumber, carrier });
}
```
TEMPLATE

    ITE_SHIPPING_GENERATED=true
    ITE_GENERATED_COUNT=$((ITE_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# 在庫管理テンプレート
# =============================================================================
_ite_generate_inventory() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITE-INVENTORY] 在庫管理テンプレート

### Inventory Model
```prisma
model Inventory {
  id            String   @id @default(cuid())
  productId     String   @unique
  product       Product  @relation(fields: [productId], references: [id])
  stock         Int      @default(0)
  reservedStock Int      @default(0)
  lowStockThreshold Int  @default(10)
  movements     InventoryMovement[]
  @@index([stock])
}

model InventoryMovement {
  id          String   @id @default(cuid())
  inventoryId String
  inventory   Inventory @relation(fields: [inventoryId], references: [id])
  type        String
  quantity    Int
  reason      String?
  referenceId String?
  createdAt   DateTime @default(now())
  @@index([inventoryId, createdAt])
}
```

### Low Stock Alert
```typescript
export async function checkLowStock(): Promise<LowStockAlert[]> {
  const items = await prisma.inventory.findMany({
    where: { stock: { lte: prisma.inventory.fields.lowStockThreshold } },
    include: { product: { select: { name: true, sku: true } } },
  });
  return items.map(i => ({
    productName: i.product.name, sku: i.product.sku,
    currentStock: i.stock, threshold: i.lowStockThreshold,
    severity: i.stock === 0 ? 'critical' : 'warning',
  }));
}
```
TEMPLATE

    ITE_INVENTORY_GENERATED=true
    ITE_GENERATED_COUNT=$((ITE_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
_ite_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Industry Template: EC v${ITE_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成テンプレート数 : ${ITE_GENERATED_COUNT}"
    echo -e "  Product            : ${ITE_PRODUCT_GENERATED}"
    echo -e "  Cart               : ${ITE_CART_GENERATED}"
    echo -e "  Payment            : ${ITE_PAYMENT_GENERATED}"
    echo -e "  Shipping           : ${ITE_SHIPPING_GENERATED}"
    echo -e "  Inventory          : ${ITE_INVENTORY_GENERATED}"
}

_ite_score() {
    local score=30
    [[ "$ITE_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$ITE_PRODUCT_GENERATED" == "true" ]] && score=$((score + 12))
    [[ "$ITE_CART_GENERATED" == "true" ]] && score=$((score + 12))
    [[ "$ITE_PAYMENT_GENERATED" == "true" ]] && score=$((score + 12))
    [[ "$ITE_SHIPPING_GENERATED" == "true" ]] && score=$((score + 12))
    [[ "$ITE_INVENTORY_GENERATED" == "true" ]] && score=$((score + 12))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "industry-template-ec" \
    --version "372.0" \
    --description "EC業界テンプレート（Product/Cart/Payment/Shipping/Inventory）" \
    --init "_ite_init" \
    --report "_ite_report" \
    --score "_ite_score" \
    --enable-var "ENABLE_ITE" \
    --cli-flags "--industry-ec:--no-industry-ec"
