#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v457.0 - Lazy Loading Orchestrator
# =============================================================================
# 遅延読み込みオーケストレーション: 候補検出、lazy loading生成、Suspense統合。
#
# Functions:
#   _llo_init()                    - Initialize
#   _llo_detect_lazy_candidates()  - Detect components for lazy loading
#   _llo_generate_lazy_loading()   - Generate dynamic import wrappers
#   _llo_generate_suspense()       - Generate Suspense boundaries
#   _llo_report() / _llo_score()
# =============================================================================

[[ -n "${_LLO_LOADED:-}" ]] && return 0; _LLO_LOADED=1

declare -g LLO_VERSION="457.0"
LLO_GENERATED=0; LLO_ERRORS=0; LLO_FILES_WRITTEN=0
LLO_DETECT_OK=false; LLO_LAZY_OK=false; LLO_SUSPENSE_OK=false

_llo_init() {
    LLO_GENERATED=0; LLO_ERRORS=0; LLO_FILES_WRITTEN=0
    LLO_DETECT_OK=false; LLO_LAZY_OK=false; LLO_SUSPENSE_OK=false
    return 0
}

_llo_log() { echo -e "  ${CYAN:-\033[0;36m}[lazy-loading]${NC:-\033[0m} $*" >&2; }
_llo_ok()  { echo -e "  ${GREEN:-\033[0;32m}✅ [lazy-loading]${NC:-\033[0m} $*" >&2; }
_llo_err() { echo -e "  ${RED:-\033[0;31m}❌ [lazy-loading]${NC:-\033[0m} $*" >&2; LLO_ERRORS=$((LLO_ERRORS + 1)); }

_llo_write_file() {
    local filepath="$1" content="$2"
    local dir; dir="$(dirname "$filepath")"
    [[ -d "$dir" ]] || mkdir -p "$dir"
    echo "$content" > "$filepath" 2>/dev/null || { _llo_err "Failed to write $filepath"; return 1; }
    LLO_FILES_WRITTEN=$((LLO_FILES_WRITTEN + 1))
    return 0
}

_llo_detect_lazy_candidates() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/performance/lazy-detector.ts"
    _llo_log "Generating lazy loading candidate detector..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v457.0 - Lazy Loading Candidate Detector

export interface LazyCandidate {
  componentPath: string;
  componentName: string;
  reason: string;
  priority: 'high' | 'medium' | 'low';
  estimatedSizeKb: number;
  belowFold: boolean;
}

const LAZY_PATTERNS: Array<{ pattern: RegExp; reason: string; priority: LazyCandidate['priority'] }> = [
  { pattern: /Modal|Dialog|Drawer/i, reason: 'Modals are shown on demand', priority: 'high' },
  { pattern: /Chart|Graph|Visualization/i, reason: 'Charts are heavy and often below fold', priority: 'high' },
  { pattern: /Editor|RichText|CodeMirror/i, reason: 'Editors are heavy components', priority: 'high' },
  { pattern: /Table|DataGrid/i, reason: 'Data tables may not be immediately visible', priority: 'medium' },
  { pattern: /Map|GoogleMap|Mapbox/i, reason: 'Map libraries are very heavy', priority: 'high' },
  { pattern: /Calendar|DatePicker/i, reason: 'Calendar widgets are on-demand', priority: 'medium' },
  { pattern: /Settings|Preferences/i, reason: 'Settings pages are rarely visited immediately', priority: 'low' },
  { pattern: /Admin|Dashboard/i, reason: 'Admin views can be lazily loaded', priority: 'low' },
  { pattern: /PDF|Pdf|Document/i, reason: 'Document viewers are heavy', priority: 'high' },
  { pattern: /Video|Audio|Media/i, reason: 'Media players are heavy', priority: 'medium' },
];

export class LazyCandidateDetector {
  detectFromName(componentName: string, componentPath: string): LazyCandidate | null {
    for (const { pattern, reason, priority } of LAZY_PATTERNS) {
      if (pattern.test(componentName)) {
        return { componentPath, componentName, reason, priority, estimatedSizeKb: 0, belowFold: true };
      }
    }
    return null;
  }

  analyzeImports(sourceCode: string): string[] {
    const heavyImports: string[] = [];
    const importRegex = /import\s+.*\s+from\s+['"]([^'"]+)['"]/g;
    let match;
    while ((match = importRegex.exec(sourceCode)) !== null) {
      const pkg = match[1];
      if (/chart|editor|map|pdf|video|three|d3|monaco/.test(pkg)) {
        heavyImports.push(pkg);
      }
    }
    return heavyImports;
  }

  generateReport(candidates: LazyCandidate[]): string {
    const byPriority = { high: 0, medium: 0, low: 0 };
    for (const c of candidates) byPriority[c.priority]++;
    return `Lazy Loading Candidates: ${candidates.length} total (${byPriority.high} high, ${byPriority.medium} medium, ${byPriority.low} low)`;
  }
}

export const lazyCandidateDetector = new LazyCandidateDetector();
TYPESCRIPT
)
    _llo_write_file "$outfile" "$content" || return 1
    LLO_DETECT_OK=true
    LLO_GENERATED=$((LLO_GENERATED + 1))
    _llo_ok "Lazy candidate detector generated"
    return 0
}

_llo_generate_lazy_loading() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/performance/lazy-wrapper.ts"
    _llo_log "Generating lazy loading wrappers..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v457.0 - Dynamic Import Lazy Loading Wrapper
import dynamic from 'next/dynamic';
import React, { Suspense } from 'react';

export interface LazyLoadConfig {
  ssr: boolean;
  loading?: React.ComponentType;
  retryAttempts: number;
  retryDelayMs: number;
}

const DEFAULT_CONFIG: LazyLoadConfig = { ssr: false, retryAttempts: 3, retryDelayMs: 1000 };

export function createLazyComponent<T extends React.ComponentType<any>>(
  importFn: () => Promise<{ default: T }>,
  config: Partial<LazyLoadConfig> = {},
) {
  const cfg = { ...DEFAULT_CONFIG, ...config };
  return dynamic(importFn, {
    ssr: cfg.ssr,
    loading: cfg.loading ?? (() => React.createElement('div', { className: 'animate-pulse bg-gray-200 rounded h-32' })),
  });
}

export function lazyWithRetry<T extends React.ComponentType<any>>(
  importFn: () => Promise<{ default: T }>,
  retries = 3,
): () => Promise<{ default: T }> {
  return async () => {
    for (let i = 0; i < retries; i++) {
      try { return await importFn(); } catch (err) {
        if (i === retries - 1) throw err;
        await new Promise(r => setTimeout(r, 1000 * (i + 1)));
      }
    }
    throw new Error('Failed to load component after retries');
  };
}

export function createPreloadable<T extends React.ComponentType<any>>(
  importFn: () => Promise<{ default: T }>,
) {
  let preloaded: Promise<{ default: T }> | null = null;
  const Component = createLazyComponent(importFn);
  (Component as any).preload = () => { preloaded = preloaded ?? importFn(); return preloaded; };
  return Component;
}
TYPESCRIPT
)
    _llo_write_file "$outfile" "$content" || return 1
    LLO_LAZY_OK=true
    LLO_GENERATED=$((LLO_GENERATED + 1))
    _llo_ok "Lazy loading wrappers generated"
    return 0
}

_llo_generate_suspense() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/performance/suspense-boundaries.ts"
    _llo_log "Generating Suspense boundaries..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v457.0 - Suspense Boundary Configuration
import React, { Suspense } from 'react';

interface SuspenseBoundaryConfig {
  name: string;
  fallback: React.ReactNode;
  onError?: (error: Error) => void;
}

export function createSuspenseBoundary(config: SuspenseBoundaryConfig) {
  return function SuspenseBoundary({ children }: { children: React.ReactNode }) {
    return React.createElement(Suspense, { fallback: config.fallback }, children);
  };
}

export const PageSuspense = createSuspenseBoundary({
  name: 'page',
  fallback: React.createElement('div', { className: 'flex items-center justify-center min-h-screen' },
    React.createElement('div', { className: 'animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600' })),
});

export const SectionSuspense = createSuspenseBoundary({
  name: 'section',
  fallback: React.createElement('div', { className: 'animate-pulse space-y-4 p-4' },
    React.createElement('div', { className: 'h-4 bg-gray-200 rounded w-3/4' }),
    React.createElement('div', { className: 'h-4 bg-gray-200 rounded w-1/2' })),
});

export const InlineSuspense = createSuspenseBoundary({
  name: 'inline',
  fallback: React.createElement('span', { className: 'inline-block animate-pulse bg-gray-200 rounded w-20 h-4' }),
});
TYPESCRIPT
)
    _llo_write_file "$outfile" "$content" || return 1
    LLO_SUSPENSE_OK=true
    LLO_GENERATED=$((LLO_GENERATED + 1))
    _llo_ok "Suspense boundaries generated"
    return 0
}

_llo_generate_all() {
    local project_dir="${1:-.}"
    _llo_log "Generating full lazy loading orchestration..."
    _llo_detect_lazy_candidates "$project_dir"
    _llo_generate_lazy_loading "$project_dir"
    _llo_generate_suspense "$project_dir"
    _llo_ok "Lazy loading complete: ${LLO_GENERATED} components, ${LLO_ERRORS} errors"
}

_llo_report() {
    echo -e "\n  ${BOLD:-\033[1m}═══ Lazy Loading Orchestrator v${LLO_VERSION} ═══${NC:-\033[0m}"
    echo -e "  Generated  : ${LLO_GENERATED}"
    echo -e "  Errors     : ${LLO_ERRORS}"
    echo -e "  Detection  : ${LLO_DETECT_OK}"
    echo -e "  Lazy Load  : ${LLO_LAZY_OK}"
    echo -e "  Suspense   : ${LLO_SUSPENSE_OK}"
}

_llo_score() {
    local score=50
    ${LLO_DETECT_OK} && score=$((score + 15))
    ${LLO_LAZY_OK} && score=$((score + 15))
    ${LLO_SUSPENSE_OK} && score=$((score + 15))
    [[ ${LLO_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "lazy-loading-orchestrator" --version "457.0" \
        --description "遅延読み込み: 候補検出×dynamic import×Suspense境界" \
        --init "_llo_init" --report "_llo_report" --score "_llo_score" \
        --enable-var "ENABLE_LAZY_LOADING" --cli-flags "--lazy-loading:--no-lazy-loading"
fi

# v2003.1: source時のexit codeを確実に0にする
true
