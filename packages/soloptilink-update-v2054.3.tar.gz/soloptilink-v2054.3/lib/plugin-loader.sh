#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v15.0 - Plugin Loader
# =============================================================================
# Plugin discovery, registration, and execution system.
# Activates the plugins/ directory with hooks, custom agents, templates, etc.
#
# Plugin Types:
#   hooks/      - Lifecycle hooks (pre_phase, post_phase, etc.)
#   agents/     - Custom agent definitions (.md files)
#   pipelines/  - Custom pipeline definitions
#   rules/      - Custom validation/security rules
#   templates/  - Project scaffold templates
#
# Functions:
#   pl_init              - Scan and register all plugins
#   pl_discover          - Find plugins by type
#   pl_register_hook     - Register a lifecycle hook
#   pl_fire_hook         - Execute all registered hooks for an event
#   pl_load_custom_agents - Load custom agent definitions
#   pl_load_rules        - Load custom validation rules
#   pl_list              - List all loaded plugins
#   pl_report            - Plugin execution summary
# =============================================================================

[[ -n "${_PLUGIN_LOADER_LOADED:-}" ]] && return 0
_PLUGIN_LOADER_LOADED=1

# ============================================================
# State
# ============================================================
declare -g PL_PLUGINS_DIR=""
declare -g PL_ENABLED="true"
declare -g PL_TOTAL_PLUGINS=0
declare -g PL_HOOKS_FIRED=0
declare -g PL_HOOKS_FAILED=0

# Hook registry: hook_name -> space-separated list of script paths
declare -g -A PL_HOOKS=()
# Plugin inventory: plugin_name -> type
declare -g -A PL_REGISTRY=()
# Custom pipelines: pipeline_name -> script_path
declare -g -A PL_PIPELINES=()
# Hook event counts
declare -g -A PL_HOOK_COUNTS=()

# Valid hook event names
declare -g -a PL_VALID_HOOKS=(
    pre_session post_session
    pre_phase post_phase
    pre_claude_call post_claude_call
    pre_deploy post_deploy
    on_error on_heal
)

# ============================================================
# Internal logger
# ============================================================
_pl_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[PLUGIN]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize plugin system
# ============================================================
pl_init() {
    local plugins_dir="${1:-plugins}"

    PL_PLUGINS_DIR="$plugins_dir"
    PL_TOTAL_PLUGINS=0
    PL_HOOKS_FIRED=0
    PL_HOOKS_FAILED=0
    PL_HOOKS=()
    PL_REGISTRY=()
    PL_PIPELINES=()
    PL_HOOK_COUNTS=()

    if [[ ! -d "$PL_PLUGINS_DIR" ]]; then
        _pl_log "WARN" "プラグインディレクトリ未検出: ${PL_PLUGINS_DIR}"
        PL_ENABLED="false"
        return 0
    fi

    PL_ENABLED="true"

    # Auto-discover hooks
    _pl_discover_hooks "${PL_PLUGINS_DIR}/hooks"

    # Auto-discover custom agents
    pl_load_custom_agents "${PL_PLUGINS_DIR}/agents"

    # Auto-discover custom pipelines
    _pl_discover_pipelines "${PL_PLUGINS_DIR}/pipelines"

    # Auto-discover rules
    pl_load_rules "${PL_PLUGINS_DIR}/rules"

    _pl_log "SUCCESS" "プラグインシステム初期化: ${PL_TOTAL_PLUGINS}プラグイン検出"
    return 0
}

# ============================================================
# Discover plugins by type
# ============================================================
pl_discover() {
    local plugin_type="$1"
    local dir="${PL_PLUGINS_DIR}/${plugin_type}"

    [[ ! -d "$dir" ]] && return

    local count=0
    for file in "$dir"/*; do
        [[ ! -f "$file" ]] && continue
        echo "$file"
        count=$((count + 1))
    done

    return 0
}

# ============================================================
# Internal: discover hook scripts
# ============================================================
_pl_discover_hooks() {
    local hooks_dir="$1"
    [[ ! -d "$hooks_dir" ]] && return 0

    for hook_script in "$hooks_dir"/*.sh; do
        [[ ! -f "$hook_script" ]] && continue

        # Validate ownership and permissions
        if ! _pl_validate_plugin "$hook_script"; then
            _pl_log "WARN" "プラグイン検証失敗（スキップ）: $(basename "$hook_script")"
            continue
        fi

        # Extract hook name from filename pattern: {hook_name}_{description}.sh
        local basename_file
        basename_file=$(basename "$hook_script" .sh)

        # Match against valid hook names
        local matched_hook=""
        for valid_hook in "${PL_VALID_HOOKS[@]}"; do
            if [[ "$basename_file" == "${valid_hook}"* ]]; then
                matched_hook="$valid_hook"
                break
            fi
        done

        if [[ -n "$matched_hook" ]]; then
            pl_register_hook "$matched_hook" "$hook_script"
        else
            _pl_log "WARN" "不明なフックパターン: ${basename_file}"
        fi
    done
}

# ============================================================
# Internal: discover custom pipelines
# ============================================================
_pl_discover_pipelines() {
    local pipelines_dir="$1"
    [[ ! -d "$pipelines_dir" ]] && return 0

    for pipeline_script in "$pipelines_dir"/*.sh; do
        [[ ! -f "$pipeline_script" ]] && continue

        if ! _pl_validate_plugin "$pipeline_script"; then
            continue
        fi

        local name
        name=$(basename "$pipeline_script" .sh)
        PL_PIPELINES["$name"]="$pipeline_script"
        PL_REGISTRY["pipeline:${name}"]="pipeline"
        PL_TOTAL_PLUGINS=$((PL_TOTAL_PLUGINS + 1))
        _pl_log "SUCCESS" "パイプライン登録: ${name}"
    done
}

# ============================================================
# Validate plugin file (security check)
# ============================================================
_pl_validate_plugin() {
    local filepath="$1"

    # Check file exists and is readable
    [[ ! -f "$filepath" || ! -r "$filepath" ]] && return 1

    # Check file is owned by current user
    local file_owner
    if stat --version &>/dev/null 2>&1; then
        file_owner=$(stat -c%u "$filepath" 2>/dev/null)
    else
        file_owner=$(stat -f%u "$filepath" 2>/dev/null)
    fi
    local current_uid
    current_uid=$(id -u)

    if [[ -n "$file_owner" && "$file_owner" != "$current_uid" ]]; then
        _pl_log "WARN" "プラグインは現在のユーザー所有でない: $filepath"
        return 1
    fi

    # Check not world-writable
    if [[ -w "$filepath" ]]; then
        local perms
        if stat --version &>/dev/null 2>&1; then
            perms=$(stat -c%a "$filepath" 2>/dev/null)
        else
            perms=$(stat -f%Lp "$filepath" 2>/dev/null)
        fi
        if [[ -n "$perms" && "${perms: -1}" =~ [2367] ]]; then
            _pl_log "WARN" "プラグインがworld-writable: $filepath"
            return 1
        fi
    fi

    return 0
}

# ============================================================
# Register a lifecycle hook
# ============================================================
pl_register_hook() {
    local hook_name="$1"
    local script_path="$2"

    if [[ -z "$hook_name" || -z "$script_path" ]]; then
        return 1
    fi

    # Append to existing hooks for this event
    if [[ -n "${PL_HOOKS[$hook_name]:-}" ]]; then
        PL_HOOKS["$hook_name"]="${PL_HOOKS[$hook_name]} ${script_path}"
    else
        PL_HOOKS["$hook_name"]="$script_path"
    fi

    PL_REGISTRY["hook:$(basename "$script_path")"]="hook"
    PL_TOTAL_PLUGINS=$((PL_TOTAL_PLUGINS + 1))

    _pl_log "SUCCESS" "フック登録: ${hook_name} ← $(basename "$script_path")"
}

# ============================================================
# Fire all registered hooks for an event
# ============================================================
pl_fire_hook() {
    local hook_name="$1"
    shift
    local hook_args=("$@")

    [[ "$PL_ENABLED" != "true" ]] && return 0

    local scripts="${PL_HOOKS[$hook_name]:-}"
    [[ -z "$scripts" ]] && return 0

    PL_HOOK_COUNTS["$hook_name"]=$(( ${PL_HOOK_COUNTS[$hook_name]:-0} + 1 ))

    for script_path in $scripts; do
        [[ ! -f "$script_path" ]] && continue

        PL_HOOKS_FIRED=$((PL_HOOKS_FIRED + 1))

        # Execute hook in a subshell for isolation
        (
            source "$script_path" 2>/dev/null
            # Call the hook function if it exists (convention: hook_name as function)
            if type -t "$hook_name" &>/dev/null; then
                "$hook_name" "${hook_args[@]}" 2>/dev/null
            fi
        )

        if [[ $? -ne 0 ]]; then
            PL_HOOKS_FAILED=$((PL_HOOKS_FAILED + 1))
            _pl_log "WARN" "フック実行失敗: ${hook_name} ($(basename "$script_path"))"
        fi
    done

    return 0
}

# ============================================================
# Load custom agent definitions from plugins/agents/
# ============================================================
pl_load_custom_agents() {
    local agents_dir="$1"
    [[ ! -d "$agents_dir" ]] && return 0

    local count=0
    for agent_md in "$agents_dir"/*.md; do
        [[ ! -f "$agent_md" ]] && continue

        local agent_name
        agent_name=$(basename "$agent_md" .md)

        # Register with agent orchestrator if available
        if type -t ao_register_agent &>/dev/null; then
            ao_register_agent "$agent_name" "$agent_md" "custom" 2>/dev/null || true
        fi

        PL_REGISTRY["agent:${agent_name}"]="agent"
        PL_TOTAL_PLUGINS=$((PL_TOTAL_PLUGINS + 1))
        count=$((count + 1))
    done

    [[ $count -gt 0 ]] && _pl_log "SUCCESS" "${count}カスタムエージェント読み込み"
    return 0
}

# ============================================================
# Load custom validation/security rules
# ============================================================
pl_load_rules() {
    local rules_dir="$1"
    [[ ! -d "$rules_dir" ]] && return 0

    local count=0
    for rule_script in "$rules_dir"/*.sh; do
        [[ ! -f "$rule_script" ]] && continue

        if ! _pl_validate_plugin "$rule_script"; then
            continue
        fi

        source "$rule_script" 2>/dev/null || {
            _pl_log "WARN" "ルール読み込み失敗: $(basename "$rule_script")"
            continue
        }

        local rule_name
        rule_name=$(basename "$rule_script" .sh)
        PL_REGISTRY["rule:${rule_name}"]="rule"
        PL_TOTAL_PLUGINS=$((PL_TOTAL_PLUGINS + 1))
        count=$((count + 1))
    done

    [[ $count -gt 0 ]] && _pl_log "SUCCESS" "${count}カスタムルール読み込み"
    return 0
}

# ============================================================
# List all loaded plugins
# ============================================================
pl_list() {
    echo -e "\n${BOLD:-}=== Loaded Plugins ===${NC:-}"

    if [[ ${#PL_REGISTRY[@]} -eq 0 ]]; then
        echo "  プラグインなし"
        return 0
    fi

    printf "  %-30s  %-10s\n" "Name" "Type"
    echo -e "  ──────────────────────────────  ──────────"
    for name in "${!PL_REGISTRY[@]}"; do
        printf "  %-30s  %-10s\n" "$name" "${PL_REGISTRY[$name]}"
    done
    echo ""
}

# ============================================================
# Plugin execution summary
# ============================================================
pl_report() {
    echo ""
    echo -e "  ${BOLD:-}${CYAN:-}[Plugin System Report] v15.0${NC:-}"
    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo -e "  状態:             ${PL_ENABLED}"
    echo -e "  登録プラグイン数: ${PL_TOTAL_PLUGINS}"
    echo -e "  フック実行回数:   ${PL_HOOKS_FIRED}"
    echo -e "  フック失敗:       ${PL_HOOKS_FAILED}"

    if [[ ${#PL_HOOK_COUNTS[@]} -gt 0 ]]; then
        echo ""
        echo -e "  フックイベント別実行回数:"
        for hook in "${!PL_HOOK_COUNTS[@]}"; do
            printf "    %-20s  %d回\n" "$hook" "${PL_HOOK_COUNTS[$hook]}"
        done
    fi

    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo ""
}
