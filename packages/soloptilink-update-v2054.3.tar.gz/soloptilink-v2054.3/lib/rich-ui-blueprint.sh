#!/usr/bin/env bash
# rich-ui-blueprint.sh
# SoloptiLinkAI v2030.2 - Rich UI Doctrine Module
#
# 役割:
#   "ロッピングライフ品質"の左サイドバー + データ可視化リッチダッシュボードを
#   構造化ノウハウとして提供する。生成系（agent / SKILL）はこのブループリントを
#   参照することで、視覚的に見やすい・データが明瞭に可視化されたシステムを
#   一貫して生成できる。
#
# 由来:
#   2026-05-09 ロッピングライフ (Next.js 14 + Tailwind + Prisma + Recharts)
#   13ページ・10種データ可視化・全ページ200 OK。完璧モードで実装した実例。
#
# 使い方:
#   source ~/.soloptilink/lib/rich-ui-blueprint.sh
#   rui::doctrine            # 教典(JSON) を吐く
#   rui::components_list     # 提供コンポーネント一覧
#   rui::tone_map            # 色 tone マップ
#   rui::status_table        # ステータス辞書
#   rui::checklist           # 品質チェックリスト
#   rui::prompt_injection    # 生成エージェント向けプロンプト断片

set -u
SOLOPTILINK_RUI_VERSION="2030.2"
SOLOPTILINK_RUI_BIRTH="2026-05-09"
SOLOPTILINK_RUI_SOURCE="loppinglife (統合EC通販基幹システム)"

# ─────────────────────────────────────────────────────────
# Doctrine #1: VISUAL HIERARCHY
# ─────────────────────────────────────────────────────────
# 1) 左固定サイドバー (240px / w-60) でナビゲーションを縦に並べる。
#    上部にロゴ (Rロゴ + サービス名 + サブタイトル)、中央にメニュー、
#    下部にバージョン情報カード。スクロールはサイドバー内部に閉じる。
# 2) メイン領域は ml-60 で側面と分離。最初に PageHeader (パンくず +
#    タイトル + サブテキスト + アクション) を白背景・border-b 付きで配置。
# 3) コンテンツは p-8 + space-y-5 で縦リズムを統一。
# 4) 数値カード (StatCard) を最上段。重要 KPI を左から重要度順に並べる。
# 5) その下に大きな時系列・分布グラフ → 構成比 → 詳細テーブルの
#    "上から下へだんだん粒度が細かくなる" 階層で配置する。
#
# Doctrine #2: DATA-AS-SHAPE
# ─────────────────────────────────────────────────────────
# 数字は数字のままで置かない。必ず以下の "形" のいずれかに変換する:
#   ・絶対値 → StatCard (大文字で目に飛び込む)
#   ・推移   → SalesTrendChart / Spark (時系列を一目で)
#   ・構成比 → ChannelBar / CategoryDonut (合計に対する割合を可視化)
#   ・順位   → HorizontalRank (バッジ + gradientバー)
#   ・分布   → MiniBar / Heatmap (バケット別に集約)
#   ・状態   → SentimentGauge / Badge (色とアイコンで意味を持たせる)
#   ・流れ   → Funnel (ステップ間 CV %)
#
# Doctrine #3: COLOR DISCIPLINE
# ─────────────────────────────────────────────────────────
# tone (rose / emerald / sky / amber / violet / slate) を本体カラーとし、
# StatCard 縦線・バッジ・アイコン背景の3要素で同じ tone を使う。
# 1画面で同 tone を3個以上連発しない (視覚的飽和を避ける)。
# ステータス/感情ラベルは dictionary を引いて統一カラーを返す。
#
# Doctrine #4: NUMERIC TYPOGRAPHY
# ─────────────────────────────────────────────────────────
# すべての数値表示に tabular-nums + font-mono の併用を推奨。
# 通貨: ¥ + locale 区切り (formatYen)。
# 件数/率: 区切り + 単位を別 span で淡色 (formatNumber)。
# 時刻: ja-JP の 2桁表示 (formatDate / formatDateTime)。
#
# Doctrine #5: EMPTY/ERROR/LOADING STATE
# ─────────────────────────────────────────────────────────
# 0件: <Empty title=... description=... /> で必ず空状態を描く。
# エラー: try/catch + NextResponse.json({ error }) でレスポンス統一。
# ローディング: skelton or "更新" ボタンの spinner で示す。

# ─────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────

rui::version() {
  echo "$SOLOPTILINK_RUI_VERSION"
}

rui::components_list() {
  cat <<'EOF'
[components]
layout/sidebar.tsx           - 左固定サイドバー (240px), グラデーションロゴ, アクティブハイライト
layout/page-header.tsx       - パンくず + タイトル + 説明 + アクションボタン
ui/card.tsx                  - Card / CardHeader / CardTitle / CardBody / Badge
ui/stat-card.tsx             - 縦線アクセント + tone別カラー + diff + spark
ui/data-table.tsx            - 汎用テーブル (Column<T>定義型)
ui/empty.tsx                 - 0件状態用の Empty パネル
charts/sales-trend-chart.tsx - 売上+受注 時系列 (Recharts AreaChart デュアル軸)
charts/channel-bar.tsx       - チャネル別 横棒 + % + 件数/金額
charts/category-donut.tsx    - 中央数値付きドーナツ + 凡例リスト
charts/sentiment-gauge.tsx   - 半円ゲージ NPS + ポジ/中立/ネガ 内訳
charts/heatmap.tsx           - 曜日 x 時間帯 7x8 ヒートマップ
charts/funnel.tsx            - ファネル (ステップ間 CV% 自動計算)
charts/horizontal-rank.tsx   - ランキング (1位金/2位銀/3位銅 + gradient)
charts/spark.tsx             - 縮小スパークライン (Area)
charts/mini-bar.tsx          - 汎用棒グラフ
EOF
}

rui::tone_map() {
  cat <<'EOF'
{
  "rose":    { "use": "売上/重要KPI",     "accent": "before:bg-rose-500",    "label": "text-rose-600 bg-rose-50" },
  "emerald": { "use": "成功/完了",         "accent": "before:bg-emerald-500", "label": "text-emerald-700 bg-emerald-50" },
  "sky":     { "use": "情報/総数",         "accent": "before:bg-sky-500",     "label": "text-sky-700 bg-sky-50" },
  "amber":   { "use": "警告/未対応",       "accent": "before:bg-amber-500",   "label": "text-amber-700 bg-amber-50" },
  "violet":  { "use": "顧客/分析",         "accent": "before:bg-violet-500",  "label": "text-violet-700 bg-violet-50" },
  "slate":   { "use": "中立/メタ",         "accent": "before:bg-slate-500",   "label": "text-slate-700 bg-slate-50" }
}
EOF
}

rui::status_table() {
  cat <<'EOF'
{
  "pending":     { "label": "未処理",     "color": "bg-amber-50 text-amber-700 border-amber-200" },
  "processing":  { "label": "処理中",     "color": "bg-blue-50 text-blue-700 border-blue-200" },
  "shipped":     { "label": "出荷済み",   "color": "bg-indigo-50 text-indigo-700 border-indigo-200" },
  "delivered":   { "label": "配送完了",   "color": "bg-emerald-50 text-emerald-700 border-emerald-200" },
  "cancelled":   { "label": "キャンセル", "color": "bg-rose-50 text-rose-700 border-rose-200" },
  "paid":        { "label": "決済完了",   "color": "bg-emerald-50 text-emerald-700 border-emerald-200" },
  "refunded":    { "label": "返金済み",   "color": "bg-zinc-50 text-zinc-700 border-zinc-200" },
  "open":        { "label": "未対応",     "color": "bg-rose-50 text-rose-700 border-rose-200" },
  "in_progress": { "label": "対応中",     "color": "bg-amber-50 text-amber-700 border-amber-200" },
  "closed":      { "label": "解決済み",   "color": "bg-emerald-50 text-emerald-700 border-emerald-200" },
  "scheduled":   { "label": "予定",       "color": "bg-sky-50 text-sky-700 border-sky-200" },
  "active":      { "label": "実施中",     "color": "bg-emerald-50 text-emerald-700 border-emerald-200" },
  "ended":       { "label": "終了",       "color": "bg-zinc-50 text-zinc-700 border-zinc-200" },
  "aired":       { "label": "放送済み",   "color": "bg-zinc-50 text-zinc-700 border-zinc-200" },
  "draft":       { "label": "下書き",     "color": "bg-zinc-50 text-zinc-700 border-zinc-200" },
  "completed":   { "label": "完了",       "color": "bg-emerald-50 text-emerald-700 border-emerald-200" }
}
EOF
}

rui::sentiment_table() {
  cat <<'EOF'
{
  "positive": { "label": "ポジティブ", "color": "bg-emerald-50 text-emerald-700 border-emerald-200" },
  "neutral":  { "label": "中立",       "color": "bg-zinc-50 text-zinc-700 border-zinc-200" },
  "negative": { "label": "ネガティブ", "color": "bg-rose-50 text-rose-700 border-rose-200" }
}
EOF
}

rui::checklist() {
  cat <<'EOF'
[Rich UI Quality Checklist - 16 axes]
 1) [ ] 左固定サイドバー (w-60) + アクティブハイライト + アイコン+ラベル
 2) [ ] PageHeader (パンくず + h1 + 説明 + アクションボタン)
 3) [ ] StatCard 縦線アクセントが tone と一致
 4) [ ] 重要 KPI に diff (前期比) と spark を最低1つは添える
 5) [ ] 時系列グラフ (Area / Bar) が最低1つ存在
 6) [ ] 構成比グラフ (ChannelBar / CategoryDonut) が最低1つ存在
 7) [ ] ランキング表示 (HorizontalRank) が最低1つ存在
 8) [ ] テーブルは DataTable パターンで Column<T> 定義
 9) [ ] 全ステータスバッジが status dictionary 経由で描画
10) [ ] 数値はすべて tabular-nums + 区切り (¥ / カンマ)
11) [ ] 0件の表 / 0件のリストに <Empty /> が出る
12) [ ] 全ページ <PageHeader /> + space-y-5 + p-8 で統一
13) [ ] 全ページ Server Component + Prisma 直接アクセス (動的)
14) [ ] /api/health が DB count を JSON で返す
15) [ ] axe-core / アクセシビリティ違反ゼロ
16) [ ] レスポンシブ: grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 を主軸
EOF
}

rui::dependency_set() {
  cat <<'EOF'
{
  "framework":   "next@14.2 + react@18.3 + typescript@5.6",
  "styling":     "tailwindcss@3.4 + clsx + tailwind-merge",
  "icons":       "lucide-react@0.460",
  "charts":      "recharts@2.13",
  "orm":         "@prisma/client@5.22 + prisma@5.22",
  "validation":  "zod@3.23",
  "date":        "date-fns@3.6"
}
EOF
}

rui::prompt_injection() {
  cat <<'EOF'
==== RICH UI DOCTRINE (auto-injected by SoloptiLinkAI v2030.2) ====
あなたが UI/UX を伴うシステムを生成するときは、以下を絶対に守ること:

レイアウト
  - 機能ナビゲーションは "上に並べない"。必ず左固定サイドバー (w-60) に縦並びで配置。
  - サイドバー上部: ロゴ (グラデーションR + サービス名 + サブタイトル)。
  - サイドバー下部: 軽量な version カード (例: v1.0.0 + 同期時刻)。
  - メインは ml-60 / 各ページは <PageHeader> + p-8 + space-y-5 で揃える。

ダッシュボード骨格 (上から下へ)
  1. KPI StatCard (4枚以上) - 各カードに縦線アクセント + tone + diff + spark。
  2. 大きな時系列グラフ + 顧客満足/NPS 系メーター (デュアルカラム)。
  3. 構成比 (ChannelBar) + サブパネル (VOC / 受注 / アラート)。
  4. カテゴリ別ドーナツ + ランキング TOP5。
  5. ヒートマップ (曜日 x 時間) + ファネル。
  6. 直近データテーブル + アラートリスト。

データ可視化原則
  - 数字を裸で出さない。形 (StatCard / Bar / Donut / Heatmap / Funnel / Rank / Spark) に変換する。
  - tone は意味と一致 (重要=rose / 成功=emerald / 情報=sky / 警告=amber / 顧客=violet)。
  - すべてのステータス/感情はディクショナリ (rui::status_table / rui::sentiment_table) 経由。
  - 通貨は formatYen / 件数は formatNumber / 日付は formatDate を共通 utils で定義。

技術スタック (固定推奨)
  Next.js 14 (App Router) + Tailwind v3 + Prisma + Recharts + lucide-react + zod。
  Node.js v18.17 以上で動くこと。サーバコンポーネント中心で書き、API は最小限。

品質ゲート
  - 13 + のページを生成した場合、各ページで:
      <PageHeader />, StatCard セクション, 1 個以上のグラフ or 表 を必ず含める。
  - 0件状態は <Empty /> で必ずカバー。
  - /api/health は { status, database: "connected", counts:{...}, timestamp } を返す。

参照実装 (実例ありの場合は丸写し可):
  ~/.soloptilink/templates/rich-ui-loppinglife/  (2026-05-09 ロッピングライフ実装)
==== END RICH UI DOCTRINE ====
EOF
}

rui::doctrine() {
  cat <<EOF
{
  "version": "$SOLOPTILINK_RUI_VERSION",
  "birth": "$SOLOPTILINK_RUI_BIRTH",
  "source": "$SOLOPTILINK_RUI_SOURCE",
  "principles": [
    "Visual Hierarchy: 上に並べない / 左サイドバーに縦並び",
    "Data-As-Shape: 数字を必ず形に変換",
    "Color Discipline: tone を意味と一致させ 1画面で同 tone を3連発しない",
    "Numeric Typography: 全数値 tabular-nums + 区切り",
    "Empty/Error/Loading State: 0件と失敗を必ず描く"
  ],
  "components_count": 15,
  "chart_kinds_count": 10,
  "page_template_count": 13,
  "axes": 16
}
EOF
}

rui::self_test() {
  local fails=0
  for fn in version doctrine components_list tone_map status_table sentiment_table checklist dependency_set prompt_injection; do
    out=$(rui::"$fn" 2>&1)
    if [ -z "$out" ]; then
      echo "[FAIL] rui::$fn returned empty"
      fails=$((fails+1))
    fi
  done
  if [ $fails -eq 0 ]; then
    echo "[PASS] rich-ui-blueprint v$SOLOPTILINK_RUI_VERSION self-test (9/9)"
    return 0
  else
    echo "[FAIL] $fails functions failed"
    return 1
  fi
}

# 直接実行された場合のみ self-test を走らせる (source 時は実行しない)
# `return 0 2>/dev/null` は source されているときだけ成功する
(return 0 2>/dev/null) || rui::self_test
