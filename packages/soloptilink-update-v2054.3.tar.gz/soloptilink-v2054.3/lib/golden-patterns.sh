#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v120.0 - Golden Patterns Engine
# =============================================================================
# 「禁止事項」から「必須テンプレート」へのパラダイムシフト。
# Claudeがコピーすべき完全動作コードを提供し、初回生成品質を85%+に引き上げる。
#
# 従来: 「onClick={() => {}} は禁止」 → Claudeは何をすべきか分からない
# v120: 「以下のGolden Patternをそのまま使え」 → 具体的な実装を渡す
#
# パターン一覧:
#   GP-001: データ取得（useSWR + loading/error/empty/success状態）
#   GP-002: フォーム送信（React Hook Form + zod + field-level error）
#   GP-003: 削除確認（AlertDialog + async削除 + mutate + toast）
#   GP-004: CRUDリスト（DataTable + pagination + search + sort）
#   GP-005: ナビゲーションボタン（router.push + 実在パスへの遷移）
#   GP-006: モーダルダイアログ（制御されたDialog + フォーム）
#   GP-007: リアルタイムチャット（WebSocket + メッセージリスト + 再接続）
#   GP-008: ページスケルトン（Suspense + ErrorBoundary + skeleton）
#
# 全globals: GP_ prefix
# =============================================================================

[[ -n "${_GOLDEN_PATTERNS_LOADED:-}" ]] && return 0
_GOLDEN_PATTERNS_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g GP_VERSION="142.0"
declare -g GP_INITIALIZED=false
declare -g GP_INJECT_COUNT=0

# =============================================================================
# 初期化
# =============================================================================
gp_init() {
    GP_INITIALIZED=true
    GP_INJECT_COUNT=0
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Golden Patterns v${GP_VERSION}"
}

# =============================================================================
# GP-001: データ取得パターン
# useSWR + 4状態（loading/error/empty/success）完全実装
# =============================================================================
gp_pattern_data_fetching() {
    cat <<'PATTERN'
## [GP-001] データ取得パターン（必須準拠 - 省略厳禁）

```tsx
'use client';
import useSWR from 'swr';

const fetcher = (url: string) => fetch(url).then(r => {
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
});

export default function ItemListPage() {
  const { data, error, isLoading, mutate } = useSWR<{ data: Item[] }>('/api/items', fetcher);

  // 1. ローディング状態（必須）
  if (isLoading) {
    return (
      <div className="space-y-4 p-6">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-16 bg-gray-200 rounded animate-pulse" />
        ))}
      </div>
    );
  }

  // 2. エラー状態（必須）
  if (error) {
    return (
      <div className="p-6 text-center">
        <p className="text-red-600 mb-4">データの取得に失敗しました: {error.message}</p>
        <button
          onClick={() => mutate()}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          再試行
        </button>
      </div>
    );
  }

  const items = data?.data ?? [];

  // 3. 空状態（必須）
  if (items.length === 0) {
    return (
      <div className="p-6 text-center text-gray-500">
        <p className="text-lg mb-4">データがありません</p>
        <button
          onClick={() => router.push('/items/new')}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          最初のアイテムを作成
        </button>
      </div>
    );
  }

  // 4. 成功状態（データ表示）
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">アイテム一覧</h1>
        <button
          onClick={() => router.push('/items/new')}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          新規作成
        </button>
      </div>
      {/* データ一覧をここにレンダリング */}
    </div>
  );
}
```

**チェック項目**: loading状態, error状態+再試行ボタン, empty状態+作成ボタン, success状態
PATTERN
}

# =============================================================================
# GP-002: フォーム送信パターン
# React Hook Form + zodResolver + field-level error + submit with loading
# =============================================================================
gp_pattern_form_submission() {
    cat <<'PATTERN'
## [GP-002] フォーム送信パターン（必須準拠 - 省略厳禁）

```tsx
'use client';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

// 1. zodスキーマ定義（Prismaスキーマの全フィールドをカバー）
const formSchema = z.object({
  name: z.string().min(1, '名前は必須です').max(100, '100文字以内'),
  email: z.string().email('有効なメールアドレスを入力してください'),
  description: z.string().optional(),
});
type FormData = z.infer<typeof formSchema>;

export default function ItemCreatePage() {
  const router = useRouter();
  const [submitError, setSubmitError] = useState('');

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
  });

  // 2. 送信ハンドラ（API呼び出し + エラー処理 + 成功時遷移）
  const onSubmit = async (data: FormData) => {
    setSubmitError('');
    try {
      const res = await fetch('/api/items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'エラーが発生しました' }));
        throw new Error(err.error || `HTTP ${res.status}`);
      }
      router.push('/items');
      router.refresh();
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : '保存に失敗しました');
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">新規作成</h1>

      {/* 3. サーバーエラー表示（必須） */}
      {submitError && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded text-red-700">
          {submitError}
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {/* 4. 各フィールド + field-levelエラー（必須） */}
        <div>
          <label htmlFor="name" className="block text-sm font-medium mb-1">名前 *</label>
          <input
            id="name"
            {...register('name')}
            className={`w-full border rounded px-3 py-2 ${errors.name ? 'border-red-500' : 'border-gray-300'}`}
          />
          {errors.name && <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>}
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium mb-1">メール *</label>
          <input
            id="email"
            type="email"
            {...register('email')}
            className={`w-full border rounded px-3 py-2 ${errors.email ? 'border-red-500' : 'border-gray-300'}`}
          />
          {errors.email && <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>}
        </div>

        {/* 5. 送信ボタン（disabled + loading表示 必須） */}
        <div className="flex gap-3">
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? '保存中...' : '保存'}
          </button>
          <button
            type="button"
            onClick={() => router.back()}
            className="px-6 py-2 border border-gray-300 rounded hover:bg-gray-50"
          >
            キャンセル
          </button>
        </div>
      </form>
    </div>
  );
}
```

**チェック項目**: zodResolver, field-level error表示, submitError状態, isSubmitting+disabled, 成功時router.push
PATTERN
}

# =============================================================================
# GP-003: 削除確認パターン
# AlertDialog + async削除 + mutate/revalidation + error toast
# =============================================================================
gp_pattern_delete_with_confirm() {
    cat <<'PATTERN'
## [GP-003] 削除確認パターン（必須準拠 - 省略厳禁）

```tsx
// 削除ハンドラ（確認ダイアログ + API + 状態更新 + エラー処理）
const [deleting, setDeleting] = useState<string | null>(null);

const handleDelete = async (id: string, name: string) => {
  // 1. 確認ダイアログ（必須）
  if (!confirm(`「${name}」を削除してもよろしいですか？この操作は取り消せません。`)) {
    return;
  }

  setDeleting(id);
  try {
    // 2. API DELETE呼び出し
    const res = await fetch(`/api/items/${id}`, { method: 'DELETE' });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: '削除に失敗しました' }));
      throw new Error(err.error || `HTTP ${res.status}`);
    }
    // 3. データ再取得（必須）
    mutate();
  } catch (err) {
    // 4. エラー表示（必須）
    alert(err instanceof Error ? err.message : '削除に失敗しました');
  } finally {
    setDeleting(null);
  }
};

// レンダリング
<button
  onClick={() => handleDelete(item.id, item.name)}
  disabled={deleting === item.id}
  className="text-red-600 hover:text-red-800 disabled:opacity-50"
>
  {deleting === item.id ? '削除中...' : '削除'}
</button>
```

**チェック項目**: confirm()ダイアログ, DELETE API呼び出し, mutate()再取得, エラーalert, disabled状態
PATTERN
}

# =============================================================================
# GP-004: CRUDリストパターン
# DataTable + pagination + search + sort + 行クリック遷移
# =============================================================================
gp_pattern_crud_list() {
    cat <<'PATTERN'
## [GP-004] CRUDリストパターン（テーブル表示時に必須準拠）

```tsx
// 検索 + ページネーション状態
const [search, setSearch] = useState('');
const [page, setPage] = useState(1);
const limit = 20;

const { data, error, isLoading, mutate } = useSWR<{ data: Item[], total: number }>(
  `/api/items?search=${encodeURIComponent(search)}&page=${page}&limit=${limit}`,
  fetcher
);

const items = data?.data ?? [];
const total = data?.total ?? 0;
const totalPages = Math.ceil(total / limit);

// テーブルレンダリング
<div>
  {/* 検索バー */}
  <input
    type="search"
    placeholder="検索..."
    value={search}
    onChange={(e) => { setSearch(e.target.value); setPage(1); }}
    className="mb-4 w-full border rounded px-3 py-2"
  />

  {/* テーブル */}
  <table className="w-full border-collapse">
    <thead>
      <tr className="border-b bg-gray-50">
        <th className="text-left p-3">名前</th>
        <th className="text-left p-3">ステータス</th>
        <th className="text-left p-3">作成日</th>
        <th className="text-right p-3">操作</th>
      </tr>
    </thead>
    <tbody>
      {items.map((item) => (
        <tr
          key={item.id}
          onClick={() => router.push(`/items/${item.id}`)}
          className="border-b hover:bg-gray-50 cursor-pointer"
        >
          <td className="p-3">{item.name}</td>
          <td className="p-3">{item.status}</td>
          <td className="p-3">{new Date(item.createdAt).toLocaleDateString('ja-JP')}</td>
          <td className="p-3 text-right">
            <button
              onClick={(e) => { e.stopPropagation(); router.push(`/items/${item.id}/edit`); }}
              className="text-blue-600 hover:underline mr-3"
            >
              編集
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); handleDelete(item.id, item.name); }}
              disabled={deleting === item.id}
              className="text-red-600 hover:underline disabled:opacity-50"
            >
              {deleting === item.id ? '削除中...' : '削除'}
            </button>
          </td>
        </tr>
      ))}
    </tbody>
  </table>

  {/* ページネーション */}
  {totalPages > 1 && (
    <div className="flex justify-center gap-2 mt-4">
      <button
        onClick={() => setPage(p => Math.max(1, p - 1))}
        disabled={page <= 1}
        className="px-3 py-1 border rounded disabled:opacity-50"
      >
        前へ
      </button>
      <span className="px-3 py-1">{page} / {totalPages}</span>
      <button
        onClick={() => setPage(p => Math.min(totalPages, p + 1))}
        disabled={page >= totalPages}
        className="px-3 py-1 border rounded disabled:opacity-50"
      >
        次へ
      </button>
    </div>
  )}
</div>
```
PATTERN
}

# =============================================================================
# GP-005: ナビゲーションボタンパターン
# =============================================================================
gp_pattern_navigation_button() {
    cat <<'PATTERN'
## [GP-005] ナビゲーションボタンパターン

```tsx
// 正しい例: router.pushで実在するページに遷移
import { useRouter } from 'next/navigation';

const router = useRouter();

// ✅ 新規作成ボタン → /items/new ページに遷移
<button onClick={() => router.push('/items/new')}>新規作成</button>

// ✅ 編集ボタン → /items/[id]/edit ページに遷移
<button onClick={() => router.push(`/items/${item.id}/edit`)}>編集</button>

// ✅ 詳細ボタン → /items/[id] ページに遷移
<button onClick={() => router.push(`/items/${item.id}`)}>詳細</button>

// ✅ 戻るボタン
<button onClick={() => router.back()}>戻る</button>

// ❌ 絶対禁止パターン
<button onClick={() => console.log('click')}>新規作成</button>  // console.logのみ
<button onClick={() => {}}>編集</button>                         // 空ハンドラ
<a href="#">詳細</a>                                             // href="#"
<button onClick={() => alert('todo')}>削除</button>             // alertのみ
```

**ルール**: 全てのボタンは実際のページ遷移またはAPI操作を行うこと。出力ファイルに遷移先ページも含めること。
PATTERN
}

# =============================================================================
# GP-006: モーダルダイアログパターン
# =============================================================================
gp_pattern_modal_dialog() {
    cat <<'PATTERN'
## [GP-006] モーダルダイアログパターン

```tsx
'use client';
import { useState } from 'react';

export function CreateItemDialog({ onSuccess }: { onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    const formData = new FormData(e.currentTarget);
    try {
      const res = await fetch('/api/items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.fromEntries(formData)),
      });
      if (!res.ok) throw new Error('作成に失敗しました');
      setOpen(false);
      onSuccess();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'エラーが発生しました');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      {/* トリガーボタン（必ずsetOpen(true)を接続） */}
      <button onClick={() => setOpen(true)} className="px-4 py-2 bg-blue-600 text-white rounded">
        新規作成
      </button>

      {/* モーダル */}
      {open && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-lg font-bold mb-4">新規作成</h2>
            {error && <p className="text-red-600 mb-3">{error}</p>}
            <form onSubmit={handleSubmit} className="space-y-3">
              <input name="name" required placeholder="名前" className="w-full border rounded px-3 py-2" />
              <div className="flex gap-2 justify-end">
                <button type="button" onClick={() => setOpen(false)} className="px-4 py-2 border rounded">
                  キャンセル
                </button>
                <button type="submit" disabled={submitting} className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50">
                  {submitting ? '保存中...' : '保存'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
```

**チェック項目**: open状態管理, トリガーボタンにsetOpen(true), フォームにonSubmit+API, 閉じるボタン, disabled状態
PATTERN
}

# =============================================================================
# GP-007: リアルタイムチャットパターン
# =============================================================================
gp_pattern_realtime_chat() {
    cat <<'PATTERN'
## [GP-007] リアルタイムチャットパターン

```tsx
'use client';
import { useState, useEffect, useRef } from 'react';

interface Message {
  id: string;
  content: string;
  sender: string;
  createdAt: string;
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [connected, setConnected] = useState(false);
  const [sending, setSending] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  // 1. 過去メッセージ取得
  useEffect(() => {
    fetch('/api/messages')
      .then(r => r.json())
      .then(data => setMessages(data.data || []))
      .catch(console.error);
  }, []);

  // 2. WebSocket接続 + 再接続ロジック
  useEffect(() => {
    const connect = () => {
      const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss:' : 'ws:'}//${location.host}/api/ws`);
      ws.onopen = () => setConnected(true);
      ws.onclose = () => {
        setConnected(false);
        setTimeout(connect, 3000); // 3秒後に再接続
      };
      ws.onmessage = (e) => {
        const msg: Message = JSON.parse(e.data);
        setMessages(prev => [...prev, msg]);
      };
      wsRef.current = ws;
    };
    connect();
    return () => wsRef.current?.close();
  }, []);

  // 3. 自動スクロール
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // 4. メッセージ送信
  const handleSend = async () => {
    if (!input.trim() || sending) return;
    setSending(true);
    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: input.trim() }),
      });
      if (!res.ok) throw new Error('送信に失敗しました');
      setInput('');
    } catch (err) {
      alert(err instanceof Error ? err.message : '送信エラー');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex flex-col h-screen">
      {/* 接続状態表示 */}
      <div className={`px-4 py-1 text-sm ${connected ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
        {connected ? '接続中' : '再接続中...'}
      </div>

      {/* メッセージ一覧 */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map(msg => (
          <div key={msg.id} className="p-3 bg-gray-50 rounded">
            <span className="font-medium">{msg.sender}</span>
            <p>{msg.content}</p>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* 入力エリア */}
      <div className="border-t p-4 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
          placeholder="メッセージを入力..."
          className="flex-1 border rounded px-3 py-2"
        />
        <button
          onClick={handleSend}
          disabled={!input.trim() || sending}
          className="px-6 py-2 bg-blue-600 text-white rounded disabled:opacity-50"
        >
          {sending ? '送信中...' : '送信'}
        </button>
      </div>
    </div>
  );
}
```

**チェック項目**: 過去メッセージ取得, WebSocket接続+再接続, 自動スクロール, 送信ハンドラ+API, 接続状態表示
PATTERN
}

# =============================================================================
# GP-008: ページスケルトンパターン
# =============================================================================
gp_pattern_page_skeleton() {
    cat <<'PATTERN'
## [GP-008] ページスケルトンパターン（全ページに適用）

```tsx
// app/items/page.tsx
'use client';
import { Suspense } from 'react';

// ローディングスケルトン
function ItemListSkeleton() {
  return (
    <div className="p-6 space-y-4">
      <div className="h-8 w-48 bg-gray-200 rounded animate-pulse" />
      {[...Array(5)].map((_, i) => (
        <div key={i} className="h-16 bg-gray-200 rounded animate-pulse" />
      ))}
    </div>
  );
}

// エラーバウンダリ（クラスコンポーネント）
class ErrorBoundary extends React.Component<
  { children: React.ReactNode; fallback?: React.ReactNode },
  { hasError: boolean; error?: Error }
> {
  state = { hasError: false, error: undefined as Error | undefined };
  static getDerivedStateFromError(error: Error) { return { hasError: true, error }; }
  render() {
    if (this.state.hasError) {
      return this.props.fallback || (
        <div className="p-6 text-center">
          <p className="text-red-600 mb-4">エラーが発生しました: {this.state.error?.message}</p>
          <button onClick={() => this.setState({ hasError: false })} className="px-4 py-2 bg-blue-600 text-white rounded">
            再試行
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

// ページ本体
export default function ItemsPage() {
  return (
    <ErrorBoundary>
      <Suspense fallback={<ItemListSkeleton />}>
        <ItemListContent />
      </Suspense>
    </ErrorBoundary>
  );
}
```

**チェック項目**: Suspense + fallback, ErrorBoundary + 再試行ボタン, スケルトンUI
PATTERN
}

# =============================================================================
# v142.0: フェーズ別Golden Patterns注入（frontend/backend/api対応）
# =============================================================================
gp_inject_for_phase() {
    local phase="${1:-implementation}"
    local domain="${2:-general}"

    GP_INJECT_COUNT=$((GP_INJECT_COUNT + 1))

    local output=""

    case "$phase" in
        frontend|ui_design|implementation|frontend_pages|frontend_core|pages)
            # フロントエンド: 全8パターン注入
            output+="
# ============================================================
# Golden Patterns v142.0 - フロントエンド必須テンプレート集
# ============================================================
# 以下のパターンをそのまま適用すること。省略・簡略化は品質ゲートで自動FAIL。
# 「簡潔にするため省略」「同様のパターンで」等の手抜きは禁止。全て完全に実装する。
# ============================================================

$(gp_pattern_data_fetching)

$(gp_pattern_form_submission)

$(gp_pattern_delete_with_confirm)

$(gp_pattern_navigation_button)

$(gp_pattern_modal_dialog)

$(gp_pattern_page_skeleton)"

            # チャット系ドメインの場合のみチャットパターンを追加
            case "$domain" in
                chat|messaging|communication|sns|social)
                    output+="

$(gp_pattern_realtime_chat)"
                    ;;
            esac
            ;;

        backend|backend_core)
            # バックエンド: APIハンドラ関連パターン（zod/try-catch/CRUD構造）
            output+="
# ============================================================
# Golden Patterns v142.0 - バックエンド必須テンプレート集
# ============================================================
# APIハンドラは以下のパターンに準拠すること。省略は品質ゲートで自動FAIL。
# ============================================================

$(gp_pattern_form_submission)

$(gp_pattern_delete_with_confirm)

$(gp_pattern_crud_list)"
            ;;

        api|api_routes)
            # API: ルート定義・バリデーション関連パターン
            output+="
# ============================================================
# Golden Patterns v142.0 - APIルート必須テンプレート集
# ============================================================
# 全エンドポイントは以下のパターンに準拠すること。省略は品質ゲートで自動FAIL。
# ============================================================

$(gp_pattern_form_submission)

$(gp_pattern_crud_list)"
            ;;

        *)
            # 未対応フェーズ: 注入なし
            GP_INJECT_COUNT=$((GP_INJECT_COUNT - 1))
            return 0
            ;;
    esac

    echo "$output"
}

# =============================================================================
# v184: Chat feature verification
# =============================================================================
gp_verify_chat_completeness() {
    local project_dir="${1:-.}"
    local chat_files
    chat_files=$(grep -rl 'chat\|message\|Chat\|Message' "$project_dir/app" "$project_dir/src" 2>/dev/null --include="*.tsx" --include="*.jsx" | head -20)

    [[ -z "$chat_files" ]] && { echo "100"; return 0; }

    local score=100
    local has_input=false has_send=false has_list=false has_scroll=false

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null)
        echo "$content" | grep -qE 'input.*message\|textarea\|MessageInput' && has_input=true
        echo "$content" | grep -qE 'send\|handleSend\|onSubmit.*message' && has_send=true
        echo "$content" | grep -qE '\.map.*message\|MessageList\|messages\.' && has_list=true
        echo "$content" | grep -qE 'scrollTo\|scrollIntoView\|autoScroll\|useRef' && has_scroll=true
    done <<< "$chat_files"

    $has_input || score=$((score - 25))
    $has_send || score=$((score - 25))
    $has_list || score=$((score - 25))
    $has_scroll || score=$((score - 15))

    echo "$score"
}

# =============================================================================
# レポート
# =============================================================================
gp_report() {
    echo -e "\n  ${BOLD:-}═══ Golden Patterns v${GP_VERSION} ═══${NC:-}"
    echo -e "  パターン数  : 8 (GP-001〜GP-008)"
    echo -e "  注入回数    : ${GP_INJECT_COUNT}"
}

gp_report_json() {
    cat <<EOF
{"module":"golden-patterns","version":"${GP_VERSION}","patterns":8,"inject_count":${GP_INJECT_COUNT}}
EOF
}

gp_score() {
    [[ "$GP_INITIALIZED" == "true" ]] && echo 100 || echo 0
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "golden-patterns" \
        --version "120.0" \
        --description "必須コードテンプレート集（禁止事項→正例パターン）" \
        --init "gp_init" \
        --report "gp_report" \
        --score "gp_score" \
        --enable-var "ENABLE_GOLDEN_PATTERNS" \
        --cli-flags "--golden-patterns:--no-golden-patterns"
fi

# v2003.1: source時のexit codeを確実に0にする
true
