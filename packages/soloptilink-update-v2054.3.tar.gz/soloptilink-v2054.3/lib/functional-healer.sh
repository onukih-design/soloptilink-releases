#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v24.0 - Functional Healer (機能修復エンジン)
# =============================================================================
# Quality Gateの検出結果に基づき、的確な修復指示をClaudeに送って修正する
#
# v24.0: 品質問題の平易な日本語説明を追加
#   - 「モックデータ検出」→「仮のデータが使われています。本番では動きません」
#   - 修復中・修復後の状況をわかりやすく表示
#
# 修復パターン:
#   1. モックデータ → Prisma/ORM クエリに置換
#   2. 空イベントハンドラ → API呼び出し実装
#   3. DB統合不備 → Prisma設定生成・適用
#   4. API接続不備 → エンドポイント修正・CORS設定
#   5. CRUD不完全 → 不足CRUDオペレーション追加
#
# 使用方法:
#   source lib/functional-healer.sh
#   fh_run_functional_healing "/path/to/project" "$quality_gate_findings_json"
# =============================================================================

[[ -n "${_FUNCTIONAL_HEALER_LOADED:-}" ]] && return 0
_FUNCTIONAL_HEALER_LOADED=1

# ============================================================
# Constants
# ============================================================
FH_VERSION="20.0"
FH_MAX_HEAL_LOOPS=3
FH_CLAUDE_TIMEOUT="${CLAUDE_CALL_TIMEOUT:-300}"

# ============================================================
# Internal state
# ============================================================
_FH_HEALED_COUNT=0
_FH_FAILED_COUNT=0
_FH_LOG_DIR=""

# ============================================================
# v24.0: 品質問題のわかりやすい説明
# ============================================================
# 技術用語を、ITリテラシーが低い人でもわかる言葉に翻訳
_fh_explain_finding() {
    local finding_type="$1"

    case "$finding_type" in
        *MOCK_ARRAY*|*MOCK_CONST*|*DUMMY_DATA*)
            echo "  📋 仮のデータが埋め込まれています"
            echo "     → テスト用のデータが直接コードに書かれています"
            echo "     → 実際のデータベースから取得するように直します"
            ;;
        *MOCK_ID*|*MEMORY_PUSH*|*LOCAL_STORAGE*)
            echo "  💾 データの保存方法に問題があります"
            echo "     → ブラウザを閉じるとデータが消えてしまう状態です"
            echo "     → データベースに保存するように直します"
            ;;
        *EMPTY_ONCLICK*|*EMPTY_ONSUBMIT*)
            echo "  🖱️ ボタンを押しても何も起きない箇所があります"
            echo "     → ボタンやフォームの動作が未実装です"
            echo "     → 実際にデータを送信・保存する処理を追加します"
            ;;
        *CONSOLE_ONLY*|*ALERT_ONLY*|*NO_HANDLERS*)
            echo "  ⚡ 操作の処理が不十分です"
            echo "     → ボタンを押しても画面に表示するだけで、データは保存されません"
            echo "     → サーバーにデータを送る処理を追加します"
            ;;
        *NO_SCHEMA*|*NO_DB_URL*|*NO_ENV*)
            echo "  🗄️ データベースの設定がありません"
            echo "     → データを保存する場所（データベース）がまだ準備されていません"
            echo "     → データベース接続の設定を作成します"
            ;;
        *NO_ORM_IMPORT*)
            echo "  🔌 データベース接続の部品が不足しています"
            echo "     → コードからデータベースに接続するための仕組みが入っていません"
            echo "     → 接続に必要な部品を追加します"
            ;;
        *NO_API_CALLS*|*INVALID_API*)
            echo "  🌐 画面とサーバーの通信ができていません"
            echo "     → 画面でデータを操作しても、サーバーに伝わらない状態です"
            echo "     → 画面からサーバーへデータを送る仕組みを追加します"
            ;;
        *NO_BACKEND_ROUTES*|*NO_CORS*)
            echo "  🔗 サーバー側の受け口がありません"
            echo "     → 画面からのリクエストを受け取る準備ができていません"
            echo "     → サーバーの受け口（API）を作成します"
            ;;
        *CRUD_*_MISSING*|*CRUD_*_PARTIAL*)
            echo "  📝 基本操作（追加・表示・編集・削除）が不完全です"
            echo "     → データの一部の操作がまだ作られていません"
            echo "     → 不足している操作を追加します"
            ;;
        *NO_DELETE_CONFIRM*)
            echo "  ⚠️ 削除ボタンに確認画面がありません"
            echo "     → 間違えて削除ボタンを押すと、すぐにデータが消えてしまいます"
            echo "     → 「本当に削除しますか？」の確認を追加します"
            ;;
        *)
            echo "  🔧 品質改善が必要な箇所があります"
            echo "     → 自動で修復を試みます"
            ;;
    esac
}

# v24.0: 修復ループの開始時にわかりやすい概要を表示
_fh_explain_healing_start() {
    local findings="$1"

    echo ""
    echo -e "  ${BOLD:-}${CYAN:-}┌─────────────────────────────────────────────────────┐${NC:-}"
    echo -e "  ${BOLD:-}${CYAN:-}│  🩺 品質チェックの結果、以下の問題が見つかりました  │${NC:-}"
    echo -e "  ${BOLD:-}${CYAN:-}├─────────────────────────────────────────────────────┤${NC:-}"

    # 各種問題をわかりやすく表示
    if echo "$findings" | grep -qE '(NO_SCHEMA|NO_DB_URL|NO_ENV|NO_ORM_IMPORT)' 2>/dev/null; then
        _fh_explain_finding "NO_SCHEMA"
        echo ""
    fi
    if echo "$findings" | grep -qE '(MOCK_ARRAY|MOCK_CONST|MOCK_ID|MEMORY_DB|MEMORY_PUSH|LOCAL_STORAGE|DUMMY_DATA)' 2>/dev/null; then
        _fh_explain_finding "MOCK_ARRAY"
        echo ""
    fi
    if echo "$findings" | grep -qE '(EMPTY_ONCLICK|EMPTY_ONSUBMIT|CONSOLE_ONLY|ALERT_ONLY|NO_HANDLERS)' 2>/dev/null; then
        _fh_explain_finding "EMPTY_ONCLICK"
        echo ""
    fi
    if echo "$findings" | grep -qE '(NO_API_CALLS|INVALID_API|NO_BACKEND_ROUTES|NO_CORS)' 2>/dev/null; then
        _fh_explain_finding "NO_API_CALLS"
        echo ""
    fi
    if echo "$findings" | grep -qE '(CRUD_.*_MISSING|CRUD_.*_PARTIAL|NO_DELETE_CONFIRM)' 2>/dev/null; then
        _fh_explain_finding "CRUD_MISSING"
        echo ""
    fi

    echo -e "  ${BOLD:-}${CYAN:-}│  🔧 これらの問題を自動で修復します...               │${NC:-}"
    echo -e "  ${BOLD:-}${CYAN:-}└─────────────────────────────────────────────────────┘${NC:-}"
    echo ""
}

# ============================================================
# Logging
# ============================================================
_fh_log() {
    local level="$1" msg="$2"
    local timestamp
    timestamp="$(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "  [FunctionalHealer][${level}] ${msg}" >&2
    if [[ -n "${_FH_LOG_DIR}" ]]; then
        echo "[${timestamp}][FH][${level}] ${msg}" >> "${_FH_LOG_DIR}/functional_healer.log" 2>/dev/null || true
    fi
}

# ============================================================
# Claude CLI caller (with retry)
# ============================================================
_fh_call_claude() {
    local prompt="$1"
    local output_file="$2"
    local retry=0

    # v2035.0: 因果分析による修復強化 - findings/エラー文脈があれば causal_reasoner の根本原因を注入
    if [[ -n "${_FH_HEAL_CONTEXT:-}" ]] && type -t causal_healer_inject &>/dev/null; then
        prompt=$(causal_healer_inject "$prompt" "$_FH_HEAL_CONTEXT")
    fi

    while [[ "$retry" -lt 3 ]]; do
        retry=$((retry + 1))
        local result=""

        if command -v claude &>/dev/null; then
            # v23.0: macOS対応 - timeout コマンドの有無を動的判定
            local _fh_claude_cmd
            if command -v timeout &>/dev/null; then
                _fh_claude_cmd="timeout ${FH_CLAUDE_TIMEOUT} claude"
            else
                _fh_claude_cmd="claude"
            fi
            result=$(${_fh_claude_cmd} -p --dangerously-skip-permissions \
                --output-format text "$prompt" 2>/dev/null || echo "")
        fi

        if [[ -n "$result" ]]; then
            echo "$result" > "$output_file"
            return 0
        fi

        _fh_log "WARN" "Claude応答なし (試行 ${retry}/3)"
        sleep $((retry * 2))
    done

    _fh_log "ERROR" "Claude CLI呼び出し失敗（3回リトライ後）"
    return 1
}

# ============================================================
# Write Claude output to project files
# ============================================================
_fh_apply_claude_output() {
    local output_file="$1"
    local project_dir="$2"

    if type -t _write_claude_output_to_files &>/dev/null; then
        _write_claude_output_to_files "$output_file"
        return $?
    fi

    # v31.0: 4段フォールバックファイルライター
    local claude_output
    claude_output="$(cat "$output_file" 2>/dev/null)" || claude_output=""

    # Strategy 1: deep-fix-engine のファイルライターを使用（最も信頼性が高い）
    if type -t _dfe_write_to_project &>/dev/null && [[ -n "$project_dir" ]]; then
        if _dfe_write_to_project "$claude_output" "$project_dir" 2>/dev/null; then
            _fh_log "INFO" "DFEファイルライターで書き込み成功"
            return 0
        fi
        _fh_log "WARN" "DFEファイルライター失敗 → フォールバック"
    fi

    # Strategy 2: file-writer-v3 を使用
    if type -t fw3_parse_and_write &>/dev/null && [[ -n "$project_dir" ]]; then
        local _fh_tmpfile="${TMPDIR:-/tmp}/fh_output_$$.txt"
        printf '%s\n' "$claude_output" > "$_fh_tmpfile" 2>/dev/null
        if fw3_parse_and_write "$_fh_tmpfile" "$project_dir" 2>/dev/null; then
            rm -f "$_fh_tmpfile" 2>/dev/null
            _fh_log "INFO" "FW3ファイルライターで書き込み成功"
            return 0
        fi
        rm -f "$_fh_tmpfile" 2>/dev/null
        _fh_log "WARN" "FW3ファイルライター失敗 → フォールバック"
    fi

    # Strategy 3: file-writer-v2 を使用
    if type -t fw2_parse_and_write &>/dev/null && [[ -n "$project_dir" ]]; then
        local _fh_tmpfile="${TMPDIR:-/tmp}/fh_output_$$.txt"
        printf '%s\n' "$claude_output" > "$_fh_tmpfile" 2>/dev/null
        if fw2_parse_and_write "$_fh_tmpfile" "$project_dir" 2>/dev/null; then
            rm -f "$_fh_tmpfile" 2>/dev/null
            _fh_log "INFO" "FW2ファイルライターで書き込み成功"
            return 0
        fi
        rm -f "$_fh_tmpfile" 2>/dev/null
        _fh_log "WARN" "FW2ファイルライター失敗 → フォールバック"
    fi

    # Strategy 4: 既存のレガシーパーサー（元の実装）
    _fh_log "INFO" "レガシーファイルライターで書き込み試行"

    # Fallback: Simple file extraction from Claude output
    local content
    content="$(cat "$output_file" 2>/dev/null)" || return 1

    local current_file=""
    local in_code_block=0
    local code_content=""

    while IFS= read -r line; do
        # Detect code block boundaries (``` with optional language specifier)
        if [[ "$line" =~ ^[[:space:]]*\`\`\`[[:space:]]*([a-zA-Z]*)[[:space:]]*$ ]]; then
            if [[ $in_code_block -eq 1 ]]; then
                # End of code block - write file if we have a target
                if [[ -n "$current_file" ]]; then
                    local full_path="${project_dir}/${current_file}"
                    mkdir -p "$(dirname "$full_path")" 2>/dev/null
                    printf '%s' "$code_content" > "$full_path"
                    _fh_log "INFO" "ファイル書き込み: ${current_file}"
                fi
                current_file=""
                code_content=""
                in_code_block=0
            else
                in_code_block=1
                code_content=""
            fi
        elif [[ $in_code_block -eq 1 ]]; then
            code_content+="${line}"$'\n'
        elif [[ "$line" =~ (^#+[[:space:]]+|^//[[:space:]]+|^#[[:space:]]+).*\.((ts|tsx|js|jsx|py|prisma|css|json|html|yaml|yml|env|sh)) ]]; then
            # Extract file path from header (e.g., "### src/lib/prisma.ts" or "// app/api/route.ts")
            current_file=$(echo "$line" | grep -oE '[a-zA-Z0-9_./@\-]+\.(ts|tsx|js|jsx|py|prisma|css|json|html|yaml|yml|env|sh)' | head -1)
        fi
    done <<< "$content"

    # Handle case where file ends inside a code block
    if [[ $in_code_block -eq 1 && -n "$current_file" && -n "$code_content" ]]; then
        local full_path="${project_dir}/${current_file}"
        mkdir -p "$(dirname "$full_path")" 2>/dev/null
        printf '%s' "$code_content" > "$full_path"
        _fh_log "INFO" "ファイル書き込み (末尾): ${current_file}"
    fi

    return 0
}

# ============================================================
# Heal Pattern 1: Mock Data → Real DB Queries
# ============================================================
fh_heal_mock_data() {
    local project_dir="$1"
    local findings="$2"

    _fh_log "INFO" "修復パターン1: モックデータ → 実DBクエリ"

    # Collect files with mock data
    local -a mock_files=()
    while IFS= read -r finding; do
        if echo "$finding" | grep -qE '(MOCK_ARRAY|MOCK_CONST|MOCK_ID|MEMORY_DB|MEMORY_PUSH|LOCAL_STORAGE|DUMMY_DATA)' 2>/dev/null; then
            local file_ref
            file_ref=$(echo "$finding" | grep -oE '[^:]+\.(tsx?|jsx?|py|vue|svelte)' | head -1)
            [[ -n "$file_ref" ]] && mock_files+=("$file_ref")
        fi
    done <<< "$findings"

    if [[ ${#mock_files[@]} -eq 0 ]]; then
        _fh_log "INFO" "モックデータなし - スキップ"
        return 0
    fi

    # Read Prisma schema if available
    local prisma_context=""
    if [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
        prisma_context="

--- 既存Prismaスキーマ ---
$(cat "${project_dir}/prisma/schema.prisma" 2>/dev/null)"
    fi

    # Build repair prompt with actual file contents
    local file_contexts=""
    for mock_file in "${mock_files[@]}"; do
        local full_path="${project_dir}/${mock_file}"
        if [[ -f "$full_path" ]]; then
            file_contexts+="
--- ${mock_file} (修正対象) ---
$(cat "$full_path" 2>/dev/null)
"
        fi
    done

    local prompt="あなたはシニアソフトウェアエンジニアです。以下のファイルにモックデータ・ハードコードデータが検出されました。
全てのモックデータを実際のデータベースクエリ（Prisma ORM）に置き換えてください。

【修正ルール】
1. useState([{id: 1, name: \"John\"...}]) → useState([]) + useEffect内でfetch/API呼び出し
2. constデータ配列 → API呼び出し（fetch/axios）に置換
3. Date.now() ID → DBの自動採番（autoincrement/uuid）に依存
4. localStorage/sessionStorage → API + DB経由に置換
5. Array.push() → prisma.model.create() に置換
6. ダミーメールアドレス → フォーム入力から取得

${prisma_context}

【修正対象ファイル】
${file_contexts}

修正後の完全なファイル内容を出力してください。ファイル名をヘッダーとして付けてください。"

    local output_file="${_FH_LOG_DIR}/heal_mock_data.md"
    if _fh_call_claude "$prompt" "$output_file"; then
        _fh_apply_claude_output "$output_file" "$project_dir"
        _FH_HEALED_COUNT=$((_FH_HEALED_COUNT + 1))
        _fh_log "INFO" "モックデータ修復完了"
        return 0
    else
        _FH_FAILED_COUNT=$((_FH_FAILED_COUNT + 1))
        _fh_log "ERROR" "モックデータ修復失敗"
        return 1
    fi
}

# ============================================================
# Heal Pattern 2: Empty Event Handlers → API Implementations
# ============================================================
fh_heal_empty_handlers() {
    local project_dir="$1"
    local findings="$2"

    _fh_log "INFO" "修復パターン2: 空ハンドラ → API実装"

    local -a handler_files=()
    while IFS= read -r finding; do
        if echo "$finding" | grep -qE '(EMPTY_ONCLICK|EMPTY_ONSUBMIT|CONSOLE_ONLY|ALERT_ONLY|NO_HANDLERS)' 2>/dev/null; then
            local file_ref
            file_ref=$(echo "$finding" | grep -oE '[^:]+\.(tsx?|jsx?|vue|svelte)' | head -1)
            [[ -n "$file_ref" ]] && handler_files+=("$file_ref")
        fi
    done <<< "$findings"

    if [[ ${#handler_files[@]} -eq 0 ]]; then
        _fh_log "INFO" "空ハンドラなし - スキップ"
        return 0
    fi

    # Deduplicate
    local -a unique_files=()
    local -A seen=()
    for f in "${handler_files[@]}"; do
        if [[ -z "${seen[$f]:-}" ]]; then
            unique_files+=("$f")
            seen[$f]=1
        fi
    done

    # Read file contents
    local file_contexts=""
    for handler_file in "${unique_files[@]}"; do
        local full_path="${project_dir}/${handler_file}"
        if [[ -f "$full_path" ]]; then
            file_contexts+="
--- ${handler_file} (修正対象) ---
$(cat "$full_path" 2>/dev/null)
"
        fi
    done

    # Read API routes for context
    local api_context=""
    while IFS= read -r backend_file; do
        [[ -z "$backend_file" ]] && continue
        api_context+="
--- $(basename "$backend_file") (既存APIルート) ---
$(cat "$backend_file" 2>/dev/null)
"
    done < <(find "$project_dir" -type f \( -path "*/api/*" -o -path "*/routes/*" \) \
        \( -name "*.ts" -o -name "*.js" -o -name "*.py" \) \
        -not -path "*/node_modules/*" 2>/dev/null | head -5)

    local prompt="あなたはシニアフロントエンドエンジニアです。以下のファイルに空のイベントハンドラが検出されました。
全ての空ハンドラを実際のAPI呼び出し・状態管理実装に置き換えてください。

【修正ルール】
1. onClick={() => {}} → onClick={() => handleAction(id)} + handleAction関数にfetch/API呼び出し実装
2. onSubmit={() => {}} → onSubmit={handleSubmit} + handleSubmit関数にPOST/PUT API呼び出し実装
3. console.logのみ → 実際のAPI呼び出し + 状態更新 + エラーハンドリング
4. alert()のみ → API呼び出し + 成功/エラー通知(toast) + 画面更新
5. 削除ボタン → confirm()確認ダイアログ + DELETE API呼び出し + リスト更新
6. 全ハンドラにtry-catch + ローディング状態 + エラー表示を実装

${api_context}

【修正対象ファイル】
${file_contexts}

修正後の完全なファイル内容を出力してください。"

    local output_file="${_FH_LOG_DIR}/heal_handlers.md"
    if _fh_call_claude "$prompt" "$output_file"; then
        _fh_apply_claude_output "$output_file" "$project_dir"
        _FH_HEALED_COUNT=$((_FH_HEALED_COUNT + 1))
        _fh_log "INFO" "空ハンドラ修復完了"
        return 0
    else
        _FH_FAILED_COUNT=$((_FH_FAILED_COUNT + 1))
        _fh_log "ERROR" "空ハンドラ修復失敗"
        return 1
    fi
}

# ============================================================
# Heal Pattern 3: Missing DB Integration → Generate Setup
# ============================================================
fh_heal_db_integration() {
    local project_dir="$1"
    local findings="$2"

    _fh_log "INFO" "修復パターン3: DB統合不備 → 設定生成"

    local needs_schema=0
    local needs_env=0
    local needs_import=0
    local needs_seed=0

    while IFS= read -r finding; do
        case "$finding" in
            *NO_SCHEMA*) needs_schema=1 ;;
            *NO_DB_URL*|*NO_ENV*) needs_env=1 ;;
            *NO_ORM_IMPORT*) needs_import=1 ;;
            *NO_SEED*) needs_seed=1 ;;
        esac
    done <<< "$findings"

    if [[ $needs_schema -eq 0 && $needs_env -eq 0 && $needs_import -eq 0 && $needs_seed -eq 0 ]]; then
        _fh_log "INFO" "DB統合問題なし - スキップ"
        return 0
    fi

    # Detect project type
    local is_python=0
    local is_node=0
    [[ -f "${project_dir}/package.json" ]] && is_node=1
    [[ -f "${project_dir}/requirements.txt" ]] || [[ -f "${project_dir}/pyproject.toml" ]] && is_python=1

    # Collect existing model-like files for context
    local existing_models=""
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        if grep -qE '(interface|type|class|model)\s+\w+' "$file" 2>/dev/null; then
            existing_models+="
--- $(basename "$file") ---
$(cat "$file" 2>/dev/null)
"
        fi
    done < <(find "$project_dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.py" \) \
        \( -name "*model*" -o -name "*type*" -o -name "*schema*" -o -name "*entity*" \) \
        -not -path "*/node_modules/*" 2>/dev/null | head -5)

    local repair_targets=""
    [[ $needs_schema -eq 1 ]] && repair_targets+="- prisma/schema.prisma (データモデル定義)\n"
    [[ $needs_env -eq 1 ]] && repair_targets+="- .env (DATABASE_URL設定)\n"
    [[ $needs_import -eq 1 ]] && repair_targets+="- lib/prisma.ts (Prismaクライアント初期化)\n"
    [[ $needs_seed -eq 1 ]] && repair_targets+="- prisma/seed.ts (初期データ投入スクリプト)\n"

    local prompt="あなたはDBアーキテクトです。以下のプロジェクトにDB統合が不足しています。
必要なファイルを全て生成してください。

【生成対象】
$(echo -e "$repair_targets")

【既存コードの型/モデル情報】
${existing_models:-（なし - タスク説明から推定してください）}

【要件】
1. 開発環境: SQLite (file:./dev.db) で即起動
2. DATABASE_URLを変更するだけでPostgreSQLに移行可能
3. Prisma schema: 全モデルにid, createdAt, updatedAt
4. Prisma client: シングルトンパターンで初期化
5. seed.ts: 5-10件の現実的な初期データ
6. .env: DATABASE_URL=file:./dev.db

全ファイルの完全な内容を出力してください。"

    local output_file="${_FH_LOG_DIR}/heal_db_integration.md"
    if _fh_call_claude "$prompt" "$output_file"; then
        _fh_apply_claude_output "$output_file" "$project_dir"
        _FH_HEALED_COUNT=$((_FH_HEALED_COUNT + 1))
        _fh_log "INFO" "DB統合修復完了"
        return 0
    else
        _FH_FAILED_COUNT=$((_FH_FAILED_COUNT + 1))
        _fh_log "ERROR" "DB統合修復失敗"
        return 1
    fi
}

# ============================================================
# Heal Pattern 4: API Connection Issues
# ============================================================
fh_heal_api_connections() {
    local project_dir="$1"
    local findings="$2"

    _fh_log "INFO" "修復パターン4: API接続不備 → 修正"

    local has_api_issue=0
    while IFS= read -r finding; do
        if echo "$finding" | grep -qE '(NO_API_CALLS|INVALID_API|NO_BACKEND_ROUTES|NO_CORS)' 2>/dev/null; then
            has_api_issue=1
            break
        fi
    done <<< "$findings"

    if [[ $has_api_issue -eq 0 ]]; then
        _fh_log "INFO" "API接続問題なし - スキップ"
        return 0
    fi

    # Read key frontend and backend files
    local frontend_context=""
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        frontend_context+="
--- $(basename "$file") ---
$(head -100 "$file" 2>/dev/null)
"
    done < <(find "$project_dir" -type f \( -name "*.tsx" -o -name "*.jsx" \) \
        -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | head -5)

    local backend_context=""
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        backend_context+="
--- $(basename "$file") ---
$(cat "$file" 2>/dev/null)
"
    done < <(find "$project_dir" -type f \( -path "*/api/*" -o -path "*/routes/*" -o -name "server.*" -o -name "app.*" \) \
        \( -name "*.ts" -o -name "*.js" -o -name "*.py" \) \
        -not -path "*/node_modules/*" 2>/dev/null | head -5)

    local prompt="あなたはフルスタックエンジニアです。フロントエンドとバックエンドのAPI接続に問題があります。
以下のコードを分析して、API接続を正しく修正してください。

【検出された問題】
$(echo "$findings" | grep -E '(NO_API_CALLS|INVALID_API|NO_BACKEND_ROUTES|NO_CORS)')

【修正ルール】
1. フロントエンドにAPI呼び出しがない → fetch/axios でバックエンドAPIを呼ぶ
2. バックエンドルートがない → Express/FastAPI/Next.js API routes を作成
3. CORS設定がない → cors ミドルウェアを追加
4. エンドポイントURLが不正 → 正しいURL（/api/xxx）に修正

【フロントエンド】
${frontend_context}

【バックエンド】
${backend_context}

修正が必要なファイルの完全な内容を出力してください。"

    local output_file="${_FH_LOG_DIR}/heal_api_connections.md"
    if _fh_call_claude "$prompt" "$output_file"; then
        _fh_apply_claude_output "$output_file" "$project_dir"
        _FH_HEALED_COUNT=$((_FH_HEALED_COUNT + 1))
        _fh_log "INFO" "API接続修復完了"
        return 0
    else
        _FH_FAILED_COUNT=$((_FH_FAILED_COUNT + 1))
        _fh_log "ERROR" "API接続修復失敗"
        return 1
    fi
}

# ============================================================
# Heal Pattern 5: CRUD Completeness
# ============================================================
fh_heal_crud_completeness() {
    local project_dir="$1"
    local findings="$2"

    _fh_log "INFO" "修復パターン5: CRUD不完全 → 補完"

    local -a missing_ops=()
    while IFS= read -r finding; do
        case "$finding" in
            *CRUD_CREATE_MISSING*|*CRUD_CREATE_PARTIAL*) missing_ops+=("CREATE") ;;
            *CRUD_READ_MISSING*|*CRUD_READ_PARTIAL*) missing_ops+=("READ") ;;
            *CRUD_UPDATE_MISSING*|*CRUD_UPDATE_PARTIAL*) missing_ops+=("UPDATE") ;;
            *CRUD_DELETE_MISSING*|*CRUD_DELETE_PARTIAL*) missing_ops+=("DELETE") ;;
            *NO_DELETE_CONFIRM*) missing_ops+=("DELETE_CONFIRM") ;;
        esac
    done <<< "$findings"

    if [[ ${#missing_ops[@]} -eq 0 ]]; then
        _fh_log "INFO" "CRUD完全 - スキップ"
        return 0
    fi

    # Prisma schema for model context
    local schema_context=""
    if [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
        schema_context="
--- Prismaスキーマ ---
$(cat "${project_dir}/prisma/schema.prisma" 2>/dev/null)"
    fi

    # Read existing routes and components
    local existing_code=""
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        existing_code+="
--- $(basename "$file") ---
$(cat "$file" 2>/dev/null)
"
    done < <(find "$project_dir" -type f \( -path "*/api/*" -o -path "*/routes/*" -o -name "*.tsx" -o -name "*.jsx" \) \
        \( -name "*.ts" -o -name "*.js" -o -name "*.tsx" -o -name "*.jsx" \) \
        -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | head -8)

    local missing_list=""
    for op in "${missing_ops[@]}"; do
        missing_list+="- ${op}\n"
    done

    local prompt="あなたはフルスタックエンジニアです。以下のCRUD操作が不足/不完全です。
不足している操作を全て実装してください。

【不足しているCRUD操作】
$(echo -e "$missing_list")

${schema_context}

【既存コード】
${existing_code}

【実装ルール】
- CREATE: POSTエンドポイント + フォームコンポーネント + onSubmit→API POST + バリデーション
- READ: GETエンドポイント + 一覧コンポーネント + ページネーション + 検索
- UPDATE: PUT/PATCHエンドポイント + 編集フォーム + 既存データプリフィル
- DELETE: DELETEエンドポイント + 削除ボタン + confirm()確認ダイアログ + リスト更新
- DELETE_CONFIRM: 削除前に必ずconfirm()ダイアログで確認

全てPrisma ORMでDB操作。モックデータ禁止。
修正/追加が必要なファイルの完全な内容を出力してください。"

    local output_file="${_FH_LOG_DIR}/heal_crud.md"
    if _fh_call_claude "$prompt" "$output_file"; then
        _fh_apply_claude_output "$output_file" "$project_dir"
        _FH_HEALED_COUNT=$((_FH_HEALED_COUNT + 1))
        _fh_log "INFO" "CRUD補完完了"
        return 0
    else
        _FH_FAILED_COUNT=$((_FH_FAILED_COUNT + 1))
        _fh_log "ERROR" "CRUD補完失敗"
        return 1
    fi
}

# ============================================================
# Main Entry Point: Run Functional Healing
# ============================================================
fh_run_functional_healing() {
    local project_dir="${1:-.}"
    local quality_threshold="${2:-80}"
    local max_loops="${3:-$FH_MAX_HEAL_LOOPS}"

    _FH_HEALED_COUNT=0
    _FH_FAILED_COUNT=0
    _FH_LOG_DIR="${SESSION_LOG_DIR:-/tmp}/functional_healer"
    mkdir -p "${_FH_LOG_DIR}" 2>/dev/null

    _fh_log "INFO" "═══ Functional Healer v${FH_VERSION} 開始 ═══"
    _fh_log "INFO" "プロジェクト: ${project_dir}"
    _fh_log "INFO" "品質閾値: ${quality_threshold}, 最大ループ: ${max_loops}"

    local loop=0
    local _fh_prev_score=-1   # v2034.8: スコア停滞検出用 (改善0なら break)
    local _fh_stale_count=0
    while [[ $loop -lt $max_loops ]]; do
        loop=$((loop + 1))
        _fh_log "INFO" "--- 修復ループ ${loop}/${max_loops} ---"

        # Run quality gate to get current findings
        if ! type -t qg_run_quality_gate &>/dev/null; then
            _fh_log "ERROR" "Quality Gate モジュールが読み込まれていません"
            return 1
        fi

        # Reset QG state before each loop iteration to get fresh results
        if type -t _qg_reset_state &>/dev/null; then
            _qg_reset_state
        else
            # Manual reset if _qg_reset_state not available
            _QG_FINDINGS=() 2>/dev/null || true
            _QG_SCORES=() 2>/dev/null || true
        fi

        # Run quality gate (suppress dashboard display for inner loops)
        if qg_run_quality_gate "$project_dir" "$quality_threshold" 2>/dev/null; then
            _fh_log "INFO" "品質ゲートPASS - 修復完了!"
            echo ""
            echo -e "  ${GREEN:-}✅ 品質チェック合格！ ${_FH_HEALED_COUNT}件の問題を修復しました（${loop}回目で完了）${NC:-}"
            return 0
        fi

        # v2034.8: QGスコア停滞検出 (前回比改善0が2連続なら break)
        local _fh_current_score="${QG_SCORE:-0}"
        if [[ "$_fh_prev_score" -ge 0 ]] && [[ "$_fh_current_score" -le "$_fh_prev_score" ]]; then
            _fh_stale_count=$((_fh_stale_count + 1))
            _fh_log "WARN" "QGスコア停滞検出: 前回 ${_fh_prev_score} → 今回 ${_fh_current_score} (${_fh_stale_count}回連続)"
            if [[ $_fh_stale_count -ge 2 ]]; then
                _fh_log "WARN" "スコア停滞2回連続 - 修復ループ早期終了 (時間節約のため)"
                break
            fi
        else
            _fh_stale_count=0
        fi
        _fh_prev_score="$_fh_current_score"

        # Get findings
        local findings
        findings=$(qg_get_findings)
        # v2035.0: 因果分析の文脈共有(causal-healer が修復プロンプトに根本原因を注入)
        _FH_HEAL_CONTEXT="$findings"

        if [[ -z "$findings" ]]; then
            _fh_log "WARN" "検出事項なしだがスコア未達 - ループ終了"
            break
        fi

        # v24.0: 見つかった問題をわかりやすく表示（最初のループのみ）
        if [[ "$loop" -eq 1 ]]; then
            _fh_explain_healing_start "$findings"
        fi

        # Apply targeted healing based on finding types
        local healed_this_loop=0

        # Priority order: DB first (foundation), then mock data, handlers, API, CRUD
        if echo "$findings" | grep -qE '(NO_SCHEMA|NO_DB_URL|NO_ENV|NO_ORM_IMPORT)' 2>/dev/null; then
            fh_heal_db_integration "$project_dir" "$findings" && healed_this_loop=$((healed_this_loop + 1))
        fi

        if echo "$findings" | grep -qE '(MOCK_ARRAY|MOCK_CONST|MOCK_ID|MEMORY_DB|MEMORY_PUSH|LOCAL_STORAGE|DUMMY_DATA)' 2>/dev/null; then
            fh_heal_mock_data "$project_dir" "$findings" && healed_this_loop=$((healed_this_loop + 1))
        fi

        if echo "$findings" | grep -qE '(EMPTY_ONCLICK|EMPTY_ONSUBMIT|CONSOLE_ONLY|ALERT_ONLY|NO_HANDLERS)' 2>/dev/null; then
            fh_heal_empty_handlers "$project_dir" "$findings" && healed_this_loop=$((healed_this_loop + 1))
        fi

        if echo "$findings" | grep -qE '(NO_API_CALLS|INVALID_API|NO_BACKEND_ROUTES|NO_CORS)' 2>/dev/null; then
            fh_heal_api_connections "$project_dir" "$findings" && healed_this_loop=$((healed_this_loop + 1))
        fi

        if echo "$findings" | grep -qE '(CRUD_.*_MISSING|CRUD_.*_PARTIAL|NO_DELETE_CONFIRM)' 2>/dev/null; then
            fh_heal_crud_completeness "$project_dir" "$findings" && healed_this_loop=$((healed_this_loop + 1))
        fi

        if [[ $healed_this_loop -eq 0 ]]; then
            _fh_log "WARN" "修復可能な項目なし - ループ終了"
            break
        fi

        _fh_log "INFO" "ループ${loop}: ${healed_this_loop}件修復実行"
    done

    # Final quality check
    _fh_log "INFO" "--- 最終品質チェック ---"
    if qg_run_quality_gate "$project_dir" "$quality_threshold"; then
        _fh_log "INFO" "═══ 最終品質ゲートPASS ═══"
        return 0
    else
        _fh_log "WARN" "═══ 最終品質ゲートFAIL (${max_loops}ループ後) ═══"
        echo -e "  ${YELLOW:-}⚠️ ${_FH_HEALED_COUNT}件は修復しましたが、${_FH_FAILED_COUNT}件は自動修復できませんでした${NC:-}"
        echo -e "  ${YELLOW:-}   手動での確認・修正が必要です${NC:-}"
        return 1
    fi
}

# ============================================================
# Get healing statistics
# ============================================================
fh_get_stats() {
    echo "{\"healed\": ${_FH_HEALED_COUNT}, \"failed\": ${_FH_FAILED_COUNT}}"
}
