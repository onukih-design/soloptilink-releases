#!/usr/bin/env bash
# SoloptiLinkAI v2033.1 - Import Error Resolver (IER)
# learning/errors/ から「fix が失敗した import_error / type_error」を抽出し、
# 構造化された解決テンプレを solutions/index.jsonl に蓄積する
#
# 対応エラー (学習データから自動抽出):
#   - import_error / "Cannot find module"     (saas, severity 5, fix 0/1)  [v2033.0]
#   - type_error  / "Property X does not exist" (crm, severity 7, fix 2/2 = 100%)  [v2033.1 NEW]
#
# v2033.1 改修内容 (Daily Upgrade 2026-05-11):
#   - 既存 import_error テンプレに加えて type_error を 0-shot 解決パターンとして追加
#   - patterns.jsonl から fix_success_rate>=80% のエラーは「実証済み解決法」として
#     solutions/index.jsonl に success_count を実値で反映する ier_promote_proven_pattern を追加
#   - ier_summary に「実証済み解決パターン」セクションを追加

[[ -n "${_IER_LOADED:-}" ]] && return 0
_IER_LOADED=1

IER_VERSION="2034.2"
IER_HOME="${SOLOPTILINK_HOME:-$HOME/.soloptilink}"
IER_LEARN="${IER_HOME}/learning"
IER_RAW="${IER_LEARN}/errors/raw_failures.jsonl"
IER_PATTERNS="${IER_LEARN}/errors/patterns.jsonl"
IER_SOLUTIONS="${IER_LEARN}/solutions/index.jsonl"

ier_failed_import_count() {
    [[ -f "$IER_RAW" ]] || { echo 0; return; }
    grep -c '"error_type":"import_error"' "$IER_RAW" 2>/dev/null \
        | head -1 \
        || echo 0
}

ier_failed_import_unfixed() {
    [[ -f "$IER_RAW" ]] || { echo 0; return; }
    awk '/"error_type":"import_error"/ && /"fix_success":false/' "$IER_RAW" 2>/dev/null \
        | wc -l \
        | tr -d ' '
}

# v2033.1 NEW: type_error 集計
ier_type_error_total() {
    [[ -f "$IER_RAW" ]] || { echo 0; return; }
    grep -c '"error_type":"type_error"' "$IER_RAW" 2>/dev/null \
        | head -1 \
        || echo 0
}

# v2033.1 NEW: type_error 成功率 (patterns.jsonl から)
ier_type_error_success_rate() {
    [[ -f "$IER_PATTERNS" ]] || { echo 0; return; }
    awk '/"error_type":"type_error"/' "$IER_PATTERNS" 2>/dev/null \
        | grep -oE '"fix_success_rate":[0-9]+' \
        | grep -oE '[0-9]+$' \
        | head -1 \
        || echo 0
}

# 解決テンプレ: "Cannot find module" 系の構造的修正手順
ier_template_cannot_find_module() {
    cat <<'EOF'
1. tsconfig.json paths / package.json imports / vite/next エイリアスの 3 経路を全部 grep
2. node_modules/<package>/package.json の "main"/"exports" フィールドを確認
3. ESM/CJS の差異 (extension .js 必須かどうか) を確認
4. node_modules を一旦削除 → npm ci で純粋再構築 → tsc --noEmit で再現確認
5. 解決したら solutions/index.jsonl に success_count++ で追記
EOF
}

# v2033.1 NEW: 解決テンプレ "Property X does not exist on type Y" (TS2339/2741 系)
ier_template_property_does_not_exist() {
    cat <<'EOF'
1. 該当の型定義 (interface / type / Prisma model) を grep し、想定プロパティが宣言されているか確認
2. 宣言が無ければ: (a) interface に追加 / (b) Prisma schema に追加 + migrate / (c) zod schema 拡張
3. 宣言があるのに型エラー → tsconfig "strict": true の null/undefined 取り扱いを確認 (?. or ! 演算子 / Optional Chaining)
4. union 型の場合は narrowing (typeof / in / instanceof) を入れて該当ブランチに到達してから参照
5. import パスの型エクスポート漏れ (export type) を確認
6. tsc --noEmit で再現確認 → 解決したら solutions/index.jsonl の success_count++
EOF
}

# solutions に新エントリを append (idempotent: 同 signature 既存ならスキップ)
ier_register_solution() {
    local signature="${1:-import_error_cannot_find_module}"
    local domain="${2:-saas}"
    local description="${3:-4-step structural resolver: tsconfig paths -> package.json exports -> ESM/CJS check -> npm ci rebuild}"
    mkdir -p "$(dirname "$IER_SOLUTIONS")"
    touch "$IER_SOLUTIONS"

    if grep -q "\"error_signature\":\"${signature}\"" "$IER_SOLUTIONS" 2>/dev/null; then
        echo "[IER] solution already registered: ${signature}"
        return 0
    fi

    local now
    now=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    local fix_hash
    fix_hash=$(echo -n "${signature}|${domain}|v${IER_VERSION}" | shasum -a 256 2>/dev/null | awk '{print $1}' | head -c 8)
    [[ -z "$fix_hash" ]] && fix_hash="ier20331"

    cat >> "$IER_SOLUTIONS" <<EOF
{"error_signature":"${signature}","domain":"${domain}","fix_hash":"${fix_hash}","fix_description":"${description}","success_count":0,"fail_count":0,"success_rate":null,"last_used":"${now}","registered_by":"IER v${IER_VERSION}"}
EOF
    echo "[IER] solution registered: ${signature} (hash=${fix_hash})"
}

# v2033.1 NEW: 実証済み解決パターン (patterns.jsonl の fix_success_rate>=80%) を solutions に昇格
# - 既存 entry があれば success_count を patterns.jsonl の fix_success_count で更新
# - 無ければ新規追加 (success_count を実値で初期化)
ier_promote_proven_pattern() {
    [[ -f "$IER_PATTERNS" ]] || { echo "[IER] no patterns.jsonl"; return 0; }
    mkdir -p "$(dirname "$IER_SOLUTIONS")"
    touch "$IER_SOLUTIONS"

    local promoted=0
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        local etype domain rate succ total sig
        etype=$(echo "$line" | grep -oE '"error_type":"[^"]+"' | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
        domain=$(echo "$line" | grep -oE '"domain":"[^"]+"' | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
        rate=$(echo "$line" | grep -oE '"fix_success_rate":[0-9]+' | grep -oE '[0-9]+$' | head -1)
        succ=$(echo "$line" | grep -oE '"fix_success_count":[0-9]+' | grep -oE '[0-9]+$' | head -1)
        total=$(echo "$line" | grep -oE '"fix_total_count":[0-9]+' | grep -oE '[0-9]+$' | head -1)
        [[ -z "$etype" || -z "$domain" || -z "$rate" ]] && continue
        [[ "$rate" -lt 80 ]] && continue

        sig="${etype}_proven_${domain}"
        # 既存 entry をチェック
        if grep -q "\"error_signature\":\"${sig}\"" "$IER_SOLUTIONS" 2>/dev/null; then
            # 既存 → success_count を patterns 値に更新 (in-place upgrade)
            local tmp
            tmp=$(mktemp)
            awk -v sig="$sig" -v sc="$succ" -v fc="$((total-succ))" -v rate="$rate" -v now="$(date -u +%Y-%m-%dT%H:%M:%SZ)" '
                BEGIN { FS=""; updated=0 }
                {
                    if (index($0, "\"error_signature\":\"" sig "\"") > 0) {
                        line=$0
                        sub(/"success_count":[0-9]+/, "\"success_count\":" sc, line)
                        sub(/"fail_count":[0-9]+/,    "\"fail_count\":" fc, line)
                        sub(/"success_rate":[^,}]*/,  "\"success_rate\":" rate, line)
                        sub(/"last_used":"[^"]*"/,    "\"last_used\":\"" now "\"", line)
                        print line
                        updated=1
                    } else {
                        print $0
                    }
                }
            ' "$IER_SOLUTIONS" > "$tmp" && mv "$tmp" "$IER_SOLUTIONS"
            echo "[IER] proven pattern UPDATED: ${sig} (success=${succ}/${total}, rate=${rate}%)"
        else
            local fix_desc
            case "$etype" in
                type_error) fix_desc="Proven type-narrowing fix: declare missing prop in interface/Prisma OR use ?./! optional chaining OR narrow union type. Verified ${succ}/${total} success.";;
                import_error) fix_desc="4-step structural resolver: tsconfig paths -> package.json exports -> ESM/CJS check -> npm ci rebuild. Verified ${succ}/${total} success.";;
                *) fix_desc="Proven fix verified ${succ}/${total} times in domain ${domain}";;
            esac
            local now hash
            now=$(date -u +%Y-%m-%dT%H:%M:%SZ)
            hash=$(echo -n "${sig}|v${IER_VERSION}" | shasum -a 256 2>/dev/null | awk '{print $1}' | head -c 8)
            [[ -z "$hash" ]] && hash="ier20331"
            cat >> "$IER_SOLUTIONS" <<EOF
{"error_signature":"${sig}","domain":"${domain}","fix_hash":"${hash}","fix_description":"${fix_desc}","success_count":${succ},"fail_count":$((total-succ)),"success_rate":${rate},"last_used":"${now}","registered_by":"IER v${IER_VERSION} (promoted)"}
EOF
            echo "[IER] proven pattern PROMOTED: ${sig} (success=${succ}/${total}, rate=${rate}%)"
        fi
        promoted=$((promoted + 1))
    done < "$IER_PATTERNS"
    echo "[IER] total proven patterns processed: ${promoted}"
}

# v2033.1 NEW: 蓄積済み実証パターン件数
ier_proven_solution_count() {
    [[ -f "$IER_SOLUTIONS" ]] || { echo 0; return; }
    grep -c '"registered_by":"IER v[^"]*(promoted)"' "$IER_SOLUTIONS" 2>/dev/null \
        | head -1 \
        || echo 0
}

ier_summary() {
    local total unfixed type_total type_rate proven
    total=$(ier_failed_import_count)
    unfixed=$(ier_failed_import_unfixed)
    type_total=$(ier_type_error_total)
    type_rate=$(ier_type_error_success_rate)
    proven=$(ier_proven_solution_count)

    echo "- import_error 総数: ${total}"
    echo "- うち fix未成功: ${unfixed}"
    if [[ "$unfixed" -gt 0 ]]; then
        echo "- structural fix template (import_error):"
        ier_template_cannot_find_module | sed 's/^/    /'
    fi
    echo "- type_error 総数: ${type_total} (実証 fix 成功率: ${type_rate}%)"
    if [[ "$type_total" -gt 0 ]]; then
        echo "- structural fix template (type_error):"
        ier_template_property_does_not_exist | sed 's/^/    /'
    fi
    echo "- 蓄積された実証済み解決パターン: ${proven} 件 (solutions/index.jsonl)"
}

ier_run() {
    local unfixed
    unfixed=$(ier_failed_import_unfixed)
    if [[ "$unfixed" -gt 0 ]]; then
        ier_register_solution "import_error_cannot_find_module" "saas" \
            "4-step structural resolver: tsconfig paths -> package.json exports -> ESM/CJS check -> npm ci rebuild"
    fi
    # v2033.1: 実証済みパターンを solutions に自動昇格
    ier_promote_proven_pattern
    ier_summary
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-run}" in
        run) ier_run ;;
        summary) ier_summary ;;
        register) ier_register_solution "${2:-import_error_cannot_find_module}" "${3:-saas}" ;;
        promote) ier_promote_proven_pattern ;;
        version) echo "$IER_VERSION" ;;
        *) echo "usage: $0 {run|summary|register [sig] [domain]|promote|version}" >&2; exit 2 ;;
    esac
fi
