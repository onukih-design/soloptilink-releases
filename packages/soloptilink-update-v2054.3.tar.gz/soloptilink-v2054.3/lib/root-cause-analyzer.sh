#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v252.0 - Root Cause Analyzer
# =============================================================================
# エラーの表面的な症状ではなく、根本原因を特定するエンジン。
#
# 問題: エラーメッセージが示す場所が本当の原因でないことが多い。
#   - "Cannot read property 'name' of undefined" → 原因はAPI応答の形式変更
#   - "Module not found: @/lib/db" → 原因はtsconfig.jsonのpaths設定
#   - "Type error in page.tsx" → 原因はPrismaスキーマの変更
#
# 解決: エラー発生箇所からimport/呼び出し/データフローを逆方向にトレースし、
#   根本原因の場所と修正すべきファイルを特定する。
#
# Functions:
#   rca_init              - 初期化
#   _rca_analyze          - エラーから根本原因を分析
#   _rca_build_cause_chain - 症状→中間原因→根本原因のチェーンを構築
#   _rca_find_related_files - エラーチェーンに関与する全ファイルを発見
#   _rca_suggest_fix_location - 修正すべきファイル/行を提案
#   _rca_get_context      - 根本原因周辺のコードコンテキストを取得
#   rca_report            - レポート出力
#   rca_score             - モジュールスコア(0-100)
#
# All globals use the RCA_ prefix.
# =============================================================================

[[ -n "${_ROOT_CAUSE_ANALYZER_LOADED:-}" ]] && return 0
_ROOT_CAUSE_ANALYZER_LOADED=1

RCA_VERSION="252.0"
RCA_INITIALIZED=false

# --- Paths ---
RCA_CACHE_DIR=""
RCA_HISTORY_FILE=""

# --- Counters ---
RCA_TOTAL_ANALYZED=0
RCA_ROOT_FOUND=0
RCA_ROOT_MISSED=0
RCA_AVG_CHAIN_DEPTH=0

# --- In-memory storage ---
declare -g -A _RCA_CAUSE_CHAINS=()    # error_hash → cause chain JSON
declare -g -A _RCA_FIX_LOCATIONS=()   # error_hash → suggested fix location
declare -g -a _RCA_RECENT_ANALYSES=() # recent analysis results (FIFO, max 50)

# =============================================================================
# rca_init - Initialize root cause analyzer
# =============================================================================
rca_init() {
    RCA_CACHE_DIR="${HOME}/.soloptilink/cache/rca"
    mkdir -p "$RCA_CACHE_DIR" 2>/dev/null || true

    RCA_HISTORY_FILE="${RCA_CACHE_DIR}/rca-history.jsonl"

    RCA_TOTAL_ANALYZED=0
    RCA_ROOT_FOUND=0
    RCA_ROOT_MISSED=0
    RCA_AVG_CHAIN_DEPTH=0
    _RCA_CAUSE_CHAINS=()
    _RCA_FIX_LOCATIONS=()
    _RCA_RECENT_ANALYSES=()

    # Load history
    _rca_load_history

    RCA_INITIALIZED=true
    return 0
}

# =============================================================================
# _rca_hash_error - Create a short hash for an error message (for dedup)
# Arguments:
#   $1 - error message
# Returns:
#   hash string via stdout
# =============================================================================
_rca_hash_error() {
    local msg="${1:-}"
    # Use first 100 chars to create a simple hash
    echo "$msg" | head -c 100 | cksum | awk '{print $1}'
}

# =============================================================================
# _rca_analyze - Analyze an error to find root cause
# Arguments:
#   $1 - error_message
#   $2 - project_dir (optional, default ".")
#   $3 - error_file (optional, file where error occurred)
# Returns:
#   JSON analysis result via stdout
# =============================================================================
_rca_analyze() {
    local error_message="${1:-}"
    local project_dir="${2:-.}"
    local error_file="${3:-}"

    [[ -z "$error_message" ]] && echo '{"root_cause":"unknown","confidence":0}' && return 1

    RCA_TOTAL_ANALYZED=$((RCA_TOTAL_ANALYZED + 1))

    local error_hash
    error_hash=$(_rca_hash_error "$error_message")

    # Check cache
    if [[ -n "${_RCA_CAUSE_CHAINS[$error_hash]:-}" ]]; then
        echo "${_RCA_CAUSE_CHAINS[$error_hash]}"
        return 0
    fi

    # Step 1: Extract error location
    local symptom_file=""
    local symptom_line=0
    local symptom_func=""

    # Parse file:line from error message
    symptom_file=$(echo "$error_message" | grep -oE '[/.][a-zA-Z0-9_/.-]+\.(ts|tsx|js|jsx):[0-9]+' | head -1 | sed 's/:[0-9]*$//')
    if [[ -z "$symptom_file" ]]; then
        symptom_file=$(echo "$error_message" | grep -oE '\./[a-zA-Z0-9_/.-]+\.(ts|tsx|js|jsx)' | head -1)
    fi
    symptom_line=$(echo "$error_message" | grep -oE ':[0-9]+' | head -1 | tr -d ':')
    symptom_func=$(echo "$error_message" | grep -oE 'at ([a-zA-Z0-9_.]+)' | head -1 | sed 's/at //')

    # Use provided error_file if parsing failed
    [[ -z "$symptom_file" && -n "$error_file" ]] && symptom_file="$error_file"

    # Step 2: Determine error type for analysis strategy
    local error_type="unknown"
    _rca_detect_error_type "$error_message"
    error_type="$_RCA_DETECTED_TYPE"

    # Step 3: Trace to root cause based on error type
    local root_file=""
    local root_line=0
    local root_reason=""
    local confidence=0
    local chain_depth=0

    case "$error_type" in
        "import_error")
            _rca_trace_import_error "$error_message" "$project_dir" "$symptom_file"
            ;;
        "type_error")
            _rca_trace_type_error "$error_message" "$project_dir" "$symptom_file"
            ;;
        "api_error")
            _rca_trace_api_error "$error_message" "$project_dir" "$symptom_file"
            ;;
        "db_error")
            _rca_trace_db_error "$error_message" "$project_dir" "$symptom_file"
            ;;
        "config_error")
            _rca_trace_config_error "$error_message" "$project_dir" "$symptom_file"
            ;;
        *)
            _rca_trace_generic_error "$error_message" "$project_dir" "$symptom_file"
            ;;
    esac

    root_file="${_RCA_TRACE_FILE:-$symptom_file}"
    root_line="${_RCA_TRACE_LINE:-0}"
    root_reason="${_RCA_TRACE_REASON:-$error_message}"
    confidence="${_RCA_TRACE_CONFIDENCE:-30}"
    chain_depth="${_RCA_TRACE_DEPTH:-1}"

    if [[ -n "$root_file" && "$root_file" != "$symptom_file" ]]; then
        RCA_ROOT_FOUND=$((RCA_ROOT_FOUND + 1))
    elif [[ -n "$root_reason" && "$root_reason" != "$error_message" ]]; then
        RCA_ROOT_FOUND=$((RCA_ROOT_FOUND + 1))
    else
        RCA_ROOT_MISSED=$((RCA_ROOT_MISSED + 1))
    fi

    # Update average chain depth
    local total_depth=$((RCA_AVG_CHAIN_DEPTH * (RCA_TOTAL_ANALYZED - 1) + chain_depth))
    RCA_AVG_CHAIN_DEPTH=$((total_depth / RCA_TOTAL_ANALYZED))

    # Build result
    local safe_symptom
    safe_symptom=$(echo "$error_message" | head -c 300 | sed 's/"/\\"/g; s/\t/ /g; s/\r//g')
    local safe_reason
    safe_reason=$(echo "$root_reason" | head -c 300 | sed 's/"/\\"/g; s/\t/ /g; s/\r//g')

    local result
    result=$(cat <<EOF
{
  "symptom": {
    "file": "${symptom_file:-}",
    "line": ${symptom_line:-0},
    "function": "${symptom_func:-}",
    "message": "${safe_symptom}"
  },
  "root_cause": {
    "file": "${root_file:-}",
    "line": ${root_line:-0},
    "reason": "${safe_reason}",
    "type": "${error_type}"
  },
  "confidence": ${confidence},
  "chain_depth": ${chain_depth}
}
EOF
)

    # Cache the result
    _RCA_CAUSE_CHAINS["$error_hash"]="$result"
    _RCA_FIX_LOCATIONS["$error_hash"]="${root_file:-$symptom_file}"

    # Add to recent analyses (FIFO)
    _RCA_RECENT_ANALYSES+=("$result")
    if [[ ${#_RCA_RECENT_ANALYSES[@]} -gt 50 ]]; then
        _RCA_RECENT_ANALYSES=("${_RCA_RECENT_ANALYSES[@]:1}")
    fi

    # Persist
    _rca_save_history "$result"

    echo "$result"
    return 0
}

# --- Internal: detected error type storage ---
_RCA_DETECTED_TYPE=""

# =============================================================================
# _rca_detect_error_type - Determine the high-level error type
# =============================================================================
_rca_detect_error_type() {
    local msg="${1:-}"

    if echo "$msg" | grep -qiE 'Cannot find module|Module not found|import.*error|ERR_MODULE_NOT_FOUND'; then
        _RCA_DETECTED_TYPE="import_error"
    elif echo "$msg" | grep -qiE 'TypeError|Type.*not assignable|Property.*does not exist|TS2[0-9]{3}'; then
        _RCA_DETECTED_TYPE="type_error"
    elif echo "$msg" | grep -qiE '404.*Not Found.*api|405.*Method|fetch.*failed.*api|route.*not found|API.*error'; then
        _RCA_DETECTED_TYPE="api_error"
    elif echo "$msg" | grep -qiE 'PrismaClient|P[0-9]{4}|database|migration|SQLITE|unique constraint|foreign key'; then
        _RCA_DETECTED_TYPE="db_error"
    elif echo "$msg" | grep -qiE 'config.*error|\.env|tsconfig|ENOENT.*config|missing.*env'; then
        _RCA_DETECTED_TYPE="config_error"
    else
        _RCA_DETECTED_TYPE="generic"
    fi
}

# --- Internal: trace result storage ---
_RCA_TRACE_FILE=""
_RCA_TRACE_LINE=0
_RCA_TRACE_REASON=""
_RCA_TRACE_CONFIDENCE=0
_RCA_TRACE_DEPTH=1

# =============================================================================
# _rca_trace_import_error - Trace import/module resolution errors
# =============================================================================
_rca_trace_import_error() {
    local msg="${1:-}"
    local project_dir="${2:-.}"
    local symptom_file="${3:-}"

    _RCA_TRACE_FILE=""
    _RCA_TRACE_LINE=0
    _RCA_TRACE_REASON=""
    _RCA_TRACE_CONFIDENCE=30
    _RCA_TRACE_DEPTH=1

    # Extract the missing module path
    local missing_module
    missing_module=$(echo "$msg" | grep -oE "Cannot find module '[^']+'" | sed "s/Cannot find module '//;s/'//")
    [[ -z "$missing_module" ]] && missing_module=$(echo "$msg" | grep -oE "Module not found:.*'[^']+'" | sed "s/.*'//;s/'//")
    [[ -z "$missing_module" ]] && missing_module=$(echo "$msg" | grep -oE "Could not resolve '[^']+'" | sed "s/Could not resolve '//;s/'//")

    if [[ -z "$missing_module" ]]; then
        _RCA_TRACE_REASON="インポートエラーだがモジュールパスを特定できず"
        return 0
    fi

    # Case 1: Path alias (e.g., @/lib/db)
    if echo "$missing_module" | grep -qE '^@/'; then
        local resolved_path
        resolved_path=$(echo "$missing_module" | sed 's|^@/||')

        # Check tsconfig.json paths
        local tsconfig="${project_dir}/tsconfig.json"
        if [[ -f "$tsconfig" ]]; then
            local has_paths
            has_paths=$(grep -c '"paths"' "$tsconfig" 2>/dev/null || echo "0")
            if [[ "$has_paths" -eq 0 ]]; then
                _RCA_TRACE_FILE="$tsconfig"
                _RCA_TRACE_REASON="tsconfig.jsonにpaths設定がない。@/エイリアスが解決できない。paths: {\"@/*\": [\"./*\"]} を追加する必要がある。"
                _RCA_TRACE_CONFIDENCE=85
                _RCA_TRACE_DEPTH=2
                return 0
            fi
        fi

        # Check if target file exists
        local target_candidates=("${project_dir}/${resolved_path}.ts" "${project_dir}/${resolved_path}.tsx" "${project_dir}/${resolved_path}/index.ts" "${project_dir}/${resolved_path}/index.tsx")
        local found=false
        for candidate in "${target_candidates[@]}"; do
            if [[ -f "$candidate" ]]; then
                found=true
                break
            fi
        done

        if [[ "$found" == "false" ]]; then
            _RCA_TRACE_FILE="${project_dir}/${resolved_path}"
            _RCA_TRACE_REASON="インポート先ファイルが存在しない: ${resolved_path}。ファイルを作成するか、インポートパスを修正する必要がある。"
            _RCA_TRACE_CONFIDENCE=90
            _RCA_TRACE_DEPTH=2
            return 0
        fi
    fi

    # Case 2: Node module
    if ! echo "$missing_module" | grep -qE '^[./]'; then
        local pkg_json="${project_dir}/package.json"
        if [[ -f "$pkg_json" ]]; then
            local pkg_name
            pkg_name=$(echo "$missing_module" | sed 's|/.*||')
            local in_deps
            in_deps=$(grep -c "\"${pkg_name}\"" "$pkg_json" 2>/dev/null || echo "0")

            if [[ "$in_deps" -eq 0 ]]; then
                _RCA_TRACE_FILE="$pkg_json"
                _RCA_TRACE_REASON="パッケージ '${pkg_name}' がpackage.jsonに定義されていない。npm install ${pkg_name} が必要。"
                _RCA_TRACE_CONFIDENCE=90
                _RCA_TRACE_DEPTH=2
                return 0
            else
                _RCA_TRACE_FILE="${project_dir}/node_modules/${pkg_name}"
                _RCA_TRACE_REASON="パッケージ '${pkg_name}' はpackage.jsonにあるがnode_modulesにない。npm installが必要。"
                _RCA_TRACE_CONFIDENCE=75
                _RCA_TRACE_DEPTH=2
                return 0
            fi
        fi
    fi

    # Case 3: Relative import
    if echo "$missing_module" | grep -qE '^[./]' && [[ -n "$symptom_file" ]]; then
        local base_dir
        base_dir=$(dirname "${project_dir}/${symptom_file}" 2>/dev/null || echo "$project_dir")
        local resolved
        resolved=$(cd "$base_dir" 2>/dev/null && realpath "$missing_module" 2>/dev/null || echo "")

        _RCA_TRACE_FILE="${base_dir}/${missing_module}"
        _RCA_TRACE_REASON="相対パス '${missing_module}' の解決先にファイルが存在しない。パスを修正するかファイルを作成する必要がある。"
        _RCA_TRACE_CONFIDENCE=70
        _RCA_TRACE_DEPTH=2
        return 0
    fi

    _RCA_TRACE_REASON="モジュール '${missing_module}' が見つからない"
    _RCA_TRACE_CONFIDENCE=40
}

# =============================================================================
# _rca_trace_type_error - Trace TypeScript type errors to root cause
# =============================================================================
_rca_trace_type_error() {
    local msg="${1:-}"
    local project_dir="${2:-.}"
    local symptom_file="${3:-}"

    _RCA_TRACE_FILE=""
    _RCA_TRACE_LINE=0
    _RCA_TRACE_REASON=""
    _RCA_TRACE_CONFIDENCE=30
    _RCA_TRACE_DEPTH=1

    # Case 1: Prisma type mismatch
    if echo "$msg" | grep -qiE 'Prisma|@prisma/client'; then
        local schema_file="${project_dir}/prisma/schema.prisma"
        if [[ -f "$schema_file" ]]; then
            _RCA_TRACE_FILE="$schema_file"
            _RCA_TRACE_REASON="Prismaスキーマと使用箇所の型が不一致。prisma/schema.prismaを修正後、npx prisma generateで型を再生成する必要がある。"
            _RCA_TRACE_CONFIDENCE=80
            _RCA_TRACE_DEPTH=3
            return 0
        fi
    fi

    # Case 2: Property does not exist on type
    local missing_prop
    missing_prop=$(echo "$msg" | grep -oE "Property '[^']+' does not exist on type '[^']+'" | head -1)
    if [[ -n "$missing_prop" ]]; then
        local prop_name
        prop_name=$(echo "$missing_prop" | grep -oE "Property '[^']+'" | sed "s/Property '//;s/'//")
        local type_name
        type_name=$(echo "$missing_prop" | grep -oE "type '[^']+'" | sed "s/type '//;s/'//")

        # Search for the type definition
        if [[ -n "$type_name" ]]; then
            local type_file
            type_file=$(grep -rlE "(interface|type) ${type_name}" "${project_dir}" --include="*.ts" --include="*.tsx" 2>/dev/null | head -1)

            if [[ -n "$type_file" ]]; then
                local type_line
                type_line=$(grep -nE "(interface|type) ${type_name}" "$type_file" 2>/dev/null | head -1 | cut -d: -f1)
                _RCA_TRACE_FILE="$type_file"
                _RCA_TRACE_LINE="${type_line:-0}"
                _RCA_TRACE_REASON="型 '${type_name}' にプロパティ '${prop_name}' が定義されていない。型定義を更新する必要がある。"
                _RCA_TRACE_CONFIDENCE=85
                _RCA_TRACE_DEPTH=2
                return 0
            fi
        fi
    fi

    # Case 3: Type 'X' is not assignable to type 'Y'
    local actual_type
    actual_type=$(echo "$msg" | grep -oE "Type '[^']+' is not assignable" | sed "s/Type '//;s/' is not assignable//")
    local expected_type
    expected_type=$(echo "$msg" | grep -oE "to type '[^']+'" | sed "s/to type '//;s/'//")

    if [[ -n "$actual_type" && -n "$expected_type" ]]; then
        # Trace where the actual type comes from
        if [[ -n "$symptom_file" ]]; then
            local full_path="${project_dir}/${symptom_file}"
            if [[ -f "$full_path" ]]; then
                # Check if the variable is receiving data from an API call
                local api_usage
                api_usage=$(grep -nE "fetch|axios|api\." "$full_path" 2>/dev/null | head -3)
                if [[ -n "$api_usage" ]]; then
                    _RCA_TRACE_REASON="APIレスポンスの型(${actual_type})と期待型(${expected_type})が不一致。APIルートのレスポンス型またはフロントエンドの型定義を修正する必要がある。"
                    _RCA_TRACE_CONFIDENCE=70
                    _RCA_TRACE_DEPTH=3
                    return 0
                fi
            fi
        fi

        _RCA_TRACE_REASON="型 '${actual_type}' を '${expected_type}' に割り当てできない。型定義を統一する必要がある。"
        _RCA_TRACE_CONFIDENCE=50
        _RCA_TRACE_DEPTH=2
        return 0
    fi

    _RCA_TRACE_REASON="TypeScript型エラー。型定義の確認が必要。"
    _RCA_TRACE_CONFIDENCE=30
}

# =============================================================================
# _rca_trace_api_error - Trace API contract errors
# =============================================================================
_rca_trace_api_error() {
    local msg="${1:-}"
    local project_dir="${2:-.}"
    local symptom_file="${3:-}"

    _RCA_TRACE_FILE=""
    _RCA_TRACE_LINE=0
    _RCA_TRACE_REASON=""
    _RCA_TRACE_CONFIDENCE=30
    _RCA_TRACE_DEPTH=1

    # Extract API path
    local api_path
    api_path=$(echo "$msg" | grep -oE '/api/[a-zA-Z0-9/_-]+' | head -1)

    if [[ -n "$api_path" ]]; then
        # Convert API path to file system path (Next.js convention)
        local route_file="${project_dir}/app${api_path}/route.ts"
        local route_file_js="${project_dir}/app${api_path}/route.js"

        if [[ -f "$route_file" ]]; then
            # Route exists - check method handlers
            local method
            method=$(echo "$msg" | grep -oiE '(GET|POST|PUT|DELETE|PATCH)' | head -1)
            if [[ -n "$method" ]]; then
                local has_method
                has_method=$(grep -cE "export (async )?function ${method}" "$route_file" 2>/dev/null || echo "0")
                if [[ "$has_method" -eq 0 ]]; then
                    local handler_line
                    handler_line=$(grep -nE "export" "$route_file" 2>/dev/null | head -1 | cut -d: -f1)
                    _RCA_TRACE_FILE="$route_file"
                    _RCA_TRACE_LINE="${handler_line:-0}"
                    _RCA_TRACE_REASON="APIルート ${api_path} に ${method} ハンドラが定義されていない。export async function ${method}(request: NextRequest)を追加する必要がある。"
                    _RCA_TRACE_CONFIDENCE=90
                    _RCA_TRACE_DEPTH=2
                    return 0
                fi
            fi

            _RCA_TRACE_FILE="$route_file"
            _RCA_TRACE_REASON="APIルート ${api_path} は存在するがエラーが発生。ハンドラ内部のロジックを確認する必要がある。"
            _RCA_TRACE_CONFIDENCE=60
            _RCA_TRACE_DEPTH=2
            return 0
        elif [[ -f "$route_file_js" ]]; then
            _RCA_TRACE_FILE="$route_file_js"
            _RCA_TRACE_CONFIDENCE=60
            _RCA_TRACE_DEPTH=2
            return 0
        else
            # Route file doesn't exist
            _RCA_TRACE_FILE="$route_file"
            _RCA_TRACE_REASON="APIルート ${api_path} に対応するroute.tsが存在しない。app${api_path}/route.tsを作成する必要がある。"
            _RCA_TRACE_CONFIDENCE=95
            _RCA_TRACE_DEPTH=2

            # Find the fetch call in source
            if [[ -n "$symptom_file" && -f "${project_dir}/${symptom_file}" ]]; then
                local fetch_line
                fetch_line=$(grep -nE "fetch.*${api_path}" "${project_dir}/${symptom_file}" 2>/dev/null | head -1 | cut -d: -f1)
                if [[ -n "$fetch_line" ]]; then
                    _RCA_TRACE_DEPTH=3
                fi
            fi
            return 0
        fi
    fi

    _RCA_TRACE_REASON="API関連エラー。エンドポイントとフロントエンドの整合性を確認する必要がある。"
    _RCA_TRACE_CONFIDENCE=30
}

# =============================================================================
# _rca_trace_db_error - Trace database errors to schema/migration root cause
# =============================================================================
_rca_trace_db_error() {
    local msg="${1:-}"
    local project_dir="${2:-.}"
    local symptom_file="${3:-}"

    _RCA_TRACE_FILE=""
    _RCA_TRACE_LINE=0
    _RCA_TRACE_REASON=""
    _RCA_TRACE_CONFIDENCE=30
    _RCA_TRACE_DEPTH=1

    local schema_file="${project_dir}/prisma/schema.prisma"

    # Case 1: Unknown field/column
    local unknown_field
    unknown_field=$(echo "$msg" | grep -oiE "column '[^']+' not found|Unknown.*field.*'[^']+'" | head -1)
    if [[ -n "$unknown_field" ]]; then
        local field_name
        field_name=$(echo "$unknown_field" | grep -oE "'[^']+'" | head -1 | tr -d "'")

        if [[ -f "$schema_file" ]]; then
            _RCA_TRACE_FILE="$schema_file"
            _RCA_TRACE_REASON="フィールド '${field_name}' がデータベーススキーマに存在しない。prisma/schema.prismaにフィールドを追加し、npx prisma db pushを実行する必要がある。"
            _RCA_TRACE_CONFIDENCE=90
            _RCA_TRACE_DEPTH=2
            return 0
        fi
    fi

    # Case 2: Unique constraint violation
    if echo "$msg" | grep -qiE 'unique constraint|duplicate key'; then
        local constraint_field
        constraint_field=$(echo "$msg" | grep -oE "fields: \`[^)]+\`" | sed 's/fields: `//;s/`//' | head -1)
        [[ -z "$constraint_field" ]] && constraint_field=$(echo "$msg" | grep -oE "key.*'[^']+'" | grep -oE "'[^']+'" | tr -d "'")

        if [[ -n "$constraint_field" ]]; then
            _RCA_TRACE_FILE="${symptom_file:-$schema_file}"
            _RCA_TRACE_REASON="ユニーク制約違反 (${constraint_field})。重複データの挿入を防ぐためにupsertを使うか、事前に存在チェックを行う必要がある。"
            _RCA_TRACE_CONFIDENCE=80
            _RCA_TRACE_DEPTH=2
            return 0
        fi
    fi

    # Case 3: Foreign key violation
    if echo "$msg" | grep -qiE 'foreign key'; then
        _RCA_TRACE_FILE="$schema_file"
        _RCA_TRACE_REASON="外部キー制約違反。参照先のレコードが存在しないか、削除順序が不正。リレーション定義とデータ操作順序を確認する必要がある。"
        _RCA_TRACE_CONFIDENCE=75
        _RCA_TRACE_DEPTH=3
        return 0
    fi

    # Case 4: Migration error
    if echo "$msg" | grep -qiE 'migration.*failed|migrate.*error'; then
        local migration_dir="${project_dir}/prisma/migrations"
        _RCA_TRACE_FILE="$migration_dir"
        _RCA_TRACE_REASON="マイグレーション失敗。prisma/migrationsの最新マイグレーションを確認するか、npx prisma migrate resetでリセットする必要がある。"
        _RCA_TRACE_CONFIDENCE=70
        _RCA_TRACE_DEPTH=2
        return 0
    fi

    # Case 5: Connection error
    if echo "$msg" | grep -qiE 'ECONNREFUSED|connection.*refused|Can.*t reach'; then
        _RCA_TRACE_FILE="${project_dir}/.env"
        _RCA_TRACE_REASON="データベース接続エラー。DATABASE_URL環境変数の確認とデータベースサーバーの起動状態を確認する必要がある。"
        _RCA_TRACE_CONFIDENCE=85
        _RCA_TRACE_DEPTH=2
        return 0
    fi

    if [[ -f "$schema_file" ]]; then
        _RCA_TRACE_FILE="$schema_file"
    fi
    _RCA_TRACE_REASON="データベースエラー。スキーマ定義とクエリの整合性を確認する必要がある。"
    _RCA_TRACE_CONFIDENCE=40
}

# =============================================================================
# _rca_trace_config_error - Trace configuration errors
# =============================================================================
_rca_trace_config_error() {
    local msg="${1:-}"
    local project_dir="${2:-.}"
    local symptom_file="${3:-}"

    _RCA_TRACE_FILE=""
    _RCA_TRACE_LINE=0
    _RCA_TRACE_REASON=""
    _RCA_TRACE_CONFIDENCE=30
    _RCA_TRACE_DEPTH=1

    # Missing env variable
    local missing_env
    missing_env=$(echo "$msg" | grep -oE '[A-Z_]{3,}' | head -1)

    if echo "$msg" | grep -qiE 'env|environment.*variable'; then
        local env_file="${project_dir}/.env"
        if [[ -f "$env_file" ]]; then
            if [[ -n "$missing_env" ]]; then
                local defined
                defined=$(grep -c "^${missing_env}=" "$env_file" 2>/dev/null || echo "0")
                if [[ "$defined" -eq 0 ]]; then
                    _RCA_TRACE_FILE="$env_file"
                    _RCA_TRACE_REASON="環境変数 '${missing_env}' が.envに定義されていない。.envファイルに ${missing_env}=値 を追加する必要がある。"
                    _RCA_TRACE_CONFIDENCE=90
                    _RCA_TRACE_DEPTH=2
                    return 0
                fi
            fi
        else
            _RCA_TRACE_FILE="$env_file"
            _RCA_TRACE_REASON=".envファイルが存在しない。.env.exampleをコピーして.envを作成し、環境変数を設定する必要がある。"
            _RCA_TRACE_CONFIDENCE=90
            _RCA_TRACE_DEPTH=2
            return 0
        fi
    fi

    # tsconfig error
    if echo "$msg" | grep -qiE 'tsconfig'; then
        _RCA_TRACE_FILE="${project_dir}/tsconfig.json"
        _RCA_TRACE_REASON="tsconfig.jsonの設定エラー。コンパイラオプションとパス設定を確認する必要がある。"
        _RCA_TRACE_CONFIDENCE=70
        _RCA_TRACE_DEPTH=2
        return 0
    fi

    _RCA_TRACE_REASON="設定ファイルのエラー。関連する設定ファイルを確認する必要がある。"
    _RCA_TRACE_CONFIDENCE=30
}

# =============================================================================
# _rca_trace_generic_error - Generic error tracing via stack/imports
# =============================================================================
_rca_trace_generic_error() {
    local msg="${1:-}"
    local project_dir="${2:-.}"
    local symptom_file="${3:-}"

    _RCA_TRACE_FILE=""
    _RCA_TRACE_LINE=0
    _RCA_TRACE_REASON=""
    _RCA_TRACE_CONFIDENCE=20
    _RCA_TRACE_DEPTH=1

    # Try to trace via stack frames
    local stack_files
    stack_files=$(echo "$msg" | grep -oE 'at [a-zA-Z0-9_.]+ \([^)]+\)' | grep -oE '\([^)]+\)' | tr -d '()' | sed 's/:[0-9]*:[0-9]*$//')

    if [[ -n "$stack_files" ]]; then
        # Find the deepest application file (not node_modules)
        local deepest_file=""
        while IFS= read -r frame_file; do
            if ! echo "$frame_file" | grep -qE 'node_modules|internal/|<anonymous>'; then
                deepest_file="$frame_file"
            fi
        done <<< "$stack_files"

        if [[ -n "$deepest_file" ]]; then
            _RCA_TRACE_FILE="$deepest_file"
            _RCA_TRACE_REASON="スタックトレースの最深部アプリケーションコード。この関数の入力値/状態を確認する必要がある。"
            _RCA_TRACE_CONFIDENCE=50
            _RCA_TRACE_DEPTH=2
            return 0
        fi
    fi

    # Fallback: look for the source of undefined/null
    if echo "$msg" | grep -qiE 'undefined|null|Cannot read'; then
        if [[ -n "$symptom_file" && -f "${project_dir}/${symptom_file}" ]]; then
            # Check if data comes from props/API
            local data_source
            data_source=$(grep -nE '(props\.|useQuery|useSWR|fetch|axios|\.data)' "${project_dir}/${symptom_file}" 2>/dev/null | head -1)
            if [[ -n "$data_source" ]]; then
                _RCA_TRACE_FILE="${project_dir}/${symptom_file}"
                _RCA_TRACE_LINE=$(echo "$data_source" | cut -d: -f1)
                _RCA_TRACE_REASON="undefinedアクセス。データソース(API/props)からのレスポンスがnull/undefinedの可能性。オプショナルチェーニング(?.)またはデフォルト値を使用する必要がある。"
                _RCA_TRACE_CONFIDENCE=55
                _RCA_TRACE_DEPTH=2
                return 0
            fi
        fi
    fi

    _RCA_TRACE_REASON="$msg"
    _RCA_TRACE_CONFIDENCE=20
}

# =============================================================================
# _rca_build_cause_chain - Build symptom → intermediate → root cause chain
# Arguments:
#   $1 - error_message
#   $2 - project_dir
# Returns:
#   JSON chain via stdout
# =============================================================================
_rca_build_cause_chain() {
    local error_message="${1:-}"
    local project_dir="${2:-.}"

    # First get the full analysis
    local analysis
    analysis=$(_rca_analyze "$error_message" "$project_dir")

    local symptom_file symptom_msg root_file root_reason chain_depth
    symptom_file=$(echo "$analysis" | grep -oE '"file": *"[^"]*"' | head -1 | sed 's/"file": *"//;s/"//')
    symptom_msg=$(echo "$analysis" | grep -oE '"message": *"[^"]*"' | head -1 | sed 's/"message": *"//;s/"//')
    root_file=$(echo "$analysis" | grep -oE '"file": *"[^"]*"' | tail -1 | sed 's/"file": *"//;s/"//')
    root_reason=$(echo "$analysis" | grep -oE '"reason": *"[^"]*"' | head -1 | sed 's/"reason": *"//;s/"//')
    chain_depth=$(echo "$analysis" | grep -oE '"chain_depth": *[0-9]+' | sed 's/"chain_depth": *//')

    # Build intermediate step(s)
    local intermediate=""
    if [[ "${chain_depth:-1}" -ge 2 && -n "$symptom_file" && -n "$root_file" && "$symptom_file" != "$root_file" ]]; then
        # Find intermediate connection (e.g., import chain)
        if [[ -f "${project_dir}/${symptom_file}" ]]; then
            local imports
            imports=$(grep -E "^import|^from|require\(" "${project_dir}/${symptom_file}" 2>/dev/null | head -5)
            if [[ -n "$imports" ]]; then
                local safe_imports
                safe_imports=$(echo "$imports" | head -c 200 | sed 's/"/\\"/g; s/\n/ /g')
                intermediate=",{\"step\":\"intermediate\",\"file\":\"${symptom_file}\",\"detail\":\"このファイルのインポート/依存を経由: ${safe_imports}\"}"
            fi
        fi
    fi

    cat <<EOF
{
  "chain": [
    {"step": "symptom", "file": "${symptom_file:-}", "detail": "$(echo "$symptom_msg" | head -c 200 | sed 's/"/\\"/g')"}${intermediate},
    {"step": "root_cause", "file": "${root_file:-}", "detail": "$(echo "$root_reason" | head -c 200 | sed 's/"/\\"/g')"}
  ],
  "depth": ${chain_depth:-1}
}
EOF
    return 0
}

# =============================================================================
# _rca_find_related_files - Find all files involved in the error chain
# Arguments:
#   $1 - error_message
#   $2 - project_dir
# Returns:
#   JSON array of file paths via stdout
# =============================================================================
_rca_find_related_files() {
    local error_message="${1:-}"
    local project_dir="${2:-.}"

    local analysis
    analysis=$(_rca_analyze "$error_message" "$project_dir")

    local symptom_file root_file
    symptom_file=$(echo "$analysis" | grep -oE '"file": *"[^"]*"' | head -1 | sed 's/"file": *"//;s/"//')
    root_file=$(echo "$analysis" | grep -oE '"file": *"[^"]*"' | tail -1 | sed 's/"file": *"//;s/"//')

    local files=()
    [[ -n "$symptom_file" ]] && files+=("$symptom_file")
    [[ -n "$root_file" && "$root_file" != "$symptom_file" ]] && files+=("$root_file")

    # Find files that import the symptom file
    if [[ -n "$symptom_file" ]]; then
        local basename_no_ext
        basename_no_ext=$(basename "$symptom_file" | sed 's/\.[^.]*$//')

        local importers
        importers=$(grep -rlE "from.*['\"].*${basename_no_ext}['\"]|import.*${basename_no_ext}" "$project_dir" \
            --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" 2>/dev/null | head -5)

        while IFS= read -r importer; do
            [[ -z "$importer" ]] && continue
            local rel_path
            rel_path=$(echo "$importer" | sed "s|^${project_dir}/||")
            local already_added=false
            for f in "${files[@]}"; do
                [[ "$f" == "$rel_path" ]] && already_added=true && break
            done
            [[ "$already_added" == "false" ]] && files+=("$rel_path")
        done <<< "$importers"
    fi

    # Find files that the root cause file imports
    if [[ -n "$root_file" && -f "${project_dir}/${root_file}" ]]; then
        local imported_modules
        imported_modules=$(grep -oE "from ['\"]([^'\"]+)['\"]" "${project_dir}/${root_file}" 2>/dev/null | sed "s/from ['\"]//;s/['\"]//")
        while IFS= read -r mod; do
            [[ -z "$mod" ]] && continue
            if echo "$mod" | grep -qE '^[./]'; then
                local dir
                dir=$(dirname "$root_file")
                local resolved="${dir}/${mod}"
                local already=false
                for f in "${files[@]}"; do
                    [[ "$f" == "$resolved"* ]] && already=true && break
                done
                [[ "$already" == "false" ]] && files+=("$resolved")
            fi
        done <<< "$imported_modules"
    fi

    # Build JSON array
    local json="["
    local first=true
    for f in "${files[@]}"; do
        if [[ "$first" == "true" ]]; then
            first=false
        else
            json="${json},"
        fi
        json="${json}\"${f}\""
    done
    json="${json}]"

    echo "$json"
    return 0
}

# =============================================================================
# _rca_suggest_fix_location - Suggest which file/line to fix
# Arguments:
#   $1 - error_message
#   $2 - project_dir
# Returns:
#   JSON with suggested fix location
# =============================================================================
_rca_suggest_fix_location() {
    local error_message="${1:-}"
    local project_dir="${2:-.}"

    local analysis
    analysis=$(_rca_analyze "$error_message" "$project_dir")

    local root_file root_line root_reason confidence
    root_file=$(echo "$analysis" | grep -oE '"root_cause":\{[^}]*\}' | grep -oE '"file":"[^"]*"' | sed 's/"file":"//;s/"//')
    root_line=$(echo "$analysis" | grep -oE '"root_cause":\{[^}]*\}' | grep -oE '"line":[0-9]*' | sed 's/"line"://')
    root_reason=$(echo "$analysis" | grep -oE '"reason":"[^"]*"' | head -1 | sed 's/"reason":"//;s/"//')
    confidence=$(echo "$analysis" | grep -oE '"confidence":[0-9]*' | sed 's/"confidence"://')

    cat <<EOF
{
  "fix_file": "${root_file:-}",
  "fix_line": ${root_line:-0},
  "reason": "$(echo "${root_reason:-}" | head -c 300 | sed 's/"/\\"/g')",
  "confidence": ${confidence:-0},
  "note": "$(
    if [[ ${confidence:-0} -ge 80 ]]; then
        echo "高信頼度: この場所の修正で解決する可能性が高い"
    elif [[ ${confidence:-0} -ge 50 ]]; then
        echo "中信頼度: この場所を起点に調査を開始すべき"
    else
        echo "低信頼度: 手動分析を推奨"
    fi
  )"
}
EOF
    return 0
}

# =============================================================================
# _rca_get_context - Get code context around the root cause location
# Arguments:
#   $1 - file_path
#   $2 - line_number
#   $3 - context_lines (default 10)
# Returns:
#   Code context via stdout
# =============================================================================
_rca_get_context() {
    local file_path="${1:-}"
    local line_num="${2:-0}"
    local context="${3:-10}"

    [[ -z "$file_path" || ! -f "$file_path" ]] && echo '{"context":"file not found"}' && return 1

    local start=$((line_num - context))
    [[ $start -lt 1 ]] && start=1
    local end=$((line_num + context))

    local code_block
    code_block=$(sed -n "${start},${end}p" "$file_path" 2>/dev/null | head -c 2000)

    local total_lines
    total_lines=$(wc -l < "$file_path" 2>/dev/null | tr -d ' ')

    local safe_code
    safe_code=$(echo "$code_block" | sed 's/"/\\"/g; s/\t/  /g' | tr '\n' '|' | sed 's/|/\\n/g')

    cat <<EOF
{
  "file": "${file_path}",
  "target_line": ${line_num},
  "range": {"start": ${start}, "end": ${end}},
  "total_lines": ${total_lines:-0},
  "code": "${safe_code}"
}
EOF
    return 0
}

# =============================================================================
# _rca_load_history / _rca_save_history - Persistence
# =============================================================================
_rca_load_history() {
    [[ ! -f "$RCA_HISTORY_FILE" ]] && return 0

    local count=0
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        count=$((count + 1))
    done < "$RCA_HISTORY_FILE"

    # Just count for now; full load deferred
    return 0
}

_rca_save_history() {
    local entry="${1:-}"
    [[ -z "$entry" || -z "$RCA_HISTORY_FILE" ]] && return 0

    # Compact to single line
    local compact
    compact=$(echo "$entry" | tr '\n' ' ' | sed 's/  */ /g')
    echo "$compact" >> "$RCA_HISTORY_FILE" 2>/dev/null || true

    # Rotate if too large (keep last 500 entries)
    local lines
    lines=$(wc -l < "$RCA_HISTORY_FILE" 2>/dev/null | tr -d ' ')
    if [[ "${lines:-0}" -gt 500 ]]; then
        tail -200 "$RCA_HISTORY_FILE" > "${RCA_HISTORY_FILE}.tmp" 2>/dev/null
        mv "${RCA_HISTORY_FILE}.tmp" "$RCA_HISTORY_FILE" 2>/dev/null || true
    fi

    return 0
}

# =============================================================================
# rca_report - Module report output
# =============================================================================
rca_report() {
    echo -e "\n  ${CLR_BOLD:-}═══ Root Cause Analyzer v${RCA_VERSION} ═══${CLR_NC:-}" >&2
    echo -e "  分析総数           : ${RCA_TOTAL_ANALYZED}" >&2
    echo -e "  根本原因特定       : ${RCA_ROOT_FOUND}" >&2
    echo -e "  特定失敗           : ${RCA_ROOT_MISSED}" >&2
    echo -e "  平均チェーン深度   : ${RCA_AVG_CHAIN_DEPTH}" >&2

    if [[ $RCA_TOTAL_ANALYZED -gt 0 ]]; then
        local success_rate=$(( (RCA_ROOT_FOUND * 100) / RCA_TOTAL_ANALYZED ))
        echo -e "  根本原因特定率     : ${success_rate}%" >&2
    fi
}

# =============================================================================
# rca_score - Module score (0-100)
# =============================================================================
rca_score() {
    local score=50

    if [[ $RCA_TOTAL_ANALYZED -gt 0 ]]; then
        score=$(( (RCA_ROOT_FOUND * 70) / RCA_TOTAL_ANALYZED ))
    fi

    [[ $RCA_TOTAL_ANALYZED -ge 5 ]] && score=$((score + 10))
    [[ $RCA_TOTAL_ANALYZED -ge 20 ]] && score=$((score + 10))
    [[ $RCA_AVG_CHAIN_DEPTH -ge 2 ]] && score=$((score + 10))

    [[ $score -gt 100 ]] && score=100
    [[ $score -lt 0 ]] && score=0

    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "root-cause-analyzer" \
    --version "252.0" \
    --description "エラーの根本原因を逆方向トレースで特定" \
    --init "rca_init" \
    --report "rca_report" \
    --score "rca_score" \
    --enable-var "ENABLE_RCA" \
    --cli-flags "--root-cause-analyzer:--no-root-cause-analyzer"
