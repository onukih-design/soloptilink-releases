#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v384.0 - Data Model Intelligence
# =============================================================================
# データモデルインテリジェンスエンジン。
# ドメイン分析→スキーマ提案→最適化を自動で行う。
#
# All globals use the DMI_ prefix.
# =============================================================================

[[ -n "${_DATA_MODEL_INTELLIGENCE_LOADED:-}" ]] && return 0
_DATA_MODEL_INTELLIGENCE_LOADED=1

declare -g DMI_VERSION="384.0"
declare -g DMI_INITIALIZED=false
declare -g DMI_ANALYZED_COUNT=0
declare -g DMI_SUGGESTED_COUNT=0
declare -g DMI_OPTIMIZED_COUNT=0
declare -g ENABLE_DMI="${ENABLE_DMI:-true}"

_dmi_init() {
    DMI_INITIALIZED=true
    DMI_ANALYZED_COUNT=0
    DMI_SUGGESTED_COUNT=0
    DMI_OPTIMIZED_COUNT=0
    return 0
}

_dmi_run_all() {
    local project_dir="${1:-.}"
    local domain="${2:-generic}"
    [[ "$DMI_INITIALIZED" != "true" ]] && _dmi_init

    echo -e "  ${CYAN:-\033[0;36m}[DMI]${NC:-\033[0m} データモデルインテリジェンス開始 (domain=${domain})..." >&2

    _dmi_analyze_domain "$project_dir" "$domain"
    _dmi_suggest_model "$project_dir" "$domain"
    _dmi_optimize_schema "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[DMI]${NC:-\033[0m} データモデル分析完了" >&2
    return 0
}

# =============================================================================
# ドメイン分析
# =============================================================================
_dmi_analyze_domain() {
    local project_dir="${1:-.}"
    local domain="${2:-generic}"

    cat <<'TEMPLATE'
## [DMI-ANALYZE] ドメイン分析テンプレート

### Domain Entity Extraction
```typescript
interface DomainEntity {
  name: string;
  description: string;
  attributes: EntityAttribute[];
  relationships: EntityRelation[];
  businessRules: string[];
}

interface EntityAttribute {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'date' | 'json' | 'enum';
  required: boolean;
  unique: boolean;
  defaultValue?: any;
  validation?: string;
}

interface EntityRelation {
  target: string;
  type: 'one-to-one' | 'one-to-many' | 'many-to-many';
  required: boolean;
  cascadeDelete: boolean;
}

// ドメイン別エンティティマップ
const DOMAIN_ENTITIES: Record<string, DomainEntity[]> = {
  crm: [
    { name: 'Company', description: '取引先企業', attributes: [
      { name: 'name', type: 'string', required: true, unique: false },
      { name: 'industry', type: 'string', required: false, unique: false },
      { name: 'website', type: 'string', required: false, unique: false },
      { name: 'phone', type: 'string', required: false, unique: false },
    ], relationships: [
      { target: 'Contact', type: 'one-to-many', required: false, cascadeDelete: true },
      { target: 'Deal', type: 'one-to-many', required: false, cascadeDelete: false },
    ], businessRules: ['企業名は必須', '削除時にContactも削除'] },
  ],
  ec: [
    { name: 'Product', description: '商品', attributes: [
      { name: 'name', type: 'string', required: true, unique: false },
      { name: 'price', type: 'number', required: true, unique: false },
      { name: 'sku', type: 'string', required: false, unique: true },
    ], relationships: [
      { target: 'Category', type: 'many-to-many', required: false, cascadeDelete: false },
      { target: 'OrderItem', type: 'one-to-many', required: false, cascadeDelete: false },
    ], businessRules: ['価格は0以上', 'SKUは一意'] },
  ],
};

export function analyzeAndExtract(domain: string, requirements: string): DomainEntity[] {
  const baseEntities = DOMAIN_ENTITIES[domain] ?? [];
  // requirements から追加エンティティを推論
  return baseEntities;
}
```
TEMPLATE

    DMI_ANALYZED_COUNT=$((DMI_ANALYZED_COUNT + 1))
    return 0
}

# =============================================================================
# スキーマ提案
# =============================================================================
_dmi_suggest_model() {
    local project_dir="${1:-.}"
    local domain="${2:-generic}"

    cat <<'TEMPLATE'
## [DMI-SUGGEST] データモデル提案テンプレート

### Schema Generator
```typescript
export function generatePrismaSchema(entities: DomainEntity[]): string {
  let schema = '';
  for (const entity of entities) {
    schema += `model ${entity.name} {\n`;
    schema += `  id        String   @id @default(cuid())\n`;

    for (const attr of entity.attributes) {
      const prismaType = mapToPrismaType(attr.type);
      const modifiers: string[] = [];
      if (attr.unique) modifiers.push('@unique');
      if (!attr.required) prismaType + '?';
      if (attr.defaultValue !== undefined) modifiers.push(`@default(${JSON.stringify(attr.defaultValue)})`);
      schema += `  ${attr.name.padEnd(12)} ${attr.required ? prismaType : prismaType + '?'} ${modifiers.join(' ')}\n`;
    }

    for (const rel of entity.relationships) {
      if (rel.type === 'one-to-many') {
        schema += `  ${camelCase(rel.target)}s ${rel.target}[]\n`;
      } else if (rel.type === 'many-to-many') {
        schema += `  ${camelCase(rel.target)}s ${rel.target}[]\n`;
      }
    }

    schema += `  createdAt  DateTime @default(now())\n`;
    schema += `  updatedAt  DateTime @updatedAt\n`;
    schema += `}\n\n`;
  }
  return schema;
}

function mapToPrismaType(type: string): string {
  const map: Record<string, string> = { string: 'String', number: 'Int', boolean: 'Boolean', date: 'DateTime', json: 'Json', enum: 'String' };
  return map[type] ?? 'String';
}
```

### Index Suggestions
```typescript
export function suggestIndexes(entities: DomainEntity[]): IndexSuggestion[] {
  const suggestions: IndexSuggestion[] = [];
  for (const entity of entities) {
    // FK fields should be indexed
    for (const rel of entity.relationships) {
      if (rel.type === 'one-to-many' || rel.type === 'one-to-one') {
        suggestions.push({ model: entity.name, fields: [`${camelCase(rel.target)}Id`], reason: 'Foreign key lookup' });
      }
    }
    // Status fields should be indexed
    const statusField = entity.attributes.find(a => a.name === 'status');
    if (statusField) suggestions.push({ model: entity.name, fields: ['status'], reason: 'Frequent status filtering' });
    // Date fields for range queries
    suggestions.push({ model: entity.name, fields: ['createdAt'], reason: 'Date range queries' });
  }
  return suggestions;
}
```
TEMPLATE

    DMI_SUGGESTED_COUNT=$((DMI_SUGGESTED_COUNT + 1))
    return 0
}

# =============================================================================
# スキーマ最適化
# =============================================================================
_dmi_optimize_schema() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [DMI-OPTIMIZE] スキーマ最適化テンプレート

### N+1 Query Detection
```typescript
export function detectNPlusOneRisks(schema: string): NPlusOneRisk[] {
  const risks: NPlusOneRisk[] = [];
  const models = parseModels(schema);
  for (const model of models) {
    const relations = model.fields.filter(f => f.isRelation);
    if (relations.length > 2) {
      risks.push({ model: model.name, relations: relations.map(r => r.name),
        suggestion: `${model.name}のクエリ時にincludeを限定するか、select句を使用してください` });
    }
  }
  return risks;
}

// Composite Index Suggestion
export function suggestCompositeIndexes(queryPatterns: QueryPattern[]): CompositeIndex[] {
  const indexes: CompositeIndex[] = [];
  for (const pattern of queryPatterns) {
    if (pattern.whereFields.length > 1) {
      indexes.push({ model: pattern.model, fields: pattern.whereFields,
        reason: `WHERE句で${pattern.whereFields.join(', ')}を同時に使用` });
    }
    if (pattern.orderByField && pattern.whereFields.length > 0) {
      indexes.push({ model: pattern.model, fields: [...pattern.whereFields, pattern.orderByField],
        reason: `フィルタ+ソートの複合インデックス` });
    }
  }
  return indexes;
}
```
TEMPLATE

    DMI_OPTIMIZED_COUNT=$((DMI_OPTIMIZED_COUNT + 1))
    return 0
}

_dmi_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Data Model Intelligence v${DMI_VERSION} ===${NC:-\033[0m}"
    echo -e "  ドメイン分析数     : ${DMI_ANALYZED_COUNT}"
    echo -e "  モデル提案数       : ${DMI_SUGGESTED_COUNT}"
    echo -e "  最適化数           : ${DMI_OPTIMIZED_COUNT}"
}

_dmi_score() {
    local score=30
    [[ "$DMI_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ $DMI_ANALYZED_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $DMI_SUGGESTED_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $DMI_OPTIMIZED_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "data-model-intelligence" \
    --version "384.0" \
    --description "データモデルインテリジェンス（ドメイン分析/スキーマ提案/最適化）" \
    --init "_dmi_init" \
    --report "_dmi_report" \
    --score "_dmi_score" \
    --enable-var "ENABLE_DMI" \
    --cli-flags "--data-model:--no-data-model"
