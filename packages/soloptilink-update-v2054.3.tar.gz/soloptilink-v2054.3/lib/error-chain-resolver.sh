#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v256.0 - Error Chain Resolver
# =============================================================================
# エラーチェーン解析・一括解決エンジン。
# 複数のエラーが1つのルート原因から派生している場合を検出し、
# チェーン全体を一括修正するプロンプトを生成する。
#
# 典型的なチェーン:
#   missing import -> type error -> build error
#   missing env var -> connection error -> handler crash
#   schema drift -> migration error -> client generation error -> type mismatch
#   missing dependency -> module not found -> compile error -> test failure
#
# Functions:
#   _ecr_init             - 初期化・ストレージ準備
#   _ecr_detect_chain     - 複数エラーが1つのルート原因から派生しているか検出
#   _ecr_group_errors     - 関連エラーをチェーンにグループ化
#   _ecr_find_chain_root  - チェーン内のルートエラーを特定
#   _ecr_resolve_chain    - チェーン全体を一括修正するプロンプト生成
#   _ecr_validate_chain_fix - チェーン修正が全リンクエラーを解決したか検証
#   _ecr_report           - レポート出力
#   _ecr_score            - モジュールスコア(0-100)
#
# All globals use the ECR_ prefix.
# =============================================================================

[[ -n "${_ERROR_CHAIN_RESOLVER_LOADED:-}" ]] && return 0
_ERROR_CHAIN_RESOLVER_LOADED=1

# --- Colors (fallback) ---
readonly _ECR_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly _ECR_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly _ECR_RED="${CLR_RED:-\033[0;31m}"
readonly _ECR_BLUE="${CLR_BLUE:-\033[0;34m}"
readonly _ECR_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly _ECR_PURPLE="${CLR_PURPLE:-\033[0;35m}"
readonly _ECR_BOLD="${CLR_BOLD:-\033[1m}"
readonly _ECR_NC="${CLR_NC:-\033[0m}"

# --- Module State ---
ECR_VERSION="256.0"
ECR_INITIALIZED=false
ECR_ENABLED="${ECR_ENABLED:-true}"

# --- Counters ---
ECR_TOTAL_ERRORS=0
ECR_CHAINS_DETECTED=0
ECR_CHAINS_RESOLVED=0
ECR_ROOT_CAUSES_FOUND=0
ECR_FIXES_GENERATED=0
ECR_FIXES_VALIDATED=0
ECR_FIXES_PASSED=0

# --- Storage ---
ECR_STORE_DIR=""
ECR_CHAIN_LOG=""
ECR_PATTERN_DB=""

# --- In-memory error buffer ---
declare -g -a _ECR_ERROR_MSGS=()
declare -g -a _ECR_ERROR_FILES=()
declare -g -a _ECR_ERROR_LINES=()
declare -g -a _ECR_ERROR_TYPES=()
declare -g -a _ECR_ERROR_PHASES=()
declare -g -a _ECR_ERROR_TIMESTAMPS=()

# --- Chain storage ---
declare -g -a _ECR_CHAIN_IDS=()
declare -g -A _ECR_CHAIN_MEMBERS=()     # chain_id -> "idx1,idx2,idx3"
declare -g -A _ECR_CHAIN_ROOT=()        # chain_id -> root error index
declare -g -A _ECR_CHAIN_TYPE=()        # chain_id -> chain type name
declare -g -A _ECR_CHAIN_STATUS=()      # chain_id -> "detected"|"resolving"|"resolved"|"failed"
declare -g -A _ECR_CHAIN_FIX=()         # chain_id -> fix prompt text

# =============================================================================
# Chain Pattern Database - 40+ known error chain patterns
# Each pattern: "trigger_type|cascade_type1|cascade_type2|...|name|priority"
# =============================================================================
declare -g -a _ECR_CHAIN_PATTERNS=()

_ecr_init_pattern_db() {
    _ECR_CHAIN_PATTERNS=()

    # --- Import / Module chains ---
    _ECR_CHAIN_PATTERNS+=("import|type|build|Missing Import Chain|90")
    _ECR_CHAIN_PATTERNS+=("import|compile|test|Import Compile Test Chain|88")
    _ECR_CHAIN_PATTERNS+=("import|reference|render|Import Reference Render Chain|85")
    _ECR_CHAIN_PATTERNS+=("module_not_found|import|type|Module Resolution Chain|92")
    _ECR_CHAIN_PATTERNS+=("module_not_found|compile|build|Module Build Chain|90")
    _ECR_CHAIN_PATTERNS+=("circular_import|type|runtime|Circular Dependency Chain|87")

    # --- Environment variable chains ---
    _ECR_CHAIN_PATTERNS+=("env_missing|connection|handler_crash|Env Connection Chain|95")
    _ECR_CHAIN_PATTERNS+=("env_missing|config|startup|Env Config Startup Chain|93")
    _ECR_CHAIN_PATTERNS+=("env_missing|auth|api_error|Env Auth API Chain|91")
    _ECR_CHAIN_PATTERNS+=("env_invalid|validation|runtime|Env Validation Chain|89")
    _ECR_CHAIN_PATTERNS+=("env_missing|prisma_connection|migration|Env Prisma Chain|94")

    # --- Schema / Database chains ---
    _ECR_CHAIN_PATTERNS+=("schema_drift|migration|client_gen|type_mismatch|Schema Drift Chain|96")
    _ECR_CHAIN_PATTERNS+=("schema_drift|prisma_validate|client_gen|Schema Validation Chain|94")
    _ECR_CHAIN_PATTERNS+=("missing_field|query|runtime|Missing Field Chain|88")
    _ECR_CHAIN_PATTERNS+=("wrong_relation|foreign_key|query|Relation Error Chain|86")
    _ECR_CHAIN_PATTERNS+=("migration_failed|schema_mismatch|client_gen|Migration Failure Chain|93")
    _ECR_CHAIN_PATTERNS+=("unique_constraint|insert|handler_crash|Unique Constraint Chain|85")

    # --- TypeScript type chains ---
    _ECR_CHAIN_PATTERNS+=("type_mismatch|generic|compile|Type Mismatch Chain|87")
    _ECR_CHAIN_PATTERNS+=("missing_property|type|build|Missing Property Chain|86")
    _ECR_CHAIN_PATTERNS+=("null_check|runtime|crash|Null Safety Chain|90")
    _ECR_CHAIN_PATTERNS+=("any_type|type_assertion|runtime|Unsafe Type Chain|82")
    _ECR_CHAIN_PATTERNS+=("generic_constraint|type|compile|Generic Constraint Chain|84")
    _ECR_CHAIN_PATTERNS+=("overload_mismatch|type|build|Overload Resolution Chain|83")

    # --- Next.js specific chains ---
    _ECR_CHAIN_PATTERNS+=("hydration|render|dom_mismatch|Hydration Chain|91")
    _ECR_CHAIN_PATTERNS+=("ssr|window_undefined|render|SSR Client Chain|89")
    _ECR_CHAIN_PATTERNS+=("middleware|redirect|page_error|Middleware Chain|87")
    _ECR_CHAIN_PATTERNS+=("app_router|layout|render|App Router Chain|88")
    _ECR_CHAIN_PATTERNS+=("api_route|handler|response|API Route Chain|86")
    _ECR_CHAIN_PATTERNS+=("server_component|client_import|build|Server Component Chain|90")

    # --- React specific chains ---
    _ECR_CHAIN_PATTERNS+=("hook_violation|render|crash|Hook Violation Chain|92")
    _ECR_CHAIN_PATTERNS+=("render_loop|state|memory|Render Loop Chain|94")
    _ECR_CHAIN_PATTERNS+=("missing_key|reconciliation|performance|Key Error Chain|80")
    _ECR_CHAIN_PATTERNS+=("state_during_render|infinite_loop|crash|State Update Chain|93")
    _ECR_CHAIN_PATTERNS+=("ref_null|dom_access|crash|Ref Error Chain|85")
    _ECR_CHAIN_PATTERNS+=("context_missing|undefined|type|Context Chain|84")

    # --- Dependency / Package chains ---
    _ECR_CHAIN_PATTERNS+=("dep_missing|import|compile|Dependency Missing Chain|91")
    _ECR_CHAIN_PATTERNS+=("dep_version|peer_dep|build|Dependency Version Chain|88")
    _ECR_CHAIN_PATTERNS+=("dep_conflict|resolution|install|Dependency Conflict Chain|86")
    _ECR_CHAIN_PATTERNS+=("lockfile_mismatch|install|build|Lockfile Chain|84")

    # --- Configuration chains ---
    _ECR_CHAIN_PATTERNS+=("tsconfig|path_alias|import|TSConfig Path Chain|87")
    _ECR_CHAIN_PATTERNS+=("eslint_config|lint|ci|ESLint Config Chain|79")
    _ECR_CHAIN_PATTERNS+=("webpack_config|bundle|build|Webpack Config Chain|83")
    _ECR_CHAIN_PATTERNS+=("next_config|build|deploy|Next Config Chain|85")
}

# =============================================================================
# Error Type Classification Rules
# Maps error message patterns to canonical error types
# =============================================================================
declare -g -A _ECR_TYPE_RULES=()

_ecr_init_type_rules() {
    _ECR_TYPE_RULES=()

    # Import / Module errors
    _ECR_TYPE_RULES["Cannot find module"]="module_not_found"
    _ECR_TYPE_RULES["Module not found"]="module_not_found"
    _ECR_TYPE_RULES["ModuleNotFoundError"]="module_not_found"
    _ECR_TYPE_RULES["cannot resolve"]="module_not_found"
    _ECR_TYPE_RULES["Could not find a declaration file"]="import"
    _ECR_TYPE_RULES["is not a module"]="import"
    _ECR_TYPE_RULES["has no exported member"]="import"
    _ECR_TYPE_RULES["has no default export"]="import"
    _ECR_TYPE_RULES["Circular dependency"]="circular_import"

    # Type errors
    _ECR_TYPE_RULES["Type .* is not assignable to type"]="type_mismatch"
    _ECR_TYPE_RULES["Property .* does not exist on type"]="missing_property"
    _ECR_TYPE_RULES["Cannot read properties of null"]="null_check"
    _ECR_TYPE_RULES["Cannot read properties of undefined"]="null_check"
    _ECR_TYPE_RULES["Object is possibly 'null'"]="null_check"
    _ECR_TYPE_RULES["Object is possibly 'undefined'"]="null_check"
    _ECR_TYPE_RULES["Argument of type .* is not assignable"]="type_mismatch"
    _ECR_TYPE_RULES["Generic type .* requires"]="generic_constraint"
    _ECR_TYPE_RULES["No overload matches this call"]="overload_mismatch"
    _ECR_TYPE_RULES["has no property"]="missing_property"
    _ECR_TYPE_RULES["is not a function"]="type_mismatch"

    # Environment errors
    _ECR_TYPE_RULES["DATABASE_URL"]="env_missing"
    _ECR_TYPE_RULES["NEXTAUTH_SECRET"]="env_missing"
    _ECR_TYPE_RULES["API_KEY"]="env_missing"
    _ECR_TYPE_RULES["Missing environment variable"]="env_missing"
    _ECR_TYPE_RULES["env is not defined"]="env_missing"
    _ECR_TYPE_RULES["Invalid environment"]="env_invalid"

    # Connection errors
    _ECR_TYPE_RULES["ECONNREFUSED"]="connection"
    _ECR_TYPE_RULES["ECONNRESET"]="connection"
    _ECR_TYPE_RULES["ETIMEDOUT"]="connection"
    _ECR_TYPE_RULES["Can't reach database"]="connection"
    _ECR_TYPE_RULES["Connection refused"]="connection"

    # Schema / Prisma errors
    _ECR_TYPE_RULES["P1001"]="prisma_connection"
    _ECR_TYPE_RULES["P1002"]="prisma_connection"
    _ECR_TYPE_RULES["P2002"]="unique_constraint"
    _ECR_TYPE_RULES["P2003"]="foreign_key"
    _ECR_TYPE_RULES["P2025"]="missing_field"
    _ECR_TYPE_RULES["PrismaClientInitializationError"]="prisma_connection"
    _ECR_TYPE_RULES["PrismaClientValidationError"]="schema_drift"
    _ECR_TYPE_RULES["prisma migrate"]="migration_failed"
    _ECR_TYPE_RULES["database schema is not empty"]="schema_drift"
    _ECR_TYPE_RULES["prisma generate"]="client_gen"
    _ECR_TYPE_RULES["Unknown field"]="schema_drift"
    _ECR_TYPE_RULES["Unknown model"]="schema_drift"

    # Build errors
    _ECR_TYPE_RULES["Build error"]="build"
    _ECR_TYPE_RULES["tsc.*error"]="compile"
    _ECR_TYPE_RULES["Failed to compile"]="compile"
    _ECR_TYPE_RULES["webpack.*error"]="build"
    _ECR_TYPE_RULES["next build.*failed"]="build"

    # Runtime errors
    _ECR_TYPE_RULES["ReferenceError"]="reference"
    _ECR_TYPE_RULES["TypeError"]="type"
    _ECR_TYPE_RULES["RangeError"]="runtime"
    _ECR_TYPE_RULES["SyntaxError"]="syntax"
    _ECR_TYPE_RULES["Error: listen EADDRINUSE"]="runtime"
    _ECR_TYPE_RULES["SIGABRT"]="crash"
    _ECR_TYPE_RULES["SIGSEGV"]="crash"

    # React / Next.js errors
    _ECR_TYPE_RULES["Hydration failed"]="hydration"
    _ECR_TYPE_RULES["Text content does not match"]="hydration"
    _ECR_TYPE_RULES["window is not defined"]="ssr"
    _ECR_TYPE_RULES["document is not defined"]="ssr"
    _ECR_TYPE_RULES["Invalid hook call"]="hook_violation"
    _ECR_TYPE_RULES["Rendered more hooks"]="hook_violation"
    _ECR_TYPE_RULES["Too many re-renders"]="render_loop"
    _ECR_TYPE_RULES["Maximum update depth exceeded"]="render_loop"
    _ECR_TYPE_RULES["Cannot update a component"]="state_during_render"
    _ECR_TYPE_RULES["Each child in a list"]="missing_key"

    # Auth errors
    _ECR_TYPE_RULES["Unauthorized"]="auth"
    _ECR_TYPE_RULES["401"]="auth"
    _ECR_TYPE_RULES["jwt expired"]="auth"
    _ECR_TYPE_RULES["invalid token"]="auth"

    # API errors
    _ECR_TYPE_RULES["404 Not Found"]="api_error"
    _ECR_TYPE_RULES["500 Internal Server Error"]="handler_crash"
    _ECR_TYPE_RULES["INTERNAL_SERVER_ERROR"]="handler_crash"

    # Config errors
    _ECR_TYPE_RULES["tsconfig.json"]="tsconfig"
    _ECR_TYPE_RULES["next.config"]="next_config"
    _ECR_TYPE_RULES["eslintrc"]="eslint_config"
    _ECR_TYPE_RULES["paths.*alias"]="tsconfig"
}

# =============================================================================
# _ecr_init - Initialize module, prepare storage
# =============================================================================
_ecr_init() {
    [[ "$ECR_ENABLED" != "true" ]] && return 0

    ECR_STORE_DIR="${HOME}/.soloptilink/error-chains"
    mkdir -p "$ECR_STORE_DIR" 2>/dev/null || true
    ECR_CHAIN_LOG="${ECR_STORE_DIR}/chain_history.jsonl"
    ECR_PATTERN_DB="${ECR_STORE_DIR}/pattern_db.json"

    # Reset counters
    ECR_TOTAL_ERRORS=0
    ECR_CHAINS_DETECTED=0
    ECR_CHAINS_RESOLVED=0
    ECR_ROOT_CAUSES_FOUND=0
    ECR_FIXES_GENERATED=0
    ECR_FIXES_VALIDATED=0
    ECR_FIXES_PASSED=0

    # Reset buffers
    _ECR_ERROR_MSGS=()
    _ECR_ERROR_FILES=()
    _ECR_ERROR_LINES=()
    _ECR_ERROR_TYPES=()
    _ECR_ERROR_PHASES=()
    _ECR_ERROR_TIMESTAMPS=()
    _ECR_CHAIN_IDS=()
    _ECR_CHAIN_MEMBERS=()
    _ECR_CHAIN_ROOT=()
    _ECR_CHAIN_TYPE=()
    _ECR_CHAIN_STATUS=()
    _ECR_CHAIN_FIX=()

    # Initialize pattern database
    _ecr_init_pattern_db
    _ecr_init_type_rules

    ECR_INITIALIZED=true
    echo -e "  ${_ECR_GREEN}[ECR]${_ECR_NC} Error Chain Resolver v${ECR_VERSION} initialized" >&2
    return 0
}

# =============================================================================
# _ecr_classify_error - Classify a single error message into a type
# =============================================================================
_ecr_classify_error() {
    local msg="${1:-}"
    [[ -z "$msg" ]] && echo "unknown" && return 0

    local pattern type
    for pattern in "${!_ECR_TYPE_RULES[@]}"; do
        if echo "$msg" | grep -qiE "$pattern" 2>/dev/null; then
            echo "${_ECR_TYPE_RULES[$pattern]}"
            return 0
        fi
    done

    # Fallback classification by keywords
    if echo "$msg" | grep -qi "error" 2>/dev/null; then
        echo "generic_error"
    elif echo "$msg" | grep -qi "warning" 2>/dev/null; then
        echo "warning"
    else
        echo "unknown"
    fi
}

# =============================================================================
# _ecr_add_error - Add an error to the buffer for chain analysis
# =============================================================================
_ecr_add_error() {
    local msg="${1:-unknown error}"
    local file="${2:-unknown}"
    local line="${3:-0}"
    local phase="${4:-unknown}"

    local idx=${#_ECR_ERROR_MSGS[@]}
    _ECR_ERROR_MSGS+=("$msg")
    _ECR_ERROR_FILES+=("$file")
    _ECR_ERROR_LINES+=("$line")
    _ECR_ERROR_PHASES+=("$phase")
    _ECR_ERROR_TIMESTAMPS+=("$(date +%s)")

    local err_type
    err_type=$(_ecr_classify_error "$msg")
    _ECR_ERROR_TYPES+=("$err_type")

    ECR_TOTAL_ERRORS=$((ECR_TOTAL_ERRORS + 1))

    # Keep buffer manageable (max 200 errors)
    if [[ ${#_ECR_ERROR_MSGS[@]} -gt 200 ]]; then
        _ECR_ERROR_MSGS=("${_ECR_ERROR_MSGS[@]:50}")
        _ECR_ERROR_FILES=("${_ECR_ERROR_FILES[@]:50}")
        _ECR_ERROR_LINES=("${_ECR_ERROR_LINES[@]:50}")
        _ECR_ERROR_TYPES=("${_ECR_ERROR_TYPES[@]:50}")
        _ECR_ERROR_PHASES=("${_ECR_ERROR_PHASES[@]:50}")
        _ECR_ERROR_TIMESTAMPS=("${_ECR_ERROR_TIMESTAMPS[@]:50}")
    fi

    echo "$idx:$err_type"
}

# =============================================================================
# _ecr_detect_chain - Detect when multiple errors stem from one root cause
# Analyzes the error buffer for chain patterns
# Returns: number of chains detected
# =============================================================================
_ecr_detect_chain() {
    local min_chain_size="${1:-2}"
    local detected=0

    [[ ${#_ECR_ERROR_MSGS[@]} -lt 2 ]] && echo "0" && return 0

    echo -e "  ${_ECR_CYAN}[ECR]${_ECR_NC} Analyzing ${#_ECR_ERROR_MSGS[@]} errors for chain patterns..." >&2

    # Strategy 1: Match against known chain patterns
    local pattern_line
    for pattern_line in "${_ECR_CHAIN_PATTERNS[@]}"; do
        local IFS='|'
        local parts=($pattern_line)
        unset IFS

        local num_types=$((${#parts[@]} - 2))
        local chain_name="${parts[$((${#parts[@]} - 2))]}"
        local priority="${parts[$((${#parts[@]} - 1))]}"

        # Extract the type sequence from the pattern
        local -a pattern_types=()
        local i
        for ((i = 0; i < num_types; i++)); do
            pattern_types+=("${parts[$i]}")
        done

        # Search for matching sequences in error buffer
        local match_indices=""
        local matched_count=0
        local last_match_time=0

        for ((i = 0; i < ${#_ECR_ERROR_TYPES[@]}; i++)); do
            local err_type="${_ECR_ERROR_TYPES[$i]}"
            if [[ "$err_type" == "${pattern_types[$matched_count]}" ]]; then
                local err_time="${_ECR_ERROR_TIMESTAMPS[$i]:-0}"
                # Check temporal proximity (within 60 seconds)
                if [[ $matched_count -eq 0 ]] || [[ $((err_time - last_match_time)) -lt 60 ]]; then
                    if [[ -n "$match_indices" ]]; then
                        match_indices="${match_indices},${i}"
                    else
                        match_indices="${i}"
                    fi
                    matched_count=$((matched_count + 1))
                    last_match_time="$err_time"

                    if [[ $matched_count -eq ${#pattern_types[@]} ]]; then
                        # Full pattern matched
                        _ecr_create_chain "$chain_name" "$match_indices" "$priority"
                        detected=$((detected + 1))
                        break
                    fi
                fi
            fi
        done
    done

    # Strategy 2: File-based chain detection (errors in same file)
    local -A file_errors=()
    for ((i = 0; i < ${#_ECR_ERROR_FILES[@]}; i++)); do
        local f="${_ECR_ERROR_FILES[$i]}"
        [[ "$f" == "unknown" ]] && continue
        if [[ -n "${file_errors[$f]:-}" ]]; then
            file_errors["$f"]="${file_errors[$f]},${i}"
        else
            file_errors["$f"]="$i"
        fi
    done

    for f in "${!file_errors[@]}"; do
        local indices="${file_errors[$f]}"
        local count
        count=$(echo "$indices" | tr ',' '\n' | wc -l | tr -d ' ')
        if [[ $count -ge $min_chain_size ]]; then
            # Check if not already part of a detected chain
            local already_chained=false
            local first_idx="${indices%%,*}"
            for cid in "${_ECR_CHAIN_IDS[@]}"; do
                if echo "${_ECR_CHAIN_MEMBERS[$cid]:-}" | grep -q "$first_idx" 2>/dev/null; then
                    already_chained=true
                    break
                fi
            done
            if [[ "$already_chained" != "true" ]]; then
                _ecr_create_chain "File Cluster: $(basename "$f")" "$indices" "70"
                detected=$((detected + 1))
            fi
        fi
    done

    # Strategy 3: Temporal proximity chain detection
    # Errors within 5 seconds of each other are likely related
    local -a temporal_group=()
    local prev_time=0
    for ((i = 0; i < ${#_ECR_ERROR_TIMESTAMPS[@]}; i++)); do
        local ts="${_ECR_ERROR_TIMESTAMPS[$i]:-0}"
        if [[ $prev_time -gt 0 ]] && [[ $((ts - prev_time)) -le 5 ]]; then
            if [[ ${#temporal_group[@]} -eq 0 ]]; then
                temporal_group+=("$((i - 1))")
            fi
            temporal_group+=("$i")
        else
            if [[ ${#temporal_group[@]} -ge $min_chain_size ]]; then
                local t_indices=""
                for idx in "${temporal_group[@]}"; do
                    [[ -n "$t_indices" ]] && t_indices="${t_indices},"
                    t_indices="${t_indices}${idx}"
                done
                # Check not already chained
                local t_already=false
                local t_first="${temporal_group[0]}"
                for cid in "${_ECR_CHAIN_IDS[@]}"; do
                    if echo "${_ECR_CHAIN_MEMBERS[$cid]:-}" | grep -q "$t_first" 2>/dev/null; then
                        t_already=true
                        break
                    fi
                done
                if [[ "$t_already" != "true" ]]; then
                    _ecr_create_chain "Temporal Cluster" "$t_indices" "60"
                    detected=$((detected + 1))
                fi
            fi
            temporal_group=()
        fi
        prev_time="$ts"
    done
    # Handle trailing temporal group
    if [[ ${#temporal_group[@]} -ge $min_chain_size ]]; then
        local t_indices=""
        for idx in "${temporal_group[@]}"; do
            [[ -n "$t_indices" ]] && t_indices="${t_indices},"
            t_indices="${t_indices}${idx}"
        done
        local t_already=false
        local t_first="${temporal_group[0]}"
        for cid in "${_ECR_CHAIN_IDS[@]}"; do
            if echo "${_ECR_CHAIN_MEMBERS[$cid]:-}" | grep -q "$t_first" 2>/dev/null; then
                t_already=true
                break
            fi
        done
        if [[ "$t_already" != "true" ]]; then
            _ecr_create_chain "Temporal Cluster" "$t_indices" "60"
            detected=$((detected + 1))
        fi
    fi

    ECR_CHAINS_DETECTED=$((ECR_CHAINS_DETECTED + detected))
    echo -e "  ${_ECR_GREEN}[ECR]${_ECR_NC} Detected ${detected} error chain(s)" >&2
    echo "$detected"
}

# =============================================================================
# _ecr_create_chain - Internal: create a chain record
# =============================================================================
_ecr_create_chain() {
    local name="$1"
    local indices="$2"
    local priority="${3:-50}"

    local chain_id="chain_$(date +%s)_${RANDOM}"
    _ECR_CHAIN_IDS+=("$chain_id")
    _ECR_CHAIN_MEMBERS["$chain_id"]="$indices"
    _ECR_CHAIN_TYPE["$chain_id"]="$name"
    _ECR_CHAIN_STATUS["$chain_id"]="detected"
    _ECR_CHAIN_ROOT["$chain_id"]=""
    _ECR_CHAIN_FIX["$chain_id"]=""

    echo -e "  ${_ECR_BLUE}[ECR]${_ECR_NC} Chain created: ${_ECR_BOLD}${name}${_ECR_NC} (${indices}) priority=${priority}" >&2
}

# =============================================================================
# _ecr_group_errors - Group related errors into chains
# Uses multiple heuristics: same file, causal type relationship, temporal
# =============================================================================
_ecr_group_errors() {
    local project_dir="${1:-.}"

    echo -e "  ${_ECR_CYAN}[ECR]${_ECR_NC} Grouping errors into chains..." >&2

    # Re-run detection if no chains exist
    if [[ ${#_ECR_CHAIN_IDS[@]} -eq 0 ]]; then
        _ecr_detect_chain 2
    fi

    # Merge overlapping chains
    local merged=0
    local -a to_remove=()
    local num_chains=${#_ECR_CHAIN_IDS[@]}

    for ((i = 0; i < num_chains; i++)); do
        local cid1="${_ECR_CHAIN_IDS[$i]}"
        [[ -z "$cid1" ]] && continue
        local members1="${_ECR_CHAIN_MEMBERS[$cid1]:-}"

        for ((j = i + 1; j < num_chains; j++)); do
            local cid2="${_ECR_CHAIN_IDS[$j]}"
            [[ -z "$cid2" ]] && continue
            local members2="${_ECR_CHAIN_MEMBERS[$cid2]:-}"

            # Check for overlap
            local overlap=false
            local IFS=','
            for idx in $members1; do
                if echo ",$members2," | grep -q ",${idx}," 2>/dev/null; then
                    overlap=true
                    break
                fi
            done
            unset IFS

            if [[ "$overlap" == "true" ]]; then
                # Merge chain2 into chain1
                local combined
                combined=$(echo "${members1},${members2}" | tr ',' '\n' | sort -un | tr '\n' ',' | sed 's/,$//')
                _ECR_CHAIN_MEMBERS["$cid1"]="$combined"
                to_remove+=("$j")
                merged=$((merged + 1))
                echo -e "  ${_ECR_PURPLE}[ECR]${_ECR_NC} Merged chain ${cid2} into ${cid1}" >&2
            fi
        done
    done

    # Remove merged chains (reverse order)
    local -a new_chain_ids=()
    for ((i = 0; i < num_chains; i++)); do
        local should_remove=false
        for rm_idx in "${to_remove[@]}"; do
            [[ "$i" -eq "$rm_idx" ]] && should_remove=true && break
        done
        [[ "$should_remove" != "true" ]] && new_chain_ids+=("${_ECR_CHAIN_IDS[$i]}")
    done
    _ECR_CHAIN_IDS=("${new_chain_ids[@]}")

    echo -e "  ${_ECR_GREEN}[ECR]${_ECR_NC} Grouping complete: ${#_ECR_CHAIN_IDS[@]} chain(s), ${merged} merged" >&2
    echo "${#_ECR_CHAIN_IDS[@]}"
}

# =============================================================================
# _ecr_find_chain_root - Find the root error in a chain
# Root = earliest error with highest causal priority
# =============================================================================
_ecr_find_chain_root() {
    local chain_id="${1:-}"
    [[ -z "$chain_id" ]] && echo "" && return 1

    local members="${_ECR_CHAIN_MEMBERS[$chain_id]:-}"
    [[ -z "$members" ]] && echo "" && return 1

    echo -e "  ${_ECR_CYAN}[ECR]${_ECR_NC} Finding root cause for chain: ${_ECR_CHAIN_TYPE[$chain_id]:-unknown}" >&2

    # Causal priority: earlier types are more likely root causes
    # Lower number = higher causal priority
    local -A causal_priority=(
        ["env_missing"]=1
        ["env_invalid"]=2
        ["module_not_found"]=3
        ["dep_missing"]=4
        ["dep_version"]=5
        ["tsconfig"]=6
        ["next_config"]=7
        ["schema_drift"]=8
        ["migration_failed"]=9
        ["circular_import"]=10
        ["import"]=11
        ["prisma_connection"]=12
        ["connection"]=13
        ["config"]=14
        ["syntax"]=15
        ["type_mismatch"]=16
        ["missing_property"]=17
        ["null_check"]=18
        ["generic_constraint"]=19
        ["overload_mismatch"]=20
        ["type"]=21
        ["compile"]=22
        ["build"]=23
        ["reference"]=24
        ["runtime"]=25
        ["auth"]=26
        ["api_error"]=27
        ["handler_crash"]=28
        ["hydration"]=29
        ["ssr"]=30
        ["hook_violation"]=31
        ["render_loop"]=32
        ["state_during_render"]=33
        ["render"]=34
        ["crash"]=35
    )

    local best_idx=""
    local best_priority=999
    local best_time=999999999999

    local IFS=','
    for idx in $members; do
        local err_type="${_ECR_ERROR_TYPES[$idx]:-unknown}"
        local err_time="${_ECR_ERROR_TIMESTAMPS[$idx]:-0}"
        local priority="${causal_priority[$err_type]:-50}"

        # Root cause: highest causal priority, then earliest timestamp
        if [[ $priority -lt $best_priority ]] || \
           { [[ $priority -eq $best_priority ]] && [[ $err_time -lt $best_time ]]; }; then
            best_idx="$idx"
            best_priority="$priority"
            best_time="$err_time"
        fi
    done
    unset IFS

    if [[ -n "$best_idx" ]]; then
        _ECR_CHAIN_ROOT["$chain_id"]="$best_idx"
        ECR_ROOT_CAUSES_FOUND=$((ECR_ROOT_CAUSES_FOUND + 1))
        echo -e "  ${_ECR_GREEN}[ECR]${_ECR_NC} Root cause found: [${_ECR_ERROR_TYPES[$best_idx]}] ${_ECR_ERROR_MSGS[$best_idx]:0:80}" >&2
        echo "$best_idx"
    else
        echo ""
        return 1
    fi
}

# =============================================================================
# _ecr_find_all_roots - Find root causes for all detected chains
# =============================================================================
_ecr_find_all_roots() {
    local found=0
    for chain_id in "${_ECR_CHAIN_IDS[@]}"; do
        local root
        root=$(_ecr_find_chain_root "$chain_id")
        [[ -n "$root" ]] && found=$((found + 1))
    done
    echo "$found"
}

# =============================================================================
# _ecr_resolve_chain - Generate fix that resolves entire error chain at once
# =============================================================================
_ecr_resolve_chain() {
    local chain_id="${1:-}"
    local project_dir="${2:-.}"
    [[ -z "$chain_id" ]] && return 1

    local root_idx="${_ECR_CHAIN_ROOT[$chain_id]:-}"
    local members="${_ECR_CHAIN_MEMBERS[$chain_id]:-}"
    local chain_type="${_ECR_CHAIN_TYPE[$chain_id]:-unknown}"

    if [[ -z "$root_idx" ]]; then
        root_idx=$(_ecr_find_chain_root "$chain_id")
    fi
    [[ -z "$root_idx" ]] && return 1

    _ECR_CHAIN_STATUS["$chain_id"]="resolving"
    echo -e "  ${_ECR_CYAN}[ECR]${_ECR_NC} Generating chain fix for: ${_ECR_BOLD}${chain_type}${_ECR_NC}" >&2

    # Build context for the fix prompt
    local root_msg="${_ECR_ERROR_MSGS[$root_idx]:-}"
    local root_file="${_ECR_ERROR_FILES[$root_idx]:-}"
    local root_type="${_ECR_ERROR_TYPES[$root_idx]:-}"
    local root_line="${_ECR_ERROR_LINES[$root_idx]:-0}"

    # Collect all cascade errors
    local cascade_context=""
    local cascade_count=0
    local IFS=','
    for idx in $members; do
        [[ "$idx" == "$root_idx" ]] && continue
        local cmsg="${_ECR_ERROR_MSGS[$idx]:-}"
        local cfile="${_ECR_ERROR_FILES[$idx]:-}"
        local ctype="${_ECR_ERROR_TYPES[$idx]:-}"
        cascade_context="${cascade_context}
  - [${ctype}] ${cmsg} (file: ${cfile})"
        cascade_count=$((cascade_count + 1))
    done
    unset IFS

    # Generate fix strategy based on root type
    local fix_strategy=""
    fix_strategy=$(_ecr_get_fix_strategy "$root_type" "$root_msg" "$root_file")

    # Build the complete fix prompt
    local fix_prompt="## Error Chain Resolution - ${chain_type}

### Root Cause (FIX THIS FIRST)
- Type: ${root_type}
- Error: ${root_msg}
- File: ${root_file}
- Line: ${root_line}

### Cascade Errors (${cascade_count} errors caused by root)
${cascade_context}

### Fix Strategy
${fix_strategy}

### Instructions
1. Fix the ROOT CAUSE first - the cascade errors will resolve automatically
2. Verify that fixing the root cause does not introduce new errors
3. If the root file does not exist, check if it needs to be created
4. After fixing, run the build to verify all cascade errors are resolved

### Project Context
- Project directory: ${project_dir}
- Chain type: ${chain_type}
- Total errors in chain: $((cascade_count + 1))"

    _ECR_CHAIN_FIX["$chain_id"]="$fix_prompt"
    ECR_FIXES_GENERATED=$((ECR_FIXES_GENERATED + 1))

    echo -e "  ${_ECR_GREEN}[ECR]${_ECR_NC} Fix prompt generated (root=${root_type}, cascades=${cascade_count})" >&2
    echo "$fix_prompt"
}

# =============================================================================
# _ecr_get_fix_strategy - Get fix strategy for a specific root error type
# =============================================================================
_ecr_get_fix_strategy() {
    local root_type="${1:-}"
    local root_msg="${2:-}"
    local root_file="${3:-}"

    case "$root_type" in
        env_missing)
            local var_name=""
            var_name=$(echo "$root_msg" | grep -oE '[A-Z_]{3,}' | head -1)
            cat <<STRATEGY
**Environment Variable Fix:**
1. Add \`${var_name}\` to \`.env\` file with appropriate value
2. Add \`${var_name}\` to \`.env.example\` with placeholder
3. Add validation in \`lib/env.ts\` or \`env.mjs\`:
   \`\`\`
   ${var_name}: z.string().min(1, "${var_name} is required")
   \`\`\`
4. If using Next.js, ensure \`NEXT_PUBLIC_\` prefix for client-side vars
5. Restart the dev server after adding the variable
STRATEGY
            ;;
        module_not_found|import)
            local module_name=""
            module_name=$(echo "$root_msg" | grep -oE "'[^']+'" | head -1 | tr -d "'")
            cat <<STRATEGY
**Missing Module/Import Fix:**
1. Check if \`${module_name}\` is installed: \`npm ls ${module_name}\`
2. If not installed: \`npm install ${module_name}\`
3. If it's a local module, verify the path is correct relative to ${root_file}
4. Check tsconfig.json paths aliases if using \`@/\` prefix
5. Verify the export exists in the source module
6. If type-only: use \`import type { ... } from '...'\`
STRATEGY
            ;;
        schema_drift|migration_failed)
            cat <<STRATEGY
**Schema/Migration Fix:**
1. Run \`npx prisma validate\` to check schema syntax
2. Run \`npx prisma generate\` to regenerate the client
3. If migration drift: \`npx prisma migrate reset --force\` (dev only)
4. If production: create a new migration with \`npx prisma migrate dev --name fix_drift\`
5. Verify model relationships match database foreign keys
6. Ensure all referenced models exist in schema.prisma
STRATEGY
            ;;
        prisma_connection|connection)
            cat <<STRATEGY
**Database Connection Fix:**
1. Verify DATABASE_URL is set correctly in .env
2. Check database server is running
3. Test connection: \`npx prisma db pull\`
4. For SQLite: ensure the database file path exists
5. For PostgreSQL: check host, port, user, password, database name
6. Ensure connection pool settings are appropriate
STRATEGY
            ;;
        type_mismatch|missing_property)
            cat <<STRATEGY
**TypeScript Type Fix:**
1. Check the expected type vs actual type in ${root_file}
2. If Prisma types: run \`npx prisma generate\` to sync types
3. If API response: update the interface to match actual response shape
4. Use type assertions only as last resort: \`as unknown as TargetType\`
5. Consider using Partial<T>, Pick<T, K>, or Omit<T, K> for flexibility
6. Add null checks where \`strictNullChecks\` is enabled
STRATEGY
            ;;
        null_check)
            cat <<STRATEGY
**Null Safety Fix:**
1. Add null/undefined checks before accessing properties
2. Use optional chaining: \`obj?.prop?.nested\`
3. Use nullish coalescing: \`value ?? defaultValue\`
4. Add type guards: \`if (obj !== null && obj !== undefined)\`
5. In Prisma queries: handle the case where findUnique returns null
6. For React refs: check \`ref.current\` before accessing
STRATEGY
            ;;
        hydration|ssr)
            cat <<STRATEGY
**Hydration/SSR Fix:**
1. Wrap browser-only code in \`useEffect\` or dynamic import with \`ssr: false\`
2. Use \`typeof window !== 'undefined'\` guard for browser APIs
3. Ensure server and client render identical initial HTML
4. Check for Date/time-dependent rendering (use suppressHydrationWarning)
5. Move \`localStorage\`/\`sessionStorage\` access to useEffect
6. Use \`next/dynamic\` with \`{ ssr: false }\` for client-only components
STRATEGY
            ;;
        hook_violation)
            cat <<STRATEGY
**React Hook Rules Fix:**
1. Ensure hooks are called at the top level of the component
2. Do NOT call hooks inside conditions, loops, or nested functions
3. Do NOT call hooks after early returns
4. Ensure all hooks are called in the same order on every render
5. Custom hooks must start with 'use' prefix
6. Check for accidentally calling a hook inside a callback
STRATEGY
            ;;
        render_loop|state_during_render)
            cat <<STRATEGY
**Render Loop Fix:**
1. Wrap state updates in useEffect with proper dependencies
2. Do NOT call setState directly in the render body
3. Use useCallback for event handlers passed as props
4. Use useMemo for expensive computations
5. Check useEffect dependencies - avoid objects/arrays without useMemo
6. Use functional updates: \`setState(prev => ...)\` to avoid stale closures
STRATEGY
            ;;
        dep_missing|dep_version)
            cat <<STRATEGY
**Dependency Fix:**
1. Run \`npm install\` to install missing dependencies
2. Check package.json for correct version ranges
3. If peer dependency conflict: \`npm install --legacy-peer-deps\`
4. Delete node_modules and package-lock.json, then reinstall
5. Check for conflicting versions with \`npm ls <package>\`
6. Consider using \`overrides\` in package.json for version forcing
STRATEGY
            ;;
        tsconfig)
            cat <<STRATEGY
**TSConfig Fix:**
1. Validate tsconfig.json syntax (no trailing commas in JSON)
2. Check \`paths\` aliases match actual directory structure
3. Ensure \`baseUrl\` is set when using path aliases
4. Verify \`include\`/\`exclude\` patterns cover the right files
5. Check \`moduleResolution\` is set to "bundler" or "node"
6. If using Next.js, ensure \`next.config.js\` paths align with tsconfig
STRATEGY
            ;;
        *)
            cat <<STRATEGY
**General Fix Strategy:**
1. Read the full error message carefully for clues
2. Check the file and line number mentioned in the error
3. Search for similar errors in the project's error history
4. Verify all imports and dependencies are correct
5. Run \`npm run build\` to see the complete error list
6. Fix errors from the bottom of the stack trace upward
STRATEGY
            ;;
    esac
}

# =============================================================================
# _ecr_validate_chain_fix - Verify the chain fix resolves all linked errors
# =============================================================================
_ecr_validate_chain_fix() {
    local chain_id="${1:-}"
    local project_dir="${2:-.}"
    local build_cmd="${3:-npm run build}"
    [[ -z "$chain_id" ]] && return 1

    local chain_type="${_ECR_CHAIN_TYPE[$chain_id]:-unknown}"
    echo -e "  ${_ECR_CYAN}[ECR]${_ECR_NC} Validating chain fix for: ${_ECR_BOLD}${chain_type}${_ECR_NC}" >&2

    ECR_FIXES_VALIDATED=$((ECR_FIXES_VALIDATED + 1))

    # Run build and capture output
    local build_output=""
    local build_exit=0
    if [[ -d "$project_dir" ]]; then
        build_output=$(cd "$project_dir" && eval "$build_cmd" 2>&1) || build_exit=$?
    else
        echo -e "  ${_ECR_YELLOW}[ECR]${_ECR_NC} Project dir not found: ${project_dir}" >&2
        return 1
    fi

    # Check if original chain errors are still present
    local members="${_ECR_CHAIN_MEMBERS[$chain_id]:-}"
    local remaining=0
    local resolved=0

    local IFS=','
    for idx in $members; do
        local err_msg="${_ECR_ERROR_MSGS[$idx]:-}"
        # Extract a key phrase from the error message
        local key_phrase
        key_phrase=$(echo "$err_msg" | head -1 | cut -c1-60)
        if echo "$build_output" | grep -qF "$key_phrase" 2>/dev/null; then
            remaining=$((remaining + 1))
        else
            resolved=$((resolved + 1))
        fi
    done
    unset IFS

    local total_in_chain=$((remaining + resolved))
    local resolution_rate=0
    [[ $total_in_chain -gt 0 ]] && resolution_rate=$((resolved * 100 / total_in_chain))

    if [[ $remaining -eq 0 ]]; then
        _ECR_CHAIN_STATUS["$chain_id"]="resolved"
        ECR_CHAINS_RESOLVED=$((ECR_CHAINS_RESOLVED + 1))
        ECR_FIXES_PASSED=$((ECR_FIXES_PASSED + 1))
        echo -e "  ${_ECR_GREEN}[ECR] PASS${_ECR_NC} Chain fully resolved! (${resolved}/${total_in_chain} errors fixed)" >&2
        _ecr_log_resolution "$chain_id" "resolved" "$resolution_rate"
        return 0
    else
        if [[ $resolution_rate -ge 50 ]]; then
            echo -e "  ${_ECR_YELLOW}[ECR] PARTIAL${_ECR_NC} Chain partially resolved: ${resolved}/${total_in_chain} (${resolution_rate}%)" >&2
            _ecr_log_resolution "$chain_id" "partial" "$resolution_rate"
        else
            _ECR_CHAIN_STATUS["$chain_id"]="failed"
            echo -e "  ${_ECR_RED}[ECR] FAIL${_ECR_NC} Chain fix ineffective: ${resolved}/${total_in_chain} (${resolution_rate}%)" >&2
            _ecr_log_resolution "$chain_id" "failed" "$resolution_rate"
        fi
        return 1
    fi
}

# =============================================================================
# _ecr_log_resolution - Log chain resolution to history
# =============================================================================
_ecr_log_resolution() {
    local chain_id="$1"
    local status="$2"
    local rate="$3"

    [[ -z "$ECR_CHAIN_LOG" ]] && return 0

    local chain_type="${_ECR_CHAIN_TYPE[$chain_id]:-unknown}"
    local root_idx="${_ECR_CHAIN_ROOT[$chain_id]:-}"
    local root_type=""
    [[ -n "$root_idx" ]] && root_type="${_ECR_ERROR_TYPES[$root_idx]:-unknown}"

    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    echo "{\"timestamp\":\"${timestamp}\",\"chain_id\":\"${chain_id}\",\"chain_type\":\"${chain_type}\",\"root_type\":\"${root_type}\",\"status\":\"${status}\",\"resolution_rate\":${rate}}" >> "$ECR_CHAIN_LOG" 2>/dev/null || true
}

# =============================================================================
# _ecr_resolve_all - Resolve all detected chains
# =============================================================================
_ecr_resolve_all() {
    local project_dir="${1:-.}"
    local fixes=()

    for chain_id in "${_ECR_CHAIN_IDS[@]}"; do
        local status="${_ECR_CHAIN_STATUS[$chain_id]:-detected}"
        [[ "$status" == "resolved" ]] && continue

        local fix
        fix=$(_ecr_resolve_chain "$chain_id" "$project_dir")
        [[ -n "$fix" ]] && fixes+=("$fix")
    done

    echo "${#fixes[@]}"
}

# =============================================================================
# _ecr_get_chain_summary - Get human-readable summary of a chain
# =============================================================================
_ecr_get_chain_summary() {
    local chain_id="${1:-}"
    [[ -z "$chain_id" ]] && return 1

    local chain_type="${_ECR_CHAIN_TYPE[$chain_id]:-unknown}"
    local status="${_ECR_CHAIN_STATUS[$chain_id]:-unknown}"
    local members="${_ECR_CHAIN_MEMBERS[$chain_id]:-}"
    local root_idx="${_ECR_CHAIN_ROOT[$chain_id]:-}"

    local count
    count=$(echo "$members" | tr ',' '\n' | wc -l | tr -d ' ')

    echo "Chain: ${chain_type}"
    echo "Status: ${status}"
    echo "Errors: ${count}"

    if [[ -n "$root_idx" ]]; then
        echo "Root: [${_ECR_ERROR_TYPES[$root_idx]:-?}] ${_ECR_ERROR_MSGS[$root_idx]:0:100}"
    fi

    echo "Members:"
    local IFS=','
    for idx in $members; do
        echo "  - [${_ECR_ERROR_TYPES[$idx]:-?}] ${_ECR_ERROR_MSGS[$idx]:0:80} (${_ECR_ERROR_FILES[$idx]:-?})"
    done
    unset IFS
}

# =============================================================================
# _ecr_get_stats - Get statistics as JSON
# =============================================================================
_ecr_get_stats() {
    cat <<EOF
{"module":"error-chain-resolver","version":"${ECR_VERSION}","total_errors":${ECR_TOTAL_ERRORS},"chains_detected":${ECR_CHAINS_DETECTED},"chains_resolved":${ECR_CHAINS_RESOLVED},"root_causes_found":${ECR_ROOT_CAUSES_FOUND},"fixes_generated":${ECR_FIXES_GENERATED},"fixes_validated":${ECR_FIXES_VALIDATED},"fixes_passed":${ECR_FIXES_PASSED}}
EOF
}

# =============================================================================
# _ecr_report - Report output
# =============================================================================
_ecr_report() {
    echo -e "\n  ${_ECR_BOLD}=== Error Chain Resolver v${ECR_VERSION} Report ===${_ECR_NC}"
    echo -e "  Total errors analyzed : ${ECR_TOTAL_ERRORS}"
    echo -e "  Chains detected       : ${ECR_CHAINS_DETECTED}"
    echo -e "  Root causes found     : ${ECR_ROOT_CAUSES_FOUND}"
    echo -e "  Fixes generated       : ${ECR_FIXES_GENERATED}"
    echo -e "  Fixes validated       : ${ECR_FIXES_VALIDATED}"
    echo -e "  Fixes passed          : ${ECR_FIXES_PASSED}"
    echo -e "  Chains resolved       : ${ECR_CHAINS_RESOLVED}"

    if [[ ${#_ECR_CHAIN_IDS[@]} -gt 0 ]]; then
        echo -e "\n  ${_ECR_BOLD}Active Chains:${_ECR_NC}"
        for chain_id in "${_ECR_CHAIN_IDS[@]}"; do
            local ctype="${_ECR_CHAIN_TYPE[$chain_id]:-?}"
            local cstatus="${_ECR_CHAIN_STATUS[$chain_id]:-?}"
            local members="${_ECR_CHAIN_MEMBERS[$chain_id]:-}"
            local count
            count=$(echo "$members" | tr ',' '\n' | wc -l | tr -d ' ')
            local status_color="${_ECR_YELLOW}"
            [[ "$cstatus" == "resolved" ]] && status_color="${_ECR_GREEN}"
            [[ "$cstatus" == "failed" ]] && status_color="${_ECR_RED}"
            echo -e "    ${status_color}[${cstatus}]${_ECR_NC} ${ctype} (${count} errors)"
        done
    fi
}

# =============================================================================
# _ecr_score - Module score (0-100)
# =============================================================================
_ecr_score() {
    local score=50

    # Bonus for detecting chains
    [[ $ECR_CHAINS_DETECTED -gt 0 ]] && score=$((score + 10))

    # Bonus for finding root causes
    [[ $ECR_ROOT_CAUSES_FOUND -gt 0 ]] && score=$((score + 10))

    # Bonus for generating fixes
    [[ $ECR_FIXES_GENERATED -gt 0 ]] && score=$((score + 10))

    # Bonus for validated fixes
    if [[ $ECR_FIXES_VALIDATED -gt 0 ]]; then
        local pass_rate=$((ECR_FIXES_PASSED * 100 / ECR_FIXES_VALIDATED))
        if [[ $pass_rate -ge 80 ]]; then
            score=$((score + 20))
        elif [[ $pass_rate -ge 50 ]]; then
            score=$((score + 10))
        fi
    fi

    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# _ecr_init_message - Display init message
# =============================================================================
_ecr_init_message() {
    echo -e "  ${_ECR_GREEN}v${ECR_VERSION}${_ECR_NC} Error Chain Resolver: 40+ chain patterns, 3-strategy detection, root cause analysis" >&2
}

# =============================================================================
# Module Registry Registration
# =============================================================================
_mr_register \
    --name "error-chain-resolver" \
    --version "${ECR_VERSION}" \
    --description "エラーチェーン解析・一括解決（40+パターン、3戦略検出、ルート原因分析）" \
    --init "_ecr_init" \
    --report "_ecr_report" \
    --score "_ecr_score" \
    --enable-var "ECR_ENABLED" \
    --cli-flags "--error-chain-resolver:--no-error-chain-resolver" \
    --init-msg "_ecr_init_message"
