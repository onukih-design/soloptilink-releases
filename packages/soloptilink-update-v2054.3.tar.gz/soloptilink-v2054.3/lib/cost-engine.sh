#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v16.0 - Cost Attribution Engine
# =============================================================================
# Provides fine-grained cost tracking with attribution by phase, agent, and domain.
# v16.0: Model-specific pricing (Opus/Sonnet/Haiku), model tier tracking
# =============================================================================

[[ -n "${_COST_ENGINE_LOADED:-}" ]] && return 0
_COST_ENGINE_LOADED=1

# ============================================================
# State
# ============================================================
declare -g COST_CALLS_TOTAL=0
declare -g COST_USD_TOTAL="0.00"
declare -g COST_LOG_FILE=""
declare -g -A COST_BY_PHASE=()     # phase_name -> cumulative USD (as string)
declare -g -A COST_BY_AGENT=()     # agent_id -> cumulative USD
declare -g -A COST_BY_DOMAIN=()    # domain -> cumulative USD
declare -g -A COST_CALLS_BY_PHASE=()  # phase_name -> call count
declare -g -A COST_CALLS_BY_AGENT=()  # agent_id -> call count

# Domain inference mapping
declare -g -A _COST_PHASE_DOMAIN=(
    [requirements]="planning"
    [competitive_research]="planning"
    [database]="database"
    [backend]="backend"
    [api]="backend"
    [frontend]="frontend"
    [quality_check]="qa"
    [testing]="qa"
    [security_audit]="security"
    [documentation]="documentation"
    [deploy]="devops"
    [implementation]="backend"
    [hotfix]="backend"
    [scaffold]="planning"
    [prompt_expand]="planning"
    [browser_test]="qa"
)

# ============================================================
# Internal logger
# ============================================================
_cost_log() {
    local level="$1" msg="$2"
    echo -e "  ${CYAN:-}[COST]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize cost engine
# ============================================================
cost_init() {
    COST_CALLS_TOTAL=0
    COST_USD_TOTAL="0.00"

    # Reset associative arrays from any previous session
    COST_BY_PHASE=()
    COST_BY_AGENT=()
    COST_BY_DOMAIN=()
    COST_CALLS_BY_PHASE=()
    COST_CALLS_BY_AGENT=()

    local obs_dir="${SESSION_LOG_DIR:-/tmp}/observatory"
    mkdir -p "$obs_dir" 2>/dev/null || true
    COST_LOG_FILE="${obs_dir}/cost_entries.jsonl"
}

# ============================================================
# Record a single cost entry with attribution
# ============================================================
cost_record() {
    local amount="${1:-0.08}"
    local phase="${2:-unknown}"
    local agent_id="${3:-system}"
    local domain="${4:-}"

    # Auto-infer domain from phase if not provided
    if [[ -z "$domain" ]]; then
        domain="${_COST_PHASE_DOMAIN[$phase]:-general}"
    fi

    COST_CALLS_TOTAL=$((COST_CALLS_TOTAL + 1))

    # Accumulate USD totals using bc (with awk fallback)
    if command -v bc &>/dev/null; then
        COST_USD_TOTAL=$(echo "scale=2; ${COST_USD_TOTAL} + ${amount}" | bc 2>/dev/null | sed 's/^\./0./' || echo "$COST_USD_TOTAL")

        local prev_phase="${COST_BY_PHASE[$phase]:-0.00}"
        COST_BY_PHASE["$phase"]=$(echo "scale=2; ${prev_phase} + ${amount}" | bc 2>/dev/null | sed 's/^\./0./' || echo "$prev_phase")

        local prev_agent="${COST_BY_AGENT[$agent_id]:-0.00}"
        COST_BY_AGENT["$agent_id"]=$(echo "scale=2; ${prev_agent} + ${amount}" | bc 2>/dev/null | sed 's/^\./0./' || echo "$prev_agent")

        local prev_domain="${COST_BY_DOMAIN[$domain]:-0.00}"
        COST_BY_DOMAIN["$domain"]=$(echo "scale=2; ${prev_domain} + ${amount}" | bc 2>/dev/null | sed 's/^\./0./' || echo "$prev_domain")
    elif command -v awk &>/dev/null; then
        # Fallback: use awk for arithmetic when bc is unavailable
        COST_USD_TOTAL=$(awk "BEGIN{printf \"%.2f\", ${COST_USD_TOTAL} + ${amount}}" 2>/dev/null || echo "$COST_USD_TOTAL")

        local prev_phase="${COST_BY_PHASE[$phase]:-0.00}"
        COST_BY_PHASE["$phase"]=$(awk "BEGIN{printf \"%.2f\", ${prev_phase} + ${amount}}" 2>/dev/null || echo "$prev_phase")

        local prev_agent="${COST_BY_AGENT[$agent_id]:-0.00}"
        COST_BY_AGENT["$agent_id"]=$(awk "BEGIN{printf \"%.2f\", ${prev_agent} + ${amount}}" 2>/dev/null || echo "$prev_agent")

        local prev_domain="${COST_BY_DOMAIN[$domain]:-0.00}"
        COST_BY_DOMAIN["$domain"]=$(awk "BEGIN{printf \"%.2f\", ${prev_domain} + ${amount}}" 2>/dev/null || echo "$prev_domain")
    fi

    # Call counts
    COST_CALLS_BY_PHASE["$phase"]=$(( ${COST_CALLS_BY_PHASE[$phase]:-0} + 1 ))
    COST_CALLS_BY_AGENT["$agent_id"]=$(( ${COST_CALLS_BY_AGENT[$agent_id]:-0} + 1 ))

    # Append to JSONL log
    if [[ -n "$COST_LOG_FILE" ]]; then
        local ts
        ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
        printf '{"timestamp":"%s","amount":"%s","phase":"%s","agent":"%s","domain":"%s","call_num":%d}\n' \
            "$ts" "$amount" "$phase" "$agent_id" "$domain" "$COST_CALLS_TOTAL" \
            >> "$COST_LOG_FILE" 2>/dev/null || true
    fi
}

# ============================================================
# Get cost breakdown by phase as JSON
# ============================================================
cost_by_phase() {
    local json="{"
    local first=1
    for phase in "${!COST_BY_PHASE[@]}"; do
        [[ "$first" -eq 0 ]] && json+=","
        json+="\"${phase}\":\"${COST_BY_PHASE[$phase]}\""
        first=0
    done
    json+="}"
    echo "$json"
}

# Get cost breakdown by agent as JSON
cost_by_agent() {
    local json="{"
    local first=1
    for agent in "${!COST_BY_AGENT[@]}"; do
        [[ "$first" -eq 0 ]] && json+=","
        json+="\"${agent}\":\"${COST_BY_AGENT[$agent]}\""
        first=0
    done
    json+="}"
    echo "$json"
}

# Get cost breakdown by domain as JSON
cost_by_domain() {
    local json="{"
    local first=1
    for domain in "${!COST_BY_DOMAIN[@]}"; do
        [[ "$first" -eq 0 ]] && json+=","
        json+="\"${domain}\":\"${COST_BY_DOMAIN[$domain]}\""
        first=0
    done
    json+="}"
    echo "$json"
}

# ============================================================
# Print ASCII cost attribution report
# ============================================================
cost_breakdown_report() {
    echo ""
    echo -e "  ${BOLD:-}${CYAN:-}[Cost Attribution Report] v14.0${NC:-}"
    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    printf "  %-6s  %-20s  %8s  %6s\n" "Type" "Name" "Cost" "Calls"
    echo -e "  ──────  ────────────────────  ────────  ──────"

    # By Phase
    for phase in "${!COST_BY_PHASE[@]}"; do
        printf "  %-6s  %-20s  \$%7s  %6d\n" "Phase" "${phase:0:20}" "${COST_BY_PHASE[$phase]}" "${COST_CALLS_BY_PHASE[$phase]:-0}"
    done

    echo -e "  ──────  ────────────────────  ────────  ──────"

    # By Agent
    for agent in "${!COST_BY_AGENT[@]}"; do
        printf "  %-6s  %-20s  \$%7s  %6d\n" "Agent" "${agent:0:20}" "${COST_BY_AGENT[$agent]}" "${COST_CALLS_BY_AGENT[$agent]:-0}"
    done

    echo -e "  ──────  ────────────────────  ────────  ──────"

    # By Domain
    for domain in "${!COST_BY_DOMAIN[@]}"; do
        printf "  %-6s  %-20s  \$%7s\n" "Domain" "${domain:0:20}" "${COST_BY_DOMAIN[$domain]}"
    done

    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    printf "  %-6s  %-20s  \$%7s  %6d\n" "TOTAL" "" "$COST_USD_TOTAL" "$COST_CALLS_TOTAL"
    echo ""
}

# ============================================================
# Export cost data as JSON
# ============================================================
cost_export_json() {
    local output_file="${SESSION_LOG_DIR:-/tmp}/observatory/cost_report.json"

    {
        echo "{"
        echo "  \"total_usd\": \"${COST_USD_TOTAL}\","
        echo "  \"total_calls\": ${COST_CALLS_TOTAL},"
        echo "  \"by_phase\": $(cost_by_phase),"
        echo "  \"by_agent\": $(cost_by_agent),"
        echo "  \"by_domain\": $(cost_by_domain)"
        echo "}"
    } > "$output_file" 2>/dev/null || true
}

# ============================================================
# v16.0: Model-tier-aware token-based cost recording
# ============================================================
cost_record_tokens() {
    local input_tokens="${1:-0}"
    local output_tokens="${2:-0}"
    local phase="${3:-unknown}"
    local agent_id="${4:-system}"
    local model_tier="${5:-balanced}"

    # v16.0: Model-specific pricing per 1M tokens
    local input_price="3.00"    # Sonnet default
    local output_price="15.00"

    case "$model_tier" in
        frontier|opus)
            input_price="15.00"
            output_price="75.00"
            ;;
        balanced|sonnet)
            input_price="3.00"
            output_price="15.00"
            ;;
        economy|haiku)
            input_price="0.25"
            output_price="1.25"
            ;;
    esac

    local total_cost="0.08"
    if command -v bc &>/dev/null; then
        local input_cost output_cost
        input_cost=$(echo "scale=6; ${input_tokens} * ${input_price} / 1000000" | bc 2>/dev/null || echo "0")
        output_cost=$(echo "scale=6; ${output_tokens} * ${output_price} / 1000000" | bc 2>/dev/null || echo "0")
        total_cost=$(echo "scale=4; ${input_cost} + ${output_cost}" | bc 2>/dev/null | sed 's/^\./0./' || echo "0.08")
    elif command -v awk &>/dev/null; then
        total_cost=$(awk "BEGIN{printf \"%.4f\", (${input_tokens} * ${input_price} / 1000000) + (${output_tokens} * ${output_price} / 1000000)}" 2>/dev/null || echo "0.08")
    fi

    cost_record "$total_cost" "$phase" "$agent_id" ""
}

# ============================================================
# Check if session is within budget
# ============================================================
cost_check_budget() {
    local budget="${1:-${COST_LIMIT:-10.00}}"
    if command -v bc &>/dev/null; then
        local over
        over=$(echo "${COST_USD_TOTAL} > ${budget}" | bc 2>/dev/null || echo "0")
        [[ "$over" == "1" ]] && return 1
    fi
    return 0
}
