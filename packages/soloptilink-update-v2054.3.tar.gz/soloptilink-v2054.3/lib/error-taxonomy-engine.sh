#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v251.0 - Error Taxonomy Engine
# =============================================================================
# エラーを15カテゴリに自動分類し、カテゴリ別統計と修正戦略を提供する。
#
# 問題: エラーメッセージは多種多様で、修正戦略の選択が困難。
#   - TypeErrorとRuntimeErrorでは修正アプローチが全く異なる
#   - DB_ERRORはスキーマ修正が必要、IMPORT_ERRORはパス修正が必要
#   - 同じカテゴリのエラーには共通の修正パターンが適用できる
#
# 解決: エラーをパターンマッチングで15カテゴリに分類し、
#   カテゴリ別の統計と推奨修正戦略を提供する。
#
# Functions:
#   ete_init                  - 初期化・キャッシュロード
#   _ete_classify_error       - エラーメッセージをカテゴリに分類
#   _ete_parse_error_message  - エラーメッセージから構造化情報を抽出
#   _ete_get_category_stats   - カテゴリ別統計を返す
#   _ete_get_fix_strategy     - カテゴリ別推奨修正戦略を返す
#   ete_report                - レポート出力
#   ete_score                 - モジュールスコア(0-100)
#
# All globals use the ETE_ prefix.
# =============================================================================

[[ -n "${_ERROR_TAXONOMY_ENGINE_LOADED:-}" ]] && return 0
_ERROR_TAXONOMY_ENGINE_LOADED=1

ETE_VERSION="251.0"
ETE_INITIALIZED=false

# --- Paths ---
ETE_CACHE_DIR=""
ETE_TAXONOMY_FILE=""

# --- Counters ---
ETE_TOTAL_CLASSIFIED=0
ETE_CLASSIFICATION_HITS=0
ETE_CLASSIFICATION_MISSES=0

# --- Error Categories ---
readonly ETE_CAT_TYPE_ERROR="TYPE_ERROR"
readonly ETE_CAT_RUNTIME_ERROR="RUNTIME_ERROR"
readonly ETE_CAT_BUILD_ERROR="BUILD_ERROR"
readonly ETE_CAT_DB_ERROR="DB_ERROR"
readonly ETE_CAT_NETWORK_ERROR="NETWORK_ERROR"
readonly ETE_CAT_AUTH_ERROR="AUTH_ERROR"
readonly ETE_CAT_VALIDATION_ERROR="VALIDATION_ERROR"
readonly ETE_CAT_IMPORT_ERROR="IMPORT_ERROR"
readonly ETE_CAT_CONFIG_ERROR="CONFIG_ERROR"
readonly ETE_CAT_DEPENDENCY_ERROR="DEPENDENCY_ERROR"
readonly ETE_CAT_CSS_ERROR="CSS_ERROR"
readonly ETE_CAT_API_CONTRACT_ERROR="API_CONTRACT_ERROR"
readonly ETE_CAT_MEMORY_ERROR="MEMORY_ERROR"
readonly ETE_CAT_PERMISSION_ERROR="PERMISSION_ERROR"
readonly ETE_CAT_TIMEOUT_ERROR="TIMEOUT_ERROR"
readonly ETE_CAT_UNKNOWN="UNKNOWN"

# --- In-memory category stats ---
declare -g -A _ETE_CAT_COUNT=()         # category → count
declare -g -A _ETE_CAT_LAST_MSG=()      # category → last error message
declare -g -A _ETE_CAT_LAST_FILE=()     # category → last file path
declare -g -A _ETE_CAT_FIX_COUNT=()     # category → successful fix count
declare -g -A _ETE_CAT_TOTAL_FIXES=()   # category → total fix attempts

# --- Classification rules (regex patterns per category) ---
declare -g -A _ETE_RULES=()

# =============================================================================
# ete_init - Initialize taxonomy engine, load cache, register rules
# =============================================================================
ete_init() {
    ETE_CACHE_DIR="${HOME}/.soloptilink/cache"
    mkdir -p "$ETE_CACHE_DIR" 2>/dev/null || true

    ETE_TAXONOMY_FILE="${ETE_CACHE_DIR}/error-taxonomy.json"

    # Reset in-memory state
    ETE_TOTAL_CLASSIFIED=0
    ETE_CLASSIFICATION_HITS=0
    ETE_CLASSIFICATION_MISSES=0
    _ETE_CAT_COUNT=()
    _ETE_CAT_LAST_MSG=()
    _ETE_CAT_LAST_FILE=()
    _ETE_CAT_FIX_COUNT=()
    _ETE_CAT_TOTAL_FIXES=()

    # Register classification rules
    _ete_register_rules

    # Load persisted taxonomy data
    _ete_load_cache

    ETE_INITIALIZED=true
    return 0
}

# =============================================================================
# _ete_register_rules - Define regex patterns for each error category
# =============================================================================
_ete_register_rules() {
    _ETE_RULES=()

    # TYPE_ERROR: TypeScript type mismatches, undefined properties, null access
    _ETE_RULES["$ETE_CAT_TYPE_ERROR"]="TypeError|Type .* is not assignable|Property .* does not exist|Cannot read propert|is not a function|Expected .* arguments.*got|Argument of type|has no property|Object is possibly|undefined is not|null is not|TS2[0-9]{3}|type.*mismatch|Overload.*not applicable"

    # RUNTIME_ERROR: Unhandled exceptions, uncaught errors at runtime
    _ETE_RULES["$ETE_CAT_RUNTIME_ERROR"]="RangeError|ReferenceError|SyntaxError.*runtime|unhandled.*rejection|uncaught.*exception|process.*exit|SIGTERM|SIGKILL|fatal error|stack overflow|call stack|Maximum call stack|Unhandled Runtime Error|cannot.*destructure"

    # BUILD_ERROR: Compilation, bundling, transpilation failures
    _ETE_RULES["$ETE_CAT_BUILD_ERROR"]="Module build failed|Compilation.*failed|Build error|Failed to compile|webpack.*error|esbuild.*error|SWC.*error|tsc.*error|Parsing error|Unexpected token|unterminated|vite.*error|rollup.*error|next build.*failed|ELIFECYCLE"

    # DB_ERROR: Database connection, query, migration, schema errors
    _ETE_RULES["$ETE_CAT_DB_ERROR"]="PrismaClient|P[0-9]{4}|SQLITE_ERROR|database.*error|migration.*failed|unique constraint|foreign key|column.*not found|table.*not exist|relation.*does not exist|ECONNREFUSED.*5432|ECONNREFUSED.*3306|deadlock|duplicate key|schema.*error|invalid.*prisma|prisma.*validate"

    # NETWORK_ERROR: Fetch failures, DNS, socket, CORS
    _ETE_RULES["$ETE_CAT_NETWORK_ERROR"]="fetch.*failed|ECONNREFUSED|ENOTFOUND|ETIMEDOUT|ECONNRESET|network.*error|socket.*error|DNS.*resolution|getaddrinfo|CORS.*error|Access-Control-Allow|ERR_CONNECTION|net::ERR_|XMLHttpRequest|AbortError.*fetch"

    # AUTH_ERROR: Authentication, authorization, JWT, session issues
    _ETE_RULES["$ETE_CAT_AUTH_ERROR"]="unauthorized|403.*forbidden|401.*unauthorized|jwt.*expired|jwt.*invalid|token.*expired|token.*invalid|authentication.*failed|authorization.*failed|invalid.*credentials|session.*expired|CSRF.*token|permission.*denied.*auth|access.*denied|invalid.*api.*key"

    # VALIDATION_ERROR: Input validation, schema validation, zod errors
    _ETE_RULES["$ETE_CAT_VALIDATION_ERROR"]="ZodError|validation.*failed|invalid.*input|required.*field|must be.*string|must be.*number|expected.*got|schema.*validation|invalid.*format|invalid.*email|min.*length|max.*length|pattern.*match|enum.*value|Received.*Expected"

    # IMPORT_ERROR: Module resolution, missing imports, circular deps
    _ETE_RULES["$ETE_CAT_IMPORT_ERROR"]="Cannot find module|Module not found|Could not resolve|import.*error|require.*error|ERR_MODULE_NOT_FOUND|unable to resolve|Cannot resolve|no such file.*import|circular.*dependency|dynamic import.*error|export.*not found"

    # CONFIG_ERROR: Configuration file issues, env vars, settings
    _ETE_RULES["$ETE_CAT_CONFIG_ERROR"]="ENOENT.*config|invalid.*configuration|missing.*env|environment.*variable|\.env.*not found|config.*error|tsconfig.*error|next\.config|eslint.*config|tailwind.*config|postcss.*config|missing.*key|invalid.*option"

    # DEPENDENCY_ERROR: Package installation, version conflicts, peer deps
    _ETE_RULES["$ETE_CAT_DEPENDENCY_ERROR"]="peer dependency|ERESOLVE|npm ERR|yarn.*error|pnpm.*error|package.*not found|version.*conflict|ENOENT.*node_modules|Cannot find.*node_modules|incompatible.*version|missing.*dependency|deprecated.*package|EBADPLATFORM"

    # CSS_ERROR: Styling issues, Tailwind, CSS modules, PostCSS
    _ETE_RULES["$ETE_CAT_CSS_ERROR"]="Unknown utility class|Cannot apply|CSS.*error|postcss.*error|tailwind.*error|unknown.*class|invalid.*selector|Expected.*found.*css|SCSS.*error|Sass.*error|styled-component|css module.*error|Unknown at rule"

    # API_CONTRACT_ERROR: REST/GraphQL contract mismatches
    _ETE_RULES["$ETE_CAT_API_CONTRACT_ERROR"]="404.*Not Found.*api|405.*Method Not Allowed|422.*Unprocessable|API.*route.*not found|endpoint.*not.*exist|route.*handler|response.*schema|expected.*response|unexpected.*field|missing.*field.*response|GraphQL.*error|query.*error.*api"

    # MEMORY_ERROR: Out of memory, heap, buffer overflow
    _ETE_RULES["$ETE_CAT_MEMORY_ERROR"]="heap out of memory|ENOMEM|out of memory|memory.*allocation|JavaScript heap|buffer.*overflow|allocation failed|OOM|GC overhead|memory.*limit|FATAL ERROR.*heap"

    # PERMISSION_ERROR: File system permissions, access control
    _ETE_RULES["$ETE_CAT_PERMISSION_ERROR"]="EACCES|EPERM|permission denied|access denied.*file|read-only file|cannot write|mkdir.*permission|unlink.*permission|chmod.*error|chown.*error|Operation not permitted"

    # TIMEOUT_ERROR: Timeouts, deadlines, slow operations
    _ETE_RULES["$ETE_CAT_TIMEOUT_ERROR"]="timeout.*exceeded|ETIMEDOUT|deadline.*exceeded|request.*timeout|connection.*timeout|operation.*timed out|jest.*timeout|test.*timeout|async.*timeout|watchdog.*timeout|gateway.*timeout|504.*timeout"
}

# =============================================================================
# _ete_classify_error - Classify an error message into a category
# Arguments:
#   $1 - error_message (full error text)
# Returns:
#   category string via stdout
# =============================================================================
_ete_classify_error() {
    local error_message="${1:-}"
    [[ -z "$error_message" ]] && echo "$ETE_CAT_UNKNOWN" && return 0

    ETE_TOTAL_CLASSIFIED=$((ETE_TOTAL_CLASSIFIED + 1))

    local category="$ETE_CAT_UNKNOWN"
    local best_match_len=0

    # Try each category's regex patterns
    local cat pattern
    for cat in "${!_ETE_RULES[@]}"; do
        pattern="${_ETE_RULES[$cat]}"
        [[ -z "$pattern" ]] && continue

        if echo "$error_message" | grep -qiE "$pattern" 2>/dev/null; then
            # Prefer the category with the longest matching pattern segment
            local match
            match=$(echo "$error_message" | grep -oiE "$pattern" 2>/dev/null | head -1)
            local match_len=${#match}

            if [[ $match_len -gt $best_match_len ]]; then
                best_match_len=$match_len
                category="$cat"
            fi
        fi
    done

    # Update statistics
    if [[ "$category" != "$ETE_CAT_UNKNOWN" ]]; then
        ETE_CLASSIFICATION_HITS=$((ETE_CLASSIFICATION_HITS + 1))
    else
        ETE_CLASSIFICATION_MISSES=$((ETE_CLASSIFICATION_MISSES + 1))
    fi

    local prev_count="${_ETE_CAT_COUNT[$category]:-0}"
    _ETE_CAT_COUNT["$category"]=$((prev_count + 1))
    _ETE_CAT_LAST_MSG["$category"]="$error_message"

    # Persist to cache
    _ete_save_cache

    echo "$category"
    return 0
}

# =============================================================================
# _ete_parse_error_message - Extract structured information from error message
# Arguments:
#   $1 - error_message
# Returns:
#   JSON object with parsed info via stdout
# =============================================================================
_ete_parse_error_message() {
    local error_message="${1:-}"
    [[ -z "$error_message" ]] && echo '{"file":"","line":0,"column":0,"expected":"","actual":"","stack_frames":[]}' && return 0

    local file_path=""
    local line_num=0
    local col_num=0
    local expected=""
    local actual=""
    local func_name=""
    local stack_depth=0

    # Extract file path (various formats)
    # Format: /path/to/file.ts:123:45
    if echo "$error_message" | grep -qoE '[/.][a-zA-Z0-9_/.-]+\.(ts|tsx|js|jsx|sh|py|go):[0-9]+'; then
        file_path=$(echo "$error_message" | grep -oE '[/.][a-zA-Z0-9_/.-]+\.(ts|tsx|js|jsx|sh|py|go):[0-9]+' | head -1)
        line_num=$(echo "$file_path" | grep -oE ':[0-9]+' | head -1 | tr -d ':')
        file_path=$(echo "$file_path" | sed 's/:[0-9]*$//')
    fi

    # Try Next.js / Webpack format: ./src/app/page.tsx
    if [[ -z "$file_path" ]]; then
        file_path=$(echo "$error_message" | grep -oE '\./[a-zA-Z0-9_/.-]+\.(ts|tsx|js|jsx)' | head -1)
    fi

    # Try at <func> (file:line:col) format
    if [[ -z "$file_path" ]]; then
        local at_match
        at_match=$(echo "$error_message" | grep -oE 'at [a-zA-Z0-9_.]+ \([^)]+\)' | head -1)
        if [[ -n "$at_match" ]]; then
            func_name=$(echo "$at_match" | sed 's/at \([^ ]*\) .*/\1/')
            file_path=$(echo "$at_match" | grep -oE '\([^)]+\)' | tr -d '()' | sed 's/:[0-9]*:[0-9]*$//')
            line_num=$(echo "$at_match" | grep -oE ':[0-9]+' | head -1 | tr -d ':')
            col_num=$(echo "$at_match" | grep -oE ':[0-9]+' | tail -1 | tr -d ':')
        fi
    fi

    # Extract column number if we have file:line:col
    if [[ $col_num -eq 0 ]]; then
        col_num=$(echo "$error_message" | grep -oE ':[0-9]+:[0-9]+' | head -1 | awk -F: '{print $3}')
        col_num="${col_num:-0}"
    fi

    # Extract expected vs actual (TypeScript, zod, etc.)
    # Format: Expected X, got Y  OR  Type 'X' is not assignable to type 'Y'
    if echo "$error_message" | grep -qiE 'expected.*got|expected.*received'; then
        expected=$(echo "$error_message" | grep -oiE "expected ['\"]?[^,.'\"]+['\"]?" | head -1 | sed "s/expected //i; s/['\"]//g")
        actual=$(echo "$error_message" | grep -oiE "(got|received) ['\"]?[^,.'\"]+['\"]?" | head -1 | sed "s/\(got\|received\) //i; s/['\"]//g")
    elif echo "$error_message" | grep -qiE "Type '.*' is not assignable to type '.*'"; then
        actual=$(echo "$error_message" | grep -oE "Type '[^']+'" | head -1 | sed "s/Type '//; s/'//")
        expected=$(echo "$error_message" | grep -oE "to type '[^']+'" | head -1 | sed "s/to type '//; s/'//")
    fi

    # Count stack trace frames
    stack_depth=$(echo "$error_message" | grep -cE '^\s*at ' 2>/dev/null || echo "0")

    # Extract function name from first stack frame if not already found
    if [[ -z "$func_name" ]]; then
        func_name=$(echo "$error_message" | grep -oE 'at ([a-zA-Z0-9_.]+)' | head -1 | sed 's/at //')
    fi

    # Build JSON output
    cat <<EOF
{
  "file": "${file_path:-}",
  "line": ${line_num:-0},
  "column": ${col_num:-0},
  "function": "${func_name:-}",
  "expected": "${expected:-}",
  "actual": "${actual:-}",
  "stack_depth": ${stack_depth:-0}
}
EOF
    return 0
}

# =============================================================================
# _ete_classify_with_context - Classify error with file context for accuracy
# Arguments:
#   $1 - error_message
#   $2 - project_dir (optional, for file analysis)
# Returns:
#   JSON with category + details via stdout
# =============================================================================
_ete_classify_with_context() {
    local error_message="${1:-}"
    local project_dir="${2:-.}"

    local category
    category=$(_ete_classify_error "$error_message")

    local parsed
    parsed=$(_ete_parse_error_message "$error_message")

    local file_path
    file_path=$(echo "$parsed" | grep -oE '"file": *"[^"]*"' | head -1 | sed 's/"file": *"//;s/"//')

    local file_exists="false"
    local file_type=""
    local nearby_files=""

    # Check if the referenced file exists
    if [[ -n "$file_path" ]]; then
        local full_path="${project_dir}/${file_path}"
        full_path=$(echo "$full_path" | sed 's|^\./||')

        if [[ -f "$full_path" ]]; then
            file_exists="true"
            file_type=$(basename "$full_path" | grep -oE '\.[^.]+$')
        elif [[ -f "$file_path" ]]; then
            file_exists="true"
            file_type=$(basename "$file_path" | grep -oE '\.[^.]+$')
        fi

        # Find nearby related files (same directory)
        local dir
        dir=$(dirname "$full_path" 2>/dev/null || dirname "$file_path" 2>/dev/null)
        if [[ -d "$dir" ]]; then
            nearby_files=$(ls "$dir" 2>/dev/null | head -5 | tr '\n' ',' | sed 's/,$//')
        fi
    fi

    # Secondary classification heuristics based on file context
    local refined_category="$category"
    if [[ "$category" == "$ETE_CAT_UNKNOWN" && -n "$file_path" ]]; then
        case "$file_path" in
            *prisma*|*migration*|*schema*)
                refined_category="$ETE_CAT_DB_ERROR";;
            *route.ts|*route.js|*api/*)
                refined_category="$ETE_CAT_API_CONTRACT_ERROR";;
            *.css|*.scss|*tailwind*|*postcss*)
                refined_category="$ETE_CAT_CSS_ERROR";;
            *config*|*tsconfig*|*.env*)
                refined_category="$ETE_CAT_CONFIG_ERROR";;
            *auth*|*login*|*session*)
                refined_category="$ETE_CAT_AUTH_ERROR";;
            *test*|*spec*|*__test__*)
                refined_category="$ETE_CAT_RUNTIME_ERROR";;
        esac

        if [[ "$refined_category" != "$ETE_CAT_UNKNOWN" ]]; then
            # Reclassify
            local prev_unk="${_ETE_CAT_COUNT[$ETE_CAT_UNKNOWN]:-0}"
            [[ $prev_unk -gt 0 ]] && _ETE_CAT_COUNT["$ETE_CAT_UNKNOWN"]=$((prev_unk - 1))
            local prev_ref="${_ETE_CAT_COUNT[$refined_category]:-0}"
            _ETE_CAT_COUNT["$refined_category"]=$((prev_ref + 1))
            ETE_CLASSIFICATION_MISSES=$((ETE_CLASSIFICATION_MISSES - 1))
            ETE_CLASSIFICATION_HITS=$((ETE_CLASSIFICATION_HITS + 1))
        fi
    fi

    cat <<EOF
{
  "category": "${refined_category}",
  "parsed": ${parsed},
  "context": {
    "file_exists": ${file_exists},
    "file_type": "${file_type:-}",
    "nearby_files": "${nearby_files:-}"
  }
}
EOF
    return 0
}

# =============================================================================
# _ete_get_category_stats - Return statistics for all categories or a specific one
# Arguments:
#   $1 - category (optional; if empty, returns all)
# Returns:
#   JSON stats via stdout
# =============================================================================
_ete_get_category_stats() {
    local target_cat="${1:-}"

    if [[ -n "$target_cat" ]]; then
        # Single category stats
        local count="${_ETE_CAT_COUNT[$target_cat]:-0}"
        local fix_count="${_ETE_CAT_FIX_COUNT[$target_cat]:-0}"
        local total_fixes="${_ETE_CAT_TOTAL_FIXES[$target_cat]:-0}"
        local fix_rate=0
        if [[ $total_fixes -gt 0 ]]; then
            fix_rate=$(( (fix_count * 100) / total_fixes ))
        fi

        cat <<EOF
{
  "category": "${target_cat}",
  "count": ${count},
  "fix_success": ${fix_count},
  "fix_total": ${total_fixes},
  "fix_rate_pct": ${fix_rate},
  "last_message": "$(echo "${_ETE_CAT_LAST_MSG[$target_cat]:-}" | head -c 200 | sed 's/"/\\"/g; s/$//')"
}
EOF
        return 0
    fi

    # All categories stats
    local total=0
    local categories_json=""

    local all_cats=("$ETE_CAT_TYPE_ERROR" "$ETE_CAT_RUNTIME_ERROR" "$ETE_CAT_BUILD_ERROR" \
        "$ETE_CAT_DB_ERROR" "$ETE_CAT_NETWORK_ERROR" "$ETE_CAT_AUTH_ERROR" \
        "$ETE_CAT_VALIDATION_ERROR" "$ETE_CAT_IMPORT_ERROR" "$ETE_CAT_CONFIG_ERROR" \
        "$ETE_CAT_DEPENDENCY_ERROR" "$ETE_CAT_CSS_ERROR" "$ETE_CAT_API_CONTRACT_ERROR" \
        "$ETE_CAT_MEMORY_ERROR" "$ETE_CAT_PERMISSION_ERROR" "$ETE_CAT_TIMEOUT_ERROR" \
        "$ETE_CAT_UNKNOWN")

    local first=true
    for cat in "${all_cats[@]}"; do
        local count="${_ETE_CAT_COUNT[$cat]:-0}"
        [[ $count -eq 0 ]] && continue

        total=$((total + count))
        local fix_count="${_ETE_CAT_FIX_COUNT[$cat]:-0}"
        local total_fixes="${_ETE_CAT_TOTAL_FIXES[$cat]:-0}"

        if [[ "$first" == "true" ]]; then
            first=false
        else
            categories_json="${categories_json},"
        fi
        categories_json="${categories_json}{\"category\":\"${cat}\",\"count\":${count},\"fix_success\":${fix_count},\"fix_total\":${total_fixes}}"
    done

    local hit_rate=0
    if [[ $ETE_TOTAL_CLASSIFIED -gt 0 ]]; then
        hit_rate=$(( (ETE_CLASSIFICATION_HITS * 100) / ETE_TOTAL_CLASSIFIED ))
    fi

    cat <<EOF
{
  "total_classified": ${ETE_TOTAL_CLASSIFIED},
  "hit_rate_pct": ${hit_rate},
  "categories": [${categories_json}]
}
EOF
    return 0
}

# =============================================================================
# _ete_get_fix_strategy - Return recommended fix strategy for a category
# Arguments:
#   $1 - category
# Returns:
#   JSON with strategy details via stdout
# =============================================================================
_ete_get_fix_strategy() {
    local category="${1:-$ETE_CAT_UNKNOWN}"

    local strategy=""
    local priority=""
    local typical_fix=""
    local files_to_check=""
    local prevention=""

    case "$category" in
        "$ETE_CAT_TYPE_ERROR")
            strategy="type-alignment"
            priority="high"
            typical_fix="型定義を修正するか、適切な型キャストを追加。Prismaの生成型とフロントエンドの型定義を同期させる。"
            files_to_check="*.ts,*.tsx,prisma/schema.prisma,types/*.ts"
            prevention="strictモードのtsconfig.json、zodスキーマとPrisma型の自動同期"
            ;;
        "$ETE_CAT_RUNTIME_ERROR")
            strategy="error-boundary-and-guard"
            priority="critical"
            typical_fix="try-catchブロックの追加、null/undefinedチェック、Error Boundaryの設置。"
            files_to_check="*.ts,*.tsx,*.js,*.jsx"
            prevention="strictNullChecks有効化、Error Boundary全ページ設置、入力値バリデーション"
            ;;
        "$ETE_CAT_BUILD_ERROR")
            strategy="syntax-and-config-fix"
            priority="critical"
            typical_fix="構文エラーの修正、tsconfig/next.config/webpack設定の確認。未使用import削除。"
            files_to_check="tsconfig.json,next.config.*,package.json,*.ts,*.tsx"
            prevention="pre-commit hookでtsc --noEmit、ESLint必須、CI/CDでビルドチェック"
            ;;
        "$ETE_CAT_DB_ERROR")
            strategy="schema-and-migration-sync"
            priority="high"
            typical_fix="Prismaスキーマ修正→prisma generate→prisma db push。マイグレーション整合性確認。"
            files_to_check="prisma/schema.prisma,prisma/migrations/**,lib/prisma.ts,lib/db.ts"
            prevention="prisma validate自動実行、マイグレーション前のドライラン、DBバックアップ"
            ;;
        "$ETE_CAT_NETWORK_ERROR")
            strategy="connection-and-retry"
            priority="medium"
            typical_fix="APIエンドポイントURL確認、CORS設定修正、リトライロジック追加。"
            files_to_check="next.config.*,.env*,middleware.ts,app/api/**/route.ts"
            prevention="ヘルスチェックエンドポイント、自動リトライ(exponential backoff)、タイムアウト設定"
            ;;
        "$ETE_CAT_AUTH_ERROR")
            strategy="auth-flow-review"
            priority="critical"
            typical_fix="JWT秘密鍵確認、トークン有効期限確認、認証ミドルウェアのルート設定見直し。"
            files_to_check="lib/auth.ts,middleware.ts,.env*,app/api/auth/**/route.ts"
            prevention="トークン自動リフレッシュ、セッション監視、認証テスト自動化"
            ;;
        "$ETE_CAT_VALIDATION_ERROR")
            strategy="schema-validation-fix"
            priority="medium"
            typical_fix="zodスキーマの修正、入力フォームのバリデーションルール更新、APIリクエスト/レスポンス型整合。"
            files_to_check="lib/validations/**,app/api/**/route.ts,components/forms/**"
            prevention="zodスキーマの共有化(shared types)、APIテスト自動化"
            ;;
        "$ETE_CAT_IMPORT_ERROR")
            strategy="module-resolution-fix"
            priority="high"
            typical_fix="importパス修正、モジュールインストール確認、tsconfig pathsの確認。"
            files_to_check="tsconfig.json,package.json,node_modules/"
            prevention="ESLint import/no-unresolved、path aliasの統一、依存関係チェック"
            ;;
        "$ETE_CAT_CONFIG_ERROR")
            strategy="config-audit"
            priority="medium"
            typical_fix="設定ファイルの構文確認、環境変数の定義確認、デフォルト値の追加。"
            files_to_check=".env*,tsconfig.json,next.config.*,tailwind.config.*,postcss.config.*"
            prevention=".env.exampleの維持、zod環境変数バリデーション、設定スキーマ定義"
            ;;
        "$ETE_CAT_DEPENDENCY_ERROR")
            strategy="dependency-resolution"
            priority="medium"
            typical_fix="npm install実行、バージョン競合の解決、peer dependency手動インストール。"
            files_to_check="package.json,package-lock.json,node_modules/"
            prevention="lockfileコミット必須、renovate/dependabot自動更新、CI依存チェック"
            ;;
        "$ETE_CAT_CSS_ERROR")
            strategy="style-config-fix"
            priority="low"
            typical_fix="Tailwindクラス名の修正、tailwind.config.jsのcontent設定確認、CSSモジュール名の修正。"
            files_to_check="tailwind.config.*,postcss.config.*,globals.css,**/*.module.css"
            prevention="Tailwind IntelliSense、stylelint、CSSクラス名の命名規約"
            ;;
        "$ETE_CAT_API_CONTRACT_ERROR")
            strategy="api-contract-sync"
            priority="high"
            typical_fix="APIルートのパス確認、HTTPメソッド確認、リクエスト/レスポンス型の整合。"
            files_to_check="app/api/**/route.ts,lib/api.ts,types/api.ts"
            prevention="OpenAPIスキーマ自動生成、API契約テスト、フロントエンド-バックエンド型共有"
            ;;
        "$ETE_CAT_MEMORY_ERROR")
            strategy="memory-optimization"
            priority="critical"
            typical_fix="Node.jsヒープサイズ増加、メモリリーク箇所の特定、大量データのストリーミング処理化。"
            files_to_check="package.json(scripts),*.ts(large arrays),next.config.*"
            prevention="メモリプロファイリング、ページネーション必須、ストリーミングAPI"
            ;;
        "$ETE_CAT_PERMISSION_ERROR")
            strategy="permission-fix"
            priority="medium"
            typical_fix="ファイル/ディレクトリのパーミッション修正、実行ユーザー確認。"
            files_to_check="scripts/**,bin/**,.github/workflows/**"
            prevention="CI/CDでの権限設定、Docker non-rootユーザー、最小権限原則"
            ;;
        "$ETE_CAT_TIMEOUT_ERROR")
            strategy="timeout-and-async-fix"
            priority="medium"
            typical_fix="タイムアウト値の調整、非同期処理の最適化、N+1クエリの解消。"
            files_to_check="app/api/**/route.ts,lib/db.ts,jest.config.*"
            prevention="クエリ最適化、接続プーリング、適切なタイムアウト設定、キャッシュ導入"
            ;;
        *)
            strategy="manual-analysis"
            priority="low"
            typical_fix="エラーメッセージを詳細に分析し、手動で修正方針を決定。"
            files_to_check=""
            prevention="エラーログの充実化、監視の強化"
            ;;
    esac

    cat <<EOF
{
  "category": "${category}",
  "strategy": "${strategy}",
  "priority": "${priority}",
  "typical_fix": "${typical_fix}",
  "files_to_check": "${files_to_check}",
  "prevention": "${prevention}"
}
EOF
    return 0
}

# =============================================================================
# _ete_record_fix_result - Record whether a fix for a category succeeded
# Arguments:
#   $1 - category
#   $2 - success ("true"/"false")
# =============================================================================
_ete_record_fix_result() {
    local category="${1:-}"
    local success="${2:-false}"

    [[ -z "$category" ]] && return 1

    local total="${_ETE_CAT_TOTAL_FIXES[$category]:-0}"
    _ETE_CAT_TOTAL_FIXES["$category"]=$((total + 1))

    if [[ "$success" == "true" ]]; then
        local fixes="${_ETE_CAT_FIX_COUNT[$category]:-0}"
        _ETE_CAT_FIX_COUNT["$category"]=$((fixes + 1))
    fi

    _ete_save_cache
    return 0
}

# =============================================================================
# _ete_get_top_categories - Return top N most frequent error categories
# Arguments:
#   $1 - N (default 5)
# Returns:
#   Sorted category list via stdout
# =============================================================================
_ete_get_top_categories() {
    local top_n="${1:-5}"
    local temp_file
    temp_file=$(mktemp 2>/dev/null || echo "/tmp/ete_top_$$")

    for cat in "${!_ETE_CAT_COUNT[@]}"; do
        local count="${_ETE_CAT_COUNT[$cat]}"
        [[ $count -gt 0 ]] && echo "${count} ${cat}"
    done | sort -rn | head -"$top_n" > "$temp_file"

    local result=""
    local first=true
    while IFS=' ' read -r count cat; do
        if [[ "$first" == "true" ]]; then
            first=false
        else
            result="${result},"
        fi
        result="${result}{\"category\":\"${cat}\",\"count\":${count}}"
    done < "$temp_file"

    rm -f "$temp_file" 2>/dev/null
    echo "[${result}]"
    return 0
}

# =============================================================================
# _ete_batch_classify - Classify multiple errors from a log file
# Arguments:
#   $1 - log_file path
# Returns:
#   JSON array of classifications via stdout
# =============================================================================
_ete_batch_classify() {
    local log_file="${1:-}"
    [[ ! -f "$log_file" ]] && echo "[]" && return 1

    local results=""
    local first=true
    local line_num=0

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        line_num=$((line_num + 1))

        # Skip non-error lines (basic heuristic)
        if ! echo "$line" | grep -qiE 'error|fail|exception|TypeError|Cannot|undefined'; then
            continue
        fi

        local category
        category=$(_ete_classify_error "$line")

        if [[ "$first" == "true" ]]; then
            first=false
        else
            results="${results},"
        fi

        local safe_line
        safe_line=$(echo "$line" | head -c 200 | sed 's/"/\\"/g; s/\\/\\\\/g')
        results="${results}{\"line\":${line_num},\"category\":\"${category}\",\"message\":\"${safe_line}\"}"
    done < "$log_file"

    echo "[${results}]"
    return 0
}

# =============================================================================
# _ete_load_cache - Load persisted taxonomy data from JSON
# =============================================================================
_ete_load_cache() {
    [[ ! -f "$ETE_TAXONOMY_FILE" ]] && return 0

    local line
    # Simple JSON parsing for cached categories
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue

        local cat count fix_count fix_total
        cat=$(echo "$line" | grep -oE '"category":"[^"]*"' | sed 's/"category":"//;s/"//')
        count=$(echo "$line" | grep -oE '"count":[0-9]*' | sed 's/"count"://')
        fix_count=$(echo "$line" | grep -oE '"fix_success":[0-9]*' | sed 's/"fix_success"://')
        fix_total=$(echo "$line" | grep -oE '"fix_total":[0-9]*' | sed 's/"fix_total"://')

        [[ -z "$cat" ]] && continue

        _ETE_CAT_COUNT["$cat"]="${count:-0}"
        _ETE_CAT_FIX_COUNT["$cat"]="${fix_count:-0}"
        _ETE_CAT_TOTAL_FIXES["$cat"]="${fix_total:-0}"
    done < "$ETE_TAXONOMY_FILE"

    return 0
}

# =============================================================================
# _ete_save_cache - Persist taxonomy data to JSON
# =============================================================================
_ete_save_cache() {
    [[ -z "$ETE_TAXONOMY_FILE" ]] && return 0

    local tmp_file="${ETE_TAXONOMY_FILE}.tmp"
    : > "$tmp_file"

    for cat in "${!_ETE_CAT_COUNT[@]}"; do
        local count="${_ETE_CAT_COUNT[$cat]:-0}"
        [[ $count -eq 0 ]] && continue

        local fix_count="${_ETE_CAT_FIX_COUNT[$cat]:-0}"
        local fix_total="${_ETE_CAT_TOTAL_FIXES[$cat]:-0}"
        local last_msg
        last_msg=$(echo "${_ETE_CAT_LAST_MSG[$cat]:-}" | head -c 300 | sed 's/"/\\"/g')

        echo "{\"category\":\"${cat}\",\"count\":${count},\"fix_success\":${fix_count},\"fix_total\":${fix_total},\"last_msg\":\"${last_msg}\"}" >> "$tmp_file"
    done

    mv "$tmp_file" "$ETE_TAXONOMY_FILE" 2>/dev/null || true
    return 0
}

# =============================================================================
# _ete_generate_prevention_prompt - Generate prevention prompt for top categories
# Arguments:
#   $1 - domain (optional)
# Returns:
#   Prevention prompt text via stdout
# =============================================================================
_ete_generate_prevention_prompt() {
    local domain="${1:-all}"

    local top_cats
    top_cats=$(_ete_get_top_categories 3)

    if [[ "$top_cats" == "[]" ]]; then
        echo ""
        return 0
    fi

    local prompt="【Error Taxonomy: 頻出エラーカテゴリ予防ガイド】\n"

    # Parse top categories and add prevention for each
    local idx=0
    while true; do
        local cat
        cat=$(echo "$top_cats" | grep -oE '"category":"[^"]*"' | sed 's/"category":"//;s/"//' | sed -n "$((idx+1))p")
        [[ -z "$cat" ]] && break

        local strategy_json
        strategy_json=$(_ete_get_fix_strategy "$cat")

        local prevention
        prevention=$(echo "$strategy_json" | grep -oE '"prevention":"[^"]*"' | sed 's/"prevention":"//;s/"//')

        if [[ -n "$prevention" ]]; then
            prompt="${prompt}\n- ${cat}: ${prevention}"
        fi

        idx=$((idx + 1))
        [[ $idx -ge 3 ]] && break
    done

    echo -e "$prompt"
    return 0
}

# =============================================================================
# ete_report - Module report output
# =============================================================================
ete_report() {
    echo -e "\n  ${CLR_BOLD:-}═══ Error Taxonomy Engine v${ETE_VERSION} ═══${CLR_NC:-}" >&2
    echo -e "  分類総数           : ${ETE_TOTAL_CLASSIFIED}" >&2
    echo -e "  分類成功           : ${ETE_CLASSIFICATION_HITS}" >&2
    echo -e "  未分類             : ${ETE_CLASSIFICATION_MISSES}" >&2

    local hit_rate=0
    if [[ $ETE_TOTAL_CLASSIFIED -gt 0 ]]; then
        hit_rate=$(( (ETE_CLASSIFICATION_HITS * 100) / ETE_TOTAL_CLASSIFIED ))
    fi
    echo -e "  分類成功率         : ${hit_rate}%" >&2

    # Show top categories
    local top
    top=$(_ete_get_top_categories 5)
    if [[ "$top" != "[]" ]]; then
        echo -e "  頻出カテゴリ       :" >&2
        echo "$top" | grep -oE '"category":"[^"]*","count":[0-9]*' | while IFS= read -r entry; do
            local cat count
            cat=$(echo "$entry" | grep -oE '"category":"[^"]*"' | sed 's/"category":"//;s/"//')
            count=$(echo "$entry" | grep -oE '"count":[0-9]*' | sed 's/"count"://')
            echo -e "    ${cat}: ${count}回" >&2
        done
    fi
}

# =============================================================================
# ete_score - Module score (0-100)
# =============================================================================
ete_score() {
    local score=50

    # Base: classification hit rate
    if [[ $ETE_TOTAL_CLASSIFIED -gt 0 ]]; then
        score=$(( (ETE_CLASSIFICATION_HITS * 80) / ETE_TOTAL_CLASSIFIED ))
    fi

    # Bonus for volume
    if [[ $ETE_TOTAL_CLASSIFIED -ge 10 ]]; then
        score=$((score + 10))
    fi
    if [[ $ETE_TOTAL_CLASSIFIED -ge 50 ]]; then
        score=$((score + 10))
    fi

    [[ $score -gt 100 ]] && score=100
    [[ $score -lt 0 ]] && score=0

    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "error-taxonomy-engine" \
    --version "251.0" \
    --description "エラーを15カテゴリに自動分類・統計・修正戦略提供" \
    --init "ete_init" \
    --report "ete_report" \
    --score "ete_score" \
    --enable-var "ENABLE_ETE" \
    --cli-flags "--error-taxonomy:--no-error-taxonomy"
