#!/usr/bin/env bash
# hearing-engine.sh — 業種別ヒアリングシート素材エンジン (v1.0)
#
# 目的:
#   /soloptilink-hearing Step 1 の正規エンジン。業種フレーズから DBL を特定し、
#   該当辞書の models/pages/business_logic/regulations/keywords を「質問の種」として
#   構造化 JSON で出力する (Claude が顧客に見せられる日本語の質問文に展開するための素材)。
#   DBL 未検出・低確信度の場合は汎用の業務ヒアリング7軸 (hearing_axes) を主軸として出力する。
#
# 使い方 (CLI 契約 — soloptilink-hearing.md がこの契約で呼ぶため変更禁止):
#   bash ~/.soloptilink/lib/hearing-engine.sh sheet "<業種フレーズ>"
#       → stdout 整形JSON: { status, detection, dbl_profile, question_seeds,
#                            candidate_preview, hearing_axes, notes_for_claude }
#         status: detected (確信度高=辞書素材フル出力) / low_confidence (候補のみ・要ユーザー確認)
#                 / unregistered (未登録=汎用7軸のみ)
#   bash ~/.soloptilink/lib/hearing-engine.sh digest "<dbl名>"
#       → stdout 整形JSON: 指定辞書の要点 digest (モデル名/画面/業務ロジック/法令/KPI 等)
#
# 環境変数:
#   SOLOPTILINK_DOMAINS_DIR  (default: ~/.soloptilink/domains) — dbl-detect.sh と同一規約
#   SOLOPTILINK_LIB_DIR      (default: ~/.soloptilink/lib)
#   HEARING_KEYWORDS_MAX     (default: 80) — sheet 出力に含める keywords 種の最大件数
#
# 依存: python3 標準ライブラリのみ (jq 非依存)。業種検出は dbl-detect.sh (正規エンジン) に委譲。
# exit: 0 = 正常 / 2 = 引数・環境エラー

set -uo pipefail

LIB_DIR="${SOLOPTILINK_LIB_DIR:-$HOME/.soloptilink/lib}"
DOMAINS_DIR="${SOLOPTILINK_DOMAINS_DIR:-$HOME/.soloptilink/domains}"
KW_MAX="${HEARING_KEYWORDS_MAX:-80}"
DBL_DETECT="$LIB_DIR/dbl-detect.sh"
CMD="${1:-}"
ARG="${2:-}"

usage() {
    cat >&2 <<'USAGE'
使い方:
  bash hearing-engine.sh sheet "<業種フレーズ>"   # 業種特定 → 質問の種を構造化JSONで出力
  bash hearing-engine.sh digest "<dbl名>"          # 指定 DBL 辞書の要点 digest を出力
USAGE
}

if [[ ! -d "$DOMAINS_DIR" ]]; then
    echo "❌ domains ディレクトリが見つかりません: $DOMAINS_DIR" >&2
    exit 2
fi
if [[ ! -f "$DBL_DETECT" ]]; then
    echo "❌ dbl-detect.sh が見つかりません: $DBL_DETECT" >&2
    exit 2
fi

case "$CMD" in
    sheet|digest)
        if [[ -z "$ARG" ]]; then
            echo "❌ $CMD には引数が必要です" >&2
            usage
            exit 2
        fi
        ;;
    *)
        usage
        exit 2
        ;;
esac

# 業種検出は dbl-detect.sh の CLI 契約に委譲 (スコアリング/グレード判定の SoT を二重実装しない)
DETECT_JSON=""
if [[ "$CMD" == "sheet" ]]; then
    DETECT_JSON="$(bash "$DBL_DETECT" detect "$ARG" 2>/dev/null || true)"
    [[ -n "$DETECT_JSON" ]] || DETECT_JSON='{"dbl":"unregistered","score":0,"grade":"NONE","confident":false}'
fi

# グレード/件数/ファイル名の対応表も dbl-detect.sh audit から取得 (グレード判定ロジックの重複禁止)
AUDIT_JSON="$(bash "$DBL_DETECT" audit 2>/dev/null || true)"
[[ -n "$AUDIT_JSON" ]] || AUDIT_JSON='[]'

# Python 側にモード/ディレクトリ/引数/検出結果を argv で渡す (シェル展開事故防止のためヒアドキュメントに変数を埋め込まない)
exec python3 - "$CMD" "$DOMAINS_DIR" "$KW_MAX" "$ARG" "$DETECT_JSON" "$AUDIT_JSON" <<'PYEOF'
# -*- coding: utf-8 -*-
# hearing-engine 本体 (依存: 標準ライブラリのみ)
import json
import os
import sys

MODE = sys.argv[1]
DOMAINS_DIR = sys.argv[2]
KW_MAX = int(sys.argv[3])
ARG = sys.argv[4]
DETECT_JSON = sys.argv[5] if len(sys.argv) > 5 else ""
AUDIT_JSON = sys.argv[6] if len(sys.argv) > 6 else "[]"

DESC_TRUNC = 240  # 説明文の最大長 (質問の種として十分な情報量と出力肥大のバランス)


def jload(s, fallback):
    try:
        v = json.loads(s)
        return v if v is not None else fallback
    except Exception:
        return fallback


AUDIT = [e for e in jload(AUDIT_JSON, []) if isinstance(e, dict)]

# ---- 汎用業務ヒアリング7軸 (DBL の有無に関わらずシートの骨格になる) ----
# dbl_material = question_seeds のどのキーをこの軸の質問具体化に使うか (Claude 向けの対応表)
GENERIC_AXES = [
    {
        "no": 1, "id": "workflow", "label": "業務フロー",
        "intent": "始業から終業・受注から入金までの実際の流れと、時間がかかる工程を把握する",
        "dbl_material": ["pages", "business_logic"],
        "seed_questions": [
            "1日の業務の流れを、朝の始業から終業まで順に教えてください",
            "お客様 (利用者) との最初の接点から、サービス提供・請求・入金までの流れはどうなっていますか",
            "その中で一番時間がかかっている工程はどこですか",
            "複数人で分担している業務はどれで、誰がどこを担当していますか",
            "月次・年次など、決まった周期で発生する業務は何がありますか",
        ],
    },
    {
        "no": 2, "id": "pain_points", "label": "現在の困りごと",
        "intent": "手作業・二重入力・ミス多発箇所など、システム化で解消すべき痛点を特定する",
        "dbl_material": ["kpi_targets", "business_logic"],
        "seed_questions": [
            "今、業務の中で「これが一番つらい」と感じることは何ですか",
            "手作業・二重入力・転記が発生している場面はありますか",
            "ミスや漏れが起きやすいのはどの業務ですか。直近で実際に起きたトラブルがあれば教えてください",
            "「本当はやりたいのに手が回っていないこと」はありますか",
            "この困りごとが解決すると、月あたり何時間くらい浮きそうですか",
        ],
    },
    {
        "no": 3, "id": "documents_data", "label": "帳票・データ",
        "intent": "日々の帳票・保存データ・移行対象・毎月見たい集計を洗い出す",
        "dbl_material": ["models", "seed_data_tables"],
        "seed_questions": [
            "日々作成・提出している帳票や書類を全部挙げてください (社内向け・社外向け両方)",
            "Excel・紙・既存システムなど、今データはどこにどんな形で保存されていますか",
            "過去データの移行は必要ですか。何年分・何件くらいありますか",
            "役所や取引先に決まった様式で提出する書類はありますか",
            "集計・レポートとして毎月見たい数字は何ですか",
        ],
    },
    {
        "no": 4, "id": "exceptions_peak", "label": "例外処理・繁忙期",
        "intent": "イレギュラー対応・繁忙期の負荷・属人化リスクを把握する",
        "dbl_material": ["business_logic", "enums"],
        "seed_questions": [
            "通常の流れに乗らないイレギュラーな対応にはどんなものがありますか (キャンセル・返品・訂正・特急対応など)",
            "繁忙期はいつで、その時期は業務量がどれくらい増えますか",
            "担当者が急に休んだとき、業務はどう回していますか",
            "過去に「システムや運用が想定していなかった」事態はありましたか",
        ],
    },
    {
        "no": 5, "id": "regulations", "label": "関係法令・規制対応",
        "intent": "遵守すべき法令・届出・監査・記録保存年限・機微データを確認する",
        "dbl_material": ["regulations"],
        "seed_questions": [
            "業務上守らなければならない法令・規制・業界ルールには何がありますか",
            "行政への届出・報告・監査対応は定期的にありますか",
            "記録の保存期間が法令で決まっているものはありますか",
            "個人情報・マイナンバーなど、特に慎重に扱うデータはありますか",
        ],
    },
    {
        "no": 6, "id": "existing_systems", "label": "既存システム・連携先",
        "intent": "現行システム・外部連携・残したい資産を確認し移行/連携範囲を決める",
        "dbl_material": ["keywords"],
        "seed_questions": [
            "今使っているシステム・サービス (会計ソフト・勤怠・グループウェア等) を教えてください",
            "そのうち、新システムとデータ連携が必要なものはどれですか",
            "銀行・取引先・行政システムなど、外部とのデータやり取りはありますか",
            "今のシステムで「残したい良いところ」はありますか",
        ],
    },
    {
        "no": 7, "id": "users_permissions", "label": "利用者・権限",
        "intent": "利用者数・役割・権限分離・利用端末・IT習熟度を把握する",
        "dbl_material": ["models", "pages"],
        "seed_questions": [
            "システムを使う人は何名で、どんな役割の方々ですか",
            "役割ごとに見せたい情報・見せたくない情報の区別はありますか",
            "社外の人 (顧客・取引先・ご家族など) もログインして使いますか",
            "PC・タブレット・スマホ、どの端末で使うことが多いですか",
            "IT に不慣れな方も使いますか。その場合に配慮してほしいことはありますか",
        ],
    },
]


def trunc(s, n=DESC_TRUNC):
    if not isinstance(s, str):
        return ""
    return s if len(s) <= n else s[:n] + "…"


def as_list(v):
    return v if isinstance(v, list) else []


def strip_json_ext(name):
    return name[:-5] if name.lower().endswith(".json") else name


def find_audit_entry(name):
    """dbl 名 (domain/name/ファイル名 stem いずれか) から audit エントリを引く"""
    nl = strip_json_ext(str(name)).strip().lower()
    if not nl:
        return None
    for e in AUDIT:
        if e.get("parse_error"):
            continue
        stem = os.path.splitext(str(e.get("file", "")))[0].lower()
        if nl in (str(e.get("name", "")).lower(), stem):
            return e
    return None


def load_dbl(entry):
    path = os.path.join(DOMAINS_DIR, entry["file"])
    with open(path, encoding="utf-8") as fp:
        j = json.load(fp)
    if not isinstance(j, dict):
        raise ValueError("トップレベルが object ではありません")
    return j


# ---- 質問の種 (question_seeds) ビルダー: str/dict 混在の辞書スキーマ差を吸収 ----

def seed_models(j):
    out = []
    for m in as_list(j.get("models")):
        if isinstance(m, str):
            out.append({"name": m, "description": "", "fields_count": 0})
        elif isinstance(m, dict):
            fields = m.get("fields")
            out.append({
                "name": m.get("name", ""),
                "description": trunc(m.get("description", "")),
                "fields_count": len(fields) if isinstance(fields, list) else 0,
            })
    return out


def seed_pages(j):
    pages = j.get("pages") if j.get("pages") is not None else j.get("screens")
    out = []
    for p in as_list(pages):
        if isinstance(p, str):
            out.append({"path": p, "description": ""})
        elif isinstance(p, dict):
            out.append({"path": p.get("path") or p.get("name", ""),
                        "description": trunc(p.get("description", ""))})
    return out


def seed_logic(j):
    out = []
    for b in as_list(j.get("business_logic")):
        if isinstance(b, str):
            out.append({"name": b, "description": ""})
        elif isinstance(b, dict):
            out.append({"name": b.get("name", ""),
                        "description": trunc(b.get("description", ""))})
    return out


def seed_regulations(j):
    out = []
    for r in as_list(j.get("regulations")):
        if isinstance(r, str):
            out.append({"name": r, "official_name": "", "key_articles": [],
                        "compliance_required": False})
        elif isinstance(r, dict):
            out.append({
                "name": r.get("name", ""),
                "official_name": r.get("official_name", ""),
                "key_articles": [a for a in as_list(r.get("key_articles")) if isinstance(a, str)][:5],
                "compliance_required": bool(r.get("compliance_required", False)),
            })
    return out


def seed_keywords(j, limit):
    return [k for k in as_list(j.get("keywords")) if isinstance(k, str)][:limit]


def seed_kpi(j):
    out = []
    for k in as_list(j.get("kpi_targets")):
        if isinstance(k, str):
            out.append({"name": k, "target": ""})
        elif isinstance(k, dict):
            out.append({"name": k.get("name", ""), "target": k.get("target", "")})
    return out


def seed_tables(j):
    sd = j.get("seed_data")
    return sorted(sd.keys()) if isinstance(sd, dict) else []


def seed_enums(j):
    en = j.get("enums")
    if isinstance(en, dict):
        return sorted(en.keys())
    if isinstance(en, list):
        return [e.get("name", "") if isinstance(e, dict) else str(e) for e in en]
    return []


def build_seeds(j):
    return {
        "models": seed_models(j),
        "pages": seed_pages(j),
        "business_logic": seed_logic(j),
        "regulations": seed_regulations(j),
        "keywords": seed_keywords(j, KW_MAX),
        "kpi_targets": seed_kpi(j),
        "seed_data_tables": seed_tables(j),
        "enums": seed_enums(j),
    }


def profile_of(j, entry):
    return {
        "dbl": entry.get("name", ""),
        "file": entry.get("file", ""),
        "grade": entry.get("grade", ""),
        "industry": j.get("industry") or j.get("display_name") or j.get("displayName") or "",
        "version": j.get("version", ""),
        "description": trunc(j.get("description", ""), 400),
        "counts": entry.get("counts", {}),
    }


def cmd_sheet():
    det = jload(DETECT_JSON, {})
    if not isinstance(det, dict) or "dbl" not in det:
        det = {"dbl": "unregistered", "score": 0, "grade": "NONE", "confident": False}
    dbl = det.get("dbl", "unregistered")
    confident = bool(det.get("confident", False))

    out = {
        "engine": "hearing-engine v1.0",
        "mode": "sheet",
        "industry_phrase": ARG,
        "detection": det,
        "status": "unregistered",
        "dbl_profile": None,
        "question_seeds": None,
        "candidate_preview": None,
        "hearing_axes": GENERIC_AXES,
        "notes_for_claude": [],
    }

    entry = find_audit_entry(dbl) if dbl and dbl != "unregistered" else None
    j = None
    if entry is not None:
        try:
            j = load_dbl(entry)
        except Exception:
            j = None  # 破損辞書は素材に使わない (dbl-validate.sh --strict の領分)

    if j is not None and confident:
        out["status"] = "detected"
        out["dbl_profile"] = profile_of(j, entry)
        out["question_seeds"] = build_seeds(j)
        out["notes_for_claude"] = [
            "業種特定に成功 (confident=true)。question_seeds の素材を hearing_axes の7カテゴリ"
            " (各 axis の dbl_material が対応キー) に割り付け、顧客に見せられる日本語の具体的な質問文に展開すること。",
            "models/pages/business_logic の名称・説明に含まれる業界用語をそのまま質問に活かし、"
            "汎用質問の言い換えだけで済ませないこと。",
            "regulations は ⑤関係法令・規制対応 の質問に必ず反映する"
            " (該当法令の遵守状況・届出・記録保存年限を具体名で聞く)。",
        ]
    elif j is not None:
        out["status"] = "low_confidence"
        out["candidate_preview"] = {
            "dbl_profile": profile_of(j, entry),
            "keywords_sample": seed_keywords(j, 15),
            "model_names": [m.get("name", "") for m in seed_models(j)][:15],
            "regulation_names": [r.get("name", "") for r in seed_regulations(j)],
        }
        out["notes_for_claude"] = [
            "業種特定の確信度が低い (confident=false)。candidate_preview の業種が本当に合っているかを"
            "最初にユーザーへ日本語で確認すること。誤検出の可能性が高い場合は無視してよい。",
            "確認が取れるまでは hearing_axes の汎用7軸を主軸にし、candidate_preview を断定的な前提として使わないこと。",
            "ユーザーが業種を確定したら hearing-engine.sh digest \"<dbl名>\" で辞書要点を取得して質問を具体化できる。",
        ]
    else:
        out["notes_for_claude"] = [
            "DBL 未登録の業種。hearing_axes の汎用7軸を業種フレーズ「" + ARG + "」の文脈に合わせて言い換え、"
            "顧客に見せられる日本語の質問リストに展開すること。",
            "業界特有の帳票・法令・繁忙期はヒアリングの中でユーザーから聞き出し、"
            "後続の /soloptilink-rfp・/soloptilink-boost に引き継ぐこと。",
        ]

    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


def cmd_digest():
    entry = find_audit_entry(ARG)
    if entry is None:
        names = sorted(str(e.get("name", "")) for e in AUDIT if not e.get("parse_error"))
        sys.stderr.write("❌ 指定の DBL が見つかりません: %s\n" % ARG)
        sys.stderr.write("   利用可能: %s\n" % ", ".join(names))
        return 2
    try:
        j = load_dbl(entry)
    except Exception as e:
        sys.stderr.write("❌ 辞書 JSON の読込に失敗: %s (%s)\n" % (entry.get("file", ""), e))
        return 2
    out = {
        "engine": "hearing-engine v1.0",
        "mode": "digest",
        "dbl_profile": profile_of(j, entry),
        "digest": {
            "model_names": [m.get("name", "") for m in seed_models(j)],
            "page_paths": [p.get("path", "") for p in seed_pages(j)],
            "business_logic": seed_logic(j),
            "regulations": seed_regulations(j),
            "keywords_top": seed_keywords(j, 30),
            "kpi_targets": seed_kpi(j),
            "seed_data_tables": seed_tables(j),
            "enums": seed_enums(j),
        },
    }
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


sys.exit({"sheet": cmd_sheet, "digest": cmd_digest}[MODE]())
PYEOF
