#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v467.0 - Cost-Performance Optimizer
# =============================================================================
# コスト対パフォーマンス最適化: トレードオフ分析、最適化提案、設定生成。
#
# Functions:
#   _cpopt_init()                   - Initialize
#   _cpopt_analyze_tradeoffs()      - Analyze cost vs performance tradeoffs
#   _cpopt_suggest_optimization()   - Suggest optimizations
#   _cpopt_generate_config()        - Generate optimized configuration
#   _cpopt_report() / _cpopt_score()
# =============================================================================

[[ -n "${_CPOPT_LOADED:-}" ]] && return 0; _CPOPT_LOADED=1

declare -g CPOPT_VERSION="467.0"
CPOPT_GENERATED=0; CPOPT_ERRORS=0; CPOPT_FILES_WRITTEN=0
CPOPT_TRADEOFFS_OK=false; CPOPT_SUGGEST_OK=false; CPOPT_CONFIG_OK=false

_cpopt_init() {
    CPOPT_GENERATED=0; CPOPT_ERRORS=0; CPOPT_FILES_WRITTEN=0
    CPOPT_TRADEOFFS_OK=false; CPOPT_SUGGEST_OK=false; CPOPT_CONFIG_OK=false
    return 0
}

_cpopt_log() { echo -e "  ${CYAN:-\033[0;36m}[cost-perf]${NC:-\033[0m} $*" >&2; }
_cpopt_ok()  { echo -e "  ${GREEN:-\033[0;32m}✅ [cost-perf]${NC:-\033[0m} $*" >&2; }
_cpopt_err() { echo -e "  ${RED:-\033[0;31m}❌ [cost-perf]${NC:-\033[0m} $*" >&2; CPOPT_ERRORS=$((CPOPT_ERRORS + 1)); }

_cpopt_write_file() {
    local filepath="$1" content="$2"
    local dir; dir="$(dirname "$filepath")"
    [[ -d "$dir" ]] || mkdir -p "$dir"
    echo "$content" > "$filepath" 2>/dev/null || { _cpopt_err "Failed to write $filepath"; return 1; }
    CPOPT_FILES_WRITTEN=$((CPOPT_FILES_WRITTEN + 1))
    return 0
}

_cpopt_analyze_tradeoffs() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/cost-perf/tradeoff-analyzer.ts"
    _cpopt_log "Generating tradeoff analyzer..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v467.0 - Cost-Performance Tradeoff Analyzer

export interface ResourceOption {
  name: string;
  tier: 'free' | 'starter' | 'pro' | 'enterprise';
  monthlyCost: number;
  performance: { latencyMs: number; throughput: number; availability: number };
  limits: Record<string, number>;
}

export interface TradeoffResult {
  recommendation: string;
  currentCost: number;
  optimizedCost: number;
  savingsPercent: number;
  performanceImpact: 'none' | 'minimal' | 'moderate' | 'significant';
  changes: Array<{ resource: string; from: string; to: string; savings: number }>;
}

const RESOURCE_OPTIONS: Record<string, ResourceOption[]> = {
  database: [
    { name: 'SQLite', tier: 'free', monthlyCost: 0, performance: { latencyMs: 5, throughput: 1000, availability: 99.5 }, limits: { connections: 1, storageMb: 500 } },
    { name: 'PlanetScale Hobby', tier: 'free', monthlyCost: 0, performance: { latencyMs: 20, throughput: 5000, availability: 99.9 }, limits: { connections: 5, storageMb: 5000 } },
    { name: 'PlanetScale Scaler', tier: 'pro', monthlyCost: 29, performance: { latencyMs: 10, throughput: 50000, availability: 99.99 }, limits: { connections: 100, storageMb: 50000 } },
    { name: 'RDS t3.medium', tier: 'pro', monthlyCost: 50, performance: { latencyMs: 5, throughput: 100000, availability: 99.95 }, limits: { connections: 300, storageMb: 500000 } },
  ],
  hosting: [
    { name: 'Vercel Hobby', tier: 'free', monthlyCost: 0, performance: { latencyMs: 50, throughput: 100, availability: 99.9 }, limits: { bandwidth: 100, builds: 6000 } },
    { name: 'Vercel Pro', tier: 'pro', monthlyCost: 20, performance: { latencyMs: 30, throughput: 1000, availability: 99.95 }, limits: { bandwidth: 1000, builds: 24000 } },
    { name: 'AWS Fargate', tier: 'pro', monthlyCost: 40, performance: { latencyMs: 20, throughput: 10000, availability: 99.99 }, limits: { bandwidth: 10000, builds: -1 } },
  ],
  cache: [
    { name: 'In-Memory', tier: 'free', monthlyCost: 0, performance: { latencyMs: 1, throughput: 50000, availability: 99 }, limits: { storageMb: 256 } },
    { name: 'Upstash Free', tier: 'free', monthlyCost: 0, performance: { latencyMs: 5, throughput: 10000, availability: 99.9 }, limits: { storageMb: 256 } },
    { name: 'Upstash Pro', tier: 'pro', monthlyCost: 10, performance: { latencyMs: 3, throughput: 100000, availability: 99.99 }, limits: { storageMb: 10000 } },
  ],
};

export class TradeoffAnalyzer {
  analyzeForBudget(monthlyBudget: number, userCount: number): TradeoffResult {
    const changes: TradeoffResult['changes'] = [];
    let totalCost = 0;
    for (const [resource, options] of Object.entries(RESOURCE_OPTIONS)) {
      const affordable = options.filter(o => o.monthlyCost <= monthlyBudget * 0.4);
      const best = affordable.sort((a, b) => b.performance.throughput - a.performance.throughput)[0];
      if (best) { totalCost += best.monthlyCost; changes.push({ resource, from: 'current', to: best.name, savings: 0 }); }
    }
    return { recommendation: `Optimized for budget $${monthlyBudget}/mo with ~${userCount} users`, currentCost: 0, optimizedCost: totalCost, savingsPercent: 0, performanceImpact: 'none', changes };
  }

  getOptions(resource: string): ResourceOption[] { return RESOURCE_OPTIONS[resource] ?? []; }
  getAllCategories(): string[] { return Object.keys(RESOURCE_OPTIONS); }
}

export const tradeoffAnalyzer = new TradeoffAnalyzer();
TYPESCRIPT
)
    _cpopt_write_file "$outfile" "$content" || return 1
    CPOPT_TRADEOFFS_OK=true
    CPOPT_GENERATED=$((CPOPT_GENERATED + 1))
    _cpopt_ok "Tradeoff analyzer generated"
    return 0
}

_cpopt_suggest_optimization() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/cost-perf/optimization-advisor.ts"
    _cpopt_log "Generating optimization advisor..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v467.0 - Cost-Performance Optimization Advisor

export interface OptimizationSuggestion {
  id: string;
  category: 'infrastructure' | 'code' | 'architecture' | 'caching' | 'database';
  title: string;
  description: string;
  estimatedSavings: string;
  performanceGain: string;
  effort: 'low' | 'medium' | 'high';
  priority: number;
}

const SUGGESTIONS: OptimizationSuggestion[] = [
  { id: 'edge-runtime', category: 'infrastructure', title: 'Use Edge Runtime for API routes', description: 'Move lightweight API routes to edge runtime for lower latency and cost', estimatedSavings: '20-40%', performanceGain: '50-80% TTFB reduction', effort: 'low', priority: 1 },
  { id: 'isr-caching', category: 'caching', title: 'Implement ISR for frequently accessed pages', description: 'Use Incremental Static Regeneration to reduce server-side rendering load', estimatedSavings: '30-60%', performanceGain: 'Near-instant page loads', effort: 'low', priority: 2 },
  { id: 'db-connection-pool', category: 'database', title: 'Optimize connection pooling', description: 'Use Prisma connection pooling or PgBouncer to reduce database connections', estimatedSavings: '10-20%', performanceGain: '30% query reduction', effort: 'low', priority: 3 },
  { id: 'bundle-splitting', category: 'code', title: 'Aggressive code splitting', description: 'Split vendor bundles and lazy-load heavy components', estimatedSavings: '5-10%', performanceGain: '40% faster initial load', effort: 'medium', priority: 4 },
  { id: 'image-optimization', category: 'code', title: 'Optimize image delivery', description: 'Use next/image with WebP/AVIF, proper sizing, and CDN', estimatedSavings: '15-30%', performanceGain: '60% bandwidth savings', effort: 'low', priority: 5 },
  { id: 'query-optimization', category: 'database', title: 'Optimize N+1 queries', description: 'Add proper includes/joins and database indexes', estimatedSavings: '10-25%', performanceGain: '50-80% query speed', effort: 'medium', priority: 6 },
];

export class OptimizationAdvisor {
  getSuggestions(context?: { budget?: string; userCount?: number }): OptimizationSuggestion[] {
    return [...SUGGESTIONS].sort((a, b) => a.priority - b.priority);
  }

  getByCategory(category: OptimizationSuggestion['category']): OptimizationSuggestion[] {
    return SUGGESTIONS.filter(s => s.category === category);
  }

  getQuickWins(): OptimizationSuggestion[] {
    return SUGGESTIONS.filter(s => s.effort === 'low').sort((a, b) => a.priority - b.priority);
  }
}

export const optimizationAdvisor = new OptimizationAdvisor();
TYPESCRIPT
)
    _cpopt_write_file "$outfile" "$content" || return 1
    CPOPT_SUGGEST_OK=true
    CPOPT_GENERATED=$((CPOPT_GENERATED + 1))
    _cpopt_ok "Optimization advisor generated"
    return 0
}

_cpopt_generate_config() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/cost-perf/optimized-config.ts"
    _cpopt_log "Generating optimized configuration..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v467.0 - Optimized Configuration Generator

export type OptimizationProfile = 'cost-first' | 'balanced' | 'performance-first';

export interface OptimizedConfig {
  profile: OptimizationProfile;
  next: Record<string, unknown>;
  database: Record<string, unknown>;
  cache: Record<string, unknown>;
  cdn: Record<string, unknown>;
}

export class ConfigOptimizer {
  generate(profile: OptimizationProfile): OptimizedConfig {
    const configs: Record<OptimizationProfile, OptimizedConfig> = {
      'cost-first': {
        profile, next: { output: 'export', compress: true, images: { unoptimized: false, formats: ['webp'] } },
        database: { provider: 'sqlite', connectionLimit: 1 },
        cache: { provider: 'memory', maxSize: '256mb' },
        cdn: { provider: 'vercel', cacheControl: 'public, max-age=86400' },
      },
      'balanced': {
        profile, next: { compress: true, images: { formats: ['webp', 'avif'], quality: 80 }, experimental: { ppr: true } },
        database: { provider: 'planetscale', connectionLimit: 10 },
        cache: { provider: 'upstash', maxSize: '1gb' },
        cdn: { provider: 'vercel', cacheControl: 'public, max-age=3600, stale-while-revalidate=86400' },
      },
      'performance-first': {
        profile, next: { compress: true, images: { formats: ['avif', 'webp'], quality: 90 }, experimental: { ppr: true } },
        database: { provider: 'rds', connectionLimit: 50, readReplicas: 2 },
        cache: { provider: 'elasticache', maxSize: '10gb' },
        cdn: { provider: 'cloudfront', cacheControl: 'public, max-age=60, stale-while-revalidate=3600' },
      },
    };
    return configs[profile];
  }

  estimateMonthlyCost(config: OptimizedConfig): number {
    const costs: Record<OptimizationProfile, number> = { 'cost-first': 0, 'balanced': 50, 'performance-first': 200 };
    return costs[config.profile] ?? 50;
  }
}

export const configOptimizer = new ConfigOptimizer();
TYPESCRIPT
)
    _cpopt_write_file "$outfile" "$content" || return 1
    CPOPT_CONFIG_OK=true
    CPOPT_GENERATED=$((CPOPT_GENERATED + 1))
    _cpopt_ok "Optimized config generated"
    return 0
}

_cpopt_generate_all() {
    local project_dir="${1:-.}"
    _cpopt_analyze_tradeoffs "$project_dir"
    _cpopt_suggest_optimization "$project_dir"
    _cpopt_generate_config "$project_dir"
    _cpopt_ok "Cost-performance optimization complete: ${CPOPT_GENERATED} components, ${CPOPT_ERRORS} errors"
}

_cpopt_report() {
    echo -e "\n  ${BOLD:-\033[1m}═══ Cost-Performance Optimizer v${CPOPT_VERSION} ═══${NC:-\033[0m}"
    echo -e "  Generated    : ${CPOPT_GENERATED}"
    echo -e "  Errors       : ${CPOPT_ERRORS}"
    echo -e "  Tradeoffs    : ${CPOPT_TRADEOFFS_OK}"
    echo -e "  Suggestions  : ${CPOPT_SUGGEST_OK}"
    echo -e "  Config       : ${CPOPT_CONFIG_OK}"
}

_cpopt_score() {
    local score=50
    ${CPOPT_TRADEOFFS_OK} && score=$((score + 15))
    ${CPOPT_SUGGEST_OK} && score=$((score + 15))
    ${CPOPT_CONFIG_OK} && score=$((score + 15))
    [[ ${CPOPT_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "cost-performance-optimizer" --version "467.0" \
        --description "コスト対パフォーマンス最適化: トレードオフ分析×提案×設定生成" \
        --init "_cpopt_init" --report "_cpopt_report" --score "_cpopt_score" \
        --enable-var "ENABLE_COST_PERF" --cli-flags "--cost-perf:--no-cost-perf"
fi

# v2003.1: source時のexit codeを確実に0にする
true
