#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2015.0 - Multi-Stage Review Pipeline
# =============================================================================
# 4段階カスケードレビューシステム。各ステージが通過基準を満たさないと
# 次のステージに進めない。出力品質を構造・意味・品質・完全性の4軸で保証。
#
# Stages:
#   1. Structural Validation  (10% weight) - ファイル構造・import・ルート・設定
#   2. Semantic Correctness   (30% weight) - 型安全・APIコントラクト・認証・DB整合性
#   3. Quality Standards      (40% weight) - コード品質・UX・テスト・ドキュメント・性能
#   4. Completeness           (20% weight) - 機能網羅・CRUD・エッジケース・a11y
#
# All globals: MSR_ prefix
# All functions: msr_ prefix
# =============================================================================

[[ -n "${_MULTI_STAGE_REVIEW_LOADED:-}" ]] && return 0
_MULTI_STAGE_REVIEW_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g MSR_VERSION="2015.0"
declare -g MSR_INITIALIZED=false
declare -g MSR_LOG_PREFIX="[MSR]"

# Stage thresholds (minimum score to pass)
declare -g MSR_THRESHOLD_STAGE1=70
declare -g MSR_THRESHOLD_STAGE2=65
declare -g MSR_THRESHOLD_STAGE3=60
declare -g MSR_THRESHOLD_STAGE4=55

# Stage weights (must sum to 100)
declare -g MSR_WEIGHT_STAGE1=10
declare -g MSR_WEIGHT_STAGE2=30
declare -g MSR_WEIGHT_STAGE3=40
declare -g MSR_WEIGHT_STAGE4=20

# Current run results
declare -g MSR_SCORE_STAGE1=0
declare -g MSR_SCORE_STAGE2=0
declare -g MSR_SCORE_STAGE3=0
declare -g MSR_SCORE_STAGE4=0
declare -g MSR_WEIGHTED_TOTAL=0
declare -g MSR_PIPELINE_PASSED=false

# Issue tracking
declare -g MSR_ISSUES_STAGE1=""
declare -g MSR_ISSUES_STAGE2=""
declare -g MSR_ISSUES_STAGE3=""
declare -g MSR_ISSUES_STAGE4=""

# Statistics (persistent across runs within session)
declare -g MSR_STAT_TOTAL_RUNS=0
declare -g MSR_STAT_PASS_COUNT=0
declare -g MSR_STAT_FAIL_COUNT=0
declare -g MSR_STAT_TOTAL_RETRIES=0
declare -g MSR_STAT_S1_SUM=0
declare -g MSR_STAT_S2_SUM=0
declare -g MSR_STAT_S3_SUM=0
declare -g MSR_STAT_S4_SUM=0
declare -g MSR_STAT_COMMON_FAILURES=""

# =============================================================================
# Logging
# =============================================================================
_msr_log()     { echo -e "  ${CLR_CYAN:-\033[0;36m}${MSR_LOG_PREFIX}${CLR_NC:-\033[0m} $*" >&2; }
_msr_success() { echo -e "  ${CLR_GREEN:-\033[0;32m}${MSR_LOG_PREFIX} PASS${CLR_NC:-\033[0m} $*" >&2; }
_msr_warn()    { echo -e "  ${CLR_YELLOW:-\033[0;33m}${MSR_LOG_PREFIX} WARN${CLR_NC:-\033[0m} $*" >&2; }
_msr_error()   { echo -e "  ${CLR_RED:-\033[0;31m}${MSR_LOG_PREFIX} FAIL${CLR_NC:-\033[0m} $*" >&2; }
_msr_stage()   { echo -e "  ${CLR_MAGENTA:-\033[0;35m}${MSR_LOG_PREFIX} STAGE${CLR_NC:-\033[0m} $*" >&2; }

# Helper: log_info/log_warn/log_error delegation
_msr_log_info()  { if declare -f log_info &>/dev/null; then log_info "$1"; else _msr_log "$1"; fi; }
_msr_log_warn()  { if declare -f log_warn &>/dev/null; then log_warn "$1"; else _msr_warn "$1"; fi; }
_msr_log_error() { if declare -f log_error &>/dev/null; then log_error "$1"; else _msr_error "$1"; fi; }

# =============================================================================
# 1. msr_init() - Initialize pipeline
# =============================================================================
msr_init() {
    MSR_INITIALIZED=true

    # Reset current run scores
    MSR_SCORE_STAGE1=0
    MSR_SCORE_STAGE2=0
    MSR_SCORE_STAGE3=0
    MSR_SCORE_STAGE4=0
    MSR_WEIGHTED_TOTAL=0
    MSR_PIPELINE_PASSED=false

    # Reset issue lists
    MSR_ISSUES_STAGE1=""
    MSR_ISSUES_STAGE2=""
    MSR_ISSUES_STAGE3=""
    MSR_ISSUES_STAGE4=""

    # Thresholds can be overridden via env
    MSR_THRESHOLD_STAGE1="${MSR_CUSTOM_THRESHOLD_S1:-70}"
    MSR_THRESHOLD_STAGE2="${MSR_CUSTOM_THRESHOLD_S2:-65}"
    MSR_THRESHOLD_STAGE3="${MSR_CUSTOM_THRESHOLD_S3:-60}"
    MSR_THRESHOLD_STAGE4="${MSR_CUSTOM_THRESHOLD_S4:-55}"

    _msr_log_info "msr: v${MSR_VERSION} initialized (thresholds: S1=${MSR_THRESHOLD_STAGE1} S2=${MSR_THRESHOLD_STAGE2} S3=${MSR_THRESHOLD_STAGE3} S4=${MSR_THRESHOLD_STAGE4})"
    return 0
}

# =============================================================================
# Internal: append issue to a stage's issue list
# =============================================================================
_msr_add_issue() {
    local stage="$1"
    local severity="$2"  # critical, major, minor
    local category="$3"
    local message="$4"
    local file="${5:-}"

    local entry="${severity}|${category}|${message}|${file}"

    case "$stage" in
        1) MSR_ISSUES_STAGE1="${MSR_ISSUES_STAGE1:+${MSR_ISSUES_STAGE1}$'\n'}${entry}" ;;
        2) MSR_ISSUES_STAGE2="${MSR_ISSUES_STAGE2:+${MSR_ISSUES_STAGE2}$'\n'}${entry}" ;;
        3) MSR_ISSUES_STAGE3="${MSR_ISSUES_STAGE3:+${MSR_ISSUES_STAGE3}$'\n'}${entry}" ;;
        4) MSR_ISSUES_STAGE4="${MSR_ISSUES_STAGE4:+${MSR_ISSUES_STAGE4}$'\n'}${entry}" ;;
    esac
}

# =============================================================================
# Internal: count issues by severity for a stage
# =============================================================================
_msr_count_issues() {
    local issues_var="$1"
    local severity="$2"

    if [[ -z "$issues_var" ]]; then
        echo 0
        return
    fi

    echo "$issues_var" | grep -c "^${severity}|" 2>/dev/null || echo 0
}

# =============================================================================
# Internal: calculate score from issue counts
#   critical = -15pts each, major = -8pts each, minor = -3pts each
# =============================================================================
_msr_calculate_score() {
    local issues_var="$1"
    local score=100

    if [[ -n "$issues_var" ]]; then
        local criticals majors minors
        criticals=$(_msr_count_issues "$issues_var" "critical")
        majors=$(_msr_count_issues "$issues_var" "major")
        minors=$(_msr_count_issues "$issues_var" "minor")

        score=$(( score - (criticals * 15) - (majors * 8) - (minors * 3) ))
    fi

    # Clamp to 0-100
    (( score < 0 )) && score=0
    (( score > 100 )) && score=100
    echo "$score"
}

# =============================================================================
# 3. msr_stage1_structural(project_dir) - Structural Validation
# =============================================================================
msr_stage1_structural() {
    local project_dir="${1:-.}"
    _msr_stage "1/4: Structural Validation (weight: ${MSR_WEIGHT_STAGE1}%)"

    if [[ ! -d "$project_dir" ]]; then
        _msr_log_error "msr-s1: Project directory does not exist: $project_dir"
        MSR_SCORE_STAGE1=0
        return 1
    fi

    MSR_ISSUES_STAGE1=""

    # ---- 1a. Required directories ----
    _msr_log "S1: Checking directory structure..."
    local required_dirs=("src" "app" "components" "lib")
    local alt_dirs_map_src="src|app"
    local alt_dirs_map_comp="components|src/components|app/components"

    local has_src=false has_app=false has_comp=false has_lib=false

    [[ -d "$project_dir/src" ]] && has_src=true
    [[ -d "$project_dir/app" ]] && has_app=true

    if [[ "$has_src" == false && "$has_app" == false ]]; then
        _msr_add_issue 1 "critical" "dir-structure" "No src/ or app/ directory found" "$project_dir"
    fi

    # Components can live in several places
    if [[ -d "$project_dir/components" || -d "$project_dir/src/components" || -d "$project_dir/app/components" ]]; then
        has_comp=true
    fi
    if [[ "$has_comp" == false ]]; then
        _msr_add_issue 1 "major" "dir-structure" "No components directory found (checked components/, src/components/, app/components/)" "$project_dir"
    fi

    # lib/ is optional but recommended
    if [[ -d "$project_dir/lib" || -d "$project_dir/src/lib" || -d "$project_dir/utils" || -d "$project_dir/src/utils" ]]; then
        has_lib=true
    fi
    if [[ "$has_lib" == false ]]; then
        _msr_add_issue 1 "minor" "dir-structure" "No lib/ or utils/ directory found for shared utilities" "$project_dir"
    fi

    # ---- 1b. Import graph validation ----
    _msr_log "S1: Checking imports for circular dependencies..."
    local ts_files
    ts_files=$(find "$project_dir" -type f \( -name '*.ts' -o -name '*.tsx' \) -not -path '*/node_modules/*' -not -path '*/.next/*' -not -path '*/dist/*' 2>/dev/null)

    local circular_count=0
    if [[ -n "$ts_files" ]]; then
        # Build a simple import map and detect A->B->A cycles
        local -A import_map
        while IFS= read -r ts_file; do
            [[ -z "$ts_file" ]] && continue
            local relative_file="${ts_file#$project_dir/}"
            local imports
            imports=$(grep -oP "from\s+['\"](\./[^'\"]+|\.\.\/[^'\"]+)['\"]" "$ts_file" 2>/dev/null | sed "s/from[[:space:]]*['\"]//;s/['\"]$//" | head -50)
            while IFS= read -r imp; do
                [[ -z "$imp" ]] && continue
                local dir_of_file
                dir_of_file=$(dirname "$relative_file")
                local resolved
                resolved=$(cd "$project_dir" && realpath --relative-to=. "$dir_of_file/$imp" 2>/dev/null || echo "$dir_of_file/$imp")
                import_map["$relative_file"]+="$resolved "
            done <<< "$imports"
        done <<< "$ts_files"

        # Simple 2-hop cycle detection: A imports B, B imports A
        for file_a in "${!import_map[@]}"; do
            for dep_b in ${import_map[$file_a]}; do
                if [[ -n "${import_map[$dep_b]+x}" ]]; then
                    local file_a_base="${file_a%.tsx}"
                    file_a_base="${file_a_base%.ts}"
                    if echo "${import_map[$dep_b]}" | grep -q "$file_a_base"; then
                        circular_count=$((circular_count + 1))
                        _msr_add_issue 1 "major" "circular-import" "Circular import detected: $file_a <-> $dep_b" "$file_a"
                    fi
                fi
            done
        done
        # Cap at 3 to avoid duplicate noise
        if (( circular_count > 3 )); then
            _msr_log "S1: $circular_count circular import candidates found (showing first 3)"
        fi
    fi

    # Check for missing imports (files importing from paths that don't exist)
    _msr_log "S1: Checking for missing imports..."
    local missing_imports=0
    if [[ -n "$ts_files" ]]; then
        while IFS= read -r ts_file; do
            [[ -z "$ts_file" ]] && continue
            local relative_imports
            relative_imports=$(grep -oP "from\s+['\"](\./[^'\"]+|\.\.\/[^'\"]+)['\"]" "$ts_file" 2>/dev/null | sed "s/from[[:space:]]*['\"]//;s/['\"]$//" | head -30)
            while IFS= read -r imp; do
                [[ -z "$imp" ]] && continue
                local dir_of_file
                dir_of_file=$(dirname "$ts_file")
                # Check if the import target exists (with common extensions)
                local found=false
                for ext in "" ".ts" ".tsx" ".js" ".jsx" "/index.ts" "/index.tsx" "/index.js"; do
                    if [[ -f "${dir_of_file}/${imp}${ext}" ]]; then
                        found=true
                        break
                    fi
                done
                if [[ "$found" == false ]]; then
                    missing_imports=$((missing_imports + 1))
                    if (( missing_imports <= 5 )); then
                        _msr_add_issue 1 "major" "missing-import" "Import not found: $imp" "$ts_file"
                    fi
                fi
            done <<< "$relative_imports"
        done <<< "$(echo "$ts_files" | head -100)"
    fi

    # ---- 1c. Route completeness ----
    _msr_log "S1: Checking route completeness..."
    if [[ -d "$project_dir/app" ]]; then
        # Next.js App Router: every directory under app/ with page.tsx constitutes a route
        local route_dirs
        route_dirs=$(find "$project_dir/app" -type d -not -path '*/node_modules/*' -not -name 'api' -not -path '*/api/*' 2>/dev/null | head -50)
        while IFS= read -r route_dir; do
            [[ -z "$route_dir" ]] && continue
            [[ "$route_dir" == "$project_dir/app" ]] && continue
            local dir_name
            dir_name=$(basename "$route_dir")
            # Skip special Next.js dirs
            [[ "$dir_name" == "_*" ]] && continue
            [[ "$dir_name" == "components" || "$dir_name" == "lib" || "$dir_name" == "hooks" || "$dir_name" == "utils" ]] && continue

            # Check if this route dir has either page.tsx or layout.tsx
            if [[ ! -f "$route_dir/page.tsx" && ! -f "$route_dir/page.ts" && ! -f "$route_dir/page.jsx" && ! -f "$route_dir/page.js" ]]; then
                # Directory exists under app/ but no page file - it might be a route group or layout-only
                if [[ ! -f "$route_dir/layout.tsx" && ! -f "$route_dir/layout.ts" && ! "$dir_name" =~ ^\(.+\)$ ]]; then
                    _msr_add_issue 1 "minor" "route-incomplete" "Route directory has no page or layout file: $route_dir" "$route_dir"
                fi
            fi
        done <<< "$route_dirs"
    fi

    # ---- 1d. Config completeness ----
    _msr_log "S1: Checking configuration files..."

    # package.json
    if [[ -f "$project_dir/package.json" ]]; then
        local pkg_content
        pkg_content=$(cat "$project_dir/package.json" 2>/dev/null)
        # Check required scripts
        for script in "dev" "build" "start"; do
            if ! echo "$pkg_content" | grep -q "\"$script\""; then
                _msr_add_issue 1 "major" "config-incomplete" "package.json missing '$script' script" "package.json"
            fi
        done
        # Check lint script (recommended)
        if ! echo "$pkg_content" | grep -q '"lint"'; then
            _msr_add_issue 1 "minor" "config-incomplete" "package.json missing 'lint' script" "package.json"
        fi
    else
        _msr_add_issue 1 "critical" "config-missing" "No package.json found" "$project_dir"
    fi

    # tsconfig.json
    if [[ -f "$project_dir/tsconfig.json" ]]; then
        # Validate JSON syntax
        if command -v python3 &>/dev/null; then
            if ! python3 -c "import json; json.load(open('$project_dir/tsconfig.json'))" 2>/dev/null; then
                _msr_add_issue 1 "major" "config-invalid" "tsconfig.json has invalid JSON syntax" "tsconfig.json"
            fi
        fi
        # Check strict mode
        if ! grep -q '"strict":\s*true' "$project_dir/tsconfig.json" 2>/dev/null && \
           ! grep -q '"strict": true' "$project_dir/tsconfig.json" 2>/dev/null; then
            _msr_add_issue 1 "minor" "config-incomplete" "tsconfig.json does not have strict mode enabled" "tsconfig.json"
        fi
    else
        # Not critical if .js project
        local ts_count
        ts_count=$(find "$project_dir" -name '*.ts' -o -name '*.tsx' -not -path '*/node_modules/*' 2>/dev/null | head -1 | wc -l)
        if (( ts_count > 0 )); then
            _msr_add_issue 1 "major" "config-missing" "TypeScript files found but no tsconfig.json" "$project_dir"
        fi
    fi

    # ---- 1e. Schema validation ----
    _msr_log "S1: Checking Prisma schema..."
    local prisma_schema=""
    [[ -f "$project_dir/prisma/schema.prisma" ]] && prisma_schema="$project_dir/prisma/schema.prisma"
    [[ -f "$project_dir/schema.prisma" ]] && prisma_schema="$project_dir/schema.prisma"

    if [[ -n "$prisma_schema" ]]; then
        # Check that all models have id field
        local models
        models=$(grep -c '^model ' "$prisma_schema" 2>/dev/null || echo 0)
        local models_with_id
        models_with_id=$(awk '/^model /{m=1; has_id=0} m && /^\s+id\s/{has_id=1} m && /^\}/{if(has_id)c++; m=0} END{print c+0}' "$prisma_schema" 2>/dev/null)

        if (( models > 0 && models_with_id < models )); then
            local missing_id=$((models - models_with_id))
            _msr_add_issue 1 "major" "schema-integrity" "$missing_id Prisma model(s) missing id field" "$prisma_schema"
        fi

        # Check that models have timestamp fields (createdAt/updatedAt)
        local models_with_timestamps
        models_with_timestamps=$(awk '/^model /{m=1; has_ts=0} m && /createdAt/{has_ts++} m && /updatedAt/{has_ts++} m && /^\}/{if(has_ts>=2)c++; m=0} END{print c+0}' "$prisma_schema" 2>/dev/null)
        if (( models > 0 && models_with_timestamps < models )); then
            local missing_ts=$((models - models_with_timestamps))
            _msr_add_issue 1 "minor" "schema-integrity" "$missing_ts Prisma model(s) missing createdAt/updatedAt timestamps" "$prisma_schema"
        fi

        # Check for datasource block
        if ! grep -q '^datasource ' "$prisma_schema" 2>/dev/null; then
            _msr_add_issue 1 "critical" "schema-integrity" "Prisma schema missing datasource block" "$prisma_schema"
        fi

        # Check for generator block
        if ! grep -q '^generator ' "$prisma_schema" 2>/dev/null; then
            _msr_add_issue 1 "major" "schema-integrity" "Prisma schema missing generator block" "$prisma_schema"
        fi
    fi

    # Calculate score
    MSR_SCORE_STAGE1=$(_msr_calculate_score "$MSR_ISSUES_STAGE1")

    if (( MSR_SCORE_STAGE1 >= MSR_THRESHOLD_STAGE1 )); then
        _msr_success "Stage 1 Structural: ${MSR_SCORE_STAGE1}/100 (threshold: ${MSR_THRESHOLD_STAGE1})"
        return 0
    else
        _msr_error "Stage 1 Structural: ${MSR_SCORE_STAGE1}/100 (threshold: ${MSR_THRESHOLD_STAGE1})"
        return 1
    fi
}

# =============================================================================
# 4. msr_stage2_semantic(project_dir) - Semantic Correctness
# =============================================================================
msr_stage2_semantic() {
    local project_dir="${1:-.}"
    _msr_stage "2/4: Semantic Correctness (weight: ${MSR_WEIGHT_STAGE2}%)"

    if [[ ! -d "$project_dir" ]]; then
        _msr_log_error "msr-s2: Project directory does not exist: $project_dir"
        MSR_SCORE_STAGE2=0
        return 1
    fi

    MSR_ISSUES_STAGE2=""

    local ts_files
    ts_files=$(find "$project_dir" -type f \( -name '*.ts' -o -name '*.tsx' \) \
        -not -path '*/node_modules/*' -not -path '*/.next/*' -not -path '*/dist/*' 2>/dev/null)

    # ---- 2a. Type safety: No `any` types ----
    _msr_log "S2: Checking type safety..."
    local any_count=0
    if [[ -n "$ts_files" ]]; then
        # Count explicit `any` type annotations (excluding comments and strings)
        any_count=$(echo "$ts_files" | xargs grep -n ':\s*any\b\|<any>' 2>/dev/null \
            | grep -v '^\s*//' | grep -v '^\s*\*' | grep -v 'eslint-disable' | wc -l)
        any_count=$(echo "$any_count" | tr -d ' ')

        if (( any_count > 10 )); then
            _msr_add_issue 2 "critical" "type-safety" "Excessive 'any' usage: $any_count occurrences across codebase" ""
        elif (( any_count > 5 )); then
            _msr_add_issue 2 "major" "type-safety" "'any' type found $any_count times - should use proper types" ""
        elif (( any_count > 0 )); then
            _msr_add_issue 2 "minor" "type-safety" "'any' type found $any_count times" ""
        fi

        # Check for @ts-ignore / @ts-nocheck
        local ts_ignore_count
        ts_ignore_count=$(echo "$ts_files" | xargs grep -c '@ts-ignore\|@ts-nocheck' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')
        if (( ts_ignore_count > 3 )); then
            _msr_add_issue 2 "major" "type-safety" "@ts-ignore/@ts-nocheck found $ts_ignore_count times - weakens type checking" ""
        elif (( ts_ignore_count > 0 )); then
            _msr_add_issue 2 "minor" "type-safety" "@ts-ignore/@ts-nocheck found $ts_ignore_count times" ""
        fi
    fi

    # ---- 2b. API contract validation ----
    _msr_log "S2: Checking API contracts..."
    local api_dir=""
    [[ -d "$project_dir/app/api" ]] && api_dir="$project_dir/app/api"
    [[ -d "$project_dir/pages/api" ]] && api_dir="$project_dir/pages/api"
    [[ -d "$project_dir/src/app/api" ]] && api_dir="$project_dir/src/app/api"

    if [[ -n "$api_dir" ]]; then
        local api_routes
        api_routes=$(find "$api_dir" -type f \( -name 'route.ts' -o -name 'route.tsx' -o -name '*.ts' \) 2>/dev/null)

        while IFS= read -r api_file; do
            [[ -z "$api_file" ]] && continue

            # Check that API handlers return proper Response objects or use NextResponse
            if ! grep -qE 'NextResponse|Response|res\.json|res\.status|res\.send' "$api_file" 2>/dev/null; then
                local rel_path="${api_file#$project_dir/}"
                _msr_add_issue 2 "major" "api-contract" "API route has no clear response handling" "$rel_path"
            fi

            # Check that POST/PUT/PATCH handlers validate request body
            if grep -qE 'export\s+(async\s+)?function\s+(POST|PUT|PATCH)\b|method.*POST|method.*PUT' "$api_file" 2>/dev/null; then
                if ! grep -qE 'zod|z\.\|schema\.parse|validate|body\.parse|safeParse|req\.body' "$api_file" 2>/dev/null; then
                    local rel_path="${api_file#$project_dir/}"
                    _msr_add_issue 2 "major" "api-contract" "Mutation endpoint lacks request body validation" "$rel_path"
                fi
            fi
        done <<< "$api_routes"
    fi

    # ---- 2c. Database integrity ----
    _msr_log "S2: Checking database operation integrity..."
    if [[ -n "$ts_files" ]]; then
        # Find files with multiple DB operations that should use transactions
        local db_files
        db_files=$(echo "$ts_files" | xargs grep -l 'prisma\.\|db\.\|supabase\.' 2>/dev/null | head -50)

        while IFS= read -r db_file; do
            [[ -z "$db_file" ]] && continue
            local rel_path="${db_file#$project_dir/}"

            # Count separate DB operations in the same function scope
            local create_count update_count delete_count
            create_count=$(grep -c '\.create\b\|\.createMany\b' "$db_file" 2>/dev/null || echo 0)
            update_count=$(grep -c '\.update\b\|\.updateMany\b' "$db_file" 2>/dev/null || echo 0)
            delete_count=$(grep -c '\.delete\b\|\.deleteMany\b' "$db_file" 2>/dev/null || echo 0)

            local total_mutations=$(( create_count + update_count + delete_count ))

            # If more than 2 mutations in one file, check for transaction usage
            if (( total_mutations > 2 )); then
                if ! grep -qE '\$transaction|\btransaction\b|BEGIN|COMMIT' "$db_file" 2>/dev/null; then
                    _msr_add_issue 2 "major" "db-integrity" "Multiple DB mutations ($total_mutations) without transaction" "$rel_path"
                fi
            fi
        done <<< "$db_files"
    fi

    # ---- 2d. Auth flow validation ----
    _msr_log "S2: Checking authentication flow..."
    if [[ -n "$api_dir" ]]; then
        local unprotected_count=0
        local api_route_files
        api_route_files=$(find "$api_dir" -type f -name 'route.ts' -o -name 'route.tsx' 2>/dev/null)

        while IFS= read -r api_file; do
            [[ -z "$api_file" ]] && continue
            local rel_path="${api_file#$project_dir/}"

            # Skip public endpoints
            if echo "$rel_path" | grep -qiE 'auth/|login|register|signup|public|health|webhook'; then
                continue
            fi

            # Check if endpoint has auth check
            if ! grep -qE 'getServerSession|getSession|auth\(\)|currentUser|verifyToken|requireAuth|middleware|isAuthenticated|getToken|cookies' "$api_file" 2>/dev/null; then
                unprotected_count=$((unprotected_count + 1))
                if (( unprotected_count <= 5 )); then
                    _msr_add_issue 2 "critical" "auth-flow" "API route missing authentication check" "$rel_path"
                fi
            fi
        done <<< "$api_route_files"

        if (( unprotected_count > 5 )); then
            _msr_add_issue 2 "critical" "auth-flow" "Total $unprotected_count unprotected API routes found (showing first 5)" ""
        fi
    fi

    # Check protected pages (middleware or layout-level auth)
    local has_middleware=false
    [[ -f "$project_dir/middleware.ts" || -f "$project_dir/middleware.tsx" || -f "$project_dir/src/middleware.ts" ]] && has_middleware=true
    if [[ "$has_middleware" == false && -n "$api_dir" ]]; then
        _msr_add_issue 2 "major" "auth-flow" "No middleware.ts found for route protection" "$project_dir"
    fi

    # ---- 2e. Data flow validation (props, state) ----
    _msr_log "S2: Checking data flow patterns..."
    if [[ -n "$ts_files" ]]; then
        # Check for prop drilling (components passing through more than 5 props of same name)
        local tsx_files
        tsx_files=$(echo "$ts_files" | grep '\.tsx$' | head -80)

        while IFS= read -r tsx_file; do
            [[ -z "$tsx_file" ]] && continue
            local rel_path="${tsx_file#$project_dir/}"

            # Count inline props (heuristic: lines with many prop=value patterns)
            local props_per_component
            props_per_component=$(grep -oP '\w+=' "$tsx_file" 2>/dev/null | sort | uniq -c | sort -rn | head -1 | awk '{print $1}')
            if [[ -n "$props_per_component" ]] && (( props_per_component > 15 )); then
                _msr_add_issue 2 "minor" "data-flow" "Possible prop drilling: $props_per_component repeated prop patterns" "$rel_path"
            fi

            # Check for unsafe state mutation
            if grep -qE '\.push\(|\.splice\(|\.sort\(\)' "$tsx_file" 2>/dev/null; then
                if grep -qE 'useState|setState' "$tsx_file" 2>/dev/null; then
                    _msr_add_issue 2 "major" "data-flow" "Possible direct state mutation (.push/.splice/.sort)" "$rel_path"
                fi
            fi
        done <<< "$tsx_files"
    fi

    # Calculate score
    MSR_SCORE_STAGE2=$(_msr_calculate_score "$MSR_ISSUES_STAGE2")

    if (( MSR_SCORE_STAGE2 >= MSR_THRESHOLD_STAGE2 )); then
        _msr_success "Stage 2 Semantic: ${MSR_SCORE_STAGE2}/100 (threshold: ${MSR_THRESHOLD_STAGE2})"
        return 0
    else
        _msr_error "Stage 2 Semantic: ${MSR_SCORE_STAGE2}/100 (threshold: ${MSR_THRESHOLD_STAGE2})"
        return 1
    fi
}

# =============================================================================
# 5. msr_stage3_quality(project_dir) - Quality Standards
# =============================================================================
msr_stage3_quality() {
    local project_dir="${1:-.}"
    _msr_stage "3/4: Quality Standards (weight: ${MSR_WEIGHT_STAGE3}%)"

    if [[ ! -d "$project_dir" ]]; then
        _msr_log_error "msr-s3: Project directory does not exist: $project_dir"
        MSR_SCORE_STAGE3=0
        return 1
    fi

    MSR_ISSUES_STAGE3=""

    local ts_files
    ts_files=$(find "$project_dir" -type f \( -name '*.ts' -o -name '*.tsx' \) \
        -not -path '*/node_modules/*' -not -path '*/.next/*' -not -path '*/dist/*' 2>/dev/null)
    local tsx_files
    tsx_files=$(echo "$ts_files" | grep '\.tsx$')

    # ---- 3a. Code quality ----
    _msr_log "S3: Checking code quality..."
    if [[ -n "$ts_files" ]]; then
        # Console.log left in production code
        local console_logs
        console_logs=$(echo "$ts_files" | xargs grep -rn 'console\.log\b' 2>/dev/null \
            | grep -v '\.test\.\|\.spec\.\|__tests__\|__mocks__' | wc -l)
        console_logs=$(echo "$console_logs" | tr -d ' ')
        if (( console_logs > 10 )); then
            _msr_add_issue 3 "major" "code-quality" "Excessive console.log: $console_logs occurrences in production code" ""
        elif (( console_logs > 3 )); then
            _msr_add_issue 3 "minor" "code-quality" "console.log found $console_logs times in production code" ""
        fi

        # TODO/FIXME/HACK comments
        local todo_count
        todo_count=$(echo "$ts_files" | xargs grep -c 'TODO\|FIXME\|HACK\|XXX' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')
        if (( todo_count > 10 )); then
            _msr_add_issue 3 "major" "code-quality" "$todo_count TODO/FIXME/HACK comments - unresolved technical debt" ""
        elif (( todo_count > 3 )); then
            _msr_add_issue 3 "minor" "code-quality" "$todo_count TODO/FIXME/HACK comments found" ""
        fi

        # Magic numbers (numeric literals outside of common ones like 0, 1, -1, 100, 200, etc.)
        local magic_numbers
        magic_numbers=$(echo "$ts_files" | xargs grep -nP '(?<!\w)[2-9]\d{2,}(?!\w)' 2>/dev/null \
            | grep -v 'port\|PORT\|status\|width\|height\|padding\|margin\|size\|color\|#[0-9a-f]\|0x\|timeout\|delay\|duration\|interval' \
            | grep -v '\.test\.\|\.spec\.\|\.config\.' | wc -l)
        magic_numbers=$(echo "$magic_numbers" | tr -d ' ')
        if (( magic_numbers > 15 )); then
            _msr_add_issue 3 "major" "code-quality" "$magic_numbers suspected magic numbers - should use named constants" ""
        elif (( magic_numbers > 5 )); then
            _msr_add_issue 3 "minor" "code-quality" "$magic_numbers suspected magic numbers found" ""
        fi

        # Empty catch blocks
        local empty_catch
        empty_catch=$(echo "$ts_files" | xargs grep -cP 'catch\s*\([^)]*\)\s*\{\s*\}' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')
        if (( empty_catch > 0 )); then
            _msr_add_issue 3 "major" "code-quality" "$empty_catch empty catch block(s) - errors silently swallowed" ""
        fi

        # Functions over 100 lines (heuristic)
        local large_functions=0
        while IFS= read -r ts_file; do
            [[ -z "$ts_file" ]] && continue
            local line_count
            line_count=$(wc -l < "$ts_file" 2>/dev/null)
            if (( line_count > 300 )); then
                large_functions=$((large_functions + 1))
                if (( large_functions <= 3 )); then
                    local rel_path="${ts_file#$project_dir/}"
                    _msr_add_issue 3 "minor" "code-quality" "File exceeds 300 lines ($line_count lines) - consider splitting" "$rel_path"
                fi
            fi
        done <<< "$(echo "$ts_files" | head -100)"
    fi

    # ---- 3b. UX quality ----
    _msr_log "S3: Checking UX quality..."
    if [[ -n "$tsx_files" ]]; then
        # Loading states
        local has_loading
        has_loading=$(echo "$tsx_files" | xargs grep -l 'isLoading\|loading\|Spinner\|Skeleton\|LoadingState\|Loader' 2>/dev/null | wc -l)
        has_loading=$(echo "$has_loading" | tr -d ' ')
        local total_pages
        total_pages=$(echo "$tsx_files" | grep -c 'page\.tsx$' 2>/dev/null || echo 0)
        if (( total_pages > 3 && has_loading < 2 )); then
            _msr_add_issue 3 "major" "ux-quality" "Few loading states found ($has_loading files) for $total_pages pages" ""
        fi

        # Error states
        local has_error_state
        has_error_state=$(echo "$tsx_files" | xargs grep -l 'isError\|error\s*&&\|ErrorBoundary\|error\.tsx\|ErrorState\|ErrorMessage' 2>/dev/null | wc -l)
        has_error_state=$(echo "$has_error_state" | tr -d ' ')
        if (( total_pages > 3 && has_error_state < 2 )); then
            _msr_add_issue 3 "major" "ux-quality" "Few error states found ($has_error_state files) for $total_pages pages" ""
        fi

        # Empty states
        local has_empty_state
        has_empty_state=$(echo "$tsx_files" | xargs grep -l 'EmptyState\|empty.*state\|no.*data\|No.*found\|length\s*===\s*0\|\.length\s*<\s*1' 2>/dev/null | wc -l)
        has_empty_state=$(echo "$has_empty_state" | tr -d ' ')
        if (( total_pages > 3 && has_empty_state < 1 )); then
            _msr_add_issue 3 "minor" "ux-quality" "No empty state handling detected for data lists" ""
        fi

        # alert() / confirm() / prompt() usage (should use UI modals)
        local alert_usage
        alert_usage=$(echo "$tsx_files" | xargs grep -c '\balert(\|confirm(\|prompt(' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')
        if (( alert_usage > 0 )); then
            _msr_add_issue 3 "major" "ux-quality" "$alert_usage native alert/confirm/prompt calls - should use UI modals" ""
        fi
    fi

    # ---- 3c. Test quality ----
    _msr_log "S3: Checking test quality..."
    local test_files
    test_files=$(find "$project_dir" -type f \( -name '*.test.ts' -o -name '*.test.tsx' -o -name '*.spec.ts' -o -name '*.spec.tsx' \) \
        -not -path '*/node_modules/*' 2>/dev/null)
    local test_count
    test_count=$(echo "$test_files" | grep -c '.' 2>/dev/null || echo 0)

    local source_count=0
    if [[ -n "$ts_files" ]]; then
        source_count=$(echo "$ts_files" | grep -v '\.test\.\|\.spec\.\|\.d\.ts' | wc -l)
        source_count=$(echo "$source_count" | tr -d ' ')
    fi

    if (( source_count > 10 && test_count == 0 )); then
        _msr_add_issue 3 "critical" "test-quality" "No test files found for $source_count source files" ""
    elif (( source_count > 10 && test_count < 3 )); then
        _msr_add_issue 3 "major" "test-quality" "Only $test_count test files for $source_count source files" ""
    fi

    # Check test assertions quality
    if [[ -n "$test_files" ]] && (( test_count > 0 )); then
        local assert_count
        assert_count=$(echo "$test_files" | xargs grep -c 'expect(\|assert\.\|should\.\|toBe\|toEqual\|toHaveBeenCalled' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')
        local avg_assertions=$(( assert_count / test_count ))
        if (( avg_assertions < 2 )); then
            _msr_add_issue 3 "major" "test-quality" "Low assertion density: avg $avg_assertions per test file" ""
        fi
    fi

    # ---- 3d. Documentation ----
    _msr_log "S3: Checking documentation..."
    if [[ -n "$ts_files" ]]; then
        # Count exported functions/components
        local exported_count
        exported_count=$(echo "$ts_files" | xargs grep -c '^export\s\|^export default' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')

        # Count JSDoc comments
        local jsdoc_count
        jsdoc_count=$(echo "$ts_files" | xargs grep -c '/\*\*' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')

        if (( exported_count > 20 && jsdoc_count < 5 )); then
            _msr_add_issue 3 "major" "documentation" "Low JSDoc coverage: $jsdoc_count docs for $exported_count exports" ""
        elif (( exported_count > 10 && jsdoc_count == 0 )); then
            _msr_add_issue 3 "major" "documentation" "No JSDoc comments found for $exported_count exports" ""
        fi
    fi

    # README check
    if [[ ! -f "$project_dir/README.md" && ! -f "$project_dir/readme.md" ]]; then
        _msr_add_issue 3 "minor" "documentation" "No README.md found" "$project_dir"
    fi

    # ---- 3e. Performance ----
    _msr_log "S3: Checking performance patterns..."
    if [[ -n "$ts_files" ]]; then
        # N+1 query detection: DB calls inside loops
        local n_plus_one_suspects=0
        while IFS= read -r ts_file; do
            [[ -z "$ts_file" ]] && continue
            # Look for patterns like: for/forEach/map followed by prisma/db calls
            if grep -qE '\.forEach\(|\.map\(|for\s*\(' "$ts_file" 2>/dev/null; then
                if grep -qE 'prisma\.\w+\.find|db\.\w+\.find|await.*\.get\(' "$ts_file" 2>/dev/null; then
                    # Rough heuristic: check if DB call appears after a loop in the same file
                    local loop_line db_line
                    loop_line=$(grep -nE '\.forEach\(|\.map\(|for\s*\(' "$ts_file" 2>/dev/null | head -1 | cut -d: -f1)
                    db_line=$(grep -nE 'prisma\.\w+\.find|db\.\w+\.find' "$ts_file" 2>/dev/null | head -1 | cut -d: -f1)
                    if [[ -n "$loop_line" && -n "$db_line" ]]; then
                        local diff=$(( db_line - loop_line ))
                        if (( diff > 0 && diff < 20 )); then
                            n_plus_one_suspects=$((n_plus_one_suspects + 1))
                            if (( n_plus_one_suspects <= 3 )); then
                                local rel_path="${ts_file#$project_dir/}"
                                _msr_add_issue 3 "major" "performance" "Possible N+1 query: DB call near loop" "$rel_path"
                            fi
                        fi
                    fi
                fi
            fi
        done <<< "$(echo "$ts_files" | head -80)"

        # Check for missing dynamic imports / lazy loading
        if [[ -n "$tsx_files" ]]; then
            local has_lazy
            has_lazy=$(echo "$tsx_files" | xargs grep -l 'React\.lazy\|dynamic(\|import(' 2>/dev/null | wc -l)
            has_lazy=$(echo "$has_lazy" | tr -d ' ')
            local component_files
            component_files=$(echo "$tsx_files" | grep -v 'page\.\|layout\.\|\.test\.\|\.spec\.' | wc -l)
            component_files=$(echo "$component_files" | tr -d ' ')
            if (( component_files > 20 && has_lazy == 0 )); then
                _msr_add_issue 3 "minor" "performance" "No lazy loading found for $component_files components" ""
            fi
        fi

        # Unoptimized images (next/image vs <img>)
        if [[ -n "$tsx_files" ]]; then
            local raw_img_count
            raw_img_count=$(echo "$tsx_files" | xargs grep -c '<img ' 2>/dev/null \
                | awk -F: '{s+=$NF} END{print s+0}')
            if (( raw_img_count > 3 )); then
                _msr_add_issue 3 "minor" "performance" "$raw_img_count raw <img> tags - consider using next/image for optimization" ""
            fi
        fi
    fi

    # Calculate score
    MSR_SCORE_STAGE3=$(_msr_calculate_score "$MSR_ISSUES_STAGE3")

    if (( MSR_SCORE_STAGE3 >= MSR_THRESHOLD_STAGE3 )); then
        _msr_success "Stage 3 Quality: ${MSR_SCORE_STAGE3}/100 (threshold: ${MSR_THRESHOLD_STAGE3})"
        return 0
    else
        _msr_error "Stage 3 Quality: ${MSR_SCORE_STAGE3}/100 (threshold: ${MSR_THRESHOLD_STAGE3})"
        return 1
    fi
}

# =============================================================================
# 6. msr_stage4_completeness(project_dir, domain) - Completeness
# =============================================================================
msr_stage4_completeness() {
    local project_dir="${1:-.}"
    local domain="${2:-general}"
    _msr_stage "4/4: Completeness (weight: ${MSR_WEIGHT_STAGE4}%)"

    if [[ ! -d "$project_dir" ]]; then
        _msr_log_error "msr-s4: Project directory does not exist: $project_dir"
        MSR_SCORE_STAGE4=0
        return 1
    fi

    MSR_ISSUES_STAGE4=""

    local ts_files
    ts_files=$(find "$project_dir" -type f \( -name '*.ts' -o -name '*.tsx' \) \
        -not -path '*/node_modules/*' -not -path '*/.next/*' -not -path '*/dist/*' 2>/dev/null)
    local tsx_files
    tsx_files=$(echo "$ts_files" | grep '\.tsx$')

    # ---- 4a. Feature completeness (domain-based) ----
    _msr_log "S4: Checking feature completeness for domain: $domain"
    local domain_features=""
    case "$domain" in
        ecommerce|ec)
            domain_features="cart checkout product order payment user" ;;
        saas|dashboard)
            domain_features="auth dashboard settings billing user analytics" ;;
        blog|cms)
            domain_features="post category tag user comment media" ;;
        crm)
            domain_features="contact company deal pipeline activity user" ;;
        *)
            domain_features="auth user dashboard settings" ;;
    esac

    for feature in $domain_features; do
        local found=false
        # Check for feature presence in file names, directories, or code
        if find "$project_dir" -iname "*${feature}*" -not -path '*/node_modules/*' 2>/dev/null | head -1 | grep -q .; then
            found=true
        fi
        if [[ "$found" == false ]] && [[ -n "$ts_files" ]]; then
            if echo "$ts_files" | xargs grep -li "\b${feature}\b" 2>/dev/null | head -1 | grep -q .; then
                found=true
            fi
        fi
        if [[ "$found" == false ]]; then
            _msr_add_issue 4 "major" "feature-completeness" "Domain feature '$feature' not found in project" ""
        fi
    done

    # ---- 4b. CRUD completeness ----
    _msr_log "S4: Checking CRUD completeness..."
    local prisma_schema=""
    [[ -f "$project_dir/prisma/schema.prisma" ]] && prisma_schema="$project_dir/prisma/schema.prisma"
    [[ -f "$project_dir/schema.prisma" ]] && prisma_schema="$project_dir/schema.prisma"

    if [[ -n "$prisma_schema" ]]; then
        local models
        models=$(grep '^model ' "$prisma_schema" 2>/dev/null | awk '{print $2}')

        while IFS= read -r model; do
            [[ -z "$model" ]] && continue
            local model_lower
            model_lower=$(echo "$model" | tr '[:upper:]' '[:lower:]')

            # Check for API routes covering CRUD
            local has_create=false has_read=false has_update=false has_delete=false

            if [[ -n "$ts_files" ]]; then
                echo "$ts_files" | xargs grep -li "\.create\b.*${model}\|${model}.*\.create\b\|create.*${model_lower}" 2>/dev/null | head -1 | grep -q . && has_create=true
                echo "$ts_files" | xargs grep -li "\.find\b.*${model}\|${model}.*\.find\|findMany.*${model_lower}\|findUnique.*${model_lower}" 2>/dev/null | head -1 | grep -q . && has_read=true
                echo "$ts_files" | xargs grep -li "\.update\b.*${model}\|${model}.*\.update\b\|update.*${model_lower}" 2>/dev/null | head -1 | grep -q . && has_update=true
                echo "$ts_files" | xargs grep -li "\.delete\b.*${model}\|${model}.*\.delete\b\|delete.*${model_lower}" 2>/dev/null | head -1 | grep -q . && has_delete=true
            fi

            local missing_ops=""
            [[ "$has_create" == false ]] && missing_ops+="Create "
            [[ "$has_read" == false ]] && missing_ops+="Read "
            [[ "$has_update" == false ]] && missing_ops+="Update "
            [[ "$has_delete" == false ]] && missing_ops+="Delete "

            if [[ -n "$missing_ops" ]]; then
                local missing_count
                missing_count=$(echo "$missing_ops" | wc -w)
                missing_count=$(echo "$missing_count" | tr -d ' ')
                if (( missing_count >= 3 )); then
                    _msr_add_issue 4 "major" "crud-completeness" "Model '$model' missing CRUD ops: $missing_ops" "$prisma_schema"
                elif (( missing_count >= 1 )); then
                    _msr_add_issue 4 "minor" "crud-completeness" "Model '$model' missing: $missing_ops" "$prisma_schema"
                fi
            fi
        done <<< "$models"
    fi

    # ---- 4c. Edge case handling ----
    _msr_log "S4: Checking edge case handling..."
    if [[ -n "$tsx_files" ]]; then
        # Check for null/undefined guards
        local null_guard_count
        null_guard_count=$(echo "$tsx_files" | xargs grep -c '\?\.\|??\|!=\s*null\|!==\s*null\|!==\s*undefined' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')
        local tsx_count
        tsx_count=$(echo "$tsx_files" | wc -l)
        tsx_count=$(echo "$tsx_count" | tr -d ' ')

        if (( tsx_count > 10 && null_guard_count < 5 )); then
            _msr_add_issue 4 "major" "edge-cases" "Very few null/undefined guards ($null_guard_count) across $tsx_count TSX files" ""
        fi

        # Check for empty array handling
        local empty_arr_handling
        empty_arr_handling=$(echo "$tsx_files" | xargs grep -c '\.length\s*[=!><]\|Array\.isArray\|isEmpty\b' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')
        if (( tsx_count > 10 && empty_arr_handling < 3 )); then
            _msr_add_issue 4 "minor" "edge-cases" "Few empty array checks ($empty_arr_handling) across $tsx_count TSX files" ""
        fi
    fi

    # ---- 4d. Error recovery ----
    _msr_log "S4: Checking error recovery patterns..."
    if [[ -n "$ts_files" ]]; then
        # Files with fetch/axios calls
        local api_caller_files
        api_caller_files=$(echo "$ts_files" | xargs grep -l 'fetch(\|axios\.\|useSWR\|useQuery' 2>/dev/null | head -30)
        local api_caller_count=0
        local unhandled_count=0

        while IFS= read -r caller_file; do
            [[ -z "$caller_file" ]] && continue
            api_caller_count=$((api_caller_count + 1))

            # Check for try-catch or .catch() around API calls
            if ! grep -qE 'try\s*\{|\.catch\(|onError|error.*=>' "$caller_file" 2>/dev/null; then
                unhandled_count=$((unhandled_count + 1))
                if (( unhandled_count <= 3 )); then
                    local rel_path="${caller_file#$project_dir/}"
                    _msr_add_issue 4 "major" "error-recovery" "API calls without error handling" "$rel_path"
                fi
            fi
        done <<< "$api_caller_files"

        if (( unhandled_count > 3 )); then
            _msr_add_issue 4 "major" "error-recovery" "Total $unhandled_count files with unhandled API errors" ""
        fi

        # Check for retry logic on critical operations
        local has_retry
        has_retry=$(echo "$ts_files" | xargs grep -l 'retry\|retries\|maxRetries\|attempts' 2>/dev/null | wc -l)
        has_retry=$(echo "$has_retry" | tr -d ' ')
        if (( api_caller_count > 5 && has_retry == 0 )); then
            _msr_add_issue 4 "minor" "error-recovery" "No retry logic found for $api_caller_count API caller files" ""
        fi
    fi

    # ---- 4e. Accessibility ----
    _msr_log "S4: Checking accessibility..."
    if [[ -n "$tsx_files" ]]; then
        # ARIA labels
        local aria_count
        aria_count=$(echo "$tsx_files" | xargs grep -c 'aria-label\|aria-labelledby\|aria-describedby\|aria-live\|aria-hidden' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')

        local interactive_elements
        interactive_elements=$(echo "$tsx_files" | xargs grep -c '<button\|<input\|<select\|<textarea\|onClick\|onSubmit' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')

        if (( interactive_elements > 20 && aria_count < 5 )); then
            _msr_add_issue 4 "major" "accessibility" "Low ARIA coverage: $aria_count labels for ~$interactive_elements interactive elements" ""
        elif (( interactive_elements > 10 && aria_count == 0 )); then
            _msr_add_issue 4 "major" "accessibility" "No ARIA attributes found for $interactive_elements interactive elements" ""
        fi

        # Keyboard navigation (tabIndex, onKeyDown/onKeyUp)
        local keyboard_nav
        keyboard_nav=$(echo "$tsx_files" | xargs grep -c 'tabIndex\|onKeyDown\|onKeyUp\|onKeyPress\|role=' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')
        if (( interactive_elements > 15 && keyboard_nav < 3 )); then
            _msr_add_issue 4 "minor" "accessibility" "Low keyboard navigation support: $keyboard_nav handlers for ~$interactive_elements interactive elements" ""
        fi

        # Alt text on images
        local img_tags
        img_tags=$(echo "$tsx_files" | xargs grep -c '<img\b\|<Image\b' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')
        local img_with_alt
        img_with_alt=$(echo "$tsx_files" | xargs grep -oP '<(?:img|Image)\b[^>]*alt=' 2>/dev/null | wc -l)
        img_with_alt=$(echo "$img_with_alt" | tr -d ' ')
        if (( img_tags > 0 && img_with_alt < img_tags )); then
            local missing_alt=$(( img_tags - img_with_alt ))
            _msr_add_issue 4 "major" "accessibility" "$missing_alt image(s) missing alt text" ""
        fi

        # Screen reader: sr-only class usage
        local sr_only_count
        sr_only_count=$(echo "$tsx_files" | xargs grep -c 'sr-only\|visually-hidden\|VisuallyHidden' 2>/dev/null \
            | awk -F: '{s+=$NF} END{print s+0}')
        if (( interactive_elements > 20 && sr_only_count == 0 )); then
            _msr_add_issue 4 "minor" "accessibility" "No screen-reader-only text found (sr-only/visually-hidden)" ""
        fi
    fi

    # Calculate score
    MSR_SCORE_STAGE4=$(_msr_calculate_score "$MSR_ISSUES_STAGE4")

    if (( MSR_SCORE_STAGE4 >= MSR_THRESHOLD_STAGE4 )); then
        _msr_success "Stage 4 Completeness: ${MSR_SCORE_STAGE4}/100 (threshold: ${MSR_THRESHOLD_STAGE4})"
        return 0
    else
        _msr_error "Stage 4 Completeness: ${MSR_SCORE_STAGE4}/100 (threshold: ${MSR_THRESHOLD_STAGE4})"
        return 1
    fi
}

# =============================================================================
# 2. msr_run_pipeline(project_dir, domain) - Execute full 4-stage pipeline
# =============================================================================
msr_run_pipeline() {
    local project_dir="${1:-.}"
    local domain="${2:-general}"

    [[ "$MSR_INITIALIZED" != true ]] && msr_init

    _msr_log "========================================================"
    _msr_log "Multi-Stage Review Pipeline v${MSR_VERSION}"
    _msr_log "Project: $project_dir"
    _msr_log "Domain:  $domain"
    _msr_log "========================================================"

    local start_time
    start_time=$(date +%s)

    # Stage 1: Structural Validation
    local s1_passed=false
    msr_stage1_structural "$project_dir" && s1_passed=true
    if [[ "$s1_passed" == false ]]; then
        _msr_log_warn "msr: Pipeline HALTED at Stage 1 - structural issues must be resolved first"
        _msr_compute_weighted_total
        _msr_update_stats false
        MSR_PIPELINE_PASSED=false
        msr_generate_report
        return 1
    fi

    # Stage 2: Semantic Correctness
    local s2_passed=false
    msr_stage2_semantic "$project_dir" && s2_passed=true
    if [[ "$s2_passed" == false ]]; then
        _msr_log_warn "msr: Pipeline HALTED at Stage 2 - semantic issues must be resolved first"
        _msr_compute_weighted_total
        _msr_update_stats false
        MSR_PIPELINE_PASSED=false
        msr_generate_report
        return 1
    fi

    # Stage 3: Quality Standards
    local s3_passed=false
    msr_stage3_quality "$project_dir" && s3_passed=true
    if [[ "$s3_passed" == false ]]; then
        _msr_log_warn "msr: Pipeline HALTED at Stage 3 - quality standards not met"
        _msr_compute_weighted_total
        _msr_update_stats false
        MSR_PIPELINE_PASSED=false
        msr_generate_report
        return 1
    fi

    # Stage 4: Completeness
    local s4_passed=false
    msr_stage4_completeness "$project_dir" "$domain" && s4_passed=true

    _msr_compute_weighted_total

    local end_time
    end_time=$(date +%s)
    local duration=$(( end_time - start_time ))

    if [[ "$s4_passed" == true ]]; then
        MSR_PIPELINE_PASSED=true
        _msr_update_stats true
        _msr_log "========================================================"
        _msr_success "ALL STAGES PASSED - Weighted Score: ${MSR_WEIGHTED_TOTAL}/100 (${duration}s)"
        _msr_log "========================================================"
    else
        MSR_PIPELINE_PASSED=false
        _msr_update_stats false
        _msr_log "========================================================"
        _msr_error "Stage 4 failed - Weighted Score: ${MSR_WEIGHTED_TOTAL}/100 (${duration}s)"
        _msr_log "========================================================"
    fi

    msr_generate_report
    return $([[ "$MSR_PIPELINE_PASSED" == true ]] && echo 0 || echo 1)
}

# =============================================================================
# Internal: compute weighted total score
# =============================================================================
_msr_compute_weighted_total() {
    MSR_WEIGHTED_TOTAL=$(( \
        (MSR_SCORE_STAGE1 * MSR_WEIGHT_STAGE1 + \
         MSR_SCORE_STAGE2 * MSR_WEIGHT_STAGE2 + \
         MSR_SCORE_STAGE3 * MSR_WEIGHT_STAGE3 + \
         MSR_SCORE_STAGE4 * MSR_WEIGHT_STAGE4) / 100 ))
}

# =============================================================================
# Internal: update session statistics
# =============================================================================
_msr_update_stats() {
    local passed="$1"
    MSR_STAT_TOTAL_RUNS=$(( MSR_STAT_TOTAL_RUNS + 1 ))
    if [[ "$passed" == true ]]; then
        MSR_STAT_PASS_COUNT=$(( MSR_STAT_PASS_COUNT + 1 ))
    else
        MSR_STAT_FAIL_COUNT=$(( MSR_STAT_FAIL_COUNT + 1 ))
    fi
    MSR_STAT_S1_SUM=$(( MSR_STAT_S1_SUM + MSR_SCORE_STAGE1 ))
    MSR_STAT_S2_SUM=$(( MSR_STAT_S2_SUM + MSR_SCORE_STAGE2 ))
    MSR_STAT_S3_SUM=$(( MSR_STAT_S3_SUM + MSR_SCORE_STAGE3 ))
    MSR_STAT_S4_SUM=$(( MSR_STAT_S4_SUM + MSR_SCORE_STAGE4 ))

    # Track common failure reasons
    local all_issues="${MSR_ISSUES_STAGE1}${MSR_ISSUES_STAGE2}${MSR_ISSUES_STAGE3}${MSR_ISSUES_STAGE4}"
    if [[ -n "$all_issues" ]]; then
        local top_category
        top_category=$(echo "$all_issues" | awk -F'|' '{print $2}' | sort | uniq -c | sort -rn | head -1 | awk '{print $2}')
        if [[ -n "$top_category" ]]; then
            MSR_STAT_COMMON_FAILURES="${MSR_STAT_COMMON_FAILURES:+${MSR_STAT_COMMON_FAILURES},}${top_category}"
        fi
    fi
}

# =============================================================================
# 7. msr_generate_fix_instructions(stage_results) - Generate fixes
# =============================================================================
msr_generate_fix_instructions() {
    local stage_filter="${1:-all}"  # all, 1, 2, 3, 4

    _msr_log "Generating fix instructions..."

    local fix_count=0
    local output=""

    output+="$(printf '=%.0s' {1..60})"$'\n'
    output+="  FIX INSTRUCTIONS (prioritized by impact)"$'\n'
    output+="$(printf '=%.0s' {1..60})"$'\n\n'

    # Collect all issues, sorted by weighted impact
    # impact = stage_weight * severity_multiplier
    # severity: critical=3, major=2, minor=1
    local all_issues=""

    if [[ "$stage_filter" == "all" || "$stage_filter" == "1" ]]; then
        if [[ -n "$MSR_ISSUES_STAGE1" ]]; then
            while IFS= read -r issue; do
                [[ -z "$issue" ]] && continue
                all_issues+="S1|${MSR_WEIGHT_STAGE1}|${issue}"$'\n'
            done <<< "$MSR_ISSUES_STAGE1"
        fi
    fi

    if [[ "$stage_filter" == "all" || "$stage_filter" == "2" ]]; then
        if [[ -n "$MSR_ISSUES_STAGE2" ]]; then
            while IFS= read -r issue; do
                [[ -z "$issue" ]] && continue
                all_issues+="S2|${MSR_WEIGHT_STAGE2}|${issue}"$'\n'
            done <<< "$MSR_ISSUES_STAGE2"
        fi
    fi

    if [[ "$stage_filter" == "all" || "$stage_filter" == "3" ]]; then
        if [[ -n "$MSR_ISSUES_STAGE3" ]]; then
            while IFS= read -r issue; do
                [[ -z "$issue" ]] && continue
                all_issues+="S3|${MSR_WEIGHT_STAGE3}|${issue}"$'\n'
            done <<< "$MSR_ISSUES_STAGE3"
        fi
    fi

    if [[ "$stage_filter" == "all" || "$stage_filter" == "4" ]]; then
        if [[ -n "$MSR_ISSUES_STAGE4" ]]; then
            while IFS= read -r issue; do
                [[ -z "$issue" ]] && continue
                all_issues+="S4|${MSR_WEIGHT_STAGE4}|${issue}"$'\n'
            done <<< "$MSR_ISSUES_STAGE4"
        fi
    fi

    if [[ -z "$all_issues" ]]; then
        output+="  No issues found - all stages clean."$'\n'
        echo "$output"
        return 0
    fi

    # Sort by impact: compute impact score and sort descending
    local sorted_issues
    sorted_issues=$(echo "$all_issues" | while IFS='|' read -r stage weight severity category message file; do
        local sev_mult=1
        case "$severity" in
            critical) sev_mult=3 ;;
            major)    sev_mult=2 ;;
            minor)    sev_mult=1 ;;
        esac
        local impact=$(( weight * sev_mult ))
        printf '%03d|%s|%s|%s|%s|%s|%s\n' "$impact" "$stage" "$severity" "$category" "$message" "$file" "$weight"
    done | sort -t'|' -k1 -rn)

    # Generate fix instructions per issue
    while IFS='|' read -r impact stage severity category message file weight; do
        [[ -z "$impact" ]] && continue
        fix_count=$((fix_count + 1))

        local priority_label="LOW"
        local impact_num=$((10#$impact))
        (( impact_num >= 80 )) && priority_label="CRITICAL"
        (( impact_num >= 40 && impact_num < 80 )) && priority_label="HIGH"
        (( impact_num >= 20 && impact_num < 40 )) && priority_label="MEDIUM"

        output+="  [$priority_label] #${fix_count} (${stage}, impact:${impact_num})"$'\n'
        output+="    Category: ${category}"$'\n'
        output+="    Issue:    ${message}"$'\n'
        [[ -n "$file" ]] && output+="    File:     ${file}"$'\n'

        # Generate fix suggestion based on category
        case "$category" in
            dir-structure)
                output+="    Fix:      Create missing directory structure. Run: mkdir -p <path>"$'\n' ;;
            circular-import)
                output+="    Fix:      Break the cycle by extracting shared types into a separate types.ts file"$'\n'
                output+="    Pattern:  Move shared interfaces to lib/types/ and import from there"$'\n' ;;
            missing-import)
                output+="    Fix:      Verify the import path or create the missing module file"$'\n' ;;
            route-incomplete)
                output+="    Fix:      Add a page.tsx with default export to the route directory"$'\n'
                output+="    Pattern:  export default function Page() { return <div>...</div> }"$'\n' ;;
            config-*)
                output+="    Fix:      Update the configuration file to include required fields"$'\n' ;;
            schema-integrity)
                output+="    Fix:      Add missing fields to the Prisma schema model"$'\n'
                output+="    Pattern:  id String @id @default(cuid()); createdAt DateTime @default(now()); updatedAt DateTime @updatedAt"$'\n' ;;
            type-safety)
                output+="    Fix:      Replace 'any' with proper TypeScript types. Use 'unknown' if the type is truly unknown."$'\n'
                output+="    Pattern:  Define interfaces in types.ts and use them consistently"$'\n' ;;
            api-contract)
                output+="    Fix:      Add Zod schema validation for request bodies. Return typed Response."$'\n'
                output+="    Pattern:  const schema = z.object({...}); const body = schema.parse(await req.json());"$'\n' ;;
            db-integrity)
                output+="    Fix:      Wrap related DB mutations in prisma.\$transaction()"$'\n'
                output+="    Pattern:  await prisma.\$transaction([prisma.model.create(...), prisma.other.update(...)])"$'\n' ;;
            auth-flow)
                output+="    Fix:      Add auth check at the top of the route handler"$'\n'
                output+="    Pattern:  const session = await getServerSession(authOptions); if (!session) return new Response('Unauthorized', {status:401});"$'\n' ;;
            data-flow)
                output+="    Fix:      Use immutable state updates. Replace .push() with spread operator."$'\n'
                output+="    Pattern:  setState(prev => [...prev, newItem]) instead of state.push(newItem)"$'\n' ;;
            code-quality)
                output+="    Fix:      Address code quality issue. Remove console.log, extract constants, handle errors."$'\n' ;;
            ux-quality)
                output+="    Fix:      Add UI states for loading/error/empty. Replace alert() with modal components."$'\n'
                output+="    Pattern:  {isLoading ? <Skeleton /> : data.length === 0 ? <EmptyState /> : <DataList />}"$'\n' ;;
            test-quality)
                output+="    Fix:      Add tests for critical paths. Use @testing-library/react for component tests."$'\n'
                output+="    Pattern:  describe('Component', () => { it('renders correctly', () => { expect(...).toBeInTheDocument() }) })"$'\n' ;;
            documentation)
                output+="    Fix:      Add JSDoc comments on exported functions and components"$'\n'
                output+="    Pattern:  /** @description Brief description @param name - desc @returns desc */"$'\n' ;;
            performance)
                output+="    Fix:      Optimize data fetching. Use include/select in Prisma queries. Add React.lazy for large components."$'\n' ;;
            feature-completeness)
                output+="    Fix:      Implement the missing domain feature with full UI + API + DB integration"$'\n' ;;
            crud-completeness)
                output+="    Fix:      Add missing CRUD API routes and corresponding UI forms/tables"$'\n' ;;
            edge-cases)
                output+="    Fix:      Add null checks with optional chaining (?.) and nullish coalescing (??)"$'\n' ;;
            error-recovery)
                output+="    Fix:      Wrap API calls in try-catch. Add user-friendly error messages."$'\n'
                output+="    Pattern:  try { const res = await fetch(...); if(!res.ok) throw new Error(); } catch(e) { toast.error('...'); }"$'\n' ;;
            accessibility)
                output+="    Fix:      Add ARIA attributes, keyboard handlers, and alt text to interactive elements"$'\n'
                output+="    Pattern:  <button aria-label=\"Close dialog\" onKeyDown={handleKeyDown}>...</button>"$'\n' ;;
            *)
                output+="    Fix:      Review and resolve the reported issue"$'\n' ;;
        esac
        output+=""$'\n'
    done <<< "$sorted_issues"

    output+="$(printf '-%.0s' {1..60})"$'\n'
    output+="  Total fixes: ${fix_count}"$'\n'

    echo "$output"
    return 0
}

# =============================================================================
# 8. msr_retry_failed_stages(project_dir, domain, previous_results) - Retry
# =============================================================================
msr_retry_failed_stages() {
    local project_dir="${1:-.}"
    local domain="${2:-general}"
    local previous_s1="${3:-$MSR_SCORE_STAGE1}"
    local previous_s2="${4:-$MSR_SCORE_STAGE2}"
    local previous_s3="${5:-$MSR_SCORE_STAGE3}"
    local previous_s4="${6:-$MSR_SCORE_STAGE4}"

    MSR_STAT_TOTAL_RETRIES=$(( MSR_STAT_TOTAL_RETRIES + 1 ))

    _msr_log "========================================================"
    _msr_log "RETRY RUN #${MSR_STAT_TOTAL_RETRIES} - Re-checking failed stages"
    _msr_log "========================================================"

    local all_passed=true

    # Re-run Stage 1 if it previously failed
    if (( previous_s1 < MSR_THRESHOLD_STAGE1 )); then
        _msr_log "Retrying Stage 1 (previous: ${previous_s1})..."
        if msr_stage1_structural "$project_dir"; then
            local delta=$(( MSR_SCORE_STAGE1 - previous_s1 ))
            _msr_success "Stage 1 improved: ${previous_s1} -> ${MSR_SCORE_STAGE1} (+${delta})"
        else
            all_passed=false
            local delta=$(( MSR_SCORE_STAGE1 - previous_s1 ))
            _msr_error "Stage 1 still failing: ${previous_s1} -> ${MSR_SCORE_STAGE1} (delta: ${delta})"
        fi
    else
        _msr_log "Stage 1 already passed (${previous_s1}) - skipping"
        MSR_SCORE_STAGE1="$previous_s1"
    fi

    # Re-run Stage 2 if it previously failed (and Stage 1 now passes)
    if (( MSR_SCORE_STAGE1 >= MSR_THRESHOLD_STAGE1 )); then
        if (( previous_s2 < MSR_THRESHOLD_STAGE2 )); then
            _msr_log "Retrying Stage 2 (previous: ${previous_s2})..."
            if msr_stage2_semantic "$project_dir"; then
                local delta=$(( MSR_SCORE_STAGE2 - previous_s2 ))
                _msr_success "Stage 2 improved: ${previous_s2} -> ${MSR_SCORE_STAGE2} (+${delta})"
            else
                all_passed=false
                local delta=$(( MSR_SCORE_STAGE2 - previous_s2 ))
                _msr_error "Stage 2 still failing: ${previous_s2} -> ${MSR_SCORE_STAGE2} (delta: ${delta})"
            fi
        else
            _msr_log "Stage 2 already passed (${previous_s2}) - skipping"
            MSR_SCORE_STAGE2="$previous_s2"
        fi
    else
        all_passed=false
        _msr_warn "Stage 2 skipped - Stage 1 still failing"
        MSR_SCORE_STAGE2="$previous_s2"
    fi

    # Re-run Stage 3 if it previously failed (and Stages 1-2 pass)
    if (( MSR_SCORE_STAGE1 >= MSR_THRESHOLD_STAGE1 && MSR_SCORE_STAGE2 >= MSR_THRESHOLD_STAGE2 )); then
        if (( previous_s3 < MSR_THRESHOLD_STAGE3 )); then
            _msr_log "Retrying Stage 3 (previous: ${previous_s3})..."
            if msr_stage3_quality "$project_dir"; then
                local delta=$(( MSR_SCORE_STAGE3 - previous_s3 ))
                _msr_success "Stage 3 improved: ${previous_s3} -> ${MSR_SCORE_STAGE3} (+${delta})"
            else
                all_passed=false
                local delta=$(( MSR_SCORE_STAGE3 - previous_s3 ))
                _msr_error "Stage 3 still failing: ${previous_s3} -> ${MSR_SCORE_STAGE3} (delta: ${delta})"
            fi
        else
            _msr_log "Stage 3 already passed (${previous_s3}) - skipping"
            MSR_SCORE_STAGE3="$previous_s3"
        fi
    else
        all_passed=false
        _msr_warn "Stage 3 skipped - earlier stages still failing"
        MSR_SCORE_STAGE3="$previous_s3"
    fi

    # Re-run Stage 4 if it previously failed (and Stages 1-3 pass)
    if (( MSR_SCORE_STAGE1 >= MSR_THRESHOLD_STAGE1 && MSR_SCORE_STAGE2 >= MSR_THRESHOLD_STAGE2 && MSR_SCORE_STAGE3 >= MSR_THRESHOLD_STAGE3 )); then
        if (( previous_s4 < MSR_THRESHOLD_STAGE4 )); then
            _msr_log "Retrying Stage 4 (previous: ${previous_s4})..."
            if msr_stage4_completeness "$project_dir" "$domain"; then
                local delta=$(( MSR_SCORE_STAGE4 - previous_s4 ))
                _msr_success "Stage 4 improved: ${previous_s4} -> ${MSR_SCORE_STAGE4} (+${delta})"
            else
                all_passed=false
                local delta=$(( MSR_SCORE_STAGE4 - previous_s4 ))
                _msr_error "Stage 4 still failing: ${previous_s4} -> ${MSR_SCORE_STAGE4} (delta: ${delta})"
            fi
        else
            _msr_log "Stage 4 already passed (${previous_s4}) - skipping"
            MSR_SCORE_STAGE4="$previous_s4"
        fi
    else
        all_passed=false
        _msr_warn "Stage 4 skipped - earlier stages still failing"
        MSR_SCORE_STAGE4="$previous_s4"
    fi

    _msr_compute_weighted_total

    if [[ "$all_passed" == true ]]; then
        MSR_PIPELINE_PASSED=true
        _msr_update_stats true
        _msr_success "RETRY PASSED - Weighted Score: ${MSR_WEIGHTED_TOTAL}/100"
    else
        MSR_PIPELINE_PASSED=false
        _msr_update_stats false
        _msr_error "RETRY INCOMPLETE - Weighted Score: ${MSR_WEIGHTED_TOTAL}/100"
    fi

    msr_generate_report
    return $([[ "$all_passed" == true ]] && echo 0 || echo 1)
}

# =============================================================================
# 9. msr_generate_report(all_results) - Generate ASCII report
# =============================================================================
msr_generate_report() {
    local report=""

    report+=""$'\n'
    report+="$(printf '=%.0s' {1..62})"$'\n'
    report+="  MULTI-STAGE REVIEW REPORT v${MSR_VERSION}"$'\n'
    report+="$(printf '=%.0s' {1..62})"$'\n'
    report+=""$'\n'

    # Pass/Fail status
    if [[ "$MSR_PIPELINE_PASSED" == true ]]; then
        report+="  Result:  PASSED"$'\n'
    else
        report+="  Result:  FAILED"$'\n'
    fi
    report+="  Weighted Score: ${MSR_WEIGHTED_TOTAL}/100"$'\n'
    report+=""$'\n'

    # Score breakdown table
    report+="  $(printf '+-%-12s-+-%-7s-+-%-11s-+-%-8s-+' '------------' '-------' '-----------' '--------')"$'\n'
    report+="  $(printf '| %-12s | %-7s | %-11s | %-8s |' 'Stage' 'Score' 'Threshold' 'Status')"$'\n'
    report+="  $(printf '+-%-12s-+-%-7s-+-%-11s-+-%-8s-+' '------------' '-------' '-----------' '--------')"$'\n'

    local s1_status="PASS" s2_status="PASS" s3_status="PASS" s4_status="PASS"
    (( MSR_SCORE_STAGE1 < MSR_THRESHOLD_STAGE1 )) && s1_status="FAIL"
    (( MSR_SCORE_STAGE2 < MSR_THRESHOLD_STAGE2 )) && s2_status="FAIL"
    (( MSR_SCORE_STAGE3 < MSR_THRESHOLD_STAGE3 )) && s3_status="FAIL"
    (( MSR_SCORE_STAGE4 < MSR_THRESHOLD_STAGE4 )) && s4_status="FAIL"

    report+="  $(printf '| %-12s | %3d/100 | %-11s | %-8s |' '1.Structural' "$MSR_SCORE_STAGE1" ">=${MSR_THRESHOLD_STAGE1}" "$s1_status")"$'\n'
    report+="  $(printf '| %-12s | %3d/100 | %-11s | %-8s |' '2.Semantic' "$MSR_SCORE_STAGE2" ">=${MSR_THRESHOLD_STAGE2}" "$s2_status")"$'\n'
    report+="  $(printf '| %-12s | %3d/100 | %-11s | %-8s |' '3.Quality' "$MSR_SCORE_STAGE3" ">=${MSR_THRESHOLD_STAGE3}" "$s3_status")"$'\n'
    report+="  $(printf '| %-12s | %3d/100 | %-11s | %-8s |' '4.Complete' "$MSR_SCORE_STAGE4" ">=${MSR_THRESHOLD_STAGE4}" "$s4_status")"$'\n'

    report+="  $(printf '+-%-12s-+-%-7s-+-%-11s-+-%-8s-+' '------------' '-------' '-----------' '--------')"$'\n'
    report+=""$'\n'

    # Weighted contribution
    local c1=$(( MSR_SCORE_STAGE1 * MSR_WEIGHT_STAGE1 / 100 ))
    local c2=$(( MSR_SCORE_STAGE2 * MSR_WEIGHT_STAGE2 / 100 ))
    local c3=$(( MSR_SCORE_STAGE3 * MSR_WEIGHT_STAGE3 / 100 ))
    local c4=$(( MSR_SCORE_STAGE4 * MSR_WEIGHT_STAGE4 / 100 ))
    report+="  Weighted Contributions:"$'\n'
    report+="    S1 (${MSR_WEIGHT_STAGE1}%): ${c1}pt  |  S2 (${MSR_WEIGHT_STAGE2}%): ${c2}pt  |  S3 (${MSR_WEIGHT_STAGE3}%): ${c3}pt  |  S4 (${MSR_WEIGHT_STAGE4}%): ${c4}pt"$'\n'
    report+=""$'\n'

    # Top issues summary
    report+="  $(printf '-%.0s' {1..62})"$'\n'
    report+="  TOP ISSUES"$'\n'
    report+="  $(printf '-%.0s' {1..62})"$'\n'

    local issue_num=0
    local all_issues="${MSR_ISSUES_STAGE1}
${MSR_ISSUES_STAGE2}
${MSR_ISSUES_STAGE3}
${MSR_ISSUES_STAGE4}"

    # Show criticals first, then majors
    while IFS='|' read -r severity category message file; do
        [[ -z "$severity" ]] && continue
        [[ "$severity" != "critical" ]] && continue
        issue_num=$((issue_num + 1))
        (( issue_num > 10 )) && break
        report+="    [CRITICAL] ${category}: ${message}"$'\n'
        [[ -n "$file" ]] && report+="               -> ${file}"$'\n'
    done <<< "$all_issues"

    while IFS='|' read -r severity category message file; do
        [[ -z "$severity" ]] && continue
        [[ "$severity" != "major" ]] && continue
        issue_num=$((issue_num + 1))
        (( issue_num > 10 )) && break
        report+="    [MAJOR]    ${category}: ${message}"$'\n'
        [[ -n "$file" ]] && report+="               -> ${file}"$'\n'
    done <<< "$all_issues"

    if (( issue_num == 0 )); then
        report+="    No issues found."$'\n'
    fi
    report+=""$'\n'

    # Improvement recommendations
    report+="  $(printf '-%.0s' {1..62})"$'\n'
    report+="  RECOMMENDATIONS"$'\n'
    report+="  $(printf '-%.0s' {1..62})"$'\n'

    local weakest_stage=1 weakest_score=$MSR_SCORE_STAGE1
    (( MSR_SCORE_STAGE2 < weakest_score )) && { weakest_stage=2; weakest_score=$MSR_SCORE_STAGE2; }
    (( MSR_SCORE_STAGE3 < weakest_score )) && { weakest_stage=3; weakest_score=$MSR_SCORE_STAGE3; }
    (( MSR_SCORE_STAGE4 < weakest_score )) && { weakest_stage=4; weakest_score=$MSR_SCORE_STAGE4; }

    report+="    Weakest area: Stage ${weakest_stage} (score: ${weakest_score})"$'\n'

    case "$weakest_stage" in
        1) report+="    -> Focus on project structure: ensure all directories, configs, and schemas are in place"$'\n'
           report+="    -> Fix import paths and resolve circular dependencies"$'\n' ;;
        2) report+="    -> Strengthen type safety: eliminate 'any' types, add Zod validation"$'\n'
           report+="    -> Add authentication to all non-public API routes"$'\n'
           report+="    -> Wrap multi-mutation DB operations in transactions"$'\n' ;;
        3) report+="    -> Improve code quality: remove console.log, extract constants, handle errors"$'\n'
           report+="    -> Add loading/error/empty states to all data-fetching pages"$'\n'
           report+="    -> Increase test coverage for critical paths"$'\n' ;;
        4) report+="    -> Implement missing domain features and complete CRUD operations"$'\n'
           report+="    -> Add error recovery (try-catch) to all API calls"$'\n'
           report+="    -> Improve accessibility: ARIA labels, keyboard nav, alt text"$'\n' ;;
    esac

    if (( MSR_WEIGHTED_TOTAL >= 90 )); then
        report+=""$'\n'
        report+="    Overall: Excellent quality. Minor polish remaining."$'\n'
    elif (( MSR_WEIGHTED_TOTAL >= 70 )); then
        report+=""$'\n'
        report+="    Overall: Good foundation. Address the top issues to reach production quality."$'\n'
    elif (( MSR_WEIGHTED_TOTAL >= 50 )); then
        report+=""$'\n'
        report+="    Overall: Needs work. Focus on the weakest stage before proceeding."$'\n'
    else
        report+=""$'\n'
        report+="    Overall: Significant issues. Prioritize structural and semantic fixes first."$'\n'
    fi

    report+=""$'\n'
    report+="$(printf '=%.0s' {1..62})"$'\n'

    echo "$report" >&2
    return 0
}

# =============================================================================
# 10. msr_get_stats() - Pipeline statistics
# =============================================================================
msr_get_stats() {
    local stats=""

    stats+=""$'\n'
    stats+="$(printf '=%.0s' {1..50})"$'\n'
    stats+="  MSR PIPELINE STATISTICS"$'\n'
    stats+="$(printf '=%.0s' {1..50})"$'\n'
    stats+=""$'\n'
    stats+="  Total runs:    ${MSR_STAT_TOTAL_RUNS}"$'\n'
    stats+="  Passed:        ${MSR_STAT_PASS_COUNT}"$'\n'
    stats+="  Failed:        ${MSR_STAT_FAIL_COUNT}"$'\n'

    if (( MSR_STAT_TOTAL_RUNS > 0 )); then
        local pass_rate=$(( MSR_STAT_PASS_COUNT * 100 / MSR_STAT_TOTAL_RUNS ))
        stats+="  Pass rate:     ${pass_rate}%"$'\n'
    else
        stats+="  Pass rate:     N/A"$'\n'
    fi

    stats+="  Total retries: ${MSR_STAT_TOTAL_RETRIES}"$'\n'
    stats+=""$'\n'

    # Average scores per stage
    stats+="  Average Scores per Stage:"$'\n'
    if (( MSR_STAT_TOTAL_RUNS > 0 )); then
        local avg_s1=$(( MSR_STAT_S1_SUM / MSR_STAT_TOTAL_RUNS ))
        local avg_s2=$(( MSR_STAT_S2_SUM / MSR_STAT_TOTAL_RUNS ))
        local avg_s3=$(( MSR_STAT_S3_SUM / MSR_STAT_TOTAL_RUNS ))
        local avg_s4=$(( MSR_STAT_S4_SUM / MSR_STAT_TOTAL_RUNS ))
        stats+="    Stage 1 (Structural):  ${avg_s1}/100"$'\n'
        stats+="    Stage 2 (Semantic):    ${avg_s2}/100"$'\n'
        stats+="    Stage 3 (Quality):     ${avg_s3}/100"$'\n'
        stats+="    Stage 4 (Completeness):${avg_s4}/100"$'\n'

        local avg_retries=0
        (( MSR_STAT_FAIL_COUNT > 0 )) && avg_retries=$(( MSR_STAT_TOTAL_RETRIES / MSR_STAT_FAIL_COUNT ))
        stats+=""$'\n'
        stats+="  Avg retries to pass: ${avg_retries}"$'\n'
    else
        stats+="    No data yet."$'\n'
    fi

    # Most common failure reasons
    stats+=""$'\n'
    stats+="  Most Common Failure Categories:"$'\n'
    if [[ -n "$MSR_STAT_COMMON_FAILURES" ]]; then
        echo "$MSR_STAT_COMMON_FAILURES" | tr ',' '\n' | sort | uniq -c | sort -rn | head -5 | while read -r count category; do
            stats+="    ${count}x ${category}"$'\n'
        done
        # The pipe subshell loses the variable, so use process substitution
        local top_failures
        top_failures=$(echo "$MSR_STAT_COMMON_FAILURES" | tr ',' '\n' | sort | uniq -c | sort -rn | head -5)
        while read -r count category; do
            [[ -z "$count" ]] && continue
            stats+="    ${count}x ${category}"$'\n'
        done <<< "$top_failures"
    else
        stats+="    No failures recorded yet."$'\n'
    fi

    stats+=""$'\n'
    stats+="$(printf '=%.0s' {1..50})"$'\n'

    echo "$stats" >&2
    return 0
}

# =============================================================================
# Module self-test (run directly for validation)
# =============================================================================
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    echo "multi-stage-review.sh v${MSR_VERSION} - self-test"
    msr_init
    echo "Initialized. Thresholds: S1=${MSR_THRESHOLD_STAGE1} S2=${MSR_THRESHOLD_STAGE2} S3=${MSR_THRESHOLD_STAGE3} S4=${MSR_THRESHOLD_STAGE4}"

    if [[ -n "${1:-}" ]]; then
        echo "Running pipeline on: $1 (domain: ${2:-general})"
        msr_run_pipeline "$1" "${2:-general}"
        echo ""
        msr_generate_fix_instructions
        echo ""
        msr_get_stats
    else
        echo "Usage: bash multi-stage-review.sh <project_dir> [domain]"
        echo "Domains: ecommerce, saas, blog, crm, general"
    fi
fi
