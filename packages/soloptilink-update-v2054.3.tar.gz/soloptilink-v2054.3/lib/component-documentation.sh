#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v396.0 - Component Documentation
# =============================================================================
# コンポーネントドキュメント生成。Storybook/Props/使用例を自動生成。
# All globals use the CD_ prefix.
# =============================================================================

[[ -n "${_COMPONENT_DOCUMENTATION_LOADED:-}" ]] && return 0
_COMPONENT_DOCUMENTATION_LOADED=1

declare -g CD_VERSION="396.0"
declare -g CD_INITIALIZED=false
declare -g CD_GENERATED_COUNT=0
declare -g CD_STORYBOOK_GENERATED=false
declare -g CD_PROPS_GENERATED=false
declare -g CD_EXAMPLES_GENERATED=false
declare -g CD_CATALOG_GENERATED=false
declare -g ENABLE_CD="${ENABLE_CD:-true}"

_cd_init() { CD_INITIALIZED=true; CD_GENERATED_COUNT=0; return 0; }

_cd_generate_all() {
    local project_dir="${1:-.}"
    [[ "$CD_INITIALIZED" != "true" ]] && _cd_init
    echo -e "  ${CYAN:-\033[0;36m}[CD]${NC:-\033[0m} コンポーネントドキュメント生成開始..." >&2
    _cd_generate_storybook "$project_dir"
    _cd_generate_props_doc "$project_dir"
    _cd_generate_examples "$project_dir"
    _cd_generate_catalog "$project_dir"
    echo -e "  ${GREEN:-\033[0;32m}[CD]${NC:-\033[0m} コンポーネントドキュメント生成完了: ${CD_GENERATED_COUNT}件" >&2
    return 0
}

_cd_generate_storybook() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CD-STORYBOOK] Storybook自動生成

```typescript
// Storybook Story Generator
export function generateStory(component: ComponentInfo): string {
  const { name, props, defaultProps } = component;
  return `
import type { Meta, StoryObj } from '@storybook/react';
import { ${name} } from './${name}';

const meta: Meta<typeof ${name}> = {
  title: 'Components/${name}',
  component: ${name},
  tags: ['autodocs'],
  argTypes: {
${props.map(p => `    ${p.name}: { control: '${mapTypeToControl(p.type)}', description: '${p.description}' },`).join('\n')}
  },
};
export default meta;
type Story = StoryObj<typeof ${name}>;

export const Default: Story = { args: ${JSON.stringify(defaultProps, null, 2)} };
export const Loading: Story = { args: { ...Default.args, isLoading: true } };
export const Error: Story = { args: { ...Default.args, error: 'Something went wrong' } };
export const Empty: Story = { args: { ...Default.args, data: [] } };
`;
}

function mapTypeToControl(type: string): string {
  if (type === 'boolean') return 'boolean';
  if (type === 'number') return 'number';
  if (type.includes('|')) return 'select';
  return 'text';
}
```
TEMPLATE
    CD_STORYBOOK_GENERATED=true
    CD_GENERATED_COUNT=$((CD_GENERATED_COUNT + 1))
    return 0
}

_cd_generate_props_doc() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CD-PROPS] Props自動ドキュメント

```typescript
interface PropInfo { name: string; type: string; required: boolean; defaultValue?: string; description: string; }

export function extractPropsFromFile(filePath: string): PropInfo[] {
  const content = readFileSync(filePath, 'utf-8');
  const interfaceMatch = content.match(/interface\s+\w*Props\s*\{([^}]+)\}/s);
  if (!interfaceMatch) return [];
  const propsBlock = interfaceMatch[1];
  const props: PropInfo[] = [];
  for (const line of propsBlock.split('\n')) {
    const match = line.match(/^\s*(\w+)(\??):\s*(.+?);?\s*(?:\/\/\s*(.*))?$/);
    if (match) {
      props.push({ name: match[1], required: match[2] !== '?', type: match[3].trim(), description: match[4] ?? '' });
    }
  }
  return props;
}

export function generatePropsTable(props: PropInfo[]): string {
  let md = '| Prop | Type | Required | Default | Description |\n|------|------|----------|---------|-------------|\n';
  for (const p of props) {
    md += `| ${p.name} | \`${p.type}\` | ${p.required ? 'Yes' : 'No'} | ${p.defaultValue ?? '-'} | ${p.description} |\n`;
  }
  return md;
}
```
TEMPLATE
    CD_PROPS_GENERATED=true
    CD_GENERATED_COUNT=$((CD_GENERATED_COUNT + 1))
    return 0
}

_cd_generate_examples() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CD-EXAMPLES] 使用例生成

```typescript
export function generateUsageExamples(component: ComponentInfo): string {
  const { name, props } = component;
  let examples = `## Usage Examples\n\n### Basic\n\`\`\`tsx\nimport { ${name} } from '@/components/${name}';\n\n<${name}`;
  const requiredProps = props.filter(p => p.required);
  if (requiredProps.length > 0) {
    examples += '\n';
    for (const p of requiredProps) { examples += `  ${p.name}={${generateExampleValue(p.type)}}\n`; }
  }
  examples += `/>\n\`\`\`\n`;
  return examples;
}
```
TEMPLATE
    CD_EXAMPLES_GENERATED=true
    CD_GENERATED_COUNT=$((CD_GENERATED_COUNT + 1))
    return 0
}

_cd_generate_catalog() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CD-CATALOG] コンポーネントカタログ

```tsx
'use client';
export function ComponentCatalog() {
  const { data, isLoading } = useSWR('/api/dev/components');
  const [search, setSearch] = useState('');
  if (isLoading) return <Skeleton />;
  const filtered = data?.components?.filter((c: any) => c.name.toLowerCase().includes(search.toLowerCase()));
  return (
    <div className="space-y-4">
      <Input placeholder="コンポーネント検索..." value={search} onChange={(e) => setSearch(e.target.value)} />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered?.map((c: any) => (
          <div key={c.name} className="border rounded-lg p-4">
            <h3 className="font-bold">{c.name}</h3>
            <p className="text-sm text-muted-foreground">{c.description}</p>
            <div className="mt-2 flex gap-1">{c.props?.length && <Badge>{c.props.length} props</Badge>}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
```
TEMPLATE
    CD_CATALOG_GENERATED=true
    CD_GENERATED_COUNT=$((CD_GENERATED_COUNT + 1))
    return 0
}

_cd_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Component Documentation v${CD_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成数             : ${CD_GENERATED_COUNT}"
    echo -e "  Storybook          : ${CD_STORYBOOK_GENERATED}"
    echo -e "  Props              : ${CD_PROPS_GENERATED}"
    echo -e "  使用例             : ${CD_EXAMPLES_GENERATED}"
    echo -e "  カタログ           : ${CD_CATALOG_GENERATED}"
}

_cd_score() {
    local score=30
    [[ "$CD_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$CD_STORYBOOK_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$CD_PROPS_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$CD_EXAMPLES_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$CD_CATALOG_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "component-documentation" \
    --version "396.0" \
    --description "コンポーネントドキュメント（Storybook/Props/使用例/カタログ）" \
    --init "_cd_init" \
    --report "_cd_report" \
    --score "_cd_score" \
    --enable-var "ENABLE_CD" \
    --cli-flags "--component-docs:--no-component-docs"
