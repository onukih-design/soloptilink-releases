#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2003.0 - Mode Router
# =============================================================================
# 開発モードの判定・ルーティングエンジン
#
# 2つのモードで明確にフローを分ける:
#
# 【自社開発モード (internal)】 ← デフォルト
#   1. 競合調査（実Web検索）
#   2. 競合分析結果を基に機能提案
#   3. ユーザー承認を得てから設計・実装
#   → 「人が依頼するよりも優れたシステム」を目指す
#
# 【受託開発モード (client)】
#   1. 要件確認（依頼内容の明確化のみ）
#   2. 要件通りに忠実に設計・実装
#   → 「言われたことだけを正確に開発」する
#
# 判定方法:
#   - --client フラグ → 受託開発
#   - --internal フラグ → 自社開発
#   - 「受託」「クライアント」等のキーワード → 受託開発
#   - それ以外 → 初回のみユーザーに確認
# =============================================================================

[[ -n "${_MODE_ROUTER_LOADED:-}" ]] && return 0
_MODE_ROUTER_LOADED=1

# グローバル: モード情報
declare -g MR_MODE="${SESSION_MODE:-internal}"  # デフォルトは自社開発
declare -g MR_MODE_CONFIRMED="false"
declare -g MR_SKIP_RESEARCH="false"

# カラー
MRT_GREEN='\033[0;32m'
MRT_YELLOW='\033[0;33m'
MRT_RED='\033[0;31m'
MRT_BLUE='\033[0;34m'
MRT_PURPLE='\033[0;35m'
MRT_CYAN='\033[0;36m'
MRT_BOLD='\033[1m'
MRT_NC='\033[0m'

# =============================================================================
# 初期化
# =============================================================================
mrt_init() {
    echo -e "  ${MRT_GREEN}🔀 v2003.0 Mode Router 初期化完了 (現在: ${MR_MODE})${MRT_NC}"
}

# =============================================================================
# ログ
# =============================================================================
_mrt_log() {
    local level="$1" message="$2"
    local color="${MRT_NC}"
    case "$level" in
        INFO)    color="${MRT_CYAN}"   ;;
        SUCCESS) color="${MRT_GREEN}"  ;;
        WARN)    color="${MRT_YELLOW}" ;;
        ERROR)   color="${MRT_RED}"    ;;
        MODE)    color="${MRT_PURPLE}" ;;
    esac
    echo -e "  ${color}[MODE:${level}]${MRT_NC} ${message}"
}

# =============================================================================
# タスク説明からモードを自動判定
# =============================================================================
_mrt_detect_mode_from_task() {
    local task_desc="$1"
    local task_lower
    task_lower=$(echo "$task_desc" | tr '[:upper:]' '[:lower:]')

    # 受託開発を示すキーワード
    if [[ "$task_lower" =~ (受託|クライアント|client|顧客依頼|要件通り|指示通り|言われた通り|仕様書通り) ]]; then
        echo "client"
        return 0
    fi

    # 自社開発を示すキーワード
    if [[ "$task_lower" =~ (自社|自前|内製|internal|社内|自分|自宅開発用|自分用|自社開発) ]]; then
        echo "internal"
        return 0
    fi

    # 判定不能
    echo "unknown"
    return 0
}

# =============================================================================
# モード確認（ユーザーへの対話的確認）
# =============================================================================
mrt_confirm_mode() {
    local task_desc="$1"

    # 既にCLIフラグで指定されている場合はスキップ
    if [[ "${SESSION_MODE:-}" == "client" ]]; then
        MR_MODE="client"
        MR_MODE_CONFIRMED="true"
        _mrt_log "MODE" "受託開発モード（CLIフラグ指定）"
        return 0
    fi
    if [[ "${SESSION_MODE:-}" == "internal" ]]; then
        MR_MODE="internal"
        MR_MODE_CONFIRMED="true"
        _mrt_log "MODE" "自社開発モード（CLIフラグ指定）"
        return 0
    fi

    # タスク説明からの自動判定
    local detected
    detected=$(_mrt_detect_mode_from_task "$task_desc")

    if [[ "$detected" == "client" ]]; then
        MR_MODE="client"
        MR_MODE_CONFIRMED="true"
        _mrt_log "MODE" "受託開発モード（タスク説明から自動判定）"
        return 0
    fi

    if [[ "$detected" == "internal" ]]; then
        MR_MODE="internal"
        MR_MODE_CONFIRMED="true"
        _mrt_log "MODE" "自社開発モード（タスク説明から自動判定）"
        return 0
    fi

    # v2003.1: 非interactive環境では自動判定（ハング防止）
    # SESSION_MODE/--client/--internalが指定されていれば対話スキップ
    if [[ "${SOLOPTILINK_NON_INTERACTIVE:-false}" == "true" ]]; then
        MR_MODE="${SESSION_MODE:-internal}"
        MR_MODE_CONFIRMED="true"
        _mrt_log "MODE" "非interactiveモード: ${MR_MODE}で自動続行"
        return 0
    fi

    # 判定不能 → ユーザーに確認（TTY利用可能な場合のみ）
    if [[ -t 0 ]] && [[ -e /dev/tty ]]; then
        echo ""
        echo -e "${MRT_BOLD}${MRT_BLUE}╔═══════════════════════════════════════════════════════╗${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_BLUE}║  🔀 開発モードの確認                                   ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_BLUE}╠═══════════════════════════════════════════════════════╣${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_BLUE}║                                                       ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_BLUE}║  [1] 自社開発モード（デフォルト）                       ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_BLUE}║      → 競合調査を行い、より優れたシステムを提案         ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_BLUE}║      → あなたの要件 + AIの提案 で最高品質に             ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_BLUE}║                                                       ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_BLUE}║  [2] 受託開発モード                                    ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_BLUE}║      → 言われた要件だけを正確に開発                     ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_BLUE}║      → 機能追加の提案はしない                          ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_BLUE}║                                                       ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_BLUE}╚═══════════════════════════════════════════════════════╝${MRT_NC}"
        echo ""

        local answer=""
        read -r -p "  選択 [1/2] (デフォルト: 1): " answer < /dev/tty 2>/dev/null || answer="1"

        case "$answer" in
            2|client|受託)
                MR_MODE="client"
                _mrt_log "MODE" "受託開発モードを選択"
                ;;
            *)
                MR_MODE="internal"
                _mrt_log "MODE" "自社開発モードを選択"
                ;;
        esac
        MR_MODE_CONFIRMED="true"
    else
        # TTYなし → デフォルトは自社開発
        MR_MODE="internal"
        MR_MODE_CONFIRMED="true"
        _mrt_log "MODE" "自社開発モード（デフォルト、非対話環境）"
    fi

    # グローバル変数にも反映
    SESSION_MODE="$MR_MODE"
    export SESSION_MODE

    return 0
}

# =============================================================================
# モードに応じた実行ルーティング
# =============================================================================
mrt_route() {
    local task_desc="$1"
    local domain="${2:-general}"
    local session_id="${3:-}"

    # Step 1: モード確認（まだの場合）
    if [[ "$MR_MODE_CONFIRMED" != "true" ]]; then
        mrt_confirm_mode "$task_desc"
    fi

    echo ""
    if [[ "$MR_MODE" == "internal" ]]; then
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # 自社開発モード: 競合調査 → 提案 → 承認 → 設計
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        echo -e "${MRT_BOLD}${MRT_GREEN}╔═══════════════════════════════════════════════════════╗${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_GREEN}║  🚀 自社開発モード                                     ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_GREEN}║  競合調査 → 機能提案 → 設計 → 実装 → 深層テスト        ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_GREEN}╚═══════════════════════════════════════════════════════╝${MRT_NC}"
        echo ""

        # Phase R1: 競合調査
        if [[ "$MR_SKIP_RESEARCH" != "true" ]] && type -t rcr_research_competitors &>/dev/null; then
            rcr_research_competitors "$task_desc" "$domain" "$session_id"

            # 調査結果のサマリー表示
            if type -t rcr_show_summary &>/dev/null; then
                rcr_show_summary
            fi
        else
            _mrt_log "WARN" "競合調査モジュール未ロード（スキップ）"
        fi

        # Phase R2: 調査結果をConsultant Engineに注入
        if type -t rcr_get_context_for_prompt &>/dev/null; then
            local _rcr_context
            _rcr_context=$(rcr_get_context_for_prompt 4000)
            if [[ -n "$_rcr_context" ]]; then
                export RCR_COMPETITIVE_CONTEXT="$_rcr_context"
                _mrt_log "SUCCESS" "競合調査結果をパイプラインに注入完了"
            fi
        fi

    else
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # 受託開発モード: 要件確認のみ → 忠実に実装
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        echo -e "${MRT_BOLD}${MRT_CYAN}╔═══════════════════════════════════════════════════════╗${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_CYAN}║  📋 受託開発モード                                     ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_CYAN}║  要件確認 → 忠実に設計 → 正確に実装 → 品質検証          ║${MRT_NC}"
        echo -e "${MRT_BOLD}${MRT_CYAN}╚═══════════════════════════════════════════════════════╝${MRT_NC}"
        echo ""

        _mrt_log "MODE" "要件通りに開発します。機能追加の提案は行いません。"

        # 競合調査は実行しない
        MR_SKIP_RESEARCH="true"
    fi

    return 0
}

# =============================================================================
# モード取得（他モジュールから参照用）
# =============================================================================
mrt_get_mode() {
    echo "${MR_MODE:-internal}"
}

mrt_is_internal() {
    [[ "${MR_MODE:-internal}" == "internal" ]]
}

mrt_is_client() {
    [[ "${MR_MODE:-internal}" == "client" ]]
}

# =============================================================================
# Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "mode-router" \
        --version "2003.0" \
        --init "mrt_init" \
        --description "開発モード判定・ルーティングエンジン"
fi

# v2003.1: source時のexit codeを確実に0にする
true
