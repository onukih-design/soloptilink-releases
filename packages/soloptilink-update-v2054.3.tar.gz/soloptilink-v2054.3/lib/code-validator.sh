#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v31.0 - Code Validator (Pre-Write Validation Pipeline)
# =============================================================================
# Validates Claude's output BEFORE writing to files.
# Prevents bad code from being written, reducing heal cycles.
#
# Core Principle: "書き込む前に検証 → 修復サイクル激減 → 無駄なAPI消費ゼロ"
#
# Validation Pipeline:
#   1. Syntax Check      - Node.js syntax or bracket matching
#   2. Import Integrity  - Referenced files exist or in same batch
#   3. Anti-Pattern Scan - Mock data, empty handlers, console.log, TODO
#   4. Path Validation   - No duplicate files, paths within project
#   5. Auto-Fix          - console.log removal, import path normalization
#
# Flow:
#   Claude Output → cv2_validate() → PASS → write files
#                                   → FAIL → cv2_generate_fix_prompt() → re-call Claude
#
# Functions:
#   cv2_init                  - Initialize validator
#   cv2_parse_file_blocks     - Parse --- FILE: path --- blocks
#   cv2_validate_output       - Full validation pipeline
#   cv2_check_syntax          - Syntax validation
#   cv2_check_imports         - Import path validation
#   cv2_check_anti_patterns   - Anti-pattern detection
#   cv2_check_paths           - File path validation
#   cv2_fix_common_issues     - Auto-fix trivial issues
#   cv2_should_reject         - Determine if output is bad enough to reject
#   cv2_generate_fix_prompt   - Generate targeted fix prompt for re-call
#   cv2_report                - Validation report
#
# All globals use the CV2_ prefix (CV_ is taken by config-validator).
# =============================================================================

[[ -n "${_CODE_VALIDATOR_LOADED:-}" ]] && return 0
_CODE_VALIDATOR_LOADED=1

# ============================================================
# State
# ============================================================
declare -g CV2_VERSION="31.0"
declare -g CV2_ENABLED="true"
declare -g CV2_PROJECT_DIR=""
declare -g CV2_MAX_RETRIES=2
declare -g CV2_REJECT_THRESHOLD=30   # Reject if >30% of files have issues
declare -g CV2_TOTAL_FILES=0
declare -g CV2_PASS_FILES=0
declare -g CV2_WARN_FILES=0
declare -g CV2_FAIL_FILES=0
declare -g CV2_AUTO_FIXED=0

# Per-file results
declare -g -A CV2_FILE_STATUS=()     # path -> PASS|WARN|FAIL
declare -g -A CV2_FILE_ISSUES=()     # path -> issue description

# Anti-patterns to detect
declare -g -a CV2_ANTI_PATTERNS=(
    'useState\(\s*\[\s*\{.*id.*name'     # Hardcoded mock arrays in useState
    'const\s+\w+\s*=\s*\[\s*\{.*id.*:'   # Module-level mock data
    'onClick=\{?\(\)\s*=>\s*\{\s*\}\}?'  # Empty onClick handlers
    'onSubmit=\{?\(\)\s*=>\s*\{\s*\}\}?' # Empty onSubmit handlers
    'TODO|FIXME|HACK|XXX'                 # Unfinished code markers
    'Date\.now\(\)\s*(\.toString\(\))?'   # Date.now() as ID
    'localStorage\.(set|get)Item'         # localStorage as primary DB
    ':\s*any\b'                           # TypeScript any type
    # Swift-specific anti-patterns
    '\w+!\.'                              # Force unwrap (e.g., foo!.bar)
    '\btry!\s'                            # Force try (should use try/try? with error handling)
    '\bas!\s'                             # Force cast (should use as? with nil check)
    'Thread\.sleep'                       # Thread.sleep blocks main thread
    'DispatchQueue\.main\.sync'           # sync on main queue risks deadlock
)

# ============================================================
# Internal logger
# ============================================================
_cv2_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[CODE-VALID]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize code validator
# ============================================================
cv2_init() {
    local project_dir="${1:-${PROJECT_DIR:-}}"

    CV2_PROJECT_DIR="$project_dir"
    CV2_TOTAL_FILES=0
    CV2_PASS_FILES=0
    CV2_WARN_FILES=0
    CV2_FAIL_FILES=0
    CV2_AUTO_FIXED=0
    CV2_FILE_STATUS=()
    CV2_FILE_ISSUES=()

    _cv2_log "SUCCESS" "Code Validator v31.0 初期化: project=${project_dir}"
    return 0
}

# ============================================================
# Parse Claude output into file blocks
# Returns associative array via global CV2_PARSED_FILES
# ============================================================
declare -g -A CV2_PARSED_FILES=()
declare -g -a CV2_PARSED_PATHS=()

cv2_parse_file_blocks() {
    local output="$1"
    CV2_PARSED_FILES=()
    CV2_PARSED_PATHS=()

    local current_path=""
    local current_content=""
    local in_file=0

    while IFS= read -r line; do
        # Detect file start: --- FILE: path --- or --- FILE: path ---
        if [[ "$line" =~ ^---[[:space:]]*FILE:[[:space:]]*(.*[^[:space:]])[[:space:]]*---$ ]] || \
           [[ "$line" =~ ^//[[:space:]]*---[[:space:]]*FILE:[[:space:]]*(.*[^[:space:]])[[:space:]]*---$ ]]; then
            # Save previous file if exists
            if [[ -n "$current_path" && "$in_file" -eq 1 ]]; then
                CV2_PARSED_FILES["$current_path"]="$current_content"
                CV2_PARSED_PATHS+=("$current_path")
            fi
            current_path="${BASH_REMATCH[1]}"
            current_content=""
            in_file=1
            continue
        fi

        # Detect file end
        if [[ "$line" =~ ^---[[:space:]]*END[[:space:]]*FILE ]] || \
           [[ "$line" =~ ^//[[:space:]]*---[[:space:]]*END[[:space:]]*FILE ]]; then
            if [[ -n "$current_path" && "$in_file" -eq 1 ]]; then
                CV2_PARSED_FILES["$current_path"]="$current_content"
                CV2_PARSED_PATHS+=("$current_path")
            fi
            current_path=""
            current_content=""
            in_file=0
            continue
        fi

        # Accumulate content
        if [[ "$in_file" -eq 1 ]]; then
            current_content+="${line}
"
        fi
    done <<< "$output"

    # Save last file if no END marker
    if [[ -n "$current_path" && "$in_file" -eq 1 ]]; then
        CV2_PARSED_FILES["$current_path"]="$current_content"
        CV2_PARSED_PATHS+=("$current_path")
    fi

    CV2_TOTAL_FILES=${#CV2_PARSED_PATHS[@]}
    return 0
}

# ============================================================
# Check syntax of a single file
# ============================================================
cv2_check_syntax() {
    local file_path="$1"
    local content="$2"
    local issues=""

    local ext="${file_path##*.}"

    case "$ext" in
        ts|tsx|js|jsx)
            # Check bracket/brace/paren balance
            local open_braces close_braces open_parens close_parens open_brackets close_brackets
            open_braces=$(echo "$content" | tr -cd '{' | wc -c | tr -d ' ')
            close_braces=$(echo "$content" | tr -cd '}' | wc -c | tr -d ' ')
            open_parens=$(echo "$content" | tr -cd '(' | wc -c | tr -d ' ')
            close_parens=$(echo "$content" | tr -cd ')' | wc -c | tr -d ' ')
            open_brackets=$(echo "$content" | tr -cd '[' | wc -c | tr -d ' ')
            close_brackets=$(echo "$content" | tr -cd ']' | wc -c | tr -d ' ')

            if [[ "$open_braces" -ne "$close_braces" ]]; then
                issues+="Brace mismatch: { ${open_braces} vs } ${close_braces}; "
            fi
            if [[ "$open_parens" -ne "$close_parens" ]]; then
                issues+="Paren mismatch: ( ${open_parens} vs ) ${close_parens}; "
            fi
            if [[ "$open_brackets" -ne "$close_brackets" ]]; then
                issues+="Bracket mismatch: [ ${open_brackets} vs ] ${close_brackets}; "
            fi

            # Check for unclosed template literals
            local backtick_count
            backtick_count=$(echo "$content" | tr -cd '`' | wc -c | tr -d ' ')
            if [[ $((backtick_count % 2)) -ne 0 ]]; then
                issues+="Unclosed template literal; "
            fi
            ;;
        swift)
            # Check bracket/brace balance for Swift
            local open_braces close_braces open_parens close_parens open_brackets close_brackets
            open_braces=$(echo "$content" | tr -cd '{' | wc -c | tr -d ' ')
            close_braces=$(echo "$content" | tr -cd '}' | wc -c | tr -d ' ')
            open_parens=$(echo "$content" | tr -cd '(' | wc -c | tr -d ' ')
            close_parens=$(echo "$content" | tr -cd ')' | wc -c | tr -d ' ')
            open_brackets=$(echo "$content" | tr -cd '[' | wc -c | tr -d ' ')
            close_brackets=$(echo "$content" | tr -cd ']' | wc -c | tr -d ' ')

            if [[ "$open_braces" -ne "$close_braces" ]]; then
                issues+="Brace mismatch: { ${open_braces} vs } ${close_braces}; "
            fi
            if [[ "$open_parens" -ne "$close_parens" ]]; then
                issues+="Paren mismatch: ( ${open_parens} vs ) ${close_parens}; "
            fi
            if [[ "$open_brackets" -ne "$close_brackets" ]]; then
                issues+="Bracket mismatch: [ ${open_brackets} vs ] ${close_brackets}; "
            fi
            ;;
        json)
            # JSON syntax check via python
            if command -v python3 &>/dev/null; then
                if ! echo "$content" | python3 -c "import json,sys; json.load(sys.stdin)" 2>/dev/null; then
                    issues+="Invalid JSON; "
                fi
            fi
            ;;
    esac

    echo "$issues"
}

# ============================================================
# Check import integrity
# ============================================================
cv2_check_imports() {
    local file_path="$1"
    local content="$2"
    local issues=""

    local ext="${file_path##*.}"
    [[ "$ext" != "ts" && "$ext" != "tsx" && "$ext" != "js" && "$ext" != "jsx" ]] && return 0

    # Extract import paths
    local -a import_paths=()
    while IFS= read -r line; do
        if [[ "$line" =~ from[[:space:]]+[\'\"]([^\'\"]+)[\'\"] ]]; then
            import_paths+=("${BASH_REMATCH[1]}")
        fi
    done <<< "$content"

    for imp_path in "${import_paths[@]}"; do
        # Skip external packages (no ./ or ../ or @/ prefix)
        [[ "$imp_path" != ./* && "$imp_path" != ../* && "$imp_path" != @/* ]] && continue
        # Skip @/ alias (handled by tsconfig)
        [[ "$imp_path" == @/* ]] && continue

        # Check if referenced file exists in batch or project
        local resolved_path="$imp_path"
        # Add extensions to check
        local found=0
        for check_ext in "" ".ts" ".tsx" ".js" ".jsx" "/index.ts" "/index.tsx"; do
            local check_path="${resolved_path}${check_ext}"
            # Check in batch
            if [[ -n "${CV2_PARSED_FILES[$check_path]:-}" ]]; then
                found=1; break
            fi
            # Check in project
            if [[ -n "${CV2_PROJECT_DIR}" && -f "${CV2_PROJECT_DIR}/${check_path}" ]]; then
                found=1; break
            fi
        done

        # Relative imports that can't be resolved are only warnings
        if [[ "$found" -eq 0 && "$imp_path" == ./* ]]; then
            issues+="Unresolved import: ${imp_path}; "
        fi
    done

    echo "$issues"
}

# ============================================================
# Check for anti-patterns
# ============================================================
cv2_check_anti_patterns() {
    local file_path="$1"
    local content="$2"
    local issues=""

    local ext="${file_path##*.}"
    # Only check code files
    [[ "$ext" != "ts" && "$ext" != "tsx" && "$ext" != "js" && "$ext" != "jsx" && "$ext" != "swift" ]] && return 0

    # Skip test files
    [[ "$file_path" == *test* || "$file_path" == *spec* || "$file_path" == *__test__* || "$file_path" == *Tests* ]] && return 0
    # Skip seed files and preview files
    [[ "$file_path" == *seed* || "$file_path" == *Preview* ]] && return 0

    for pattern in "${CV2_ANTI_PATTERNS[@]}"; do
        local match_count
        match_count=$(echo "$content" | grep -cE "$pattern" 2>/dev/null | tr -d '[:space:]' || echo "0")
        [[ -z "$match_count" ]] && match_count=0
        if (( match_count > 0 )); then
            # Determine severity
            case "$pattern" in
                *TODO*|*FIXME*)
                    issues+="WARN:TODO/FIXME found(${match_count}); "
                    ;;
                *localStorage*)
                    issues+="WARN:localStorage usage(${match_count}); "
                    ;;
                *:.*any*)
                    issues+="WARN:TypeScript any type(${match_count}); "
                    ;;
                *onClick*|*onSubmit*)
                    issues+="FAIL:Empty handler(${match_count}); "
                    ;;
                *useState*|*const.*\[.*id*)
                    issues+="FAIL:Mock data detected(${match_count}); "
                    ;;
                *Date.now*)
                    issues+="WARN:Date.now() as ID(${match_count}); "
                    ;;
                *'!\.'*)
                    issues+="WARN:Swift force unwrap(${match_count}); "
                    ;;
                *'try!'*)
                    issues+="WARN:Swift force try(${match_count}); "
                    ;;
                *'as!'*)
                    issues+="WARN:Swift force cast(${match_count}); "
                    ;;
                *Thread.sleep*)
                    issues+="WARN:Thread.sleep usage(${match_count}); "
                    ;;
                *DispatchQueue*main*sync*)
                    issues+="WARN:DispatchQueue.main.sync(${match_count}); "
                    ;;
            esac
        fi
    done

    echo "$issues"
}

# ============================================================
# Check file paths
# ============================================================
cv2_check_paths() {
    local issues=""

    # Check for duplicate paths
    local -A seen_paths=()
    for path in "${CV2_PARSED_PATHS[@]}"; do
        if [[ -n "${seen_paths[$path]:-}" ]]; then
            issues+="Duplicate file: ${path}; "
        fi
        seen_paths["$path"]=1

        # Check for suspicious paths
        if [[ "$path" == /* ]]; then
            issues+="Absolute path: ${path}; "
        fi
        if [[ "$path" == *../* ]]; then
            issues+="Path traversal: ${path}; "
        fi
    done

    echo "$issues"
}

# ============================================================
# Auto-fix common issues in content
# ============================================================
cv2_fix_common_issues() {
    local content="$1"
    local file_path="$2"
    local fixed="$content"
    local fix_count=0

    local ext="${file_path##*.}"
    [[ "$ext" != "ts" && "$ext" != "tsx" && "$ext" != "js" && "$ext" != "jsx" ]] && echo "$fixed" && return 0

    # 1. Remove standalone console.log (not in error handlers)
    local new_content
    new_content=$(echo "$fixed" | sed '/^[[:space:]]*console\.log(/d' 2>/dev/null)
    if [[ "$new_content" != "$fixed" ]]; then
        fixed="$new_content"
        fix_count=$((fix_count + 1))
    fi

    # 2. Fix import paths: ../lib/ → @/lib/ (if using @/ alias)
    new_content=$(echo "$fixed" | sed "s|from '\.\./\.\./lib/|from '@/lib/|g; s|from \"\.\./\.\./lib/|from \"@/lib/|g" 2>/dev/null)
    if [[ "$new_content" != "$fixed" ]]; then
        fixed="$new_content"
        fix_count=$((fix_count + 1))
    fi

    # 3. Remove // eslint-disable comments
    new_content=$(echo "$fixed" | sed '/\/\/\s*eslint-disable/d' 2>/dev/null)
    if [[ "$new_content" != "$fixed" ]]; then
        fixed="$new_content"
        fix_count=$((fix_count + 1))
    fi

    CV2_AUTO_FIXED=$((CV2_AUTO_FIXED + fix_count))
    echo "$fixed"
}

# ============================================================
# Full validation pipeline
# ============================================================
cv2_validate_output() {
    local claude_output="$1"

    [[ "${CV2_ENABLED}" != "true" ]] && return 0

    # Reset counters
    CV2_PASS_FILES=0
    CV2_WARN_FILES=0
    CV2_FAIL_FILES=0
    CV2_AUTO_FIXED=0
    CV2_FILE_STATUS=()
    CV2_FILE_ISSUES=()

    # Parse file blocks
    cv2_parse_file_blocks "$claude_output"

    if [[ ${CV2_TOTAL_FILES} -eq 0 ]]; then
        _cv2_log "WARN" "ファイルブロックが検出されません"
        return 0
    fi

    _cv2_log "INFO" "検証開始: ${CV2_TOTAL_FILES}ファイル"

    # Global path check
    local path_issues
    path_issues=$(cv2_check_paths)

    # Per-file validation
    for file_path in "${CV2_PARSED_PATHS[@]}"; do
        local content="${CV2_PARSED_FILES[$file_path]}"
        local all_issues=""
        local status="PASS"

        # 1. Syntax check
        local syntax_issues
        syntax_issues=$(cv2_check_syntax "$file_path" "$content")
        all_issues+="$syntax_issues"

        # 2. Anti-pattern check
        local ap_issues
        ap_issues=$(cv2_check_anti_patterns "$file_path" "$content")
        all_issues+="$ap_issues"

        # 3. Import check
        local import_issues
        import_issues=$(cv2_check_imports "$file_path" "$content")
        all_issues+="$import_issues"

        # Determine status
        if [[ "$all_issues" == *"FAIL:"* ]]; then
            status="FAIL"
            CV2_FAIL_FILES=$((CV2_FAIL_FILES + 1))
        elif [[ -n "$all_issues" ]]; then
            status="WARN"
            CV2_WARN_FILES=$((CV2_WARN_FILES + 1))
        else
            CV2_PASS_FILES=$((CV2_PASS_FILES + 1))
        fi

        CV2_FILE_STATUS["$file_path"]="$status"
        CV2_FILE_ISSUES["$file_path"]="$all_issues"

        # Auto-fix if only warnings
        if [[ "$status" == "WARN" || "$status" == "PASS" ]]; then
            local fixed_content
            fixed_content=$(cv2_fix_common_issues "$content" "$file_path")
            CV2_PARSED_FILES["$file_path"]="$fixed_content"
        fi
    done

    # Log summary
    _cv2_log "INFO" "検証完了: PASS=${CV2_PASS_FILES} WARN=${CV2_WARN_FILES} FAIL=${CV2_FAIL_FILES} 自動修正=${CV2_AUTO_FIXED}"

    return 0
}

# ============================================================
# Should we reject this output and re-prompt Claude?
# ============================================================
cv2_should_reject() {
    [[ ${CV2_TOTAL_FILES} -eq 0 ]] && return 1  # No files = nothing to reject

    # Calculate fail percentage
    local fail_pct=0
    if command -v awk &>/dev/null; then
        fail_pct=$(awk "BEGIN{printf \"%.0f\", (${CV2_FAIL_FILES} / ${CV2_TOTAL_FILES}) * 100}" 2>/dev/null)
    fi

    if [[ "${fail_pct:-0}" -gt "${CV2_REJECT_THRESHOLD}" ]]; then
        _cv2_log "ERROR" "品質不合格: ${fail_pct}%のファイルに重大な問題 (閾値: ${CV2_REJECT_THRESHOLD}%)"
        return 0  # Should reject
    fi

    return 1  # Should accept
}

# ============================================================
# Generate targeted fix prompt for re-call
# ============================================================
cv2_generate_fix_prompt() {
    local original_prompt="${1:-}"
    local fix_prompt=""

    fix_prompt+="前回の出力に以下の品質問題が検出されました。修正してください。

=== 検出された問題 ===
"

    for file_path in "${!CV2_FILE_STATUS[@]}"; do
        local status="${CV2_FILE_STATUS[$file_path]}"
        [[ "$status" == "PASS" ]] && continue

        local issues="${CV2_FILE_ISSUES[$file_path]}"
        fix_prompt+="
[${status}] ${file_path}:
  ${issues}
"
    done

    fix_prompt+="
=== 修正ルール ===
1. モックデータ(ハードコード配列)は全てPrismaクエリに置換
2. 空のイベントハンドラは実際のAPI呼び出し+状態更新を実装
3. console.logは全て削除（console.errorのみ許可、エラーハンドラ内のみ）
4. TODO/FIXMEは実装して削除
5. Date.now()をIDに使わない（cuid()またはuuid()を使用）
6. TypeScriptのany型は具体的な型に置換

修正した全ファイルを出力してください。
"

    if [[ -n "$original_prompt" ]]; then
        fix_prompt+="

=== 元の要件 ===
${original_prompt}
"
    fi

    echo "$fix_prompt"
}

# ============================================================
# Get validated output (with auto-fixes applied)
# ============================================================
cv2_get_validated_output() {
    local output=""

    for file_path in "${CV2_PARSED_PATHS[@]}"; do
        local content="${CV2_PARSED_FILES[$file_path]}"
        output+="--- FILE: ${file_path} ---
${content}--- END FILE ---
"
    done

    echo "$output"
}

# ============================================================
# Validation report
# ============================================================
cv2_report() {
    echo ""
    echo -e "  ${BOLD:-}=== Code Validator レポート (v31.0) ===${NC:-}"
    echo ""
    printf "  %-40s %8s %s\n" "ファイル" "状態" "問題"
    echo "  ──────────────────────────────────────── ──────── ─────────────"

    for file_path in "${CV2_PARSED_PATHS[@]}"; do
        local status="${CV2_FILE_STATUS[$file_path]:-UNKNOWN}"
        local issues="${CV2_FILE_ISSUES[$file_path]:-}"
        local status_color="${GREEN:-}"
        [[ "$status" == "WARN" ]] && status_color="${YELLOW:-}"
        [[ "$status" == "FAIL" ]] && status_color="${RED:-}"

        # Truncate long paths and issues
        local display_path="${file_path}"
        [[ ${#display_path} -gt 40 ]] && display_path="...${display_path: -37}"
        local display_issues="${issues:0:40}"

        printf "  %-40s ${status_color}%8s${NC:-} %s\n" "$display_path" "$status" "$display_issues"
    done

    echo "  ──────────────────────────────────────── ──────── ─────────────"
    echo -e "  合計: ${CV2_TOTAL_FILES}ファイル | ${GREEN:-}PASS:${CV2_PASS_FILES}${NC:-} ${YELLOW:-}WARN:${CV2_WARN_FILES}${NC:-} ${RED:-}FAIL:${CV2_FAIL_FILES}${NC:-} | 自動修正:${CV2_AUTO_FIXED}件"
    echo ""
}

# ============================================================
# Export as JSON
# ============================================================
cv2_export_json() {
    local json="{"
    json+="\"version\":\"${CV2_VERSION}\","
    json+="\"total_files\":${CV2_TOTAL_FILES},"
    json+="\"pass\":${CV2_PASS_FILES},"
    json+="\"warn\":${CV2_WARN_FILES},"
    json+="\"fail\":${CV2_FAIL_FILES},"
    json+="\"auto_fixed\":${CV2_AUTO_FIXED},"
    json+="\"files\":{"

    local first=1
    for path in "${CV2_PARSED_PATHS[@]}"; do
        [[ "$first" -eq 0 ]] && json+=","
        json+="\"${path}\":{\"status\":\"${CV2_FILE_STATUS[$path]:-UNKNOWN}\",\"issues\":\"${CV2_FILE_ISSUES[$path]:-}\"}"
        first=0
    done

    json+="}}"
    echo "$json"
}
