#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v101.0 - AI Provider Abstraction Layer
# AGI対応: AIプロバイダーを差し替え可能にする統一抽象化層
#
# 目的:
# 1. 全AI呼び出しを単一エントリーポイント(ai_call)に統一
# 2. Claude/OpenAI/AGI等のプロバイダーをプラグイン形式で差し替え可能
# 3. 全呼び出しが自動的にaudit/cost/governance/learningを通過
# 4. 既存80+モジュールは変更不要（cb2_call/_call_claudeが内部で委譲）
#
# アーキテクチャ:
#   Caller → ai_call() → Pre-hooks → Provider → Post-hooks → Result
#
# v101.0: AGI-Ready Foundation
# ============================================================

[[ -n "${_AI_PROVIDER_LOADED:-}" ]] && return 0
_AI_PROVIDER_LOADED=1

# --- グローバル状態 ---
AIP_VERSION="200.0"
AIP_INITIALIZED=false
AIP_CALL_COUNT=0
AIP_TOTAL_CALLS_OK=0
AIP_TOTAL_CALLS_FAIL=0
AIP_DEFAULT_PROVIDER="${AIP_DEFAULT_PROVIDER:-claude-cli}"

# --- プロバイダーレジストリ ---
declare -a _AIP_PROVIDERS=()                # 登録済みプロバイダー名リスト
declare -A _AIP_PROVIDER_VERSION=()         # name → version
declare -A _AIP_PROVIDER_CAPABILITIES=()    # name → "text,structured,multi-turn,..."
declare -A _AIP_PROVIDER_GENERATE_FN=()     # name → generate関数名
declare -A _AIP_PROVIDER_STRUCTURED_FN=()   # name → structured generate関数名
declare -A _AIP_PROVIDER_HEALTH_FN=()       # name → health check関数名
declare -A _AIP_PROVIDER_COST_FN=()         # name → cost estimation関数名
declare -A _AIP_PROVIDER_STATUS=()          # name → "ok" / "degraded" / "unavailable"

# --- 設定 ---
AIP_ENABLE_PRE_HOOKS="${AIP_ENABLE_PRE_HOOKS:-true}"
AIP_ENABLE_POST_HOOKS="${AIP_ENABLE_POST_HOOKS:-true}"
AIP_ENABLE_AUDIT="${AIP_ENABLE_AUDIT:-true}"
AIP_ENABLE_COST_GATE="${AIP_ENABLE_COST_GATE:-true}"
AIP_ENABLE_LEARNING="${AIP_ENABLE_LEARNING:-true}"
AIP_AUTO_FAILOVER="${AIP_AUTO_FAILOVER:-true}"

# --- v101.0 AGI能力契約 ---
# プロバイダーが「何ができるか」ではなく「何を保証するか」を定義
# AGI移行時: 能力契約を満たせば即座にスワップ可能
declare -A _AIP_CAPABILITY_CONTRACTS=(
    # [capability]=required_quality_score
    ["code_generation"]="80"       # コード生成: tscパス率80%以上
    ["schema_design"]="90"         # スキーマ設計: prisma validate 90%パス
    ["api_implementation"]="85"    # API実装: 統合検証85%パス
    ["frontend_generation"]="75"   # フロント生成: UIコネクティビティ75%以上
    ["error_correction"]="90"      # エラー修正: 修正成功率90%以上
    ["architecture_design"]="70"   # 設計: レビュアー合意70%以上
)

# --- v101.0 プロバイダー品質メトリクス ---
declare -A _AIP_PROVIDER_QUALITY=()    # provider → 直近の平均品質スコア
declare -A _AIP_PROVIDER_CALL_HIST=()  # provider → "score1,score2,score3,..."(直近10回)

# ============================================================
# 初期化
# ============================================================
aip_init() {
    AIP_INITIALIZED=true
    AIP_CALL_COUNT=0
    AIP_TOTAL_CALLS_OK=0
    AIP_TOTAL_CALLS_FAIL=0

    # プロバイダープラグインを自動ロード
    local providers_dir="${SCRIPT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}/providers"
    if [[ -d "$providers_dir" ]]; then
        for provider_file in "$providers_dir"/*.sh; do
            [[ -f "$provider_file" ]] || continue
            [[ "$(basename "$provider_file")" == "provider-template.sh" ]] && continue
            source "$provider_file" 2>/dev/null || true
        done
    fi

    return 0
}

# ============================================================
# プロバイダー登録（各プロバイダーがsource時に呼ぶ）
# ============================================================
# 使い方:
#   _aip_register_provider \
#     --name "claude-cli" \
#     --version "1.0" \
#     --capabilities "text,structured,multi-turn,agents,system-prompt" \
#     --generate-fn "claude_provider_generate" \
#     --structured-fn "claude_provider_generate_structured" \
#     --health-fn "claude_provider_health" \
#     --cost-fn "claude_provider_estimate_cost"
# ============================================================
_aip_register_provider() {
    local name="" version="" capabilities="" generate_fn="" structured_fn=""
    local health_fn="" cost_fn=""

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --name)          name="$2"; shift 2 ;;
            --version)       version="$2"; shift 2 ;;
            --capabilities)  capabilities="$2"; shift 2 ;;
            --generate-fn)   generate_fn="$2"; shift 2 ;;
            --structured-fn) structured_fn="$2"; shift 2 ;;
            --health-fn)     health_fn="$2"; shift 2 ;;
            --cost-fn)       cost_fn="$2"; shift 2 ;;
            *) shift ;;
        esac
    done

    [[ -z "$name" ]] && return 1
    [[ -z "$generate_fn" ]] && return 1

    _AIP_PROVIDERS+=("$name")
    _AIP_PROVIDER_VERSION["$name"]="${version:-0.1}"
    _AIP_PROVIDER_CAPABILITIES["$name"]="${capabilities:-text}"
    _AIP_PROVIDER_GENERATE_FN["$name"]="$generate_fn"
    _AIP_PROVIDER_STRUCTURED_FN["$name"]="${structured_fn:-}"
    _AIP_PROVIDER_HEALTH_FN["$name"]="${health_fn:-}"
    _AIP_PROVIDER_COST_FN["$name"]="${cost_fn:-}"
    _AIP_PROVIDER_STATUS["$name"]="ok"

    return 0
}

# ============================================================
# プロバイダー選択
# AIP_PROVIDER指定 → デフォルト → 利用可能な最初のプロバイダー
# ============================================================
_aip_select_provider() {
    local required_capabilities="${1:-text}"

    # v109.0: 最適選択が有効なら使う（明示指定がない場合）
    local target="${AIP_PROVIDER:-}"
    if [[ -z "$target" && "${AIP_USE_OPTIMAL_SELECTION:-false}" == "true" ]]; then
        target=$(aip_select_optimal "${AIP_CURRENT_TASK_TYPE:-code_generation}" "${DOMAIN_TYPE:-general}" 2>/dev/null)
    fi
    target="${target:-$AIP_DEFAULT_PROVIDER}"

    # 指定プロバイダーが利用可能か確認
    if [[ -n "${_AIP_PROVIDER_GENERATE_FN[$target]:-}" ]]; then
        if [[ "${_AIP_PROVIDER_STATUS[$target]:-}" != "unavailable" ]]; then
            echo "$target"
            return 0
        fi
    fi

    # フェイルオーバー: 利用可能なプロバイダーを探す
    if [[ "$AIP_AUTO_FAILOVER" == "true" ]]; then
        for provider in "${_AIP_PROVIDERS[@]}"; do
            if [[ "${_AIP_PROVIDER_STATUS[$provider]:-}" != "unavailable" ]]; then
                # capability チェック
                local caps="${_AIP_PROVIDER_CAPABILITIES[$provider]:-}"
                local has_all=true
                IFS=',' read -ra req_caps <<< "$required_capabilities"
                for cap in "${req_caps[@]}"; do
                    if [[ "$caps" != *"$cap"* ]]; then
                        has_all=false
                        break
                    fi
                done
                if $has_all; then
                    echo "$provider"
                    return 0
                fi
            fi
        done
    fi

    echo ""
    return 1
}

# ============================================================
# Pre-hooks: AI呼び出し前の共通処理
# ============================================================
_aip_pre_hooks() {
    local prompt="$1"
    local phase="$2"
    local domain="$3"

    # --- Trace開始 ---
    if type -t trace_begin_span &>/dev/null; then
        trace_begin_span "ai_call" "$phase" 2>/dev/null || true
    fi

    # --- Audit記録 ---
    if [[ "$AIP_ENABLE_AUDIT" == "true" ]] && type -t obs_emit_event &>/dev/null; then
        obs_emit_event "AI_CALL_START" "{\"call\":${AIP_CALL_COUNT},\"phase\":\"${phase}\",\"domain\":\"${domain}\",\"provider\":\"${AIP_PROVIDER:-$AIP_DEFAULT_PROVIDER}\",\"prompt_len\":${#prompt}}" 2>/dev/null || true
    fi

    # --- Cost Gate: 予算チェック ---
    if [[ "$AIP_ENABLE_COST_GATE" == "true" && "${CG_ENABLED:-false}" == "true" ]] && type -t cg_pre_phase_gate &>/dev/null; then
        if ! cg_pre_phase_gate "$phase" 2>/dev/null; then
            echo -e "${RED:-}  [AIP] Cost Gate: 予算超過 - AI呼び出しをブロック${NC:-}" >&2
            return 1
        fi
    fi

    # --- AI Governance: 承認チェック ---
    if [[ "${ENABLE_AI_GOVERNANCE:-true}" == "true" ]] && type -t aig_check_approval &>/dev/null; then
        if ! aig_check_approval "$phase" "$domain" "0" "AI generation for ${phase}" 2>/dev/null; then
            echo -e "${RED:-}  [AIP] Governance: 操作がブロックされました${NC:-}" >&2
            return 1
        fi
    fi

    return 0
}

# ============================================================
# Post-hooks: AI呼び出し後の共通処理
# ============================================================
_aip_post_hooks_success() {
    local result="$1"
    local phase="$2"
    local provider="$3"

    # --- Cost Gate: 実績記録 ---
    if [[ "$AIP_ENABLE_COST_GATE" == "true" && "${CG_ENABLED:-false}" == "true" ]] && type -t cg_record_actual &>/dev/null; then
        cg_record_actual "$phase" "0.08" 2>/dev/null || true
    fi

    # --- Learning Hub: 呼び出し記録 ---
    if [[ "$AIP_ENABLE_LEARNING" == "true" ]] && type -t lh_record_call &>/dev/null; then
        lh_record_call "$phase" "0" "${#result}" "1" "balanced" "0" "0" "" "0" 2>/dev/null || true
    fi

    # --- Memory保存 ---
    if type -t mm_store_short &>/dev/null; then
        mm_store_short "${phase}_output" "${result:0:500}" 2>/dev/null || true
    fi

    # --- Knowledge DB: 成功記録 ---
    if type -t kdb_record_phase_result &>/dev/null; then
        kdb_record_phase_result "$phase" "${DOMAIN_TYPE:-general}" "true" "0" "provider=${provider},chars=${#result}" 2>/dev/null || true
    fi

    # --- AI Governance: 出力安全性検証 ---
    if [[ "${ENABLE_AI_GOVERNANCE:-true}" == "true" ]] && type -t aig_validate_output &>/dev/null; then
        aig_validate_output "$result" "$phase" 2>/dev/null || true
    fi

    # --- Observatory: 成功イベント ---
    if [[ "$AIP_ENABLE_AUDIT" == "true" ]] && type -t obs_emit_event &>/dev/null; then
        obs_emit_event "AI_CALL_OK" "{\"call\":${AIP_CALL_COUNT},\"phase\":\"${phase}\",\"provider\":\"${provider}\",\"result_chars\":${#result}}" 2>/dev/null || true
    fi

    # --- Trace終了 ---
    if type -t trace_end_span &>/dev/null; then
        trace_end_span "" "ok" 2>/dev/null || true
    fi
}

_aip_post_hooks_failure() {
    local phase="$1"
    local provider="$2"
    local error_msg="${3:-unknown}"

    # --- Knowledge DB: 失敗記録 ---
    if type -t kdb_record_phase_result &>/dev/null; then
        kdb_record_phase_result "$phase" "${DOMAIN_TYPE:-general}" "false" "0" "provider=${provider},error=${error_msg}" 2>/dev/null || true
    fi

    # --- Observatory: 失敗イベント ---
    if [[ "$AIP_ENABLE_AUDIT" == "true" ]] && type -t obs_emit_event &>/dev/null; then
        obs_emit_event "AI_CALL_FAIL" "{\"call\":${AIP_CALL_COUNT},\"phase\":\"${phase}\",\"provider\":\"${provider}\",\"error\":\"${error_msg}\"}" 2>/dev/null || true
    fi

    # --- Error Chain記録 ---
    if type -t ec_record_error &>/dev/null; then
        ec_record_error "AI call failure: ${error_msg}" "$phase" "" 2>/dev/null || true
    fi

    # --- Trace終了 ---
    if type -t trace_end_span &>/dev/null; then
        trace_end_span "" "error" 2>/dev/null || true
    fi
}

# ============================================================
# プロンプト強化（プロバイダー非依存の共通強化）
# ============================================================
_aip_enhance_prompt() {
    local prompt="$1"
    local phase="$2"
    local domain="$3"

    # --- v55.1: プロンプト品質バリデーション ---
    local _pq_len=${#prompt}
    case "$phase" in
        implementation|backend|frontend|api|database)
            if [[ $_pq_len -lt 500 ]]; then
                prompt+="

=== 品質ルール自動注入（v101.0 AI Provider） ===
- 全データはDB永続化必須（モックデータ/インメモリ配列禁止）
- 全APIエンドポイントにzodバリデーション必須
- 全async関数にtry-catch + 適切なエラーレスポンス必須
- TypeScript strict mode必須
- サービス層分離必須"
            fi
            ;;
    esac

    # --- Enterprise Patterns注入 ---
    if [[ -n "$phase" ]] && type -t ep_inject_for_phase &>/dev/null; then
        prompt=$(ep_inject_for_phase "$prompt" "$phase" 2>/dev/null || echo "$prompt")
    fi

    # --- Cross-Session Intelligence注入 ---
    if type -t cs_inject_warnings &>/dev/null && [[ ${CS_TOTAL_SESSIONS:-0} -gt 0 ]] 2>/dev/null; then
        prompt=$(cs_inject_warnings "$prompt" "$domain" 2>/dev/null || echo "$prompt")
    fi
    if type -t cs_inject_best_practices &>/dev/null && [[ ${CS_TOTAL_SESSIONS:-0} -gt 2 ]] 2>/dev/null; then
        prompt=$(cs_inject_best_practices "$prompt" "$domain" 2>/dev/null || echo "$prompt")
    fi

    # --- Prompt Evolution ---
    if type -t pev_mutate_prompt &>/dev/null && [[ "${PEV_ENABLED:-false}" == "true" ]]; then
        prompt=$(pev_mutate_prompt "$prompt" "$domain" "$phase" 2>/dev/null || echo "$prompt")
    fi

    # --- Business Context Engine: ドメイン知識注入 ---
    if [[ "${ENABLE_BUSINESS_CONTEXT:-true}" == "true" ]] && type -t bce_inject_context &>/dev/null; then
        prompt=$(bce_inject_context "$prompt" "$domain" "$phase" 2>/dev/null || echo "$prompt")
    fi

    # --- Domain References: ドメイン別参照実装注入 ---
    if [[ "${ENABLE_DOMAIN_REFERENCES:-true}" == "true" ]] && type -t dr_inject_for_prompt &>/dev/null; then
        prompt=$(dr_inject_for_prompt "$prompt" "$domain" "$phase" 2>/dev/null || echo "$prompt")
    fi

    # --- Error Intelligence: 既知パターン防止注入 ---
    if [[ "${ENABLE_ERROR_INTELLIGENCE:-true}" == "true" ]] && type -t ei_build_prevention_prompt &>/dev/null; then
        local _prevention
        _prevention=$(ei_build_prevention_prompt 2>/dev/null || echo "")
        if [[ -n "$_prevention" ]]; then
            prompt+="

${_prevention}"
        fi
    fi

    echo "$prompt"
}

# ============================================================
# ai_call() - 統一AIエントリーポイント
#
# 全AI呼び出しはここを通る。プロバイダー非依存。
# 既存のcb2_call()/_call_claude()はこの関数に委譲する。
#
# 引数:
#   $1 - prompt (テキスト)
#   $2 - output_file (省略可: 結果をファイルに書く)
#   $3 - phase (省略可: "implementation")
#   $4 - domain (省略可: "general")
#
# 環境変数オプション（AIP_*）:
#   AIP_PROVIDER      - プロバイダー指定 (default: $AIP_DEFAULT_PROVIDER)
#   AIP_SYSTEM_PROMPT  - システムプロンプト（プロバイダーが対応していれば使用）
#   AIP_APPEND_CONTEXT - 追加コンテキスト
#   AIP_MODEL_TIER     - モデルtier (frontier/balanced/economy)
#   AIP_MAX_BUDGET     - 1回あたりの予算上限
#   AIP_TIMEOUT        - タイムアウト(秒)
#   AIP_MAX_RETRIES    - 最大リトライ回数
#   AIP_JSON_SCHEMA    - 構造化出力のJSONスキーマ
#   AIP_AGENT_FILE     - エージェントファイルパス
#   AIP_SKIP_ENHANCE   - "true"でプロンプト強化をスキップ
#   AIP_SKIP_PRE_HOOKS - "true"でpre-hooksをスキップ
#   AIP_SKIP_POST_HOOKS - "true"でpost-hooksをスキップ
# ============================================================
ai_call() {
    local prompt="$1"
    local output_file="${2:-}"
    local phase="${3:-implementation}"
    local domain="${4:-general}"

    AIP_CALL_COUNT=$((AIP_CALL_COUNT + 1))

    # --- ステップ1: プロバイダー選択 ---
    local required_caps="text"
    [[ -n "${AIP_JSON_SCHEMA:-}" ]] && required_caps="text,structured"

    local provider
    provider=$(_aip_select_provider "$required_caps")
    if [[ -z "$provider" ]]; then
        echo -e "${RED:-}  [AIP] 利用可能なAIプロバイダーがありません${NC:-}" >&2
        AIP_TOTAL_CALLS_FAIL=$((AIP_TOTAL_CALLS_FAIL + 1))
        return 1
    fi

    # --- ステップ2: Pre-hooks ---
    if [[ "${AIP_SKIP_PRE_HOOKS:-}" != "true" && "$AIP_ENABLE_PRE_HOOKS" == "true" ]]; then
        if ! _aip_pre_hooks "$prompt" "$phase" "$domain"; then
            AIP_TOTAL_CALLS_FAIL=$((AIP_TOTAL_CALLS_FAIL + 1))
            return 1
        fi
    fi

    # --- ステップ3: プロンプト強化（プロバイダー非依存） ---
    if [[ "${AIP_SKIP_ENHANCE:-}" != "true" ]]; then
        prompt=$(_aip_enhance_prompt "$prompt" "$phase" "$domain")
    fi

    # --- ステップ4: ログ記録 ---
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        printf '[%s] ai_call#%d provider=%s phase=%s domain=%s prompt_len=%d\n' \
            "$(date '+%Y-%m-%d %H:%M:%S')" "$AIP_CALL_COUNT" "$provider" "$phase" "$domain" \
            "${#prompt}" \
            >> "${SESSION_LOG_DIR}/ai_calls.log" 2>/dev/null || true
    fi

    # --- ステップ5: プロバイダーにディスパッチ ---
    local generate_fn="${_AIP_PROVIDER_GENERATE_FN[$provider]}"
    local result=""
    local rc=0

    if type -t "$generate_fn" &>/dev/null; then
        result=$("$generate_fn" "$prompt" "$output_file" "$phase" "$domain" 2>/dev/null)
        rc=$?
    else
        echo -e "${RED:-}  [AIP] プロバイダー '${provider}' のgenerate関数が見つかりません${NC:-}" >&2
        rc=1
    fi

    # --- ステップ6: 結果処理 ---
    if [[ $rc -eq 0 && -n "$result" ]]; then
        # ファイル出力（プロバイダーが直接書いていない場合）
        if [[ -n "$output_file" && ! -s "$output_file" ]]; then
            mkdir -p "$(dirname "$output_file")" 2>/dev/null || true
            printf '%s\n' "$result" > "$output_file"
        fi

        # Post-hooks (成功)
        if [[ "${AIP_SKIP_POST_HOOKS:-}" != "true" && "$AIP_ENABLE_POST_HOOKS" == "true" ]]; then
            _aip_post_hooks_success "$result" "$phase" "$provider"
        fi

        AIP_TOTAL_CALLS_OK=$((AIP_TOTAL_CALLS_OK + 1))

        # stdout出力（output_file指定がない場合）
        if [[ -z "$output_file" ]]; then
            printf '%s\n' "$result"
        fi

        # ログ記録
        if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
            printf '[%s] ai_call#%d SUCCESS provider=%s result_chars=%d\n' \
                "$(date '+%Y-%m-%d %H:%M:%S')" "$AIP_CALL_COUNT" "$provider" "${#result}" \
                >> "${SESSION_LOG_DIR}/ai_calls.log" 2>/dev/null || true
        fi

        return 0
    else
        # Post-hooks (失敗)
        if [[ "${AIP_SKIP_POST_HOOKS:-}" != "true" && "$AIP_ENABLE_POST_HOOKS" == "true" ]]; then
            _aip_post_hooks_failure "$phase" "$provider" "rc=${rc}"
        fi

        AIP_TOTAL_CALLS_FAIL=$((AIP_TOTAL_CALLS_FAIL + 1))

        # プロバイダー状態更新
        if [[ "$AIP_AUTO_FAILOVER" == "true" ]]; then
            _AIP_PROVIDER_STATUS["$provider"]="degraded"
        fi

        return 1
    fi
}

# ============================================================
# ai_call_structured() - 構造化出力付きAI呼び出し
# ============================================================
ai_call_structured() {
    local prompt="$1"
    local json_schema="$2"
    local phase="${3:-implementation}"
    local domain="${4:-general}"

    local provider
    provider=$(_aip_select_provider "text,structured")

    if [[ -n "$provider" ]]; then
        local structured_fn="${_AIP_PROVIDER_STRUCTURED_FN[$provider]:-}"
        if [[ -n "$structured_fn" ]] && type -t "$structured_fn" &>/dev/null; then
            "$structured_fn" "$prompt" "$json_schema" "$phase" "$domain"
            return $?
        fi
    fi

    # フォールバック: 通常のai_callにスキーマを注入
    AIP_JSON_SCHEMA="$json_schema" ai_call "$prompt" "" "$phase" "$domain"
}

# ============================================================
# ユーティリティ
# ============================================================

# プロバイダー一覧取得
aip_list_providers() {
    for provider in "${_AIP_PROVIDERS[@]}"; do
        local status="${_AIP_PROVIDER_STATUS[$provider]:-unknown}"
        local caps="${_AIP_PROVIDER_CAPABILITIES[$provider]:-}"
        local ver="${_AIP_PROVIDER_VERSION[$provider]:-}"
        echo "  ${provider} v${ver} [${status}] caps=(${caps})"
    done
}

# ヘルスチェック
aip_health_check() {
    for provider in "${_AIP_PROVIDERS[@]}"; do
        local health_fn="${_AIP_PROVIDER_HEALTH_FN[$provider]:-}"
        if [[ -n "$health_fn" ]] && type -t "$health_fn" &>/dev/null; then
            local status
            status=$("$health_fn" 2>/dev/null || echo "unavailable")
            _AIP_PROVIDER_STATUS["$provider"]="$status"
        fi
    done
}

# ============================================================
# v101.0 AGI能力契約: 品質フィードバック
# quality-gateの結果をプロバイダーの品質記録にフィードバック
# ============================================================
aip_record_quality() {
    local provider="${1:-$AIP_DEFAULT_PROVIDER}"
    local quality_score="${2:-0}"
    local capability="${3:-code_generation}"

    # 直近10回の品質スコアを保持
    local hist="${_AIP_PROVIDER_CALL_HIST[$provider]:-}"
    local count
    count=$(echo "$hist" | tr ',' '\n' | grep -c '[0-9]' 2>/dev/null || echo "0")

    if [[ $count -ge 10 ]]; then
        # 最古のエントリを削除
        hist=$(echo "$hist" | sed 's/^[0-9]*,//')
    fi

    if [[ -n "$hist" ]]; then
        hist="${hist},${quality_score}"
    else
        hist="$quality_score"
    fi
    _AIP_PROVIDER_CALL_HIST["$provider"]="$hist"

    # 平均計算
    local sum=0 cnt=0
    IFS=',' read -ra scores <<< "$hist"
    for s in "${scores[@]}"; do
        [[ -z "$s" ]] && continue
        sum=$((sum + s))
        cnt=$((cnt + 1))
    done
    if [[ $cnt -gt 0 ]]; then
        _AIP_PROVIDER_QUALITY["$provider"]=$((sum / cnt))
    fi

    # 能力契約チェック: 品質が契約基準を下回る場合は警告
    local contract_threshold="${_AIP_CAPABILITY_CONTRACTS[$capability]:-80}"
    local avg="${_AIP_PROVIDER_QUALITY[$provider]:-0}"
    if [[ $avg -gt 0 && $avg -lt $contract_threshold ]]; then
        echo -e "${YELLOW:-}  [AIP] 警告: ${provider}の${capability}品質(${avg})が契約基準(${contract_threshold})を下回っています${NC:-}" >&2
        # プロバイダーをdegradedに設定
        _AIP_PROVIDER_STATUS["$provider"]="degraded"
    fi
}

# プロバイダー品質レポート
aip_quality_report() {
    echo "--- Provider Quality Report ---"
    for provider in "${_AIP_PROVIDERS[@]}"; do
        local avg="${_AIP_PROVIDER_QUALITY[$provider]:-N/A}"
        local hist="${_AIP_PROVIDER_CALL_HIST[$provider]:-}"
        echo "  ${provider}: avg=${avg} history=[${hist}]"
    done
    echo "--- Capability Contracts ---"
    for cap in "${!_AIP_CAPABILITY_CONTRACTS[@]}"; do
        echo "  ${cap}: min_quality=${_AIP_CAPABILITY_CONTRACTS[$cap]}"
    done
}

# ============================================================
# v101.0 宣言的タスク実行
# AIに「何をさせるか」をデータとして定義し、HOWはプロバイダーに任せる
# AGI時代: タスク定義は不変、実行方法だけがAGIに最適化される
# ============================================================
ai_execute_task() {
    local task_type="$1"    # code_generation, schema_design, error_correction, etc.
    local intent="$2"       # 何を達成したいか（自然言語）
    local context="$3"      # 追加コンテキスト（ファイル内容等）
    local output_file="${4:-}"
    local phase="${5:-implementation}"
    local domain="${6:-general}"

    # タスク型に応じてプロンプト構造を最適化
    local prompt=""
    case "$task_type" in
        code_generation)
            prompt="## タスク: コード生成
## 達成すべきこと
${intent}

## コンテキスト
${context}

## 出力形式
--- FILE: path --- マーカー付きで全ファイルを出力してください"
            ;;
        error_correction)
            prompt="## タスク: エラー修正
## 修正すべきエラー
${intent}

## 現在のコード
${context}

## 出力形式
修正後のコードを --- FILE: path --- マーカー付きで全ファイル出力してください"
            ;;
        schema_design)
            prompt="## タスク: データベース設計
## 要件
${intent}

## コンテキスト
${context}

## 出力形式
Prismaスキーマ(schema.prisma)を出力してください"
            ;;
        *)
            prompt="${intent}

${context}"
            ;;
    esac

    # ai_call経由で実行（プロバイダー非依存）
    ai_call "$prompt" "$output_file" "$phase" "$domain"
    local rc=$?

    # 品質記録（quality-gate結果が利用可能な場合）
    if type -t rv_validate_project &>/dev/null && [[ -n "$output_file" ]]; then
        local q_score=50
        if [[ ${RV_TOTAL_ERRORS:-0} -eq 0 ]]; then
            q_score=90
        elif [[ ${RV_TOTAL_ERRORS:-0} -lt 5 ]]; then
            q_score=70
        fi
        aip_record_quality "${AIP_PROVIDER:-$AIP_DEFAULT_PROVIDER}" "$q_score" "$task_type"
    fi

    return $rc
}

# ============================================================
# v109.0 プロバイダーベンチマーク評価
# ============================================================

# 指定プロバイダーでベンチマークを実行し品質スコアを記録
aip_evaluate_provider() {
    local provider_name="${1:-$AIP_DEFAULT_PROVIDER}"
    local benchmark_name="${2:-simple-crud}"

    # ベンチマークスイートが利用可能か確認
    if ! type -t bs_run_benchmark &>/dev/null; then
        echo "  [AIP] Benchmark Suite not available. Cannot evaluate provider." >&2
        return 1
    fi

    # ベンチマークが存在するか確認
    if ! type -t bs_get_benchmark &>/dev/null; then
        echo "  [AIP] bs_get_benchmark not available." >&2
        return 1
    fi

    local bench_config
    bench_config=$(bs_get_benchmark "$benchmark_name" 2>/dev/null)
    if [[ -z "$bench_config" ]]; then
        echo "  [AIP] Benchmark '${benchmark_name}' not found." >&2
        return 1
    fi

    echo "  [AIP] Evaluating provider '${provider_name}' with benchmark '${benchmark_name}'..." >&2

    # プロバイダーを一時的に切り替え
    local original_provider="${AIP_PROVIDER:-$AIP_DEFAULT_PROVIDER}"
    AIP_PROVIDER="$provider_name"

    # ベンチマーク実行
    local result
    result=$(bs_run_benchmark "$benchmark_name" "${PROJECT_DIR:-./output}" 2>/dev/null)
    local rc=$?

    # プロバイダーを復元
    AIP_PROVIDER="$original_provider"

    # 結果からスコア抽出
    local score
    score=$(echo "$result" | sed -n 's/.*"composite_score":\([0-9]*\).*/\1/p')
    score=${score:-0}

    # 品質記録
    aip_record_quality "$provider_name" "$score" "benchmark_${benchmark_name}"

    # 評価結果を永続化
    local eval_dir="${HOME}/.soloptilink/provider-evaluations"
    mkdir -p "$eval_dir" 2>/dev/null || true
    local eval_record="{\"timestamp\":\"$(date '+%Y-%m-%dT%H:%M:%S')\",\"provider\":\"${provider_name}\",\"benchmark\":\"${benchmark_name}\",\"score\":${score},\"verdict\":\"$([ $rc -eq 0 ] && echo 'PASS' || echo 'FAIL')\"}"
    echo "$eval_record" >> "${eval_dir}/evaluations.jsonl" 2>/dev/null || true

    echo "  [AIP] Provider '${provider_name}' scored ${score} on '${benchmark_name}'" >&2
    echo "$result"
    return $rc
}

# ============================================================
# v109.0 最適プロバイダー選択
# task_type + domain の組み合わせで最高品質のプロバイダーを選択
# ============================================================
aip_select_optimal() {
    local task_type="${1:-code_generation}"
    local domain="${2:-general}"

    local best_provider=""
    local best_score=0

    for provider in "${_AIP_PROVIDERS[@]}"; do
        # 利用不可プロバイダーはスキップ
        [[ "${_AIP_PROVIDER_STATUS[$provider]:-}" == "unavailable" ]] && continue

        # 品質スコア取得
        local avg_quality="${_AIP_PROVIDER_QUALITY[$provider]:-0}"

        # 能力契約チェック: task_typeに対応する契約基準を満たすか
        local contract_threshold="${_AIP_CAPABILITY_CONTRACTS[$task_type]:-80}"
        if [[ $avg_quality -gt 0 && $avg_quality -lt $contract_threshold ]]; then
            # 契約基準未達 → ペナルティ（ただし候補には残す）
            avg_quality=$((avg_quality - 10))
        fi

        # ドメインボーナス: プロバイダーの履歴にドメイン関連データがあれば+5
        local hist="${_AIP_PROVIDER_CALL_HIST[$provider]:-}"
        if [[ -n "$hist" ]]; then
            # 履歴があるプロバイダーは実績あり → 小ボーナス
            avg_quality=$((avg_quality + 5))
        fi

        if [[ $avg_quality -gt $best_score ]]; then
            best_score=$avg_quality
            best_provider="$provider"
        fi
    done

    # データ不足の場合はデフォルト
    if [[ -z "$best_provider" || $best_score -le 0 ]]; then
        best_provider="${AIP_DEFAULT_PROVIDER}"
    fi

    echo "$best_provider"
    return 0
}

# ============================================================
# v109.0 プロバイダー統計取得
# ============================================================
aip_get_provider_stats() {
    echo "=== Provider Statistics ==="

    for provider in "${_AIP_PROVIDERS[@]}"; do
        local status="${_AIP_PROVIDER_STATUS[$provider]:-unknown}"
        local avg_quality="${_AIP_PROVIDER_QUALITY[$provider]:-N/A}"
        local hist="${_AIP_PROVIDER_CALL_HIST[$provider]:-}"
        local ver="${_AIP_PROVIDER_VERSION[$provider]:-}"
        local caps="${_AIP_PROVIDER_CAPABILITIES[$provider]:-}"

        # 呼び出し回数計算
        local call_count=0
        if [[ -n "$hist" ]]; then
            call_count=$(echo "$hist" | tr ',' '\n' | grep -c '[0-9]' 2>/dev/null || echo "0")
        fi

        # 平均レイテンシ推定（コスト関数から推定、実測値は別途必要）
        local avg_latency="N/A"
        local cost_fn="${_AIP_PROVIDER_COST_FN[$provider]:-}"
        local estimated_cost="N/A"
        if [[ -n "$cost_fn" ]] && type -t "$cost_fn" &>/dev/null; then
            estimated_cost=$("$cost_fn" "estimate" 2>/dev/null || echo "N/A")
        fi

        echo "  --- ${provider} v${ver} [${status}] ---"
        echo "    Capabilities: ${caps}"
        echo "    Recorded calls: ${call_count}"
        echo "    Avg quality: ${avg_quality}"
        echo "    Estimated cost/call: ${estimated_cost}"
        echo "    Score history: [${hist:-none}]"

        # 能力契約達成状況
        if [[ "$avg_quality" != "N/A" && "$avg_quality" -gt 0 ]] 2>/dev/null; then
            local contracts_met=0
            local contracts_total=0
            for cap in "${!_AIP_CAPABILITY_CONTRACTS[@]}"; do
                contracts_total=$((contracts_total + 1))
                local threshold="${_AIP_CAPABILITY_CONTRACTS[$cap]}"
                if [[ $avg_quality -ge $threshold ]]; then
                    contracts_met=$((contracts_met + 1))
                fi
            done
            echo "    Contracts met: ${contracts_met}/${contracts_total}"
        fi
    done

    # セッション全体の統計
    echo ""
    echo "  --- Session Totals ---"
    echo "    Total calls: ${AIP_CALL_COUNT}"
    echo "    Successful: ${AIP_TOTAL_CALLS_OK}"
    echo "    Failed: ${AIP_TOTAL_CALLS_FAIL}"
    if [[ $AIP_CALL_COUNT -gt 0 ]]; then
        local success_rate=$(( (AIP_TOTAL_CALLS_OK * 100) / AIP_CALL_COUNT ))
        echo "    Success rate: ${success_rate}%"
    fi
    echo "    Default provider: ${AIP_DEFAULT_PROVIDER}"

    return 0
}

# レポート
aip_report() {
    echo "=== AI Provider Abstraction Layer v${AIP_VERSION} ==="
    echo "  Total calls: ${AIP_CALL_COUNT} (OK: ${AIP_TOTAL_CALLS_OK}, Fail: ${AIP_TOTAL_CALLS_FAIL})"
    echo "  Default provider: ${AIP_DEFAULT_PROVIDER}"
    echo "  Registered providers: ${#_AIP_PROVIDERS[@]}"
    aip_list_providers
}

# スコア（品質メトリクス用）
aip_score() {
    if [[ $AIP_CALL_COUNT -eq 0 ]]; then
        echo "100"
        return
    fi
    local success_rate
    success_rate=$(( (AIP_TOTAL_CALLS_OK * 100) / AIP_CALL_COUNT ))
    echo "$success_rate"
}

# ============================================================
# v191: Phase-based provider routing
# フェーズ別に最適なAIプロバイダーを自動選択
# ============================================================
aip_select_provider_for_phase() {
    local phase="$1"
    local budget_remaining="${2:-999}"

    case "$phase" in
        scaffold|prompt_expand|requirements)
            # Use cheaper model for non-critical phases
            echo "${AIP_ECONOMY_PROVIDER:-claude-haiku}"
            ;;
        implementation|frontend|backend|api)
            # Use strongest model for code generation
            if [[ "$budget_remaining" -gt 50 ]]; then
                echo "${AIP_PRIMARY_PROVIDER:-claude-sonnet}"
            else
                echo "${AIP_ECONOMY_PROVIDER:-claude-haiku}"
            fi
            ;;
        quality_gate|healing)
            # Use medium model for validation
            echo "${AIP_SECONDARY_PROVIDER:-claude-sonnet}"
            ;;
        *)
            echo "${AIP_DEFAULT_PROVIDER:-claude-sonnet}"
            ;;
    esac
}

# ============================================================
# Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "ai-provider" \
        --version "$AIP_VERSION" \
        --description "AI Provider Abstraction Layer - AGI対応プロバイダー抽象化 + v191 Phase-based routing" \
        --init "aip_init" \
        --report "aip_report" \
        --score "aip_score" \
        --enable-var "ENABLE_AI_PROVIDER" \
        --cli-flags "--ai-provider:--no-ai-provider"
fi

# v2003.1: source時のexit codeを確実に0にする
true
