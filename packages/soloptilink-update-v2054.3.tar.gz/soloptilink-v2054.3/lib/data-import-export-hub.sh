#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v316.0 - Data Import/Export Hub
# =============================================================================
# データインポート/エクスポートハブ: CSVインポート/API同期/Webhook受信/定期エクスポート
#
# 全globals: DIEH_ prefix
# =============================================================================

[[ -n "${_DATA_IMPORT_EXPORT_HUB_LOADED:-}" ]] && return 0
_DATA_IMPORT_EXPORT_HUB_LOADED=1

declare -g DIEH_VERSION="316.0"
declare -g DIEH_INITIALIZED=false
declare -g DIEH_GENERATED_COUNT=0
declare -g ENABLE_DATA_IMPORT_EXPORT_HUB="${ENABLE_DATA_IMPORT_EXPORT_HUB:-true}"

readonly DIEH_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly DIEH_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly DIEH_BOLD="${CLR_BOLD:-\033[1m}"
readonly DIEH_NC="${CLR_NC:-\033[0m}"

_dieh_log() { echo -e "  ${DIEH_CYAN}[DIEH]${DIEH_NC} $*" >&2; }
_dieh_ok()  { echo -e "  ${DIEH_GREEN}[DIEH] OK${DIEH_NC} $*" >&2; }

dieh_init() { DIEH_INITIALIZED=true; DIEH_GENERATED_COUNT=0; return 0; }
dieh_report() { [[ "$DIEH_INITIALIZED" != "true" ]] && return 0; echo -e "\n  ${DIEH_BOLD}--- Data Import/Export Hub v${DIEH_VERSION} ---${DIEH_NC}" >&2; echo -e "  生成数: ${DIEH_GENERATED_COUNT}" >&2; }
dieh_score() { [[ "$DIEH_INITIALIZED" != "true" ]] && { echo "0"; return; }; local s=50; [[ $DIEH_GENERATED_COUNT -ge 3 ]] && s=85; echo "$s"; }
dieh_init_message() { echo -e "  ${DIEH_GREEN}v${DIEH_VERSION} data-import-export-hub: データ入出力ハブ自動生成${DIEH_NC}" >&2; }

_dieh_generate_csv_import() {
    local project_dir="${1:-.}"
    _dieh_log "CSVインポートウィザード生成"
    local comp_dir="${project_dir}/src/components/data"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/CsvImportWizard.tsx" <<'EOF'
'use client';
import { useState, useRef } from 'react';
import { Upload, FileText, CheckCircle, AlertTriangle, ArrowRight } from 'lucide-react';

type Step = 'upload' | 'mapping' | 'preview' | 'importing' | 'done';

interface CsvImportWizardProps { targetEntity: string; requiredFields: string[]; onComplete?: (result: any) => void; }

export function CsvImportWizard({ targetEntity, requiredFields, onComplete }: CsvImportWizardProps) {
  const [step, setStep] = useState<Step>('upload');
  const [file, setFile] = useState<File | null>(null);
  const [headers, setHeaders] = useState<string[]>([]);
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [preview, setPreview] = useState<any[]>([]);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  const parseCSV = (text: string) => {
    const lines = text.split('\n').filter(l => l.trim());
    const hdrs = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    const rows = lines.slice(1).map(line => {
      const vals = line.split(',').map(v => v.trim().replace(/^"|"$/g, ''));
      return Object.fromEntries(hdrs.map((h, i) => [h, vals[i] || '']));
    });
    return { headers: hdrs, rows };
  };

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f);
    const text = await f.text();
    const { headers: hdrs, rows } = parseCSV(text);
    setHeaders(hdrs);
    setPreview(rows.slice(0, 5));
    const autoMap: Record<string, string> = {};
    requiredFields.forEach(rf => { const match = hdrs.find(h => h.toLowerCase() === rf.toLowerCase()); if (match) autoMap[rf] = match; });
    setMapping(autoMap);
    setStep('mapping');
  };

  const handleImport = async () => {
    setStep('importing');
    setError('');
    try {
      const formData = new FormData();
      formData.append('file', file!);
      formData.append('mapping', JSON.stringify(mapping));
      formData.append('entity', targetEntity);
      const res = await fetch('/api/data/import/csv', { method: 'POST', body: formData });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Import failed');
      setResult(data);
      setStep('done');
      onComplete?.(data);
    } catch (e: any) { setError(e.message); setStep('preview'); }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex gap-2 mb-6">{(['upload', 'mapping', 'preview', 'done'] as Step[]).map((s, i) => (
        <div key={s} className={`flex-1 h-2 rounded ${['upload','mapping','preview','importing','done'].indexOf(step) >= i ? 'bg-blue-600' : 'bg-gray-200'}`} />
      ))}</div>

      {step === 'upload' && (
        <div className="text-center py-12 border-2 border-dashed rounded-lg hover:border-blue-400 cursor-pointer" onClick={() => fileRef.current?.click()}>
          <Upload size={48} className="mx-auto text-gray-400 mb-4" />
          <p className="font-medium">CSVファイルをアップロード</p>
          <p className="text-sm text-gray-500 mt-1">クリックまたはドラッグ＆ドロップ</p>
          <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={handleFile} />
        </div>
      )}

      {step === 'mapping' && (
        <div className="space-y-4">
          <h3 className="font-semibold">フィールドマッピング</h3>
          {requiredFields.map(rf => (
            <div key={rf} className="flex items-center gap-4">
              <span className="w-32 text-sm font-medium">{rf} <span className="text-red-500">*</span></span>
              <ArrowRight size={16} className="text-gray-400" />
              <select value={mapping[rf] || ''} onChange={e => setMapping({ ...mapping, [rf]: e.target.value })} className="border rounded px-3 py-2 text-sm flex-1">
                <option value="">-- 選択 --</option>{headers.map(h => <option key={h} value={h}>{h}</option>)}
              </select>
            </div>
          ))}
          <button onClick={() => setStep('preview')} disabled={requiredFields.some(rf => !mapping[rf])}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg disabled:opacity-50">プレビュー</button>
        </div>
      )}

      {step === 'preview' && (
        <div className="space-y-4">
          <h3 className="font-semibold">プレビュー（先頭5件）</h3>
          {error && <p className="text-red-600 text-sm">{error}</p>}
          <div className="overflow-auto"><table className="w-full text-sm border">
            <thead><tr>{requiredFields.map(f => <th key={f} className="border px-2 py-1 bg-gray-50">{f}</th>)}</tr></thead>
            <tbody>{preview.map((row, i) => <tr key={i}>{requiredFields.map(f => <td key={f} className="border px-2 py-1">{row[mapping[f]] || '-'}</td>)}</tr>)}</tbody>
          </table></div>
          <div className="flex gap-3">
            <button onClick={() => setStep('mapping')} className="px-4 py-2 border rounded-lg">戻る</button>
            <button onClick={handleImport} className="bg-blue-600 text-white px-6 py-2 rounded-lg">インポート実行</button>
          </div>
        </div>
      )}

      {step === 'importing' && <div className="text-center py-12"><div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4" /><p>インポート中...</p></div>}

      {step === 'done' && result && (
        <div className="text-center py-12">
          <CheckCircle size={48} className="mx-auto text-green-500 mb-4" />
          <p className="font-semibold text-lg">インポート完了</p>
          <p className="text-gray-500 mt-2">{result.imported || 0}件インポート / {result.errors || 0}件エラー</p>
        </div>
      )}
    </div>
  );
}
EOF

    DIEH_GENERATED_COUNT=$((DIEH_GENERATED_COUNT + 1))
    _dieh_ok "CSVインポートウィザード生成完了"
    return 0
}

_dieh_generate_api_sync() {
    local project_dir="${1:-.}"
    _dieh_log "API同期生成"
    local lib_dir="${project_dir}/src/lib"
    mkdir -p "$lib_dir"

    cat > "${lib_dir}/api-sync.ts" <<'EOF'
interface SyncConfig { name: string; sourceUrl: string; headers?: Record<string, string>; method?: string; body?: any; transform?: (data: any) => any[]; targetEntity: string; idField?: string; schedule?: string; }

export class ApiSyncEngine {
  private configs: SyncConfig[] = [];

  register(config: SyncConfig) { this.configs.push(config); }

  async sync(name: string): Promise<{ synced: number; errors: number; duration: number }> {
    const config = this.configs.find(c => c.name === name);
    if (!config) throw new Error(`Sync config '${name}' not found`);

    const start = Date.now();
    let synced = 0, errors = 0;

    try {
      const res = await fetch(config.sourceUrl, {
        method: config.method || 'GET',
        headers: { 'Content-Type': 'application/json', ...config.headers },
        body: config.body ? JSON.stringify(config.body) : undefined,
      });
      if (!res.ok) throw new Error(`API responded with ${res.status}`);
      let data = await res.json();
      if (config.transform) data = config.transform(data);
      if (!Array.isArray(data)) data = [data];

      for (const item of data) {
        try {
          await fetch(`/api/data/sync/upsert`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ entity: config.targetEntity, data: item, idField: config.idField || 'id' }),
          });
          synced++;
        } catch { errors++; }
      }
    } catch (e) { errors++; }

    return { synced, errors, duration: Date.now() - start };
  }

  async syncAll() {
    const results: Record<string, any> = {};
    for (const config of this.configs) {
      results[config.name] = await this.sync(config.name);
    }
    return results;
  }
}

export const apiSync = new ApiSyncEngine();
EOF

    DIEH_GENERATED_COUNT=$((DIEH_GENERATED_COUNT + 1))
    _dieh_ok "API同期エンジン生成完了"
    return 0
}

_dieh_generate_webhook_receiver() {
    local project_dir="${1:-.}"
    _dieh_log "Webhook受信API生成"
    local api_dir="${project_dir}/src/app/api/webhooks/receive"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';

function verifySignature(payload: string, signature: string, secret: string): boolean {
  const expected = crypto.createHmac('sha256', secret).update(payload).digest('hex');
  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
}

export async function POST(req: NextRequest) {
  try {
    const source = req.nextUrl.searchParams.get('source') || 'generic';
    const rawBody = await req.text();
    const signature = req.headers.get('x-webhook-signature') || req.headers.get('x-hub-signature-256') || '';

    // Verify signature if secret is configured
    const secret = process.env[`WEBHOOK_SECRET_${source.toUpperCase()}`];
    if (secret && signature) {
      const sig = signature.replace('sha256=', '');
      if (!verifySignature(rawBody, sig, secret)) {
        return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
      }
    }

    const payload = JSON.parse(rawBody);
    const event = req.headers.get('x-webhook-event') || payload.event || 'unknown';

    // Store webhook event for processing
    // await prisma.webhookEvent.create({ data: { source, event, payload, status: 'PENDING' } });

    // Process based on source
    console.log(`[Webhook] Received: ${source}/${event}`, { payloadSize: rawBody.length });

    return NextResponse.json({ received: true, source, event });
  } catch (error) {
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 });
  }
}
EOF

    DIEH_GENERATED_COUNT=$((DIEH_GENERATED_COUNT + 1))
    _dieh_ok "Webhook受信API生成完了"
    return 0
}

_dieh_generate_export_scheduler() {
    local project_dir="${1:-.}"
    _dieh_log "定期エクスポートAPI生成"
    local api_dir="${project_dir}/src/app/api/data/export/scheduled"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

interface ExportJob { entity: string; format: 'csv' | 'json'; filters?: Record<string, any>; recipients?: string[]; }

export async function POST(req: NextRequest) {
  try {
    const { entity, format, filters, recipients } = await req.json() as ExportJob;
    if (!entity || !format) return NextResponse.json({ error: 'entity and format required' }, { status: 400 });

    // Fetch data dynamically
    const modelDelegate = (prisma as any)[entity];
    if (!modelDelegate) return NextResponse.json({ error: `Unknown entity: ${entity}` }, { status: 400 });

    const data = await modelDelegate.findMany({ where: filters || {}, take: 10000 });

    if (format === 'csv' && data.length > 0) {
      const headers = Object.keys(data[0]);
      const csv = [headers.join(','), ...data.map((r: any) => headers.map(h => `"${String(r[h] ?? '').replace(/"/g, '""')}"`).join(','))].join('\n');
      return new NextResponse(csv, { headers: { 'Content-Type': 'text/csv', 'Content-Disposition': `attachment; filename="${entity}-export.csv"` } });
    }

    return NextResponse.json({ data, count: data.length, entity, format });
  } catch (error) {
    return NextResponse.json({ error: 'Export failed' }, { status: 500 });
  }
}
EOF

    DIEH_GENERATED_COUNT=$((DIEH_GENERATED_COUNT + 1))
    _dieh_ok "定期エクスポート生成完了"
    return 0
}

_mr_register \
    --name "data-import-export-hub" \
    --version "316.0" \
    --description "データ入出力ハブ（CSVインポート/API同期/Webhook受信/定期エクスポート）" \
    --init "dieh_init" \
    --report "dieh_report" \
    --score "dieh_score" \
    --enable-var "ENABLE_DATA_IMPORT_EXPORT_HUB" \
    --cli-flags "--data-hub:--no-data-hub" \
    --init-msg "dieh_init_message"
