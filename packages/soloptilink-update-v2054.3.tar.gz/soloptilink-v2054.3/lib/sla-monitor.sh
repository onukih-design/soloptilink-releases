#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v358.0 - SLA Monitor
# =============================================================================
# SLA定義×メトリクス追跡×レポート生成
#
# 機能:
#   - SLA定義（可用性/レイテンシ/エラー率/スループット）
#   - リアルタイムSLI追跡
#   - エラーバジェット計算
#   - SLAレポート・ダッシュボード生成
#   - SLA違反アラート
#
# 全globals: SLM_ prefix
# =============================================================================

[[ -n "${_SLM_LOADED:-}" ]] && return 0; _SLM_LOADED=1

SLM_VERSION="358.0"
SLM_GENERATED=0
SLM_ERRORS=0
SLM_PHASE="sla_monitor"
SLM_FILES_CREATED=()

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_slm_log() { echo -e "  ${CYAN}[SLM]${NC} $*"; }
_slm_ok() { echo -e "  ${GREEN}[SLM]${NC} $*"; }
_slm_err() { echo -e "  ${RED}[SLM]${NC} $*"; }

_slm_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        SLM_FILES_CREATED+=("$filepath")
        SLM_GENERATED=$((SLM_GENERATED + 1))
        _slm_ok "Created: ${filepath##*/}"
    else
        SLM_ERRORS=$((SLM_ERRORS + 1))
        _slm_err "Failed: ${filepath##*/}"
    fi
}

slm_init() {
    SLM_GENERATED=0; SLM_ERRORS=0; SLM_FILES_CREATED=()
    _slm_log "SLA Monitor v${SLM_VERSION} initialized"
    return 0
}

# =============================================================================
# Define SLA
# =============================================================================
_slm_define_sla() {
    local project_dir="${1:-.}"

    _slm_log "Generating SLA definition system..."

    local sla_dir="${project_dir}/src/lib/sla"
    mkdir -p "$sla_dir" 2>/dev/null

    _slm_write_file "${sla_dir}/sla-config.ts" "$(cat <<'TS'
import { z } from 'zod';

export const SLOSchema = z.object({
  name: z.string(),
  metric: z.enum(['availability', 'latency_p50', 'latency_p99', 'error_rate', 'throughput']),
  target: z.number(),
  unit: z.enum(['percent', 'ms', 'rps']),
  window: z.enum(['rolling_30d', 'rolling_7d', 'calendar_month']),
});

export const SLASchema = z.object({
  id: z.string(),
  name: z.string(),
  service: z.string(),
  tier: z.enum(['platinum', 'gold', 'silver', 'bronze']),
  slos: z.array(SLOSchema),
  errorBudgetPolicy: z.object({
    burnRateAlertThresholds: z.array(z.object({
      burnRate: z.number(),
      windowMinutes: z.number(),
      severity: z.enum(['warning', 'critical']),
    })),
  }),
  createdAt: z.string().datetime(),
});

export type SLO = z.infer<typeof SLOSchema>;
export type SLA = z.infer<typeof SLASchema>;

export const DEFAULT_SLA: SLA = {
  id: 'sla-production',
  name: 'Production API SLA',
  service: 'api',
  tier: 'gold',
  slos: [
    { name: 'Availability', metric: 'availability', target: 99.9, unit: 'percent', window: 'rolling_30d' },
    { name: 'Latency P50', metric: 'latency_p50', target: 200, unit: 'ms', window: 'rolling_30d' },
    { name: 'Latency P99', metric: 'latency_p99', target: 1000, unit: 'ms', window: 'rolling_30d' },
    { name: 'Error Rate', metric: 'error_rate', target: 0.1, unit: 'percent', window: 'rolling_30d' },
  ],
  errorBudgetPolicy: {
    burnRateAlertThresholds: [
      { burnRate: 14.4, windowMinutes: 60, severity: 'critical' },
      { burnRate: 6, windowMinutes: 360, severity: 'critical' },
      { burnRate: 3, windowMinutes: 1440, severity: 'warning' },
      { burnRate: 1, windowMinutes: 4320, severity: 'warning' },
    ],
  },
  createdAt: new Date().toISOString(),
};
TS
)"

    _slm_ok "SLA definition system generated"
}

# =============================================================================
# Track Metrics
# =============================================================================
_slm_track_metrics() {
    local project_dir="${1:-.}"

    _slm_log "Generating SLI tracking system..."

    local sla_dir="${project_dir}/src/lib/sla"
    mkdir -p "$sla_dir" 2>/dev/null

    _slm_write_file "${sla_dir}/tracker.ts" "$(cat <<'TS'
import type { SLA, SLO } from './sla-config';

interface SLIDataPoint {
  metric: string;
  value: number;
  timestamp: Date;
}

interface ErrorBudgetStatus {
  sloName: string;
  target: number;
  current: number;
  budgetTotal: number;
  budgetRemaining: number;
  budgetConsumedPercent: number;
  burnRate: number;
  projectedExhaustionDate: Date | null;
}

export class SLATracker {
  private dataPoints: SLIDataPoint[] = [];
  private sla: SLA;

  constructor(sla: SLA) {
    this.sla = sla;
  }

  record(metric: string, value: number): void {
    this.dataPoints.push({ metric, value, timestamp: new Date() });
    // Keep last 30 days
    const cutoff = Date.now() - 30 * 86400000;
    this.dataPoints = this.dataPoints.filter(d => d.timestamp.getTime() > cutoff);
  }

  getSLIValue(metric: string, windowDays = 30): number {
    const cutoff = Date.now() - windowDays * 86400000;
    const relevant = this.dataPoints.filter(d => d.metric === metric && d.timestamp.getTime() > cutoff);
    if (relevant.length === 0) return 0;
    return relevant.reduce((sum, d) => sum + d.value, 0) / relevant.length;
  }

  getErrorBudget(): ErrorBudgetStatus[] {
    return this.sla.slos.map(slo => {
      const current = this.getSLIValue(slo.metric);
      const budgetTotal = slo.metric === 'availability'
        ? 100 - slo.target
        : slo.target * 0.1;
      const consumed = slo.metric === 'availability'
        ? Math.max(0, slo.target - current)
        : Math.max(0, current - slo.target);
      const remaining = Math.max(0, budgetTotal - consumed);
      const burnRate = budgetTotal > 0 ? consumed / budgetTotal : 0;

      let projectedExhaustion: Date | null = null;
      if (burnRate > 0 && remaining > 0) {
        const msPerUnit = 30 * 86400000 / budgetTotal;
        projectedExhaustion = new Date(Date.now() + remaining * msPerUnit / burnRate);
      }

      return {
        sloName: slo.name,
        target: slo.target,
        current,
        budgetTotal,
        budgetRemaining: remaining,
        budgetConsumedPercent: budgetTotal > 0 ? (consumed / budgetTotal) * 100 : 0,
        burnRate,
        projectedExhaustionDate: projectedExhaustion,
      };
    });
  }
}
TS
)"

    _slm_ok "SLI tracking system generated"
}

# =============================================================================
# Generate Report
# =============================================================================
_slm_generate_report() {
    local project_dir="${1:-.}"

    _slm_log "Generating SLA report dashboard..."

    local dash_dir="${project_dir}/src/app/admin/sla"
    mkdir -p "$dash_dir" 2>/dev/null

    _slm_write_file "${dash_dir}/page.tsx" "$(cat <<'TSX'
'use client';
import { useEffect, useState } from 'react';

interface BudgetStatus {
  sloName: string;
  target: number;
  current: number;
  budgetRemaining: number;
  budgetConsumedPercent: number;
  burnRate: number;
}

export default function SLADashboard() {
  const [budgets, setBudgets] = useState<BudgetStatus[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/v1/admin/sla/status')
      .then(r => r.json())
      .then(data => { setBudgets(data.budgets || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-8">Loading SLA data...</div>;

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">SLA Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {budgets.map(b => {
          const statusColor = b.budgetConsumedPercent < 50 ? 'green' : b.budgetConsumedPercent < 80 ? 'yellow' : 'red';
          return (
            <div key={b.sloName} className="border rounded-lg p-6">
              <h3 className="font-semibold text-lg">{b.sloName}</h3>
              <div className="mt-2 space-y-2">
                <div className="flex justify-between">
                  <span>Target</span><span className="font-mono">{b.target}</span>
                </div>
                <div className="flex justify-between">
                  <span>Current</span><span className="font-mono">{b.current.toFixed(2)}</span>
                </div>
                <div className="w-full bg-gray-200 rounded h-3 mt-2">
                  <div className={`h-3 rounded bg-${statusColor}-500`}
                    style={{ width: `${Math.min(100, b.budgetConsumedPercent)}%` }} />
                </div>
                <div className="text-sm text-gray-500">
                  Error Budget: {b.budgetConsumedPercent.toFixed(1)}% consumed
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
TSX
)"

    _slm_ok "SLA report dashboard generated"
}

# =============================================================================
# Report / Score / Register
# =============================================================================
slm_report() {
    echo -e "\n  ${BOLD}=== SLA Monitor v${SLM_VERSION} ===${NC}"
    echo -e "  生成ファイル数 : ${SLM_GENERATED}"
    echo -e "  エラー         : ${SLM_ERRORS}"
    if [[ ${#SLM_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${SLM_FILES_CREATED[@]}"; do echo -e "    - ${f}"; done
    fi
}

slm_score() {
    if [[ ${SLM_GENERATED} -ge 3 ]] && [[ ${SLM_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${SLM_GENERATED} -gt 0 ]] && [[ ${SLM_ERRORS} -eq 0 ]]; then echo "90"
    elif [[ ${SLM_GENERATED} -gt 0 ]]; then echo "70"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "sla-monitor" --version "358.0" \
        --description "SLA定義×メトリクス追跡×エラーバジェット×レポート" \
        --init "slm_init" --report "slm_report" --score "slm_score" \
        --enable-var "ENABLE_SLA_MONITOR" --cli-flags "--sla-monitor:--no-sla-monitor"
fi

# v2003.1: source時のexit codeを確実に0にする
true
