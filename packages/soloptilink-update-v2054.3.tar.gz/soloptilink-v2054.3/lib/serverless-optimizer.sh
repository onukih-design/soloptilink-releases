#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v440.0 - Serverless Optimizer
# =============================================================================
# サーバーレス環境の最適化。コールドスタート軽減、メモリ設定最適化、
# デプロイ設定の生成を行う。Lambda/Vercel/Cloudflare Workers対応。
#
# Functions:
#   _so2_init()                - 初期化
#   _so2_optimize_cold_start() - コールドスタート最適化
#   _so2_optimize_memory()     - メモリ設定最適化
#   _so2_generate_config()     - サーバーレス設定生成
#   _so2_report() / _so2_score()
#
# All globals use the SO2_ prefix.
# =============================================================================

[[ -n "${_SO2_LOADED:-}" ]] && return 0; _SO2_LOADED=1

declare -g SO2_VERSION="440.0"
declare -g SO2_GENERATED=0
declare -g SO2_ERRORS=0
declare -g SO2_PLATFORM=""
declare -g SO2_FUNCTIONS_COUNT=0
declare -g SO2_COLD_START_ISSUES=0
declare -g SO2_MEMORY_OPTIMIZED=0
declare -g SO2_CONFIG_GENERATED=false

declare -ga _SO2_FINDINGS=()

_SO2_GREEN="${GREEN:-\033[0;32m}"
_SO2_RED="${RED:-\033[0;31m}"
_SO2_YELLOW="${YELLOW:-\033[0;33m}"
_SO2_CYAN="${CYAN:-\033[0;36m}"
_SO2_BOLD="${BOLD:-\033[1m}"
_SO2_NC="${NC:-\033[0m}"

_so2_init() {
    SO2_GENERATED=0; SO2_ERRORS=0; SO2_PLATFORM=""
    SO2_FUNCTIONS_COUNT=0; SO2_COLD_START_ISSUES=0
    SO2_MEMORY_OPTIMIZED=0; SO2_CONFIG_GENERATED=false
    _SO2_FINDINGS=()
    return 0
}

_so2_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_SO2_CYAN}[SO2]${_SO2_NC} $*" >&2 ;;
        ok)    echo -e "  ${_SO2_GREEN}[SO2]${_SO2_NC} $*" >&2 ;;
        warn)  echo -e "  ${_SO2_YELLOW}[SO2]${_SO2_NC} $*" >&2 ;;
        error) echo -e "  ${_SO2_RED}[SO2]${_SO2_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _so2_optimize_cold_start - コールドスタート最適化
# =============================================================================
_so2_optimize_cold_start() {
    local project_dir="${1:-.}"
    _so2_log info "コールドスタート最適化"

    SO2_COLD_START_ISSUES=0

    # プラットフォーム検出
    if [[ -f "${project_dir}/serverless.yml" ]] || [[ -f "${project_dir}/serverless.yaml" ]]; then
        SO2_PLATFORM="serverless-framework"
    elif [[ -f "${project_dir}/vercel.json" ]]; then
        SO2_PLATFORM="vercel"
    elif [[ -f "${project_dir}/wrangler.toml" ]]; then
        SO2_PLATFORM="cloudflare"
    elif [[ -f "${project_dir}/template.yaml" ]] || [[ -f "${project_dir}/template.yml" ]]; then
        SO2_PLATFORM="aws-sam"
    elif [[ -f "${project_dir}/cdk.json" ]]; then
        SO2_PLATFORM="aws-cdk"
    fi

    # トップレベルimportの分析
    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"
        SO2_FUNCTIONS_COUNT=$((SO2_FUNCTIONS_COUNT + 1))

        # 重いモジュールのトップレベルimport
        local heavy_imports=0
        local heavy_modules=("aws-sdk" "@aws-sdk" "sharp" "puppeteer" "canvas" "pdf-lib" "xlsx" "nodemailer")

        for mod in "${heavy_modules[@]}"; do
            if grep -q "^import.*${mod}\|^const.*require.*${mod}" "$file" 2>/dev/null; then
                heavy_imports=$((heavy_imports + 1))
                _SO2_FINDINGS+=("HEAVY_IMPORT:${rel}:${mod} at top level - use lazy import")
            fi
        done

        if [[ $heavy_imports -gt 0 ]]; then
            SO2_COLD_START_ISSUES=$((SO2_COLD_START_ISSUES + 1))
            _so2_log warn "重いインポート: ${rel} (${heavy_imports}個)"
        fi

        # DB接続をハンドラ外で初期化
        local global_db
        global_db=$(grep -n "new PrismaClient\|createConnection\|connect(" "$file" 2>/dev/null | head -1)
        if [[ -n "$global_db" ]]; then
            local line_num="${global_db%%:*}"
            local in_handler
            in_handler=$(sed -n "1,${line_num}p" "$file" 2>/dev/null | grep -c "export.*handler\|export.*GET\|export.*POST" || echo 0)
            if [[ $in_handler -eq 0 ]]; then
                _SO2_FINDINGS+=("GLOBAL_DB:${rel}:DB connection at module level - reuse across invocations (good)")
            fi
        fi
    done < <(find "$project_dir" \( -name "route.ts" -o -name "handler.ts" -o -name "index.ts" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" \
             \( -path "*/api/*" -o -path "*/lambda/*" -o -path "*/functions/*" \) \
             -print0 2>/dev/null)

    # Provisioned Concurrency推奨
    if [[ "$SO2_PLATFORM" == "aws-"* ]] || [[ "$SO2_PLATFORM" == "serverless-framework" ]]; then
        _SO2_FINDINGS+=("PROVISIONED:consider Provisioned Concurrency for critical paths")
    fi

    ECS_GENERATED=$((SO2_GENERATED + 1))
    _so2_log ok "コールドスタート問題: ${SO2_COLD_START_ISSUES}件 (${SO2_FUNCTIONS_COUNT}関数)"
    return 0
}

# =============================================================================
# _so2_optimize_memory - メモリ設定最適化
# =============================================================================
_so2_optimize_memory() {
    local project_dir="${1:-.}"
    _so2_log info "メモリ設定最適化"

    SO2_MEMORY_OPTIMIZED=0

    case "$SO2_PLATFORM" in
        serverless-framework)
            local config="${project_dir}/serverless.yml"
            [[ ! -f "$config" ]] && config="${project_dir}/serverless.yaml"
            if [[ -f "$config" ]]; then
                local has_memory
                has_memory=$(grep -c "memorySize:" "$config" 2>/dev/null || echo 0)
                if [[ $has_memory -eq 0 ]]; then
                    _SO2_FINDINGS+=("SLS_MEMORY:serverless.yml should set memorySize (1024MB recommended)")
                    SO2_MEMORY_OPTIMIZED=$((SO2_MEMORY_OPTIMIZED + 1))
                fi
                local has_timeout
                has_timeout=$(grep -c "timeout:" "$config" 2>/dev/null || echo 0)
                if [[ $has_timeout -eq 0 ]]; then
                    _SO2_FINDINGS+=("SLS_TIMEOUT:serverless.yml should set timeout (30s max for API Gateway)")
                fi
            fi
            ;;
        vercel)
            if [[ -f "${project_dir}/vercel.json" ]]; then
                local has_fn_config
                has_fn_config=$(grep -c "functions\|maxDuration" "${project_dir}/vercel.json" 2>/dev/null || echo 0)
                if [[ $has_fn_config -eq 0 ]]; then
                    _SO2_FINDINGS+=("VERCEL_FN:vercel.json should configure functions.maxDuration")
                    SO2_MEMORY_OPTIMIZED=$((SO2_MEMORY_OPTIMIZED + 1))
                fi
            fi
            ;;
        aws-sam|aws-cdk)
            _SO2_FINDINGS+=("AWS_POWER:consider AWS Lambda Power Tuning for optimal memory/cost")
            SO2_MEMORY_OPTIMIZED=$((SO2_MEMORY_OPTIMIZED + 1))
            ;;
    esac

    # バンドルサイズの確認
    local dist_size=0
    for dir in ".next" "dist" ".serverless" ".vercel/output"; do
        if [[ -d "${project_dir}/${dir}" ]]; then
            local size
            size=$(du -sk "${project_dir}/${dir}" 2>/dev/null | cut -f1 || echo 0)
            dist_size=$((dist_size + size))
        fi
    done

    if [[ $dist_size -gt 50000 ]]; then  # 50MB以上
        _SO2_FINDINGS+=("BUNDLE_SIZE:deployment bundle is ${dist_size}KB - consider optimization")
        SO2_MEMORY_OPTIMIZED=$((SO2_MEMORY_OPTIMIZED + 1))
    fi

    SO2_GENERATED=$((SO2_GENERATED + 1))
    _so2_log ok "メモリ最適化: ${SO2_MEMORY_OPTIMIZED}件推奨"
    return 0
}

# =============================================================================
# _so2_generate_config - サーバーレス設定生成
# =============================================================================
_so2_generate_config() {
    local project_dir="${1:-.}"
    _so2_log info "サーバーレス設定生成"

    SO2_CONFIG_GENERATED=false

    case "$SO2_PLATFORM" in
        vercel)
            _SO2_FINDINGS+=("VERCEL_CONFIG:optimize vercel.json for serverless performance")
            ;;
        serverless-framework)
            _SO2_FINDINGS+=("SLS_CONFIG:optimize serverless.yml with esbuild bundler")
            ;;
        cloudflare)
            _SO2_FINDINGS+=("CF_CONFIG:optimize wrangler.toml for Workers performance")
            ;;
        *)
            _so2_log info "汎用サーバーレス推奨を生成"
            ;;
    esac

    # 共通推奨
    _SO2_FINDINGS+=("KEEP_ALIVE:use HTTP keep-alive for external API calls in serverless")
    _SO2_FINDINGS+=("CONNECTION_REUSE:reuse DB connections across invocations with global scope")
    _SO2_FINDINGS+=("LOGGING:use structured JSON logging for serverless observability")

    SO2_CONFIG_GENERATED=true
    SO2_GENERATED=$((SO2_GENERATED + 1))
    _so2_log ok "設定生成完了: platform=${SO2_PLATFORM:-generic}"
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_so2_report() {
    echo -e "\n  ${_SO2_BOLD}=== serverless-optimizer v${SO2_VERSION} ===${_SO2_NC}"
    echo -e "  プラットフォーム: ${SO2_PLATFORM:-unknown}"
    echo -e "  関数数          : ${SO2_FUNCTIONS_COUNT}"
    echo -e "  CS問題          : ${SO2_COLD_START_ISSUES}"
    echo -e "  メモリ最適化    : ${SO2_MEMORY_OPTIMIZED}"
    echo -e "  設定生成        : ${SO2_CONFIG_GENERATED}"
    echo -e "  エラー          : ${SO2_ERRORS}"
}

_so2_score() {
    local score=50
    [[ -n "$SO2_PLATFORM" ]] && score=$((score + 10))
    [[ ${SO2_COLD_START_ISSUES} -eq 0 ]] && score=$((score + 15))
    [[ "$SO2_CONFIG_GENERATED" == "true" ]] && score=$((score + 10))
    [[ ${SO2_MEMORY_OPTIMIZED} -gt 0 ]] && score=$((score + 10))
    [[ ${SO2_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "serverless-optimizer" --version "${SO2_VERSION}" \
        --description "サーバーレス最適化×コールドスタート×メモリ×設定生成 (v440)" \
        --init "_so2_init" --report "_so2_report" --score "_so2_score" \
        --enable-var "ENABLE_SERVERLESS_OPT" --cli-flags "--serverless-opt:--no-serverless-opt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
