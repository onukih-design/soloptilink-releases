#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v423.0 - Smart Caching Layer
# =============================================================================
# AI生成結果・中間成果物のスマートキャッシュ層。TTL管理、LRU eviction、
# 依存ベースinvalidation、圧縮保存を提供し、再実行時間を大幅削減する。
#
# Functions:
#   _scl_init()            - 初期化
#   _scl_init_cache()      - キャッシュストア初期化
#   _scl_check_cache()     - キャッシュルックアップ
#   _scl_store_result()    - 結果をキャッシュに保存
#   _scl_invalidate()      - キャッシュ無効化
#   _scl_report() / _scl_score()
#
# All globals use the SCL_ prefix.
# =============================================================================

[[ -n "${_SCL_LOADED:-}" ]] && return 0; _SCL_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g SCL_VERSION="423.0"
declare -g SCL_GENERATED=0
declare -g SCL_ERRORS=0
declare -g SCL_HITS=0
declare -g SCL_MISSES=0
declare -g SCL_EVICTIONS=0
declare -g SCL_INVALIDATIONS=0
declare -g SCL_STORE_COUNT=0
declare -g SCL_CACHE_DIR="${SCL_CACHE_DIR:-.soloptilink/cache/smart}"
declare -g SCL_MAX_ENTRIES="${SCL_MAX_ENTRIES:-500}"
declare -g SCL_DEFAULT_TTL="${SCL_DEFAULT_TTL:-3600}"
declare -g SCL_COMPRESSION="${SCL_COMPRESSION:-true}"

declare -gA _SCL_ENTRIES=()
declare -gA _SCL_TTL_MAP=()
declare -gA _SCL_ACCESS_TIME=()

_SCL_GREEN="${GREEN:-\033[0;32m}"
_SCL_RED="${RED:-\033[0;31m}"
_SCL_YELLOW="${YELLOW:-\033[0;33m}"
_SCL_CYAN="${CYAN:-\033[0;36m}"
_SCL_BOLD="${BOLD:-\033[1m}"
_SCL_NC="${NC:-\033[0m}"

# =============================================================================
# Init
# =============================================================================
_scl_init() {
    SCL_GENERATED=0
    SCL_ERRORS=0
    SCL_HITS=0
    SCL_MISSES=0
    SCL_EVICTIONS=0
    SCL_INVALIDATIONS=0
    SCL_STORE_COUNT=0
    _SCL_ENTRIES=()
    _SCL_TTL_MAP=()
    _SCL_ACCESS_TIME=()
    return 0
}

_scl_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_SCL_CYAN}[SCL]${_SCL_NC} $*" >&2 ;;
        ok)    echo -e "  ${_SCL_GREEN}[SCL]${_SCL_NC} $*" >&2 ;;
        warn)  echo -e "  ${_SCL_YELLOW}[SCL]${_SCL_NC} $*" >&2 ;;
        error) echo -e "  ${_SCL_RED}[SCL]${_SCL_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _scl_init_cache - キャッシュストア初期化
# =============================================================================
_scl_init_cache() {
    local cache_dir="${1:-$SCL_CACHE_DIR}"
    SCL_CACHE_DIR="$cache_dir"

    _scl_log info "キャッシュストア初期化: ${cache_dir}"
    mkdir -p "${cache_dir}/data" "${cache_dir}/meta" 2>/dev/null

    # 既存キャッシュメタデータを読み込み
    if [[ -f "${cache_dir}/meta/index.txt" ]]; then
        local loaded=0
        while IFS='|' read -r key hash ttl atime; do
            [[ -z "$key" ]] && continue
            _SCL_ENTRIES["$key"]="$hash"
            _SCL_TTL_MAP["$key"]="$ttl"
            _SCL_ACCESS_TIME["$key"]="$atime"
            loaded=$((loaded + 1))
        done < "${cache_dir}/meta/index.txt"
        _scl_log ok "既存キャッシュ読込: ${loaded}エントリ"
    fi

    # 期限切れエントリを削除
    _scl_evict_expired

    SCL_GENERATED=$((SCL_GENERATED + 1))
    return 0
}

# =============================================================================
# _scl_check_cache - キャッシュルックアップ
# =============================================================================
_scl_check_cache() {
    local key="$1"
    local cache_file="${SCL_CACHE_DIR}/data/$(echo "$key" | sha256sum 2>/dev/null | cut -d' ' -f1 || echo "$key" | md5 2>/dev/null || echo "$key")"

    # エントリ存在チェック
    if [[ -z "${_SCL_ENTRIES[$key]:-}" ]]; then
        SCL_MISSES=$((SCL_MISSES + 1))
        return 1
    fi

    # TTLチェック
    local ttl="${_SCL_TTL_MAP[$key]:-$SCL_DEFAULT_TTL}"
    local atime="${_SCL_ACCESS_TIME[$key]:-0}"
    local now
    now=$(date +%s 2>/dev/null || echo 0)
    local age=$((now - atime))

    if [[ $age -gt $ttl ]]; then
        _scl_log info "キャッシュ期限切れ: ${key} (${age}s > ${ttl}s)"
        unset "_SCL_ENTRIES[$key]"
        unset "_SCL_TTL_MAP[$key]"
        unset "_SCL_ACCESS_TIME[$key]"
        rm -f "$cache_file" 2>/dev/null
        SCL_MISSES=$((SCL_MISSES + 1))
        return 1
    fi

    # キャッシュファイル存在チェック
    if [[ ! -f "$cache_file" ]]; then
        SCL_MISSES=$((SCL_MISSES + 1))
        return 1
    fi

    # アクセス時刻更新
    _SCL_ACCESS_TIME["$key"]="$now"

    SCL_HITS=$((SCL_HITS + 1))

    # キャッシュ内容を返す
    if [[ "$SCL_COMPRESSION" == "true" ]] && command -v gzip &>/dev/null && [[ -f "${cache_file}.gz" ]]; then
        gzip -dc "${cache_file}.gz" 2>/dev/null
    else
        cat "$cache_file" 2>/dev/null
    fi

    return 0
}

# =============================================================================
# _scl_store_result - 結果をキャッシュに保存
# =============================================================================
_scl_store_result() {
    local key="$1"
    local content="$2"
    local ttl="${3:-$SCL_DEFAULT_TTL}"

    local key_hash
    key_hash=$(echo "$key" | sha256sum 2>/dev/null | cut -d' ' -f1 || echo "$key" | md5 2>/dev/null || echo "$key")
    local cache_file="${SCL_CACHE_DIR}/data/${key_hash}"

    # LRU eviction: 上限チェック
    if [[ ${#_SCL_ENTRIES[@]} -ge $SCL_MAX_ENTRIES ]]; then
        _scl_evict_lru
    fi

    # 保存
    mkdir -p "$(dirname "$cache_file")" 2>/dev/null
    if [[ "$SCL_COMPRESSION" == "true" ]] && command -v gzip &>/dev/null; then
        printf '%s\n' "$content" | gzip -c > "${cache_file}.gz" 2>/dev/null
    else
        printf '%s\n' "$content" > "$cache_file" 2>/dev/null
    fi

    local now
    now=$(date +%s 2>/dev/null || echo 0)
    local content_hash
    content_hash=$(echo "$content" | sha256sum 2>/dev/null | cut -d' ' -f1 || echo "none")

    _SCL_ENTRIES["$key"]="$content_hash"
    _SCL_TTL_MAP["$key"]="$ttl"
    _SCL_ACCESS_TIME["$key"]="$now"

    SCL_STORE_COUNT=$((SCL_STORE_COUNT + 1))

    # メタデータインデックス更新
    _scl_save_index

    return 0
}

# =============================================================================
# _scl_invalidate - キャッシュ無効化
# =============================================================================
_scl_invalidate() {
    local pattern="${1:-}"

    if [[ -z "$pattern" ]]; then
        _scl_log warn "全キャッシュ無効化"
        _SCL_ENTRIES=()
        _SCL_TTL_MAP=()
        _SCL_ACCESS_TIME=()
        rm -rf "${SCL_CACHE_DIR}/data/"* 2>/dev/null
        SCL_INVALIDATIONS=$((SCL_INVALIDATIONS + 1))
        _scl_save_index
        return 0
    fi

    local invalidated=0
    local keys_to_remove=()
    for key in "${!_SCL_ENTRIES[@]}"; do
        if [[ "$key" == *"$pattern"* ]]; then
            keys_to_remove+=("$key")
        fi
    done

    for key in "${keys_to_remove[@]}"; do
        local key_hash
        key_hash=$(echo "$key" | sha256sum 2>/dev/null | cut -d' ' -f1 || echo "$key")
        rm -f "${SCL_CACHE_DIR}/data/${key_hash}" "${SCL_CACHE_DIR}/data/${key_hash}.gz" 2>/dev/null
        unset "_SCL_ENTRIES[$key]"
        unset "_SCL_TTL_MAP[$key]"
        unset "_SCL_ACCESS_TIME[$key]"
        invalidated=$((invalidated + 1))
    done

    SCL_INVALIDATIONS=$((SCL_INVALIDATIONS + invalidated))
    _scl_save_index
    _scl_log ok "無効化完了: ${invalidated}エントリ (パターン: ${pattern})"

    return 0
}

# =============================================================================
# Internal helpers
# =============================================================================
_scl_evict_lru() {
    local oldest_key=""
    local oldest_time=999999999999

    for key in "${!_SCL_ACCESS_TIME[@]}"; do
        local atime="${_SCL_ACCESS_TIME[$key]}"
        if [[ $atime -lt $oldest_time ]]; then
            oldest_time=$atime
            oldest_key="$key"
        fi
    done

    if [[ -n "$oldest_key" ]]; then
        local key_hash
        key_hash=$(echo "$oldest_key" | sha256sum 2>/dev/null | cut -d' ' -f1 || echo "$oldest_key")
        rm -f "${SCL_CACHE_DIR}/data/${key_hash}" "${SCL_CACHE_DIR}/data/${key_hash}.gz" 2>/dev/null
        unset "_SCL_ENTRIES[$oldest_key]"
        unset "_SCL_TTL_MAP[$oldest_key]"
        unset "_SCL_ACCESS_TIME[$oldest_key]"
        SCL_EVICTIONS=$((SCL_EVICTIONS + 1))
    fi
}

_scl_evict_expired() {
    local now
    now=$(date +%s 2>/dev/null || echo 0)
    local expired=0

    local keys_to_remove=()
    for key in "${!_SCL_TTL_MAP[@]}"; do
        local ttl="${_SCL_TTL_MAP[$key]}"
        local atime="${_SCL_ACCESS_TIME[$key]:-0}"
        if [[ $((now - atime)) -gt $ttl ]]; then
            keys_to_remove+=("$key")
        fi
    done

    for key in "${keys_to_remove[@]}"; do
        unset "_SCL_ENTRIES[$key]"
        unset "_SCL_TTL_MAP[$key]"
        unset "_SCL_ACCESS_TIME[$key]"
        expired=$((expired + 1))
    done

    SCL_EVICTIONS=$((SCL_EVICTIONS + expired))
}

_scl_save_index() {
    local index_file="${SCL_CACHE_DIR}/meta/index.txt"
    mkdir -p "$(dirname "$index_file")" 2>/dev/null
    : > "$index_file"
    for key in "${!_SCL_ENTRIES[@]}"; do
        echo "${key}|${_SCL_ENTRIES[$key]}|${_SCL_TTL_MAP[$key]:-$SCL_DEFAULT_TTL}|${_SCL_ACCESS_TIME[$key]:-0}" >> "$index_file"
    done
}

# =============================================================================
# Report & Score
# =============================================================================
_scl_report() {
    local total=$((SCL_HITS + SCL_MISSES))
    local hit_rate=0
    [[ $total -gt 0 ]] && hit_rate=$((SCL_HITS * 100 / total))

    echo -e "\n  ${_SCL_BOLD}=== smart-caching-layer v${SCL_VERSION} ===${_SCL_NC}"
    echo -e "  ヒット数        : ${SCL_HITS}"
    echo -e "  ミス数          : ${SCL_MISSES}"
    echo -e "  ヒット率        : ${hit_rate}%"
    echo -e "  保存数          : ${SCL_STORE_COUNT}"
    echo -e "  Eviction数      : ${SCL_EVICTIONS}"
    echo -e "  無効化数        : ${SCL_INVALIDATIONS}"
    echo -e "  エラー          : ${SCL_ERRORS}"
}

_scl_score() {
    local score=50
    [[ ${SCL_STORE_COUNT} -gt 0 ]] && score=$((score + 10))
    [[ ${SCL_HITS} -gt 0 ]] && score=$((score + 15))
    local total=$((SCL_HITS + SCL_MISSES))
    if [[ $total -gt 0 ]]; then
        local rate=$((SCL_HITS * 100 / total))
        [[ $rate -ge 50 ]] && score=$((score + 15))
    fi
    [[ ${SCL_ERRORS} -eq 0 ]] && score=$((score + 10))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "smart-caching-layer" --version "${SCL_VERSION}" \
        --description "スマートキャッシュ×LRU×TTL×圧縮×依存invalidation (v423)" \
        --init "_scl_init" --report "_scl_report" --score "_scl_score" \
        --enable-var "ENABLE_SMART_CACHE" --cli-flags "--smart-cache:--no-smart-cache"
fi

# v2003.1: source時のexit codeを確実に0にする
true
