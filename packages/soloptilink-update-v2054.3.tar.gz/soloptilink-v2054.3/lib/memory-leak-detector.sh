#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v276.0 - Memory Leak Detector
# =============================================================================
# メモリリークの原因となるパターンを静的解析で検出。
# イベントリスナー、タイマー、サブスクリプション、クロージャの
# クリーンアップ漏れを検出し、修正コードを生成する。
#
# Functions:
#   _mld_init               - 初期化
#   _mld_scan_event_listeners - クリーンアップなしイベントリスナー検出
#   _mld_scan_intervals     - clearInterval/clearTimeout漏れ検出
#   _mld_scan_subscriptions - unsubscribe漏れ検出
#   _mld_scan_closures      - クロージャベースメモリ保持検出
#   _mld_generate_cleanup   - クリーンアップコード生成
#   _mld_report             - レポート出力
#   _mld_score              - スコア算出(0-100)
#
# All globals use the MLD_ prefix.
# =============================================================================

[[ -n "${_MEMORY_LEAK_DETECTOR_LOADED:-}" ]] && return 0
_MEMORY_LEAK_DETECTOR_LOADED=1

MLD_VERSION="276.0"
MLD_INITIALIZED=false
ENABLE_MLD="${ENABLE_MLD:-true}"

# Counters
MLD_LISTENER_LEAKS=0
MLD_INTERVAL_LEAKS=0
MLD_SUBSCRIPTION_LEAKS=0
MLD_CLOSURE_LEAKS=0
MLD_CLEANUPS_GENERATED=0
MLD_TOTAL_SCANS=0
MLD_TOTAL_FILES=0

# Storage
MLD_WORK_DIR=""
declare -g -a _MLD_FINDINGS=()
declare -g -a _MLD_CLEANUP_SUGGESTIONS=()

# =============================================================================
# _mld_init
# =============================================================================
_mld_init() {
    MLD_WORK_DIR="${HOME}/.soloptilink/memory-leak"
    mkdir -p "$MLD_WORK_DIR" 2>/dev/null || true

    MLD_LISTENER_LEAKS=0
    MLD_INTERVAL_LEAKS=0
    MLD_SUBSCRIPTION_LEAKS=0
    MLD_CLOSURE_LEAKS=0
    MLD_CLEANUPS_GENERATED=0
    MLD_TOTAL_SCANS=0
    MLD_TOTAL_FILES=0
    _MLD_FINDINGS=()
    _MLD_CLEANUP_SUGGESTIONS=()

    MLD_INITIALIZED=true
    return 0
}

# =============================================================================
# _mld_scan_event_listeners - Find event listeners without cleanup
# Usage: _mld_scan_event_listeners <project_dir>
# =============================================================================
_mld_scan_event_listeners() {
    [[ "$MLD_INITIALIZED" != "true" ]] && _mld_init
    local project_dir="${1:-.}"
    MLD_TOTAL_SCANS=$((MLD_TOTAL_SCANS + 1))

    echo -e "  ${CYAN:-}[MLD] Scanning for event listener leaks...${NC:-}" >&2

    local src_dirs=("${project_dir}/src" "${project_dir}/app" "${project_dir}/components")

    for dir in "${src_dirs[@]}"; do
        [[ ! -d "$dir" ]] && continue

        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            MLD_TOTAL_FILES=$((MLD_TOTAL_FILES + 1))
            local content
            content=$(cat "$file" 2>/dev/null || echo "")

            # Count addEventListener calls
            local add_count
            add_count=$(echo "$content" | grep -c 'addEventListener' 2>/dev/null || echo "0")

            # Count removeEventListener calls
            local remove_count
            remove_count=$(echo "$content" | grep -c 'removeEventListener' 2>/dev/null || echo "0")

            if [[ $add_count -gt 0 ]] && [[ $remove_count -lt $add_count ]]; then
                local missing=$((add_count - remove_count))
                _MLD_FINDINGS+=("[Listener] ${file}: ${add_count} addEventListener, ${remove_count} removeEventListener (${missing} missing)")
                MLD_LISTENER_LEAKS=$((MLD_LISTENER_LEAKS + missing))
            fi

            # Check useEffect with addEventListener but no cleanup
            if echo "$content" | grep -q 'useEffect' 2>/dev/null; then
                # Check for addEventListener in useEffect without return cleanup
                local effects_with_listener
                effects_with_listener=$(echo "$content" | awk '/useEffect.*\(/,/\}\s*,\s*\[/' | grep -c 'addEventListener' 2>/dev/null || echo "0")

                local effects_with_cleanup
                effects_with_cleanup=$(echo "$content" | awk '/useEffect.*\(/,/\}\s*,\s*\[/' | grep -c 'removeEventListener' 2>/dev/null || echo "0")

                if [[ $effects_with_listener -gt 0 ]] && [[ $effects_with_cleanup -lt $effects_with_listener ]]; then
                    _MLD_FINDINGS+=("[Listener] ${file}: useEffect adds event listener without cleanup return")
                    MLD_LISTENER_LEAKS=$((MLD_LISTENER_LEAKS + 1))
                fi
            fi

            # Check for window/document listeners in components
            if echo "$file" | grep -qE '\.(tsx|jsx)$'; then
                local window_listeners
                window_listeners=$(echo "$content" | grep -c 'window\.addEventListener\|document\.addEventListener' 2>/dev/null || echo "0")
                if [[ $window_listeners -gt 0 ]]; then
                    local window_removals
                    window_removals=$(echo "$content" | grep -c 'window\.removeEventListener\|document\.removeEventListener' 2>/dev/null || echo "0")
                    if [[ $window_removals -lt $window_listeners ]]; then
                        _MLD_FINDINGS+=("[Listener] ${file}: Global listener without cleanup in component")
                        MLD_LISTENER_LEAKS=$((MLD_LISTENER_LEAKS + 1))
                    fi
                fi
            fi

        done < <(find "$dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
            -not -path "*/node_modules/*" 2>/dev/null)
    done

    return 0
}

# =============================================================================
# _mld_scan_intervals - Find setInterval/setTimeout without clearInterval/clearTimeout
# Usage: _mld_scan_intervals <project_dir>
# =============================================================================
_mld_scan_intervals() {
    [[ "$MLD_INITIALIZED" != "true" ]] && _mld_init
    local project_dir="${1:-.}"
    MLD_TOTAL_SCANS=$((MLD_TOTAL_SCANS + 1))

    echo -e "  ${CYAN:-}[MLD] Scanning for timer leaks...${NC:-}" >&2

    local src_dirs=("${project_dir}/src" "${project_dir}/app" "${project_dir}/components")

    for dir in "${src_dirs[@]}"; do
        [[ ! -d "$dir" ]] && continue

        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            local content
            content=$(cat "$file" 2>/dev/null || echo "")

            # setInterval without clearInterval
            local set_interval
            set_interval=$(echo "$content" | grep -c 'setInterval' 2>/dev/null || echo "0")
            local clear_interval
            clear_interval=$(echo "$content" | grep -c 'clearInterval' 2>/dev/null || echo "0")

            if [[ $set_interval -gt 0 ]] && [[ $clear_interval -lt $set_interval ]]; then
                _MLD_FINDINGS+=("[Timer] ${file}: ${set_interval} setInterval, ${clear_interval} clearInterval")
                MLD_INTERVAL_LEAKS=$((MLD_INTERVAL_LEAKS + (set_interval - clear_interval)))
            fi

            # setTimeout in components without cleanup (in loops or effects)
            if echo "$file" | grep -qE '\.(tsx|jsx)$'; then
                local set_timeout
                set_timeout=$(echo "$content" | grep -c 'setTimeout' 2>/dev/null || echo "0")
                local clear_timeout
                clear_timeout=$(echo "$content" | grep -c 'clearTimeout' 2>/dev/null || echo "0")

                # In components, every setTimeout should have clearTimeout in cleanup
                if [[ $set_timeout -gt 0 ]] && [[ $clear_timeout -lt $set_timeout ]]; then
                    _MLD_FINDINGS+=("[Timer] ${file}: ${set_timeout} setTimeout in component, ${clear_timeout} clearTimeout")
                    MLD_INTERVAL_LEAKS=$((MLD_INTERVAL_LEAKS + (set_timeout - clear_timeout)))
                fi
            fi

            # requestAnimationFrame without cancel
            local raf_count
            raf_count=$(echo "$content" | grep -c 'requestAnimationFrame' 2>/dev/null || echo "0")
            local cancel_raf
            cancel_raf=$(echo "$content" | grep -c 'cancelAnimationFrame' 2>/dev/null || echo "0")

            if [[ $raf_count -gt 0 ]] && [[ $cancel_raf -lt $raf_count ]]; then
                _MLD_FINDINGS+=("[Timer] ${file}: requestAnimationFrame without cancelAnimationFrame")
                MLD_INTERVAL_LEAKS=$((MLD_INTERVAL_LEAKS + 1))
            fi

        done < <(find "$dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
            -not -path "*/node_modules/*" 2>/dev/null)
    done

    return 0
}

# =============================================================================
# _mld_scan_subscriptions - Find subscriptions without unsubscribe
# Usage: _mld_scan_subscriptions <project_dir>
# =============================================================================
_mld_scan_subscriptions() {
    [[ "$MLD_INITIALIZED" != "true" ]] && _mld_init
    local project_dir="${1:-.}"
    MLD_TOTAL_SCANS=$((MLD_TOTAL_SCANS + 1))

    echo -e "  ${CYAN:-}[MLD] Scanning for subscription leaks...${NC:-}" >&2

    local src_dirs=("${project_dir}/src" "${project_dir}/app" "${project_dir}/components")

    for dir in "${src_dirs[@]}"; do
        [[ ! -d "$dir" ]] && continue

        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            local content
            content=$(cat "$file" 2>/dev/null || echo "")

            # RxJS subscribe without unsubscribe
            local subscribes
            subscribes=$(echo "$content" | grep -c '\.subscribe(' 2>/dev/null || echo "0")
            local unsubscribes
            unsubscribes=$(echo "$content" | grep -c '\.unsubscribe()\|takeUntil\|pipe.*take(' 2>/dev/null || echo "0")

            if [[ $subscribes -gt 0 ]] && [[ $unsubscribes -lt $subscribes ]]; then
                _MLD_FINDINGS+=("[Subscription] ${file}: ${subscribes} subscribe(), ${unsubscribes} unsubscribe/takeUntil")
                MLD_SUBSCRIPTION_LEAKS=$((MLD_SUBSCRIPTION_LEAKS + (subscribes - unsubscribes)))
            fi

            # WebSocket connections without close
            local ws_opens
            ws_opens=$(echo "$content" | grep -c 'new WebSocket\|WebSocket(' 2>/dev/null || echo "0")
            local ws_closes
            ws_closes=$(echo "$content" | grep -c '\.close()\|ws\.close\|socket\.close' 2>/dev/null || echo "0")

            if [[ $ws_opens -gt 0 ]] && [[ $ws_closes -lt $ws_opens ]]; then
                _MLD_FINDINGS+=("[Subscription] ${file}: WebSocket opened without close")
                MLD_SUBSCRIPTION_LEAKS=$((MLD_SUBSCRIPTION_LEAKS + 1))
            fi

            # EventSource (SSE) without close
            local sse_opens
            sse_opens=$(echo "$content" | grep -c 'new EventSource' 2>/dev/null || echo "0")
            if [[ $sse_opens -gt 0 ]]; then
                local sse_closes
                sse_closes=$(echo "$content" | grep -c 'eventSource\.close\|\.close()' 2>/dev/null || echo "0")
                if [[ $sse_closes -lt $sse_opens ]]; then
                    _MLD_FINDINGS+=("[Subscription] ${file}: EventSource opened without close")
                    MLD_SUBSCRIPTION_LEAKS=$((MLD_SUBSCRIPTION_LEAKS + 1))
                fi
            fi

            # AbortController without abort
            local controllers
            controllers=$(echo "$content" | grep -c 'new AbortController' 2>/dev/null || echo "0")
            local aborts
            aborts=$(echo "$content" | grep -c '\.abort()' 2>/dev/null || echo "0")

            if [[ $controllers -gt 0 ]] && [[ $aborts -lt $controllers ]]; then
                _MLD_FINDINGS+=("[Subscription] ${file}: AbortController without abort() in cleanup")
                MLD_SUBSCRIPTION_LEAKS=$((MLD_SUBSCRIPTION_LEAKS + 1))
            fi

            # MutationObserver/IntersectionObserver/ResizeObserver without disconnect
            for observer in "MutationObserver" "IntersectionObserver" "ResizeObserver"; do
                local obs_count
                obs_count=$(echo "$content" | grep -c "new ${observer}" 2>/dev/null || echo "0")
                local disc_count
                disc_count=$(echo "$content" | grep -c '\.disconnect()' 2>/dev/null || echo "0")

                if [[ $obs_count -gt 0 ]] && [[ $disc_count -lt $obs_count ]]; then
                    _MLD_FINDINGS+=("[Subscription] ${file}: ${observer} without disconnect()")
                    MLD_SUBSCRIPTION_LEAKS=$((MLD_SUBSCRIPTION_LEAKS + 1))
                fi
            done

        done < <(find "$dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
            -not -path "*/node_modules/*" 2>/dev/null)
    done

    return 0
}

# =============================================================================
# _mld_scan_closures - Find closure-based memory retention
# Usage: _mld_scan_closures <project_dir>
# =============================================================================
_mld_scan_closures() {
    [[ "$MLD_INITIALIZED" != "true" ]] && _mld_init
    local project_dir="${1:-.}"
    MLD_TOTAL_SCANS=$((MLD_TOTAL_SCANS + 1))

    echo -e "  ${CYAN:-}[MLD] Scanning for closure memory retention...${NC:-}" >&2

    local src_dirs=("${project_dir}/src" "${project_dir}/app" "${project_dir}/lib")

    for dir in "${src_dirs[@]}"; do
        [[ ! -d "$dir" ]] && continue

        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            local content
            content=$(cat "$file" 2>/dev/null || echo "")

            # Module-level arrays/maps that grow unbounded
            if echo "$content" | grep -qE '^(const|let|var)\s+\w+\s*[:=]\s*(new Map|new Set|\[\]|{})' 2>/dev/null; then
                local has_clear
                has_clear=$(echo "$content" | grep -c '\.clear()\|\.splice(0)\|= \[\]\|= {}' 2>/dev/null || echo "0")
                local has_push
                has_push=$(echo "$content" | grep -c '\.push(\|\.set(\|\.add(' 2>/dev/null || echo "0")

                if [[ $has_push -gt 2 ]] && [[ $has_clear -eq 0 ]]; then
                    _MLD_FINDINGS+=("[Closure] ${file}: Module-level collection grows without bound (no clear/cleanup)")
                    MLD_CLOSURE_LEAKS=$((MLD_CLOSURE_LEAKS + 1))
                fi
            fi

            # Closures capturing large objects in callbacks
            if echo "$content" | grep -qE 'useCallback.*=>\s*\{' 2>/dev/null; then
                # Check for stale closures (useCallback without proper deps)
                local callbacks_no_deps
                callbacks_no_deps=$(echo "$content" | grep -c 'useCallback.*\[\]' 2>/dev/null || echo "0")
                if [[ $callbacks_no_deps -gt 0 ]]; then
                    _MLD_FINDINGS+=("[Closure] ${file}: useCallback with empty deps may cause stale closure")
                    MLD_CLOSURE_LEAKS=$((MLD_CLOSURE_LEAKS + 1))
                fi
            fi

            # Cache without eviction
            if echo "$content" | grep -qE 'cache|Cache|memo|CACHE' 2>/dev/null; then
                if echo "$content" | grep -qE 'new Map|= {}|Record<' 2>/dev/null; then
                    if ! echo "$content" | grep -qE '\.delete\(|maxSize|maxAge|ttl|evict|prune|lru' 2>/dev/null; then
                        _MLD_FINDINGS+=("[Closure] ${file}: Cache without eviction strategy - may grow unbounded")
                        MLD_CLOSURE_LEAKS=$((MLD_CLOSURE_LEAKS + 1))
                    fi
                fi
            fi

        done < <(find "$dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
            -not -path "*/node_modules/*" 2>/dev/null)
    done

    return 0
}

# =============================================================================
# _mld_generate_cleanup - Generate cleanup code for detected leaks
# Usage: _mld_generate_cleanup <output_dir>
# =============================================================================
_mld_generate_cleanup() {
    [[ "$MLD_INITIALIZED" != "true" ]] && _mld_init
    local output_dir="${1:-.}/src/hooks"
    mkdir -p "$output_dir" 2>/dev/null || true
    local target="${output_dir}/useCleanup.ts"

    echo -e "  ${CYAN:-}[MLD] Generating cleanup utilities...${NC:-}" >&2

    cat > "$target" << 'CLEOF'
/**
 * Memory Cleanup Hooks - Prevent common memory leaks in React
 * Generated by SoloptiLinkAI v276.0 Memory Leak Detector
 */

import { useEffect, useRef, useCallback } from 'react';

/**
 * useEventListener - Automatically cleaned up event listener
 */
export function useEventListener<K extends keyof WindowEventMap>(
  eventName: K,
  handler: (event: WindowEventMap[K]) => void,
  element: Window | HTMLElement | null = typeof window !== 'undefined' ? window : null,
  options?: boolean | AddEventListenerOptions
): void {
  const savedHandler = useRef(handler);

  useEffect(() => {
    savedHandler.current = handler;
  }, [handler]);

  useEffect(() => {
    if (!element) return;

    const eventListener = (event: Event) => {
      savedHandler.current(event as WindowEventMap[K]);
    };

    element.addEventListener(eventName, eventListener, options);
    return () => {
      element.removeEventListener(eventName, eventListener, options);
    };
  }, [eventName, element, options]);
}

/**
 * useInterval - setInterval with automatic cleanup
 */
export function useInterval(callback: () => void, delay: number | null): void {
  const savedCallback = useRef(callback);

  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  useEffect(() => {
    if (delay === null) return;
    const id = setInterval(() => savedCallback.current(), delay);
    return () => clearInterval(id);
  }, [delay]);
}

/**
 * useTimeout - setTimeout with automatic cleanup
 */
export function useTimeout(callback: () => void, delay: number | null): void {
  const savedCallback = useRef(callback);

  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  useEffect(() => {
    if (delay === null) return;
    const id = setTimeout(() => savedCallback.current(), delay);
    return () => clearTimeout(id);
  }, [delay]);
}

/**
 * useAbortController - AbortController with automatic cleanup
 */
export function useAbortController(): AbortController {
  const controllerRef = useRef<AbortController>(new AbortController());

  useEffect(() => {
    const controller = new AbortController();
    controllerRef.current = controller;
    return () => controller.abort();
  }, []);

  return controllerRef.current;
}

/**
 * useSafeCallback - Callback that won't fire after unmount
 */
export function useSafeCallback<T extends (...args: any[]) => any>(
  callback: T
): T {
  const isMounted = useRef(true);
  const savedCallback = useRef(callback);

  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  useEffect(() => {
    isMounted.current = true;
    return () => {
      isMounted.current = false;
    };
  }, []);

  return useCallback(
    ((...args: any[]) => {
      if (isMounted.current) {
        return savedCallback.current(...args);
      }
    }) as T,
    []
  );
}
CLEOF

    MLD_CLEANUPS_GENERATED=$((MLD_CLEANUPS_GENERATED + 1))
    _MLD_CLEANUP_SUGGESTIONS+=("Generated useCleanup.ts with safe hooks")
    return 0
}

# =============================================================================
# _mld_scan_all - Run all scans
# =============================================================================
_mld_scan_all() {
    local project_dir="${1:-.}"
    _mld_scan_event_listeners "$project_dir"
    _mld_scan_intervals "$project_dir"
    _mld_scan_subscriptions "$project_dir"
    _mld_scan_closures "$project_dir"

    local total=$((MLD_LISTENER_LEAKS + MLD_INTERVAL_LEAKS + MLD_SUBSCRIPTION_LEAKS + MLD_CLOSURE_LEAKS))
    if [[ $total -gt 0 ]]; then
        echo -e "  ${RED:-}[MLD] ${total} potential memory leaks detected${NC:-}" >&2
    else
        echo -e "  ${GREEN:-}[MLD] No memory leaks detected${NC:-}" >&2
    fi
}

# =============================================================================
# _mld_report
# =============================================================================
_mld_report() {
    echo -e "\n  ${BOLD:-}═══ Memory Leak Detector v276.0 ═══${NC:-}"
    echo -e "  Total scans         : ${MLD_TOTAL_SCANS}"
    echo -e "  Files scanned       : ${MLD_TOTAL_FILES}"
    echo -e "  Listener leaks      : ${MLD_LISTENER_LEAKS}"
    echo -e "  Timer leaks         : ${MLD_INTERVAL_LEAKS}"
    echo -e "  Subscription leaks  : ${MLD_SUBSCRIPTION_LEAKS}"
    echo -e "  Closure leaks       : ${MLD_CLOSURE_LEAKS}"
    echo -e "  Cleanups generated  : ${MLD_CLEANUPS_GENERATED}"

    if [[ ${#_MLD_FINDINGS[@]} -gt 0 ]]; then
        echo -e "  ${YELLOW:-}--- Findings ---${NC:-}"
        for f in "${_MLD_FINDINGS[@]}"; do
            echo -e "    ${YELLOW:-}${f}${NC:-}"
        done
    fi
}

# =============================================================================
# _mld_score
# =============================================================================
_mld_score() {
    local total=$((MLD_LISTENER_LEAKS + MLD_INTERVAL_LEAKS + MLD_SUBSCRIPTION_LEAKS + MLD_CLOSURE_LEAKS))
    local score=90
    [[ $total -gt 0 ]] && score=$((90 - total * 5))
    [[ $score -lt 20 ]] && score=20
    [[ $MLD_CLEANUPS_GENERATED -gt 0 ]] && score=$((score + 5))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "memory-leak-detector" \
    --version "276.0" \
    --description "メモリリーク静的検出（リスナー/タイマー/サブスクリプション/クロージャ）" \
    --init "_mld_init" \
    --report "_mld_report" \
    --score "_mld_score" \
    --enable-var "ENABLE_MLD" \
    --cli-flags "--memory-leak-detector:--no-memory-leak-detector"
