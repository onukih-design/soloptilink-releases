#!/usr/bin/env bash
# ============================================================
# SoloptiLink Chain v9.0 - Project Scaffolder Module
# ============================================================
# prompt-expanderが生成したブループリントとテックスタック情報を元に、
# プロジェクトの骨格を自動構築。ディレクトリ作成・依存インストール・
# ビルドツール設定を行い、コード生成前に動作する基盤を準備する。
# ============================================================

# sourceされるライブラリなので set -euo pipefail は設定しない

# カラー定義（SC_プレフィックスで他モジュールとの衝突を防止）
SC_GREEN='\033[0;32m'  SC_YELLOW='\033[0;33m' SC_RED='\033[0;31m'
SC_CYAN='\033[0;36m'   SC_PURPLE='\033[0;35m' SC_BOLD='\033[1m'
SC_NC='\033[0m'

# スキャフォルダー設定
SCAFFOLD_PROJECT_DIR=""
SCAFFOLD_LOG_DIR=""
SCAFFOLD_TIMEOUT="${SCAFFOLD_TIMEOUT:-120}"

# ============================================================
# ヘルパー関数群
# ============================================================
_sc_log() {
    local level="$1" message="$2" color="${SC_NC}"
    case "$level" in
        INFO|SUCCESS) color="${SC_GREEN}"  ;; WARN) color="${SC_YELLOW}" ;;
        ERROR|FAIL)   color="${SC_RED}"    ;; STEP) color="${SC_CYAN}"   ;;
        SECTION)      color="${SC_PURPLE}" ;;
    esac
    echo -e "  ${color}[SCAFFOLD:${level}]${SC_NC} ${message}"
    [[ -n "$SCAFFOLD_LOG_DIR" ]] && \
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${level}] ${message}" >> "${SCAFFOLD_LOG_DIR}/scaffolder.log" 2>/dev/null || true
}

_sc_run_cmd() {
    local cmd="$1" description="${2:-コマンド実行}" timeout_sec="${3:-$SCAFFOLD_TIMEOUT}"
    _sc_log "STEP" "${description}"
    local output exit_code
    if command -v timeout &>/dev/null; then
        output=$(timeout "${timeout_sec}" bash -c "$cmd" 2>&1); exit_code=$?
    elif command -v gtimeout &>/dev/null; then
        output=$(gtimeout "${timeout_sec}" bash -c "$cmd" 2>&1); exit_code=$?
    else
        output=$(bash -c "$cmd" 2>&1); exit_code=$?
    fi
    if [[ $exit_code -eq 0 ]]; then _sc_log "SUCCESS" "${description} 完了"
    elif [[ $exit_code -eq 124 ]]; then _sc_log "WARN" "${description} タイムアウト (${timeout_sec}秒)"
    else _sc_log "ERROR" "${description} 失敗 (exit=${exit_code})"; [[ -n "$output" ]] && _sc_log "ERROR" "出力: ${output:0:500}"
    fi
    return $exit_code
}

# ============================================================
# 初期化
# ============================================================
scaffold_init() {
    local project_dir="${1:-.}"
    SCAFFOLD_PROJECT_DIR="$(cd "$project_dir" 2>/dev/null && pwd)" || {
        mkdir -p "$project_dir" 2>/dev/null || { _sc_log "ERROR" "ディレクトリ作成失敗: $project_dir"; return 1; }
        SCAFFOLD_PROJECT_DIR="$(cd "$project_dir" && pwd)"
    }
    SCAFFOLD_LOG_DIR="${SCAFFOLD_PROJECT_DIR}/docs/chain-logs"
    mkdir -p "$SCAFFOLD_LOG_DIR" 2>/dev/null || true
    _sc_log "INFO" "スキャフォルダー初期化: ${SCAFFOLD_PROJECT_DIR}"
}

# ============================================================
# テックスタック検出
# ============================================================
scaffold_detect_stack() {
    local tech_stack_file="$1"
    [[ ! -f "$tech_stack_file" ]] && { echo "unknown"; return 1; }
    local c; c=$(tr '[:upper:]' '[:lower:]' < "$tech_stack_file" 2>/dev/null)
    if echo "$c" | grep -qE '\bnext\.?js\b|nextjs'; then echo "nextjs"
    elif echo "$c" | grep -qE '\bvue\b' && echo "$c" | grep -qE '\bfastapi\b'; then echo "vue-fastapi"
    elif echo "$c" | grep -qE '\breact\b' && echo "$c" | grep -qE '\bexpress\b'; then echo "react-express"
    elif echo "$c" | grep -qE '\bvue\b'; then echo "vue"
    elif echo "$c" | grep -qE '\bfastapi\b'; then echo "python-fastapi"
    elif echo "$c" | grep -qE '\bflask\b'; then echo "python-flask"
    elif echo "$c" | grep -qE '\bstatic\b|html.*css.*js|vanilla'; then echo "static"
    elif echo "$c" | grep -qE '\breact\b'; then echo "react-express"
    elif echo "$c" | grep -qiE 'ios|swiftui|uikit|xcode|iphone|ipad|ネイティブアプリ'; then
        if echo "$c" | grep -qE '\buikit\b'; then echo "ios-uikit"
        else echo "ios-swiftui"; fi
    else echo "static"; fi
    return 0
}

# ============================================================
# メイン: ブループリントからスキャフォルド
# ============================================================
scaffold_from_blueprint() {
    local blueprint_file="$1" tech_stack_file="$2" project_dir="${3:-$SCAFFOLD_PROJECT_DIR}"
    [[ -z "$project_dir" ]] && { _sc_log "ERROR" "プロジェクトディレクトリが未指定"; return 1; }
    scaffold_init "$project_dir" || return 1
    _sc_log "SECTION" "========== プロジェクトスキャフォルド開始 =========="
    local stack; stack=$(scaffold_detect_stack "$tech_stack_file")
    _sc_log "INFO" "検出されたスタック: ${stack}"

    local result=0
    case "$stack" in
        nextjs)          _scaffold_nextjs "$project_dir" "$blueprint_file"         || result=$? ;;
        react-express)   _scaffold_react_express "$project_dir" "$blueprint_file"  || result=$? ;;
        vue|vue-fastapi) _scaffold_vue "$project_dir" "$blueprint_file"            || result=$? ;;
        python-flask)    _scaffold_python_flask "$project_dir" "$blueprint_file"   || result=$? ;;
        python-fastapi)  _scaffold_python_fastapi "$project_dir" "$blueprint_file" || result=$? ;;
        ios-swiftui|ios-uikit) _scaffold_ios "$project_dir" "$blueprint_file" "$stack" || result=$? ;;
        *)               _scaffold_static "$project_dir" "$blueprint_file"         || result=$? ;;
    esac
    _scaffold_crud_templates "$project_dir" "$stack"
    _scaffold_custom_dirs "$project_dir" "$blueprint_file"

    if scaffold_verify "$project_dir"; then
        _sc_log "SUCCESS" "スキャフォルド完了・検証成功: ${stack}"; return 0
    else
        _sc_log "WARN" "スキャフォルド完了、ただし検証で問題検出"; return $result
    fi
}

# ============================================================
# スキャフォルド: Next.js
# ============================================================
_scaffold_nextjs() {
    local project_dir="$1" blueprint_file="$2"
    _sc_log "SECTION" "Next.js プロジェクト生成"
    if ! command -v npx &>/dev/null; then
        _sc_log "WARN" "npx未検出。手動構造にフォールバック"; _scaffold_static "$project_dir" "$blueprint_file"; return $?
    fi
    if [[ ! -f "${project_dir}/package.json" ]]; then
        local tmp="${project_dir}_tmp_$$"
        _sc_run_cmd "npx --yes create-next-app@latest '${tmp}' --typescript --tailwind --eslint --app --use-npm --no-import-alias --yes" \
            "create-next-app 実行" 180
        if [[ -f "${tmp}/package.json" ]]; then
            mkdir -p "$project_dir" 2>/dev/null
            cp -rn "${tmp}/"* "${tmp}/".* "$project_dir/" 2>/dev/null || true
            rm -rf "$tmp" 2>/dev/null
        else
            rm -rf "$tmp" 2>/dev/null
            _sc_log "WARN" "create-next-app 失敗。npm install フォールバック"
            mkdir -p "$project_dir" && _sc_run_cmd "cd '${project_dir}' && npm init -y && npm install --save next react react-dom typescript @types/react @types/node tailwindcss" \
                "Next.js パッケージインストール" 120
        fi
    fi
    local d; for d in src/components src/lib src/api src/hooks src/styles src/types public; do
        mkdir -p "${project_dir}/${d}" 2>/dev/null
    done
    return 0
}

# ============================================================
# スキャフォルド: React + Express
# ============================================================
_scaffold_react_express() {
    local project_dir="$1" blueprint_file="$2"
    _sc_log "SECTION" "React + Express プロジェクト生成"
    mkdir -p "${project_dir}/frontend" "${project_dir}/backend" 2>/dev/null
    # フロントエンド
    if command -v npx &>/dev/null && [[ ! -f "${project_dir}/frontend/package.json" ]]; then
        _sc_run_cmd "cd '${project_dir}/frontend' && npm create vite@latest . -- --template react-ts --yes 2>/dev/null || npm init -y" \
            "フロントエンド(Vite+React)生成" 120
    fi
    # バックエンド
    if command -v npm &>/dev/null && [[ ! -f "${project_dir}/backend/package.json" ]]; then
        _sc_run_cmd "cd '${project_dir}/backend' && npm init -y && npm install --save express cors dotenv prisma @prisma/client" \
            "Express バックエンド生成 (Prisma ORM付き)" 120
    fi
    # Prisma初期セットアップ
    mkdir -p "${project_dir}/backend/prisma" 2>/dev/null
    [[ ! -f "${project_dir}/backend/prisma/schema.prisma" ]] && cat > "${project_dir}/backend/prisma/schema.prisma" << 'PRISMASCHEMA'
datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

// 設計書のDBスキーマに基づいてモデルが自動追加されます
PRISMASCHEMA
    # server.js (実DB接続版)
    [[ ! -f "${project_dir}/backend/server.js" ]] && cat > "${project_dir}/backend/server.js" << 'EOF'
const express = require('express');
const cors = require('cors');
const { PrismaClient } = require('@prisma/client');
require('dotenv').config();

const app = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

app.get('/api/health', async (req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({ status: 'ok', db: 'connected', timestamp: new Date().toISOString() });
  } catch (error) {
    res.status(503).json({ status: 'error', db: 'disconnected', error: error.message });
  }
});

// ルート登録はここに追加 (例: app.use('/api/users', require('./routes/users')))

process.on('beforeExit', async () => { await prisma.$disconnect(); });
app.listen(PORT, () => console.log(`Server running on port ${PORT} | DB: ${process.env.DATABASE_URL}`));
EOF
    [[ ! -f "${project_dir}/backend/.env" ]] && printf 'PORT=3001\nNODE_ENV=development\nDATABASE_URL="file:./dev.db"\n' > "${project_dir}/backend/.env"
    [[ ! -f "${project_dir}/backend/.env.example" ]] && printf 'PORT=3001\nNODE_ENV=development\nDATABASE_URL="file:./dev.db"\n' > "${project_dir}/backend/.env.example"
    _sc_log "SUCCESS" "React + Express プロジェクト生成完了"
}

# ============================================================
# スキャフォルド: Vue.js
# ============================================================
_scaffold_vue() {
    local project_dir="$1" blueprint_file="$2"
    _sc_log "SECTION" "Vue.js プロジェクト生成"
    if ! command -v npx &>/dev/null; then
        _sc_log "WARN" "npx未検出。手動構造にフォールバック"; _scaffold_static "$project_dir" "$blueprint_file"; return $?
    fi
    if [[ ! -f "${project_dir}/package.json" ]]; then
        local tmp="${project_dir}_vue_$$"
        _sc_run_cmd "npm create vue@latest '${tmp}' -- --typescript --router --pinia --eslint --yes 2>/dev/null || npm create vite@latest '${tmp}' -- --template vue-ts --yes" \
            "Vue.js プロジェクト生成" 120
        if [[ -f "${tmp}/package.json" ]]; then
            mkdir -p "$project_dir" 2>/dev/null
            cp -rn "${tmp}/"* "${tmp}/".* "$project_dir/" 2>/dev/null || true; rm -rf "$tmp" 2>/dev/null
        else
            rm -rf "$tmp" 2>/dev/null
            _sc_run_cmd "cd '${project_dir}' && npm init -y" "npm init フォールバック"
        fi
    fi
    mkdir -p "${project_dir}/src/components" "${project_dir}/src/views" "${project_dir}/src/stores" 2>/dev/null
    _sc_log "SUCCESS" "Vue.js プロジェクト生成完了"
}

# ============================================================
# スキャフォルド: Python Flask
# ============================================================
_scaffold_python_flask() {
    local project_dir="$1" blueprint_file="$2"
    _sc_log "SECTION" "Python Flask プロジェクト生成"
    command -v python3 &>/dev/null || { _sc_log "ERROR" "python3が見つかりません"; return 1; }
    mkdir -p "${project_dir}/templates" "${project_dir}/static/css" "${project_dir}/static/js" 2>/dev/null
    [[ ! -d "${project_dir}/venv" ]] && _sc_run_cmd "python3 -m venv '${project_dir}/venv'" "venv作成" 60
    [[ ! -f "${project_dir}/requirements.txt" ]] && printf 'flask>=3.0.0\nflask-cors>=4.0.0\npython-dotenv>=1.0.0\nsqlalchemy>=2.0.0\nflask-sqlalchemy>=3.1.0\nflask-migrate>=4.0.0\ngunicorn>=21.2.0\n' > "${project_dir}/requirements.txt"
    if [[ ! -f "${project_dir}/app.py" ]]; then
        cat > "${project_dir}/app.py" << 'EOF'
import os
from flask import Flask, jsonify, render_template
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
CORS(app)

# 実DB接続設定 (SQLiteで即起動、PostgreSQLにURL変更だけで移行可能)
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///instance/app.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-change-in-production')

db = SQLAlchemy(app)
migrate = Migrate(app, db)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/health')
def health():
    try:
        db.session.execute(db.text('SELECT 1'))
        return jsonify({'status': 'ok', 'db': 'connected'})
    except Exception as e:
        return jsonify({'status': 'error', 'db': 'disconnected', 'error': str(e)}), 503

# モデルとルートはここにimport (例: from routes.items import items_bp; app.register_blueprint(items_bp))

with app.app_context():
    db.create_all()  # テーブル自動作成

if __name__ == '__main__':
    app.run(debug=True, port=int(os.environ.get('PORT', 5000)))
EOF
    fi
    mkdir -p "${project_dir}/instance" 2>/dev/null
    [[ ! -f "${project_dir}/.env" ]] && printf 'FLASK_ENV=development\nPORT=5000\nDATABASE_URL=sqlite:///instance/app.db\nSECRET_KEY=change-me-in-production\n' > "${project_dir}/.env"
    [[ ! -f "${project_dir}/.env.example" ]] && printf 'FLASK_ENV=development\nPORT=5000\nDATABASE_URL=sqlite:///instance/app.db\nSECRET_KEY=\n' > "${project_dir}/.env.example"
    [[ -f "${project_dir}/venv/bin/pip" ]] && _sc_run_cmd "'${project_dir}/venv/bin/pip' install -r '${project_dir}/requirements.txt' -q" "Flask依存インストール" 120
    _sc_log "SUCCESS" "Python Flask プロジェクト生成完了"
}

# ============================================================
# スキャフォルド: Python FastAPI
# ============================================================
_scaffold_python_fastapi() {
    local project_dir="$1" blueprint_file="$2"
    _sc_log "SECTION" "Python FastAPI プロジェクト生成"
    command -v python3 &>/dev/null || { _sc_log "ERROR" "python3が見つかりません"; return 1; }
    mkdir -p "${project_dir}/app/routers" "${project_dir}/app/models" "${project_dir}/app/schemas" "${project_dir}/tests" 2>/dev/null
    [[ ! -d "${project_dir}/venv" ]] && _sc_run_cmd "python3 -m venv '${project_dir}/venv'" "venv作成" 60
    [[ ! -f "${project_dir}/requirements.txt" ]] && printf 'fastapi>=0.110.0\nuvicorn[standard]>=0.27.0\npydantic>=2.5.0\npython-dotenv>=1.0.0\nsqlalchemy>=2.0.0\nhttpx>=0.26.0\n' > "${project_dir}/requirements.txt"
    if [[ ! -f "${project_dir}/app/main.py" ]]; then
        cat > "${project_dir}/app/main.py" << 'EOF'
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
load_dotenv()
app = FastAPI(title="API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.get("/")
async def root():
    return {"message": "API is running"}

@app.get("/api/health")
async def health():
    return {"status": "ok"}
EOF
    fi
    touch "${project_dir}/app/__init__.py" 2>/dev/null
    [[ ! -f "${project_dir}/.env.example" ]] && printf 'PORT=8000\nDATABASE_URL=\nSECRET_KEY=\n' > "${project_dir}/.env.example"
    [[ -f "${project_dir}/venv/bin/pip" ]] && _sc_run_cmd "'${project_dir}/venv/bin/pip' install -r '${project_dir}/requirements.txt' -q" "FastAPI依存インストール" 120
    _sc_log "SUCCESS" "Python FastAPI プロジェクト生成完了"
}

# ============================================================
# スキャフォルド: 静的サイト
# ============================================================
_scaffold_static() {
    local project_dir="$1" blueprint_file="$2"
    _sc_log "SECTION" "静的サイト プロジェクト生成"
    mkdir -p "${project_dir}/css" "${project_dir}/js" "${project_dir}/images" 2>/dev/null
    [[ ! -f "${project_dir}/index.html" ]] && cat > "${project_dir}/index.html" << 'EOF'
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Project</title><link rel="stylesheet" href="css/styles.css">
</head>
<body>
  <div id="app"><h1>Project</h1></div>
  <script src="js/script.js"></script>
</body>
</html>
EOF
    [[ ! -f "${project_dir}/css/styles.css" ]] && cat > "${project_dir}/css/styles.css" << 'EOF'
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; line-height: 1.6; color: #333; }
#app { max-width: 1200px; margin: 0 auto; padding: 2rem; }
EOF
    [[ ! -f "${project_dir}/js/script.js" ]] && cat > "${project_dir}/js/script.js" << 'EOF'
'use strict';
document.addEventListener('DOMContentLoaded', () => { console.log('Application initialized'); });
EOF
    _sc_log "SUCCESS" "静的サイト プロジェクト生成完了"
}

# ============================================================
# スキャフォルド: iOS (SwiftUI / UIKit)
# ============================================================
_scaffold_ios() {
    local project_dir="$1" blueprint_file="$2" stack="${3:-ios-swiftui}"
    _sc_log "SECTION" "iOS (${stack}) プロジェクト生成"

    # プロジェクト名を推定（ディレクトリ名からハイフン除去してPascalCase化）
    local dir_name app_name
    dir_name=$(basename "$project_dir")
    # ハイフン/アンダースコア区切りをPascalCaseに変換
    app_name=$(echo "$dir_name" | sed -E 's/(^|[-_])([a-z])/\U\2/g' | sed 's/[-_]//g')
    [[ -z "$app_name" ]] && app_name="MyApp"
    _sc_log "INFO" "アプリ名: ${app_name}"

    # ディレクトリ構造作成
    local dirs=("App" "Models" "Views" "ViewModels" "Services" "Utilities" "Resources" "Tests" "UITests")
    local d
    for d in "${dirs[@]}"; do
        mkdir -p "${project_dir}/${d}" 2>/dev/null
    done
    _sc_log "STEP" "ディレクトリ構造を作成 (${#dirs[@]}ディレクトリ)"

    # Package.swift 生成
    if [[ ! -f "${project_dir}/Package.swift" ]]; then
        cat > "${project_dir}/Package.swift" << PACKAGESWIFT
// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "${app_name}",
    platforms: [
        .iOS(.v17),
        .macOS(.v14)
    ],
    dependencies: [
        .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0"),
        .package(url: "https://github.com/apple/swift-collections", from: "1.1.0"),
    ],
    targets: [
        .executableTarget(
            name: "${app_name}",
            dependencies: [
                .product(name: "Algorithms", package: "swift-algorithms"),
                .product(name: "Collections", package: "swift-collections"),
            ],
            path: "App"
        ),
        .testTarget(
            name: "${app_name}Tests",
            dependencies: ["${app_name}"],
            path: "Tests"
        ),
    ]
)
PACKAGESWIFT
        _sc_log "SUCCESS" "Package.swift 生成完了"
    fi

    # Info.plist 生成
    if [[ ! -f "${project_dir}/Resources/Info.plist" ]]; then
        cat > "${project_dir}/Resources/Info.plist" << INFOPLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleDevelopmentRegion</key>
    <string>\$(DEVELOPMENT_LANGUAGE)</string>
    <key>CFBundleExecutable</key>
    <string>\$(EXECUTABLE_NAME)</string>
    <key>CFBundleIdentifier</key>
    <string>\$(PRODUCT_BUNDLE_IDENTIFIER)</string>
    <key>CFBundleInfoDictionaryVersion</key>
    <string>6.0</string>
    <key>CFBundleName</key>
    <string>\$(PRODUCT_NAME)</string>
    <key>CFBundlePackageType</key>
    <string>\$(PRODUCT_BUNDLE_PACKAGE_TYPE)</string>
    <key>CFBundleShortVersionString</key>
    <string>1.0</string>
    <key>CFBundleVersion</key>
    <string>1</string>
    <key>LSRequiresIPhoneOS</key>
    <true/>
    <key>UIApplicationSceneManifest</key>
    <dict>
        <key>UIApplicationSupportsMultipleScenes</key>
        <false/>
    </dict>
    <key>UILaunchScreen</key>
    <dict/>
    <key>UISupportedInterfaceOrientations</key>
    <array>
        <string>UIInterfaceOrientationPortrait</string>
        <string>UIInterfaceOrientationLandscapeLeft</string>
        <string>UIInterfaceOrientationLandscapeRight</string>
    </array>
</dict>
</plist>
INFOPLIST
        _sc_log "SUCCESS" "Info.plist 生成完了"
    fi

    # SwiftUI @main エントリーポイント
    if [[ ! -f "${project_dir}/App/${app_name}App.swift" ]]; then
        cat > "${project_dir}/App/${app_name}App.swift" << APPSWIFT
import SwiftUI

@main
struct ${app_name}App: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
APPSWIFT
        _sc_log "SUCCESS" "${app_name}App.swift 生成完了"
    fi

    # Persistence.swift (CoreData セットアップ)
    if [[ ! -f "${project_dir}/App/Persistence.swift" ]]; then
        cat > "${project_dir}/App/Persistence.swift" << 'PERSISTENCE'
import CoreData

struct PersistenceController {
    static let shared = PersistenceController()

    let container: NSPersistentContainer

    init(inMemory: Bool = false) {
        container = NSPersistentContainer(name: "DataModel")
        if inMemory {
            container.persistentStoreDescriptions.first?.url = URL(fileURLWithPath: "/dev/null")
        }
        container.loadPersistentStores { _, error in
            if let error = error as NSError? {
                fatalError("CoreData ロードエラー: \(error), \(error.userInfo)")
            }
        }
        container.viewContext.automaticallyMergesChangesFromParent = true
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
    }

    static var preview: PersistenceController = {
        let controller = PersistenceController(inMemory: true)
        return controller
    }()

    func save() {
        let context = container.viewContext
        guard context.hasChanges else { return }
        do {
            try context.save()
        } catch {
            let nsError = error as NSError
            print("CoreData 保存エラー: \(nsError), \(nsError.userInfo)")
        }
    }
}
PERSISTENCE
        _sc_log "SUCCESS" "Persistence.swift 生成完了"
    fi

    # ContentView.swift (TabView ルートビュー)
    if [[ ! -f "${project_dir}/Views/ContentView.swift" ]]; then
        cat > "${project_dir}/Views/ContentView.swift" << 'CONTENTVIEW'
import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            NavigationStack {
                Text("ホーム")
                    .navigationTitle("ホーム")
            }
            .tabItem {
                Label("ホーム", systemImage: "house")
            }

            NavigationStack {
                Text("一覧")
                    .navigationTitle("一覧")
            }
            .tabItem {
                Label("一覧", systemImage: "list.bullet")
            }

            NavigationStack {
                Text("設定")
                    .navigationTitle("設定")
            }
            .tabItem {
                Label("設定", systemImage: "gear")
            }
        }
    }
}

#Preview {
    ContentView()
}
CONTENTVIEW
        _sc_log "SUCCESS" "ContentView.swift 生成完了"
    fi

    # APIClient.swift (WITH_BACKEND フラグ設定時)
    if [[ "${WITH_BACKEND:-}" == "true" || "${WITH_BACKEND:-}" == "1" ]]; then
        if [[ ! -f "${project_dir}/Services/APIClient.swift" ]]; then
            cat > "${project_dir}/Services/APIClient.swift" << 'APICLIENT'
import Foundation

enum APIError: LocalizedError {
    case invalidURL
    case invalidResponse
    case httpError(statusCode: Int, message: String)
    case decodingError(Error)
    case networkError(Error)

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "無効なURLです"
        case .invalidResponse: return "無効なレスポンスです"
        case .httpError(let code, let msg): return "HTTP \(code): \(msg)"
        case .decodingError(let err): return "デコードエラー: \(err.localizedDescription)"
        case .networkError(let err): return "ネットワークエラー: \(err.localizedDescription)"
        }
    }
}

actor APIClient {
    static let shared = APIClient()

    private let baseURL: String
    private let session: URLSession
    private let decoder: JSONDecoder
    private let encoder: JSONEncoder

    init(baseURL: String = "http://localhost:3001/api", session: URLSession = .shared) {
        self.baseURL = baseURL
        self.session = session
        self.decoder = JSONDecoder()
        self.decoder.dateDecodingStrategy = .iso8601
        self.encoder = JSONEncoder()
        self.encoder.dateEncodingStrategy = .iso8601
    }

    func get<T: Decodable>(_ endpoint: String) async throws -> T {
        return try await request(endpoint, method: "GET")
    }

    func post<T: Decodable, U: Encodable>(_ endpoint: String, body: U) async throws -> T {
        return try await request(endpoint, method: "POST", body: body)
    }

    func put<T: Decodable, U: Encodable>(_ endpoint: String, body: U) async throws -> T {
        return try await request(endpoint, method: "PUT", body: body)
    }

    func delete<T: Decodable>(_ endpoint: String) async throws -> T {
        return try await request(endpoint, method: "DELETE")
    }

    private func request<T: Decodable>(_ endpoint: String, method: String, body: (any Encodable)? = nil) async throws -> T {
        guard let url = URL(string: "\(baseURL)\(endpoint)") else {
            throw APIError.invalidURL
        }
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = method
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let body = body {
            urlRequest.httpBody = try encoder.encode(body)
        }
        let (data, response) = try await session.data(for: urlRequest)
        guard let httpResponse = response as? HTTPURLResponse else {
            throw APIError.invalidResponse
        }
        guard (200...299).contains(httpResponse.statusCode) else {
            let message = String(data: data, encoding: .utf8) ?? "不明なエラー"
            throw APIError.httpError(statusCode: httpResponse.statusCode, message: message)
        }
        do {
            return try decoder.decode(T.self, from: data)
        } catch {
            throw APIError.decodingError(error)
        }
    }
}
APICLIENT
            _sc_log "SUCCESS" "APIClient.swift 生成完了 (バックエンド連携用)"
        fi
    fi

    _sc_log "SUCCESS" "iOS (${stack}) プロジェクト生成完了"
}

# ============================================================
# v14.0: CRUD操作テンプレート注入
# 各スタックに応じた操作可能なCRUDテンプレートを生成
# ============================================================
_scaffold_crud_templates() {
    local project_dir="$1" stack="$2"
    _sc_log "INFO" "v14.0: CRUD操作テンプレート注入 (${stack})"

    case "$stack" in
        nextjs)
            # Next.js: APIルート + Reactフック + CRUDコンポーネント
            mkdir -p "${project_dir}/src/components/crud" "${project_dir}/src/hooks" "${project_dir}/src/lib" 2>/dev/null

            # APIクライアントユーティリティ
            [[ ! -f "${project_dir}/src/lib/api-client.ts" ]] && cat > "${project_dir}/src/lib/api-client.ts" << 'APICLIENT'
const API_BASE = process.env.NEXT_PUBLIC_API_URL || '';

export async function apiClient<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({ message: res.statusText }));
    throw new Error(error.message || `API Error: ${res.status}`);
  }
  return res.json();
}

export const api = {
  get: <T>(url: string) => apiClient<T>(url),
  post: <T>(url: string, data: unknown) => apiClient<T>(url, { method: 'POST', body: JSON.stringify(data) }),
  put: <T>(url: string, data: unknown) => apiClient<T>(url, { method: 'PUT', body: JSON.stringify(data) }),
  delete: <T>(url: string) => apiClient<T>(url, { method: 'DELETE' }),
};
APICLIENT

            # useCRUDフック
            [[ ! -f "${project_dir}/src/hooks/useCrud.ts" ]] && cat > "${project_dir}/src/hooks/useCrud.ts" << 'USECRUD'
import { useState, useCallback } from 'react';
import { api } from '@/lib/api-client';

interface UseCrudOptions<T> {
  endpoint: string;
}

export function useCrud<T extends { id: string | number }>({ endpoint }: UseCrudOptions<T>) {
  const [items, setItems] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortField, setSortField] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.get<T[]>(endpoint);
      setItems(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'データの取得に失敗しました');
    } finally {
      setLoading(false);
    }
  }, [endpoint]);

  const create = useCallback(async (data: Omit<T, 'id'>) => {
    setLoading(true);
    setError(null);
    try {
      const created = await api.post<T>(endpoint, data);
      setItems(prev => [...prev, created]);
      return created;
    } catch (e) {
      setError(e instanceof Error ? e.message : '作成に失敗しました');
      throw e;
    } finally {
      setLoading(false);
    }
  }, [endpoint]);

  const update = useCallback(async (id: string | number, data: Partial<T>) => {
    setLoading(true);
    setError(null);
    try {
      const updated = await api.put<T>(`${endpoint}/${id}`, data);
      setItems(prev => prev.map(item => item.id === id ? updated : item));
      return updated;
    } catch (e) {
      setError(e instanceof Error ? e.message : '更新に失敗しました');
      throw e;
    } finally {
      setLoading(false);
    }
  }, [endpoint]);

  const remove = useCallback(async (id: string | number) => {
    if (!window.confirm('本当に削除しますか？この操作は取り消せません。')) return;
    setLoading(true);
    setError(null);
    try {
      await api.delete(`${endpoint}/${id}`);
      setItems(prev => prev.filter(item => item.id !== id));
    } catch (e) {
      setError(e instanceof Error ? e.message : '削除に失敗しました');
      throw e;
    } finally {
      setLoading(false);
    }
  }, [endpoint]);

  // フィルタリング・ソート・ページネーション
  const filteredItems = items
    .filter(item => {
      if (!searchQuery) return true;
      return Object.values(item).some(val =>
        String(val).toLowerCase().includes(searchQuery.toLowerCase())
      );
    })
    .sort((a, b) => {
      if (!sortField) return 0;
      const aVal = String((a as Record<string, unknown>)[sortField] ?? '');
      const bVal = String((b as Record<string, unknown>)[sortField] ?? '');
      return sortOrder === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    });

  const totalPages = Math.ceil(filteredItems.length / pageSize);
  const paginatedItems = filteredItems.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const toggleSort = useCallback((field: string) => {
    if (sortField === field) {
      setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  }, [sortField]);

  return {
    items: paginatedItems, allItems: filteredItems, loading, error,
    fetchAll, create, update, remove,
    searchQuery, setSearchQuery,
    sortField, sortOrder, toggleSort,
    currentPage, setCurrentPage, totalPages, pageSize,
  };
}
USECRUD
            _sc_log "SUCCESS" "Next.js CRUD テンプレート作成完了"
            ;;

        react-express)
            # React + Express: バックエンドCRUDルート + フロントエンドフック
            mkdir -p "${project_dir}/backend/routes" "${project_dir}/frontend/src/hooks" "${project_dir}/frontend/src/lib" 2>/dev/null

            # Express CRUDルートテンプレート (v19.1: Prisma ORM実DB接続)
            [[ ! -f "${project_dir}/backend/routes/crud-template.js" ]] && cat > "${project_dir}/backend/routes/crud-template.js" << 'CRUDROUTE'
const express = require('express');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// 実DB接続CRUDルート - Prisma ORM経由 (モックデータ・TODOスタブなし)
// Usage: const itemsRouter = createCrudRouter('item');
function createCrudRouter(entityName) {
  const router = express.Router();

  router.get('/', async (req, res) => {
    try {
      const { search, sort = 'createdAt', order = 'desc', page = 1, limit = 10 } = req.query;
      const skip = (Number(page) - 1) * Number(limit);
      const where = search ? { OR: [{ name: { contains: search } }] } : {};
      const [data, total] = await Promise.all([
        prisma[entityName].findMany({ where, orderBy: { [sort]: order }, skip, take: Number(limit) }),
        prisma[entityName].count({ where }),
      ]);
      res.json({ data, total, page: Number(page), limit: Number(limit), totalPages: Math.ceil(total / Number(limit)) });
    } catch (error) {
      res.status(500).json({ message: `${entityName}の取得に失敗しました`, error: error.message });
    }
  });

  router.get('/:id', async (req, res) => {
    try {
      const item = await prisma[entityName].findUnique({ where: { id: req.params.id } });
      if (!item) return res.status(404).json({ message: `${entityName}が見つかりません` });
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: `${entityName}の取得に失敗しました` });
    }
  });

  router.post('/', async (req, res) => {
    try {
      if (!req.body || Object.keys(req.body).length === 0) {
        return res.status(400).json({ message: '入力データが空です' });
      }
      const item = await prisma[entityName].create({ data: req.body });
      res.status(201).json(item);
    } catch (error) {
      res.status(500).json({ message: `${entityName}の作成に失敗しました`, error: error.message });
    }
  });

  router.put('/:id', async (req, res) => {
    try {
      const item = await prisma[entityName].update({ where: { id: req.params.id }, data: req.body });
      res.json(item);
    } catch (error) {
      if (error.code === 'P2025') return res.status(404).json({ message: `${entityName}が見つかりません` });
      res.status(500).json({ message: `${entityName}の更新に失敗しました` });
    }
  });

  router.delete('/:id', async (req, res) => {
    try {
      await prisma[entityName].delete({ where: { id: req.params.id } });
      res.json({ message: `${entityName}を削除しました`, id: req.params.id });
    } catch (error) {
      if (error.code === 'P2025') return res.status(404).json({ message: `${entityName}が見つかりません` });
      res.status(500).json({ message: `${entityName}の削除に失敗しました` });
    }
  });

  return router;
}
module.exports = { createCrudRouter, prisma };
CRUDROUTE
            _sc_log "SUCCESS" "React+Express CRUD テンプレート作成完了"
            ;;

        python-flask|python-fastapi)
            # Python: CRUDブループリントテンプレート
            mkdir -p "${project_dir}/app/routes" 2>/dev/null
            [[ ! -f "${project_dir}/app/routes/__init__.py" ]] && touch "${project_dir}/app/routes/__init__.py" 2>/dev/null

            [[ ! -f "${project_dir}/app/routes/crud_template.py" ]] && cat > "${project_dir}/app/routes/crud_template.py" << 'PYCRUD'
"""
実DB接続CRUDルートテンプレート (v19.1 - SQLAlchemy ORM経由)
モックデータ・TODOスタブなし。全操作がDB経由。
Usage: app.register_blueprint(create_crud_blueprint('items', ItemModel, db.session))
"""
from flask import Blueprint, request, jsonify
from sqlalchemy import or_

def create_crud_blueprint(name, model, db_session):
    bp = Blueprint(name, __name__, url_prefix=f'/api/{name}')

    @bp.route('/', methods=['GET'])
    def list_items():
        search = request.args.get('search', '')
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 10))
        sort = request.args.get('sort', 'created_at')
        order = request.args.get('order', 'desc')
        query = db_session.query(model)
        if search and hasattr(model, 'name'):
            query = query.filter(model.name.ilike(f'%{search}%'))
        sort_col = getattr(model, sort, None)
        if sort_col is not None:
            query = query.order_by(sort_col.desc() if order == 'desc' else sort_col.asc())
        total = query.count()
        items = query.offset((page - 1) * limit).limit(limit).all()
        return jsonify({'data': [item.to_dict() for item in items], 'total': total, 'page': page, 'limit': limit})

    @bp.route('/', methods=['POST'])
    def create_item():
        data = request.get_json()
        if not data:
            return jsonify({'message': '入力データが空です'}), 400
        item = model(**data)
        db_session.add(item)
        db_session.commit()
        return jsonify(item.to_dict()), 201

    @bp.route('/<int:item_id>', methods=['GET'])
    def get_item(item_id):
        item = db_session.get(model, item_id)
        if not item:
            return jsonify({'message': f'{name}が見つかりません'}), 404
        return jsonify(item.to_dict())

    @bp.route('/<int:item_id>', methods=['PUT'])
    def update_item(item_id):
        item = db_session.get(model, item_id)
        if not item:
            return jsonify({'message': f'{name}が見つかりません'}), 404
        data = request.get_json()
        for key, value in data.items():
            if hasattr(item, key):
                setattr(item, key, value)
        db_session.commit()
        return jsonify(item.to_dict())

    @bp.route('/<int:item_id>', methods=['DELETE'])
    def delete_item(item_id):
        item = db_session.get(model, item_id)
        if not item:
            return jsonify({'message': f'{name}が見つかりません'}), 404
        db_session.delete(item)
        db_session.commit()
        return jsonify({'message': f'{name}を削除しました', 'id': item_id})

    return bp
PYCRUD
            _sc_log "SUCCESS" "Python CRUD テンプレート作成完了"
            ;;

        ios-swiftui|ios-uikit)
            # iOS: Swift CRUD テンプレート (Repository + ViewModel + Views)
            mkdir -p "${project_dir}/Models" "${project_dir}/ViewModels" "${project_dir}/Views" "${project_dir}/Services" 2>/dev/null

            # ItemRepository.swift (プロトコル + CoreData実装)
            [[ ! -f "${project_dir}/Services/ItemRepository.swift" ]] && cat > "${project_dir}/Services/ItemRepository.swift" << 'ITEMREPO'
import Foundation
import CoreData

// MARK: - Repository Protocol
protocol ItemRepositoryProtocol {
    func fetchAll() async throws -> [Item]
    func fetch(byId id: UUID) async throws -> Item?
    func create(_ item: Item) async throws -> Item
    func update(_ item: Item) async throws -> Item
    func delete(byId id: UUID) async throws
}

// MARK: - CoreData Implementation
final class ItemRepository: ItemRepositoryProtocol {
    private let context: NSManagedObjectContext

    init(context: NSManagedObjectContext = PersistenceController.shared.container.viewContext) {
        self.context = context
    }

    func fetchAll() async throws -> [Item] {
        let request = ItemEntity.fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(keyPath: \ItemEntity.createdAt, ascending: false)]
        let entities = try context.fetch(request)
        return entities.map { $0.toItem() }
    }

    func fetch(byId id: UUID) async throws -> Item? {
        let request = ItemEntity.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", id as CVarArg)
        request.fetchLimit = 1
        return try context.fetch(request).first?.toItem()
    }

    func create(_ item: Item) async throws -> Item {
        let entity = ItemEntity(context: context)
        entity.id = item.id
        entity.name = item.name
        entity.detail = item.detail
        entity.createdAt = Date()
        entity.updatedAt = Date()
        try context.save()
        return entity.toItem()
    }

    func update(_ item: Item) async throws -> Item {
        let request = ItemEntity.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", item.id as CVarArg)
        guard let entity = try context.fetch(request).first else {
            throw RepositoryError.notFound
        }
        entity.name = item.name
        entity.detail = item.detail
        entity.updatedAt = Date()
        try context.save()
        return entity.toItem()
    }

    func delete(byId id: UUID) async throws {
        let request = ItemEntity.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", id as CVarArg)
        guard let entity = try context.fetch(request).first else {
            throw RepositoryError.notFound
        }
        context.delete(entity)
        try context.save()
    }
}

enum RepositoryError: LocalizedError {
    case notFound
    case saveFailed(Error)
    var errorDescription: String? {
        switch self {
        case .notFound: return "アイテムが見つかりません"
        case .saveFailed(let err): return "保存に失敗しました: \(err.localizedDescription)"
        }
    }
}
ITEMREPO

            # Item Model
            [[ ! -f "${project_dir}/Models/Item.swift" ]] && cat > "${project_dir}/Models/Item.swift" << 'ITEMMODEL'
import Foundation

struct Item: Identifiable, Hashable {
    let id: UUID
    var name: String
    var detail: String
    var createdAt: Date
    var updatedAt: Date

    init(id: UUID = UUID(), name: String = "", detail: String = "", createdAt: Date = Date(), updatedAt: Date = Date()) {
        self.id = id
        self.name = name
        self.detail = detail
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}
ITEMMODEL

            # ItemListViewModel.swift (ObservableObject + @Published)
            [[ ! -f "${project_dir}/ViewModels/ItemListViewModel.swift" ]] && cat > "${project_dir}/ViewModels/ItemListViewModel.swift" << 'ITEMVM'
import Foundation
import SwiftUI

@MainActor
final class ItemListViewModel: ObservableObject {
    @Published var items: [Item] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var searchText = ""

    private let repository: ItemRepositoryProtocol

    init(repository: ItemRepositoryProtocol = ItemRepository()) {
        self.repository = repository
    }

    var filteredItems: [Item] {
        guard !searchText.isEmpty else { return items }
        return items.filter {
            $0.name.localizedCaseInsensitiveContains(searchText) ||
            $0.detail.localizedCaseInsensitiveContains(searchText)
        }
    }

    func fetchAll() async {
        isLoading = true
        errorMessage = nil
        do {
            items = try await repository.fetchAll()
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    func create(_ item: Item) async {
        do {
            let created = try await repository.create(item)
            items.insert(created, at: 0)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func update(_ item: Item) async {
        do {
            let updated = try await repository.update(item)
            if let index = items.firstIndex(where: { $0.id == updated.id }) {
                items[index] = updated
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func delete(_ item: Item) async {
        do {
            try await repository.delete(byId: item.id)
            items.removeAll { $0.id == item.id }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
ITEMVM

            # ItemListView.swift (SwiftUI List)
            [[ ! -f "${project_dir}/Views/ItemListView.swift" ]] && cat > "${project_dir}/Views/ItemListView.swift" << 'ITEMLIST'
import SwiftUI

struct ItemListView: View {
    @StateObject private var viewModel = ItemListViewModel()
    @State private var showingAddForm = false

    var body: some View {
        NavigationStack {
            Group {
                if viewModel.isLoading {
                    ProgressView("読み込み中...")
                } else if let error = viewModel.errorMessage {
                    ContentUnavailableView {
                        Label("エラー", systemImage: "exclamationmark.triangle")
                    } description: {
                        Text(error)
                    } actions: {
                        Button("再試行") { Task { await viewModel.fetchAll() } }
                    }
                } else if viewModel.filteredItems.isEmpty {
                    ContentUnavailableView.search(text: viewModel.searchText)
                } else {
                    List {
                        ForEach(viewModel.filteredItems) { item in
                            NavigationLink(value: item) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(item.name).font(.headline)
                                    Text(item.detail).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                                }
                            }
                        }
                        .onDelete { indexSet in
                            for index in indexSet {
                                let item = viewModel.filteredItems[index]
                                Task { await viewModel.delete(item) }
                            }
                        }
                    }
                }
            }
            .navigationTitle("アイテム一覧")
            .searchable(text: $viewModel.searchText, prompt: "検索")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button { showingAddForm = true } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showingAddForm) {
                ItemFormView { newItem in
                    Task { await viewModel.create(newItem) }
                }
            }
            .navigationDestination(for: Item.self) { item in
                ItemFormView(item: item) { updated in
                    Task { await viewModel.update(updated) }
                }
            }
            .task { await viewModel.fetchAll() }
        }
    }
}

#Preview {
    ItemListView()
}
ITEMLIST

            # ItemFormView.swift (SwiftUI Form for create/edit)
            [[ ! -f "${project_dir}/Views/ItemFormView.swift" ]] && cat > "${project_dir}/Views/ItemFormView.swift" << 'ITEMFORM'
import SwiftUI

struct ItemFormView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var name: String
    @State private var detail: String
    private let existingItem: Item?
    private let onSave: (Item) -> Void

    var isEditing: Bool { existingItem != nil }

    init(item: Item? = nil, onSave: @escaping (Item) -> Void) {
        self.existingItem = item
        self.onSave = onSave
        _name = State(initialValue: item?.name ?? "")
        _detail = State(initialValue: item?.detail ?? "")
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("基本情報") {
                    TextField("名前", text: $name)
                    TextField("詳細", text: $detail, axis: .vertical)
                        .lineLimit(3...6)
                }
            }
            .navigationTitle(isEditing ? "編集" : "新規作成")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("キャンセル") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        let item = Item(
                            id: existingItem?.id ?? UUID(),
                            name: name,
                            detail: detail,
                            createdAt: existingItem?.createdAt ?? Date(),
                            updatedAt: Date()
                        )
                        onSave(item)
                        dismiss()
                    }
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }
}

#Preview {
    ItemFormView { item in
        print("Saved: \(item.name)")
    }
}
ITEMFORM
            _sc_log "SUCCESS" "iOS CRUD テンプレート作成完了"
            ;;

        *)
            # 静的サイト: JavaScriptでのCRUDヘルパー
            mkdir -p "${project_dir}/js" 2>/dev/null
            [[ ! -f "${project_dir}/js/crud-helper.js" ]] && cat > "${project_dir}/js/crud-helper.js" << 'JSCRUD'
'use strict';
/**
 * CRUD操作ヘルパー (v14.0)
 * 静的サイトでもAPI経由でCRUD操作を可能にする
 */
const CrudHelper = {
  apiBase: '/api',

  async fetchAll(entity) {
    try {
      const res = await fetch(`${this.apiBase}/${entity}`);
      if (!res.ok) throw new Error(`取得失敗: ${res.statusText}`);
      return await res.json();
    } catch (error) {
      console.error(`${entity}の取得に失敗:`, error);
      this.showError(`データの取得に失敗しました: ${error.message}`);
      return [];
    }
  },

  async create(entity, data) {
    try {
      const res = await fetch(`${this.apiBase}/${entity}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error(`作成失敗: ${res.statusText}`);
      this.showSuccess('データを作成しました');
      return await res.json();
    } catch (error) {
      this.showError(`作成に失敗しました: ${error.message}`);
      throw error;
    }
  },

  async update(entity, id, data) {
    try {
      const res = await fetch(`${this.apiBase}/${entity}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error(`更新失敗: ${res.statusText}`);
      this.showSuccess('データを更新しました');
      return await res.json();
    } catch (error) {
      this.showError(`更新に失敗しました: ${error.message}`);
      throw error;
    }
  },

  async remove(entity, id) {
    if (!confirm('本当に削除しますか？この操作は取り消せません。')) return null;
    try {
      const res = await fetch(`${this.apiBase}/${entity}/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error(`削除失敗: ${res.statusText}`);
      this.showSuccess('データを削除しました');
      return await res.json();
    } catch (error) {
      this.showError(`削除に失敗しました: ${error.message}`);
      throw error;
    }
  },

  showSuccess(msg) {
    const el = document.createElement('div');
    el.className = 'notification success';
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  },

  showError(msg) {
    const el = document.createElement('div');
    el.className = 'notification error';
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 5000);
  }
};
JSCRUD
            _sc_log "SUCCESS" "静的サイト CRUD ヘルパー作成完了"
            ;;
    esac
}

# ============================================================
# カスタムディレクトリ作成（ブループリント解析）
# ============================================================
_scaffold_custom_dirs() {
    local project_dir="$1" blueprint_file="$2"
    [[ ! -f "$blueprint_file" ]] && return 0
    _sc_log "INFO" "ブループリントからカスタムディレクトリを解析"
    local in_dir_section=false dirs_created=0
    while IFS= read -r line; do
        if echo "$line" | grep -qiE '(directory|ディレクトリ|structure|構造|folder|フォルダ)'; then
            in_dir_section=true; continue
        fi
        [[ "$in_dir_section" == true && -z "${line// /}" ]] && { in_dir_section=false; continue; }
        if [[ "$in_dir_section" == true ]]; then
            local dir_path
            dir_path=$(echo "$line" | sed -E 's/^[[:space:]]*[-*#│├└|]+[[:space:]]*//' | sed 's/[[:space:]]*#.*//' | sed 's|/$||' | tr -d '`')
            if [[ -n "$dir_path" && "$dir_path" =~ ^[a-zA-Z0-9_./-]+$ && ! "$dir_path" =~ \.\. ]]; then
                mkdir -p "${project_dir}/${dir_path}" 2>/dev/null && ((dirs_created++))
            fi
        fi
    done < "$blueprint_file"
    _sc_log "INFO" "カスタムディレクトリ ${dirs_created}個 作成"
}

# ============================================================
# プロジェクト検証
# ============================================================
scaffold_verify() {
    local project_dir="${1:-$SCAFFOLD_PROJECT_DIR}"
    [[ -z "$project_dir" || ! -d "$project_dir" ]] && { _sc_log "ERROR" "検証対象ディレクトリが存在しません"; return 1; }
    _sc_log "SECTION" "プロジェクト構造を検証中"
    local checks_passed=0 checks_total=0

    if [[ -f "${project_dir}/package.json" ]]; then
        ((checks_total++)); ((checks_passed++))
        _sc_log "INFO" "package.json 検出 - Node.jsプロジェクト"
        if [[ ! -d "${project_dir}/node_modules" ]] && command -v npm &>/dev/null; then
            ((checks_total++))
            _sc_run_cmd "cd '${project_dir}' && npm install --no-audit --no-fund 2>&1" "npm install 検証" "$SCAFFOLD_TIMEOUT" && ((checks_passed++))
        fi
    elif [[ -f "${project_dir}/requirements.txt" ]]; then
        ((checks_total++)); ((checks_passed++))
        _sc_log "INFO" "requirements.txt 検出 - Pythonプロジェクト"
        if [[ -f "${project_dir}/venv/bin/python" ]]; then
            ((checks_total++))
            _sc_run_cmd "'${project_dir}/venv/bin/pip' check 2>&1" "pip依存関係チェック" 30 && ((checks_passed++))
        fi
    elif [[ -f "${project_dir}/Package.swift" ]] || ls "${project_dir}/"*.xcodeproj &>/dev/null; then
        ((checks_total++)); ((checks_passed++))
        _sc_log "INFO" "Package.swift/.xcodeproj 検出 - iOSプロジェクト"
        if [[ -f "${project_dir}/Package.swift" ]] && command -v swift &>/dev/null; then
            ((checks_total++))
            _sc_run_cmd "cd '${project_dir}' && swift build --skip-update 2>&1" "swift build 検証" "$SCAFFOLD_TIMEOUT" && ((checks_passed++))
        fi
    elif [[ -f "${project_dir}/index.html" ]]; then
        ((checks_total++)); ((checks_passed++))
        _sc_log "INFO" "index.html 検出 - 静的サイト"
    else
        _sc_log "WARN" "主要ファイルが見つかりません (package.json / requirements.txt / Package.swift / index.html)"; return 1
    fi

    local file_count
    file_count=$(find "$project_dir" -maxdepth 3 -type f ! -path "*/node_modules/*" ! -path "*/.git/*" ! -path "*/venv/*" ! -path "*/__pycache__/*" 2>/dev/null | wc -l | tr -d ' ')
    _sc_log "INFO" "プロジェクトファイル数: ${file_count}"
    if [[ $checks_total -gt 0 && $checks_passed -eq $checks_total ]]; then
        _sc_log "SUCCESS" "検証完了: ${checks_passed}/${checks_total} チェック通過"; return 0
    else
        _sc_log "WARN" "検証結果: ${checks_passed}/${checks_total} チェック通過"; return 1
    fi
}

# ============================================================
_sc_log "INFO" "scaffolder.sh v9.0 ロード完了"
