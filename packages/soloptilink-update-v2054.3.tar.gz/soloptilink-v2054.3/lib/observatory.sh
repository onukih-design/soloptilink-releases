#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v14.0 - Unified Observatory
# =============================================================================
# Central observability aggregator. Collects data from all modules and provides:
# - Unified event stream (events.jsonl)
# - Cost attribution dashboard
# - Performance comparison
# - Integrated ASCII dashboard
# - JSON report export
# =============================================================================

[[ -n "${_OBSERVATORY_LOADED:-}" ]] && return 0
_OBSERVATORY_LOADED=1

# ============================================================
# State
# ============================================================
declare -g OBS_SESSION_ID=""
declare -g OBS_OUTPUT_DIR=""
declare -g OBS_TRACE_ID=""
declare -g OBS_EVENT_LOG=""
declare -g OBS_EVENT_COUNT=0
declare -g OBS_PHASES_COMPLETED=0
declare -g OBS_START_TIME=0
# Collected data caches
declare -g OBS_DAG_DATA=""
declare -g OBS_AGENT_DATA=""
declare -g OBS_HEALER_DATA=""
declare -g OBS_VALIDATOR_SCORE=""
declare -g OBS_SECURITY_SCORE=""
declare -g OBS_LOG_SUMMARY=""
# v15.0: Agent Runtime & Plugin data
declare -g OBS_AGENT_RUNTIME_DATA=""
declare -g OBS_PLUGIN_DATA=""

# ============================================================
# Internal logger
# ============================================================
_obs_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    echo -e "  ${color}[OBSERVATORY]${NC:-} ${msg}" >&2
}

# ============================================================
# Generate pseudo-UUID span identifier
# ============================================================
_obs_generate_span_id() {
    printf '%04x%04x' $RANDOM $RANDOM
}

# ============================================================
# Initialize observatory for a session
# ============================================================
obs_init() {
    local session_id="${1:-$SESSION_ID}"
    OBS_SESSION_ID="$session_id"
    OBS_START_TIME=$(date +%s)

    OBS_OUTPUT_DIR="${SESSION_LOG_DIR:-/tmp}/observatory"
    mkdir -p "$OBS_OUTPUT_DIR" 2>/dev/null || true

    OBS_EVENT_LOG="${OBS_OUTPUT_DIR}/events.jsonl"
    : > "$OBS_EVENT_LOG" 2>/dev/null || true

    # Use trace_id from trace-propagator if available
    if [[ -n "${TRACE_ROOT_ID:-}" ]]; then
        OBS_TRACE_ID="$TRACE_ROOT_ID"
    else
        OBS_TRACE_ID=$(_obs_generate_span_id)$(_obs_generate_span_id)
    fi

    OBS_EVENT_COUNT=0

    obs_emit_event "SESSION_START" "{\"session_id\":\"${session_id}\",\"version\":\"${VERSION:-14.0}\"}"
    _obs_log "INFO" "Observatory初期化: ${OBS_OUTPUT_DIR}"
}

# ============================================================
# Start a named span
# ============================================================
obs_span_start() {
    local name="${1:-unnamed}"
    local parent="${2:-root}"

    local span_id
    span_id=$(_obs_generate_span_id)

    # Delegate to trace-propagator if available
    if type -t trace_new_span &>/dev/null; then
        span_id=$(trace_new_span "$name" "$parent")
    fi

    obs_emit_event "SPAN_START" "{\"span_id\":\"${span_id}\",\"name\":\"${name}\",\"parent\":\"${parent}\"}"
    echo "$span_id"
}

# ============================================================
# End a span
# ============================================================
obs_span_end() {
    local span_id="${1:-}"
    local status="${2:-ok}"
    local metadata="${3:-{}}"

    # Delegate to trace-propagator
    if type -t trace_end_span &>/dev/null; then
        trace_end_span "$span_id" "$status"
    fi

    obs_emit_event "SPAN_END" "{\"span_id\":\"${span_id}\",\"status\":\"${status}\",\"metadata\":${metadata}}"
}

# ============================================================
# Emit event to events.jsonl
# ============================================================
obs_emit_event() {
    local event_type="${1:-GENERIC}"
    local payload="${2:-{}}"

    local ts
    ts=$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date +%s)

    OBS_EVENT_COUNT=$((OBS_EVENT_COUNT + 1))

    if [[ -n "$OBS_EVENT_LOG" ]]; then
        printf '{"timestamp":"%s","trace_id":"%s","event_num":%d,"type":"%s","payload":%s}\n' \
            "$ts" "${OBS_TRACE_ID}" "$OBS_EVENT_COUNT" "$event_type" "$payload" \
            >> "$OBS_EVENT_LOG" 2>/dev/null || true
    fi
}

# ============================================================
# Record cost entry (delegates to cost-engine)
# ============================================================
obs_record_cost() {
    local source="${1:-claude_call}"
    local amount="${2:-0.08}"
    local phase="${3:-unknown}"
    local agent="${4:-system}"

    if type -t cost_record &>/dev/null; then
        cost_record "$amount" "$phase" "$agent" ""
    fi

    obs_emit_event "COST" "{\"source\":\"${source}\",\"amount\":\"${amount}\",\"phase\":\"${phase}\",\"agent\":\"${agent}\"}"
}

# ============================================================
# Record performance metric
# ============================================================
obs_record_perf() {
    local metric="${1:-lcp}"
    local value="${2:-0}"
    local unit="${3:-ms}"
    local phase="${4:-browser_test}"

    # Record to perf-baseline if available
    if type -t perf_baseline_record &>/dev/null; then
        perf_baseline_record "$metric" "$value" "/" ""
    fi

    obs_emit_event "PERF" "{\"metric\":\"${metric}\",\"value\":\"${value}\",\"unit\":\"${unit}\",\"phase\":\"${phase}\"}"
}

# ============================================================
# Record coverage data
# ============================================================
obs_record_coverage() {
    local line="${1:-0}"
    local branch="${2:-0}"
    local func="${3:-0}"
    local stmt="${4:-0}"

    obs_emit_event "COVERAGE" "{\"line\":${line},\"branch\":${branch},\"func\":${func},\"stmt\":${stmt}}"
}

# ============================================================
# Collect data from DAG pipeline
# ============================================================
obs_collect_dag_data() {
    local nodes_total=0 nodes_completed=0 nodes_failed=0

    if declare -p DAG_STATUS &>/dev/null 2>&1; then
        for node_id in "${!DAG_STATUS[@]}"; do
            nodes_total=$((nodes_total + 1))
            case "${DAG_STATUS[$node_id]}" in
                completed) nodes_completed=$((nodes_completed + 1)) ;;
                failed)    nodes_failed=$((nodes_failed + 1)) ;;
            esac
        done
    fi

    OBS_DAG_DATA="{\"nodes_total\":${nodes_total},\"nodes_completed\":${nodes_completed},\"nodes_failed\":${nodes_failed}}"
}

# ============================================================
# Collect data from agent orchestrator
# ============================================================
obs_collect_agent_data() {
    local total="${AO_TOTAL_DISPATCHES:-0}"
    local succeeded="${AO_SUCCEEDED:-0}"
    local failed="${AO_FAILED:-0}"

    OBS_AGENT_DATA="{\"total_dispatches\":${total},\"succeeded\":${succeeded},\"failed\":${failed}}"
}

# ============================================================
# Collect data from healer
# ============================================================
obs_collect_healer_data() {
    local total="${HEAL_TOTAL_FIXES:-0}"
    local success="${HEAL_SUCCESSFUL_FIXES:-0}"
    local failed="${HEAL_FAILED_FIXES:-0}"

    OBS_HEALER_DATA="{\"total_fixes\":${total},\"successful\":${success},\"failed\":${failed}}"
}

# ============================================================
# Collect data from validator
# ============================================================
obs_collect_validator_data() {
    OBS_VALIDATOR_SCORE="${VLD_HEALTH_SCORE:-N/A}"
    OBS_SECURITY_SCORE="${SECURITY_SCORE:-N/A}"
}

# ============================================================
# Collect data from browser tests
# ============================================================
obs_collect_browser_data() {
    local lcp="${BT_PERF_LCP:-}"
    local fcp="${BT_PERF_FCP:-}"
    local cls="${BT_PERF_CLS:-}"
    local ttfb="${BT_PERF_TTFB:-}"

    # Feed into perf-baseline
    if type -t perf_baseline_record &>/dev/null; then
        [[ -n "$lcp" ]] && perf_baseline_record "lcp" "$lcp" "/" ""
        [[ -n "$fcp" ]] && perf_baseline_record "fcp" "$fcp" "/" ""
        [[ -n "$cls" ]] && perf_baseline_record "cls" "$cls" "/" ""
        [[ -n "$ttfb" ]] && perf_baseline_record "ttfb" "$ttfb" "/" ""
    fi
}

# ============================================================
# Collect data from logger
# ============================================================
obs_collect_logger_data() {
    if type -t log_summary &>/dev/null; then
        OBS_LOG_SUMMARY=$(log_summary 2>/dev/null || echo "")
    else
        OBS_LOG_SUMMARY="pass=${_LOG_COUNTS_PASS:-0} info=${_LOG_COUNTS_INFO:-0} warn=${_LOG_COUNTS_WARN:-0} error=${_LOG_COUNTS_ERROR:-0} critical=${_LOG_COUNTS_CRITICAL:-0}"
    fi
}

# ============================================================
# Collect ALL data from all modules
# ============================================================
obs_collect_all() {
    obs_collect_dag_data
    obs_collect_agent_data
    obs_collect_healer_data
    obs_collect_validator_data
    obs_collect_browser_data
    obs_collect_logger_data

    # Collect performance baselines
    if type -t perf_baseline_check_regression &>/dev/null; then
        perf_baseline_check_regression "${PB_REGRESSION_THRESHOLD:-10}" 2>/dev/null || true
    fi

    # v15.0: Agent Runtime metrics
    if type -t ar_report &>/dev/null; then
        OBS_AGENT_RUNTIME_DATA="calls=${AR_TOTAL_CALLS:-0},agent=${AR_AGENT_CALLS:-0},fallback=${AR_FALLBACK_CALLS:-0}"
    fi

    # v15.0: Plugin metrics
    if type -t pl_report &>/dev/null; then
        OBS_PLUGIN_DATA="plugins=${PL_TOTAL_PLUGINS:-0},hooks_fired=${PL_HOOKS_FIRED:-0}"
    fi

    obs_emit_event "COLLECT_ALL" "{\"status\":\"completed\"}"
    _obs_log "INFO" "全モジュールデータ収集完了"
}

# ============================================================
# Print cost attribution table
# ============================================================
obs_cost_report() {
    if type -t cost_breakdown_report &>/dev/null; then
        cost_breakdown_report
    else
        echo -e "  ${YELLOW:-}コストエンジン未ロード${NC:-}"
    fi
}

# ============================================================
# Print performance comparison
# ============================================================
obs_perf_report() {
    if type -t perf_baseline_report &>/dev/null; then
        perf_baseline_report
    else
        echo -e "  ${YELLOW:-}パフォーマンスベースライン未ロード${NC:-}"
    fi
}

# ============================================================
# Print full observatory dashboard
# ============================================================
obs_dashboard() {
    local now
    now=$(date +%s)
    local elapsed=$((now - OBS_START_TIME))
    local elapsed_min=$((elapsed / 60))
    local elapsed_sec=$((elapsed % 60))

    echo ""
    echo -e "  ${BOLD:-}${PURPLE:-}╔═══════════════════════════════════════════════════════════╗${NC:-}"
    echo -e "  ${BOLD:-}${PURPLE:-}║        🔭 Observatory Dashboard v14.0                    ║${NC:-}"
    echo -e "  ${BOLD:-}${PURPLE:-}╠═══════════════════════════════════════════════════════════╣${NC:-}"
    echo -e "  ║ Trace ID     : ${OBS_TRACE_ID}"
    echo -e "  ║ Session      : ${OBS_SESSION_ID}"
    echo -e "  ║ Duration     : ${elapsed_min}m${elapsed_sec}s"
    echo -e "  ║ Events       : ${OBS_EVENT_COUNT}"

    # Cost summary
    echo -e "  ║"
    echo -e "  ║ ${BOLD:-}--- Cost ---${NC:-}"
    echo -e "  ║ Total Cost   : \$${COST_USD_TOTAL:-${CLAUDE_ESTIMATED_COST:-0.00}}"
    echo -e "  ║ API Calls    : ${COST_CALLS_TOTAL:-${CLAUDE_CALL_COUNT:-0}}"

    # Top 3 phases by cost
    if [[ ${#COST_BY_PHASE[@]} -gt 0 ]]; then
        echo -e "  ║ Top phases   :"
        local sorted_phases
        sorted_phases=$(for p in "${!COST_BY_PHASE[@]}"; do echo "${COST_BY_PHASE[$p]} $p"; done | sort -rn | head -3)
        while IFS= read -r line; do
            local cost_val phase_name
            cost_val=$(echo "$line" | awk '{print $1}')
            phase_name=$(echo "$line" | awk '{print $2}')
            [[ -n "$phase_name" ]] && echo -e "  ║   \$${cost_val} - ${phase_name}"
        done <<< "$sorted_phases"
    fi

    # Health
    echo -e "  ║"
    echo -e "  ║ ${BOLD:-}--- Health ---${NC:-}"
    echo -e "  ║ Validator    : ${OBS_VALIDATOR_SCORE:-N/A}/100"
    echo -e "  ║ Security     : ${OBS_SECURITY_SCORE:-N/A}/100"
    echo -e "  ║ Logs         : ${OBS_LOG_SUMMARY:-N/A}"

    # DAG
    echo -e "  ║"
    echo -e "  ║ ${BOLD:-}--- DAG ---${NC:-}"
    echo -e "  ║ Nodes        : ${OBS_DAG_DATA:-N/A}"

    # Agents
    echo -e "  ║"
    echo -e "  ║ ${BOLD:-}--- Agents ---${NC:-}"
    echo -e "  ║ Dispatches   : ${OBS_AGENT_DATA:-N/A}"

    # Healing
    echo -e "  ║"
    echo -e "  ║ ${BOLD:-}--- Healing ---${NC:-}"
    echo -e "  ║ Fixes        : ${OBS_HEALER_DATA:-N/A}"

    # Coverage Gate
    if type -t covgate_report &>/dev/null && [[ -n "${CG_RESULT_LINE:-}" && "${CG_RESULT_LINE:-0}" -gt 0 ]]; then
        echo -e "  ║"
        echo -e "  ║ ${BOLD:-}--- Coverage ---${NC:-}"
        echo -e "  ║ Line         : ${CG_RESULT_LINE:-0}% (threshold: ${CG_THRESHOLD_LINE:-70}%)"
        echo -e "  ║ Gate         : $([ "${CG_GATE_PASSED:-1}" -eq 1 ] && echo "${GREEN:-}PASS${NC:-}" || echo "${RED:-}BLOCKED${NC:-}")"
    fi

    # Performance
    if [[ -n "${BT_PERF_LCP:-}" ]]; then
        echo -e "  ║"
        echo -e "  ║ ${BOLD:-}--- Performance ---${NC:-}"
        echo -e "  ║ LCP          : ${BT_PERF_LCP:-N/A}ms"
        echo -e "  ║ FCP          : ${BT_PERF_FCP:-N/A}ms"
        echo -e "  ║ CLS          : ${BT_PERF_CLS:-N/A}"
        echo -e "  ║ TTFB         : ${BT_PERF_TTFB:-N/A}ms"
        if [[ "${PB_REGRESSION_DETECTED:-0}" -eq 1 ]]; then
            echo -e "  ║ ${RED:-}⚠️ パフォーマンス回帰検出${NC:-}"
        fi
    fi

    # File Writer
    if [[ "${FW3_FILES_WRITTEN:-0}" -gt 0 || "${FW2_FILES_WRITTEN:-0}" -gt 0 ]]; then
        echo -e "  ║"
        echo -e "  ║ ${BOLD:-}--- File Writer ---${NC:-}"
        echo -e "  ║ Files Written: ${FW3_FILES_WRITTEN:-${FW2_FILES_WRITTEN:-0}}"
        echo -e "  ║ Clean Merges : ${FW3_MERGES_CLEAN:-0}"
        echo -e "  ║ Conflicts    : ${FW3_MERGES_CONFLICT:-0}"
    fi

    # v15.0 Agent Runtime Stats
    if [[ -n "${AR_TOTAL_CALLS:-}" ]]; then
        echo -e "  ${BOLD:-}[Agent Runtime v15.0]${NC:-}"
        echo -e "    Total agent calls:    ${AR_TOTAL_CALLS:-0}"
        echo -e "    Agent-routed calls:   ${AR_AGENT_CALLS:-0}"
        echo -e "    Fallback calls:       ${AR_FALLBACK_CALLS:-0}"
        if [[ -n "${AR_CALLS_BY_AGENT+x}" ]]; then
            for agent_id in "${!AR_CALLS_BY_AGENT[@]}"; do
                echo -e "      ${agent_id}: ${AR_CALLS_BY_AGENT[$agent_id]} calls"
            done
        fi
        echo ""
    fi

    # v15.0 Plugin Stats
    if [[ "${PL_ENABLED:-false}" == "true" ]]; then
        echo -e "  ${BOLD:-}[Plugin System v15.0]${NC:-}"
        echo -e "    Total plugins:        ${PL_TOTAL_PLUGINS:-0}"
        echo -e "    Total hooks fired:    ${PL_TOTAL_HOOKS_FIRED:-0}"
        echo ""
    fi

    # v15.0 Structured Output Stats
    if [[ "${SO_ENABLED:-false}" == "true" ]]; then
        echo -e "  ${BOLD:-}[Structured Output v15.0]${NC:-}"
        echo -e "    Total input tokens:   ${SO_TOTAL_INPUT_TOKENS:-0}"
        echo -e "    Total output tokens:  ${SO_TOTAL_OUTPUT_TOKENS:-0}"
        echo -e "    Total calls:          ${SO_TOTAL_CALLS:-0}"
        echo ""
    fi

    echo -e "  ${BOLD:-}${PURPLE:-}╚═══════════════════════════════════════════════════════════╝${NC:-}"
    echo ""
}

# ============================================================
# Export comprehensive JSON report
# ============================================================
obs_export_json() {
    local output_file="${OBS_OUTPUT_DIR}/observatory_report.json"
    local now
    now=$(date +%s)
    local duration=$((now - OBS_START_TIME))

    local ts
    ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)

    {
        echo "{"
        echo "  \"version\": \"14.0\","
        echo "  \"session_id\": \"${OBS_SESSION_ID}\","
        echo "  \"trace_id\": \"${OBS_TRACE_ID}\","
        echo "  \"timestamp\": \"${ts}\","
        echo "  \"duration_seconds\": ${duration},"
        echo "  \"event_count\": ${OBS_EVENT_COUNT},"
        echo "  \"cost\": {"
        echo "    \"total_usd\": \"${COST_USD_TOTAL:-${CLAUDE_ESTIMATED_COST:-0.00}}\","
        echo "    \"total_calls\": ${COST_CALLS_TOTAL:-${CLAUDE_CALL_COUNT:-0}},"
        echo "    \"by_phase\": $(type -t cost_by_phase &>/dev/null && cost_by_phase || echo "{}"),"
        echo "    \"by_agent\": $(type -t cost_by_agent &>/dev/null && cost_by_agent || echo "{}"),"
        echo "    \"by_domain\": $(type -t cost_by_domain &>/dev/null && cost_by_domain || echo "{}")"
        echo "  },"
        echo "  \"health\": {"
        echo "    \"validator_score\": \"${OBS_VALIDATOR_SCORE:-N/A}\","
        echo "    \"security_score\": \"${OBS_SECURITY_SCORE:-N/A}\","
        local _log_safe
        _log_safe=$(echo "${OBS_LOG_SUMMARY:-}" | tr '"' "'" | tr '\n' ' ')
        echo "    \"log_summary\": \"${_log_safe}\""
        echo "  },"
        echo "  \"dag\": ${OBS_DAG_DATA:-{}},"
        echo "  \"agents\": ${OBS_AGENT_DATA:-{}},"
        echo "  \"healing\": ${OBS_HEALER_DATA:-{}},"
        echo "  \"coverage\": {"
        echo "    \"line\": ${CG_RESULT_LINE:-0},"
        echo "    \"branch\": ${CG_RESULT_BRANCH:-0},"
        echo "    \"function\": ${CG_RESULT_FUNC:-0},"
        echo "    \"statement\": ${CG_RESULT_STMT:-0},"
        echo "    \"gate_passed\": $([ "${CG_GATE_PASSED:-1}" -eq 1 ] && echo "true" || echo "false")"
        echo "  },"
        echo "  \"performance\": {"
        echo "    \"lcp\": \"${BT_PERF_LCP:-N/A}\","
        echo "    \"fcp\": \"${BT_PERF_FCP:-N/A}\","
        echo "    \"cls\": \"${BT_PERF_CLS:-N/A}\","
        echo "    \"ttfb\": \"${BT_PERF_TTFB:-N/A}\","
        echo "    \"regression_detected\": $([ "${PB_REGRESSION_DETECTED:-0}" -eq 1 ] && echo "true" || echo "false")"
        echo "  },"
        echo "  \"file_writer\": {"
        echo "    \"files_written\": ${FW3_FILES_WRITTEN:-${FW2_FILES_WRITTEN:-0}},"
        echo "    \"merges_clean\": ${FW3_MERGES_CLEAN:-0},"
        echo "    \"merges_conflict\": ${FW3_MERGES_CONFLICT:-0}"
        echo "  },"
        echo "  \"agent_runtime\": {"
        echo "    \"total_calls\": ${AR_TOTAL_CALLS:-0},"
        echo "    \"agent_routed\": ${AR_AGENT_CALLS:-0},"
        echo "    \"fallback\": ${AR_FALLBACK_CALLS:-0}"
        echo "  },"
        echo "  \"plugin_system\": {"
        echo "    \"total_plugins\": ${PL_TOTAL_PLUGINS:-0},"
        echo "    \"hooks_fired\": ${PL_TOTAL_HOOKS_FIRED:-0}"
        echo "  },"
        echo "  \"structured_output\": {"
        echo "    \"total_input_tokens\": ${SO_TOTAL_INPUT_TOKENS:-0},"
        echo "    \"total_output_tokens\": ${SO_TOTAL_OUTPUT_TOKENS:-0},"
        echo "    \"total_calls\": ${SO_TOTAL_CALLS:-0}"
        echo "  },"
        echo "  \"traces\": {"
        echo "    \"total_spans\": ${TRACE_SPAN_COUNT:-0},"
        echo "    \"spans_file\": \"observatory/traces.jsonl\""
        echo "  }"
        echo "}"
    } > "$output_file" 2>/dev/null

    obs_emit_event "SESSION_END" "{\"duration_seconds\":${duration},\"event_count\":${OBS_EVENT_COUNT}}"
    _obs_log "INFO" "レポートエクスポート: ${output_file}"
}
