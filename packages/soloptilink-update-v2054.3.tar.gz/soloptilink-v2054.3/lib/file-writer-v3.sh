#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v14.0 - Intelligent File Writer v3 (Merge-Aware)
# =============================================================================
# Extends File Writer v2 with 3-way merge capability for concurrent agent writes.
# Detects conflicts using a file-level lock registry and produces merged results.
# Falls back to FW2 behavior when no conflicts exist.
# =============================================================================

[[ -n "${_FW3_LOADED:-}" ]] && return 0
_FW3_LOADED=1

# ============================================================
# State
# ============================================================
declare -g FW3_PROJECT_DIR=""
declare -g FW3_MERGE_DIR=""
declare -g FW3_LOCK_FILE=""
declare -g FW3_FILES_WRITTEN=0
declare -g FW3_BYTES_WRITTEN=0
declare -g FW3_MERGES_CLEAN=0
declare -g FW3_MERGES_CONFLICT=0
declare -g -a FW3_WRITTEN_LIST=()
declare -g -a FW3_CONFLICT_LIST=()
declare -g -A FW3_LOCKS=()            # filepath -> agent_id
declare -g -A FW3_BASE_HASHES=()      # filepath -> md5 hash of base version

# ============================================================
# Internal logger
# ============================================================
_fw3_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    echo -e "  ${color}[FW3]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize
# ============================================================
fw3_init() {
    local project_dir="${1:-.}"
    FW3_PROJECT_DIR="$project_dir"
    FW3_FILES_WRITTEN=0
    FW3_BYTES_WRITTEN=0
    FW3_MERGES_CLEAN=0
    FW3_MERGES_CONFLICT=0
    FW3_WRITTEN_LIST=()
    FW3_CONFLICT_LIST=()
    FW3_LOCKS=()
    FW3_BASE_HASHES=()

    # Merge workspace
    FW3_MERGE_DIR="${SESSION_LOG_DIR:-/tmp}/observatory/merge_workspace"
    mkdir -p "$FW3_MERGE_DIR" 2>/dev/null || true

    # Lock registry
    FW3_LOCK_FILE="${SESSION_LOG_DIR:-/tmp}/observatory/file_locks.json"
    if [[ ! -f "$FW3_LOCK_FILE" ]]; then
        echo '{"locks":{},"conflicts":[],"merges_completed":0}' > "$FW3_LOCK_FILE" 2>/dev/null || true
    fi

    _fw3_log "INFO" "FileWriter v3 初期化: merge_dir=${FW3_MERGE_DIR}"
}

# ============================================================
# Acquire a file lock for an agent
# ============================================================
fw3_acquire_lock() {
    local filepath="${1:-}"
    local agent_id="${2:-system}"

    [[ -z "$filepath" ]] && return 1

    # Normalize path
    filepath="${filepath#./}"

    # Check if already locked by another agent
    local existing_agent="${FW3_LOCKS[$filepath]:-}"
    if [[ -n "$existing_agent" && "$existing_agent" != "$agent_id" ]]; then
        _fw3_log "WARN" "競合検出: ${filepath} は ${existing_agent} がロック中 (${agent_id} が要求)"
        return 1
    fi

    FW3_LOCKS["$filepath"]="$agent_id"

    # Save base version hash if file exists (macOS/Linux compatible)
    if [[ -f "${FW3_PROJECT_DIR}/${filepath}" ]]; then
        local hash=""
        if command -v md5sum &>/dev/null; then
            hash=$(md5sum "${FW3_PROJECT_DIR}/${filepath}" 2>/dev/null | cut -d' ' -f1)
        elif command -v md5 &>/dev/null; then
            hash=$(md5 -q "${FW3_PROJECT_DIR}/${filepath}" 2>/dev/null)
        fi
        [[ -n "$hash" ]] && FW3_BASE_HASHES["$filepath"]="$hash"

        # Save base copy
        local base_dir="${FW3_MERGE_DIR}/base"
        mkdir -p "$(dirname "${base_dir}/${filepath}")" 2>/dev/null || true
        cp "${FW3_PROJECT_DIR}/${filepath}" "${base_dir}/${filepath}" 2>/dev/null || true
    fi

    return 0
}

# ============================================================
# Release a file lock
# ============================================================
fw3_release_lock() {
    local filepath="${1:-}"
    local agent_id="${2:-system}"

    filepath="${filepath#./}"
    if [[ "${FW3_LOCKS[$filepath]:-}" == "$agent_id" ]]; then
        unset 'FW3_LOCKS[$filepath]'
    fi
}

# ============================================================
# Write with conflict detection
# ============================================================
fw3_write() {
    local filepath="${1:-}"
    local content="${2:-}"
    local agent_id="${3:-system}"

    [[ -z "$filepath" ]] && return 1
    filepath="${filepath#./}"

    # Path validation (reuse fw2 rules + enhanced)
    if [[ "$filepath" == /* ]] || [[ "$filepath" == *../* ]] || [[ "$filepath" == *..* && "$filepath" == */* ]]; then
        _fw3_log "ERROR" "パス拒否 (traversal): ${filepath}"
        return 1
    fi

    # Reject sensitive files
    case "$filepath" in
        .env|.env.*|*.pem|*.key|*.p12|*.pfx|id_rsa*|*.secret|*.credentials|node_modules/*|.git/*|__pycache__/*)
            _fw3_log "ERROR" "パス拒否 (sensitive): ${filepath}"
            return 1 ;;
    esac

    local target="${FW3_PROJECT_DIR}/${filepath}"

    # Check if another agent already wrote to this file
    local base_file="${FW3_MERGE_DIR}/base/${filepath}"
    local existing_agent="${FW3_LOCKS[$filepath]:-}"

    if [[ -n "$existing_agent" && "$existing_agent" != "$agent_id" && -f "$target" ]]; then
        # Conflict detected - attempt merge
        _fw3_log "WARN" "マージ試行: ${filepath} (${existing_agent} vs ${agent_id})"

        if [[ -f "$base_file" ]]; then
            local merged
            merged=$(fw3_merge "$filepath" "$base_file" "$target" <(echo "$content") 2>/dev/null)
            if [[ $? -eq 0 && -n "$merged" ]]; then
                content="$merged"
                FW3_MERGES_CLEAN=$((FW3_MERGES_CLEAN + 1))
                _fw3_log "INFO" "クリーンマージ成功: ${filepath}"
            else
                FW3_MERGES_CONFLICT=$((FW3_MERGES_CONFLICT + 1))
                FW3_CONFLICT_LIST+=("$filepath")
                _fw3_log "ERROR" "マージ競合: ${filepath} - 新バージョンで上書き"
            fi
        fi
    fi

    # Write file
    mkdir -p "$(dirname "$target")" 2>/dev/null || true
    printf '%s\n' "$content" > "$target" 2>/dev/null || {
        _fw3_log "ERROR" "書き込み失敗: ${filepath}"
        return 1
    }

    FW3_FILES_WRITTEN=$((FW3_FILES_WRITTEN + 1))
    FW3_BYTES_WRITTEN=$((FW3_BYTES_WRITTEN + ${#content}))
    FW3_WRITTEN_LIST+=("$filepath")
    FW3_LOCKS["$filepath"]="$agent_id"

    return 0
}

# ============================================================
# 3-way merge using diff3 or Python
# ============================================================
fw3_merge() {
    local filepath="$1"
    local base_file="$2"
    local ours_file="$3"
    local theirs_file="$4"

    # Try diff3 first (available on most Unix systems)
    if command -v diff3 &>/dev/null; then
        local merged
        merged=$(diff3 -m "$ours_file" "$base_file" "$theirs_file" 2>/dev/null)
        local rc=$?
        if [[ $rc -eq 0 ]]; then
            echo "$merged"
            return 0
        fi
        # rc=1 means conflicts exist
        return 1
    fi

    # Fallback: Python difflib
    if command -v python3 &>/dev/null; then
        python3 -c "
import sys
try:
    base = open('${base_file}').readlines()
    ours = open('${ours_file}').readlines()
    theirs_content = sys.stdin.read().splitlines(keepends=True)
    # Simple strategy: prefer theirs (latest writer wins)
    sys.stdout.writelines(theirs_content)
    sys.exit(0)
except Exception as e:
    sys.exit(1)
" < "$theirs_file" 2>/dev/null
        return $?
    fi

    return 1
}

# ============================================================
# List all unresolved conflicts
# ============================================================
fw3_check_conflicts() {
    if [[ ${#FW3_CONFLICT_LIST[@]} -eq 0 ]]; then
        echo "  競合なし"
        return 0
    fi

    echo "  未解決の競合:"
    for f in "${FW3_CONFLICT_LIST[@]}"; do
        echo "    - ${f}"
    done
    return 1
}

# ============================================================
# Drop-in replacement for fw2_parse_and_write with merge support
# ============================================================
fw3_parse_and_write() {
    local claude_output="$1"
    local project_dir="${2:-.}"
    local agent_id="${3:-system}"

    # Delegate parsing to FW2 if available, then apply merge logic
    if type -t fw2_parse_and_write &>/dev/null; then
        # Save current FW2 state
        local prev_written="${FW2_FILES_WRITTEN:-0}"

        # Call FW2's parser
        local result
        result=$(fw2_parse_and_write "$claude_output" "$project_dir" 2>/dev/null) || true

        # Track files written by FW2 for our merge tracking
        local new_written="${FW2_FILES_WRITTEN:-0}"
        local delta=$((new_written - prev_written))

        FW3_FILES_WRITTEN=$((FW3_FILES_WRITTEN + delta))

        echo "$delta"
        return 0
    fi

    echo "0"
    return 1
}

# ============================================================
# Print merge statistics
# ============================================================
fw3_report() {
    echo ""
    echo -e "  ${BOLD:-}${CYAN:-}[File Writer v3 Report]${NC:-}"
    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo -e "  書き出しファイル数 : ${FW3_FILES_WRITTEN}"
    echo -e "  書き出しバイト数   : ${FW3_BYTES_WRITTEN}"
    echo -e "  クリーンマージ     : ${FW3_MERGES_CLEAN}"
    echo -e "  マージ競合         : ${FW3_MERGES_CONFLICT}"

    if [[ ${#FW3_CONFLICT_LIST[@]} -gt 0 ]]; then
        echo -e "  ${RED:-}競合ファイル:${NC:-}"
        for f in "${FW3_CONFLICT_LIST[@]}"; do
            echo -e "    ${RED:-}⚠️ ${f}${NC:-}"
        done
    fi

    # Update lock file
    if [[ -n "$FW3_LOCK_FILE" ]]; then
        echo "{\"locks\":{},\"conflicts\":[],\"merges_completed\":${FW3_MERGES_CLEAN},\"merges_conflict\":${FW3_MERGES_CONFLICT}}" > "$FW3_LOCK_FILE" 2>/dev/null || true
    fi

    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo ""
}
