#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v377.0 - Industry Template: Restaurant
# =============================================================================
# 飲食店特化テンプレートエンジン。
# メニュー管理/注文/デリバリー/レビュー/テーブル予約等の飲食必須コンポーネントを自動生成。
#
# All globals use the ITRS_ prefix.
# =============================================================================

[[ -n "${_INDUSTRY_TEMPLATE_RESTAURANT_LOADED:-}" ]] && return 0
_INDUSTRY_TEMPLATE_RESTAURANT_LOADED=1

declare -g ITRS_VERSION="377.0"
declare -g ITRS_INITIALIZED=false
declare -g ITRS_GENERATED_COUNT=0
declare -g ITRS_MENU_GENERATED=false
declare -g ITRS_ORDER_GENERATED=false
declare -g ITRS_DELIVERY_GENERATED=false
declare -g ITRS_REVIEW_GENERATED=false
declare -g ENABLE_ITRS="${ENABLE_ITRS:-true}"

_itrs_init() {
    ITRS_INITIALIZED=true
    ITRS_GENERATED_COUNT=0
    return 0
}

_itrs_generate_restaurant() {
    local project_dir="${1:-.}"
    [[ "$ITRS_INITIALIZED" != "true" ]] && _itrs_init

    echo -e "  ${CYAN:-\033[0;36m}[ITRS]${NC:-\033[0m} 飲食業界テンプレート生成開始..." >&2

    _itrs_generate_menu "$project_dir"
    _itrs_generate_order "$project_dir"
    _itrs_generate_delivery "$project_dir"
    _itrs_generate_review "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[ITRS]${NC:-\033[0m} 飲食業界テンプレート生成完了: ${ITRS_GENERATED_COUNT}件" >&2
    return 0
}

_itrs_generate_menu() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITRS-MENU] メニュー管理テンプレート

### Prisma Schema
```prisma
model MenuCategory {
  id        String     @id @default(cuid())
  name      String
  slug      String     @unique
  sortOrder Int        @default(0)
  isActive  Boolean    @default(true)
  items     MenuItem[]
}

model MenuItem {
  id          String   @id @default(cuid())
  name        String
  description String?
  price       Int
  image       String?
  categoryId  String
  category    MenuCategory @relation(fields: [categoryId], references: [id])
  isAvailable Boolean  @default(true)
  isPopular   Boolean  @default(false)
  allergens   String[]
  calories    Int?
  options     MenuOption[]
  orderItems  OrderItem[]
  @@index([categoryId])
  @@index([isAvailable])
}

model MenuOption {
  id         String   @id @default(cuid())
  menuItemId String
  menuItem   MenuItem @relation(fields: [menuItemId], references: [id], onDelete: Cascade)
  name       String
  choices    Json
  isRequired Boolean @default(false)
}
```

### Digital Menu Component
```tsx
'use client';
export function DigitalMenu({ restaurantId }: { restaurantId: string }) {
  const { data, isLoading } = useSWR(`/api/restaurants/${restaurantId}/menu`);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  if (isLoading) return <MenuSkeleton />;
  const categories = data?.categories ?? [];
  const activeCategory = selectedCategory ?? categories[0]?.id;

  return (
    <div className="space-y-6">
      <div className="flex gap-2 overflow-x-auto pb-2">
        {categories.map((cat: MenuCategory) => (
          <Button key={cat.id} variant={cat.id === activeCategory ? "default" : "outline"}
            onClick={() => setSelectedCategory(cat.id)} size="sm">
            {cat.name}
          </Button>
        ))}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {categories.find((c: MenuCategory) => c.id === activeCategory)?.items
          .filter((i: MenuItem) => i.isAvailable)
          .map((item: MenuItem) => <MenuItemCard key={item.id} item={item} />)}
      </div>
    </div>
  );
}
```
TEMPLATE

    ITRS_MENU_GENERATED=true
    ITRS_GENERATED_COUNT=$((ITRS_GENERATED_COUNT + 1))
    return 0
}

_itrs_generate_order() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITRS-ORDER] 注文管理テンプレート

### Schema
```prisma
model Order {
  id           String   @id @default(cuid())
  orderNumber  String   @unique
  type         String   @default("dine_in")
  tableNumber  Int?
  customerId   String?
  status       String   @default("pending")
  items        OrderItem[]
  subtotal     Int
  tax          Int
  total        Int
  paymentMethod String?
  paidAt       DateTime?
  notes        String?
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt
  @@index([status])
  @@index([createdAt])
}

model OrderItem {
  id         String   @id @default(cuid())
  orderId    String
  order      Order    @relation(fields: [orderId], references: [id])
  menuItemId String
  menuItem   MenuItem @relation(fields: [menuItemId], references: [id])
  quantity   Int
  unitPrice  Int
  options    Json?
  notes      String?
}
```

### Kitchen Display System
```tsx
'use client';
export function KitchenDisplay() {
  const { data, mutate } = useSWR('/api/orders?status=pending,preparing', { refreshInterval: 5000 });
  const updateStatus = async (orderId: string, status: string) => {
    await fetch(`/api/orders/${orderId}/status`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    mutate();
  };
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4 p-4">
      {data?.orders?.map((order: Order) => (
        <div key={order.id} className={cn("border rounded-lg p-4", order.status === 'pending' ? 'border-red-500' : 'border-yellow-500')}>
          <div className="flex justify-between items-center mb-2">
            <span className="font-bold text-lg">#{order.orderNumber}</span>
            <Badge>{order.type === 'dine_in' ? `T${order.tableNumber}` : order.type}</Badge>
          </div>
          {order.items.map((item: OrderItem) => (
            <div key={item.id} className="py-1">
              <span className="font-medium">{item.quantity}x {item.menuItem.name}</span>
              {item.notes && <p className="text-sm text-muted-foreground">{item.notes}</p>}
            </div>
          ))}
          <Button className="w-full mt-3" onClick={() => updateStatus(order.id, order.status === 'pending' ? 'preparing' : 'ready')}>
            {order.status === 'pending' ? '調理開始' : '完成'}
          </Button>
        </div>
      ))}
    </div>
  );
}
```
TEMPLATE

    ITRS_ORDER_GENERATED=true
    ITRS_GENERATED_COUNT=$((ITRS_GENERATED_COUNT + 1))
    return 0
}

_itrs_generate_delivery() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITRS-DELIVERY] デリバリー管理テンプレート

### Delivery Tracking
```typescript
export async function createDeliveryOrder(orderId: string, address: DeliveryAddress) {
  const order = await prisma.order.findUniqueOrThrow({ where: { id: orderId } });
  const delivery = await prisma.delivery.create({
    data: { orderId, address: JSON.stringify(address), status: 'assigned',
      estimatedDeliveryAt: addMinutes(new Date(), 45), fee: calculateDeliveryFee(address) },
  });
  return delivery;
}

export async function updateDeliveryStatus(deliveryId: string, status: string, location?: { lat: number; lng: number }) {
  const data: any = { status };
  if (status === 'delivered') data.deliveredAt = new Date();
  if (location) data.currentLocation = JSON.stringify(location);
  return prisma.delivery.update({ where: { id: deliveryId }, data });
}
```
TEMPLATE

    ITRS_DELIVERY_GENERATED=true
    ITRS_GENERATED_COUNT=$((ITRS_GENERATED_COUNT + 1))
    return 0
}

_itrs_generate_review() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITRS-REVIEW] レビュー管理テンプレート

### Review Component
```tsx
'use client';
export function ReviewForm({ restaurantId }: { restaurantId: string }) {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({
    resolver: zodResolver(z.object({
      rating: z.number().min(1).max(5), food: z.number().min(1).max(5),
      service: z.number().min(1).max(5), atmosphere: z.number().min(1).max(5),
      comment: z.string().min(10, '10文字以上で入力してください').max(1000),
    })),
  });
  const onSubmit = async (data: any) => {
    await fetch(`/api/restaurants/${restaurantId}/reviews`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data),
    });
    toast.success('レビューを投稿しました');
  };
  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <StarRating label="総合評価" {...register('rating', { valueAsNumber: true })} error={errors.rating?.message} />
      <StarRating label="料理" {...register('food', { valueAsNumber: true })} />
      <StarRating label="サービス" {...register('service', { valueAsNumber: true })} />
      <StarRating label="雰囲気" {...register('atmosphere', { valueAsNumber: true })} />
      <Textarea label="コメント" {...register('comment')} error={errors.comment?.message} />
      <Button type="submit" disabled={isSubmitting}>{isSubmitting ? '投稿中...' : 'レビューを投稿'}</Button>
    </form>
  );
}
```
TEMPLATE

    ITRS_REVIEW_GENERATED=true
    ITRS_GENERATED_COUNT=$((ITRS_GENERATED_COUNT + 1))
    return 0
}

_itrs_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Industry Template: Restaurant v${ITRS_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成テンプレート数 : ${ITRS_GENERATED_COUNT}"
    echo -e "  Menu               : ${ITRS_MENU_GENERATED}"
    echo -e "  Order              : ${ITRS_ORDER_GENERATED}"
    echo -e "  Delivery           : ${ITRS_DELIVERY_GENERATED}"
    echo -e "  Review             : ${ITRS_REVIEW_GENERATED}"
}

_itrs_score() {
    local score=30
    [[ "$ITRS_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$ITRS_MENU_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITRS_ORDER_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITRS_DELIVERY_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITRS_REVIEW_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "industry-template-restaurant" \
    --version "377.0" \
    --description "飲食業界テンプレート（メニュー/注文/デリバリー/レビュー）" \
    --init "_itrs_init" \
    --report "_itrs_report" \
    --score "_itrs_score" \
    --enable-var "ENABLE_ITRS" \
    --cli-flags "--industry-restaurant:--no-industry-restaurant"
