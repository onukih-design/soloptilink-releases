#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v425.0 - Batch Processing Engine
# =============================================================================
# 大量ファイルのバッチ処理エンジン。ファイルをチャンクに分割し、
# 進捗追跡付きで順次/並列処理する。エラー耐性とリトライ機能を持つ。
#
# Functions:
#   _bpe_init()             - 初期化
#   _bpe_batch_files()      - ファイルをバッチに分割
#   _bpe_track_progress()   - 進捗追跡
#   _bpe_handle_errors()    - エラーハンドリング・リトライ
#   _bpe_report() / _bpe_score()
#
# All globals use the BPE_ prefix.
# =============================================================================

[[ -n "${_BPE_LOADED:-}" ]] && return 0; _BPE_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g BPE_VERSION="425.0"
declare -g BPE_GENERATED=0
declare -g BPE_ERRORS=0
declare -g BPE_BATCH_SIZE="${BPE_BATCH_SIZE:-10}"
declare -g BPE_MAX_RETRIES="${BPE_MAX_RETRIES:-3}"
declare -g BPE_TOTAL_FILES=0
declare -g BPE_PROCESSED=0
declare -g BPE_FAILED=0
declare -g BPE_RETRIED=0
declare -g BPE_BATCHES_TOTAL=0
declare -g BPE_BATCHES_DONE=0
declare -g BPE_START_TIME=0
declare -g BPE_PROGRESS_FILE="${BPE_PROGRESS_FILE:-.soloptilink/batch/progress.json}"

declare -ga _BPE_FILE_LIST=()
declare -ga _BPE_FAILED_FILES=()
declare -gA _BPE_RETRY_COUNT=()

_BPE_GREEN="${GREEN:-\033[0;32m}"
_BPE_RED="${RED:-\033[0;31m}"
_BPE_YELLOW="${YELLOW:-\033[0;33m}"
_BPE_CYAN="${CYAN:-\033[0;36m}"
_BPE_BOLD="${BOLD:-\033[1m}"
_BPE_NC="${NC:-\033[0m}"

# =============================================================================
# Init
# =============================================================================
_bpe_init() {
    BPE_GENERATED=0
    BPE_ERRORS=0
    BPE_TOTAL_FILES=0
    BPE_PROCESSED=0
    BPE_FAILED=0
    BPE_RETRIED=0
    BPE_BATCHES_TOTAL=0
    BPE_BATCHES_DONE=0
    BPE_START_TIME=0
    _BPE_FILE_LIST=()
    _BPE_FAILED_FILES=()
    _BPE_RETRY_COUNT=()
    mkdir -p "$(dirname "$BPE_PROGRESS_FILE")" 2>/dev/null
    return 0
}

_bpe_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_BPE_CYAN}[BPE]${_BPE_NC} $*" >&2 ;;
        ok)    echo -e "  ${_BPE_GREEN}[BPE]${_BPE_NC} $*" >&2 ;;
        warn)  echo -e "  ${_BPE_YELLOW}[BPE]${_BPE_NC} $*" >&2 ;;
        error) echo -e "  ${_BPE_RED}[BPE]${_BPE_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _bpe_batch_files - ファイルをバッチに分割
# =============================================================================
_bpe_batch_files() {
    local project_dir="${1:-.}"
    local pattern="${2:-*.ts}"
    local batch_size="${3:-$BPE_BATCH_SIZE}"

    _bpe_log info "バッチ分割開始: ${project_dir} (パターン: ${pattern}, サイズ: ${batch_size})"

    _BPE_FILE_LIST=()
    while IFS= read -r -d '' file; do
        _BPE_FILE_LIST+=("$file")
    done < <(find "$project_dir" -name "$pattern" \
             -not -path "*/node_modules/*" -not -path "*/.next/*" \
             -not -path "*/dist/*" -print0 2>/dev/null)

    BPE_TOTAL_FILES=${#_BPE_FILE_LIST[@]}
    BPE_BATCHES_TOTAL=$(( (BPE_TOTAL_FILES + batch_size - 1) / batch_size ))
    BPE_START_TIME=$(date +%s 2>/dev/null || echo 0)

    _bpe_log ok "バッチ分割完了: ${BPE_TOTAL_FILES}ファイル → ${BPE_BATCHES_TOTAL}バッチ"
    BPE_GENERATED=$((BPE_GENERATED + 1))

    # バッチ情報を返す
    echo "${BPE_BATCHES_TOTAL}"
    return 0
}

# =============================================================================
# _bpe_process_batch - 1バッチを処理
# =============================================================================
_bpe_process_batch() {
    local batch_idx="$1"
    local processor_fn="${2:-echo}"
    local batch_size="${3:-$BPE_BATCH_SIZE}"

    local start_idx=$((batch_idx * batch_size))
    local end_idx=$((start_idx + batch_size))
    [[ $end_idx -gt ${#_BPE_FILE_LIST[@]} ]] && end_idx=${#_BPE_FILE_LIST[@]}

    local batch_count=$((end_idx - start_idx))
    _bpe_log info "バッチ $((batch_idx + 1))/${BPE_BATCHES_TOTAL}: ${batch_count}ファイル処理"

    local success=0
    local fail=0

    for ((i=start_idx; i<end_idx; i++)); do
        local file="${_BPE_FILE_LIST[$i]}"
        if type -t "$processor_fn" &>/dev/null; then
            if $processor_fn "$file" 2>/dev/null; then
                success=$((success + 1))
                BPE_PROCESSED=$((BPE_PROCESSED + 1))
            else
                fail=$((fail + 1))
                _BPE_FAILED_FILES+=("$file")
                _BPE_RETRY_COUNT["$file"]=$(( ${_BPE_RETRY_COUNT["$file"]:-0} + 1 ))
            fi
        else
            BPE_PROCESSED=$((BPE_PROCESSED + 1))
            success=$((success + 1))
        fi
    done

    BPE_BATCHES_DONE=$((BPE_BATCHES_DONE + 1))
    BPE_FAILED=$((BPE_FAILED + fail))

    _bpe_track_progress

    if [[ $fail -gt 0 ]]; then
        _bpe_log warn "バッチ完了: ${success}成功, ${fail}失敗"
    else
        _bpe_log ok "バッチ完了: ${success}成功"
    fi

    return 0
}

# =============================================================================
# _bpe_track_progress - 進捗追跡
# =============================================================================
_bpe_track_progress() {
    local now
    now=$(date +%s 2>/dev/null || echo 0)
    local elapsed=$((now - BPE_START_TIME))
    local percent=0
    [[ $BPE_TOTAL_FILES -gt 0 ]] && percent=$((BPE_PROCESSED * 100 / BPE_TOTAL_FILES))

    local eta="N/A"
    if [[ $BPE_PROCESSED -gt 0 ]] && [[ $elapsed -gt 0 ]]; then
        local remaining_files=$((BPE_TOTAL_FILES - BPE_PROCESSED))
        local per_file=$((elapsed / BPE_PROCESSED))
        local eta_secs=$((remaining_files * per_file))
        eta="${eta_secs}秒"
    fi

    # 進捗ファイル更新
    cat > "$BPE_PROGRESS_FILE" <<EOF
{
  "version": "${BPE_VERSION}",
  "total": ${BPE_TOTAL_FILES},
  "processed": ${BPE_PROCESSED},
  "failed": ${BPE_FAILED},
  "retried": ${BPE_RETRIED},
  "percent": ${percent},
  "elapsed_sec": ${elapsed},
  "eta": "${eta}",
  "batches_done": ${BPE_BATCHES_DONE},
  "batches_total": ${BPE_BATCHES_TOTAL}
}
EOF

    _bpe_log info "進捗: ${percent}% (${BPE_PROCESSED}/${BPE_TOTAL_FILES}) ETA: ${eta}"
    return 0
}

# =============================================================================
# _bpe_handle_errors - エラーハンドリング・リトライ
# =============================================================================
_bpe_handle_errors() {
    local processor_fn="${1:-echo}"

    if [[ ${#_BPE_FAILED_FILES[@]} -eq 0 ]]; then
        _bpe_log ok "リトライ対象なし"
        return 0
    fi

    _bpe_log info "エラーリトライ開始: ${#_BPE_FAILED_FILES[@]}ファイル"

    local retry_list=("${_BPE_FAILED_FILES[@]}")
    _BPE_FAILED_FILES=()
    local recovered=0

    for file in "${retry_list[@]}"; do
        local retries="${_BPE_RETRY_COUNT[$file]:-0}"

        if [[ $retries -ge $BPE_MAX_RETRIES ]]; then
            _bpe_log error "最大リトライ超過: ${file} (${retries}回)"
            _BPE_FAILED_FILES+=("$file")
            continue
        fi

        BPE_RETRIED=$((BPE_RETRIED + 1))
        _BPE_RETRY_COUNT["$file"]=$((retries + 1))

        if type -t "$processor_fn" &>/dev/null; then
            if $processor_fn "$file" 2>/dev/null; then
                recovered=$((recovered + 1))
                BPE_PROCESSED=$((BPE_PROCESSED + 1))
                BPE_FAILED=$((BPE_FAILED - 1))
            else
                _BPE_FAILED_FILES+=("$file")
            fi
        fi
    done

    _bpe_log ok "リトライ結果: ${recovered}回復, ${#_BPE_FAILED_FILES[@]}残り"
    BPE_GENERATED=$((BPE_GENERATED + 1))

    return 0
}

# =============================================================================
# _bpe_run_all - 全バッチを一括実行
# =============================================================================
_bpe_run_all() {
    local processor_fn="${1:-echo}"

    for ((b=0; b<BPE_BATCHES_TOTAL; b++)); do
        _bpe_process_batch "$b" "$processor_fn"
    done

    # リトライ
    if [[ ${#_BPE_FAILED_FILES[@]} -gt 0 ]]; then
        _bpe_handle_errors "$processor_fn"
    fi

    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_bpe_report() {
    local elapsed=$(( $(date +%s 2>/dev/null || echo 0) - BPE_START_TIME ))
    echo -e "\n  ${_BPE_BOLD}=== batch-processing-engine v${BPE_VERSION} ===${_BPE_NC}"
    echo -e "  総ファイル      : ${BPE_TOTAL_FILES}"
    echo -e "  処理済み        : ${BPE_PROCESSED}"
    echo -e "  失敗            : ${BPE_FAILED}"
    echo -e "  リトライ        : ${BPE_RETRIED}"
    echo -e "  バッチ完了      : ${BPE_BATCHES_DONE}/${BPE_BATCHES_TOTAL}"
    echo -e "  処理時間        : ${elapsed}秒"
    echo -e "  エラー          : ${BPE_ERRORS}"
}

_bpe_score() {
    local score=50
    [[ ${BPE_PROCESSED} -gt 0 ]] && score=$((score + 15))
    [[ ${BPE_BATCHES_DONE} -eq ${BPE_BATCHES_TOTAL} ]] && [[ ${BPE_BATCHES_TOTAL} -gt 0 ]] && score=$((score + 15))
    [[ ${BPE_FAILED} -eq 0 ]] && score=$((score + 10))
    [[ ${BPE_ERRORS} -eq 0 ]] && score=$((score + 10))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "batch-processing-engine" --version "${BPE_VERSION}" \
        --description "バッチファイル処理×進捗追跡×エラーリトライ (v425)" \
        --init "_bpe_init" --report "_bpe_report" --score "_bpe_score" \
        --enable-var "ENABLE_BATCH_PROCESSING" --cli-flags "--batch-processing:--no-batch-processing"
fi

# v2003.1: source時のexit codeを確実に0にする
true
