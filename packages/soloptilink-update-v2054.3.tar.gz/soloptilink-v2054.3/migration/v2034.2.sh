#!/bin/bash
# ============================================================
# SoloptiLinkAI Migration v2034.2 (idempotent)
# ============================================================
# 既存顧客が v2034.2 にアップデートしたあと、auto-update.sh が
# 初回起動時に一度だけ実行する移行スクリプト。
#
# 機能:
#   1. status.json の "failed" 状態をクリア (チェックサム不一致等で固着した顧客の救済)
#   2. heal-hooks.sh を呼んで重複フックを解消 (tilde + フルパス二重登録の事案)
#   3. .error-log が 1MB 超なら .error-log.archive-YYYYMMDD にローテーション
#
# 冪等性:
#   .migration-state.json の "applied" 配列に "v2034.2" が含まれていれば即 exit 0
#   2 回目以降の実行は一切副作用なし。
#
# 設計:
#   auto-update.sh:126-136 が ~/.soloptilink/migration/v*.sh を順次起動。
#   state ファイルに mig_name (= "v2034.2") を grep して既適用判定する。
# ============================================================

set -e

SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
STATE="$SL_DIR/.migration-state.json"
NAME="v2034.2"
LOG_PREFIX="[migration $NAME]"

# 既に適用済みなら即終了 (auto-update.sh 側でも grep するが二重防御)
mkdir -p "$(dirname "$STATE")"
if [ -f "$STATE" ] && grep -q "\"$NAME\"" "$STATE" 2>/dev/null; then
  exit 0
fi

echo "$LOG_PREFIX 開始 ($(date -u +%Y-%m-%dT%H:%M:%SZ))"

# ============================================================
# 1. status.json の failed 状態をクリア
# ============================================================
STATUS_FILE="$SL_DIR/.auto-update-status.json"
if [ -f "$STATUS_FILE" ]; then
  CURRENT_STATUS=""
  if command -v python3 >/dev/null 2>&1; then
    CURRENT_STATUS=$(python3 -c "
import json
try:
  d=json.load(open('$STATUS_FILE'))
  print(d.get('status',''))
except Exception:
  pass
" 2>/dev/null)
  fi

  if [ "$CURRENT_STATUS" = "failed" ] || [ "$CURRENT_STATUS" = "error" ]; then
    # バックアップ取得後、status を "pending_recheck" に書き換え
    TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    BAK="${STATUS_FILE}.bak.v2034.2.$(date +%Y%m%d_%H%M%S)"
    cp -p "$STATUS_FILE" "$BAK" 2>/dev/null || true

    if command -v python3 >/dev/null 2>&1; then
      python3 -c "
import json
try:
  d=json.load(open('$STATUS_FILE'))
except Exception:
  d={}
d['status']='pending_recheck'
d['message']='v2034.2 migration がクリア (旧 failed 状態)'
d['timestamp']='$TS'
d['migration_cleared_from']='failed'
json.dump(d, open('$STATUS_FILE','w'), ensure_ascii=False, indent=2)
" 2>/dev/null && echo "$LOG_PREFIX status.json: failed → pending_recheck (backup: $BAK)"
    else
      # python3 がない場合は強制的に最小限の JSON で上書き (退避済み)
      cat > "$STATUS_FILE" <<EOF
{"status":"pending_recheck","message":"v2034.2 migration cleared old failed state","timestamp":"$TS","migration_cleared_from":"failed"}
EOF
      echo "$LOG_PREFIX status.json: 最小JSONで上書き (backup: $BAK)"
    fi
  else
    echo "$LOG_PREFIX status.json: ${CURRENT_STATUS:-未設定} (クリア不要)"
  fi
else
  echo "$LOG_PREFIX status.json なし — スキップ"
fi

# ============================================================
# 2. heal-hooks.sh を呼ぶ (重複フック解消)
# ============================================================
HEAL_SCRIPT="$SL_DIR/scripts/heal-hooks.sh"
if [ -f "$HEAL_SCRIPT" ]; then
  if bash "$HEAL_SCRIPT" >/dev/null 2>&1; then
    echo "$LOG_PREFIX heal-hooks.sh 実行成功"
  else
    echo "$LOG_PREFIX heal-hooks.sh 実行で警告 (致命ではない)"
  fi
else
  echo "$LOG_PREFIX heal-hooks.sh が見つかりません — スキップ ($HEAL_SCRIPT)"
fi

# ============================================================
# 3. .error-log が 1MB 超ならローテーション
# ============================================================
ERROR_LOG="$SL_DIR/.error-log"
if [ -f "$ERROR_LOG" ]; then
  # macOS BSD stat と GNU stat 双方対応
  LOG_SIZE=$(stat -f%z "$ERROR_LOG" 2>/dev/null || stat -c%s "$ERROR_LOG" 2>/dev/null || echo 0)
  case "$LOG_SIZE" in
    ''|*[!0-9]*) LOG_SIZE=0 ;;
  esac
  if [ "$LOG_SIZE" -gt 1048576 ]; then
    ARCHIVE="${ERROR_LOG}.archive-$(date +%Y%m%d)"
    if mv "$ERROR_LOG" "$ARCHIVE" 2>/dev/null; then
      : > "$ERROR_LOG"  # 空ファイルで再作成
      echo "$LOG_PREFIX error-log ローテーション: $LOG_SIZE bytes → $ARCHIVE"
    else
      echo "$LOG_PREFIX error-log ローテーション失敗 (致命ではない)"
    fi
  else
    echo "$LOG_PREFIX error-log: $LOG_SIZE bytes (ローテーション不要)"
  fi
else
  echo "$LOG_PREFIX error-log なし — スキップ"
fi

# ============================================================
# 4. state ファイルに適用済みマークを記録 (idempotent 保証)
# ============================================================
if [ -f "$STATE" ]; then
  if command -v python3 >/dev/null 2>&1; then
    python3 -c "
import json, os
try:
  with open('$STATE') as f:
    d = json.load(f) if os.path.getsize('$STATE') > 0 else {}
except Exception:
  d = {}
applied = d.setdefault('applied', [])
if '$NAME' not in applied:
  applied.append('$NAME')
with open('$STATE','w') as f:
  json.dump(d, f, ensure_ascii=False, indent=2)
" 2>/dev/null || echo '{"applied":["'$NAME'"]}' > "$STATE"
  else
    # python3 がない場合: 既存内容を尊重しつつ簡易追記
    if ! grep -q "\"$NAME\"" "$STATE" 2>/dev/null; then
      echo '{"applied":["'$NAME'"]}' > "$STATE"
    fi
  fi
else
  echo '{"applied":["'$NAME'"]}' > "$STATE"
fi

echo "$LOG_PREFIX 完了 ($(date -u +%Y-%m-%dT%H:%M:%SZ))"
exit 0
