#!/usr/bin/env bash
# ============================================================
# v2031.0 ARTE-Omega 配線 migration
# ------------------------------------------------------------
# 既存顧客 (35社) の端末に v2025-v2030 ARTE-Omega を遡及配線する。
#
# 配線内容:
#   1. lib/security/arte/v2025-v2030/ 配置確認
#   2. lib/soloptilink-omega-hook.sh 配置確認
#   3. lib/quality-fortresses/{21st-30th}fortress.sh 配置確認
#   4. settings.json の Stop hook に omega-hook 自動起動を追加
#   5. CLAUDE.md にセキュリティ自動稼働セクション追記
#
# 冪等: 既に配線済みなら何もしない
# バックアップ: ~/.claude/.backups/
# 状態: ~/.soloptilink/.migration-state.json
# ============================================================
set -u

MIG_NAME="v2031_omega_install"
SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
CLAUDE_DIR="$HOME/.claude"
SETTINGS_FILE="$CLAUDE_DIR/settings.json"
BACKUP_DIR="$CLAUDE_DIR/.backups"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"

mkdir -p "$SL_DIR" "$CLAUDE_DIR" "$BACKUP_DIR" 2>/dev/null || true

mig_log() {
  echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}
mig_log "START"

# 冪等性チェック (M-4修正: sidecar .names も参照し python3 不在環境でも二重適用しない)
NAMES_MARK="$STATE_FILE.names"
if { [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; } || grep -qxF "$MIG_NAME" "$NAMES_MARK" 2>/dev/null; then
  mig_log "ALREADY_APPLIED -> NOOP"
  echo "[migration] v2031 omega install already applied"
  exit 0
fi

# 1. v2025-v2030 ディレクトリ存在確認
MISSING=()
for V in v2025 v2026 v2027 v2028 v2029 v2030; do
  if [ ! -d "$SL_DIR/lib/security/arte/$V" ]; then
    MISSING+=("lib/security/arte/$V")
  fi
done
if [ ${#MISSING[@]} -gt 0 ]; then
  mig_log "WARN: missing dirs: ${MISSING[*]}"
  echo "[migration] WARN: v2025-v2030 一部欠如: ${MISSING[*]}"
  echo "[migration] tar.gz 再配信で同梱されるまで omega-hook は no-op で動作します"
fi

# 2. omega-hook 配置確認
if [ ! -x "$SL_DIR/lib/soloptilink-omega-hook.sh" ]; then
  mig_log "WARN: omega-hook missing"
  echo "[migration] WARN: omega-hook.sh 不在 (tar.gz 再配信待ち)"
fi

# 3. Fortress 21st-30th 配置確認
FORTRESS_COUNT=0
for F in unvigintifortress duovigintifortress tervigintifortress quattuorvigintifortress \
         quinvigintifortress sexvigintifortress septuvigintifortress octovigintifortress \
         novemvigintifortress trigintafortress; do
  [ -f "$SL_DIR/lib/quality-fortresses/$F.sh" ] && FORTRESS_COUNT=$((FORTRESS_COUNT+1))
done
mig_log "Fortress 21st-30th 配置: $FORTRESS_COUNT/10"
echo "[migration] Fortress 21st-30th 配置: $FORTRESS_COUNT/10"

# 4. settings.json の Stop hook に omega-hook 自動起動を追加
if [ -f "$SETTINGS_FILE" ]; then
  # バックアップ
  cp "$SETTINGS_FILE" "$BACKUP_DIR/settings.json.${MIG_NAME}.$(date +%Y%m%d_%H%M%S).bak" 2>/dev/null
  # 既に omega-hook が登録済みかチェック
  if grep -q "soloptilink-omega-hook" "$SETTINGS_FILE" 2>/dev/null; then
    mig_log "settings.json: omega-hook 既登録"
    echo "[migration] settings.json: omega-hook 既に登録済み"
  elif ! command -v python3 >/dev/null 2>&1; then
    # python3 不在 (標準的な Windows + Git Bash)。settings.json の JSON 編集は
    # sed では安全にできないため配線をスキップするが、必ず告知を残す (静音スキップ禁止)。
    # 自動更新フック自体はランチャーバイナリの register-autoupdate-hook が担うため
    # 更新経路は失われない。omega-hook は python3 導入後の更新で自動配線される。
    mig_log "python3 不在のため omega-hook 配線をスキップ (次回 python3 導入後の更新で自動配線)"
    echo "[migration] ⚠ python3 が見つからないため omega-hook の配線を保留しました"
  else
    # python3 で安全に append
    python3 - "$SETTINGS_FILE" <<'PY'
import json, sys, os
p = sys.argv[1]
try:
    with open(p) as f:
        d = json.load(f)
except Exception as e:
    print(f"settings.json parse failed: {e}", file=sys.stderr)
    sys.exit(1)
hooks = d.setdefault("hooks", {})
stop_hooks = hooks.setdefault("Stop", [])
# 配線対象: Stop hook で omega-hook --quick を呼ぶ (cwd を自動判定)
omega_entry = {
    "matcher": "*",
    "hooks": [{
        "type": "command",
        "command": "bash $HOME/.soloptilink/lib/soloptilink-omega-hook.sh check \"$(pwd)\" --quick 2>/dev/null | tail -5 || true"
    }]
}
# 既存と重複しないか
already = False
for h in stop_hooks:
    cmd = ""
    if isinstance(h, dict):
        for inner in h.get("hooks", []):
            if isinstance(inner, dict) and "omega-hook" in inner.get("command", ""):
                already = True; break
    if already: break
if not already:
    stop_hooks.append(omega_entry)
    with open(p, "w") as f:
        json.dump(d, f, indent=2, ensure_ascii=False)
    print("settings.json: Stop hook に omega-hook 追加完了")
else:
    print("settings.json: 既に配線済み")
PY
    mig_log "settings.json hook 配線完了"
  fi
else
  mig_log "settings.json 不在 (新規作成スキップ)"
fi

# 5. 状態記録 (M-4修正: sidecar .names を記録の正とし既存 state を壊さない)
TS=$(date +%Y-%m-%dT%H:%M:%S%z)
printf '%s\n' "$MIG_NAME" >> "$NAMES_MARK" 2>/dev/null || true
if [ -f "$STATE_FILE" ] && command -v python3 >/dev/null 2>&1; then
  python3 - "$STATE_FILE" "$MIG_NAME" "$TS" <<'PY' 2>/dev/null || true
import json, sys
p, name, ts = sys.argv[1:4]
try:
    with open(p) as f: d = json.load(f)
except: d = {"applied": []}
d.setdefault("applied", []).append({"name": name, "ts": ts})
with open(p, "w") as f:
    json.dump(d, f, indent=2, ensure_ascii=False)
PY
elif [ ! -f "$STATE_FILE" ]; then
  printf '{"applied":[{"name":"%s","ts":"%s"}]}\n' "$MIG_NAME" "$TS" > "$STATE_FILE"
fi
mig_log "DONE"
echo "[migration] v2031 omega install complete"
exit 0
