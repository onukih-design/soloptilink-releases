#!/usr/bin/env bash
# ============================================================
# v2038.x PFP-102 boost quality hooks install migration (2026-06-11)
# ------------------------------------------------------------
# 構造欠陥の遡及修正: v2038.2 まで、完成ゲート (Stop) と boost 武装フック
# (UserPromptSubmit) を顧客の ~/.claude/settings.json に配線するコードが
# どこにも存在しなかった。その結果、Desktop の品質ゲート群
# (PFP-086 Runtime Login / PFP-093 105ロール証跡 / PFP-098 深さ /
#  PFP-100 CRUD入力 / PFP-UI) が顧客環境では常時未配線=無効だった。
#
# 本 migration は次の3フックを冪等に配線する (実体ファイルが存在する場合のみ):
#   1. UserPromptSubmit: boost-session-arm-hook.sh   (完成ゲートの武装)
#   2. Stop:             boost-completion-gate-hook.sh (完成宣言の品質ブロック)
#   3. Stop:             skill-sot-guard.sh heal       (スキル4拠点ドリフト自動修復 / PFP-064)
#
# - 冪等: コマンド断片が既に配線済みなら何もしない
# - 必ずバックアップを取る (~/.claude/.backups/)
# - 状態は ~/.soloptilink/.migration-state.json に追記
# - 万一 python3 が無い環境では何もせず正常終了 (state は記録しない=再試行可能)
# 手動実行: bash ~/.soloptilink/migration/v2038_pfp102_boost_hooks.sh
# ============================================================
set -u

MIG_NAME="v2038_pfp102_boost_hooks"
SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
CLAUDE_DIR="$HOME/.claude"
SETTINGS_FILE="$CLAUDE_DIR/settings.json"
BACKUP_DIR="$CLAUDE_DIR/.backups"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"

mkdir -p "$SL_DIR" "$CLAUDE_DIR" "$BACKUP_DIR" 2>/dev/null || true

mig_log() {
    echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}

mig_log "START"

# 冪等性: 適用済みなら NOOP
if [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; then
    mig_log "ALREADY_APPLIED -> NOOP"
    exit 0
fi

# python3 必須 (無ければ再試行可能なまま終了)
if ! command -v python3 >/dev/null 2>&1; then
    mig_log "PRECONDITION_FAILED python3 not found (retryable)"
    exit 0
fi

# バックアップ
TS="$(date +%Y%m%dT%H%M%S)"
if [ -f "$SETTINGS_FILE" ]; then
    cp -p "$SETTINGS_FILE" "$BACKUP_DIR/settings.json.pre-${MIG_NAME}-${TS}" 2>/dev/null || true
fi

# 配線 (実体が存在するフックのみ / コマンド断片一致で重複防止)
WIRE_RESULT=$(SETTINGS_FILE="$SETTINGS_FILE" python3 - <<'PYEOF'
import json, os, sys
sp = os.environ["SETTINGS_FILE"]
try:
    with open(sp) as f:
        d = json.load(f)
except Exception:
    d = {}
if not isinstance(d, dict):
    print("ABORT_NOT_DICT"); sys.exit(0)
hooks = d.setdefault("hooks", {})
def has(ev, frag):
    for m in hooks.get(ev, []):
        for h in (m.get("hooks") or []):
            if frag in (h.get("command") or ""):
                return True
    return False
home = os.path.expanduser("~")
wirings = [
    ("UserPromptSubmit", "boost-session-arm-hook.sh",
     "bash ~/.soloptilink/lib/hooks/boost-session-arm-hook.sh",
     home + "/.soloptilink/lib/hooks/boost-session-arm-hook.sh"),
    ("Stop", "boost-completion-gate-hook.sh",
     'bash "$HOME/.soloptilink/lib/hooks/boost-completion-gate-hook.sh"',
     home + "/.soloptilink/lib/hooks/boost-completion-gate-hook.sh"),
    ("Stop", "skill-sot-guard.sh",
     "bash ~/.soloptilink/scripts/structural-defenses/skill-sot-guard.sh heal --silent 2>/dev/null || true",
     home + "/.soloptilink/scripts/structural-defenses/skill-sot-guard.sh"),
]
added = []
for ev, frag, cmd, target in wirings:
    if not os.path.exists(target):
        continue
    if not has(ev, frag):
        hooks.setdefault(ev, []).append({"hooks": [{"type": "command", "command": cmd}]})
        added.append(f"{ev}:{frag}")
if added:
    tmp = sp + ".tmp-pfp102"
    with open(tmp, "w") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(tmp, sp)
print("WIRED:" + ",".join(added) if added else "NOOP_ALREADY_WIRED")
PYEOF
) || { mig_log "WIRE_FAILED (retryable)"; exit 0; }

mig_log "RESULT $WIRE_RESULT"

# state 記録 (配線成功 or 既配線の場合のみ)
case "$WIRE_RESULT" in
    WIRED:*|NOOP_ALREADY_WIRED)
        if [ -f "$STATE_FILE" ]; then
            STATE_FILE="$STATE_FILE" MIG_NAME="$MIG_NAME" python3 -c "
import json, os
p = os.environ['STATE_FILE']
try:
    with open(p) as f:
        d = json.load(f)
except Exception:
    d = {}
d.setdefault('applied', []).append(os.environ['MIG_NAME'])
with open(p, 'w') as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
" 2>/dev/null || echo "{\"applied\":[\"$MIG_NAME\"]}" > "$STATE_FILE"
        else
            echo "{\"applied\":[\"$MIG_NAME\"]}" > "$STATE_FILE"
        fi
        mig_log "APPLIED"
        ;;
    *)
        mig_log "NOT_RECORDED ($WIRE_RESULT) — 次回再試行"
        ;;
esac

exit 0
