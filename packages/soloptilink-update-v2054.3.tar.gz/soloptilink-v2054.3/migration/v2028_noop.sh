#!/bin/bash
# Idempotent NOOP migration — v2028
# このバージョンには構造変更がないため、適用済みマークのみ残す。
# 顧客の auto-update.sh が一度実行すれば .migration-state.json に記録され、二度と走らない。
set -e
SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
STATE="$SL_DIR/.migration-state.json"
NAME="v2028_noop"
mkdir -p "$(dirname "$STATE")"
# 適用マークは append-only の sidecar (.names) を「記録の正」とする (M-4修正 2026-07-14)。
# python3 の有無・JSON 形式に依存せず、既存 state を絶対に壊さない (Windows+Git Bash でも
# 「一度実行すれば二度と走らない」不変条件が成立)。JSON state は python3 がある時だけ best-effort 追記。
NAMES_MARK="$STATE.names"
if { [ -f "$STATE" ] && grep -q "\"$NAME\"" "$STATE" 2>/dev/null; } || grep -qxF "$NAME" "$NAMES_MARK" 2>/dev/null; then
  exit 0
fi
printf '%s\n' "$NAME" >> "$NAMES_MARK" 2>/dev/null || true
if [ -f "$STATE" ] && command -v python3 >/dev/null 2>&1; then
  python3 -c "
import json,os,sys
with open('$STATE') as f:
    d=json.load(f) if os.path.getsize('$STATE')>0 else {}
d.setdefault('applied',[]).append('$NAME')
with open('$STATE','w') as f:
    json.dump(d,f,ensure_ascii=False,indent=2)
" 2>/dev/null || true
elif [ ! -f "$STATE" ]; then
  echo '{"applied":["'$NAME'"]}' > "$STATE"
fi
echo "[migration] $NAME applied (noop)"
