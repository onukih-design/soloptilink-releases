#!/usr/bin/env bash
# ============================================================
# v2027.0 hook install migration
# ------------------------------------------------------------
# 既存顧客 (~/.soloptilink/ がインストール済みだが ~/.claude/settings.json
# には auto-update.sh の hook が配線されていない端末) を遡及的に
# 自動更新可能な状態へ移行する。
#
# - 冪等: 既に配線済みなら何もしない (NOOP で正常終了)
# - 必ずバックアップを取る (~/.claude/.backups/)
# - 状態は ~/.soloptilink/.migration-state.json に追記
# - ログは ~/.soloptilink/.migration.log に追記
# - jq → python3 → 安全 abort の優先順
#
# 単独実行可: setup.sh が無くても動作する。
# auto-update.sh が冒頭でこのスクリプトを冪等に呼び出すのが正規ルート。
# 手動実行: bash ~/.soloptilink/migration/v2027_hook_install.sh
# ============================================================
set -u

MIG_NAME="v2027_hook_install"
SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
CLAUDE_DIR="$HOME/.claude"
SETTINGS_FILE="$CLAUDE_DIR/settings.json"
BACKUP_DIR="$CLAUDE_DIR/.backups"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"

# ------------------------------------------------------------
# HOOK_CMD を OS で出し分ける (2026-06-15 野村Windows事案 恒久対策)
# ------------------------------------------------------------
# 従来は全 OS で `bash auto-update.sh` を登録していたが、Windows は bash を
# 標準搭載しないためフックが起動できなかった。
#   - Windows (Git Bash/MSYS/Cygwin から実行): ランチャー(.exe)経由に切替。
#     Claude Code がフックを cmd/PowerShell で実行しても bash リテラルに依存しない。
#     ランチャーは内部で Git Bash 等を探索し、無ければ Go ネイティブ更新を行う。
#   - Unix (Mac/Linux): 従来どおり `bash auto-update.sh` (既存顧客の冪等性を維持・
#     HOOK_CMD 文字列が変わらないので二重登録が起きない)。
case "$(uname -s 2>/dev/null)" in
    MINGW*|MSYS*|CYGWIN*|Windows_NT)
        HOOK_CMD="\"$HOME/.soloptilink/soloptilink.exe\" --hook-autoupdate"
        ;;
    *)
        HOOK_CMD="bash $HOME/.soloptilink/auto-update.sh"
        ;;
esac

# Windows はフック登録を Go ランチャーに一任する (2026-06-16 二重登録解消)。
# 本スクリプトの jq/python マージは command 文字列の厳密一致で冪等判定するため、
# .ps1 インストーラが Go で登録した表記 (C:/...) と本スクリプトの $HOME 展開表記 (/c/...) が
# 食い違うと二重登録される。Go の登録は意味一致 de-dup を持つので、Windows ではランチャーへ委譲する。
case "$(uname -s 2>/dev/null)" in
    MINGW*|MSYS*|CYGWIN*|Windows_NT)
        if [ -x "$HOME/.soloptilink/soloptilink.exe" ]; then
            "$HOME/.soloptilink/soloptilink.exe" --register-autoupdate-hook >/dev/null 2>&1 || true
            mig_log "DELEGATED_TO_LAUNCHER (windows)"
            exit 0
        fi
        ;;
esac

mkdir -p "$SL_DIR" "$CLAUDE_DIR" "$BACKUP_DIR" 2>/dev/null || true

mig_log() {
    echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}

mig_log "START"

# ------------------------------------------------------------
# 既に適用済みかチェック (冪等性)
# ------------------------------------------------------------
if [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; then
    mig_log "ALREADY_APPLIED (state=$STATE_FILE) -> NOOP"
    exit 0
fi

# ------------------------------------------------------------
# auto-update.sh の存在確認 (前提)
# ------------------------------------------------------------
# v2054.0: $HOME/.soloptilink 直書きを $SL_DIR に是正 (SOLOPTILINK_DIR 上書き環境=
# sandbox 検証・recover.sh selftest で precondition が誤 FAIL する潜在バグの修正。
# 実顧客環境では SL_DIR == $HOME/.soloptilink のため挙動不変)
if [ ! -f "$SL_DIR/auto-update.sh" ]; then
    mig_log "PRECONDITION_FAILED auto-update.sh not found"
    exit 0  # 致命的エラーにはしない (再試行可能なので)
fi

# ------------------------------------------------------------
# settings.json の準備とバックアップ
# ------------------------------------------------------------
TS="$(date +%Y%m%dT%H%M%S)"

if [ -f "$SETTINGS_FILE" ]; then
    cp -p "$SETTINGS_FILE" "$BACKUP_DIR/settings.json.pre-${MIG_NAME}-${TS}" 2>/dev/null || true
    mig_log "BACKUP $BACKUP_DIR/settings.json.pre-${MIG_NAME}-${TS}"
else
    echo '{}' > "$SETTINGS_FILE"
    mig_log "CREATED empty settings.json"
fi

# ------------------------------------------------------------
# jq があれば jq で merge
# ------------------------------------------------------------
merge_with_jq() {
    local tmp="${SETTINGS_FILE}.tmp.$$"
    if jq --arg cmd "$HOOK_CMD" '
        .hooks //= {} |
        .hooks.UserPromptSubmit //= [] |
        (.hooks.UserPromptSubmit
         | map(.hooks // [] | map(.command))
         | flatten
         | index($cmd)) as $exists_ups |
        (if $exists_ups == null then
            .hooks.UserPromptSubmit += [{
                "matcher": "*",
                "hooks": [{"type": "command", "command": $cmd, "timeout": 30}]
            }]
        else . end) |
        .hooks.SessionStart //= [] |
        (.hooks.SessionStart
         | map(.hooks // [] | map(.command))
         | flatten
         | index($cmd)) as $exists_ss |
        (if $exists_ss == null then
            .hooks.SessionStart += [{
                "matcher": "*",
                "hooks": [{"type": "command", "command": $cmd, "timeout": 30}]
            }]
        else . end)
    ' "$SETTINGS_FILE" > "$tmp" 2>>"$LOG_FILE"; then
        mv "$tmp" "$SETTINGS_FILE"
        return 0
    else
        rm -f "$tmp" 2>/dev/null || true
        return 1
    fi
}

# ------------------------------------------------------------
# python3 fallback
# ------------------------------------------------------------
merge_with_python() {
    local tmp="${SETTINGS_FILE}.tmp.$$"
    if SETTINGS_FILE="$SETTINGS_FILE" HOOK_CMD="$HOOK_CMD" TMP_FILE="$tmp" python3 - <<'PYEOF' 2>>"$LOG_FILE"
import json, os, sys
sf = os.environ['SETTINGS_FILE']
hc = os.environ['HOOK_CMD']
tmp = os.environ['TMP_FILE']
try:
    with open(sf, 'r') as f:
        data = json.load(f)
except Exception:
    data = {}
if not isinstance(data, dict):
    data = {}
hooks = data.setdefault('hooks', {})
for evt in ('UserPromptSubmit', 'SessionStart'):
    arr = hooks.setdefault(evt, [])
    if not isinstance(arr, list):
        arr = []
        hooks[evt] = arr
    found = False
    for entry in arr:
        if not isinstance(entry, dict):
            continue
        for h in entry.get('hooks', []) or []:
            if isinstance(h, dict) and h.get('command') == hc:
                found = True
                break
        if found:
            break
    if not found:
        arr.append({
            'matcher': '*',
            'hooks': [{'type': 'command', 'command': hc, 'timeout': 30}]
        })
with open(tmp, 'w') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
PYEOF
    then
        mv "$tmp" "$SETTINGS_FILE"
        return 0
    else
        rm -f "$tmp" 2>/dev/null || true
        return 1
    fi
}

MERGED=false
if command -v jq >/dev/null 2>&1; then
    if merge_with_jq; then
        MERGED=true
        mig_log "JQ_MERGE_SUCCESS"
    else
        mig_log "JQ_MERGE_FAILED -> trying python3"
    fi
fi

if [ "$MERGED" = false ] && command -v python3 >/dev/null 2>&1; then
    if merge_with_python; then
        MERGED=true
        mig_log "PYTHON_MERGE_SUCCESS"
    else
        mig_log "PYTHON_MERGE_FAILED"
    fi
fi

if [ "$MERGED" = false ]; then
    mig_log "ABORTED neither jq nor python3 worked"
    exit 1
fi

# ------------------------------------------------------------
# state 書き込み (atomic)
# ------------------------------------------------------------
APPLIED_AT="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
STATE_TMP="${STATE_FILE}.tmp.$$"

if command -v jq >/dev/null 2>&1; then
    if [ -f "$STATE_FILE" ]; then
        if jq --arg name "$MIG_NAME" --arg at "$APPLIED_AT" '
            . + {($name): {"applied_at": $at}}
        ' "$STATE_FILE" > "$STATE_TMP" 2>>"$LOG_FILE"; then
            mv "$STATE_TMP" "$STATE_FILE"
        else
            rm -f "$STATE_TMP" 2>/dev/null || true
        fi
    else
        printf '{"%s": {"applied_at": "%s"}}\n' "$MIG_NAME" "$APPLIED_AT" > "$STATE_FILE"
    fi
elif command -v python3 >/dev/null 2>&1; then
    STATE_FILE="$STATE_FILE" MIG_NAME="$MIG_NAME" APPLIED_AT="$APPLIED_AT" STATE_TMP="$STATE_TMP" python3 - <<'PYEOF' 2>>"$LOG_FILE"
import json, os
sf = os.environ['STATE_FILE']
mn = os.environ['MIG_NAME']
at = os.environ['APPLIED_AT']
tmp = os.environ['STATE_TMP']
try:
    with open(sf, 'r') as f:
        data = json.load(f)
except Exception:
    data = {}
if not isinstance(data, dict):
    data = {}
data[mn] = {"applied_at": at}
with open(tmp, 'w') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
os.rename(tmp, sf)
PYEOF
else
    # 最終フォールバック: 単純に上書き (state ファイルが既に存在する場合は壊れる可能性あり)
    if [ ! -f "$STATE_FILE" ]; then
        printf '{"%s": {"applied_at": "%s"}}\n' "$MIG_NAME" "$APPLIED_AT" > "$STATE_FILE"
    fi
fi

mig_log "DONE applied_at=${APPLIED_AT}"
exit 0
