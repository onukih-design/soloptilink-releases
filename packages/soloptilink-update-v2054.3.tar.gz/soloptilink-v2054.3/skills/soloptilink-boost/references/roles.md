# Centuria フェーズ波 Role 1-5 詳細仕様 (コア Step 2.A の要約の出典)

> コア SKILL.md には各ロール 5 行以内の要約のみを保持する。各波の成果物仕様の正本は本ファイル。

## Role 1: Architect (アーキテクト)
- 入力: 事業推論結果 + DBL 検出結果 (+ enterprise-blueprint.json があれば統合青写真)
- 出力: データモデル設計 (Prisma schema — DBL `models` 全展開・enum 完備) / ページ構造 (App Router 階層 — DBL `pages` 全展開・L0/L1/L2/L3 層別) / API 設計 (DBL `apis` 全展開・HTTP method 完備) / エンタープライズパターン選定 (トランザクション境界 / サービス層 / 監査ログ)
- 必須: **DBL 登録の全 model / page / api を拾い切る**。「30 ページ + 25 API + 15 model」の汎用最低ラインで止まらず、DBL 記載分は全部設計に含める

## Role 2: Implementer (実装者)
- 入力: Architect の設計
- 出力: Prisma schema.prisma 完全生成 (relations / indexes 完備) / seed.ts に**業界マスタ (L2) の seed_data 全件投入** (加算マスタ20種 / 報酬単価マスタ / 資格マスタ 等) / 各ページ tsx (Server/Client 切り分け・RSC 制約遵守) / 各 API route (Zod validation / 認証 / トランザクション / AuditLog) / **業界ロジック (L3) の lib/services 配置**: DBL `business_logic` を 1 関数ずつ実装
- 必須: **DBL `business_logic[]` を「名前だけのファイル」でなく実コード化** (例: `calculateMonthlyReward` = 単位数×日数×加算×地域区分の実計算 / `checkKasanEligibility` = 加算20種全件の要件チェック / `monitoringReminderCron` = cron 6ヶ月ルール自動評価)
- 必須 (深さ L4-L6 / PFP-098):
  - **L4 データ充足**: seed.ts は業務マスタに加え、全業務テーブルへ**一覧で意味が伝わる量のトランザクション/エンティティ実データ** (各10〜50件・FK整合・業界文脈に沿った命名) を投入。
  - **L5 ドリルダウン**: 一覧を持つ**全業務モデルに `app/<module>/[id]/page.tsx` 詳細ページを実装**し、一覧主要列を `<Link href={`/<module>/${row.id}`}>` か onRowClick→router.push で詳細へ結線。「一覧だけ・企業名が素の <p>」は禁止。詳細ページは編集/関連表示まで備える。
  - **L6 業務貫通**: 詳細ページから関連モジュール (顧客→商談→請求 等) へ相互 `<Link>` + ダッシュボードに**全業務モデルの実集計** (件数/金額/推移)。孤児ページを作らない。
- 必須 (入力できる / CRUD — PFP-100):
  - **作成フォーム (全業務モデル必須)**: 一覧を持つ全業務モデルに `app/<module>/new/page.tsx` を実装し、編集可能な全フィールドの入力UI (`<Input>`/`<Select>`/`<Textarea>` + react-hook-form + zod)。一覧右上に「新規作成」ボタン + `<Link href="/<module>/new">` 結線。**「新規ボタンはあるがフォーム実体が無い/押しても保存されない」は禁止。**閲覧専用テーブルを残さない。
  - **書込パス (実DB永続化)**: フォーム送信先に server action (`'use server'`) もしくは API route (`route.ts` の POST/PUT) を実装し `prisma.<model>.create` / `.update` で**実DBに保存**。zod 二重バリデーション (HTML required ↔ schema)。送信成功で一覧反映 + トースト + リダイレクト。空 onSubmit・保存されないダミーフォームは禁止。
  - **編集・削除**: 詳細ページに「編集」(`app/<module>/[id]/edit/page.tsx` → `prisma.<model>.update`) と「削除」(delete action + 確認ダイアログ)。作成→編集→削除のライフサイクルを完結。
  - **明細行を持つ伝票** (請求書/見積/受注 等): 明細の動的追加/削除行UI + 各行 required + 合計自動計算 + 親子トランザクション保存 (FCPG PFP-074 と整合)。

## Role 3: Tester (テスター)
- 入力: Implementer の出力
- 出力: スモークテスト (curl 各 endpoint POST/GET/PUT/DELETE + 期待 status code) / 業界ロジック単体テスト (例: calculateMonthlyReward の 3 ケース minimum) / PFP-061/071/074/079 の自動チェック実行
- 必須: **`npm run build` / `npm run typecheck` / `prisma validate` 全て exit 0 まで反復**

## Role 4: Reviewer (レビュアー)
- 入力: Tester の結果 + Implementer の全ソース
- 観点: **Layered Depth Gate (PFP-080) 手動評価** (L0/L1/L2/L3 を keyword 含有数で確認) / **Deep System Gate (PFP-098) 実走**: `bash ~/.soloptilink/lib/first-boot-perfect/deep-system-gate.sh run "$PROJECT_DIR"` で L4/L5/L6 判定、`deep-system-refiner.json` の needs_detail_page / needs_clickable_list / needs_dashboard_aggregation / needs_cross_links を Refiner にフィード / 業界用語含有率 (DBL keywords[] 全件 grep で 100語+) / 業界規制対応 (regulations[] 全件が監査ログ/同意取得/アクセス制限で実装) / エンタープライズパターン (トランザクション境界/サービス層/Zod/エラーバウンダリ)
- 出力: 不足項目を箇条書きで列挙 (Refiner にフィード)

## Role 5: Refiner (修正者)
- 入力: Reviewer の不足項目リスト (+ `deep-system-refiner.json` / `crud-input-capability-refiner.json` 等の各ゲート refiner)
- 動作: 不足箇所を全て埋める (新規ファイル作成 OR 既存拡張) / L2 未達→業界マスタモデル+seed 追加 / L3 未達→business_logic 実コード化 / **L4 未達→seed に業務実データ追加投入** (空テーブルを残さない) / **L5 未達→詳細ページ `[id]/page.tsx` 作成 + 一覧主要列を詳細へ結線** (needs_detail_page / needs_clickable_list 全消化) / **L6 未達→関連モジュール相互リンク + ダッシュボード集計 + 孤児ページのナビ結線** / 業界用語含有率 100 未満→追加ページ・コメント・description で補強
- ループ条件: Reviewer「不足項目 0件」かつ Deep System Gate `achieved ≥ DEEP_SYSTEM_MIN_LAYER` まで最大 3 巡

## 完了時の報告フォーマット (PFP-093 / 実数のみ・証跡裏付き)
`🤖 実起動エージェント: 105体が実際に成果物を生成 (証跡: agent-evidence/ に105ファイル) / 実行基盤: Claude Code Task並列 / 全105ロール完走`

- **Auto Mode**: ①〜③ を自動で進め、各波終了時に1行報告 (「✅ 設計波: 実12体を並列起動 → 累計12/105」)。最終 `verify` PASS で完成宣言。
- **Auto Mode 以外**: 各波着手前に1文予告 + 終了時に1行報告。
