# トラブルシューティング詳細 (PFP-049 系誤診根絶 — コア Step 1.3 の全詳細)

> コア SKILL.md は「Boost退避前の必須3点実測」の要点のみ保持。失敗パターン分類・フォールバック判断・各エラーの対処の正本は本ファイル。

## Boost退避前の必須3点実測 (PFP-049 厳格化)

**「動かない」判断前に必ず実測。** 表面読みでの Boost退避禁止 (PFP-048/049/051/052)。

**【推奨】PFP-075 統合ヘルパー**:
```bash
bash ~/.soloptilink/scripts/structural-defenses/pfp-075-diagnose-hardgate.sh
# 出力: VERDICT = BOOST_OK / BOOST_FORBIDDEN_RUN_VIA_LAUNCHER / UNAUTHORIZED / TRUE_FAILURE
# 非一過的証拠ファイル: ~/.soloptilink/.session-diagnostics/last-diagnosis.json (--json で JSON 出力)
```

**【マニュアル】個別3点実測 (ヘルパー不可時)**:
```bash
ls -la ~/.soloptilink/lib/license-guard.sh        # 1) 実在確認 (不在エラー誤診の99%はここで覆る)
ls -la ~/.soloptilink/soloptilink                  # 2) Goランチャー実在確認
~/.soloptilink/soloptilink --status 2>&1 | grep "::SOLOPTILINK_DIAG::"   # 3) hardgate マーカー確認
```
1つでも肯定なら Boost退避禁止 → 失敗パターン分類へ。

**【PFP-076】**: 他セッションの故障報告を信じず自セッションで PFP-075 実測。最新結果: `~/.soloptilink/.session-diagnostics/last-diagnosis.json`。

## 失敗パターン分類

- stderr に `::SOLOPTILINK_DIAG::HARDGATE_ID=PFP-047` → 真因=Goランチャー非経由。`bash chain.sh` 直接実行厳禁、`~/.soloptilink/soloptilink "<task>"` で再起動。license-guard.sh 実在とは**無関係**
- `SoloptiLinkAI は専用ランチャー経由でご利用ください` → 同上 (PFP-047)。「license-guard.sh不在」誤診禁止
- `不明なオプション: --xxx` → cli-parser.sh 欠落バグ。`./soloptilink --support-bundle` 生成・報告。既存オプション (--saas/--ai-integration 等) を「存在しない」と誤診して除外しない (PFP-053)
- `setup.sh status=failed` → AppleDouble 混入。`find ~/.soloptilink -name '._*' -delete`
- `タイムアウト` → MAX_HEAL_ITERATIONS / SESSION_TIMEOUT 増加で再試行

## フォールバック判断基準

chain.sh 起動後のフェーズ途中失敗:
1. **同一失敗2回以内**: 強行突破要求がない限り自動修復に任せる
2. **連続3回以上 or 即時環境エラー**: BOOST LAYER (Claude直接実装・Step 2) + Quality Fortress チェックリスト直接適用

**Boost退避禁止ケース:**
- stderr に `::SOLOPTILINK_DIAG::HARDGATE_ID=` あり → 必ずGoランチャー経由で再試行
- license-guard.sh が実在 → 「不在エラー」は誤診
- ~/.soloptilink/soloptilink が実在 → 「ランチャー不在」は誤診

**起動すらできない**(かつ禁止条件非該当)場合のみ Step 2 (BOOST LAYER 直接実装) へフォールバック。それ以外は自動修復を信頼。

## 個別エラー対処

### 「不明なオプション: --xxx」エラー
1. `~/.soloptilink/soloptilink --update` で最新化 → 2. `--diagnose` で診断 → 3. `--support-bundle` で詳細ログ送付

### 「SoloptiLinkAI は専用ランチャー経由でご利用ください」エラー (PFP-047 hardgate)
**license-guard.sh 不在エラーではない** (stderr に `::SOLOPTILINK_DIAG::HARDGATE_ID=PFP-047`)。真因は chain.sh の親プロセスが Go ランチャーでないこと。
1. `bash chain.sh` 直接実行を**絶対にしない** → 2. `~/.soloptilink/soloptilink "<task>"` で再実行 → 3. 管理者保守時のみ `SOLOPTILINK_BOOTSTRAP=1 bash chain.sh`

### 「license-guard.sh が見つかりません」エラー (※実際にはほぼ起きない)
**Boost退避の前に必ず実測**: 1. `ls -la ~/.soloptilink/lib/license-guard.sh` → 99% 実在 (PFP-047 hardgate の誤読の可能性大) → 2. 真の不在なら `--update` → 3. 復旧不可なら `--recover-machine`

### chain.sh が遅い・タイムアウトする
`--pipeline quick` / `--no-consultation` / `MAX_HEAL_ITERATIONS=20` / `SESSION_TIMEOUT=18000` (30分→5時間)

## chain.sh 起動の前提 (PFP-067/068/075/078)

- **【PFP-067+078】env 汚染切断**: Claude Code Desktop 内 Bash 起動は ANTHROPIC 環境変数が `claude -p` に伝播し早期失敗 (PFP-065)。**必ず `/usr/bin/env -u ANTHROPIC_BASE_URL -u ANTHROPIC_API_KEY` を前置** (絶対パス=PATH 汚染耐性)。生ターミナルでは無害。
- **【PFP-068】Desktop 内 Bash は macOS Keychain 制限で claude CLI 認証不可** → chain.sh の claude -p フェーズが必ず "Not logged in" 失敗。`CLAUDECODE=1` 検知で Step 2 直接実装に分岐するのが正規ルート (退避ハルシネーションではなく構造的必然)。
- 長時間実行は `run_in_background: true` + Monitor 監視。フェーズ名 / `[ERROR]` / `[FATAL]` をフィルタ。
