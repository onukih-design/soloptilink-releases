---
name: soloptilink-fde
description: "SoloptiLinkAI v2054.3 - 「FDE」「案件台帳」「案件一覧」「担当案件」「期限アラート」「実績ポートフォリオ」「FDEダッシュボード」等で起動。FDE(Forward Deployed Engineer)が担当する全クライアント案件を横断管理するコックピット。案件ボード・瑕疵担保/保守期限アラート・実績ポートフォリオ集計・ステータス別次アクション提案を一画面で提供する。"
argument-hint: "[--board|--alerts|--list|--portfolio|--add|--update] [--client <名>] [--status hearing|proposal|contracted|building|acceptance|handover|maintenance|closed] [--days 60] [--industry <DBL名>]"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, Agent, AskUserQuestion, TodoWrite"
---

# SoloptiLinkAI v2054.3 - FDE Cockpit (案件台帳)


## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

## 機能概要

SoloptiLinkAI v1.0 FDE Cockpit - FDE (Forward Deployed Engineer) が複数クライアントの案件を同時並行で回すための司令塔。1人のFDEは「ヒアリング中のA社」「構築中のB社」「保守中のC社」を常に横断で抱えるが、Claude Code は session 単位で記憶が切れるため案件の全体像を持てない。本スキルは案件台帳 (`~/.soloptilink/engagements/ledger.jsonl`) を単一の正とし、案件ボード表示・瑕疵担保/保守期限アラート・実績ポートフォリオ集計・ステータス別次アクション提案を1コマンドで提供する。「FDE」「案件台帳」「案件一覧」「担当案件」「期限アラート」「実績ポートフォリオ」「FDEダッシュボード」「案件ボード」「瑕疵担保いつまで」「保守期限」等で起動。データ送出ゼロ (すべてローカル JSONL)。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 本スキルの主利用者は FDE 本人 (社内利用) だが、画面共有や客先同席で表示される可能性があるため、台帳の表示は engagement-ledger.sh が整形する日本語ボード/表をそのまま使い、生 JSON・スタックトレースを地の文に貼らない。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

## FDE ライフサイクル全体図（各段階とスキルの結線）

FDE の1案件は次の7段階を一方向に流れる。各段階に対応するスキルが決まっており、本コックピットはどの案件が今どの段階にいるかを一望し、次に呼ぶべきスキルへ誘導する。

```
ヒアリング ──→ 提案 ──→ 構築 ──→ 検収 ──→ 引継 ──→ 保守 ──→ (次案件へ)
 hearing      proposal  contracted  acceptance handover maintenance   closed
                         /building
    │            │           │           │          │         │
    ▼            ▼           ▼           ▼          ▼         ▼
 /soloptilink  /soloptilink /soloptilink /soloptilink /soloptilink 追加開発提案
 -hearing      -rfp         -boost       -acceptance  -handoff    (/soloptilink-rfp)
 ヒアリング     提案書/見積/  業務システム  受入テスト/   運用手順書/  + 月次運用報告
 シート生成     WBS/契約書   一発構築      検収完了書    引継書       (/soloptilink-handoff)
```

- **ヒアリング (hearing)**: `/soloptilink-hearing` でヒアリングシートを生成し、要件の取りこぼしを防ぐ
- **提案 (proposal)**: `/soloptilink-rfp` で提案書・概算見積・WBS・契約書 (請負/準委任) を一括生成
- **構築 (contracted / building)**: `/soloptilink-boost` で一発完成の業務システム構築
- **検収 (acceptance)**: `/soloptilink-acceptance` で受入テスト計画書・テスト仕様書・検収完了書・瑕疵担保期間管理
- **引継 (handover)**: `/soloptilink-handoff` で運用手順書・Runbook・SLA・引継書
- **保守 (maintenance)**: 追加開発の提案 (`/soloptilink-rfp`) と月次運用報告 (`/soloptilink-handoff`) で継続収益化
- **完了 (closed)**: `portfolio add` で実績ポートフォリオに登録し、次案件の提案弾として再利用

検収完了・引継完了のタイミングで `ingest` を使うと、各スキルが出力した session.json から台帳が自動更新される (後述)。

## Step 0: 台帳の存在確認

案件台帳エンジンの所在を確認する。ストレージディレクトリは初回実行時に自動作成されるため、事前準備は不要。

```bash
ls ~/.soloptilink/lib/engagement-ledger.sh >/dev/null 2>&1 && echo "LEDGER_READY" || echo "LEDGER_MISSING"
```

`LEDGER_MISSING` の場合は本体が古い。`/soloptilink-upgrade` で最新版へ更新してから再実行する。

## Step 1: 案件ボード表示（FDA担当の全クライアント横断）

```bash
bash ~/.soloptilink/lib/engagement-ledger.sh board
```

ステータス別 (hearing / proposal / contracted / building / acceptance / handover / maintenance / closed) にグルーピングされた日本語ボードが表示される。FDE が担当する全クライアントの案件が横断で並び、「今どの案件がどの段階にいるか」が一目で分かる。出力されたボードはそのままユーザーに提示してよい (日本語整形済み)。

特定クライアントや特定ステータスだけを見たい場合は表形式の `list` を使う:

```bash
bash ~/.soloptilink/lib/engagement-ledger.sh list --client <クライアント名>
bash ~/.soloptilink/lib/engagement-ledger.sh list --status building
```

## Step 2: 瑕疵担保・保守期限アラート

```bash
bash ~/.soloptilink/lib/engagement-ledger.sh alerts --days 60
```

`warranty_until` (瑕疵担保/契約不適合責任の期限) と `maintenance_until` (保守契約の期限) が60日以内に到来する案件を警告表示する。0件なら「期限が近い案件はありません」と表示される。

アラートが出た案件への定石:
- **瑕疵担保期限が近い**: 期限前に最終動作確認を実施し、検収完了書・瑕疵担保終了の確認文書を `/soloptilink-acceptance` で整える
- **保守期限が近い**: 保守契約の更新提案 + 追加開発提案を `/soloptilink-rfp` で作成し、更新交渉を期限の30日前までに開始する

期間を変えたい場合は `--days` を調整する (例: 四半期先まで見るなら `--days 90`)。

## Step 3: 実績ポートフォリオサマリ

```bash
bash ~/.soloptilink/lib/engagement-ledger.sh portfolio summary
```

構築社数・業種カバレッジ (DBL 業種辞書ベース) の集計が表示される。営業面談・提案書の「実績」欄にそのまま使える数字。業種を絞った一覧は:

```bash
bash ~/.soloptilink/lib/engagement-ledger.sh portfolio list --industry <DBL名>
```

案件が完了 (closed) したら、ポートフォリオに実績として登録する (クライアント名は匿名化可):

```bash
bash ~/.soloptilink/lib/engagement-ledger.sh portfolio add --industry <DBL名> --client "<クライアント名 or 匿名表記>" --summary "<実績概要>" --scale "<規模感>" --effect "<導入効果>"
```

## Step 4: ステータス別 次アクション提案

ボード表示後、各案件の `status` に応じて次のアクションを以下の表で提案する。ユーザーには「どの案件で、次に何をすべきで、どのスキルを呼べばよいか」を日本語の表で示すこと。

| status | 段階 | 次アクション | 呼ぶスキル |
|--------|------|-------------|-----------|
| `hearing` | ヒアリング中 | ヒアリングシートを生成し要件を確定 | `/soloptilink-hearing` |
| `proposal` | 提案中 | 提案書・概算見積・WBS・契約書を生成 | `/soloptilink-rfp` |
| `contracted` | 受注済 | キックオフし構築を開始 | `/soloptilink-boost` |
| `building` | 構築中 | 構築の継続・品質ゲート完走 | `/soloptilink-boost` |
| `acceptance` | 検収中 | 受入テスト計画書・テスト仕様書・検収完了書を生成 | `/soloptilink-acceptance` |
| `handover` | 引継中 | 運用手順書・Runbook・SLA・引継書を生成 | `/soloptilink-handoff` |
| `maintenance` | 保守中 | 追加開発提案 + 月次運用報告で継続収益化 | `/soloptilink-rfp` (追加開発) / `/soloptilink-handoff` (月次報告) |
| `closed` | 完了 | 実績をポートフォリオ登録し、次案件・紹介につなげる | `portfolio add` (本スキル内) |

提案時の優先順位付け:
1. **Step 2 のアラート該当案件を最優先** (期限が迫っているものから)
2. 次に `acceptance` / `handover` (顧客の入金・信頼に直結する段階)
3. 次に `building` (手が止まると遅延する段階)
4. 最後に `hearing` / `proposal` (仕込み段階)

## 新規案件の登録と更新（操作ガイド）

### 登録 (add)

新しい引き合い・案件が発生したら、その場で台帳に登録する:

```bash
bash ~/.soloptilink/lib/engagement-ledger.sh add --client "<クライアント名>" --project "<案件名>" [--dbl <業種辞書名>] [--status hearing] [--dir <プロジェクトディレクトリ>]
```

- `engagement_id` (形式: `eng_<YYYYMMDD>_<client_slug>_<2桁連番>`) が発番されて出力される。以後の更新はこのIDで行う
- `--status` 省略時の初期値はヒアリング段階。受注済みの案件を後から登録する場合は `--status contracted` 等を指定
- `--dbl` には業種辞書名 (例: construction / clinic / real-estate 等) を指定すると業種カバレッジ集計に反映される

### 更新 (update)

ステータス遷移・金額確定・期限設定はすべて `update` で行う (複数オプション同時指定可):

```bash
# ステータス遷移 (例: 提案→受注)
bash ~/.soloptilink/lib/engagement-ledger.sh update <engagement_id> --status contracted

# 納品+瑕疵担保・保守期限の設定 (検収完了時の典型形)
bash ~/.soloptilink/lib/engagement-ledger.sh update <engagement_id> --status handover --delivered 2026-06-13 --warranty-until 2026-12-13 --maintenance-until 2027-06-13

# 受注金額・メモの更新
bash ~/.soloptilink/lib/engagement-ledger.sh update <engagement_id> --amount 600000 --notes "初期構築60万+月額20万/1端末"
```

### 自動取り込み (ingest)

`/soloptilink-rfp` `/soloptilink-acceptance` `/soloptilink-handoff` が出力する session.json を渡すと、ファイル名・中身から種別を自動判別して台帳を更新する (client/project 一致の既存案件を更新、なければ新規 add):

```bash
bash ~/.soloptilink/lib/engagement-ledger.sh ingest <session.jsonのパス>
```

- rfp の session → `status=proposal` + 金額反映
- acceptance の session → `status=handover` + `warranty_until` 自動算出
- handoff の session → `status=maintenance`

各フェーズのスキルを完走したら ingest を1回流す運用にすると、台帳が手入力ゼロで最新に保たれる。

## engagement-ledger.sh リファレンス

- **場所**: `~/.soloptilink/lib/engagement-ledger.sh` (bash・jq非依存・python3でJSON処理・BSD/GNU両対応)
- **ストレージ**: `~/.soloptilink/engagements/ledger.jsonl` (1行=1案件) と `~/.soloptilink/engagements/portfolio/*.json`。初回実行時に自動作成
- **案件エントリのキー**: `engagement_id` / `client_name` / `project_name` / `industry_dbl` / `status` / `contract_type` / `amount_jpy` / `contracted_at` / `delivered_at` / `warranty_until` / `maintenance_until` / `project_dir` / `notes` / `updated_at`

| サブコマンド | 用途 |
|-------------|------|
| `add --client <名> --project <名> [--dbl <辞書名>] [--status <s>] [--dir <path>]` | 案件を発番・登録 |
| `update <engagement_id> --status/--warranty-until/--maintenance-until/--delivered/--amount/--notes` | 案件を更新 (複数可) |
| `ingest <session.jsonのパス>` | rfp/acceptance/handoff の成果物から自動更新 |
| `list [--client <名>] [--status <s>]` | 表形式一覧 (日本語ヘッダ) |
| `board` | ステータス別グルーピングボード |
| `alerts [--days 60]` | 瑕疵担保・保守期限アラート |
| `portfolio add --industry <dbl> --client <名> --summary <text> [--scale <text>] [--effect <text>]` | 実績登録 |
| `portfolio list [--industry <dbl>]` / `portfolio summary` | 実績一覧 / 件数・業種カバレッジ集計 |

出力はすべて日本語。引数を誤ると使い方が表示されるので、それをそのままユーザーへの案内に使ってよい。

## 引数解釈

| 引数 | 動作 |
|------|------|
| (引数なし) | Step 1→2→3→4 をフル実行 (コックピット表示) |
| `--board` | Step 1 のみ (案件ボード) |
| `--alerts [--days N]` | Step 2 のみ (期限アラート、既定60日) |
| `--list [--client <名>] [--status <s>]` | 表形式一覧のみ |
| `--portfolio` | Step 3 のみ (実績サマリ) |
| `--add` | 新規案件の登録ガイドへ (不足項目は日本語で質問) |
| `--update` | 既存案件の更新ガイドへ (対象IDが不明なら list で提示して選ばせる) |

## 使用例

```bash
# 朝イチの定点観測 (ボード+アラート+実績+次アクション)
/soloptilink-fde

# 期限アラートだけ四半期先まで
/soloptilink-fde --alerts --days 90

# 新しい引き合いを登録
/soloptilink-fde --add

# 特定クライアントの案件だけ確認
/soloptilink-fde --list --client 株式会社サンプル建設
```

## 連携スキル

- `/soloptilink-hearing`: hearing 段階のヒアリングシート生成
- `/soloptilink-rfp`: proposal 段階の提案書・見積・WBS・契約書 / maintenance 段階の追加開発提案
- `/soloptilink-boost`: contracted/building 段階の業務システム構築
- `/soloptilink-acceptance`: acceptance 段階の検収文書一式・瑕疵担保期間管理
- `/soloptilink-handoff`: handover 段階の引継文書 / maintenance 段階の月次運用報告
- `/soloptilink-tenant-dna`: 案件で得た顧客固有の判断・命名規則の永続学習 (台帳と相互補完)
- `/soloptilink-blueprint`: `industry_dbl` に使う業種辞書の照会

## 設計哲学

1. **単一の正**: 案件の状態は `ledger.jsonl` のみが正。記憶やチャット履歴に頼らない
2. **手入力最小**: フェーズスキルの成果物を `ingest` で自動取り込み
3. **期限は前倒し検知**: 瑕疵担保・保守期限は60日前から警告し、交渉リードタイムを確保
4. **実績は資産**: closed 案件は必ずポートフォリオ化し、次案件の提案力に変換
5. **オフライン完結**: すべてローカル JSONL、データ送出ゼロ
