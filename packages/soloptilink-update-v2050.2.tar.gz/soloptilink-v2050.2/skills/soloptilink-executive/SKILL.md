---
name: soloptilink-executive
description: "「経営者」「CEO」「CFO」「資金繰り」「ヨミ表」「着地」「事業承継」「中期経営計画」「Board Deck」「経営判断」「KPI設計」等で起動。経営者視点でシステムを生成する経営者DNAレイヤー。"
---

# SoloptiLinkAI v2050.2 - Executive Cognitive Layer (ECL)

## 機能概要

SoloptiLinkAI v2033.0 Executive Cognitive Layer (ECL) - 経営者DNAレイヤー。Phase 45 として「経営者の頭の中」を完全内蔵。9 C-Suiteロールプロファイル(CEO/CFO/COO/CTO/CHRO/CMO/CSO/CRO/CISO) / 戦略フレーム40 / 財務指標30+ (LTV/CAC/Rule of 40/Burn Multiple/NRR/Runway/DSCR/CCC) / 業界別KPIダッシュボード15業界 / 経営判断100パターン / 自然言語クエリ100 (経営者語彙: ヨミ表/Aヨミ/アンダー/内示/銀行筋/着地/腹落ち) / 経営者UIパターン20 (Dawn Brief/What-Ifスライダー/Decision Journal/Board Deck自動生成/ヨミ表ビュー) / Pyramid Principle 1ページレポート / Amazon 6-Page Memo / 取締役会年間アジェンダ / 認知バイアス20種検知 / 中小経営実務 (13週CF/黒字倒産7予兆/銀行格付/事業承継税制特例R9.3.31期限/中小M&Aガイドライン第3版/経営者保証GL R5/補助金2026 15メニュー/倒産回避民事再生/役員退職金功績倍率/法人保険) / 業種別経営ベンチマーク (営業利益率/労分/CCC/DSCR/Rule40 21指標 日本グローバル両対応 2026最新値)。「経営者として使いやすい」ではなく「経営者視点で作られた」システムを生成する核心レイヤー。「経営者」「CEO」「CFO」「COO」「資金繰り」「ヨミ表」「着地」「事業承継」「中期経営計画」「役員会」「Board Deck」「経営判断」「KPI設計」「Dawn Brief」等で起動。Vigesimaprimusfortress 21×170=3,570点 (21st = Executive Cognitive Fortress 170/170)。Phase 1-44 と完全直交、並行使用可。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

## 設計思想

通常のシステム生成は「機能要件」から始まる。本レイヤーは **「経営者がそのシステムで判断したい瞬間」** から逆算する。

```
従来:  Requirements → Features → UI → Data → Code
ECL:   Executive Decision Moment → KPI/Data Required → UI Pattern → Features → Code
```

経営者は「機能」を欲しがらない。**「次にとるべき手」が分かる答え** を欲しがる。本レイヤーは下記4軸でシステム生成プロンプトに注入される。

---

## 4軸知識ベース

### 1. C-Suite Role DNA (9ロール)
`lib/business/csuite_profiles.ts`
- CEO / CFO / COO / CTO / CHRO / CMO / CSO / CRO / CISO
- 各ロールの **朝のダッシュボード5枚** / 週次・月次・四半期意思決定 / メンタルモデル / 失敗パターン / 経営会議で問う代表10質問 / 認知バイアス
- システム生成時、ターゲット利用者ロールを選択すると **そのロール専用のホーム画面・通知設計** が自動配置される

### 2. Finance Engine (財務エンジン)
`lib/business/finance_engine.ts`
- **ユニットエコノミクス**: LTV / CAC / Payback / Magic Number / Rule of 40 / Burn Multiple / NRR / GRR / Churn
- **資金繰り**: Cash Runway / DSCR / CCC / 黒字倒産7予兆
- **バリュエーション**: DCF / WACC / NPV / IRR / マルチプル / ROIC / ROE
- **2026最新ベンチマーク**: 日本 + グローバル両対応、業種別中央値・上位25%・下位25%
- **警報閾値**: 各指標に「いつアラートを出すべきか」を内蔵

### 3. Decision Patterns (経営判断100)
`lib/business/decision_patterns.ts`
- 人事組織20 / 価販20 / 投資撤退20 / 財務20 / リスクコンプラ20
- 各判断に `{ trigger, key_metrics, common_mistakes, system_support, jp_context }` 構造
- BOOST起動時にキーワード検出で関連判断パターンを自動引込

### 4. Industry Benchmarks (業界別)
`lib/business/industry_bench_jp.ts`
- 15業界 × 5+1指標 (営業利益率/粗利率/労分/CCC/在庫回転 + 業界特有1指標)
- 中小企業庁/TKC/中央値/上位/下位
- 「業界平均と比較してどう?」を即答可能

---

## 経営者UX層

### NLQ (自然言語クエリ) 100件
`lib/executive_ux/nlq_parser.ts`
- カネ20 / ヒト15 / 顧客15 / 商品15 / 市場10 / リスク10 / 戦略15
- **日本経営者語彙20語** (ヨミ表/Aヨミ/アンダー/内示/銀行筋/着地/腹落ち/ガラポン/しゃんしゃん/てっぺん 等)
- 各クエリ: 口語 → 集計ロジック → 表示 → 次に見るべき3点

### UIパターン 20種
`lib/executive_ux/ui_patterns.ts`
1. **Dawn Brief** (経営早朝ダッシュボード)
2. **What-Ifスライダー** (売上-10%なら何ヶ月持つ?)
3. **異常通知優先度マトリクス** (アイゼンハワー4象限)
4. **前年比+業界平均オーバーレイ**
5. **経営判断ログ (Decision Journal)**
6. **One-Tap Approval** (Slack/モバイル決裁)
7. **Board Deck自動生成** (Pyramid Principle PDF)
8. **会議意思決定ボード**
9. **ストーリーモードPL** (3行要約)
10. **経営者ホワイトボード** (音声→自動分類)
11. **ヨミ表ビュー** (Aヨミ+B×0.7予測)
12. **月初コックピット**
13. **アンカー比較ビュー**
14. **アラート信号機優先キュー**
15. **マイクロカードシリーズ** (モバイル特化)
16. **トラフィックライト分布**
17. **質問プロンプトサジェスト**
18. **ナラティブ・タイムライン**
19. **ボードパックPDF** (SCQA構造)
20. **経営者プライベートチャネル** (Claude AI Co-Pilot)

### Reporting (経営者向け文体)
`lib/executive_ux/reporting.ts`
- **Pyramid Principle** (BLUF + 3根拠 + MECE)
- **SCQA構造** (Situation / Complication / Question / Answer)
- **1ページレポート** (アイゼンハワー流)
- **Amazon 6-Page Memo** (黙読30分方式)
- **ダメ報告アンチパターン5** (冗長/専門用語/結論不明/他人事/隠蔽)
- **悪い知らせ先出し** プロトコル

### Habits (経営者習慣)
`lib/executive_ux/habits.ts`
- 朝のルーティン (5-9時) システム先回り設計
- 月初・月末・四半期・年初年末の必須タスク
- 通知タイミング: 06:00 Dawn Brief / 08:00 朝礼資料 / 17:30 翌日準備 / 19:00 決裁残

---

## Governance & 中小経営実務

### Governance JP
`lib/business/governance_jp.ts`
- コーポレートガバナンスコード R6 改訂版 5原則
- 機関設計 3類型 (監査役会/監査等委員会/指名委員会等)
- 取締役会 **12ヶ月分の年間アジェンダ** (3月決算企業モデル)
- 株主総会フロー + 標準議案
- Board Deck標準構成 (月次/四半期/年次)
- 中期経営計画策定 (バックキャスト + ROICツリー)

### Cashflow JP
`lib/business/cashflow_engine.ts`
- **13週キャッシュフロー** 生成
- **黒字倒産7予兆** (営業CF/支払サイト/借入返済/税滞納合成)
- **銀行格付シミュレーター** (正常先〜破綻懸念)
- 信用保証協会 / プロパー / 政策金融公庫 制度メニュー
- **約束手形廃止 2026年度末**: でんさい移行プロトコル

### Succession & M&A JP
`lib/business/succession_ma_jp.ts`
- **事業承継税制 特例措置** (R9.3.31提出期限)
- 株式譲渡 vs 事業譲渡 vs 会社分割 税務比較
- **M&A仲介手数料** (レーマン方式)
- バリュエーション (純資産+のれん / EBITDA倍率 / DCF)
- **中小M&Aガイドライン第3版** (R6.8 仲介規律強化)
- PMI 100日プラン

### Turnaround JP
`lib/business/turnaround_jp.ts`
- **Altman Z-Score** 中小企業適用版
- **経営者保証ガイドライン R5改訂**
- 第二会社方式 / 民事再生 / 会社更生 / 特別清算 選択フロー
- スポンサー型再生 (中小企業活性化協議会 / REVIC / 中小機構)
- 廃業フロー + 廃業税制 + 経営者保証解除
- **2025年度倒産1万425件** (4年連続増 / 人手不足441件 / 物価高963件)

### Personal Risk JP
`lib/business/personal_risk_jp.ts`
- 役員退職金 (功績倍率法)
- 役員報酬 (定期同額 / 事前確定届出 / 業績連動)
- 法人保険 (節税×保障×退職金準備)
- 役員間利益相反取引
- 反社チェック (eKYC + 弁護士会照会)
- 経営者保証解除交渉

---

## Strategy Frameworks
`lib/business/frameworks.ts`
**40フレームワーク** カテゴリ別:
- 古典9: SWOT / 5Force / PEST / 3C / 4P / VRIO / バリューチェーン / BCG / GE
- モダン8: Blue Ocean / Lean Canvas / BMC / JTBD / Disruption / Chasm / Playing to Win / AARRR
- 実行6: OKR / KPIツリー / BSC / Hoshin Kanri / V2MOM / North Star Metric
- 組織5: 7S / Spotify / Holacracy / Teal / RACI
- 意思決定8: Real Options / Wardley / Scenario / Pre-mortem / OODA / Porter Generic / Ansoff / Option Elimination
- 日本式3: 5Why / 3M (Muda/Mura/Muri) / 8D
- 補強1: SCQA

各フレーム: `{ name, category, purpose, when_to_use, inputs, outputs, anti_pattern, jp_adapt }`

---

## 起動キーワード

以下のキーワード検出で本レイヤーが自動注入:

**経営層ロール**: 経営者 / CEO / CFO / COO / CTO / CHRO / CMO / CSO / CRO / CISO / 役員 / 取締役 / 社長 / 代表

**経営判断トリガー**: 値上げ / 撤退 / 採用すべき / 投資 / M&A / 事業承継 / IPO / 上場 / リスケ / 倒産

**経営指標**: KPI / ROIC / ROE / LTV / CAC / Rule of 40 / Burn Multiple / NRR / Churn / 資金繰り / Runway / DSCR / CCC / 黒字倒産

**業務シーン**: 役員会 / Board Deck / 中期経営計画 / 月次経営会議 / 株主総会 / 期初挨拶 / 年頭挨拶

**経営者語彙**: ヨミ表 / Aヨミ / アンダー / 内示 / 銀行筋 / 着地 / 腹落ち / ガラポン / しゃんしゃん / てっぺん / 筋の良し悪し / 頭出し

**UI関連**: Dawn Brief / What-If / 経営ダッシュボード / 早朝ダッシュボード / 経営判断ログ / 決裁

---

## Quality Fortress 拡張

**21st = Executive Cognitive Fortress (170/170 Diamond★★★★★)**

| 軸 | 内容 | REAL_VERIFY |
|---|---|---|
| ECF-01 | 戦略フレーム40網羅性 | 全モジュール存在チェック |
| ECF-02 | 9ロールDNA完備 | csuite_profiles.ts に9ロール存在 |
| ECF-03 | 財務指標30+カバー | finance_engine.ts に必須30指標存在 |
| ECF-04 | 業界15ベンチマーク鮮度 | 2026年データ含有 |
| ECF-05 | 経営判断100存在 | decision_patterns.ts D001-D100 |
| ECF-06 | NLQ100件 + 日本語彙20 | nlq_parser.ts |
| ECF-07 | UI20パターン仕様 | ui_patterns.ts |
| ECF-08 | Pyramid Principle 出力 | reporting.ts |
| ECF-09 | 取締役会年間アジェンダ | governance_jp.ts に12ヶ月分 |
| ECF-10 | 黒字倒産7予兆検知 | cashflow_engine.ts |
| ECF-11 | 事業承継税制期限警告 | succession_ma_jp.ts R9.3.31 |
| ECF-12 | 経営者保証GL R5 | turnaround_jp.ts |
| ECF-13 | 認知バイアス20検知 | csuite_profiles.ts に20種 |
| ECF-14 | 朝・月初・期末習慣 | habits.ts |
| ECF-15 | Dawn Brief 出力可 | components/executive/DawnBrief |
| ECF-16 | What-If シミュレータ | components/executive/WhatIfSlider |
| ECF-17 | Decision Journal 永続化 | components/executive/DecisionLog |

→ **Vigesimaprimusfortress = 21×170 = 3,570点** (Vigesimafortress 3,400点 → +170点)

---

## BOOST との統合

### Step 0.55 (ARSL前 / 新規 Executive Pre-Check)
ユーザー指示に経営層キーワードが含まれる場合、本レイヤーを **デフォルトON**:
1. ターゲットロールを推論 (CEO/CFO/COO等)
2. 該当 csuite_profile を生成プロンプトに先頭注入
3. ホーム画面の主要KPIを **5枚以内** に強制
4. 数値表示を「億・万」単位+「3桁カンマ」に強制
5. Pyramid Principle を文体ベースラインに

### Step 4f-4 (Executive Sanity Check / 新規)
経営者向け資料生成完了後:
1. 1画面KPIが6枚以上ある → ✗ (4±1チャンク違反)
2. 結論が冒頭3行に無い → ✗ (Pyramid Principle違反)
3. 信頼度ラベルが無い → ✗ (経営者AI境界違反)
4. 反証データ欠落 → ✗ (確証バイアス助長)
5. 業界ベンチマーク比較が無い → ✗ (アンカー単一)

---

## Phase 1-44 との直交性

| Phase | 既存内容 | ECL との関係 |
|---|---|---|
| Phase 1-21 | 法令・業種辞書・帳票 | **データソース** として ECL から参照 |
| Phase 22 | ガバナンス3軸 | governance_jp.ts と統合 |
| Phase 23-CS | カスタマーサポート | 経営者UX の顧客系NLQで参照 |
| Phase 24-FA | 経理会計 | finance_engine.ts に統合 |
| Phase 32-CS | サイバーセキュリティ | CISO Profile と連動 |
| Phase 42-HC | ヘルスケアIT | 業界別ベンチ15業種に統合 |
| Phase 43-IT | 国際貿易 | CFO/CSO Profile で参照 |
| Phase 44-IP | 知財3法 | 戦略 (VRIO) で参照 |
| **Phase 45 (新)** | **Executive Cognitive Layer** | 上記全てを「経営者の頭」から再編成 |

---

## 使用例

```
/soloptilink-executive 売上1.8億の中堅製造業に経営者向けダッシュボード作って
→ COO+CFO ハイブリッド Profile を注入
→ Dawn Brief + What-If + ヨミ表ビュー + 1ページレポート 構成
→ 製造業ベンチマーク (OEE/在庫日数/不良率/原価率) で構成

/soloptilink-executive 役員会資料の雛型を作って
→ Board Deck Pyramid Principle 構造で生成
→ SCQA 1ページサマリ + 詳細ページ + 決議事項

/soloptilink-executive 「資金やばくない?」に答えるアプリ
→ NLQ_CASH_001 仕様 + 信号機+残月数+砂時計UI
→ Cash Runway / DSCR / 13週CF / 黒字倒産7予兆 を内蔵
```

## 出典 & データ鮮度
- 中小企業白書 2025 (中小企業庁)
- TKC 経営指標 / 帝国データバンク / 東商リサーチ
- SaaS Benchmarks 2026 (Aventis / Drivetrain / SaaS Hero)
- コーポレートガバナンスコード R6 改訂版 (金融庁)
- 中小M&Aガイドライン 第3版 R6.8 (中小企業庁)
- 経営者保証GL R5改訂
- Pyramid Principle (Barbara Minto)
- Amazon 6-Page Memo (Jeff Bezos)
- Real Options / Wardley Mapping / Hoshin Kanri 学術原典

全ベンチマークは **2026年5月時点最新** を採用、年次更新必須。
