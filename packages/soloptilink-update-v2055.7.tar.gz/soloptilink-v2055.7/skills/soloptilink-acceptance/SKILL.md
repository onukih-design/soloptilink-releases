---
name: soloptilink-acceptance
description: "SoloptiLinkAI v2055.7 - 「検収」「受入テスト」「UAT」「テスト計画書」「テスト仕様書」「バグ票」「不具合管理表」「検収依頼書」「検収完了書」「瑕疵担保」等で起動。日本SI受託開発の検収フェーズ文書を一括生成する。"
argument-hint: "[案件名 or プロジェクトディレクトリ] [--mode plan|spec|bug-report|completion|all] [--criteria standard|strict|public-sector] [--industry 建設|製造|医療|介護|不動産|公共|金融|...] [--warranty-months 6] [--client-type 民間|公共|自治体] [--locale ja|en]"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, Agent, AskUserQuestion, TodoWrite"
---

# SoloptiLinkAI v2055.7 - Acceptance Engine


## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

## 機能概要

SoloptiLinkAI v1.0 Acceptance Engine - 日本のSI受託開発の検収フェーズを自動化。受入テスト計画書 / テスト仕様書 (テストケース集) / 不具合管理表 + バグ票 / 検収依頼書 / 検収完了書 / 瑕疵担保期間管理 を一括生成。Claude Code が触れない日本SI市場の納品〜検収のラストワンマイル。「検収」「受入テスト」「UAT」「テスト計画書」「テスト仕様書」「バグ票」「不具合管理表」「検収依頼書」「検収完了書」「瑕疵担保」等で起動。V字モデル準拠。民法636条/562条 (契約不適合責任) + 会計法29条の3 (公共調達) + 下請法60日支払 完全対応。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

Claude Code が触れない**日本のSI受託開発の検収フェーズ全体**を自動化するスキル。
姉妹スキル `/soloptilink-rfp` (RFP→提案→契約) の続きを担当し、**納品〜検収完了** までを完全カバー。

## 対 Claude Code 差別化

| 工程 | Claude Code | SoloptiLinkAI-Acceptance |
|------|------------|--------------------------|
| 受入テスト計画書 | ❌ | ✅ V字モデル準拠 9章構成 |
| テスト仕様書 | ⚠️ 雑な箇条書き | ✅ TC-ID命名規則 + 7カテゴリ網羅 |
| 不具合管理表 | ❌ | ✅ S/A/B/C重大度 + ステートマシン制御 |
| バグ票テンプレ | ❌ | ✅ 再現手順 + 環境 + コミットID紐付 |
| 合格基準エンジン | ❌ | ✅ standard / strict / public-sector 切替 |
| 検収依頼書 / 完了書 | ❌ | ✅ 民法636条/562条 + 会計法29条の3 準拠 |
| 瑕疵担保期間管理 | ❌ | ✅ --warranty-months で柔軟設定 |

## V字モデル対応

| 開発工程 | 対応するテスト工程 | 本スキル生成物 |
|---------|------------------|---------------|
| 要件定義 | 受入テスト (UAT) | テスト計画書 + 業務シナリオ仕様書 |
| 基本設計 | 結合テスト (ST) | システムテスト仕様書 |
| 詳細設計 | 単体テスト (UT) | (開発側担当 / 本スキル対象外) |
| 実装 | コードレビュー | (開発側担当) |
| 結合 | 結合テスト実施 | 不具合管理表 |
| 受入 | 検収 | 検収依頼書 + 検収完了書 + 瑕疵担保契約 |

## Step 0: 端末認証 (BOOST と同一)

```bash
SOLOPTILINK_BIN=""; if [ -f ~/.soloptilink/soloptilink ]; then SOLOPTILINK_BIN="./soloptilink"; elif [ -f ~/.soloptilink/soloptilink.exe ]; then SOLOPTILINK_BIN="./soloptilink.exe"; fi
AUTH_CHECK=$(cd ~/.soloptilink 2>/dev/null && ${SOLOPTILINK_BIN:-./soloptilink} --status 2>&1); if echo "$AUTH_CHECK" | grep -q "承認済み"; then echo "AUTHORIZED"; else echo "UNAUTHORIZED"; fi
```

`UNAUTHORIZED` の場合、認証案内を表示して処理中止。

## Step 1: コンテキスト取り込み

姉妹スキル `/soloptilink-rfp` が生成した `.soloptilink-rfp-session.json` (RFP-DNA / 提案書 / WBS / 契約書) を可能な限り読み込み、検収フェーズの一貫性を確保:

```typescript
import { generateAcceptancePackage } from './lib/index';

const result = generateAcceptancePackage({
  project_name: '工事原価管理システム',
  industry: 'construction',
  client_type: '民間',
  rfp_text: '...',  // 任意。RFP-DNA があるとテスト範囲が高精度
  parties: { client, contractor },
  schedule: { uat_start, uat_end, judgment_meeting, deadline },
  criteria_mode: 'standard',
  warranty_months: 6,
});
```

## Step 2: 受入テスト計画書生成 (`--mode plan`)

`lib/test_plan_generator.ts` で日本SI標準 9章構成のテスト計画書を生成:

1. **テスト目的・範囲** (どのモジュール / どのシナリオを対象とするか)
2. **テスト体制** (顧客側責任者 / PM / テスター / 役割分担)
3. **テスト環境** (本番相当 Stage 環境 / マスクド本番データ / 接続先)
4. **テスト工程・スケジュール** (UAT 期間 / 不具合修正期間 / 再テスト期間 / 判定会議)
5. **テスト実施方法** (シナリオベース / 探索的テスト / リグレッション / 性能)
6. **合格基準** (重大度別不具合許容数 / 業務シナリオ網羅率 / 性能SLO達成)
7. **不具合管理プロセス** (発見→起票→修正依頼→修正→再テスト→クローズ)
8. **検収判定基準** (合格 / 条件付合格 / 不合格)
9. **リスク・課題** (期間タイト / 環境制約 / ステークホルダー不在対策)

## Step 3: テスト仕様書生成 (`--mode spec`)

`lib/test_spec_generator.ts` で RFP-DNA / 提案書からテストケースを推論:

### テストケース命名規則 (`TC-<モジュール>-<番号>`)

| 例 | 説明 |
|----|------|
| `TC-AUTH-001` | 認証モジュール 1番目 |
| `TC-DASHBOARD-014` | ダッシュボード 14番目 |
| `TC-SECURITY-003` | セキュリティ 3番目 |

### テストケース構造

| 項目 | 内容 |
|------|------|
| ID | TC-XXX-NNN |
| シナリオ名 | 「ユーザがMFA有効化済アカウントでログインする」等 |
| 前提条件 | 「対象ユーザのMFAは有効化済」 |
| 操作手順 | 1. ログイン画面を開く / 2. ID/PW入力 / 3. ログインボタン押下 / 4. TOTP入力 |
| 期待結果 | 「ダッシュボードに遷移し、ユーザ名が右上に表示される」 |
| 結果記入欄 | OK / NG / N/A + 実施日 + テスター名 + 不具合票ID |

### 7カテゴリ網羅

1. **機能テスト** - CRUD / 検索 / バリデーション
2. **UI テスト** - レスポンシブ / アクセシビリティ / ブラウザ互換
3. **非機能テスト** - 性能 (TPS / レスポンス) / 可用性 / 拡張性
4. **業務シナリオテスト** - 発注→検収→入金 等のE2Eフロー
5. **セキュリティテスト** - OWASP Top 10 / 脆弱性スキャン / ペネトレーション
6. **障害復旧テスト** - DR / フェイルオーバー / バックアップリストア
7. **データ移行検証** - 既存データの移行精度 / マスタ整合性

## Step 4: 不具合管理表 + バグ票生成 (`--mode bug-report`)

`lib/bug_tracker.ts` で不具合票テンプレ + 集計ダッシュボードを生成:

### バグ票項目

| 項目 | 内容 |
|------|------|
| ID | BUG-YYYYMMDD-NNN |
| 発見日 | YYYY-MM-DD |
| 発見者 | 顧客側テスター名 |
| モジュール | 認証 / ダッシュボード / 帳票 等 |
| 重大度 | S (致命) / A (重大) / B (中程度) / C (軽微) |
| 優先度 | P1 (即時) / P2 (今週中) / P3 (次回リリース) / P4 (任意) |
| 再現手順 | 1. ... / 2. ... / 3. ... |
| 期待結果 | 期待されるシステム動作 |
| 実際結果 | 実際に観測された動作 |
| 環境 | OS / ブラウザ / 端末 / 接続先 |
| スクリーンショット | 添付ファイル参照 |
| 担当者 | 開発側担当 |
| ステータス | 新規 / 調査中 / 修正中 / 修正完了 / 再テスト中 / クローズ / 差戻し |
| 修正コミット | git SHA |
| 検証担当 | 顧客側テスター |

### ステートマシン (不正遷移防止)

```
新規 → 調査中 → 修正中 → 修正完了 → 再テスト中 → クローズ
                                       ↓
                                     差戻し → 修正中 (ループ)
クローズ → (再オープン許可) → 新規
```

### 集計ダッシュボード

- **重大度別件数**: S / A / B / C 件数とパーセンテージ
- **フェーズ別件数**: 結合テスト / システムテスト / UAT
- **担当者別件数**: 担当者ごとのオープン件数 + 修正完了率
- **オープン日数中央値**: 50パーセンタイル / 90パーセンタイルでSLO監視

## Step 5: 検収依頼書 / 検収完了書生成 (`--mode completion`)

`lib/acceptance_doc_generator.ts` で検収プロセスの両端を生成:

### 検収依頼書

| 項目 | 内容 |
|------|------|
| 件名 | 「○○システム 検収のお願い」 |
| 提出日 | YYYY-MM-DD |
| 案件名 | 契約書記載の正式名称 |
| 納品物リスト | 設計書 / コード / テスト報告書 / 運用手順書 / 教育資料 |
| 検収期間 | YYYY-MM-DD 〜 YYYY-MM-DD (民法562条 通常合理的期間) |
| 受託者署名欄 | 印影プレースホルダ |

### 検収完了書

| 項目 | 内容 |
|------|------|
| 件名 | 「○○システム 検収完了通知書」 |
| 検収日 | YYYY-MM-DD |
| 案件名 | 契約書記載の正式名称 |
| 納品物確認 | 各納品物のチェックリスト + 確認者 |
| 不具合有無 | 残不具合一覧 + 重大度別件数 |
| 検収判定 | 合格 / 条件付合格 / 不合格 |
| 委託者署名欄 | 印影プレースホルダ |
| 瑕疵担保期間 | 民法636条/562条 / デフォルト6ヶ月 / `--warranty-months` で変更可 |

### 瑕疵担保期間 (契約不適合責任)

民法 562 条 (追完請求権) / 636 条 (請負人の担保責任) / 637 条 (期間制限) に基づき:

| 規定 | 内容 |
|------|------|
| 通知期間 | 不適合を知った時から **1年以内** に通知 (民637条) |
| 担保期間 | デフォルト **6ヶ月** / システム規模により12ヶ月も可 |
| 公共調達 | **2年以上** が一般的 (会計法29条の3 + 各省 標準契約条項) |
| 追完請求 | 修補 / 代替物の引渡 / 不足分の引渡 (民562条) |
| 報酬減額 | 追完不能時 (民563条) |
| 解除 | 重大な不適合かつ追完不能時 (民564条) |

### 案件台帳・実績カード自動登録 (検収完了書生成直後)

検収完了書の生成直後に、以下の2処理を自動実行する:

1. `bash ~/.soloptilink/lib/engagement-ledger.sh ingest .soloptilink-acceptance-session.json` — 案件台帳 (Engagement Ledger) に status=handover で自動登録し、瑕疵担保期限も自動記録する
2. `bash ~/.soloptilink/lib/engagement-ledger.sh portfolio add --industry <業種> --client <匿名化した顧客名> --summary <システム概要> --scale <規模> --effect <導入効果>` — 実績カードを自動保存する (`/soloptilink-rfp` 提案書の「類似実績」章で優先引用される)

## Step 6: 合格基準エンジン (`lib/criteria_engine.ts`)

`--criteria` で3モード切替:

### standard (民間 / 一般受託)

| 重大度 | 許容件数 |
|-------|---------|
| P1 (致命的バグ) | 0 件 |
| P2 (重大バグ) | ≤ 2 件 |
| P3 (中程度バグ) | ≤ 10 件 |
| P4 (軽微) | 任意 |

### strict (大手SIer / 厳格な品質要求)

| 重大度 | 許容件数 |
|-------|---------|
| P1 | 0 件 |
| P2 | 0 件 |
| P3 | ≤ 2 件 |
| P4 | 任意 |

### public-sector (公共調達 / 会計法29条の3)

| 重大度 | 許容件数 |
|-------|---------|
| P1 | 0 件 |
| P2 | 0 件 |
| P3 | 0 件 |
| P4 | ≤ 5 件 |

判定関数 `evaluateCriteria(counts, mode)` が `合格 / 条件付合格 / 不合格` を返す。

## Step 7: 全モード一括実行 (`--mode all`)

テスト計画書 + テスト仕様書 + 不具合管理表 + 検収依頼書 + 検収完了書 (テンプレ) を一括生成。

## 業種別カスタマイズ (soloptilink-japan 連携)

`--industry` 指定時、`~/.claude/skills/soloptilink-japan/domains/<industry>.json` を読み込み、業種固有の:

- **テストカテゴリ強化**: 医療→3省2GL / 介護→LIFE連携 / 公共→改ざん検知
- **必須シナリオ**: 建設→工事台帳 / 製造→MRP / 不動産→35条書面
- **法令テスト**: インボイス / 電帳法 / 個情法 / マイナンバー法 / 下請法

## 出力フォーマット

| 種類 | フォーマット | 用途 |
|------|------------|------|
| テスト計画書 | .docx + .md | 顧客への説明 / 押印 |
| テスト仕様書 | .xlsx + .md | テスター実施 / 結果記入 |
| 不具合管理表 | .xlsx | プロジェクト管理 / 集計 |
| バグ票 (個別) | .docx + .md | 起票時テンプレ |
| 検収依頼書 | .docx | 提出 / 押印 |
| 検収完了書 | .docx | 受領 / 押印 |

## 出力配置

デフォルト: `<カレントディレクトリ>/docs/acceptance/`

- `01_test_plan.docx`
- `02_test_spec.xlsx`
- `03_bug_tracker.xlsx`
- `04_acceptance_request.docx`
- `05_acceptance_completion.docx`
- `metadata.json` (生成パラメータ + 合格基準モード)

## 引数の解釈

| 引数 | 動作 |
|------|------|
| 引数なし | インタラクティブモード (案件情報を確認) |
| ディレクトリパス | `.soloptilink-rfp-session.json` を読み込み |
| `--mode plan` | テスト計画書のみ |
| `--mode spec` | テスト仕様書のみ |
| `--mode bug-report` | 不具合管理表のみ |
| `--mode completion` | 検収依頼書 + 完了書 |
| `--mode all` (デフォルト) | フルセット生成 |
| `--criteria standard|strict|public-sector` | 合格基準モード |
| `--industry <業種>` | 業種固有カスタマイズ |
| `--warranty-months 6` | 瑕疵担保期間 (デフォルト 6ヶ月) |
| `--client-type 民間|公共|自治体` | クライアント種別 |
| `--locale ja|en` | 言語選択 |

## 使用例

```
/soloptilink-acceptance 工事原価管理システム --mode all --industry 建設 --criteria standard --warranty-months 6

/soloptilink-acceptance ./project_dir --mode plan --client-type 公共 --criteria public-sector --warranty-months 24

/soloptilink-acceptance --mode spec --industry 医療 --criteria strict (医療業界の厳格なテスト仕様書)

/soloptilink-acceptance --mode completion --warranty-months 12 (検収完了書 + 1年瑕疵担保)
```

## 統合スキル

- `/soloptilink-rfp`: RFP→提案→契約 (本スキルの前段)
- `/soloptilink-japan`: 業種辞書 / 法令DNA / 帳票テンプレ
- `/soloptilink-handoff`: 運用引継ぎ (本スキルの次段)
- `anthropic-skills:docx`: .docx 生成エンジン
- `anthropic-skills:xlsx`: .xlsx テスト仕様書 / 不具合管理表

## セッション継続ルール

このスキル起動後、`.soloptilink-acceptance-session.json` がプロジェクトに作成され、以降の会話で:

- 「P2不具合を再集計して」→ 既存不具合管理を再評価
- 「合格基準を strict に変更」→ 合格判定を再実行
- 「瑕疵担保を12ヶ月に延長」→ 検収完了書を再生成

として継続的に操作可能。

## 重要法令 (再掲)

- **民法 636 条**: 請負人の担保責任 (請負契約の契約不適合)
- **民法 562 条**: 買主の追完請求権 (売買・請負共通)
- **民法 637 条**: 期間制限 (1年以内通知)
- **会計法 29 条の3**: 一般競争入札の検査義務 (公共調達)
- **下請法 4 条 2 項 4 号**: 検収後60日以内支払 (親事業者の遅延支払禁止)
- **個情法 23 条**: 第三者提供制限 (テストデータの取扱注意)
