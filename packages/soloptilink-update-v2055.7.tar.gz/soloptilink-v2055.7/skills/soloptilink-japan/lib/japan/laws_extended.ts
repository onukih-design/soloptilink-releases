/**
 * SoloptiLinkAI JAPAN-NATIVE Mode - 拡張法令DNA Library (v2015.4 Phase 6)
 *
 * 既存 laws.ts (8法令) を補完する +12 法令。合計 20 法令。
 *
 *   9.  PL法 (製造物責任法)
 *   10. 景品表示法 (景表法)
 *   11. 特定商取引法 (特商法)
 *   12. 食品衛生法
 *   13. 食品表示法
 *   14. 薬機法 (旧 薬事法)
 *   15. 旅館業法
 *   16. 宅地建物取引業法 (宅建業法)
 *   17. 児童福祉法
 *   18. 労働安全衛生法 (安衛法)
 *   19. 育児介護休業法 (育介法)
 *   20. 労働者派遣法
 *
 * 使い方:
 *   import { PL, KeihyoHo, TokushoHo, FoodSanitation, FoodLabeling, Yakkiho,
 *            RyokanGyo, TakkenGyo, JidoFukushi, AnzenEisei, IkujiKaigo, HakenHou } from './laws_extended';
 */

// =============================================================================
// 9. PL法 (製造物責任法)
// =============================================================================
export const PL = {
  /**
   * 製造業者等への責任が問われる「製造物」の判定。
   * 加工/非加工の動産が対象。不動産・電気は原則対象外。
   */
  isProductLiable(item: { type: 'movable' | 'realestate' | 'electricity' | 'service'; processed?: boolean }): boolean {
    if (item.type !== 'movable') return false;
    return true;
  },

  /**
   * 時効期間: 損害および加害者を知った時から3年、製造物を引き渡した時から10年。
   */
  limitationPeriod(): { knowledge_years: 3; absolute_years: 10 } {
    return { knowledge_years: 3, absolute_years: 10 };
  },

  /**
   * 表示義務 (取扱説明書等)
   */
  requiredLabels(): string[] {
    return ['製造業者氏名・住所', '製造年月日', '使用上の注意', '警告表示 (危険箇所)', 'PL適合マーク (任意)'];
  },
};

// =============================================================================
// 10. 景品表示法 (景表法)
// =============================================================================
export const KeihyoHo = {
  /**
   * 一般懸賞の景品上限額計算。
   * 取引価額 5000円未満: 取引価額の20倍まで、最高 10万円
   * 取引価額 5000円以上: 一律 10万円
   */
  maxPrizeAmount(transactionAmount: number): number {
    if (transactionAmount < 5000) return Math.min(transactionAmount * 20, 100000);
    return 100000;
  },

  /**
   * 共同懸賞: 取引価額に関わらず最高 30万円
   */
  maxJointPrizeAmount(): number {
    return 300000;
  },

  /**
   * 総付景品の上限額。
   * 取引価額 1000円未満: 200円
   * 取引価額 1000円以上: 取引価額の2/10
   */
  maxBundledPrize(transactionAmount: number): number {
    if (transactionAmount < 1000) return 200;
    return Math.floor(transactionAmount * 0.2);
  },

  /**
   * 不当表示の3類型
   */
  unfairDisplayTypes(): string[] {
    return ['優良誤認表示', '有利誤認表示', 'その他誤認させるおそれのある表示'];
  },

  /**
   * 二重価格表示が許される条件
   */
  isDualPriceAllowed(comparison: { type: 'past_self' | 'competitor' | 'manufacturer_suggested'; basisDays: number; isCurrentlyShownClearly: boolean }): boolean {
    if (!comparison.isCurrentlyShownClearly) return false;
    if (comparison.type === 'past_self' && comparison.basisDays < 8) return false;
    return true;
  },
};

// =============================================================================
// 11. 特定商取引法 (特商法)
// =============================================================================
export const TokushoHo = {
  /**
   * クーリングオフ期間 (取引類型別)
   */
  coolingOffPeriod(transactionType: 'door_to_door' | 'tel_marketing' | 'mail_order' | 'multi_level' | 'specified_continuous' | 'business_opportunity'): number {
    switch (transactionType) {
      case 'door_to_door':
      case 'tel_marketing':
      case 'specified_continuous':
        return 8;
      case 'multi_level':
      case 'business_opportunity':
        return 20;
      case 'mail_order':
        return 0;
      default:
        return 0;
    }
  },

  /**
   * 通信販売の表示義務 (特定商取引法に基づく表記)
   */
  mailOrderRequiredFields(): string[] {
    return [
      '販売価格',
      '送料その他の負担金',
      '代金支払時期と方法',
      '商品引渡時期',
      '返品特約 (有無・条件)',
      '事業者の氏名・住所・電話番号',
      '事業者の代表者氏名',
      'お問い合わせ窓口',
    ];
  },

  /**
   * 不実告知/事実不告知に該当するか
   */
  isMisrepresentation(claim: string, reality: string): boolean {
    return claim !== reality;
  },
};

// =============================================================================
// 12. 食品衛生法
// =============================================================================
export const FoodSanitation = {
  /**
   * HACCP導入義務対象事業者か
   */
  requiresHACCP(business: { isFoodBusiness: boolean; smallScale: boolean }): boolean {
    return business.isFoodBusiness;
  },

  /**
   * 営業許可業種 (32業種) の例
   */
  permitRequiredCategories(): string[] {
    return [
      '飲食店営業', '調理の機能を有する自動販売機', '食肉販売業', '魚介類販売業',
      'コップ式自動販売機', '集乳業', '乳処理業', '特別牛乳搾取処理業', '食肉処理業',
      '食品の放射線照射業', '菓子製造業', 'アイスクリーム類製造業', '乳製品製造業',
      '清涼飲料水製造業', '食肉製品製造業', '水産製品製造業', '氷雪製造業',
      '液卵製造業', '食用油脂製造業', 'みそ又はしょうゆ製造業', '酒類製造業',
      '豆腐製造業', '納豆製造業', '麺類製造業', 'そうざい製造業', '冷凍食品製造業',
      '漬物製造業', '密封包装食品製造業', '食品の小分け業', '添加物製造業',
    ];
  },

  /**
   * 食中毒発生時の届出義務 (24時間以内)
   */
  poisoningReportDeadlineHours(): 24 {
    return 24;
  },
};

// =============================================================================
// 13. 食品表示法
// =============================================================================
export const FoodLabeling = {
  /**
   * 加工食品の必須表示項目
   */
  processedFoodRequiredFields(): string[] {
    return [
      '名称', '原材料名', '添加物', '原料原産地名', '内容量',
      '消費期限または賞味期限', '保存方法', '原産国名 (輸入品)',
      '製造者氏名・住所', '栄養成分表示',
    ];
  },

  /**
   * アレルゲン特定原材料 (8品目) - 表示義務
   */
  mandatoryAllergens(): string[] {
    return ['えび', 'かに', 'くるみ', '小麦', 'そば', '卵', '乳', '落花生'];
  },

  /**
   * アレルゲン特定原材料に準ずるもの (20品目) - 表示推奨
   */
  recommendedAllergens(): string[] {
    return [
      'アーモンド', 'あわび', 'いか', 'いくら', 'オレンジ', 'カシューナッツ',
      'キウイフルーツ', '牛肉', 'ごま', 'さけ', 'さば', '大豆', '鶏肉',
      'バナナ', '豚肉', 'まつたけ', 'もも', 'やまいも', 'りんご', 'ゼラチン',
    ];
  },

  /**
   * 栄養成分表示の義務項目 (5項目)
   */
  mandatoryNutritionItems(): string[] {
    return ['熱量', 'たんぱく質', '脂質', '炭水化物', '食塩相当量'];
  },
};

// =============================================================================
// 14. 薬機法 (旧 薬事法)
// =============================================================================
export const Yakkiho = {
  /**
   * 化粧品の効能効果 56 範囲のうち、広告でうたって良い表現か
   */
  isAllowedCosmeticClaim(claim: string): boolean {
    const allowedKeywords = [
      '汚れを落とす', '清浄にする', '皮膚を保護', '肌のキメを整える',
      '皮膚をなめらかにする', '日焼けによるシミ・ソバカスを防ぐ',
    ];
    return allowedKeywords.some(k => claim.includes(k));
  },

  /**
   * 医薬品的な効能効果の表現 (薬機法違反となる典型例)
   */
  forbiddenMedicalClaims(): string[] {
    return [
      '治る', '治療', '効く', '改善', '予防', '回復',
      '〜病に効果', '医師推奨', '副作用なし', '即効性',
    ];
  },

  /**
   * 一般用医薬品の区分
   */
  otcCategories(): Array<{ category: string; risk: string; sellRequirement: string }> {
    return [
      { category: '第1類医薬品', risk: '特に注意が必要', sellRequirement: '薬剤師の対面販売' },
      { category: '第2類医薬品', risk: 'リスクが比較的高い', sellRequirement: '薬剤師または登録販売者' },
      { category: '指定第2類医薬品', risk: '第2類のうち特に注意', sellRequirement: '薬剤師または登録販売者 + 確認' },
      { category: '第3類医薬品', risk: '比較的リスクが低い', sellRequirement: '薬剤師または登録販売者' },
    ];
  },
};

// =============================================================================
// 15. 旅館業法
// =============================================================================
export const RyokanGyo = {
  /**
   * 営業形態の区分
   */
  businessTypes(): string[] {
    return ['旅館・ホテル営業', '簡易宿所営業', '下宿営業'];
  },

  /**
   * 宿泊者名簿の記載義務項目
   */
  guestRegisterFields(): string[] {
    return ['氏名', '住所', '職業', '宿泊日'];
  },

  /**
   * 外国人宿泊者の追加記載義務
   */
  foreignGuestExtraFields(): string[] {
    return ['国籍', '旅券番号'];
  },

  /**
   * 名簿保存期間 (3年)
   */
  registerRetentionYears(): 3 {
    return 3;
  },

  /**
   * 民泊 (住宅宿泊事業法) との区別: 年間営業日数 180 日以下
   */
  isMinpaku(annualBusinessDays: number): boolean {
    return annualBusinessDays <= 180;
  },
};

// =============================================================================
// 16. 宅地建物取引業法 (宅建業法)
// =============================================================================
export const TakkenGyo = {
  /**
   * 重要事項説明の記載必須項目 (一部抜粋)
   */
  importantMatterFields(): string[] {
    return [
      '対象物件の表示', '登記事項', '法令上の制限', '私道負担',
      '飲用水・電気・ガス供給と排水施設', '完成時の形状・構造',
      '代金以外の授受金銭', '契約解除', '損害賠償額予定・違約金',
      '手付金等の保全措置', '支払金・預り金の保全措置',
      'ローンあっせんの内容と不成立時の措置', '瑕疵担保責任 (契約不適合責任)',
      '建物状況調査の結果概要', 'アスベスト調査結果',
    ];
  },

  /**
   * 媒介契約の3種類
   */
  brokerageTypes(): Array<{ type: string; canMultipleBrokers: boolean; mustReport: string }> {
    return [
      { type: '一般媒介契約', canMultipleBrokers: true, mustReport: '法令上の義務なし' },
      { type: '専任媒介契約', canMultipleBrokers: false, mustReport: '2週間に1回以上' },
      { type: '専属専任媒介契約', canMultipleBrokers: false, mustReport: '1週間に1回以上' },
    ];
  },

  /**
   * 報酬上限の計算 (200万円以下: 5%, 200〜400万円: 4%+2万, 400万円超: 3%+6万)
   */
  maxBrokerageFee(salePrice: number): number {
    if (salePrice <= 2_000_000) return Math.floor(salePrice * 0.05);
    if (salePrice <= 4_000_000) return Math.floor(salePrice * 0.04 + 20_000);
    return Math.floor(salePrice * 0.03 + 60_000);
  },
};

// =============================================================================
// 17. 児童福祉法
// =============================================================================
export const JidoFukushi = {
  /**
   * 保育士の配置基準 (児童 N人 : 保育士 1人)
   */
  staffRatio(ageMonths: number): number {
    if (ageMonths < 12) return 3;
    if (ageMonths < 24) return 6;
    if (ageMonths < 36) return 6;
    if (ageMonths < 48) return 20;
    return 30;
  },

  /**
   * 児童虐待 (4類型)
   */
  abuseTypes(): string[] {
    return ['身体的虐待', '性的虐待', 'ネグレクト', '心理的虐待'];
  },

  /**
   * 通告義務: 児童虐待を発見した者は速やかに市町村等に通告
   */
  reportingObligation(): { applies_to: 'all_persons'; deadline: 'without_delay' } {
    return { applies_to: 'all_persons', deadline: 'without_delay' };
  },
};

// =============================================================================
// 18. 労働安全衛生法 (安衛法)
// =============================================================================
export const AnzenEisei = {
  /**
   * 産業医選任義務: 50人以上の事業場
   */
  requiresOccupationalPhysician(workerCount: number): boolean {
    return workerCount >= 50;
  },

  /**
   * ストレスチェック実施義務: 50人以上
   */
  requiresStressCheck(workerCount: number): boolean {
    return workerCount >= 50;
  },

  /**
   * 安全管理者選任業種
   */
  safetyManagerRequiredIndustries(): string[] {
    return ['製造業', '建設業', '運輸業', '鉱業', '電気業', 'ガス業', '熱供給業',
            '通信業', '各種商品卸売業', '家具・建具・じゅう器等卸売業',
            '各種商品小売業', '家具・建具・じゅう器小売業', '燃料小売業',
            '旅館業', 'ゴルフ場業', '自動車整備業', '機械修理業'];
  },

  /**
   * 健康診断の実施頻度: 一般定期健康診断は1年に1回
   */
  generalHealthCheckFrequency(): { perYear: 1 } {
    return { perYear: 1 };
  },
};

// =============================================================================
// 19. 育児介護休業法 (育介法)
// =============================================================================
export const IkujiKaigo = {
  /**
   * 育児休業: 子が1歳に達するまで (一定要件で2歳まで延長可)
   */
  childcareLeaveDefaultMaxAgeMonths(): 12 {
    return 12;
  },

  /**
   * 出生時育児休業 (産後パパ育休): 出生後8週間以内に4週間まで
   */
  postBirthLeaveMaxDays(): 28 {
    return 28;
  },

  /**
   * 介護休業: 対象家族1人につき通算93日まで、3回まで分割可
   */
  caregiverLeaveMaxDays(): 93 {
    return 93;
  },

  /**
   * 子の看護休暇: 小学校就学前まで、1年に5日 (子が2人以上は10日)
   */
  childCareDaysPerYear(numberOfChildren: number): number {
    return Math.min(numberOfChildren, 2) * 5;
  },
};

// =============================================================================
// 20. 労働者派遣法
// =============================================================================
export const HakenHou = {
  /**
   * 派遣禁止業務
   */
  prohibitedJobs(): string[] {
    return ['港湾運送業務', '建設業務', '警備業務', '医療関連業務 (一部例外あり)', '弁護士・社労士等の士業'];
  },

  /**
   * 同一の派遣先への派遣可能期間 (個人単位): 3年
   */
  individualMaxYears(): 3 {
    return 3;
  },

  /**
   * 同一の派遣先事業所単位の派遣可能期間: 3年 (過半数組合の意見聴取で延長可)
   */
  workplaceMaxYears(): 3 {
    return 3;
  },

  /**
   * 同一労働同一賃金: 派遣先均等均衡方式 or 労使協定方式
   */
  equalPayMethods(): string[] {
    return ['派遣先均等・均衡方式', '労使協定方式'];
  },
};

// =============================================================================
// 統合判定: 業種から拡張法令を推定 (laws.ts の recommendLaws と併用)
// =============================================================================
/**
 * 業種キーから拡張法令を返す。
 *
 * 【引数は「正規化済みの分岐キー」であって業種辞書の名前ではない】
 *   業種辞書の名前 (kebab-case の具体名: beauty-salon / hotel-ryokan …) は
 *   laws.ts の normalizeIndustryKey() が分岐キーへ寄せる。対応表は laws.ts の
 *   1 箇所だけが持つ (2 箇所に置くと片方だけが古くなる)。
 *   本関数を直接呼ぶ場合は、先に normalizeIndustryKey() を通すこと。
 *   通さずに辞書の名前で呼ぶと、下の分岐に当たらず 0 件が返る。
 *
 * 【★2026-08-14 実測で直した欠陥 — 「分岐は在るのに一度も発火しない」】
 *   分岐は 15 件あるのに、114 業種を全通しで呼んで実際に発火したのは 6 件だけだった。
 *   下記の「到達する業種名」に印を付けてある 9 件は、その分岐名に寄せる業種名が
 *   対応表に無かったために **一度も発火しない死んだ分岐** で、美容室・不動産・宿泊・
 *   保育・学童・広告・物流・運送・IT では、その業種でいちばん外せない業法が
 *   生成物の「該当法令」から丸ごと落ちていた。
 *   是正は laws.ts の INDUSTRY_KEY_ALIASES への追加で行い、本関数の返す法令は
 *   1 件も変えていない (法令の中身は一次情報に基づく別の判断であるため)。
 *
 * 【この一覧を更新するときの規律】
 *   分岐を足す/変えるときは、その分岐へ到達する業種名を必ず対応表にも足すこと。
 *   足さないと、実装だけが増えて誰にも届かない分岐がまた生まれる。
 *   発火状況は 114 業種を全通しで呼んで数える (分岐の本数を数えても分からない)。
 */
export function recommendExtendedLaws(industry: string): string[] {
  // 到達する業種名 (2026-08-14 実測。左が業種辞書の名前、右が下の分岐キー)
  //   construction        → construction          (辞書の名前がそのまま分岐キー)
  //   printing            → manufacturing         (対応表)
  //   food-service        → food_service          (対応表)
  //   healthcare          → healthcare            (辞書の名前がそのまま分岐キー)
  //   retail-pos          → retail                (対応表)
  //   bridal              → bridal                (辞書の名前がそのまま分岐キー)
  //   beauty-salon        → beauty          ★2026-08-14 に到達 (それ以前は死に分岐)
  //   real-estate         → real_estate     ★同上
  //   hotel-ryokan        → hotel           ★同上
  //   nursery-school      → childcare       ★同上
  //   after-school-care   → education       ★同上
  //   sns-marketing-agency→ advertising     ★同上
  //   logistics-trucking  → logistics       ★同上
  //   trucking-transport  → transport       ★同上
  //   project-management  → it              ★同上
  switch (industry) {
    case 'construction':
      // 建設業の労働・環境・周辺法令. コア12法は laws.ts の recommendLaws('construction') に集約 (消防法は H3 でコア移動).
      return [
        '労働安全衛生法',
        '労働安全衛生規則第88条', // H2: 機械等設置届 (足場高さ10m以上60日以上/型枠支保工) と 建設工事計画届 (高さ31m超建物/掘削深10m以上)
        '廃棄物処理法',
        '大気汚染防止法', // 石綿飛散防止 (アスベスト事前調査結果報告制度)
        '労働者派遣法', // 建設業務労働者派遣事業は原則禁止 (適正な請負区分)
        '電気事業法',
        '水道法',
        'ガス事業法', // 建設現場のガス管接続
        '道路法', // 道路占用許可 (仮設・足場が公道に張り出す時)
      ];
    case 'manufacturing':
      return ['PL法', '労働安全衛生法'];
    case 'food_service':
      return ['食品衛生法', '食品表示法', 'PL法'];
    case 'healthcare':
      return ['薬機法', '労働安全衛生法'];
    case 'beauty':
      return ['薬機法', '景品表示法'];
    case 'real_estate':
      return ['宅地建物取引業法'];
    case 'hotel':
    case 'bridal':
      return ['旅館業法', '食品衛生法'];
    case 'childcare':
    case 'education':
      return ['児童福祉法'];
    case 'retail':
      return ['景品表示法', '特定商取引法', 'PL法'];
    case 'advertising':
      return ['景品表示法', '薬機法'];
    case 'logistics':
    case 'transport':
      return ['労働安全衛生法'];
    case 'it':
      return ['労働者派遣法'];
    default:
      return [];
  }
}
