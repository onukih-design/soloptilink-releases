#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v17.0 - E2E Pipeline Module
# =============================================================================
# 生成されたシステムを実際に起動し、DB接続 -> API呼び出し -> 画面操作 ->
# データ検証の自動E2Eテストを実行する。特にデータ整合性（CRUD -> 検証 ->
# 削除 -> 確認）のシナリオテストを自動生成・実行する。
#
# v17.0 機能:
#   1. プロジェクトの設計書/API定義からE2Eシナリオを自動生成
#   2. CRUD完全ライフサイクルテスト (Create->Read->Update->Delete->Verify)
#   3. 認証フローテスト (登録->ログイン->アクセス->ログアウト->未認証拒否)
#   4. データ整合性テスト (外部キー制約・カスケード・楽観的ロック)
#   5. 監査ログ完全性テスト
#   6. エラーハンドリングテスト (不正入力->バリデーション->回復)
#   7. Docker Compose / 直接起動によるサービスオーケストレーション
#   8. Playwright/supertest テストコード自動生成 (Claude CLI連携)
#   9. タイムアウト付きリトライ実行・結果レポート生成
#
# Usage: source lib/e2e-pipeline.sh
# =============================================================================

# --- Load guard --------------------------------------------------------------
[[ -n "${_E2E_PIPELINE_LOADED:-}" ]] && return 0
_E2E_PIPELINE_LOADED=1

# --- Colour constants (E2E_ prefix) -----------------------------------------
E2E_GREEN='\033[0;32m'   E2E_YELLOW='\033[0;33m'  E2E_RED='\033[0;31m'
E2E_CYAN='\033[0;36m'    E2E_PURPLE='\033[0;35m'  E2E_BOLD='\033[1m'
E2E_DIM='\033[2m'        E2E_NC='\033[0m'

# --- Global state (E2E_ prefix) ---------------------------------------------
E2E_VERSION="17.0"
E2E_ENABLED=true
E2E_REPORT_DIR=""
E2E_LOG_FILE=""
E2E_TIMEOUT=120          # 各シナリオのタイムアウト(秒)
E2E_MAX_RETRIES=3        # シナリオ失敗時のリトライ回数
E2E_PARALLEL=false       # 並列シナリオ実行フラグ
E2E_SCENARIOS_PASSED=0
E2E_SCENARIOS_FAILED=0
E2E_SCENARIOS_SKIPPED=0
E2E_SCENARIOS_TOTAL=0
E2E_START_TIME=0

# サービス管理
E2E_PROJECT_DIR=""
E2E_PROJECT_TYPE=""      # node | python | go | unknown
E2E_SERVICE_PIDS=""      # スペース区切りの起動済みPID
E2E_DB_TYPE=""           # postgres | mysql | sqlite | mongo | none
E2E_API_PORT=""
E2E_FRONTEND_PORT=""
E2E_USE_DOCKER=false

# テスト結果
E2E_RESULTS_JSON=""      # 改行区切りのJSONエントリ
E2E_FAILURE_DETAILS=""   # 失敗シナリオの詳細

# Claude CLI タイムアウト
E2E_CLAUDE_TIMEOUT="${E2E_CLAUDE_TIMEOUT:-180}"

# =============================================================================
# 内部ヘルパー関数
# =============================================================================

# --- ログ出力 ----------------------------------------------------------------
_e2e_log() {
    local level="$1" msg="$2"
    local color="${E2E_NC}"
    case "$level" in
        PASS|SUCCESS) color="${E2E_GREEN}" ;;
        FAIL|ERROR)   color="${E2E_RED}" ;;
        WARN)         color="${E2E_YELLOW}" ;;
        INFO|STEP)    color="${E2E_CYAN}" ;;
        SECTION)      color="${E2E_PURPLE}" ;;
    esac
    echo -e "  ${color}[E2E:${level}]${E2E_NC} ${msg}"
    if [[ -n "$E2E_LOG_FILE" ]]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${level}] ${msg}" >> "$E2E_LOG_FILE" 2>/dev/null || true
    fi
}

# --- JSON エントリ追加 -------------------------------------------------------
_e2e_json_add() {
    local entry="$1"
    if [[ -z "$E2E_RESULTS_JSON" ]]; then
        E2E_RESULTS_JSON="$entry"
    else
        E2E_RESULTS_JSON="${E2E_RESULTS_JSON}
${entry}"
    fi
}

# --- Claude CLI 呼び出し ----------------------------------------------------
_e2e_call_claude() {
    local prompt="$1"
    claude -p --dangerously-skip-permissions --output-format text "$prompt" 2>/dev/null
}

# --- ポート待機 --------------------------------------------------------------
_e2e_wait_for_port() {
    local port="$1" timeout="${2:-30}" i=0
    _e2e_log INFO "Waiting for port ${port} (max ${timeout}s)..."
    while (( i < timeout )); do
        if command -v nc &>/dev/null; then
            nc -z localhost "$port" 2>/dev/null && {
                _e2e_log PASS "Port ${port} ready"
                return 0
            }
        elif curl -s -o /dev/null "http://localhost:${port}" 2>/dev/null; then
            _e2e_log PASS "Port ${port} ready"
            return 0
        fi
        sleep 1
        (( i++ ))
    done
    _e2e_log FAIL "Port ${port} not ready after ${timeout}s"
    return 1
}

# --- ポート使用確認 ----------------------------------------------------------
_e2e_is_port_in_use() {
    local port="$1"
    if command -v lsof &>/dev/null; then
        lsof -iTCP:"$port" -sTCP:LISTEN &>/dev/null && return 0
    elif command -v ss &>/dev/null; then
        ss -tlnp 2>/dev/null | grep -q ":${port} " && return 0
    elif command -v nc &>/dev/null; then
        nc -z localhost "$port" 2>/dev/null && return 0
    fi
    return 1
}

# --- ソースファイル検索 ------------------------------------------------------
_e2e_find_sources() {
    local pd="$1" pattern="${2:-}"
    find "$pd" -type f \( -name '*.js' -o -name '*.ts' -o -name '*.tsx' -o -name '*.jsx' \
        -o -name '*.py' -o -name '*.go' -o -name '*.rb' -o -name '*.php' \) \
        ! -path '*/node_modules/*' ! -path '*/.git/*' ! -path '*/dist/*' \
        ! -path '*/build/*' ! -path '*/.next/*' ! -path '*/vendor/*' \
        ! -path '*/__pycache__/*' ! -path '*/.venv/*' 2>/dev/null
}

# --- サービス構成検出 --------------------------------------------------------
_e2e_detect_services() {
    local pd="$1"
    E2E_PROJECT_TYPE="unknown"
    E2E_DB_TYPE="none"
    E2E_API_PORT=""
    E2E_FRONTEND_PORT=""
    E2E_USE_DOCKER=false

    # Docker Compose 検出
    if [[ -f "${pd}/docker-compose.yml" || -f "${pd}/docker-compose.yaml" || -f "${pd}/compose.yml" ]]; then
        E2E_USE_DOCKER=true
        _e2e_log INFO "Docker Compose detected"
    fi

    # プロジェクトタイプ検出
    if [[ -f "${pd}/package.json" ]]; then
        E2E_PROJECT_TYPE="node"
        E2E_API_PORT="${E2E_API_PORT:-3000}"
        # Next.js / Express / Fastify 判定
        if grep -q '"next"' "${pd}/package.json" 2>/dev/null; then
            E2E_PROJECT_TYPE="nextjs"
            E2E_FRONTEND_PORT="${E2E_FRONTEND_PORT:-3000}"
        fi
        if grep -q '"express"' "${pd}/package.json" 2>/dev/null; then
            E2E_PROJECT_TYPE="express"
        fi
    fi
    if [[ -f "${pd}/requirements.txt" || -f "${pd}/pyproject.toml" ]]; then
        E2E_PROJECT_TYPE="python"
        E2E_API_PORT="${E2E_API_PORT:-8000}"
    fi
    if [[ -f "${pd}/go.mod" ]]; then
        E2E_PROJECT_TYPE="go"
        E2E_API_PORT="${E2E_API_PORT:-8080}"
    fi

    # DB タイプ検出
    if [[ -f "${pd}/prisma/schema.prisma" ]]; then
        if grep -qi 'postgresql' "${pd}/prisma/schema.prisma" 2>/dev/null; then
            E2E_DB_TYPE="postgres"
        elif grep -qi 'mysql' "${pd}/prisma/schema.prisma" 2>/dev/null; then
            E2E_DB_TYPE="mysql"
        elif grep -qi 'sqlite' "${pd}/prisma/schema.prisma" 2>/dev/null; then
            E2E_DB_TYPE="sqlite"
        fi
    elif grep -rq 'mongoose\|mongodb' "${pd}/package.json" 2>/dev/null; then
        E2E_DB_TYPE="mongo"
    elif grep -rq 'pg\|postgres' "${pd}/package.json" 2>/dev/null; then
        E2E_DB_TYPE="postgres"
    elif [[ -f "${pd}/requirements.txt" ]] && grep -qi 'psycopg\|asyncpg' "${pd}/requirements.txt" 2>/dev/null; then
        E2E_DB_TYPE="postgres"
    fi

    _e2e_log INFO "Project: ${E2E_PROJECT_TYPE} | DB: ${E2E_DB_TYPE} | Docker: ${E2E_USE_DOCKER}"
    _e2e_log INFO "API port: ${E2E_API_PORT:-auto} | Frontend port: ${E2E_FRONTEND_PORT:-none}"
}

# --- ヘルスチェック待機 ------------------------------------------------------
_e2e_wait_for_health() {
    local url="$1" timeout="${2:-60}" i=0
    _e2e_log INFO "Health check: ${url} (max ${timeout}s)..."
    while (( i < timeout )); do
        local status
        status=$(curl -s -o /dev/null -w '%{http_code}' "$url" 2>/dev/null) || true
        if [[ "$status" =~ ^(200|201|204|301|302|304)$ ]]; then
            _e2e_log PASS "Health check passed: ${url} (HTTP ${status})"
            return 0
        fi
        sleep 2
        (( i += 2 ))
    done
    _e2e_log FAIL "Health check failed: ${url} after ${timeout}s"
    return 1
}

# --- テストデータクリーンアップ ----------------------------------------------
_e2e_cleanup_test_data() {
    local pd="$1"
    _e2e_log INFO "Cleaning up test data..."

    # テスト用DBのリセット (環境変数でテストDB切り替えを想定)
    if [[ -f "${pd}/prisma/schema.prisma" ]]; then
        (cd "$pd" && npx prisma migrate reset --force 2>/dev/null) || true
    fi

    # テスト用一時ファイルの削除
    rm -rf "${pd}/tests/e2e/tmp" 2>/dev/null || true
    rm -rf "${pd}/tests/e2e/.test-data" 2>/dev/null || true

    _e2e_log PASS "Test data cleanup complete"
}

# --- カウンタリセット --------------------------------------------------------
_e2e_reset_counters() {
    E2E_SCENARIOS_PASSED=0
    E2E_SCENARIOS_FAILED=0
    E2E_SCENARIOS_SKIPPED=0
    E2E_SCENARIOS_TOTAL=0
    E2E_RESULTS_JSON=""
    E2E_FAILURE_DETAILS=""
    E2E_SERVICE_PIDS=""
    E2E_START_TIME=$(date +%s)
}

# =============================================================================
# 公開API: 初期化
# =============================================================================
e2e_init() {
    local project_dir="${1:-.}"
    project_dir="$(cd "$project_dir" 2>/dev/null && pwd)" || {
        _e2e_log ERROR "Directory not found: $1"
        return 1
    }

    E2E_PROJECT_DIR="$project_dir"
    E2E_REPORT_DIR="${project_dir}/docs/chain-logs/e2e"
    E2E_LOG_FILE="${E2E_REPORT_DIR}/e2e_$(date +%Y%m%d_%H%M%S).log"
    mkdir -p "$E2E_REPORT_DIR" 2>/dev/null || true
    mkdir -p "${project_dir}/tests/e2e" 2>/dev/null || true

    _e2e_reset_counters

    # サービス構成検出
    _e2e_detect_services "$project_dir"

    _e2e_log SECTION "=== E2E Pipeline v${E2E_VERSION} Initialized ==="
    _e2e_log INFO "Project: ${project_dir}"
    _e2e_log INFO "Report dir: ${E2E_REPORT_DIR}"
    _e2e_log INFO "Timeout: ${E2E_TIMEOUT}s | Max retries: ${E2E_MAX_RETRIES}"

    return 0
}

# =============================================================================
# 公開API: シナリオ自動生成
# =============================================================================
e2e_generate_scenarios() {
    local pd="${1:-$E2E_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { _e2e_log ERROR "Invalid project dir: ${pd}"; return 1; }

    local scenario_dir="${pd}/tests/e2e/scenarios"
    mkdir -p "$scenario_dir" 2>/dev/null

    _e2e_log SECTION "=== Generating E2E Scenarios ==="

    # プロジェクト構造の収集
    local project_context=""

    # Prisma スキーマ取得
    if [[ -f "${pd}/prisma/schema.prisma" ]]; then
        project_context+="--- PRISMA SCHEMA ---
$(head -200 "${pd}/prisma/schema.prisma" 2>/dev/null)
"
    fi

    # API ルート検出 (Next.js / Express / FastAPI)
    local api_files=""
    api_files=$(find "$pd" -type f \( -name 'route.ts' -o -name 'route.js' \
        -o -name '*.controller.ts' -o -name '*.controller.js' \
        -o -name '*.router.ts' -o -name '*.router.js' \
        -o -name '*.routes.ts' -o -name '*.routes.js' \
        -o -name 'urls.py' -o -name 'views.py' -o -name 'main.go' \) \
        ! -path '*/node_modules/*' ! -path '*/.git/*' ! -path '*/dist/*' \
        2>/dev/null | head -20)

    if [[ -n "$api_files" ]]; then
        project_context+="--- API ROUTES ---
"
        while IFS= read -r f; do
            project_context+="--- ${f#"$pd"/} ---
$(head -60 "$f" 2>/dev/null)
"
        done <<< "$api_files"
    fi

    # package.json の依存関係
    if [[ -f "${pd}/package.json" ]]; then
        project_context+="--- PACKAGE.JSON ---
$(head -80 "${pd}/package.json" 2>/dev/null)
"
    fi

    # requirements.txt
    if [[ -f "${pd}/requirements.txt" ]]; then
        project_context+="--- REQUIREMENTS.TXT ---
$(head -40 "${pd}/requirements.txt" 2>/dev/null)
"
    fi

    # 設計書の取得 (chain.shが生成するもの)
    local design_doc=""
    if [[ -d "${pd}/docs/chain-logs" ]]; then
        design_doc=$(find "${pd}/docs/chain-logs" -name '*design*' -o -name '*spec*' \
            2>/dev/null | head -3 | while IFS= read -r f; do
            head -100 "$f" 2>/dev/null
        done)
    fi
    if [[ -n "$design_doc" ]]; then
        project_context+="--- DESIGN DOCS ---
${design_doc}
"
    fi

    # Claude CLI でシナリオ生成
    _e2e_log INFO "Generating CRUD lifecycle scenario..."
    local crud_scenario
    crud_scenario=$(_e2e_call_claude "You are an E2E test scenario generator. Analyze this project and generate a JSON test scenario for CRUD lifecycle testing.

PROJECT CONTEXT:
${project_context}

Generate a JSON object with this structure:
{
  \"name\": \"crud_lifecycle\",
  \"type\": \"crud\",
  \"description\": \"CRUD complete lifecycle test\",
  \"steps\": [
    {\"action\": \"create\", \"endpoint\": \"/api/...\", \"method\": \"POST\", \"body\": {...}, \"expect_status\": 201},
    {\"action\": \"read\", \"endpoint\": \"/api/...\", \"method\": \"GET\", \"expect_status\": 200, \"expect_body\": {...}},
    {\"action\": \"update\", \"endpoint\": \"/api/...\", \"method\": \"PUT\", \"body\": {...}, \"expect_status\": 200},
    {\"action\": \"read_after_update\", \"endpoint\": \"/api/...\", \"method\": \"GET\", \"expect_status\": 200},
    {\"action\": \"delete\", \"endpoint\": \"/api/...\", \"method\": \"DELETE\", \"expect_status\": 200},
    {\"action\": \"verify_deleted\", \"endpoint\": \"/api/...\", \"method\": \"GET\", \"expect_status\": 404}
  ]
}

Output ONLY valid JSON. No markdown fences. No explanation.")

    if [[ -n "$crud_scenario" && ${#crud_scenario} -gt 50 ]]; then
        echo "$crud_scenario" | sed '/^```/d; /^json$/d' > "${scenario_dir}/01_crud_lifecycle.json"
        _e2e_log PASS "Generated: 01_crud_lifecycle.json"
    else
        _e2e_log WARN "CRUD scenario generation insufficient - writing default"
        _e2e_write_default_crud_scenario "$scenario_dir"
    fi

    # 認証フロー シナリオ
    _e2e_log INFO "Generating auth flow scenario..."
    local auth_scenario
    auth_scenario=$(_e2e_call_claude "You are an E2E test scenario generator. Generate a JSON test scenario for authentication flow testing.

PROJECT CONTEXT:
${project_context}

Generate a JSON object with this structure:
{
  \"name\": \"auth_flow\",
  \"type\": \"auth\",
  \"description\": \"Authentication flow test\",
  \"steps\": [
    {\"action\": \"register\", \"endpoint\": \"/api/auth/register\", \"method\": \"POST\", \"body\": {\"email\":\"test@e2e.local\",\"password\":\"Test1234!\"}, \"expect_status\": 201},
    {\"action\": \"login\", \"endpoint\": \"/api/auth/login\", \"method\": \"POST\", \"body\": {\"email\":\"test@e2e.local\",\"password\":\"Test1234!\"}, \"expect_status\": 200, \"save_token\": true},
    {\"action\": \"access_protected\", \"endpoint\": \"/api/me\", \"method\": \"GET\", \"use_token\": true, \"expect_status\": 200},
    {\"action\": \"logout\", \"endpoint\": \"/api/auth/logout\", \"method\": \"POST\", \"use_token\": true, \"expect_status\": 200},
    {\"action\": \"access_denied\", \"endpoint\": \"/api/me\", \"method\": \"GET\", \"use_token\": false, \"expect_status\": 401}
  ]
}

Output ONLY valid JSON. No markdown fences.")

    if [[ -n "$auth_scenario" && ${#auth_scenario} -gt 50 ]]; then
        echo "$auth_scenario" | sed '/^```/d; /^json$/d' > "${scenario_dir}/02_auth_flow.json"
        _e2e_log PASS "Generated: 02_auth_flow.json"
    else
        _e2e_log WARN "Auth scenario generation insufficient - writing default"
        _e2e_write_default_auth_scenario "$scenario_dir"
    fi

    # データ整合性 シナリオ
    _e2e_log INFO "Generating data integrity scenario..."
    local integrity_scenario
    integrity_scenario=$(_e2e_call_claude "You are an E2E test scenario generator. Generate a JSON test scenario for data integrity testing.

PROJECT CONTEXT:
${project_context}

Generate a JSON object testing:
1. Create parent record, then child records with foreign key references
2. Read and verify relationships are correct
3. Update parent and verify cascade behavior
4. Delete parent and verify cascade delete or constraint error
5. Concurrent update simulation (optimistic locking)

Structure:
{
  \"name\": \"data_integrity\",
  \"type\": \"integrity\",
  \"description\": \"Data integrity and referential consistency test\",
  \"steps\": [...]
}

Output ONLY valid JSON. No markdown fences.")

    if [[ -n "$integrity_scenario" && ${#integrity_scenario} -gt 50 ]]; then
        echo "$integrity_scenario" | sed '/^```/d; /^json$/d' > "${scenario_dir}/03_data_integrity.json"
        _e2e_log PASS "Generated: 03_data_integrity.json"
    else
        _e2e_log WARN "Integrity scenario generation insufficient - writing default"
        _e2e_write_default_integrity_scenario "$scenario_dir"
    fi

    # エラーハンドリング シナリオ
    _e2e_log INFO "Generating error handling scenario..."
    local error_scenario
    error_scenario=$(_e2e_call_claude "You are an E2E test scenario generator. Generate a JSON test scenario for error handling testing.

PROJECT CONTEXT:
${project_context}

Generate a JSON object testing:
1. Invalid input (missing required fields) -> expect 400/422
2. Duplicate entry -> expect 409
3. Non-existent resource -> expect 404
4. Malformed request body -> expect 400
5. Recovery: valid request after errors -> expect success

Structure:
{
  \"name\": \"error_handling\",
  \"type\": \"error\",
  \"description\": \"Error handling and validation test\",
  \"steps\": [...]
}

Output ONLY valid JSON. No markdown fences.")

    if [[ -n "$error_scenario" && ${#error_scenario} -gt 50 ]]; then
        echo "$error_scenario" | sed '/^```/d; /^json$/d' > "${scenario_dir}/04_error_handling.json"
        _e2e_log PASS "Generated: 04_error_handling.json"
    else
        _e2e_log WARN "Error handling scenario generation insufficient - writing default"
        _e2e_write_default_error_scenario "$scenario_dir"
    fi

    # 並行操作 シナリオ
    _e2e_log INFO "Generating concurrency scenario..."
    local concurrency_scenario
    concurrency_scenario=$(_e2e_call_claude "You are an E2E test scenario generator. Generate a JSON test scenario for concurrency testing.

PROJECT CONTEXT:
${project_context}

Generate a JSON object testing:
1. Create a resource
2. Simulate two concurrent PUT requests with different data
3. Verify only one succeeds or optimistic lock is enforced
4. Verify final state is consistent

Structure:
{
  \"name\": \"concurrency\",
  \"type\": \"concurrency\",
  \"description\": \"Concurrent access and optimistic locking test\",
  \"concurrent_steps\": [{\"parallel\": [step_a, step_b]}, ...],
  \"steps\": [...]
}

Output ONLY valid JSON. No markdown fences.")

    if [[ -n "$concurrency_scenario" && ${#concurrency_scenario} -gt 50 ]]; then
        echo "$concurrency_scenario" | sed '/^```/d; /^json$/d' > "${scenario_dir}/05_concurrency.json"
        _e2e_log PASS "Generated: 05_concurrency.json"
    else
        _e2e_log WARN "Concurrency scenario generation skipped"
    fi

    # 生成結果サマリ
    local generated_count
    generated_count=$(find "$scenario_dir" -name '*.json' 2>/dev/null | wc -l | tr -d ' ')
    _e2e_log PASS "Total scenarios generated: ${generated_count}"

    return 0
}

# --- デフォルトシナリオ書き込し (Claude生成失敗時のフォールバック) -----------
_e2e_write_default_crud_scenario() {
    local dir="$1"
    cat > "${dir}/01_crud_lifecycle.json" << 'CRUD_EOF'
{
  "name": "crud_lifecycle",
  "type": "crud",
  "description": "CRUD complete lifecycle test (default)",
  "steps": [
    {"action": "create", "endpoint": "/api/items", "method": "POST", "body": {"name": "Test Item", "description": "E2E test item"}, "expect_status": 201},
    {"action": "read", "endpoint": "/api/items/{id}", "method": "GET", "expect_status": 200},
    {"action": "update", "endpoint": "/api/items/{id}", "method": "PUT", "body": {"name": "Updated Item"}, "expect_status": 200},
    {"action": "read_after_update", "endpoint": "/api/items/{id}", "method": "GET", "expect_status": 200},
    {"action": "delete", "endpoint": "/api/items/{id}", "method": "DELETE", "expect_status": 200},
    {"action": "verify_deleted", "endpoint": "/api/items/{id}", "method": "GET", "expect_status": 404}
  ]
}
CRUD_EOF
}

_e2e_write_default_auth_scenario() {
    local dir="$1"
    cat > "${dir}/02_auth_flow.json" << 'AUTH_EOF'
{
  "name": "auth_flow",
  "type": "auth",
  "description": "Authentication flow test (default)",
  "steps": [
    {"action": "register", "endpoint": "/api/auth/register", "method": "POST", "body": {"email": "test@e2e.local", "password": "Test1234!"}, "expect_status": 201},
    {"action": "login", "endpoint": "/api/auth/login", "method": "POST", "body": {"email": "test@e2e.local", "password": "Test1234!"}, "expect_status": 200, "save_token": true},
    {"action": "access_protected", "endpoint": "/api/me", "method": "GET", "use_token": true, "expect_status": 200},
    {"action": "logout", "endpoint": "/api/auth/logout", "method": "POST", "use_token": true, "expect_status": 200},
    {"action": "access_denied", "endpoint": "/api/me", "method": "GET", "use_token": false, "expect_status": 401}
  ]
}
AUTH_EOF
}

_e2e_write_default_integrity_scenario() {
    local dir="$1"
    cat > "${dir}/03_data_integrity.json" << 'INTEG_EOF'
{
  "name": "data_integrity",
  "type": "integrity",
  "description": "Data integrity and referential consistency test (default)",
  "steps": [
    {"action": "create_parent", "endpoint": "/api/categories", "method": "POST", "body": {"name": "Test Category"}, "expect_status": 201},
    {"action": "create_child", "endpoint": "/api/items", "method": "POST", "body": {"name": "Child Item", "categoryId": "{parent_id}"}, "expect_status": 201},
    {"action": "verify_relation", "endpoint": "/api/categories/{parent_id}/items", "method": "GET", "expect_status": 200, "expect_count_gte": 1},
    {"action": "update_parent", "endpoint": "/api/categories/{parent_id}", "method": "PUT", "body": {"name": "Renamed Category"}, "expect_status": 200},
    {"action": "verify_child_intact", "endpoint": "/api/items/{child_id}", "method": "GET", "expect_status": 200},
    {"action": "delete_parent", "endpoint": "/api/categories/{parent_id}", "method": "DELETE", "expect_status": 200},
    {"action": "verify_cascade", "endpoint": "/api/items/{child_id}", "method": "GET", "expect_status": 404}
  ]
}
INTEG_EOF
}

_e2e_write_default_error_scenario() {
    local dir="$1"
    cat > "${dir}/04_error_handling.json" << 'ERR_EOF'
{
  "name": "error_handling",
  "type": "error",
  "description": "Error handling and validation test (default)",
  "steps": [
    {"action": "missing_field", "endpoint": "/api/items", "method": "POST", "body": {}, "expect_status": 400},
    {"action": "create_valid", "endpoint": "/api/items", "method": "POST", "body": {"name": "Unique Item"}, "expect_status": 201},
    {"action": "duplicate", "endpoint": "/api/items", "method": "POST", "body": {"name": "Unique Item"}, "expect_status": 409},
    {"action": "not_found", "endpoint": "/api/items/99999", "method": "GET", "expect_status": 404},
    {"action": "malformed", "endpoint": "/api/items", "method": "POST", "body": "not-json", "expect_status": 400},
    {"action": "recovery", "endpoint": "/api/items", "method": "POST", "body": {"name": "Recovery Item"}, "expect_status": 201}
  ]
}
ERR_EOF
}

# =============================================================================
# 公開API: シナリオからテストコード生成
# =============================================================================
e2e_generate_test_code() {
    local scenario_path="$1" output_dir="${2:-${E2E_PROJECT_DIR}/tests/e2e}"
    [[ ! -f "$scenario_path" ]] && { _e2e_log ERROR "Scenario not found: ${scenario_path}"; return 1; }

    local scenario_name
    scenario_name=$(basename "$scenario_path" .json)
    local output_file="${output_dir}/${scenario_name}.spec.ts"

    mkdir -p "$output_dir" 2>/dev/null

    _e2e_log INFO "Generating test code for: ${scenario_name}"

    local scenario_content
    scenario_content=$(cat "$scenario_path" 2>/dev/null)

    local base_url="http://localhost:${E2E_API_PORT:-3000}"

    local test_code
    test_code=$(_e2e_call_claude "You are a Playwright/supertest E2E test code generator.

Given this test scenario JSON, generate a complete TypeScript test file using @playwright/test or supertest.

SCENARIO:
${scenario_content}

BASE URL: ${base_url}
PROJECT TYPE: ${E2E_PROJECT_TYPE}

Requirements:
1. Use import { test, expect } from '@playwright/test' for UI tests, or supertest for API-only tests
2. Each step in the scenario becomes a test assertion
3. For CRUD scenarios: save created resource IDs and use them in subsequent steps
4. For auth scenarios: save JWT tokens and use them in Authorization headers
5. For integrity scenarios: verify foreign key relationships
6. Add proper setup/teardown with beforeAll/afterAll
7. Include descriptive test names
8. Handle timeouts properly
9. Add console.log for debugging

Output ONLY valid TypeScript code. No markdown fences.")

    if [[ -n "$test_code" && ${#test_code} -gt 100 ]]; then
        echo "$test_code" | sed '/^```/d; /^typescript$/d; /^ts$/d' > "$output_file"
        _e2e_log PASS "Generated: ${output_file} ($(wc -l < "$output_file" | tr -d ' ') lines)"
    else
        _e2e_log WARN "Test code generation insufficient for: ${scenario_name}"
        _e2e_write_minimal_test "$output_file" "$scenario_name" "$base_url"
    fi

    return 0
}

# --- 最小テストコード (フォールバック) ----------------------------------------
_e2e_write_minimal_test() {
    local output_file="$1" name="$2" base_url="$3"
    cat > "$output_file" << MINTEST
import { test, expect } from '@playwright/test';

test.describe('${name}', () => {
  const BASE_URL = '${base_url}';

  test('API health check', async ({ request }) => {
    const response = await request.get(BASE_URL);
    expect(response.status()).toBeLessThan(500);
  });

  test('CRUD basic flow', async ({ request }) => {
    // Create
    const createRes = await request.post(\`\${BASE_URL}/api/items\`, {
      data: { name: 'E2E Test Item', description: 'Auto-generated' }
    });
    expect([200, 201]).toContain(createRes.status());

    // Read (if create succeeded)
    if (createRes.ok()) {
      const body = await createRes.json();
      const id = body.id || body.data?.id;
      if (id) {
        const readRes = await request.get(\`\${BASE_URL}/api/items/\${id}\`);
        expect(readRes.ok()).toBeTruthy();
      }
    }
  });
});
MINTEST
    _e2e_log WARN "Wrote minimal fallback test: ${output_file}"
}

# =============================================================================
# 公開API: テスト用サービス起動
# =============================================================================
e2e_start_services() {
    local pd="${1:-$E2E_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { _e2e_log ERROR "Invalid project dir: ${pd}"; return 1; }

    _e2e_log SECTION "=== Starting E2E Services ==="

    E2E_SERVICE_PIDS=""

    # Docker Compose モード
    if [[ "$E2E_USE_DOCKER" == "true" ]]; then
        _e2e_log INFO "Starting services via Docker Compose..."
        local compose_file=""
        for cf in "docker-compose.yml" "docker-compose.yaml" "compose.yml"; do
            [[ -f "${pd}/${cf}" ]] && { compose_file="${pd}/${cf}"; break; }
        done

        if [[ -n "$compose_file" ]]; then
            (cd "$pd" && docker compose up -d 2>&1) || {
                _e2e_log WARN "Docker Compose failed, falling back to direct start"
                E2E_USE_DOCKER=false
            }
        fi

        if [[ "$E2E_USE_DOCKER" == "true" ]]; then
            # Docker起動後のヘルスチェック
            sleep 5
            local api_port="${E2E_API_PORT:-3000}"
            _e2e_wait_for_health "http://localhost:${api_port}" 60 && return 0
            _e2e_log WARN "Docker services not healthy, trying direct start"
            (cd "$pd" && docker compose down 2>/dev/null) || true
            E2E_USE_DOCKER=false
        fi
    fi

    # 直接起動モード
    _e2e_log INFO "Starting services directly..."

    # DB起動 (SQLiteの場合は不要)
    case "$E2E_DB_TYPE" in
        postgres)
            if ! _e2e_is_port_in_use 5432; then
                _e2e_log WARN "PostgreSQL not running on :5432 - tests may use SQLite fallback"
            else
                _e2e_log PASS "PostgreSQL detected on :5432"
            fi
            ;;
        mysql)
            if ! _e2e_is_port_in_use 3306; then
                _e2e_log WARN "MySQL not running on :3306 - tests may use SQLite fallback"
            else
                _e2e_log PASS "MySQL detected on :3306"
            fi
            ;;
        sqlite|none)
            _e2e_log INFO "Using SQLite or no DB required"
            ;;
    esac

    # Prisma マイグレーション実行
    if [[ -f "${pd}/prisma/schema.prisma" ]]; then
        _e2e_log INFO "Running Prisma migrations..."
        (cd "$pd" && NODE_ENV=test npx prisma migrate deploy 2>/dev/null) || \
        (cd "$pd" && NODE_ENV=test npx prisma db push --force-reset 2>/dev/null) || \
            _e2e_log WARN "Prisma migration failed - proceeding anyway"
    fi

    # アプリケーション起動
    local start_cmd=""
    local api_port="${E2E_API_PORT:-3000}"

    if [[ "$E2E_PROJECT_TYPE" == "node" || "$E2E_PROJECT_TYPE" == "nextjs" || "$E2E_PROJECT_TYPE" == "express" ]]; then
        if grep -q '"dev"' "${pd}/package.json" 2>/dev/null; then
            start_cmd="npm run dev"
        elif grep -q '"start"' "${pd}/package.json" 2>/dev/null; then
            start_cmd="npm start"
        fi
    elif [[ "$E2E_PROJECT_TYPE" == "python" ]]; then
        if [[ -f "${pd}/manage.py" ]]; then
            start_cmd="python manage.py runserver 0.0.0.0:${api_port}"
        elif [[ -f "${pd}/main.py" ]]; then
            start_cmd="uvicorn main:app --host 0.0.0.0 --port ${api_port}"
        fi
    elif [[ "$E2E_PROJECT_TYPE" == "go" ]]; then
        start_cmd="go run ."
    fi

    if [[ -z "$start_cmd" ]]; then
        _e2e_log WARN "Could not detect start command"
        return 1
    fi

    # ポートが既に使用中か確認
    if _e2e_is_port_in_use "$api_port"; then
        _e2e_log PASS "Service already running on port ${api_port}"
        return 0
    fi

    _e2e_log INFO "Starting: ${start_cmd} (port ${api_port})"

    local stdout_log="${E2E_REPORT_DIR}/service_stdout.log"
    local stderr_log="${E2E_REPORT_DIR}/service_stderr.log"

    (cd "$pd" && NODE_ENV=test PORT="${api_port}" $start_cmd \
        > "$stdout_log" 2> "$stderr_log" &)
    local svc_pid=$!
    E2E_SERVICE_PIDS="${E2E_SERVICE_PIDS} ${svc_pid}"

    # 起動待機
    _e2e_wait_for_port "$api_port" 45 || {
        _e2e_log ERROR "Service failed to start on port ${api_port}"
        # エラーログ出力
        if [[ -f "$stderr_log" ]]; then
            _e2e_log ERROR "Last stderr: $(tail -5 "$stderr_log" 2>/dev/null)"
        fi
        return 1
    }

    # ヘルスチェック
    _e2e_wait_for_health "http://localhost:${api_port}" 30 || {
        _e2e_log WARN "Health check failed but port is open - proceeding"
    }

    _e2e_log PASS "All services started successfully"
    return 0
}

# =============================================================================
# 公開API: 全E2Eシナリオ実行
# =============================================================================
e2e_run_all() {
    local pd="${1:-$E2E_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { _e2e_log ERROR "Invalid project dir: ${pd}"; return 1; }

    _e2e_log SECTION "=== E2E Pipeline: Full Run ==="

    local scenario_dir="${pd}/tests/e2e/scenarios"

    # シナリオが未生成なら生成
    if [[ ! -d "$scenario_dir" ]] || [[ $(find "$scenario_dir" -name '*.json' 2>/dev/null | wc -l | tr -d ' ') -eq 0 ]]; then
        _e2e_log INFO "No scenarios found - generating..."
        e2e_generate_scenarios "$pd" || {
            _e2e_log ERROR "Scenario generation failed"
            return 1
        }
    fi

    # テストコード生成
    _e2e_log STEP "Generating test code from scenarios..."
    local test_dir="${pd}/tests/e2e"
    while IFS= read -r scenario_file; do
        [[ -z "$scenario_file" ]] && continue
        e2e_generate_test_code "$scenario_file" "$test_dir" || true
    done < <(find "$scenario_dir" -name '*.json' -type f 2>/dev/null | sort)

    # サービス起動
    e2e_start_services "$pd" || {
        _e2e_log ERROR "Service startup failed - aborting E2E"
        return 1
    }

    # 各シナリオを実行
    _e2e_log STEP "Running E2E scenarios..."
    local scenario_files
    scenario_files=$(find "$scenario_dir" -name '*.json' -type f 2>/dev/null | sort)

    while IFS= read -r scenario_file; do
        [[ -z "$scenario_file" ]] && continue
        (( E2E_SCENARIOS_TOTAL++ ))
        e2e_run_scenario "$scenario_file"
    done <<< "$scenario_files"

    # データ整合性テスト
    # 【2026-08-03 fail-closed化】従来は戻り値を捨てており、整合性テストが不合格/未検証
    # (rc=1) や測定不能 (rc=3) でも総合判定 (E2E_SCENARIOS_FAILED) に一切現れなかった。
    # 非成功はシナリオ1件として計上する (検査を緩めない方向のみの変更)。
    _e2e_log STEP "Running data integrity tests..."
    (( E2E_SCENARIOS_TOTAL++ ))
    if e2e_test_data_integrity "$pd"; then
        (( E2E_SCENARIOS_PASSED++ ))
    else
        (( E2E_SCENARIOS_FAILED++ ))
        _e2e_log FAIL "データ整合性テスト不合格/未検証を総合判定へ計上 (fail-closed)"
    fi

    # 監査ログテスト (同上: 非成功を総合判定へ計上)
    _e2e_log STEP "Running audit trail tests..."
    (( E2E_SCENARIOS_TOTAL++ ))
    if e2e_test_audit_trail "$pd"; then
        (( E2E_SCENARIOS_PASSED++ ))
    else
        (( E2E_SCENARIOS_FAILED++ ))
        _e2e_log FAIL "監査ログテスト不合格/未検証を総合判定へ計上 (fail-closed)"
    fi

    # サービス停止
    e2e_stop_services

    # レポート生成
    e2e_generate_report

    # 結果判定
    if (( E2E_SCENARIOS_FAILED > 0 )); then
        _e2e_log FAIL "E2E Pipeline: ${E2E_SCENARIOS_FAILED}/${E2E_SCENARIOS_TOTAL} scenarios FAILED"
        return 1
    fi

    _e2e_log PASS "E2E Pipeline: All ${E2E_SCENARIOS_PASSED}/${E2E_SCENARIOS_TOTAL} scenarios PASSED"
    return 0
}

# =============================================================================
# 公開API: 単一シナリオ実行
# =============================================================================
e2e_run_scenario() {
    local scenario_file="$1"
    [[ ! -f "$scenario_file" ]] && { _e2e_log ERROR "Scenario not found: ${scenario_file}"; return 1; }

    local scenario_name
    scenario_name=$(basename "$scenario_file" .json)
    _e2e_log INFO "Running scenario: ${scenario_name}"

    local test_file="${E2E_PROJECT_DIR}/tests/e2e/${scenario_name}.spec.ts"
    local api_port="${E2E_API_PORT:-3000}"
    local base_url="http://localhost:${api_port}"
    local attempt=0
    local result=1

    # テストファイルが存在しない場合はAPIテストとしてcurlベースで実行
    if [[ -f "$test_file" ]] && command -v npx &>/dev/null; then
        # Playwright / Jest で実行
        while (( attempt < E2E_MAX_RETRIES )); do
            (( attempt++ ))
            _e2e_log INFO "Attempt ${attempt}/${E2E_MAX_RETRIES}: ${scenario_name}"

            local test_output=""
            test_output=$(cd "${E2E_PROJECT_DIR}" && \
                timeout "${E2E_TIMEOUT}" npx playwright test "$test_file" --reporter=json 2>&1) || true

            if echo "$test_output" | grep -q '"status":"passed"' 2>/dev/null; then
                result=0
                break
            elif echo "$test_output" | grep -q '"passed":' 2>/dev/null; then
                # JSON レポートから結果を確認
                local passed_count
                passed_count=$(echo "$test_output" | grep -o '"passed":[0-9]*' | head -1 | cut -d: -f2)
                local failed_count
                failed_count=$(echo "$test_output" | grep -o '"failed":[0-9]*' | head -1 | cut -d: -f2)
                if [[ "${failed_count:-1}" == "0" && "${passed_count:-0}" != "0" ]]; then
                    result=0
                    break
                fi
            fi

            (( attempt < E2E_MAX_RETRIES )) && {
                _e2e_log WARN "Retry ${attempt}: ${scenario_name}"
                sleep 2
            }
        done
    else
        # curlベースのAPI テスト (Playwright不要)
        result=0
        _e2e_log INFO "Running curl-based API test for: ${scenario_name}"

        # シナリオJSONの各ステップをcurlで実行
        local saved_id="" saved_token=""

        # jq が利用可能か確認
        if command -v jq &>/dev/null; then
            local steps_count
            steps_count=$(jq '.steps | length' "$scenario_file" 2>/dev/null || echo "0")

            local i=0
            while (( i < steps_count )); do
                local step_action step_endpoint step_method step_status step_body
                step_action=$(jq -r ".steps[$i].action" "$scenario_file" 2>/dev/null)
                step_endpoint=$(jq -r ".steps[$i].endpoint" "$scenario_file" 2>/dev/null)
                step_method=$(jq -r ".steps[$i].method" "$scenario_file" 2>/dev/null)
                step_status=$(jq -r ".steps[$i].expect_status" "$scenario_file" 2>/dev/null)
                step_body=$(jq -c ".steps[$i].body // empty" "$scenario_file" 2>/dev/null)

                # プレースホルダ置換
                step_endpoint="${step_endpoint//\{id\}/$saved_id}"
                step_endpoint="${step_endpoint//\{parent_id\}/$saved_id}"
                step_endpoint="${step_endpoint//\{child_id\}/$saved_id}"

                local curl_args=(-s -o /dev/null -w '%{http_code}')
                curl_args+=(-X "$step_method")
                [[ -n "$step_body" && "$step_body" != "null" ]] && {
                    curl_args+=(-H "Content-Type: application/json")
                    curl_args+=(-d "$step_body")
                }
                [[ -n "$saved_token" ]] && {
                    local use_token
                    use_token=$(jq -r ".steps[$i].use_token // false" "$scenario_file" 2>/dev/null)
                    [[ "$use_token" == "true" ]] && curl_args+=(-H "Authorization: Bearer ${saved_token}")
                }

                local actual_status
                actual_status=$(curl "${curl_args[@]}" "${base_url}${step_endpoint}" 2>/dev/null) || actual_status="000"

                if [[ "$actual_status" == "$step_status" ]]; then
                    _e2e_log PASS "  Step: ${step_action} -> HTTP ${actual_status} (expected ${step_status})"
                else
                    _e2e_log FAIL "  Step: ${step_action} -> HTTP ${actual_status} (expected ${step_status})"
                    result=1
                fi

                # IDやトークンの保存 (createステップ)
                if [[ "$step_action" == "create" || "$step_action" == "create_parent" || "$step_action" == "create_child" ]] \
                    && [[ "$actual_status" =~ ^20[01]$ ]]; then
                    local body_response
                    body_response=$(curl -s -X "$step_method" \
                        -H "Content-Type: application/json" \
                        ${step_body:+-d "$step_body"} \
                        "${base_url}${step_endpoint}" 2>/dev/null)
                    saved_id=$(echo "$body_response" | jq -r '.id // .data.id // empty' 2>/dev/null)
                fi
                if [[ "$(jq -r ".steps[$i].save_token // false" "$scenario_file" 2>/dev/null)" == "true" ]] \
                    && [[ "$actual_status" == "200" ]]; then
                    local token_response
                    token_response=$(curl -s -X "$step_method" \
                        -H "Content-Type: application/json" \
                        ${step_body:+-d "$step_body"} \
                        "${base_url}${step_endpoint}" 2>/dev/null)
                    saved_token=$(echo "$token_response" | jq -r '.token // .accessToken // .access_token // empty' 2>/dev/null)
                fi

                (( i++ ))
            done
        else
            _e2e_log WARN "jq not available - skipping curl-based scenario test"
            result=1
        fi
    fi

    # 結果記録
    if (( result == 0 )); then
        (( E2E_SCENARIOS_PASSED++ ))
        _e2e_log PASS "Scenario PASSED: ${scenario_name}"
        _e2e_json_add "{\"scenario\":\"${scenario_name}\",\"status\":\"passed\",\"attempts\":${attempt}}"
    else
        (( E2E_SCENARIOS_FAILED++ ))
        _e2e_log FAIL "Scenario FAILED: ${scenario_name}"
        E2E_FAILURE_DETAILS+="FAILED: ${scenario_name} (after ${attempt} attempts)\n"
        _e2e_json_add "{\"scenario\":\"${scenario_name}\",\"status\":\"failed\",\"attempts\":${attempt}}"
    fi

    return $result
}

# =============================================================================
# 公開API: テスト用サービス停止
# =============================================================================
e2e_stop_services() {
    _e2e_log SECTION "=== Stopping E2E Services ==="

    # Docker Compose 停止
    if [[ "$E2E_USE_DOCKER" == "true" && -n "$E2E_PROJECT_DIR" ]]; then
        _e2e_log INFO "Stopping Docker Compose services..."
        (cd "$E2E_PROJECT_DIR" && docker compose down --remove-orphans 2>/dev/null) || true
    fi

    # 直接起動したプロセスの停止
    if [[ -n "$E2E_SERVICE_PIDS" ]]; then
        for pid in $E2E_SERVICE_PIDS; do
            if kill -0 "$pid" 2>/dev/null; then
                _e2e_log INFO "Stopping PID: ${pid}"
                kill -TERM "$pid" 2>/dev/null || true
                # SIGTERM待機 -> SIGKILL
                local wait_count=0
                while kill -0 "$pid" 2>/dev/null && (( wait_count < 10 )); do
                    sleep 1
                    (( wait_count++ ))
                done
                kill -0 "$pid" 2>/dev/null && {
                    _e2e_log WARN "Force killing PID: ${pid}"
                    kill -9 "$pid" 2>/dev/null || true
                }
            fi
        done
    fi

    # テストデータクリーンアップ
    [[ -n "$E2E_PROJECT_DIR" ]] && _e2e_cleanup_test_data "$E2E_PROJECT_DIR"

    E2E_SERVICE_PIDS=""
    _e2e_log PASS "All services stopped"
}

# =============================================================================
# 公開API: データ整合性テスト (v17.0 核心機能)
# =============================================================================
e2e_test_data_integrity() {
    local pd="${1:-$E2E_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { _e2e_log ERROR "Invalid project dir: ${pd}"; return 1; }

    _e2e_log SECTION "=== Data Integrity Testing (v17.0 Core) ==="

    local api_port="${E2E_API_PORT:-3000}"
    local base_url="http://localhost:${api_port}"
    local integrity_passed=0
    local integrity_failed=0
    # fail-open是正 (2026-08-03): 「検証をスキップした=未検証」を合格に混ぜないための計数。
    # unverified > 0 なら本関数は成功(return 0)を返さない (fail-closed)。
    local unverified=0

    # 1. テストデータ投入
    _e2e_log STEP "1/6: Inserting test data..."
    local create_response
    create_response=$(curl -s -X POST \
        -H "Content-Type: application/json" \
        -d '{"name":"Integrity Test Record","description":"E2E data integrity test","email":"integrity@test.local"}' \
        "${base_url}/api/items" 2>/dev/null) || create_response=""

    local test_id=""
    if command -v jq &>/dev/null && [[ -n "$create_response" ]]; then
        test_id=$(echo "$create_response" | jq -r '.id // .data.id // empty' 2>/dev/null)
    fi

    if [[ -n "$test_id" && "$test_id" != "null" ]]; then
        _e2e_log PASS "Test record created: id=${test_id}"
        (( integrity_passed++ ))
    else
        _e2e_log WARN "Could not create test record - API may not support generic /api/items"
        # プロジェクト固有のエンドポイントを推測
        local api_endpoints
        api_endpoints=$(_e2e_discover_api_endpoints "$pd")
        if [[ -n "$api_endpoints" ]]; then
            local first_endpoint
            first_endpoint=$(echo "$api_endpoints" | head -1)
            _e2e_log INFO "Trying discovered endpoint: ${first_endpoint}"
            create_response=$(curl -s -X POST \
                -H "Content-Type: application/json" \
                -d '{"name":"Integrity Test","description":"auto"}' \
                "${base_url}${first_endpoint}" 2>/dev/null) || true
            if command -v jq &>/dev/null; then
                test_id=$(echo "$create_response" | jq -r '.id // .data.id // empty' 2>/dev/null)
            fi
        fi
    fi

    # 2. レコード存在確認
    _e2e_log STEP "2/6: Verifying record existence..."
    if [[ -n "$test_id" && "$test_id" != "null" ]]; then
        local read_status
        read_status=$(curl -s -o /dev/null -w '%{http_code}' \
            "${base_url}/api/items/${test_id}" 2>/dev/null) || read_status="000"
        if [[ "$read_status" =~ ^20[0-9]$ ]]; then
            _e2e_log PASS "Record readable: HTTP ${read_status}"
            (( integrity_passed++ ))
        else
            _e2e_log FAIL "Record not readable: HTTP ${read_status}"
            (( integrity_failed++ ))
        fi
    else
        # fail-open是正 (2026-08-03): レコード作成失敗によるスキップは「未検証」として計上する。
        # (ステップ2〜5の CRUD 連鎖がまるごと未検証になるため、WARN だけで合格へ落とさない)
        _e2e_log WARN "Skipping read check - no test record ID (CRUD連鎖 2〜5 を未検証として計上)"
        (( unverified++ ))
    fi

    # 3. 更新操作 before/after 比較
    _e2e_log STEP "3/6: Testing update with before/after comparison..."
    if [[ -n "$test_id" && "$test_id" != "null" ]]; then
        # before 状態を取得
        local before_state
        before_state=$(curl -s "${base_url}/api/items/${test_id}" 2>/dev/null) || before_state=""

        # update 実行
        local update_status
        update_status=$(curl -s -o /dev/null -w '%{http_code}' \
            -X PUT -H "Content-Type: application/json" \
            -d '{"name":"Updated Integrity Record","description":"after update"}' \
            "${base_url}/api/items/${test_id}" 2>/dev/null) || update_status="000"

        # after 状態を取得
        local after_state
        after_state=$(curl -s "${base_url}/api/items/${test_id}" 2>/dev/null) || after_state=""

        if [[ "$update_status" =~ ^20[0-9]$ ]]; then
            if [[ "$before_state" != "$after_state" && -n "$after_state" ]]; then
                _e2e_log PASS "Update verified: state changed (HTTP ${update_status})"
                (( integrity_passed++ ))
            else
                _e2e_log WARN "Update returned ${update_status} but state unchanged"
                (( integrity_failed++ ))
            fi
        else
            _e2e_log FAIL "Update failed: HTTP ${update_status}"
            (( integrity_failed++ ))
        fi
    fi

    # 4. 削除操作
    _e2e_log STEP "4/6: Testing delete operation..."
    if [[ -n "$test_id" && "$test_id" != "null" ]]; then
        local delete_status
        delete_status=$(curl -s -o /dev/null -w '%{http_code}' \
            -X DELETE "${base_url}/api/items/${test_id}" 2>/dev/null) || delete_status="000"

        if [[ "$delete_status" =~ ^20[0-9]$ ]]; then
            _e2e_log PASS "Delete succeeded: HTTP ${delete_status}"
            (( integrity_passed++ ))
        else
            _e2e_log FAIL "Delete failed: HTTP ${delete_status}"
            (( integrity_failed++ ))
        fi
    fi

    # 5. 削除確認 (カスケード含む)
    _e2e_log STEP "5/6: Verifying deletion..."
    if [[ -n "$test_id" && "$test_id" != "null" ]]; then
        local verify_status
        verify_status=$(curl -s -o /dev/null -w '%{http_code}' \
            "${base_url}/api/items/${test_id}" 2>/dev/null) || verify_status="000"

        if [[ "$verify_status" == "404" ]]; then
            _e2e_log PASS "Deletion verified: HTTP 404 (record gone)"
            (( integrity_passed++ ))
        elif [[ "$verify_status" =~ ^20[0-9]$ ]]; then
            _e2e_log FAIL "Record still exists after delete: HTTP ${verify_status}"
            (( integrity_failed++ ))
        else
            _e2e_log WARN "Unexpected status after delete: HTTP ${verify_status}"
        fi
    fi

    # 6. 並行更新テスト (楽観的ロック検証)
    _e2e_log STEP "6/6: Testing concurrent updates (optimistic locking)..."
    local concurrent_id=""
    local concurrent_response
    concurrent_response=$(curl -s -X POST \
        -H "Content-Type: application/json" \
        -d '{"name":"Concurrent Test","description":"for locking test"}' \
        "${base_url}/api/items" 2>/dev/null) || concurrent_response=""

    if command -v jq &>/dev/null && [[ -n "$concurrent_response" ]]; then
        concurrent_id=$(echo "$concurrent_response" | jq -r '.id // .data.id // empty' 2>/dev/null)
    fi

    if [[ -n "$concurrent_id" && "$concurrent_id" != "null" ]]; then
        # 2つの同時更新を発行
        local update_a update_b
        update_a=$(curl -s -o /dev/null -w '%{http_code}' \
            -X PUT -H "Content-Type: application/json" \
            -d '{"name":"Update A","version":1}' \
            "${base_url}/api/items/${concurrent_id}" 2>/dev/null) &
        local pid_a=$!

        update_b=$(curl -s -o /dev/null -w '%{http_code}' \
            -X PUT -H "Content-Type: application/json" \
            -d '{"name":"Update B","version":1}' \
            "${base_url}/api/items/${concurrent_id}" 2>/dev/null) &
        local pid_b=$!

        wait "$pid_a" 2>/dev/null || true
        wait "$pid_b" 2>/dev/null || true

        # 最終状態を確認
        # fail-open是正 (2026-08-03):
        #   旧実装は curl 失敗→final_state 空→WARN のみで integrity_failed に計上せず、
        #   サーバ停止で検証が丸ごと未実施でも return 0=合格になっていた。
        #   さらに PASS 条件が「応答が非空」だけだったため、エラーページや
        #   スタックトレース応答でも「final state consistent」に化けていた。
        #   取得失敗/空/期待フィールド不在はすべて FAIL 側へ倒す (fail-closed)。
        local final_state
        final_state=$(curl -s "${base_url}/api/items/${concurrent_id}" 2>/dev/null) || final_state=""

        if [[ -z "$final_state" ]]; then
            _e2e_log FAIL "Concurrent update NOT verified: 最終状態を取得できず未検証 (curl失敗/空応答)"
            (( integrity_failed++ ))
        elif echo "$final_state" | jq -e --arg cid "$concurrent_id" \
                '((.id // .data.id) | tostring) == $cid and ((.name // .data.name) != null)' \
                >/dev/null 2>&1; then
            # 応答JSONに期待フィールド (id=作成したレコードのID, name) が実在することを検証
            _e2e_log PASS "Concurrent update verified: final state has expected fields (id=${concurrent_id})"
            (( integrity_passed++ ))
        else
            _e2e_log FAIL "Concurrent update NOT verified: 応答JSONに期待フィールド(id/name)が実在しない (エラーページ/破損応答の疑い)"
            (( integrity_failed++ ))
        fi

        # クリーンアップ
        curl -s -X DELETE "${base_url}/api/items/${concurrent_id}" &>/dev/null || true
    else
        # fail-open是正 (2026-08-03): レコード作成失敗によるスキップも「未検証」として計上する。
        _e2e_log WARN "Concurrent test skipped - could not create test record (未検証として計上)"
        (( unverified++ ))
    fi

    # サマリ
    # PFP-186 (2026-07-30) fail-open 是正:
    #   以前は「合格0・失敗0」= 一度も測れていない状態でも return 0 (成功) を返し、
    #   JSON にも passed=0/failed=0 だけを載せていた。API が無い・サーバが落ちている・
    #   curl が全滅した場合の WARN 分岐は failed を増やさないため、
    #   「検査した結果 問題なし」と「検査できなかった」が区別できなかった。
    #   測れなかったことを別枠 (unmeasured) で必ず開示し、成功として返さない。
    if (( integrity_passed == 0 && integrity_failed == 0 )); then
        _e2e_log WARN "データ整合性テストを実測できませんでした (未確認) — API 未提供 or サーバ未起動の可能性"
        _e2e_json_add "{\"test\":\"data_integrity\",\"passed\":0,\"failed\":0,\"unverified\":${unverified},\"unmeasured\":1,\"verdict\":\"unmeasurable\"}"
        (( E2E_SCENARIOS_SKIPPED++ )) || true
        return 3
    fi

    _e2e_log INFO "Data integrity results: ${integrity_passed} passed, ${integrity_failed} failed, ${unverified} unverified"
    _e2e_json_add "{\"test\":\"data_integrity\",\"passed\":${integrity_passed},\"failed\":${integrity_failed},\"unverified\":${unverified},\"unmeasured\":0}"

    (( integrity_failed > 0 )) && return 1
    # fail-open是正 (2026-08-03): 未検証(スキップ)が1件でもあれば成功を返さない (fail-closed)。
    if (( unverified > 0 )); then
        _e2e_log FAIL "未検証項目が ${unverified} 件あるため合格にしません (検証スキップ=合格ではない)"
        return 1
    fi
    return 0
}

# --- APIエンドポイント自動探索 ------------------------------------------------
_e2e_discover_api_endpoints() {
    local pd="$1"
    local endpoints=""

    # Next.js App Router
    if [[ -d "${pd}/app/api" || -d "${pd}/src/app/api" ]]; then
        local api_root="${pd}/app/api"
        [[ -d "${pd}/src/app/api" ]] && api_root="${pd}/src/app/api"
        while IFS= read -r route_file; do
            local ep="${route_file#"$api_root"}"
            ep="${ep%/route.*}"
            [[ -n "$ep" ]] && endpoints+="/api${ep}
"
        done < <(find "$api_root" -name 'route.*' -type f 2>/dev/null)
    fi

    # Express ルートファイル
    if [[ -d "${pd}/routes" || -d "${pd}/src/routes" ]]; then
        local routes_dir="${pd}/routes"
        [[ -d "${pd}/src/routes" ]] && routes_dir="${pd}/src/routes"
        while IFS= read -r route_file; do
            local name
            name=$(basename "$route_file" | sed 's/\.\(ts\|js\)$//')
            [[ "$name" != "index" ]] && endpoints+="/api/${name}
"
        done < <(find "$routes_dir" -name '*.ts' -o -name '*.js' -type f 2>/dev/null | head -10)
    fi

    echo "$endpoints"
}

# =============================================================================
# 公開API: 監査ログ完全性テスト
# =============================================================================
e2e_test_audit_trail() {
    local pd="${1:-$E2E_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { _e2e_log ERROR "Invalid project dir: ${pd}"; return 1; }

    _e2e_log SECTION "=== Audit Trail Integrity Test ==="

    local api_port="${E2E_API_PORT:-3000}"
    local base_url="http://localhost:${api_port}"
    local audit_passed=0
    local audit_failed=0

    # 監査ログエンドポイント検出
    # PFP-186 是正: 「サーバへ到達できなかった」と「監査エンドポイントが無い」を弁別する。
    #   すべての探索が 000 (接続不能) なら、それは *測れなかった* のであって
    #   「監査ログの実装が無い」の根拠にはならない。
    local audit_endpoint=""
    local server_reachable=false
    for ep in "/api/audit-logs" "/api/audit" "/api/logs" "/api/activity"; do
        local status
        status=$(curl -s -o /dev/null -w '%{http_code}' "${base_url}${ep}" 2>/dev/null) || status="000"
        [[ "$status" != "000" ]] && server_reachable=true
        if [[ "$status" =~ ^20[0-9]$ ]]; then
            audit_endpoint="$ep"
            break
        fi
    done

    if [[ -z "$audit_endpoint" && "$server_reachable" != "true" ]]; then
        _e2e_log WARN "アプリへ接続できないため監査ログを実測できませんでした (未確認)"
        _e2e_json_add "{\"test\":\"audit_trail\",\"passed\":0,\"failed\":0,\"unmeasured\":1,\"verdict\":\"unmeasurable\",\"reason\":\"server unreachable\"}"
        (( E2E_SCENARIOS_SKIPPED++ )) || true
        return 3
    fi

    if [[ -z "$audit_endpoint" ]]; then
        _e2e_log WARN "No audit log endpoint detected - checking source code for audit patterns"

        # ソースコード内の監査パターン検索
        local has_audit=false
        if grep -rq 'audit\|AuditLog\|activityLog\|EventLog' \
            "${pd}/prisma/schema.prisma" "${pd}/src" "${pd}/app" 2>/dev/null; then
            has_audit=true
        fi

        if [[ "$has_audit" == "true" ]]; then
            _e2e_log INFO "Audit patterns found in source code"
            (( audit_passed++ ))
        else
            _e2e_log WARN "No audit trail implementation detected - skipping"
            _e2e_json_add "{\"test\":\"audit_trail\",\"status\":\"skipped\",\"reason\":\"no audit implementation detected\"}"
            return 0
        fi
    else
        _e2e_log PASS "Audit endpoint found: ${audit_endpoint}"
        (( audit_passed++ ))

        # CRUD操作を実行し、監査ログにエントリが記録されるか確認
        _e2e_log INFO "Performing CRUD operations and checking audit trail..."

        # 監査前のログ数を取得
        local before_count=0
        if command -v jq &>/dev/null; then
            local before_logs
            before_logs=$(curl -s "${base_url}${audit_endpoint}" 2>/dev/null) || before_logs=""
            before_count=$(echo "$before_logs" | jq 'if type == "array" then length elif .data then (.data | length) else 0 end' 2>/dev/null || echo "0")
        fi

        # テスト操作: CREATE
        curl -s -X POST -H "Content-Type: application/json" \
            -d '{"name":"Audit Trail Test"}' \
            "${base_url}/api/items" &>/dev/null || true

        sleep 1

        # 監査後のログ数を確認
        local after_count=0
        if command -v jq &>/dev/null; then
            local after_logs
            after_logs=$(curl -s "${base_url}${audit_endpoint}" 2>/dev/null) || after_logs=""
            after_count=$(echo "$after_logs" | jq 'if type == "array" then length elif .data then (.data | length) else 0 end' 2>/dev/null || echo "0")
        fi

        if (( after_count > before_count )); then
            _e2e_log PASS "Audit trail records CRUD operations (${before_count} -> ${after_count})"
            (( audit_passed++ ))
        else
            _e2e_log WARN "Audit trail count unchanged after CRUD (${before_count} -> ${after_count})"
            (( audit_failed++ ))
        fi
    fi

    # PFP-186 (2026-07-30) fail-open 是正 (data_integrity と同趣旨)。
    # 「監査ログを一度も観測できなかった」を「監査ログに問題なし」と読ませない。
    if (( audit_passed == 0 && audit_failed == 0 )); then
        _e2e_log WARN "監査ログテストを実測できませんでした (未確認) — 監査エンドポイント未提供 or サーバ未起動の可能性"
        _e2e_json_add "{\"test\":\"audit_trail\",\"passed\":0,\"failed\":0,\"unmeasured\":1,\"verdict\":\"unmeasurable\"}"
        (( E2E_SCENARIOS_SKIPPED++ )) || true
        return 3
    fi

    _e2e_log INFO "Audit trail results: ${audit_passed} passed, ${audit_failed} failed"
    _e2e_json_add "{\"test\":\"audit_trail\",\"passed\":${audit_passed},\"failed\":${audit_failed},\"unmeasured\":0}"

    (( audit_failed > 0 )) && return 1
    return 0
}

# =============================================================================
# 公開API: E2Eテスト結果レポート生成
# =============================================================================
e2e_generate_report() {
    _e2e_log SECTION "=== E2E Test Report ==="

    local end_time
    end_time=$(date +%s)
    local duration=$(( end_time - E2E_START_TIME ))

    # 人間可読なサマリ
    echo ""
    echo -e "${E2E_BOLD}  ===== E2E Pipeline Report (v${E2E_VERSION}) =====${E2E_NC}"
    echo -e "  Total Scenarios: ${E2E_SCENARIOS_TOTAL}"
    echo -e "  ${E2E_GREEN}Passed:${E2E_NC} ${E2E_SCENARIOS_PASSED}"
    echo -e "  ${E2E_RED}Failed:${E2E_NC} ${E2E_SCENARIOS_FAILED}"
    echo -e "  ${E2E_YELLOW}Skipped:${E2E_NC} ${E2E_SCENARIOS_SKIPPED}"
    echo -e "  Duration: ${duration}s"
    echo -e "  Project: ${E2E_PROJECT_TYPE} | DB: ${E2E_DB_TYPE}"
    echo ""

    # 失敗詳細
    if [[ -n "$E2E_FAILURE_DETAILS" ]]; then
        echo -e "${E2E_RED}  --- Failed Scenarios ---${E2E_NC}"
        echo -e "$E2E_FAILURE_DETAILS"
    fi

    # パス率
    local pass_rate=0
    if (( E2E_SCENARIOS_TOTAL > 0 )); then
        pass_rate=$(( (E2E_SCENARIOS_PASSED * 100) / E2E_SCENARIOS_TOTAL ))
    fi
    echo -e "  Pass Rate: ${pass_rate}%"
    echo ""

    # JSON レポート生成
    local report_file="${E2E_REPORT_DIR}/e2e_report_$(date +%Y%m%d_%H%M%S).json"
    cat > "$report_file" << REPORT_EOF
{
  "version": "${E2E_VERSION}",
  "timestamp": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
  "project_dir": "${E2E_PROJECT_DIR}",
  "project_type": "${E2E_PROJECT_TYPE}",
  "db_type": "${E2E_DB_TYPE}",
  "duration_seconds": ${duration},
  "summary": {
    "total": ${E2E_SCENARIOS_TOTAL},
    "passed": ${E2E_SCENARIOS_PASSED},
    "failed": ${E2E_SCENARIOS_FAILED},
    "skipped": ${E2E_SCENARIOS_SKIPPED},
    "pass_rate": ${pass_rate}
  },
  "config": {
    "timeout": ${E2E_TIMEOUT},
    "max_retries": ${E2E_MAX_RETRIES},
    "parallel": ${E2E_PARALLEL},
    "docker": ${E2E_USE_DOCKER}
  },
  "results": [
$(echo "$E2E_RESULTS_JSON" | sed 's/^/    /' | paste -sd ',' - | sed 's/,/,\n/g')
  ]
}
REPORT_EOF

    _e2e_log PASS "Report saved: ${report_file}"

    # Observatory イベントストリーム連携 (存在する場合)
    if declare -f trace_emit_event &>/dev/null; then
        trace_emit_event "E2E" "e2e_complete" \
            "{\"total\":${E2E_SCENARIOS_TOTAL},\"passed\":${E2E_SCENARIOS_PASSED},\"failed\":${E2E_SCENARIOS_FAILED},\"pass_rate\":${pass_rate}}"
    fi

    return 0
}

# =============================================================================
# 公開API: Claude CLIプロンプトにE2E要件を注入
# =============================================================================
e2e_inject_e2e_prompt() {
    local original_prompt="${1:-}"
    local project_type="${E2E_PROJECT_TYPE:-unknown}"

    local e2e_requirements="

=== E2E Testing Requirements (v17.0) ===
All generated code MUST support automated E2E testing:

1. API Design:
   - Every endpoint must return proper HTTP status codes (200/201/400/404/409/500)
   - POST endpoints must return the created resource with an 'id' field
   - DELETE endpoints must return 200 on success, subsequent GET must return 404
   - Support JSON Content-Type for all API endpoints

2. Data Integrity:
   - Foreign key constraints must be properly defined
   - Cascade delete behavior must be explicitly configured
   - Unique constraints must return 409 on duplicate
   - Include version/updatedAt field for optimistic locking

3. Authentication (if applicable):
   - POST /api/auth/register -> 201 with user object
   - POST /api/auth/login -> 200 with { token: 'jwt...' }
   - Protected routes must return 401 without valid token
   - POST /api/auth/logout -> 200

4. Error Handling:
   - Validation errors must return 400 with error details
   - Missing resources must return 404
   - Duplicate entries must return 409
   - Server errors must return 500 with safe error message

5. Audit Trail (recommended):
   - Log all CRUD operations with timestamp, action, userId, resourceId
   - Provide GET /api/audit-logs endpoint

6. Testing Infrastructure:
   - Include test configuration (jest.config / playwright.config / vitest.config)
   - Support NODE_ENV=test for test database isolation
   - Include seed data scripts for consistent test state
=== End E2E Requirements ==="

    echo "${original_prompt}${e2e_requirements}"
}

# =============================================================================
# 内部: Playwright インストール確認・セットアップ
# =============================================================================
_e2e_ensure_playwright() {
    local pd="$1"

    if npx playwright --version &>/dev/null 2>&1; then
        _e2e_log PASS "Playwright available"
        return 0
    fi

    _e2e_log INFO "Installing Playwright..."
    (cd "$pd" && npm install -D @playwright/test 2>/dev/null) || {
        _e2e_log WARN "Playwright install failed"
        return 1
    }

    (cd "$pd" && npx playwright install chromium 2>/dev/null) || {
        _e2e_log WARN "Playwright browser install failed"
        return 1
    }

    _e2e_log PASS "Playwright installed"
    return 0
}

# =============================================================================
# 内部: Playwright設定ファイル生成
# =============================================================================
_e2e_ensure_playwright_config() {
    local pd="$1"
    local config_file="${pd}/playwright.config.ts"

    [[ -f "$config_file" ]] && return 0

    local api_port="${E2E_API_PORT:-3000}"

    cat > "$config_file" << PWCONFIG
import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests/e2e',
  timeout: ${E2E_TIMEOUT} * 1000,
  retries: ${E2E_MAX_RETRIES},
  use: {
    baseURL: 'http://localhost:${api_port}',
    trace: 'retain-on-failure',
  },
  reporter: [['json', { outputFile: 'tests/e2e/results.json' }]],
});
PWCONFIG

    _e2e_log PASS "Generated playwright.config.ts"
}

# =============================================================================
# 公開API 追加: 一括E2E実行 (chain.shから呼ばれるメインエントリポイント)
# =============================================================================
e2e_full_pipeline() {
    local pd="${1:-$E2E_PROJECT_DIR}"
    [[ -z "$pd" ]] && { _e2e_log ERROR "Project directory required"; return 1; }

    _e2e_log SECTION "=========================================="
    _e2e_log SECTION "  E2E Pipeline v${E2E_VERSION} - Full Run"
    _e2e_log SECTION "=========================================="

    # 1. 初期化
    e2e_init "$pd" || return 1

    # 2. Playwright セットアップ (Node.jsプロジェクトの場合)
    if [[ "$E2E_PROJECT_TYPE" == "node" || "$E2E_PROJECT_TYPE" == "nextjs" || "$E2E_PROJECT_TYPE" == "express" ]]; then
        _e2e_ensure_playwright "$pd" || _e2e_log WARN "Playwright not available - using curl-based tests"
        _e2e_ensure_playwright_config "$pd"
    fi

    # 3. シナリオ生成
    e2e_generate_scenarios "$pd" || {
        _e2e_log WARN "Scenario generation had issues - continuing with available scenarios"
    }

    # 4. サービス起動 & テスト実行 & 停止
    e2e_run_all "$pd"
    local result=$?

    _e2e_log SECTION "=========================================="
    if (( result == 0 )); then
        _e2e_log PASS "E2E Pipeline: ALL TESTS PASSED"
    else
        _e2e_log FAIL "E2E Pipeline: TESTS FAILED (${E2E_SCENARIOS_FAILED} failures)"
    fi
    _e2e_log SECTION "=========================================="

    return $result
}
