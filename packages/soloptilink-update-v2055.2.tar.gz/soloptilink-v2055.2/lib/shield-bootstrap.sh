#!/usr/bin/env bash
# =============================================================================
# shield-bootstrap.sh — local-prompt-shield を chain.sh に統合する bootstrap
# =============================================================================
# chain.sh の main() からライセンス認証直後に呼ばれる。
# 役割:
#  1. CLI 引数 (./soloptilink "...") に API キーが含まれていれば即 redact
#     (LR3: プロセス引数 ps aux 漏洩 を構造的に解消)
#  2. shield が未配線なら first-run wizard を提案
#  3. shield proxy 未起動なら自動起動
#  4. shield audit を非ブロッキングで実行 (5 秒以内に異常検出)
#
# Exit code:
#  0  正常 (chain.sh は処理続行)
#  ※「機密検出+CLI引数 redact」は chain.sh を続行する設計
#  ※「shield 未配線」も警告のみで続行 (顧客の自由を尊重)

# 既存定義の保護
[[ -n "${_SHIELD_BOOTSTRAP_LOADED:-}" ]] && return 0
_SHIELD_BOOTSTRAP_LOADED=1

readonly _SHIELD_HOME="${HOME}/.soloptilink/lib/security/local-prompt-shield"
readonly _SHIELD_PROXY_PORT="${SHIELD_PROXY_PORT:-9444}"

# colors fallback (chain.sh 側で定義済みの想定だが安全側で)
: "${RED:=\033[0;31m}"
: "${YELLOW:=\033[0;33m}"
: "${GREEN:=\033[0;32m}"
: "${BLUE:=\033[0;34m}"
: "${CYAN:=\033[0;36m}"
: "${BOLD:=\033[1m}"
: "${NC:=\033[0m}"

# -----------------------------------------------------------------------------
# CLI 引数 pre-scrubber (LR3 解消)
# -----------------------------------------------------------------------------
# 渡された引数の中に API キーパターンが含まれていれば、
# OS Keychain に保存して handle に置換した版を返す。
# 元の "$@" は ps aux で見える時点で漏洩しているので、
# *せめて以降のフェーズには handle のみ渡す* + 顧客に警告。
#
# 使い方 (chain.sh 側):
#   sb_scrub_cli_args "$@"
#   set -- "${SHIELD_SCRUBBED_ARGS[@]}"

declare -ag SHIELD_SCRUBBED_ARGS=()
declare -g  SHIELD_REDACTION_COUNT=0

sb_scrub_cli_args() {
    SHIELD_SCRUBBED_ARGS=()
    SHIELD_REDACTION_COUNT=0

    if [[ ! -d "${_SHIELD_HOME}" ]]; then
        # shield 未配線 → 引数透過 (sb_first_run_check で警告)
        SHIELD_SCRUBBED_ARGS=("$@")
        return 0
    fi

    if ! command -v node &>/dev/null; then
        SHIELD_SCRUBBED_ARGS=("$@")
        return 0
    fi

    # node に各引数を JSON 配列として渡し、scrub 済み配列を JSON で受け取る
    local input_json
    input_json=$(printf '%s\n' "$@" | node -e '
const fs = require("node:fs");
const items = fs.readFileSync(0, "utf8").split("\n").filter(Boolean);
console.log(JSON.stringify(items));
')
    local out_json
    out_json=$(node -e "
const path = require('node:path');
const SHIELD = '${_SHIELD_HOME}/lib';
const { scrubPrompt } = require(path.join(SHIELD, 'pre-scrubber'));
const { LocalVault } = require(path.join(SHIELD, 'local-vault'));
const { HandleStore } = require(path.join(SHIELD, 'handle-store'));
const args = ${input_json};
let projectId;
try { projectId = require('node:crypto').createHash('sha256').update(process.cwd()).digest('hex').slice(0, 16); } catch { projectId = 'cli'; }
const vault = new LocalVault();
const store = new HandleStore({ projectId });
const out = [];
let red = 0;
for (const a of args) {
  const r = scrubPrompt(a, { projectId, vault, store });
  out.push(r.scrubbed);
  red += r.redactions;
}
console.log(JSON.stringify({ args: out, red }));
" 2>/dev/null) || { SHIELD_SCRUBBED_ARGS=("$@"); return 0; }

    # parse JSON output
    if ! command -v jq &>/dev/null; then
        SHIELD_SCRUBBED_ARGS=("$@")
        return 0
    fi
    SHIELD_REDACTION_COUNT=$(echo "${out_json}" | jq -r '.red // 0')
    if [[ "${SHIELD_REDACTION_COUNT}" -gt 0 ]]; then
        # 警告表示
        echo -e "${YELLOW}╔═══════════════════════════════════════════════════════════════╗${NC}" >&2
        echo -e "${YELLOW}║  ⚠ shield: CLI 引数に機密情報を ${SHIELD_REDACTION_COUNT} 件検出しました              ║${NC}" >&2
        echo -e "${YELLOW}║  → OS Keychain に安全保存し、ハンドル経由で処理します          ║${NC}" >&2
        echo -e "${YELLOW}║  注: ps aux で既に見えています。次回はプロンプト経由を推奨    ║${NC}" >&2
        echo -e "${YELLOW}║       ./soloptilink (引数なし) → 起動後にプロンプト入力        ║${NC}" >&2
        echo -e "${YELLOW}╚═══════════════════════════════════════════════════════════════╝${NC}" >&2
        # scrubbed args に置換
        readarray -t SHIELD_SCRUBBED_ARGS < <(echo "${out_json}" | jq -r '.args[]')
    else
        SHIELD_SCRUBBED_ARGS=("$@")
    fi
}

# -----------------------------------------------------------------------------
# Shield 配線状態チェック + first-run wizard 提案
# -----------------------------------------------------------------------------
sb_first_run_check() {
    if [[ ! -d "${_SHIELD_HOME}" ]]; then
        # ------------------------------------------------------------------
        # 2026-08-02 是正: ここは「実行しても直らない手順」を案内していた。
        #   入力保護層は配布物から外れているため、お客様の端末には最初から
        #   存在しない。それにもかかわらず「セットアップをもう一度実行して
        #   ください」と案内しており、何度実行しても状況は変わらなかった。
        #   直せない手順を案内し続けるのは、実態を隠すのと同じである。
        #   代わりに、その端末で実際に有効な自衛策だけを伝える。
        #   (毎回出すと本題が埋もれるため、24時間に1度だけ出す)
        # ------------------------------------------------------------------
        local _notice_stamp="${HOME}/.soloptilink/.input-guard-notice"
        local _now _last
        _now="$(date +%s)"
        _last=0
        [[ -f "${_notice_stamp}" ]] && _last="$(cat "${_notice_stamp}" 2>/dev/null || echo 0)"
        [[ "${_last}" =~ ^[0-9]+$ ]] || _last=0
        if (( _now - _last >= 86400 )); then
            echo -e "${YELLOW}ご確認のお願い: 対話画面に入力した文章は、そのまま AI の提供元へ送られます${NC}" >&2
            echo -e "${YELLOW}              この経路では、送る前に伏せ字へ置き換えることができません${NC}" >&2
            echo -e "${YELLOW}              API キー・パスワード・接続情報は貼り付けないでください${NC}" >&2
            echo -e "${YELLOW}              (起動時のご指示に含まれていた場合は、当社へ記録する前に伏せ字へ置き換えています)${NC}" >&2
            mkdir -p "$(dirname "${_notice_stamp}")" 2>/dev/null || true
            printf '%s' "${_now}" > "${_notice_stamp}" 2>/dev/null || true
        fi
        return 0
    fi

    # Claude Code settings.json に hook が配線されているか
    local cc_settings="${HOME}/.claude/settings.json"
    local already_init_marker="${HOME}/.shield/.initialized"
    if [[ -f "${cc_settings}" ]] && ! grep -q "user-prompt-submit.js" "${cc_settings}" 2>/dev/null; then
        # 未配線 + first-run wizard 未表示なら、対話型 wizard で誘導 (TTY のみ)
        if [[ ! -f "${already_init_marker}" ]] && [[ -t 0 ]] && [[ -t 1 ]]; then
            echo -e "${YELLOW}╔══════════════════════════════════════════════════════════════╗${NC}" >&2
            echo -e "${YELLOW}║  🛡 API キー保護機能の初回セットアップ案内                  ║${NC}" >&2
            echo -e "${YELLOW}╚══════════════════════════════════════════════════════════════╝${NC}" >&2
            echo "" >&2
            # ★2026-07-29 是正: 実装水準を超える断定表現を条件付き記述へ改めた。
            #   以前は「流出を防ぐ」「Anthropic に届く前に handle 化」「過去 transcript も自動
            #   sanitize」と書いていたが、これらは対応済みの経路と対応していない経路が混在する。
            #   検証可能な事実だけを、条件付きで書く。
            echo -e "${CYAN}API キーを扱う代表的な経路に、次のような保護を組み込むことができます:${NC}" >&2
            echo -e "  • 起動時の指示文に API キーの形が含まれていたときに、置き換えて扱います" >&2
            echo -e "  • キーそのものではなく、置き場所を指すための短い印字だけを利用に使います" >&2
            echo -e "  • OS の資格情報保管（macOS Keychain 等）に対応した保管経路を用意しています" >&2
            echo -e "  ※ 定義した形に一致した文字列だけが対象です。定義に無い形式は対象外です" >&2
            echo -e "  ※ 対話画面の中身については、外部への送信内容を書き換える手段が" >&2
            echo -e "     利用中のソフトウェア側に無いため、見つけた時点で処理を止めます" >&2
            echo "" >&2
            echo -e "${BOLD}今すぐ初期化しますか? [Y/n]:${NC}" >&2
            local ans=""
            read -r -t 30 ans 2>/dev/null || ans=""
            if [[ -z "$ans" || "$ans" == "Y" || "$ans" == "y" || "$ans" == "yes" ]]; then
                bash "${_SHIELD_HOME}/shield.sh" init
                touch "${already_init_marker}"
            else
                echo -e "${YELLOW}スキップ。後で実行: ${BOLD}${_SHIELD_HOME}/shield.sh init${NC}" >&2
                # 連続表示を避けるため marker 作成 (24h 保持)
                touch "${already_init_marker}"
                # 24h 後に再表示するため期限切れ判定用
                {
                  echo "skipped_at=$(date +%s)"
                  echo "expires_in=86400"
                } > "${already_init_marker}"
            fi
        else
            echo -e "${YELLOW}[shield] hooks 未配線 (ワンタイム警告):${NC}" >&2
            echo -e "${YELLOW}        ${BOLD}${_SHIELD_HOME}/shield.sh init${NC}" >&2
        fi
    fi

    # 24h 経過した skip marker は再表示
    if [[ -f "${already_init_marker}" ]] && grep -q "skipped_at" "${already_init_marker}" 2>/dev/null; then
        local skipped_at expires_in now
        skipped_at=$(grep "skipped_at" "${already_init_marker}" | cut -d= -f2)
        expires_in=$(grep "expires_in" "${already_init_marker}" | cut -d= -f2)
        now=$(date +%s)
        if [[ -n "${skipped_at}" && -n "${expires_in}" ]] && (( now - skipped_at > expires_in )); then
            rm -f "${already_init_marker}"
        fi
    fi
    return 0
}

# -----------------------------------------------------------------------------
# Shield proxy 状態チェック + 自動起動
# -----------------------------------------------------------------------------
sb_ensure_proxy_running() {
    if [[ ! -d "${_SHIELD_HOME}" ]]; then
        return 0
    fi
    # healthz をチェック
    if curl -fs --max-time 1 "http://127.0.0.1:${_SHIELD_PROXY_PORT}/healthz" >/dev/null 2>&1; then
        return 0
    fi
    # 未起動 → 自動起動
    if [[ -f "${_SHIELD_HOME}/shield.sh" ]]; then
        bash "${_SHIELD_HOME}/shield.sh" proxy start >/dev/null 2>&1 || true
    fi
}

# -----------------------------------------------------------------------------
# 統合 entry point
# -----------------------------------------------------------------------------
sb_bootstrap() {
    # 1. CLI 引数 redact (呼出側で配列として再代入する設計)
    sb_scrub_cli_args "$@"

    # 2. shield 配線 + proxy
    sb_first_run_check
    sb_ensure_proxy_running

    return 0
}
