#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI — Mac ダブルクリック起動インストーラ (.command)
# =============================================================================
# 顧客は Finder からこのファイルをダブルクリックするだけで:
#   1. Terminal.app が自動起動
#   2. 同梱パッケージ本体を ~/.soloptilink へ配置 (自己完結ZIP)
#      ※ 本体が無い場合のみ tar.gz / ネットワークから自動取得
#   3. アーキ(arm64/Intel)に合った Go ランチャーを配置
#   4. Claude Desktop の MCP サーバー設定を自動登録
#   5. 端末認証 (--activate) を自動チェーン
#   6. 完了画面まで自動誘導
#
# 配布レイアウト対応 (2026-06-11 リグレッション恒久対策):
#   現行の per-platform ZIP (SoloptiLinkAI_vX.Y_Mac-*.zip) は
#   「展開済みパッケージ本体 + soloptilink バイナリ + この .command」が
#   同一フォルダに並ぶ自己完結キット。本スクリプトはそのレイアウトを
#   第一に検出して動作する (旧 .command は tar.gz 同梱前提で現行ZIPでは
#   動かなかった)。tar.gz 同梱キット / ネットワーク取得にもフォールバックする。
#
# Compliance:
#   - PFP-029 (cmd 窓即閉じ事案) 同等の堅牢設計: STEP マーカー / END_PAUSE 必須
#   - PFP-044 (AppleDouble 事案) AppleDouble セルフクリーンアップ
#   - PFP-101 (0 バイト取得事案) ネットワーク取得は -L で 302 追従 / updates/check 経由
#   - macOS Gatekeeper 対応: xattr -d com.apple.quarantine で隔離属性除去
# =============================================================================
set -e
# 失敗時に Terminal を即閉じさせない (顧客が原因を読めるように)
trap '_EC=$?; _CMD="$BASH_COMMAND"; _LN=$LINENO; _RPT="$HOME/.soloptilink/lib/cognitive/customer-error-reporter.sh"; [ -f "$_RPT" ] && bash "$_RPT" "installer-failure" "Mac .command セットアップ失敗 line=$_LN exit=$_EC cmd=$_CMD" 2>/dev/null; echo ""; echo "==============================================================="; echo " ⚠️  エラーが発生しました (line=$_LN exit=$_EC)"; echo "     失敗コマンド: $_CMD"; echo "     上のメッセージをスクショして"; echo "     SoloptiLinkAI 社 (assist@soloptilink.com) に送付してください。"; echo "==============================================================="; echo "[Enterキーで閉じます]"; read -r _; exit 1' ERR

clear 2>/dev/null || true
KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
TS=$(date +%Y%m%d_%H%M%S)
API_BASE="https://admin.soloptilink.com/api/v1"

cat <<'BANNER'

  ╔════════════════════════════════════════════════════════════════╗
  ║         SoloptiLinkAI Setup (Mac版)                            ║
  ║         自動セットアップを開始します                          ║
  ║         (このウィンドウは自動で進みます。閉じずにお待ちください) ║
  ╚════════════════════════════════════════════════════════════════╝

BANNER

# ---------------------------------------------------------------------------
# STEP 0/6: 管理者端末の保護 (この .command は顧客用インストーラ)
# ---------------------------------------------------------------------------
if [ -f "$HOME/.soloptilink/.admin_mode" ]; then
    echo "  ⚠️  この端末は SoloptiLinkAI 管理者端末です。"
    echo "      顧客用インストーラの実行は中止しました (開発環境を保護)。"
    echo ""
    echo "[Enterキーで閉じます]"
    read -r _
    exit 0
fi

# ---------------------------------------------------------------------------
# STEP 1/6: macOS Gatekeeper 隔離属性の除去 (ダウンロードファイル特有)
# ---------------------------------------------------------------------------
echo "[STEP 1/6] セキュリティ属性のクリーンアップ"
find "$KIT_DIR" -name "*.command" -exec xattr -d com.apple.quarantine {} \; 2>/dev/null || true
find "$KIT_DIR" -name "*.sh" -exec xattr -d com.apple.quarantine {} \; 2>/dev/null || true
xattr -dr com.apple.quarantine "$KIT_DIR" 2>/dev/null || true
echo "  ✅ 完了"
echo ""

# ---------------------------------------------------------------------------
# STEP 2/6: AppleDouble (._*) / .DS_Store の除去 (PFP-044)
# ---------------------------------------------------------------------------
echo "[STEP 2/6] macOS メタデータの除去"
find "$KIT_DIR" -name '._*' -delete 2>/dev/null || true
find "$KIT_DIR" -name '.DS_Store' -delete 2>/dev/null || true
echo "  ✅ 完了"
echo ""

# ---------------------------------------------------------------------------
# [前提ソフト] Git / Node.js / Claude Code の確認と導入 (本体配置に先立って)
#   利用に必要な前提ソフトを、SoloptiLink 本体の配置の前に自動導入する。
#   各ソフトは「先に検出し、在ればスキップ」する冪等設計 (再実行しても無害)。
#     - Claude Code : 公式ネイティブインストーラ (curl | bash) で導入 (sudo不要・背景自動更新)
#     - Node.js     : 生成される業務システムの実行・ビルド検証に必要 (Claude Code 自体は Node 不要)
#     - Git         : SoloptiLink の bash 製 lib / chain.sh の動作に必要 (macOS は通常導入済み)
#   ★失敗しても中断しない: このフェーズだけ set +e で ERR トラップを抑止し、
#     未完了は「要対応」へ集約して完了画面で案内する (Windows 版と対称)。
# ---------------------------------------------------------------------------
echo "[前提ソフト] Git / Node.js / Claude Code を確認・導入"
PREREQ_ISSUES=()
add_issue() { PREREQ_ISSUES+=("$1|$2"); }   # "項目|対処"
set +e   # このフェーズは失敗しても中断しない (ERR トラップを抑止)

# 公式ネイティブ Claude Code は ~/.local/bin に入るため、現セッション PATH へ前置き
export PATH="$HOME/.local/bin:$PATH"

# --- Git (macOS は Command Line Tools 同梱で通常導入済み) ---
if command -v git >/dev/null 2>&1; then
    echo "  [skip] Git ($(git --version 2>/dev/null | head -1))"
else
    echo "  Git: 未導入 → コマンドラインデベロッパツールの導入を案内します"
    xcode-select --install >/dev/null 2>&1
    add_issue "Git" "画面に表示される『コマンドラインデベロッパツール』の導入を完了し、完了後にこの .command を再実行してください"
fi

# --- Node.js (v18 以上) ---
NODE_OK=0
if command -v node >/dev/null 2>&1; then
    NODE_MAJOR=$(node -v 2>/dev/null | sed -E 's/^v([0-9]+)\..*/\1/')
    if [ -n "$NODE_MAJOR" ] && [ "$NODE_MAJOR" -ge 18 ] 2>/dev/null; then
        echo "  [skip] Node.js ($(node -v 2>/dev/null))"
        NODE_OK=1
    else
        echo "  Node.js ($(node -v 2>/dev/null)) は古いため更新が必要です (必要: v18 以上)"
    fi
fi
if [ "$NODE_OK" -eq 0 ]; then
    if command -v brew >/dev/null 2>&1; then
        echo "  Node.js: Homebrew で導入します"
        brew install node >/dev/null 2>&1
        if command -v node >/dev/null 2>&1; then
            echo "  ✅ Node.js 導入完了 ($(node -v 2>/dev/null))"
        else
            add_issue "Node.js" "Homebrew での導入に失敗しました。https://nodejs.org/ja から LTS 版を導入してください"
        fi
    else
        echo "  Node.js: 未導入 (Homebrew 不在のため自動導入をスキップ)"
        add_issue "Node.js" "https://nodejs.org/ja から LTS 版を導入してください (または Homebrew を導入後に再実行)"
    fi
fi

# --- Claude Code (公式ネイティブインストーラ = sudo 不要・背景自動更新) ---
if command -v claude >/dev/null 2>&1; then
    echo "  [skip] Claude Code ($(claude --version 2>/dev/null | head -1))"
else
    echo "  Claude Code: 未導入 → 公式ネイティブインストーラで導入します (自動更新あり)"
    curl -fsSL https://claude.ai/install.sh | bash >/dev/null 2>&1
    export PATH="$HOME/.local/bin:$PATH"
    if command -v claude >/dev/null 2>&1; then
        echo "  ✅ Claude Code 導入完了 ($(claude --version 2>/dev/null | head -1))"
    else
        add_issue "Claude Code" "自動導入に失敗しました。ネットワーク(社内プロキシ/オフライン)をご確認のうえ再実行するか、assist@soloptilink.com へご連絡ください"
    fi
fi

set -e   # 以降は通常のエラー検出に戻す
echo ""

# ---------------------------------------------------------------------------
# STEP 3/6: 既存環境のバックアップ
# ---------------------------------------------------------------------------
echo "[STEP 3/6] 既存環境のバックアップ"
if [ -d "$HOME/.soloptilink" ]; then
    BK="$HOME/.soloptilink.bak.$TS"
    echo "  既存 ~/.soloptilink を $BK へ退避"
    mv "$HOME/.soloptilink" "$BK"
    echo "  ✅ バックアップ完了 (アンインストール時はこれを ~/.soloptilink に戻してください)"
else
    echo "  既存環境なし (新規インストール)"
fi
mkdir -p "$HOME/.soloptilink"

# ── 再インストール時の認証引継ぎ (PFP-119 / 2026-06-12) ──
# 退避した旧環境から認証系3ファイル (端末認証 activation.json / 端末識別
# .device_identity.json / ライセンスキャッシュ license.json) を新環境へ
# 自動コピー戻しし、再インストール後の再認証 (--activate やり直し) を不要にする。
# 配布物にはこれらの認証ファイルが含まれないため、後続の本体配置で上書きされない。
AUTH_CARRIED=0
if [ -n "${BK:-}" ] && [ -d "${BK:-}" ]; then
    for AUTH_FILE in activation.json .device_identity.json license.json; do
        if [ -f "$BK/$AUTH_FILE" ]; then
            if cp -p "$BK/$AUTH_FILE" "$HOME/.soloptilink/$AUTH_FILE" 2>/dev/null; then
                AUTH_CARRIED=$((AUTH_CARRIED+1))
            fi
        fi
    done
fi
if [ "$AUTH_CARRIED" -gt 0 ]; then
    echo "  ✅ 認証情報は引き継ぎました (再認証は不要です)"
fi
echo ""

# ---------------------------------------------------------------------------
# STEP 4/6: パッケージ本体の配置 (自己完結ZIP → tar.gz → ネットワークの順)
# ---------------------------------------------------------------------------
echo "[STEP 4/6] SoloptiLinkAI 本体を配置中..."

if [ -f "$KIT_DIR/chain.sh" ] && [ -d "$KIT_DIR/lib" ]; then
    # ── モードA: 自己完結ZIP (現行 per-platform ZIP の既定レイアウト) ──
    echo "  自己完結キットを検出 (展開済みパッケージ本体)"
    # この .command 自身と Mac専用補助ファイルは除外して本体をコピー
    ( cd "$KIT_DIR" && \
      find . -mindepth 1 -maxdepth 1 \
        ! -name 'SoloptiLinkAI-Setup.command' \
        ! -name 'はじめに_Mac.txt' \
        ! -name '.DS_Store' \
        -exec cp -R {} "$HOME/.soloptilink/" \; )
    echo "  ✅ 本体を ~/.soloptilink へ配置完了"
else
    # ── モードB: tar.gz 同梱キット ──
    PAYLOAD_TGZ=$(ls "$KIT_DIR"/../soloptilink-update-v*.tar.gz "$KIT_DIR"/soloptilink-update-v*.tar.gz 2>/dev/null | sort -V | tail -1)
    if [ -n "$PAYLOAD_TGZ" ] && [ -f "$PAYLOAD_TGZ" ]; then
        echo "  オフライン配布物を検出: $(basename "$PAYLOAD_TGZ")"
        tar xzf "$PAYLOAD_TGZ" -C "$HOME/.soloptilink" --strip-components=1
        echo "  ✅ 展開完了"
    else
        # ── モードC: ネットワーク取得 (最終手段 / PFP-101: -L で302追従) ──
        echo "  本体が見つからないため、ネットワーク経由で取得します..."
        # HTTP status と本文を分離取得。stderr は退避して顧客可視に出さない。
        _NET_TMP=$(mktemp -t solai_net.XXXXXX 2>/dev/null || echo "/tmp/solai_net.$$")
        _NET_ERR="${_NET_TMP}.err"
        HTTP_CODE=$(curl -sSL --max-time 30 -o "$_NET_TMP" -w "%{http_code}" \
            "$API_BASE/updates/check?version=0&os=darwin&arch=$(uname -m | sed 's/x86_64/amd64/')" \
            2>"$_NET_ERR" || echo "000")
        LATEST_JSON=$(cat "$_NET_TMP" 2>/dev/null || echo "")
        TAR_URL=$(echo "$LATEST_JSON" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('package_url') or '')" 2>/dev/null || echo "")
        rm -f "$_NET_TMP" "$_NET_ERR" 2>/dev/null || true
        if [ -z "$TAR_URL" ]; then
            echo ""
            echo "  ⚠️  本体を取得できませんでした。"
            if [ "$HTTP_CODE" = "000" ]; then
                echo "      インターネットに接続できていない可能性があります。"
                echo "      Wi-Fi や有線接続、社内プロキシ / VPN の設定をご確認のうえ、"
                echo "      再度 SoloptiLinkAI-Setup.command を実行してください。"
            elif [ "$HTTP_CODE" -ge 500 ] 2>/dev/null; then
                echo "      配信サーバー側で一時的な問題が発生している可能性があります (応答コード: $HTTP_CODE)。"
                echo "      数分おいて再度実行してください。解消しない場合は下記までご連絡ください。"
            elif [ "$HTTP_CODE" -ge 400 ] 2>/dev/null; then
                echo "      配信サーバーへのアクセスが許可されていません (応答コード: $HTTP_CODE)。"
                echo "      ご契約状況の確認が必要な可能性があります。下記までご連絡ください。"
            elif [ "$HTTP_CODE" = "200" ]; then
                echo "      配信情報の読み取りに失敗しました (応答: $HTTP_CODE / 本体パッケージ URL 未指定)。"
                echo "      配信側の準備が完了していない可能性があります。下記までご連絡ください。"
            else
                echo "      配信サーバーから想定外の応答を受け取りました (応答コード: $HTTP_CODE)。"
                echo "      下記までご連絡ください。"
            fi
            echo ""
            echo "      連絡先: assist@soloptilink.com"
            echo "      お手数ですが上記の応答コードを本文にお書き添えください。"
            exit 1
        fi
        echo "  ダウンロード: $TAR_URL"
        curl -fsSL --max-time 300 -o "$HOME/.soloptilink/_latest.tar.gz" "$TAR_URL"
        tar xzf "$HOME/.soloptilink/_latest.tar.gz" -C "$HOME/.soloptilink" --strip-components=1
        rm -f "$HOME/.soloptilink/_latest.tar.gz"
        echo "  ✅ ダウンロード+展開完了"
    fi
fi

# AppleDouble 再除去 + 実行権限付与
find "$HOME/.soloptilink" -name '._*' -delete 2>/dev/null || true
find "$HOME/.soloptilink" -name '.DS_Store' -delete 2>/dev/null || true
chmod +x "$HOME/.soloptilink"/chain.sh 2>/dev/null || true
chmod +x "$HOME/.soloptilink"/*.sh 2>/dev/null || true
echo ""

# ---------------------------------------------------------------------------
# STEP 5/6: Goランチャーの配置 (アーキ自動判定)
# ---------------------------------------------------------------------------
echo "[STEP 5/6] Goランチャーを配置"
ARCH=$(uname -m)
case "$ARCH" in
    arm64)  LAUNCHER_NAME="soloptilink-darwin-arm64" ;;
    x86_64) LAUNCHER_NAME="soloptilink-darwin-amd64" ;;
    *) echo "  ⚠️  未対応のアーキ: $ARCH"; exit 1 ;;
esac

if [ -f "$HOME/.soloptilink/soloptilink" ]; then
    # 自己完結ZIP は arch 専用バイナリを soloptilink として同梱済み
    :
elif [ -f "$KIT_DIR/$LAUNCHER_NAME" ]; then
    cp "$KIT_DIR/$LAUNCHER_NAME" "$HOME/.soloptilink/soloptilink"
elif [ -f "$KIT_DIR/Mac/$LAUNCHER_NAME" ]; then
    cp "$KIT_DIR/Mac/$LAUNCHER_NAME" "$HOME/.soloptilink/soloptilink"
else
    LAUNCHER_URL="https://github.com/onukih-design/soloptilink-releases/releases/latest/download/${LAUNCHER_NAME}"
    echo "  ダウンロード: $LAUNCHER_URL"
    curl -fsSL --max-time 120 -o "$HOME/.soloptilink/soloptilink" "$LAUNCHER_URL"
fi
chmod +x "$HOME/.soloptilink/soloptilink"
xattr -d com.apple.quarantine "$HOME/.soloptilink/soloptilink" 2>/dev/null || true
echo "  ✅ アーキ: $ARCH 用バイナリを配置"
echo ""

# ---------------------------------------------------------------------------
# STEP 5.5/6: 自動更新フックの登録 (2026-06-15 Windows 導入事案 恒久対策)
# ---------------------------------------------------------------------------
# 【鶏卵デッドロックの解消】従来、自動更新フック (~/.claude/settings.json) を
# 登録するのは移行スクリプト 1本だけで、それを呼ぶのは「フックで起動される
# auto-update.sh 自身」だった。そのため新規導入時は誰もフックを登録せず、
# 一度も手動更新しない限り自動更新が永遠に始まらなかった。
# → 導入のこの瞬間にフックを登録し、自動更新の点火を保証する。冪等。
echo "[STEP 5.5/6] 自動更新を有効化"
_HOOK_OK=0
# 第一経路: ランチャー経由の冪等登録 (全OS共通・テスト済みの単一実装)
if [ -x "$HOME/.soloptilink/soloptilink" ]; then
    "$HOME/.soloptilink/soloptilink" --register-autoupdate-hook >/dev/null 2>&1 && _HOOK_OK=1
fi
# 第二経路 (保険): 移行スクリプト直接実行
if [ "$_HOOK_OK" -eq 0 ] && [ -f "$HOME/.soloptilink/migration/v2027_hook_install.sh" ]; then
    bash "$HOME/.soloptilink/migration/v2027_hook_install.sh" >/dev/null 2>&1 && _HOOK_OK=1
fi
if [ "$_HOOK_OK" -eq 1 ]; then
    echo "  ✅ 以降 Claude Code 起動時に自動で最新版を取得します"
else
    echo "  ⚠️  自動更新の有効化に失敗しました (手動更新: cd ~/.soloptilink && ./soloptilink --update)"
fi

# ---------------------------------------------------------------------------
# STEP 5.6/6: 品質・信頼性フックの登録 (2026-08-01 実測監査 指摘1 の恒久対策)
# ---------------------------------------------------------------------------
# 【何が壊れていたか】ここで名指しで実行していたのは v2027 (自動更新) の1本だけだった。
#   そのため v2027 以降に追加された遡及配線 (品質ゲート・エラーゼロ化4本柱の結線層など) は
#   【新規導入の端末に一度も適用されない】。実測で、4本柱の結線層 7エントリが顧客端末の
#   ~/.claude/settings.json に一つも入っていないことが判明した (開発機でしか動いていなかった)。
#   名指し列挙は「今後増えるもの」を必ず取りこぼす構造なので、ここは列挙をやめて
#   migration/ 配下の全スクリプトを実行する (各スクリプトが自前で冪等性を保証している)。
echo "[STEP 5.6/6] 品質・信頼性フックを登録"
_MIG_N=0
if [ -d "$HOME/.soloptilink/migration" ]; then
    for _mig in "$HOME/.soloptilink/migration/"v*.sh; do
        [ -f "$_mig" ] || continue
        # v2027 は直前で実行済み (二重実行しても冪等だが、無駄な処理を避ける)
        case "$_mig" in *v2027_hook_install.sh) continue ;; esac
        bash "$_mig" >/dev/null 2>&1 || true
        _MIG_N=$((_MIG_N + 1))
    done
fi
if [ "$_MIG_N" -gt 0 ]; then
    echo "  ✅ 品質・信頼性の自動チェックを有効化しました (${_MIG_N} 項目)"
else
    echo "  ℹ️  追加で有効化する項目はありませんでした"
fi
echo ""

# ---------------------------------------------------------------------------
# STEP 6/6: Claude Desktop MCP 設定 + 端末認証起動
# ---------------------------------------------------------------------------
echo "[STEP 6/6] Claude Desktop MCP 自動設定 + 端末認証"

CLAUDE_CONFIG="$HOME/Library/Application Support/Claude/claude_desktop_config.json"
mkdir -p "$(dirname "$CLAUDE_CONFIG")"
if [ -f "$CLAUDE_CONFIG" ]; then
    cp "$CLAUDE_CONFIG" "$CLAUDE_CONFIG.bak.$TS"
    echo "  既存 claude_desktop_config.json をバックアップ: $CLAUDE_CONFIG.bak.$TS"
fi

# python3 で安全に MERGE (既存 mcpServers を保持)
SOLOPTILINK_BIN="$HOME/.soloptilink/soloptilink" python3 - "$CLAUDE_CONFIG" <<'PYEOF'
import json, sys, os
cfg_path = sys.argv[1]
bin_path = os.environ['SOLOPTILINK_BIN']
if os.path.exists(cfg_path) and os.path.getsize(cfg_path) > 0:
    try:
        with open(cfg_path) as f:
            cfg = json.load(f)
    except Exception:
        cfg = {}
else:
    cfg = {}
cfg.setdefault('mcpServers', {})
cfg['mcpServers']['soloptilink'] = {'command': bin_path, 'args': ['--mcp-server']}
with open(cfg_path, 'w') as f:
    json.dump(cfg, f, indent=2, ensure_ascii=False)
print("  ✅ Claude Desktop に soloptilink MCP サーバーを登録")
PYEOF

echo ""
echo "  端末認証を開始します。メールアドレスの入力を求められます。"
echo ""
sleep 2

# 端末認証を自動チェーン
# 2026-07-13: 承認待ちポーリング(最大30分)はインストーラ内では行わない
# (登録だけ行い即座に完了画面へ。承認後は自動で有効になる)。
cd "$HOME/.soloptilink"
SOLOPTILINK_ACTIVATE_NO_WAIT=1 ./soloptilink --activate || {
    echo ""
    echo "  ⚠️  認証が完了しませんでした。再度このファイルをダブルクリックするか、"
    echo "      Terminal で以下を実行してください:"
    echo "        cd ~/.soloptilink && ./soloptilink --activate"
    echo ""
    echo "[Enterキーで閉じます]"
    read -r _
    exit 1
}

# ---------------------------------------------------------------------------
# 完了画面
# ---------------------------------------------------------------------------
cat <<'DONE'

  ╔════════════════════════════════════════════════════════════════╗
  ║                                                                ║
  ║      ✅ SoloptiLinkAI セットアップ完了！                        ║
  ║                                                                ║
  ╚════════════════════════════════════════════════════════════════╝

  次のステップ:

    1. Claude Desktop / Claude Code を一度終了して、再起動してください
       (MCP サーバー設定を読み込むため)

    2. 起動後、チャット欄に以下のように入力:
         /soloptilink-boost CRM作って

    3. 管理者承認がまだの場合は、SoloptiLinkAI 社からの
       承認通知メールをお待ちください (通常1営業日以内)

  ステータス確認:
    cd ~/.soloptilink && ./soloptilink --status

  サポート: assist@soloptilink.com

DONE

# 動作確認 (各前提ソフトのバージョンを実測表示)
echo "  ── 動作確認 ──"
export PATH="$HOME/.local/bin:$PATH"
for c in git node npm claude; do
    if command -v "$c" >/dev/null 2>&1; then
        printf "    [ OK ] %-7s: %s\n" "$c" "$($c --version 2>/dev/null | head -1)"
    else
        printf "    [要対応] %-7s: 確認できません (再起動後に再確認してください)\n" "$c"
    fi
done
echo ""

# 前提ソフトの要対応一覧 (自動完了できなかったもの)
if [ "${#PREREQ_ISSUES[@]}" -gt 0 ]; then
    echo "  【要対応】以下は自動で完了できませんでした:"
    for it in "${PREREQ_ISSUES[@]}"; do
        echo "    ・${it%%|*}: ${it#*|}"
    done
    echo "    ※ まず上記を解消してから、次のステップへお進みください。"
    echo ""
fi

# Claude Code ログインと有料プランの注意 (Desktop / ターミナル共通)
echo "  ── Claude Code のログイン ──"
echo "    初回のみログインが必要です (Claude Desktop を起動、またはターミナルで claude)。"
echo "    ※ ご利用には有料の Claude プラン (Pro / Max / Team / Enterprise) または"
echo "      API のご契約が必要です。無料プランでは Claude Code は使えません。"
echo ""

echo "[Enterキーで閉じます]"
read -r _
exit 0
