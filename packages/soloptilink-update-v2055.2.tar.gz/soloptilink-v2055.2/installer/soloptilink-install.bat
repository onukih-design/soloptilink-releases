@echo off
setlocal EnableExtensions
set "RC=1"

echo.
echo =================================================================
echo  SoloptiLinkAI  Windows Setup
echo  (Please wait - this window proceeds automatically)
echo =================================================================
echo.

echo [STEP 1/3] Checking PowerShell
where powershell >nul 2>&1
if errorlevel 1 (
  echo [FAIL] PowerShell not found. Windows 10 or later is required.
  goto END_PAUSE
)
echo  [ OK ] PowerShell is available

echo.
echo [STEP 2/3] Launching installer (Japanese guidance appears below)
set "PS1=%~dp0soloptilink-install.ps1"
if not exist "%PS1%" (
  echo [FAIL] soloptilink-install.ps1 was not found next to this file.
  echo        Please keep this .bat and soloptilink-install.ps1 in the same folder.
  rem Japanese guidance is rendered via PowerShell EncodedCommand.
  rem This .bat must stay ASCII-only (PFP-108 bat hygiene invariant).
  powershell -NoProfile -EncodedCommand VwByAGkAdABlAC0ASABvAHMAdAAgACcAJwAKAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAnAFsAqDDpMPwwXQAgAKQw8zC5MMgw/DDpMPwwLGdTTyAAKABzAG8AbABvAHAAdABpAGwAaQBuAGsALQBpAG4AcwB0AGEAbABsAC4AcABzADEAKQAgAEwwi4lkMEswijB+MFswkzACMCcACgBXAHIAaQB0AGUALQBIAG8AcwB0ACAAJwBaAEkAUAAgANUwoTCkMOswkjDzU68w6jDDMK8wVzBmMAwwWTB5MGYwVVyLlQ0wkjB4kHMwATBVXIuVjF9uMNUwqTDrMMAwbjAtTmcwJwAKAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAnAFMwbjDVMKEwpDDrMJIwgjBGMABOpl7AMNYw6zCvMOowwzCvMFcwZjBPMGAwVTBEMAIwJwAKAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAnAEow8FaKMG4wNFgIVG8wtTDdMPwwyDCTeuNTeDA6ACAAcwB1AHAAcABvAHIAdABAAHMAbwBsAG8AcAB0AGkAbABpAG4AawAuAGMAbwBtACcA
  goto END_PAUSE
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" %*
set "RC=%ERRORLEVEL%"

echo.
echo [STEP 3/3] Finished (exit code = %RC%)

:END_PAUSE
echo.
echo =================================================================
echo  Press any key to close this window...
where powershell >nul 2>&1 && powershell -NoProfile -EncodedCommand VwByAGkAdABlAC0ASABvAHMAdAAgACcAIABTMG4wpjCjMPMwyTCmMJIwiZVYMIswazBvMAEwRDBaMIwwSzBuMK0w/DCSMLxiVzBmME8wYDBVMEQwLgAuAC4AJwA=
echo =================================================================
pause >nul
endlocal
exit /b %RC%
