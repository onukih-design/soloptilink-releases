/**
 * 運用手順書ジェネレータ
 *
 * 責務:
 *   日本SI標準の運用手順書 (8章構成) を生成。日次/週次/月次/年次の運用作業、
 *   業種別運用差分 (建設/製造/医療/介護/金融/公共/不動産)、アカウント管理、
 *   バックアップ・リストア、セキュリティ運用、エスカレーションを網羅する。
 *
 * 入力: OperationsManualInput (システム名・業種・サービス時間・連絡先 等)
 * 出力: OperationsManual (8章 + Markdown整形関数)
 */

export type IndustryKey =
  | 'construction'
  | 'manufacturing'
  | 'healthcare'
  | 'longterm_care'
  | 'finance'
  | 'public_sector'
  | 'real_estate'
  | 'retail'
  | 'food_service'
  | 'transport'
  | 'education'
  | 'it'
  | 'default';

export type CoverageWindow = '24x365' | 'business-hours' | 'extended';
export type ClientType = '民間' | '公共' | '自治体';

export interface ContactCard {
  name: string;
  role: string;
  phone?: string;
  email?: string;
  hours?: string;
}

export interface OperationsContacts {
  primary: ContactCard;
  secondary: ContactCard;
  manager_escalation: ContactCard;
  vendor_support: ContactCard;
  data_protection_officer?: ContactCard;
}

export interface RetentionPolicy {
  backup_days: number;
  audit_log_years: number;
  application_log_days: number;
}

export interface OperationsManualInput {
  system_name: string;
  industry?: IndustryKey;
  client_type?: ClientType;
  coverage?: CoverageWindow;
  contacts: OperationsContacts;
  retention?: Partial<RetentionPolicy>;
  architecture_summary?: string;
  primary_users?: string[];
  business_hours_jst?: string;
  generated_at?: string;
}

export interface OperationsTask {
  task_id: string;
  description: string;
  responsible: 'primary' | 'secondary' | 'auto';
  expected_duration_min: number;
  prerequisites: string[];
  steps: string[];
  failure_action: string;
}

export interface OperationsManualChapter {
  chapter_no: number;
  title_ja: string;
  body_md: string;
  tasks: OperationsTask[];
}

export interface OperationsManual {
  meta: {
    system_name: string;
    industry: IndustryKey;
    industry_ja: string;
    client_type: ClientType;
    coverage: CoverageWindow;
    generated_at: string;
    version: string;
  };
  retention: RetentionPolicy;
  contacts: OperationsContacts;
  chapters: OperationsManualChapter[];
}

const INDUSTRY_JA_MAP: Record<IndustryKey, string> = {
  construction: '建設業',
  manufacturing: '製造業',
  healthcare: '医療',
  longterm_care: '介護',
  finance: '金融',
  public_sector: '公共/自治体',
  real_estate: '不動産業',
  retail: '小売業',
  food_service: '飲食業',
  transport: '運輸業',
  education: '教育',
  it: 'IT/SES',
  default: '汎用業務システム',
};

const DEFAULT_RETENTION: Record<IndustryKey, RetentionPolicy> = {
  healthcare: { backup_days: 35, audit_log_years: 7, application_log_days: 90 },
  longterm_care: { backup_days: 35, audit_log_years: 5, application_log_days: 90 },
  finance: { backup_days: 90, audit_log_years: 10, application_log_days: 180 },
  public_sector: { backup_days: 60, audit_log_years: 10, application_log_days: 180 },
  construction: { backup_days: 30, audit_log_years: 10, application_log_days: 60 },
  manufacturing: { backup_days: 30, audit_log_years: 5, application_log_days: 60 },
  real_estate: { backup_days: 30, audit_log_years: 5, application_log_days: 60 },
  retail: { backup_days: 30, audit_log_years: 5, application_log_days: 60 },
  food_service: { backup_days: 30, audit_log_years: 5, application_log_days: 60 },
  transport: { backup_days: 30, audit_log_years: 5, application_log_days: 60 },
  education: { backup_days: 30, audit_log_years: 5, application_log_days: 60 },
  it: { backup_days: 30, audit_log_years: 3, application_log_days: 30 },
  default: { backup_days: 30, audit_log_years: 5, application_log_days: 60 },
};

/** 業種別の追加運用タスク。共通章に追記される。 */
const INDUSTRY_OPERATIONAL_ADDITIONS: Record<IndustryKey, string[]> = {
  healthcare: [
    '【月10日】レセプト電算ファイル提出 (オンライン請求)',
    '【月次】HPKI証明書有効期限確認 (3ヶ月前から更新着手)',
    '【週次】3省2GL関連 監査ログサマリ確認 (アクセス権変更/特権操作)',
    '【日次】電子カルテ連携IF 死活監視 (HL7 / FHIR)',
  ],
  longterm_care: [
    '【月10日】LIFE (科学的介護情報システム) データ送信',
    '【3年毎】介護報酬改定対応リリース (4月施行)',
    '【月次】科学的介護指標レポート出力',
    '【年次】事業所番号・指定更新確認',
  ],
  finance: [
    '【日次】全銀フォーマット送信ファイル整合チェック',
    '【月次】FISC安全対策基準 監査項目確認',
    '【月次】反社会的勢力データベース更新適用',
    '【年次】内部監査・外部監査受審',
  ],
  public_sector: [
    '【月次】検査調書整備・提出',
    '【月次】政府情報システム標準ガイドライン群 適合状況確認',
    '【年次】会計法29条の3 支払実績確認・年度末締め',
    '【随時】個人情報保護評価書 (PIA) 更新',
  ],
  construction: [
    '【月次】工事台帳 出力・10年保管確認',
    '【月次】CCUS (建設キャリアアップシステム) データ連携確認',
    '【月次】建退共 納付実績連携',
    '【年次】建設業許可更新 (5年毎)',
  ],
  manufacturing: [
    '【日次】EDI連携 死活監視',
    '【週次】MRP夜間バッチ 結果サマリ確認',
    '【月次】在庫棚卸 突合確認',
    '【年次】ISO 9001/14001 監査対応',
  ],
  real_estate: [
    '【月次】レインズ連携状況確認',
    '【月次】35条書面PDF 保管確認',
    '【3-5年】宅建業者免許更新',
  ],
  retail: [
    '【日次】POSレジ売上データ取込確認',
    '【月次】在庫評価レポート出力',
    '【月次】軽減税率対応設定確認',
  ],
  food_service: [
    '【月次】HACCP関連温度・衛生記録',
    '【日次】POS売上整合確認',
    '【月次】食品衛生責任者氏名確認',
  ],
  transport: [
    '【日次】GPS/タコグラフデータ取込確認',
    '【月次】運行管理者報告書確認',
    '【年次】事業用自動車の点検整備記録確認',
  ],
  education: [
    '【月次】学籍データ整合確認',
    '【年次】指導要録の電子化保管確認',
    '【年次】学習指導要領改定対応リリース',
  ],
  it: [
    '【週次】社内SLA達成率確認',
    '【月次】コスト配賦レポート',
    '【年次】契約更新条件見直し',
  ],
  default: [
    '【日次】定例ヘルスチェック確認',
    '【月次】月次レポート出力',
  ],
};

const COVERAGE_DESCRIPTIONS: Record<CoverageWindow, string> = {
  '24x365': '24時間365日 (土日祝・年末年始含む常時運用)',
  'business-hours': '平日 9:00〜18:00 (土日祝・年末年始除く)',
  'extended': '平日 8:00〜22:00 + 土日祝は要相談 (ただし夜間バッチ監視は24h)',
};

export function generateOperationsManual(input: OperationsManualInput): OperationsManual {
  const industry: IndustryKey = input.industry ?? 'default';
  const client_type: ClientType = input.client_type ?? '民間';
  const coverage: CoverageWindow = input.coverage ?? '24x365';
  const generated_at = input.generated_at ?? new Date().toISOString();
  const retention: RetentionPolicy = {
    ...DEFAULT_RETENTION[industry],
    ...input.retention,
  };

  const chapters: OperationsManualChapter[] = [
    buildSystemOverview(input, industry, client_type, coverage),
    buildArchitectureChapter(input),
    buildDailyOperations(input, industry),
    buildScheduledOperations(input, industry),
    buildAccountManagement(input, industry, client_type),
    buildBackupRestore(input, retention, industry),
    buildSecurityOperations(input, retention, industry, client_type),
    buildEscalationContacts(input.contacts, coverage),
  ];

  return {
    meta: {
      system_name: input.system_name,
      industry,
      industry_ja: INDUSTRY_JA_MAP[industry],
      client_type,
      coverage,
      generated_at,
      version: '1.0.0',
    },
    retention,
    contacts: input.contacts,
    chapters,
  };
}

function buildSystemOverview(
  input: OperationsManualInput,
  industry: IndustryKey,
  client_type: ClientType,
  coverage: CoverageWindow
): OperationsManualChapter {
  const lines: string[] = [];
  lines.push(`本書は「${input.system_name}」の運用手順を定めるものである。`);
  lines.push('');
  lines.push(`- **業種**: ${INDUSTRY_JA_MAP[industry]}`);
  lines.push(`- **顧客タイプ**: ${client_type}`);
  lines.push(`- **サービス時間**: ${COVERAGE_DESCRIPTIONS[coverage]}`);
  lines.push(`- **業務時間**: ${input.business_hours_jst ?? '平日 9:00〜18:00 JST'}`);
  if (input.primary_users?.length) {
    lines.push(`- **主要利用者**: ${input.primary_users.join(' / ')}`);
  }
  return {
    chapter_no: 1,
    title_ja: 'システム概要',
    body_md: lines.join('\n'),
    tasks: [],
  };
}

function buildArchitectureChapter(input: OperationsManualInput): OperationsManualChapter {
  const lines: string[] = [];
  lines.push(input.architecture_summary ?? '本システムは Web (Next.js) + API (Node.js) + DB (PostgreSQL) + 監視 (Datadog) の3層構成である。');
  lines.push('');
  lines.push('### 構成要素');
  lines.push('- フロントエンド: Web (Next.js)');
  lines.push('- バックエンドAPI: Node.js (TypeScript)');
  lines.push('- データベース: PostgreSQL (マスタDB) + Redis (キャッシュ)');
  lines.push('- 監視: メトリクス (Prometheus/Datadog) + ログ集約 (CloudWatch) + アラート (PagerDuty)');
  lines.push('- バックアップ: 日次フル + 1時間毎WAL');
  lines.push('');
  lines.push('### 監視ポイント');
  lines.push('- ヘルスチェック: `/api/health` (200 OK + DB疎通)');
  lines.push('- p95応答時間: 3秒以下');
  lines.push('- エラー率: 1%以下');
  lines.push('- DBコネクション数: 上限の80%以下');
  return {
    chapter_no: 2,
    title_ja: 'アーキテクチャ',
    body_md: lines.join('\n'),
    tasks: [],
  };
}

function buildDailyOperations(input: OperationsManualInput, industry: IndustryKey): OperationsManualChapter {
  const tasks: OperationsTask[] = [
    {
      task_id: 'D-01',
      description: 'システム起動確認',
      responsible: 'auto',
      expected_duration_min: 5,
      prerequisites: ['監視ダッシュボードへのアクセス権'],
      steps: [
        'ヘルスチェックエンドポイント /api/health の200応答を確認',
        'ダッシュボード上のSLOメトリクスを確認 (前日比劣化なし)',
        '異常時はSEV判定後 Runbook 参照',
      ],
      failure_action: 'SEV2として Runbook §認証/API応答 を実行',
    },
    {
      task_id: 'D-02',
      description: 'バックアップ取得結果の確認',
      responsible: 'primary',
      expected_duration_min: 5,
      prerequisites: ['前日24:00時点のジョブログ'],
      steps: [
        '日次バックアップジョブの SUCCESS ステータス確認',
        '取得サイズが平均±20%以内であること',
        '転送先ストレージの空き容量を確認',
      ],
      failure_action: 'バックアップ失敗時はSEV2として即時調査・再実行',
    },
    {
      task_id: 'D-03',
      description: 'エラーログ確認',
      responsible: 'primary',
      expected_duration_min: 10,
      prerequisites: ['ログ集約システムへのアクセス権'],
      steps: [
        'ERROR/CRITICAL ログを抽出',
        '前日比で増加していないか確認',
        '5xx エラーの発生箇所を確認',
      ],
      failure_action: '異常増加時はチケット起票 + チームリードに通知',
    },
  ];

  const lines: string[] = [];
  lines.push('日次運用は毎営業日の朝9:30までに完了させる。');
  lines.push('');
  for (const t of tasks) {
    lines.push(`### ${t.task_id} ${t.description}`);
    lines.push(`- 担当: ${formatResponsible(t.responsible)}`);
    lines.push(`- 想定所要時間: ${t.expected_duration_min}分`);
    lines.push(`- 前提: ${t.prerequisites.join(' / ')}`);
    lines.push('- 手順:');
    t.steps.forEach((s, i) => lines.push(`  ${i + 1}. ${s}`));
    lines.push(`- 異常時: ${t.failure_action}`);
    lines.push('');
  }
  const additions = INDUSTRY_OPERATIONAL_ADDITIONS[industry].filter((a) => a.startsWith('【日次】'));
  if (additions.length) {
    lines.push('### 業種別 日次追加項目');
    additions.forEach((a) => lines.push(`- ${a}`));
  }
  return {
    chapter_no: 3,
    title_ja: '日常運用 (日次)',
    body_md: lines.join('\n'),
    tasks,
  };
}

function buildScheduledOperations(input: OperationsManualInput, industry: IndustryKey): OperationsManualChapter {
  const tasks: OperationsTask[] = [
    {
      task_id: 'W-01',
      description: '週次バッチ実行確認',
      responsible: 'primary',
      expected_duration_min: 15,
      prerequisites: ['週次バッチジョブログ'],
      steps: [
        'ジョブステータスがSUCCESSであること確認',
        '対象データ件数が想定範囲内 (前週±10%以内) であること確認',
        '集計結果サマリを担当部門にメール送付',
      ],
      failure_action: '失敗時はSEV3として再実行 + 担当部門への遅延連絡',
    },
    {
      task_id: 'M-01',
      description: '月次集計バッチ実行',
      responsible: 'primary',
      expected_duration_min: 60,
      prerequisites: ['月末締めデータ確定'],
      steps: [
        '締め日翌営業日に月次集計バッチを起動',
        '対象月の取引が全件処理されていることを確認',
        '会計部門・経営層に月次レポートPDFを配布',
      ],
      failure_action: '失敗時はSEV2として即時再実行 + 経理部門通知',
    },
    {
      task_id: 'M-02',
      description: '月次容量・性能レポート',
      responsible: 'primary',
      expected_duration_min: 30,
      prerequisites: ['監視データ'],
      steps: [
        'ディスク使用率・DB容量・APIレイテンシ・エラー率の月次推移を集計',
        '閾値超過項目の有無を確認',
        '保守チームレビュー会議に提出',
      ],
      failure_action: '閾値超過があれば対応チケット起票',
    },
    {
      task_id: 'Y-01',
      description: '年次データ整理 (アーカイブ)',
      responsible: 'primary',
      expected_duration_min: 240,
      prerequisites: ['法定保存年限の確認'],
      steps: [
        '法定保存年限を超えたデータをアーカイブストレージへ移動',
        'アーカイブの整合性確認 (チェックサム照合)',
        'アーカイブ移動結果を社内に報告',
      ],
      failure_action: '整合性NGの場合は移動を中止し再取得',
    },
  ];
  const lines: string[] = [];
  lines.push('週次・月次・年次の定期運用作業を実施する。');
  lines.push('');
  for (const t of tasks) {
    lines.push(`### ${t.task_id} ${t.description}`);
    lines.push(`- 担当: ${formatResponsible(t.responsible)} / 想定: ${t.expected_duration_min}分`);
    lines.push('- 手順:');
    t.steps.forEach((s, i) => lines.push(`  ${i + 1}. ${s}`));
    lines.push(`- 異常時: ${t.failure_action}`);
    lines.push('');
  }
  const additions = INDUSTRY_OPERATIONAL_ADDITIONS[industry].filter((a) => !a.startsWith('【日次】'));
  if (additions.length) {
    lines.push('### 業種別 定期追加項目');
    additions.forEach((a) => lines.push(`- ${a}`));
  }
  return {
    chapter_no: 4,
    title_ja: '定期運用 (週次/月次/年次)',
    body_md: lines.join('\n'),
    tasks,
  };
}

function buildAccountManagement(
  input: OperationsManualInput,
  industry: IndustryKey,
  client_type: ClientType
): OperationsManualChapter {
  const tasks: OperationsTask[] = [
    {
      task_id: 'A-01',
      description: '入社時アカウント発行',
      responsible: 'primary',
      expected_duration_min: 30,
      prerequisites: ['人事からの入社通知書', '上長の権限申請'],
      steps: [
        '管理画面からアカウント作成',
        '初期パスワードを送付 (初回ログインで強制変更)',
        'MFAを設定',
        '権限ロールを上長申請に基づき設定',
      ],
      failure_action: '権限申請の不備があれば人事・上長に確認',
    },
    {
      task_id: 'A-02',
      description: '退職時アカウント無効化',
      responsible: 'primary',
      expected_duration_min: 15,
      prerequisites: ['人事からの退職通知書'],
      steps: [
        '退職日 18:00 までにアカウントを無効化',
        '退職者所有データを上長へ引き渡し',
        '監査ログに無効化処理を記録',
      ],
      failure_action: '無効化遅延はインシデント扱い',
    },
    {
      task_id: 'A-03',
      description: '半期アカウント棚卸',
      responsible: 'primary',
      expected_duration_min: 240,
      prerequisites: ['人事マスタ最新版'],
      steps: [
        '全アカウント一覧を出力',
        '人事マスタと突合 (退職者・休職者・異動者の権限状態確認)',
        '差異があれば是正 + 監査記録',
      ],
      failure_action: '差異多数の場合は経営層へ報告',
    },
  ];
  const lines: string[] = [];
  lines.push('アカウントの発行・変更・棚卸の手順を定める。最小権限原則を厳守する。');
  lines.push('');
  for (const t of tasks) {
    lines.push(`### ${t.task_id} ${t.description}`);
    lines.push(`- 担当: ${formatResponsible(t.responsible)} / 想定: ${t.expected_duration_min}分`);
    lines.push('- 手順:');
    t.steps.forEach((s, i) => lines.push(`  ${i + 1}. ${s}`));
    lines.push(`- 異常時: ${t.failure_action}`);
    lines.push('');
  }
  if (industry === 'public_sector' || client_type === '公共' || client_type === '自治体') {
    lines.push('### 公共固有');
    lines.push('- 個人情報保護評価書 (PIA) に基づく権限設計');
    lines.push('- 検査調書を年度末に整備');
  }
  return {
    chapter_no: 5,
    title_ja: 'アカウント管理',
    body_md: lines.join('\n'),
    tasks,
  };
}

function buildBackupRestore(
  input: OperationsManualInput,
  retention: RetentionPolicy,
  industry: IndustryKey
): OperationsManualChapter {
  const tasks: OperationsTask[] = [
    {
      task_id: 'B-01',
      description: '日次自動バックアップ',
      responsible: 'auto',
      expected_duration_min: 60,
      prerequisites: ['バックアップジョブの正常稼働'],
      steps: [
        '毎日 02:00 JST にフルバックアップ取得',
        '転送先 (別リージョン) へ複製',
        '結果メールで担当者に通知',
      ],
      failure_action: '失敗通知をPagerDutyへ送信',
    },
    {
      task_id: 'B-02',
      description: '月次リストア試験',
      responsible: 'primary',
      expected_duration_min: 120,
      prerequisites: ['ステージング環境の利用予約'],
      steps: [
        'ステージング環境にバックアップをリストア',
        'スモークテスト (代表3画面 + 1帳票) を実施',
        '結果を月次運用報告に記載',
      ],
      failure_action: 'リストア失敗時はバックアップ取得方式を見直し',
    },
    {
      task_id: 'B-03',
      description: '年次フルリストア訓練',
      responsible: 'primary',
      expected_duration_min: 480,
      prerequisites: ['本番相当環境', '関係者の予約'],
      steps: [
        '前日中に対象環境を停止',
        '本番フルバックアップから完全リストアを実行',
        '全機能スモーク + 性能ベンチを実施',
        '結果報告書を作成',
      ],
      failure_action: '訓練失敗の場合は緊急対応計画を策定',
    },
  ];
  const lines: string[] = [];
  lines.push(`バックアップ保管期間: **${retention.backup_days}日**`);
  lines.push('');
  for (const t of tasks) {
    lines.push(`### ${t.task_id} ${t.description}`);
    lines.push(`- 担当: ${formatResponsible(t.responsible)} / 想定: ${t.expected_duration_min}分`);
    lines.push('- 手順:');
    t.steps.forEach((s, i) => lines.push(`  ${i + 1}. ${s}`));
    lines.push(`- 異常時: ${t.failure_action}`);
    lines.push('');
  }
  if (industry === 'finance' || industry === 'public_sector') {
    lines.push('### 業種固有要件');
    lines.push('- 暗号化バックアップ (AES-256)');
    lines.push('- WORM (Write Once Read Many) ストレージへの保管');
    lines.push('- 別リージョンへのオフサイト保管必須');
  }
  return {
    chapter_no: 6,
    title_ja: 'バックアップ・リストア',
    body_md: lines.join('\n'),
    tasks,
  };
}

function buildSecurityOperations(
  input: OperationsManualInput,
  retention: RetentionPolicy,
  industry: IndustryKey,
  client_type: ClientType
): OperationsManualChapter {
  const tasks: OperationsTask[] = [
    {
      task_id: 'S-01',
      description: '監査ログ確認',
      responsible: 'primary',
      expected_duration_min: 30,
      prerequisites: ['監査ログ閲覧権限'],
      steps: [
        '特権操作 (権限変更/データ削除/エクスポート) を抽出',
        '想定外の操作があればチケット起票',
        '週次サマリを保存',
      ],
      failure_action: '想定外操作はSEV2として調査開始',
    },
    {
      task_id: 'S-02',
      description: 'CVE監視・パッチ適用',
      responsible: 'primary',
      expected_duration_min: 60,
      prerequisites: ['脆弱性情報購読 (JPCERT/CC, GHSA)'],
      steps: [
        'CVSS v3 9.0以上の脆弱性は48時間以内に評価',
        '影響あれば即時パッチ計画策定',
        'CRITICAL は緊急変更管理会議で承認',
      ],
      failure_action: '適用遅延は経営層へエスカレーション',
    },
    {
      task_id: 'S-03',
      description: '脆弱性スキャン',
      responsible: 'primary',
      expected_duration_min: 120,
      prerequisites: ['スキャンツール (Trivy/OWASP ZAP)'],
      steps: [
        '月次でWebアプリ + Dockerイメージをスキャン',
        '結果をリスク台帳に記録',
        'Critical/High はチケット化',
      ],
      failure_action: 'Critical 検出は即時対応',
    },
  ];
  const lines: string[] = [];
  lines.push(`監査ログ保管: **${retention.audit_log_years}年** / アプリログ保管: **${retention.application_log_days}日**`);
  lines.push('');
  for (const t of tasks) {
    lines.push(`### ${t.task_id} ${t.description}`);
    lines.push(`- 担当: ${formatResponsible(t.responsible)} / 想定: ${t.expected_duration_min}分`);
    lines.push('- 手順:');
    t.steps.forEach((s, i) => lines.push(`  ${i + 1}. ${s}`));
    lines.push(`- 異常時: ${t.failure_action}`);
    lines.push('');
  }
  if (industry === 'healthcare') {
    lines.push('### 医療固有');
    lines.push('- 3省2GL (医療情報システム安全管理ガイドライン) 監査ログ7年保管');
    lines.push('- HPKI証明書失効リスト確認 (月次)');
  }
  if (industry === 'finance') {
    lines.push('### 金融固有');
    lines.push('- FISC安全対策基準に基づく監査ログ運用');
    lines.push('- 反社会的勢力データベース更新の即時反映');
  }
  if (client_type === '公共' || client_type === '自治体' || industry === 'public_sector') {
    lines.push('### 公共固有');
    lines.push('- 政府情報システム標準ガイドライン群 適合確認');
    lines.push('- 個人情報保護評価書 (PIA) 年次見直し');
  }
  return {
    chapter_no: 7,
    title_ja: 'セキュリティ運用',
    body_md: lines.join('\n'),
    tasks,
  };
}

function buildEscalationContacts(contacts: OperationsContacts, coverage: CoverageWindow): OperationsManualChapter {
  const lines: string[] = [];
  lines.push('### エスカレーションフロー');
  lines.push('');
  lines.push('1. **一次対応**: プライマリオンコール');
  lines.push('2. **二次対応**: セカンダリオンコール (一次15分応答なし)');
  lines.push('3. **三次対応**: マネージャエスカレーション (一次1時間で復旧不可)');
  lines.push('4. **ベンダー支援**: クラウド/ミドルウェア事業者サポート (技術的閉塞時)');
  lines.push('');
  lines.push('### 連絡先一覧');
  lines.push('');
  lines.push(formatContactCard('一次対応 (Primary)', contacts.primary));
  lines.push(formatContactCard('二次対応 (Secondary)', contacts.secondary));
  lines.push(formatContactCard('三次対応 (Manager Escalation)', contacts.manager_escalation));
  lines.push(formatContactCard('ベンダー支援', contacts.vendor_support));
  if (contacts.data_protection_officer) {
    lines.push(formatContactCard('個人情報保護管理者 (DPO)', contacts.data_protection_officer));
  }
  lines.push('');
  lines.push(`> サービス時間: ${COVERAGE_DESCRIPTIONS[coverage]}`);
  return {
    chapter_no: 8,
    title_ja: '連絡先・エスカレーション',
    body_md: lines.join('\n'),
    tasks: [],
  };
}

function formatContactCard(label: string, c: ContactCard): string {
  const fields: string[] = [];
  fields.push(`**${label}**: ${c.name} (${c.role})`);
  if (c.phone) fields.push(`電話: ${c.phone}`);
  if (c.email) fields.push(`メール: ${c.email}`);
  if (c.hours) fields.push(`対応時間: ${c.hours}`);
  return `- ${fields.join(' / ')}`;
}

function formatResponsible(r: OperationsTask['responsible']): string {
  switch (r) {
    case 'primary': return 'プライマリオンコール';
    case 'secondary': return 'セカンダリオンコール';
    case 'auto': return '自動 (監視ジョブ)';
  }
}

/** 運用手順書をMarkdownとして整形 */
export function formatOperationsManualAsMarkdown(m: OperationsManual): string {
  const lines: string[] = [];
  lines.push(`# 運用手順書 ${m.meta.system_name}`);
  lines.push('');
  lines.push(`発行日: ${m.meta.generated_at.slice(0, 10)} / 版数: ${m.meta.version}`);
  lines.push('');
  for (const c of m.chapters) {
    lines.push(`## ${c.chapter_no}. ${c.title_ja}`);
    lines.push('');
    lines.push(c.body_md);
    lines.push('');
  }
  return lines.join('\n');
}
