/**
 * オンコールスケジューラ
 *
 * 責務:
 *   プライマリ/セカンダリ/マネージャエスカレーションの3階層ローテーションを生成。
 *   公平性 (1人月内のオンコール時間の偏りを最小化)、本人指定休暇および
 *   日本の年末年始 (12/29-1/3) / GW (4/29-5/5) / お盆 (8/13-8/16) ブロックを
 *   考慮する。月次レポート (出動回数 / 平均応答時間 / Toil率) もテンプレ化。
 *
 * 入力: OncallScheduleInput
 * 出力: OncallSchedule (週次ローテ + 月次レポートテンプレ + Markdown整形)
 */

import type { CoverageWindow } from './operations_manual';
import { isBusinessDay, isJapaneseHoliday, holidayNameOf } from './sla_generator';

export interface VacationBlock {
  member: string;
  start_date: string;
  end_date: string;
  reason?: string;
}

export interface OncallScheduleInput {
  team: string[];
  start_date: string;
  weeks: number;
  coverage?: CoverageWindow;
  vacation_blocks?: VacationBlock[];
  rotation_unit?: 'weekly' | 'daily';
  primary_only?: boolean;
}

export interface OncallSlot {
  week_index: number;
  start_date: string;
  end_date: string;
  primary: string;
  secondary: string;
  manager: string | null;
  contains_holiday: boolean;
  holiday_names: string[];
  notes: string[];
}

export interface OncallFairnessReport {
  member: string;
  total_weeks: number;
  total_holiday_days: number;
  total_business_days: number;
  fairness_index: number;
}

export interface MonthlyReportTemplate {
  month_label: string;
  metrics: {
    primary_dispatches: number | null;
    secondary_dispatches: number | null;
    average_response_min: number | null;
    toil_percent: number | null;
    sev1_count: number | null;
    sev2_count: number | null;
  };
  improvement_proposal_questions: string[];
}

export interface OncallSchedule {
  meta: {
    generated_at: string;
    version: string;
    coverage: CoverageWindow;
    rotation_unit: 'weekly' | 'daily';
    start_date: string;
    weeks: number;
  };
  team: string[];
  slots: OncallSlot[];
  fairness: OncallFairnessReport[];
  monthly_report_template: MonthlyReportTemplate;
  vacation_blocks: VacationBlock[];
  effective_blocks: VacationBlock[];
}

const FIXED_NATIONAL_BLOCKS: { name: string; mmdd_start: string; mmdd_end: string }[] = [
  { name: '年末年始', mmdd_start: '12-29', mmdd_end: '01-03' },
  { name: 'ゴールデンウィーク', mmdd_start: '04-29', mmdd_end: '05-05' },
  { name: 'お盆', mmdd_start: '08-13', mmdd_end: '08-16' },
];

export function generateOncallSchedule(input: OncallScheduleInput): OncallSchedule {
  if (input.team.length < 2) {
    throw new Error('オンコール体制は最低2名のチームが必要です (Primary + Secondary)。');
  }
  const coverage: CoverageWindow = input.coverage ?? '24x365';
  const rotation_unit = input.rotation_unit ?? 'weekly';
  const start = parseDate(input.start_date);
  const slots: OncallSlot[] = [];

  const expandedVacationBlocks = expandNationalBlocks(input.team, start, input.weeks);
  const allBlocks = [...(input.vacation_blocks ?? []), ...expandedVacationBlocks];

  const memberStats = new Map<string, { weeks: number; holiday_days: number; business_days: number }>();
  for (const m of input.team) {
    memberStats.set(m, { weeks: 0, holiday_days: 0, business_days: 0 });
  }

  for (let w = 0; w < input.weeks; w += 1) {
    const slotStart = addDays(start, w * 7);
    const slotEnd = addDays(slotStart, 6);
    const available = filterAvailableMembers(input.team, allBlocks, slotStart, slotEnd);
    const ranking = rankByLeastLoaded(memberStats, available, input.team);

    const primary = ranking[0] ?? input.team[w % input.team.length];
    const secondary = input.primary_only
      ? ''
      : (ranking[1] ?? input.team[(w + 1) % input.team.length]);
    const manager = pickManager(input.team, primary, secondary);

    const holidays = enumerateHolidaysInRange(slotStart, slotEnd);
    const business_days = enumerateBusinessDaysInRange(slotStart, slotEnd);
    const notes: string[] = [];
    if (holidays.length) notes.push(`祝日含む (${holidays.map((h) => h.name).join(' / ')})`);
    if (available.length < input.team.length) {
      const blocked = input.team.filter((m) => !available.includes(m));
      notes.push(`不在: ${blocked.join(' / ')}`);
    }
    if (coverage === 'business-hours' && holidays.length === 7) {
      notes.push('全日が非営業日のため待機要否を要相談');
    }

    slots.push({
      week_index: w + 1,
      start_date: formatDate(slotStart),
      end_date: formatDate(slotEnd),
      primary,
      secondary,
      manager,
      contains_holiday: holidays.length > 0,
      holiday_names: holidays.map((h) => h.name),
      notes,
    });

    incStat(memberStats, primary, 1, holidays.length, business_days);
    if (secondary) incStat(memberStats, secondary, 0.5, holidays.length * 0.5, business_days * 0.5);
  }

  const fairness: OncallFairnessReport[] = input.team.map((m) => {
    const s = memberStats.get(m) ?? { weeks: 0, holiday_days: 0, business_days: 0 };
    return {
      member: m,
      total_weeks: round1(s.weeks),
      total_holiday_days: round1(s.holiday_days),
      total_business_days: round1(s.business_days),
      fairness_index: round1(computeFairnessIndex(memberStats, m)),
    };
  });

  return {
    meta: {
      generated_at: new Date().toISOString(),
      version: '1.0.0',
      coverage,
      rotation_unit,
      start_date: input.start_date,
      weeks: input.weeks,
    },
    team: input.team,
    slots,
    fairness,
    monthly_report_template: buildMonthlyReportTemplate(),
    vacation_blocks: input.vacation_blocks ?? [],
    effective_blocks: allBlocks,
  };
}

function expandNationalBlocks(team: string[], start: Date, weeks: number): VacationBlock[] {
  const result: VacationBlock[] = [];
  const startYear = start.getUTCFullYear();
  const endYear = addDays(start, weeks * 7).getUTCFullYear();
  for (let y = startYear; y <= endYear; y += 1) {
    for (const blk of FIXED_NATIONAL_BLOCKS) {
      const [sm, sd] = blk.mmdd_start.split('-').map((n) => parseInt(n, 10));
      const [em, ed] = blk.mmdd_end.split('-').map((n) => parseInt(n, 10));
      let startBlock = new Date(Date.UTC(y, sm - 1, sd));
      let endBlock = new Date(Date.UTC(y, em - 1, ed));
      if (em < sm || (em === sm && ed < sd)) {
        endBlock = new Date(Date.UTC(y + 1, em - 1, ed));
      }
      for (const m of team) {
        result.push({
          member: m,
          start_date: formatDate(startBlock),
          end_date: formatDate(endBlock),
          reason: `${blk.name} (国民的休暇期間: 半数体制)`,
        });
      }
    }
  }
  return result;
}

function filterAvailableMembers(
  team: string[],
  blocks: VacationBlock[],
  slotStart: Date,
  slotEnd: Date
): string[] {
  return team.filter((m) => {
    const overlapping = blocks.filter((b) => b.member === m).some((b) => rangesOverlap(b.start_date, b.end_date, slotStart, slotEnd));
    if (!overlapping) return true;
    const personal = blocks.find((b) => b.member === m && !b.reason?.includes('国民的休暇期間'));
    if (personal && rangesOverlap(personal.start_date, personal.end_date, slotStart, slotEnd)) {
      return false;
    }
    return true;
  });
}

function rangesOverlap(aStart: string, aEnd: string, bStart: Date, bEnd: Date): boolean {
  const a1 = parseDate(aStart);
  const a2 = parseDate(aEnd);
  return a1 <= bEnd && a2 >= bStart;
}

function rankByLeastLoaded(
  stats: Map<string, { weeks: number; holiday_days: number; business_days: number }>,
  available: string[],
  fallback: string[]
): string[] {
  const ranked = [...available].sort((a, b) => {
    const sa = stats.get(a)!;
    const sb = stats.get(b)!;
    if (sa.weeks !== sb.weeks) return sa.weeks - sb.weeks;
    if (sa.holiday_days !== sb.holiday_days) return sa.holiday_days - sb.holiday_days;
    return 0;
  });
  if (ranked.length < 2) {
    for (const m of fallback) {
      if (!ranked.includes(m)) ranked.push(m);
    }
  }
  return ranked;
}

function pickManager(team: string[], primary: string, secondary: string): string | null {
  const candidate = team.find((m) => m !== primary && m !== secondary);
  return candidate ?? null;
}

function incStat(
  stats: Map<string, { weeks: number; holiday_days: number; business_days: number }>,
  m: string,
  weeks: number,
  holiday_days: number,
  business_days: number
): void {
  const s = stats.get(m);
  if (!s) return;
  s.weeks += weeks;
  s.holiday_days += holiday_days;
  s.business_days += business_days;
}

function computeFairnessIndex(
  stats: Map<string, { weeks: number; holiday_days: number; business_days: number }>,
  m: string
): number {
  const all = Array.from(stats.values()).map((s) => s.weeks);
  const avg = all.reduce((a, b) => a + b, 0) / Math.max(all.length, 1);
  if (avg === 0) return 1;
  const sd = Math.sqrt(all.reduce((a, b) => a + Math.pow(b - avg, 2), 0) / all.length);
  const member_weeks = stats.get(m)?.weeks ?? 0;
  const deviation = Math.abs(member_weeks - avg);
  const norm = avg === 0 ? 0 : deviation / avg;
  return Math.max(0, 1 - norm) * (sd === 0 ? 1 : 1);
}

function enumerateHolidaysInRange(start: Date, end: Date): { date: string; name: string }[] {
  const result: { date: string; name: string }[] = [];
  for (let d = new Date(start); d <= end; d.setUTCDate(d.getUTCDate() + 1)) {
    if (isJapaneseHoliday(d)) {
      result.push({ date: formatDate(d), name: holidayNameOf(d) ?? '祝日' });
    }
  }
  return result;
}

function enumerateBusinessDaysInRange(start: Date, end: Date): number {
  let count = 0;
  for (let d = new Date(start); d <= end; d.setUTCDate(d.getUTCDate() + 1)) {
    if (isBusinessDay(d)) count += 1;
  }
  return count;
}

function buildMonthlyReportTemplate(): MonthlyReportTemplate {
  return {
    month_label: '<YYYY-MM>',
    metrics: {
      primary_dispatches: null,
      secondary_dispatches: null,
      average_response_min: null,
      toil_percent: null,
      sev1_count: null,
      sev2_count: null,
    },
    improvement_proposal_questions: [
      'Toil率が30%を超えている繰り返し作業はあるか',
      'SEV1のポストモーテムから新規Runbookが追加可能か',
      '応答時間SLA超過のケースの根本原因は何か',
      '次月オンコール体制で公平性指標が低下する見込みはあるか',
      'ベンダーサポートの応答品質に課題はないか',
    ],
  };
}

function parseDate(s: string): Date {
  const [y, m, d] = s.split('-').map((n) => parseInt(n, 10));
  return new Date(Date.UTC(y, m - 1, d));
}

function formatDate(d: Date): string {
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}

function addDays(d: Date, n: number): Date {
  const r = new Date(d);
  r.setUTCDate(r.getUTCDate() + n);
  return r;
}

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

/** スケジュールをMarkdownとして整形 */
export function formatOncallScheduleAsMarkdown(s: OncallSchedule): string {
  const lines: string[] = [];
  lines.push(`# オンコール体制表`);
  lines.push('');
  lines.push(`発行日: ${s.meta.generated_at.slice(0, 10)} / 版数: ${s.meta.version}`);
  lines.push(`期間: ${s.meta.start_date} から ${s.meta.weeks}週間 / サービス時間: ${s.meta.coverage}`);
  lines.push('');
  lines.push('## 1. 週次ローテーション');
  lines.push('');
  lines.push('| Week | 期間 | Primary | Secondary | Manager | 祝日 | 備考 |');
  lines.push('|------|------|---------|-----------|---------|------|------|');
  for (const slot of s.slots) {
    lines.push(
      `| ${slot.week_index} | ${slot.start_date} 〜 ${slot.end_date} | ${slot.primary} | ${slot.secondary || '(なし)'} | ${slot.manager ?? '(なし)'} | ${slot.contains_holiday ? slot.holiday_names.join('/') : 'なし'} | ${slot.notes.join(' / ')} |`
    );
  }
  lines.push('');
  lines.push('## 2. 公平性指標');
  lines.push('');
  lines.push('| メンバー | 週数 | 祝日日数 | 営業日数 | 公平性Index |');
  lines.push('|---------|------|---------|---------|------------|');
  for (const f of s.fairness) {
    lines.push(`| ${f.member} | ${f.total_weeks} | ${f.total_holiday_days} | ${f.total_business_days} | ${f.fairness_index} |`);
  }
  lines.push('');
  lines.push('> 公平性Index = 1.0 (完全均等) 〜 0.0 (極端な偏り)。0.8 以下は再配分を検討。');
  lines.push('');
  lines.push('## 3. 月次レポート テンプレ');
  lines.push('');
  lines.push('| メトリクス | 値 |');
  lines.push('|---------|------|');
  lines.push(`| 対象月 | ${s.monthly_report_template.month_label} |`);
  lines.push('| Primary 出動回数 | <記入> |');
  lines.push('| Secondary 出動回数 | <記入> |');
  lines.push('| 平均応答時間 (分) | <記入> |');
  lines.push('| Toil率 (%) | <記入> |');
  lines.push('| SEV1件数 | <記入> |');
  lines.push('| SEV2件数 | <記入> |');
  lines.push('');
  lines.push('### 改善提案チェック');
  for (const q of s.monthly_report_template.improvement_proposal_questions) lines.push(`- ${q}`);
  lines.push('');
  if (s.effective_blocks.length) {
    lines.push('## 4. 不在期間 (休暇 + 国民的休暇期間)');
    lines.push('');
    lines.push('| メンバー | 期間 | 理由 |');
    lines.push('|---------|------|------|');
    for (const b of s.effective_blocks) {
      lines.push(`| ${b.member} | ${b.start_date} 〜 ${b.end_date} | ${b.reason ?? ''} |`);
    }
  }
  return lines.join('\n');
}
