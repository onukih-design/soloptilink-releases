/**
 * 保守計画書ジェネレータ
 *
 * 責務:
 *   日本SI標準の4保守区分 (障害対応/制度対応/改良要望/予防保守) に基づき、
 *   月次・年次の作業項目と工数想定、業種別の制度対応カレンダー、保守契約の
 *   重要条項 (受付窓口/対応時間/月間保守工数/超過時の追加費用/年次更新) を
 *   生成する。
 *
 * 入力: MaintenancePlanInput
 * 出力: MaintenancePlan (区分別計画 + 月次/年次タスク + 工数 + Markdown整形)
 */

import type { IndustryKey, ClientType } from './operations_manual';

export type MaintenanceCategory = 'incident' | 'regulation' | 'enhancement' | 'preventive';

export interface MaintenanceCategoryDefinition {
  category: MaintenanceCategory;
  label_ja: string;
  description_ja: string;
  monthly_pd_min: number;
  monthly_pd_max: number;
  examples: string[];
}

export const MAINTENANCE_CATEGORIES: Record<MaintenanceCategory, MaintenanceCategoryDefinition> = {
  incident: {
    category: 'incident',
    label_ja: '障害対応',
    description_ja: '本番運用中に発生した不具合・データ不整合への緊急対応',
    monthly_pd_min: 0.5,
    monthly_pd_max: 1.0,
    examples: ['緊急バグ修正', 'データパッチ適用', 'リカバリ対応', 'ホットフィックスリリース'],
  },
  regulation: {
    category: 'regulation',
    label_ja: '制度対応',
    description_ja: '法令改正・業界規制変更に伴う対応',
    monthly_pd_min: 0.3,
    monthly_pd_max: 0.8,
    examples: [
      'インボイス制度 (適格請求書発行事業者)',
      '電子帳簿保存法 (電帳法)',
      '個人情報保護法改正',
      '介護報酬改定 (3年毎)',
      '3省2GL (医療情報システム)',
      '会計基準・税制改正',
    ],
  },
  enhancement: {
    category: 'enhancement',
    label_ja: '改良要望',
    description_ja: '顧客運用部門からの機能追加・UI改善要望の消化',
    monthly_pd_min: 0.5,
    monthly_pd_max: 2.0,
    examples: ['機能追加', 'UI改善', 'レポート項目追加', '帳票フォーマット変更'],
  },
  preventive: {
    category: 'preventive',
    label_ja: '予防保守',
    description_ja: 'OS/ミドルウェア/ライブラリのパッチ適用、性能改善、リファクタリング',
    monthly_pd_min: 0.5,
    monthly_pd_max: 1.0,
    examples: [
      'OS/ミドルウェアパッチ適用',
      'CVE脆弱性対応',
      '性能チューニング',
      '不要データクリーンアップ',
      'ドキュメント更新',
    ],
  },
};

export interface MaintenanceTask {
  task_id: string;
  description: string;
  frequency: 'monthly' | 'quarterly' | 'annually' | 'ad-hoc';
  estimated_pd: number;
  category: MaintenanceCategory;
  notes?: string;
}

export interface MaintenancePlanInput {
  system_name: string;
  industry?: IndustryKey;
  client_type?: ClientType;
  team_size?: number;
  contract_period_months?: number;
  vendor_name?: string;
  client_name?: string;
}

export interface MaintenancePlan {
  meta: {
    system_name: string;
    industry: IndustryKey;
    client_type: ClientType;
    contract_period_months: number;
    generated_at: string;
    version: string;
  };
  categories: MaintenanceCategoryDefinition[];
  monthly_tasks: MaintenanceTask[];
  annual_tasks: MaintenanceTask[];
  industry_regulation_calendar: { month: number; event: string; category: MaintenanceCategory }[];
  total_monthly_pd: { min: number; max: number };
  total_annual_pd: { min: number; max: number };
  contract_clauses: string[];
}

const REGULATION_CALENDARS: Partial<Record<IndustryKey, { month: number; event: string }[]>> = {
  healthcare: [
    { month: 1, event: '診療報酬改定の事前周知 (2年に1度)' },
    { month: 4, event: '診療報酬改定 施行 (偶数年)' },
    { month: 4, event: '3省2GL最新版チェック' },
    { month: 10, event: 'マイナ保険証関連アップデート' },
  ],
  longterm_care: [
    { month: 4, event: '介護報酬改定 施行 (3年毎)' },
    { month: 4, event: '介護保険制度改正反映' },
    { month: 10, event: 'LIFE仕様アップデート' },
  ],
  finance: [
    { month: 4, event: '会計年度開始: 税制改正反映' },
    { month: 10, event: '中間決算: FISC基準アップデート' },
    { month: 12, event: '年末調整 / 反社DBアップデート' },
  ],
  public_sector: [
    { month: 3, event: '年度末: 検査調書整備' },
    { month: 4, event: '会計年度開始: 標準ガイドライン適合確認' },
    { month: 9, event: '上半期決算' },
  ],
  construction: [
    { month: 1, event: 'インボイス対応確認' },
    { month: 4, event: '建設業法改正反映' },
    { month: 10, event: '建退共 納付実績集計' },
  ],
  manufacturing: [
    { month: 4, event: '会計年度開始: 棚卸基準改定' },
    { month: 9, event: 'ISO監査対応' },
    { month: 12, event: '消費税改正対応' },
  ],
  real_estate: [
    { month: 4, event: '宅建業法改正反映' },
    { month: 10, event: 'レインズ仕様アップデート' },
  ],
  retail: [
    { month: 4, event: '消費税・軽減税率改正反映' },
    { month: 10, event: 'インボイス制度関連アップデート' },
  ],
  food_service: [
    { month: 6, event: 'HACCP基準アップデート' },
  ],
  transport: [
    { month: 4, event: '改善基準告示の見直し反映' },
  ],
  education: [
    { month: 3, event: '進級・卒業データ確定' },
    { month: 4, event: '入学者マスタ反映' },
  ],
};

export function generateMaintenancePlan(input: MaintenancePlanInput): MaintenancePlan {
  const industry: IndustryKey = input.industry ?? 'default';
  const client_type: ClientType = input.client_type ?? '民間';
  const contract_period_months = input.contract_period_months ?? 12;
  const monthly_tasks = buildMonthlyTasks(industry);
  const annual_tasks = buildAnnualTasks(industry, client_type);
  const industry_regulation_calendar = (REGULATION_CALENDARS[industry] ?? []).map((c) => ({
    ...c,
    category: 'regulation' as MaintenanceCategory,
  }));

  const total_monthly_pd = aggregatePd(monthly_tasks);
  const total_annual_pd = aggregatePd(annual_tasks);

  return {
    meta: {
      system_name: input.system_name,
      industry,
      client_type,
      contract_period_months,
      generated_at: new Date().toISOString(),
      version: '1.0.0',
    },
    categories: Object.values(MAINTENANCE_CATEGORIES),
    monthly_tasks,
    annual_tasks,
    industry_regulation_calendar,
    total_monthly_pd,
    total_annual_pd,
    contract_clauses: buildContractClauses(client_type, contract_period_months),
  };
}

function buildMonthlyTasks(industry: IndustryKey): MaintenanceTask[] {
  const base: MaintenanceTask[] = [
    {
      task_id: 'M-PV-01',
      description: 'OS/ミドルウェアパッチ適用 (CVE-CRITICAL は即時)',
      frequency: 'monthly',
      estimated_pd: 0.3,
      category: 'preventive',
    },
    {
      task_id: 'M-PV-02',
      description: 'バックアップ検証 (ランダム1日リストア試験)',
      frequency: 'monthly',
      estimated_pd: 0.2,
      category: 'preventive',
    },
    {
      task_id: 'M-PV-03',
      description: '容量・性能監視レポート作成',
      frequency: 'monthly',
      estimated_pd: 0.2,
      category: 'preventive',
    },
    {
      task_id: 'M-PV-04',
      description: '死活監視レポート作成 (稼働率・平均応答時間・SLA達成率)',
      frequency: 'monthly',
      estimated_pd: 0.2,
      category: 'preventive',
    },
    {
      task_id: 'M-PV-05',
      description: 'セキュリティ監査ログレビュー (脆弱性スキャン結果含む)',
      frequency: 'monthly',
      estimated_pd: 0.4,
      category: 'preventive',
    },
    {
      task_id: 'M-IN-01',
      description: '障害対応 (発生時のみ)',
      frequency: 'ad-hoc',
      estimated_pd: 0.5,
      category: 'incident',
    },
    {
      task_id: 'M-EH-01',
      description: '改良要望対応 (要望キュー消化)',
      frequency: 'monthly',
      estimated_pd: 1.0,
      category: 'enhancement',
    },
  ];
  if (industry === 'healthcare') {
    base.push({
      task_id: 'M-RG-HC-01',
      description: '3省2GLアップデート差分確認',
      frequency: 'monthly',
      estimated_pd: 0.2,
      category: 'regulation',
    });
  }
  if (industry === 'finance') {
    base.push({
      task_id: 'M-RG-FN-01',
      description: 'FISC基準改訂チェック / 反社データベース更新',
      frequency: 'monthly',
      estimated_pd: 0.2,
      category: 'regulation',
    });
  }
  return base;
}

function buildAnnualTasks(industry: IndustryKey, client_type: ClientType): MaintenanceTask[] {
  const base: MaintenanceTask[] = [
    {
      task_id: 'Y-PV-01',
      description: 'BCP訓練 (机上 + 実機停止)',
      frequency: 'annually',
      estimated_pd: 2.0,
      category: 'preventive',
    },
    {
      task_id: 'Y-PV-02',
      description: 'リストア訓練 (本番相当環境で全面リストア)',
      frequency: 'annually',
      estimated_pd: 2.0,
      category: 'preventive',
    },
    {
      task_id: 'Y-PV-03',
      description: '脆弱性診断 (Webアプリ + ネットワーク + ペネトレーション)',
      frequency: 'annually',
      estimated_pd: 5.0,
      category: 'preventive',
    },
    {
      task_id: 'Y-PV-04',
      description: 'SLA見直し (実績ベース)',
      frequency: 'annually',
      estimated_pd: 1.0,
      category: 'preventive',
    },
    {
      task_id: 'Y-IN-01',
      description: '保守契約更新協議',
      frequency: 'annually',
      estimated_pd: 2.0,
      category: 'incident',
    },
  ];
  if (client_type === '公共' || client_type === '自治体' || industry === 'public_sector') {
    base.push({
      task_id: 'Y-RG-PB-01',
      description: '個人情報保護評価書 (PIA) 見直し',
      frequency: 'annually',
      estimated_pd: 2.0,
      category: 'regulation',
    });
    base.push({
      task_id: 'Y-PV-PB-02',
      description: '検査調書整備 (年度末)',
      frequency: 'annually',
      estimated_pd: 1.5,
      category: 'preventive',
    });
  }
  return base;
}

function aggregatePd(tasks: MaintenanceTask[]): { min: number; max: number } {
  let min = 0;
  let max = 0;
  for (const t of tasks) {
    const cat = MAINTENANCE_CATEGORIES[t.category];
    min += Math.min(t.estimated_pd, cat.monthly_pd_min);
    max += Math.max(t.estimated_pd, cat.monthly_pd_min);
  }
  return { min: round1(min), max: round1(max) };
}

function buildContractClauses(client_type: ClientType, period_months: number): string[] {
  const clauses: string[] = [];
  clauses.push(`保守契約期間: ${period_months}ヶ月 (自動更新条項あり)`);
  clauses.push('受付窓口: 専用メール + Slack共有チャンネル + 緊急時の専用電話番号');
  if (client_type === '公共' || client_type === '自治体') {
    clauses.push('対応時間: 平日 9:00〜17:30 (会計法29条の3 / 標準ガイドライン群準拠)');
    clauses.push('支払: 検収完了後30日以内 (政府契約の支払遅延防止等に関する法律準拠)');
  } else {
    clauses.push('対応時間: 平日 9:00〜18:00 (緊急時は24h)');
    clauses.push('支払: 月末締め翌月末払い (下請法60日上限内)');
  }
  clauses.push('月間保守工数の超過時は事前見積に基づき追加発注');
  clauses.push('CVE-CRITICAL は契約工数枠外で即時対応');
  clauses.push('終了時引継ぎ: 終了3ヶ月前から引継書整備、最終月に運用ベンダーへ知識移転');
  return clauses;
}

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

/** 保守計画書をMarkdownとして整形 */
export function formatMaintenancePlanAsMarkdown(p: MaintenancePlan): string {
  const lines: string[] = [];
  lines.push(`# 保守計画書 ${p.meta.system_name}`);
  lines.push('');
  lines.push(`発行日: ${p.meta.generated_at.slice(0, 10)} / 版数: ${p.meta.version}`);
  lines.push(`契約期間: ${p.meta.contract_period_months}ヶ月 / 顧客タイプ: ${p.meta.client_type}`);
  lines.push('');
  lines.push('## 1. 保守区分 (4分類)');
  lines.push('');
  lines.push('| 区分 | 内容 | 月次工数想定 (人日) | 例 |');
  lines.push('|------|------|------------------|-----|');
  for (const c of p.categories) {
    lines.push(`| ${c.label_ja} | ${c.description_ja} | ${c.monthly_pd_min}〜${c.monthly_pd_max} | ${c.examples.slice(0, 3).join(' / ')} |`);
  }
  lines.push('');
  lines.push('## 2. 月次定例タスク');
  lines.push('');
  lines.push('| Task ID | 作業 | 頻度 | 想定工数 (人日) | 区分 |');
  lines.push('|---------|------|------|---------------|------|');
  for (const t of p.monthly_tasks) {
    lines.push(`| ${t.task_id} | ${t.description} | ${labelFrequency(t.frequency)} | ${t.estimated_pd} | ${MAINTENANCE_CATEGORIES[t.category].label_ja} |`);
  }
  lines.push('');
  lines.push('## 3. 年次定例タスク');
  lines.push('');
  lines.push('| Task ID | 作業 | 想定工数 (人日) | 区分 |');
  lines.push('|---------|------|---------------|------|');
  for (const t of p.annual_tasks) {
    lines.push(`| ${t.task_id} | ${t.description} | ${t.estimated_pd} | ${MAINTENANCE_CATEGORIES[t.category].label_ja} |`);
  }
  lines.push('');
  if (p.industry_regulation_calendar.length) {
    lines.push('## 4. 業種別 制度対応カレンダー');
    lines.push('');
    lines.push('| 月 | イベント |');
    lines.push('|----|---------|');
    for (const ev of p.industry_regulation_calendar) {
      lines.push(`| ${ev.month}月 | ${ev.event} |`);
    }
    lines.push('');
  }
  lines.push('## 5. 工数サマリ');
  lines.push(`- 月次合計: **${p.total_monthly_pd.min} 〜 ${p.total_monthly_pd.max} 人日**`);
  lines.push(`- 年次合計: **${p.total_annual_pd.min} 〜 ${p.total_annual_pd.max} 人日**`);
  lines.push('');
  lines.push('## 6. 契約条項要約');
  for (const c of p.contract_clauses) {
    lines.push(`- ${c}`);
  }
  return lines.join('\n');
}

function labelFrequency(f: MaintenanceTask['frequency']): string {
  switch (f) {
    case 'monthly': return '月次';
    case 'quarterly': return '四半期';
    case 'annually': return '年次';
    case 'ad-hoc': return '随時';
  }
}
