/**
 * soloptilink-handoff public API
 *
 * 責務:
 *   各モジュール (operations_manual / runbook_generator / maintenance_plan /
 *   sla_generator / oncall_scheduler / handover_doc) の公開エクスポートを集約し、
 *   `--mode all` 相当の一括生成関数 generateHandoffPackage() を提供する。
 *   各個モジュールは独立に呼び出すこともできる。
 */

export * from './operations_manual';
export * from './runbook_generator';
export * from './maintenance_plan';
export * from './sla_generator';
export * from './oncall_scheduler';
export * from './handover_doc';

import {
  generateOperationsManual,
  formatOperationsManualAsMarkdown,
  type OperationsManual,
  type OperationsManualInput,
} from './operations_manual';
import {
  generateRunbook,
  formatRunbookAsMarkdown,
  type Runbook,
  type RunbookGeneratorInput,
} from './runbook_generator';
import {
  generateMaintenancePlan,
  formatMaintenancePlanAsMarkdown,
  type MaintenancePlan,
  type MaintenancePlanInput,
} from './maintenance_plan';
import {
  generateSla,
  formatSlaAsMarkdown,
  type Sla,
  type SlaInput,
} from './sla_generator';
import {
  generateOncallSchedule,
  formatOncallScheduleAsMarkdown,
  type OncallSchedule,
  type OncallScheduleInput,
} from './oncall_scheduler';
import {
  generateHandoverDoc,
  formatHandoverDocAsMarkdown,
  type HandoverDoc,
  type HandoverDocInput,
} from './handover_doc';

export interface HandoffPackageInput {
  operations: OperationsManualInput;
  runbook: Omit<RunbookGeneratorInput, 'system_name' | 'contacts'>;
  maintenance: Omit<MaintenancePlanInput, 'system_name' | 'industry' | 'client_type'>;
  sla: Omit<SlaInput, 'system_name' | 'industry' | 'client_type' | 'coverage'>;
  oncall: OncallScheduleInput;
  handover: Omit<HandoverDocInput, 'system_name' | 'industry' | 'client_type' | 'contacts'>;
}

export interface HandoffPackageOutput {
  operations_manual: OperationsManual;
  runbook: Runbook;
  maintenance_plan: MaintenancePlan;
  sla: Sla;
  oncall_schedule: OncallSchedule;
  handover_doc: HandoverDoc;
  markdown: {
    operations_manual: string;
    runbook: string;
    maintenance_plan: string;
    sla: string;
    oncall_schedule: string;
    handover_doc: string;
  };
}

/**
 * フルセット (運用手順書 + Runbook + 保守計画書 + SLA + オンコール + 引継書) を一括生成。
 *
 * `--mode all` 相当。共通項目 (system_name / industry / client_type / coverage / contacts)
 * は operations 入力から派生して内部的に伝播する。
 */
export function generateHandoffPackage(input: HandoffPackageInput): HandoffPackageOutput {
  const operations_manual = generateOperationsManual(input.operations);
  const system_name = operations_manual.meta.system_name;
  const industry = operations_manual.meta.industry;
  const client_type = operations_manual.meta.client_type;
  const coverage = operations_manual.meta.coverage;
  const contacts = operations_manual.contacts;

  const runbook = generateRunbook({
    system_name,
    contacts,
    scenarios: input.runbook.scenarios,
    custom_severity: input.runbook.custom_severity,
  });

  const maintenance_plan = generateMaintenancePlan({
    system_name,
    industry,
    client_type,
    team_size: input.maintenance.team_size,
    contract_period_months: input.maintenance.contract_period_months,
    vendor_name: input.maintenance.vendor_name,
    client_name: input.maintenance.client_name,
  });

  const sla = generateSla({
    system_name,
    industry,
    client_type,
    coverage,
    availability_target: input.sla.availability_target,
    rto_minutes: input.sla.rto_minutes,
    rpo_minutes: input.sla.rpo_minutes,
    service_credit_threshold: input.sla.service_credit_threshold,
    evaluation_period_days: input.sla.evaluation_period_days,
  });

  const oncall_schedule = generateOncallSchedule(input.oncall);

  const handover_doc = generateHandoverDoc({
    direction: input.handover.direction,
    system_name,
    industry,
    client_type,
    contacts,
    servers: input.handover.servers,
    licenses: input.handover.licenses,
    accounts: input.handover.accounts,
    certificates: input.handover.certificates,
    known_issues: input.handover.known_issues,
    change_history: input.handover.change_history,
    improvement_proposals: input.handover.improvement_proposals,
    password_storage_locations: input.handover.password_storage_locations,
    contract_documents: input.handover.contract_documents,
    handover_period_start: input.handover.handover_period_start,
    handover_period_end: input.handover.handover_period_end,
  });

  return {
    operations_manual,
    runbook,
    maintenance_plan,
    sla,
    oncall_schedule,
    handover_doc,
    markdown: {
      operations_manual: formatOperationsManualAsMarkdown(operations_manual),
      runbook: formatRunbookAsMarkdown(runbook),
      maintenance_plan: formatMaintenancePlanAsMarkdown(maintenance_plan),
      sla: formatSlaAsMarkdown(sla),
      oncall_schedule: formatOncallScheduleAsMarkdown(oncall_schedule),
      handover_doc: formatHandoverDocAsMarkdown(handover_doc),
    },
  };
}
