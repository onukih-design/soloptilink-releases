/**
 * 例題1: 医療レセプト管理システムの運用引継ぎ一式生成
 *
 * 実行: bun run examples/01_medical_handoff.ts
 *       node --import tsx examples/01_medical_handoff.ts
 */

import { generateHandoffPackage } from '../lib/index';

const result = generateHandoffPackage({
  operations: {
    system_name: '医療レセプト管理システム',
    industry: 'healthcare',
    client_type: '民間',
    coverage: '24x365',
    business_hours_jst: '平日 8:30〜19:00 JST',
    primary_users: ['医事課職員', '医師', '看護師', '医療事務'],
    architecture_summary: 'Next.js + Node.js API + PostgreSQL + Redis + S3 (バックアップ) の Tokyo Region 構成。電子カルテとは HL7/FHIR で連携。',
    contacts: {
      primary: { name: '田中 太郎', role: '一次対応者', phone: '090-1111-2222', email: 'tanaka@example.jp', hours: '24x365' },
      secondary: { name: '鈴木 花子', role: '二次対応者', phone: '090-3333-4444', email: 'suzuki@example.jp' },
      manager_escalation: { name: '佐藤 マネージャ', role: '運用責任者', phone: '03-1234-5678', email: 'sato@example.jp' },
      vendor_support: { name: 'AWS Premium Support', role: 'クラウド事業者', phone: '0120-XXX-XXX', hours: '24x365' },
      data_protection_officer: { name: '渡辺 DPO', role: '個人情報保護管理者', email: 'dpo@example.jp' },
    },
    retention: { backup_days: 35, audit_log_years: 7, application_log_days: 90 },
  },
  runbook: {
    scenarios: ['db_unreachable', 'api_slow', 'auth_failure_spike', 'batch_failure', 'capacity_exhaustion', 'unauthorized_access'],
  },
  maintenance: {
    team_size: 3,
    contract_period_months: 12,
    vendor_name: 'SoloptiLink株式会社',
    client_name: '医療法人サンプル会',
  },
  sla: {
    availability_target: 0.9999,
    rto_minutes: 30,
    rpo_minutes: 5,
    service_credit_threshold: 0.99,
    evaluation_period_days: 30,
  },
  oncall: {
    team: ['田中', '鈴木', '佐藤', '渡辺'],
    start_date: '2026-05-04',
    weeks: 12,
    coverage: '24x365',
    vacation_blocks: [
      { member: '田中', start_date: '2026-06-15', end_date: '2026-06-20', reason: '夏季休暇' },
    ],
  },
  handover: {
    direction: 'sier_to_client',
    servers: [
      { hostname: 'api-prod-01', role: 'API', spec: '4 vCPU / 16GB', cloud_provider: 'AWS', region: 'ap-northeast-1', cost_jpy_monthly: 38000 },
      { hostname: 'db-prod-01', role: 'PostgreSQL Primary', spec: 'db.r6g.large', cloud_provider: 'AWS', region: 'ap-northeast-1', cost_jpy_monthly: 52000 },
      { hostname: 'db-prod-02', role: 'PostgreSQL Replica', spec: 'db.r6g.large', cloud_provider: 'AWS', region: 'ap-northeast-1', cost_jpy_monthly: 52000 },
    ],
    licenses: [
      { software_name: 'Datadog Pro', vendor: 'Datadog', license_count: 5, expiry_date: '2027-03-31', contact: 'sales@datadog.jp' },
      { software_name: 'PagerDuty Standard', vendor: 'PagerDuty', license_count: 4, expiry_date: '2027-04-30', contact: 'support@pagerduty.jp' },
    ],
    accounts: [
      { service: 'AWS Console', account_id: '123456789012', owner: '佐藤 マネージャ', permission_level: 'Admin', storage_location: '1Password (運用vault)' },
      { service: 'GitHub Enterprise', account_id: 'org-medical-rec', owner: '佐藤 マネージャ', permission_level: 'Owner', storage_location: '1Password (運用vault)' },
    ],
    certificates: [
      { domain: 'rec.example.jp', issuer: "Let's Encrypt", issued_at: '2026-04-01', expires_at: '2026-06-30', auto_renew: true },
      { domain: 'admin.rec.example.jp', issuer: 'DigiCert', issued_at: '2026-01-15', expires_at: '2027-01-14', auto_renew: false },
    ],
    known_issues: [
      { issue_id: 'KI-001', severity: '中', summary: '月初のピーク時間帯にAPI応答時間がp95で2.5秒を超えることがある', workaround: 'オートスケール閾値を月初は -10% で設定', fix_plan: 'v2.0でCQRS分離' },
      { issue_id: 'KI-002', severity: '低', summary: 'PDF出力時に印影が欠ける場合がある (Chrome 124+)', workaround: 'Edgeブラウザで再出力' },
    ],
    change_history: [
      { date: '2026-03-15', type: '法令対応', summary: 'インボイス制度対応 (適格請求書発行事業者番号フィールド追加)', ticket: 'JIRA-123' },
      { date: '2026-02-10', type: '機能追加', summary: '電子カルテとのHL7 FHIR連携モジュール追加', ticket: 'JIRA-098' },
      { date: '2026-01-20', type: 'セキュリティ', summary: 'CVE-2026-XXXX対応 (Node.js 20.11.1へアップグレード)', ticket: 'JIRA-087' },
    ],
    improvement_proposals: [
      { category: '技術的負債', description: '一部APIがv1のレガシーフォーマット。OpenAPI 3.1へ全面移行', estimated_pd: 12, expected_benefit: '保守性向上 / ドキュメント自動生成' },
      { category: 'セキュリティ強化', description: 'WAFをCloudFlare ProからEnterpriseへ', estimated_pd: 3, expected_benefit: 'BotManagement機能強化 / 不正アクセス疑い精度向上' },
    ],
    password_storage_locations: [
      '1Password (運用vault) - 運用メンバー全員が共有',
      'AWS Secrets Manager - サービスアカウント認証情報',
      '別途、契約書の写しは社内Boxの「医療RX/契約」フォルダ',
    ],
    contract_documents: [
      { title: '保守契約書 (2026-04-01 〜 2027-03-31)', storage_url_or_path: 's3://medical-rec-contracts/2026/maintenance.pdf' },
      { title: 'SLA別紙', storage_url_or_path: 's3://medical-rec-contracts/2026/sla.pdf' },
      { title: '個人情報取扱契約書', storage_url_or_path: 's3://medical-rec-contracts/2026/dpa.pdf' },
    ],
    handover_period_start: '2026-04-30',
    handover_period_end: '2026-07-31',
  },
});

console.log('===== 運用手順書 (抜粋) =====');
console.log(result.markdown.operations_manual.slice(0, 2000));
console.log('\n\n===== 障害対応Runbook (SEV分類抜粋) =====');
console.log(result.markdown.runbook.slice(0, 2000));
console.log('\n\n===== 保守計画書 (工数サマリ) =====');
console.log(`月次合計: ${result.maintenance_plan.total_monthly_pd.min} 〜 ${result.maintenance_plan.total_monthly_pd.max} 人日`);
console.log(`年次合計: ${result.maintenance_plan.total_annual_pd.min} 〜 ${result.maintenance_plan.total_annual_pd.max} 人日`);
console.log('\n\n===== SLA =====');
console.log(`可用性目標: ${(result.sla.meta.availability_target * 100).toFixed(2)}%`);
console.log(`月間許容ダウンタイム: ${result.sla.monthly_allowed_downtime_min}分`);
console.log(`RTO: ${result.sla.rto_minutes}分 / RPO: ${result.sla.rpo_minutes}分`);
console.log('\n\n===== オンコール (公平性) =====');
for (const f of result.oncall_schedule.fairness) {
  console.log(`- ${f.member}: 週数=${f.total_weeks} / 祝日=${f.total_holiday_days} / Index=${f.fairness_index}`);
}
console.log('\n\n===== 引継書 (8章タイトル一覧) =====');
for (const c of result.handover_doc.chapters) {
  console.log(`${c.chapter_no}. ${c.title_ja}`);
}
