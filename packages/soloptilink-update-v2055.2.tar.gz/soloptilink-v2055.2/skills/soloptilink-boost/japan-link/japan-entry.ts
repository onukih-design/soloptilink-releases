/**
 * Japan (日本法令・業種知識) → BOOST 連携エントリ (ビルド元)
 * ------------------------------------------------------------------
 * このファイルは esbuild で `japan-recall.bundle.mjs` に単一ファイルへ
 * バンドルされる「ビルド元ソース」。実行時はバンドル済み .mjs を bare node で動かす。
 *
 * 役割:
 *   - soloptilink-japan の「正規 API」(recommendLaws / recommendExtendedLaws /
 *     recommendFeatures / explainRecommendations) をそのまま呼ぶ(写経なし)。
 *   - BOOST が読み取れる JSON を stdout に出す。
 *
 * import 方針: index.ts は @/ alias や @soloptilink/legal-sdk 等の外部参照を含む
 *   ため経由しない。連携に必要な3ファイルを「直接」import する(これらは
 *   laws.ts/laws_extended.ts=import無し、feature_recommender.ts=type-onlyのみ)。
 *
 * 入力 (環境変数):
 *   JP_INDUSTRY  検出業種キー(construction/manufacturing/healthcare/retail/...)
 *   JP_TASK      依頼文(任意・推論補助)
 *   JP_ROLES     想定ロール カンマ区切り(任意)
 *
 * 出力 (stdout, 1行 JSON):
 *   { ok, mode, has_data, inference_block_markdown, injection_lines_for_agents }
 */

import { recommendLaws } from "../../soloptilink-japan/lib/japan/laws";
import { recommendExtendedLaws } from "../../soloptilink-japan/lib/japan/laws_extended";
import {
  recommendFeatures,
  explainRecommendations,
  selectTopRecommendations,
  type InferenceSummary,
} from "../../soloptilink-japan/lib/japan/feature_recommender";

function emit(obj: unknown): void {
  process.stdout.write(JSON.stringify(obj) + "\n");
}

interface JpResult {
  has_data: boolean;
  inference_block_markdown: string;
  injection_lines_for_agents: string[];
}

function buildJapanInjection(industry: string, task: string, roles: string[]): JpResult {
  // 業種も依頼文も無ければ no-op (BOOST 本流を止めない)。
  if (!industry && !task) {
    return {
      has_data: false,
      inference_block_markdown:
        "【Japan 自動適用】業種・依頼文が無いため適用なし。",
      injection_lines_for_agents: [],
    };
  }

  // 法令(基本3法は業種不明でも常に適用) + 業種別拡張法令をマージ。
  const baseLaws = recommendLaws(industry || "");
  const extLaws = recommendExtendedLaws(industry || "");
  const laws = Array.from(new Set([...baseLaws, ...extLaws]));

  // 業種別 優先実装機能の推薦。
  const inference: InferenceSummary = {
    industry: industry || undefined,
    roles: roles.length ? roles : undefined,
    scope: "new",
  };
  let recs = recommendFeatures(inference);
  try {
    // 上位のみに絞る(あれば)。
    recs = selectTopRecommendations(recs, 6) ?? recs;
  } catch {
    /* selectTopRecommendations が無い/失敗しても recs をそのまま使う */
  }

  const lines: string[] = [];

  // ① 法令準拠(最重要・全業務システム共通の日本堀)
  lines.push(
    `本システムは日本の以下の法令に準拠して設計・実装すること: ${laws.join(" / ")}。` +
      `特にインボイス制度(適格請求書発行事業者登録番号の保持・税率別の端数処理)、` +
      `電子帳簿保存法(電子取引データの保存要件・タイムスタンプ)、` +
      `個人情報保護法(安全管理措置・利用目的明示)は帳票・DB設計に反映すること。`,
  );

  // ② 業種別 優先実装機能
  const topFeatures = recs.slice(0, 4);
  for (const r of topFeatures) {
    const tmpl = r.required_templates?.length ? ` / 必要帳票=${r.required_templates.join("・")}` : "";
    lines.push(
      `優先実装機能『${r.feature}』(優先度${r.priority}): ${r.rationale}${tmpl}。`,
    );
  }

  // ③ 帳票・様式の日本標準
  const allTemplates = Array.from(
    new Set(recs.flatMap((r) => r.required_templates ?? [])),
  ).slice(0, 8);
  if (allTemplates.length > 0) {
    lines.push(
      `日本の業務で必要な帳票/様式を出力できるようにすること: ${allTemplates.join(" / ")}。`,
    );
  }

  // 推論ブロック(設計入力・人間可読)
  const block: string[] = [];
  block.push("【Japan 自動適用】日本法令・業種知識レイヤー");
  if (industry) block.push(`- 業種: ${industry}`);
  block.push(`- 適用法令: ${laws.join(" / ")}`);
  if (topFeatures.length > 0)
    block.push(`- 優先機能: ${topFeatures.map((r) => r.feature).join(" / ")}`);
  if (allTemplates.length > 0) block.push(`- 必要帳票: ${allTemplates.join(" / ")}`);

  return {
    has_data: true,
    inference_block_markdown: block.join("\n"),
    injection_lines_for_agents: lines,
  };
}

function runRecall(): void {
  const industry = (process.env.JP_INDUSTRY ?? "").trim();
  const task = (process.env.JP_TASK ?? "").trim();
  const roles = (process.env.JP_ROLES ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  const out = buildJapanInjection(industry, task, roles);
  emit({ ok: true, mode: "recall", ...out });
}

/**
 * born-passing 自己検証。
 * 業種あり → 法令+機能注入 / 業種不明 → 基本3法は注入 / 空 → no-op、を実証する。
 */
function runSelftest(): void {
  const failures: string[] = [];
  try {
    // positive: 建設業
    const pos = buildJapanInjection("construction", "建設業の原価管理システム", []);
    if (!pos.has_data) failures.push("建設業で has_data=false");
    const joined = pos.injection_lines_for_agents.join("\n");
    if (!/建設業法/.test(joined)) failures.push("建設業法が注入されない");
    if (!/インボイス/.test(joined)) failures.push("インボイス制度が注入されない");

    // 業種不明でも基本3法は出る(default safe)
    const unknown = buildJapanInjection("staffing-agency", "", []);
    if (!unknown.has_data) failures.push("未知業種で has_data=false");
    const ju = unknown.injection_lines_for_agents.join("\n");
    if (!/インボイス制度/.test(ju) || !/電子帳簿保存法/.test(ju) || !/個人情報保護法/.test(ju))
      failures.push("未知業種で基本3法が揃わない");

    // negative: 空 → no-op
    const empty = buildJapanInjection("", "", []);
    if (empty.has_data) failures.push("空入力で has_data=true (no-opでない)");
    if (empty.injection_lines_for_agents.length !== 0)
      failures.push("空入力で注入文が生成された");
  } catch (e) {
    failures.push("selftest 例外: " + (e as Error).message);
  }
  emit({ ok: failures.length === 0, mode: "selftest", failures });
  process.exit(failures.length === 0 ? 0 : 1);
}

const arg = process.argv[2] ?? "";
if (arg === "--selftest") {
  runSelftest();
} else {
  try {
    runRecall();
  } catch (e) {
    // 失敗は BOOST 本流を絶対に止めない。
    emit({
      ok: false,
      mode: "recall",
      has_data: false,
      inference_block_markdown: "",
      injection_lines_for_agents: [],
      error: (e as Error).message,
    });
  }
}
