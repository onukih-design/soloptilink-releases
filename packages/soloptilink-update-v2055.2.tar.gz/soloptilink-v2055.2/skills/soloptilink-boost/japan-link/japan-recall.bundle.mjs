// ../../../.soloptilink/skills/soloptilink-japan/lib/japan/laws.ts
function recommendLaws(industry) {
  const base = ["\u30A4\u30F3\u30DC\u30A4\u30B9\u5236\u5EA6", "\u96FB\u5B50\u5E33\u7C3F\u4FDD\u5B58\u6CD5", "\u500B\u4EBA\u60C5\u5831\u4FDD\u8B77\u6CD5"];
  switch (industry) {
    case "construction":
      return [...base, "\u5EFA\u8A2D\u696D\u6CD5", "\u4E0B\u8ACB\u6CD5", "\u52B4\u50CD\u57FA\u6E96\u6CD5"];
    case "manufacturing":
      return [...base, "\u4E0B\u8ACB\u6CD5", "PL\u6CD5", "\u52B4\u50CD\u57FA\u6E96\u6CD5"];
    case "healthcare":
      return [...base, "\u30DE\u30A4\u30CA\u30F3\u30D0\u30FC\u6CD5", "\u533B\u7642\u6CD5", "\u4ECB\u8B77\u4FDD\u967A\u6CD5"];
    case "professional":
      return [...base, "\u30DE\u30A4\u30CA\u30F3\u30D0\u30FC\u6CD5", "\u58EB\u696D\u6CD5", "\u52B4\u50CD\u57FA\u6E96\u6CD5"];
    case "retail":
      return [...base, "\u666F\u54C1\u8868\u793A\u6CD5", "\u7279\u5B9A\u5546\u53D6\u5F15\u6CD5"];
    case "food_service":
      return [...base, "\u98DF\u54C1\u885B\u751F\u6CD5", "\u666F\u54C1\u8868\u793A\u6CD5"];
    case "finance":
      return [...base, "\u91D1\u878D\u5546\u54C1\u53D6\u5F15\u6CD5", "\u8CB8\u91D1\u696D\u6CD5", "\u8CC7\u91D1\u6C7A\u6E08\u6CD5"];
    default:
      return base;
  }
}

// ../../../.soloptilink/skills/soloptilink-japan/lib/japan/laws_extended.ts
function recommendExtendedLaws(industry) {
  switch (industry) {
    case "construction":
      return ["\u52B4\u50CD\u5B89\u5168\u885B\u751F\u6CD5"];
    case "manufacturing":
      return ["PL\u6CD5", "\u52B4\u50CD\u5B89\u5168\u885B\u751F\u6CD5"];
    case "food_service":
      return ["\u98DF\u54C1\u885B\u751F\u6CD5", "\u98DF\u54C1\u8868\u793A\u6CD5", "PL\u6CD5"];
    case "healthcare":
      return ["\u85AC\u6A5F\u6CD5", "\u52B4\u50CD\u5B89\u5168\u885B\u751F\u6CD5"];
    case "beauty":
      return ["\u85AC\u6A5F\u6CD5", "\u666F\u54C1\u8868\u793A\u6CD5"];
    case "real_estate":
      return ["\u5B85\u5730\u5EFA\u7269\u53D6\u5F15\u696D\u6CD5"];
    case "hotel":
    case "bridal":
      return ["\u65C5\u9928\u696D\u6CD5", "\u98DF\u54C1\u885B\u751F\u6CD5"];
    case "childcare":
    case "education":
      return ["\u5150\u7AE5\u798F\u7949\u6CD5"];
    case "retail":
      return ["\u666F\u54C1\u8868\u793A\u6CD5", "\u7279\u5B9A\u5546\u53D6\u5F15\u6CD5", "PL\u6CD5"];
    case "advertising":
      return ["\u666F\u54C1\u8868\u793A\u6CD5", "\u85AC\u6A5F\u6CD5"];
    case "logistics":
    case "transport":
      return ["\u52B4\u50CD\u5B89\u5168\u885B\u751F\u6CD5"];
    case "it":
      return ["\u52B4\u50CD\u8005\u6D3E\u9063\u6CD5"];
    default:
      return [];
  }
}

// ../../../.soloptilink/skills/soloptilink-japan/lib/japan/feature_recommender.ts
var INDUSTRY_FEATURE_BUNDLE = {
  construction: [
    {
      feature: "\u6982\u7B97\u898B\u7A4D\u30A8\u30F3\u30B8\u30F3 (\u576A\u5358\u4FA1\u2192\u6570\u91CF\u62FE\u3044\u2192\u8A73\u7D30)",
      rationale: "\u5EFA\u8A2D\u696D\u306E80%\u304C\u521D\u56DE\u554F\u3044\u5408\u308F\u305B\u6642\u306B\u6982\u7B97\u898B\u7A4D\u3092\u8981\u6C42 (\u696D\u7A2E\u30D2\u30A2\u30EA\u30F3\u30B0\u96C6\u8A08)",
      priority: "P0",
      required_modules: ["estimates", "architecture", "regional_laws"],
      required_dictionaries: ["construction"],
      required_templates: ["Estimate", "Invoice"],
      estimated_quality_lift: 8
    },
    {
      feature: "\u5EFA\u8A2D\u696D\u6CD5\u6E96\u62E0 \u53D7\u6CE8\u53F0\u5E33",
      rationale: "\u4E0B\u8ACB\u6CD5+\u5EFA\u8A2D\u696D\u6CD5 19\u6761\u306E3 \u306E\u7F70\u5247\u56DE\u907F\u304C\u6700\u91CD\u8981",
      priority: "P0",
      required_modules: ["laws", "save_guarantee"],
      required_dictionaries: ["construction"],
      required_templates: ["PurchaseOrder", "DeliveryNote"],
      estimated_quality_lift: 6
    }
  ],
  healthcare: [
    {
      feature: "\u8A3A\u7642\u5831\u916C\u8A08\u7B97 + UKE\u30EC\u30BB\u30D7\u30C8\u96FB\u7B97\u51E6\u7406",
      rationale: "\u533B\u7642\u6A5F\u95A2\u3067\u306F\u6708\u521D\u306E\u30EC\u30BB\u30D7\u30C8\u63D0\u51FA\u304C\u6CD5\u5B9A\u7FA9\u52D9 (R6\u6539\u5B9A\u5BFE\u5FDC\u5FC5\u9808)",
      priority: "P0",
      required_modules: ["medical", "law_tracker"],
      required_dictionaries: ["healthcare"],
      required_templates: ["Invoice", "Receipt"],
      estimated_quality_lift: 10
    },
    {
      feature: "HPKI \u96FB\u5B50\u7F72\u540D (3\u77012\u30AC\u30A4\u30C9\u30E9\u30A4\u30F3\u6E96\u62E0)",
      rationale: "\u96FB\u5B50\u30AB\u30EB\u30C6/\u51E6\u65B9\u7B8B\u306E\u672C\u4EBA\u8A8D\u8A3C\u3067\u5FC5\u9808",
      priority: "P1",
      required_modules: ["medical", "eseal"],
      required_dictionaries: ["healthcare"],
      required_templates: [],
      estimated_quality_lift: 5
    }
  ],
  longterm_care: [
    {
      feature: "\u4ECB\u8B77\u5831\u916C\u8A08\u7B97 + LIFE \u79D1\u5B66\u7684\u4ECB\u8B77\u60C5\u5831\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9",
      rationale: "R6\u6539\u5B9A\u3067\u51E6\u9047\u6539\u5584\u52A0\u7B97\u304C\u4E00\u672C\u5316\u3001LIFE\u63D0\u51FA\u306F\u52A0\u7B97\u8981\u4EF6",
      priority: "P0",
      required_modules: ["longterm_care"],
      required_dictionaries: ["healthcare"],
      required_templates: ["Invoice"],
      estimated_quality_lift: 9
    },
    {
      feature: "\u30B1\u30A2\u30D7\u30E9\u30F31\u301C7\u8868 \u81EA\u52D5\u751F\u6210",
      rationale: "\u5C45\u5B85\u4ECB\u8B77\u652F\u63F4\u4E8B\u696D\u6240\u306E\u5FC5\u9808\u5E33\u7968",
      priority: "P0",
      required_modules: ["longterm_care"],
      required_dictionaries: ["healthcare"],
      required_templates: ["Report"],
      estimated_quality_lift: 7
    }
  ],
  finance: [
    {
      feature: "\u5168\u9280\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8 120\u30D0\u30A4\u30C8\u56FA\u5B9A\u9577\u632F\u8FBC\u30D5\u30A1\u30A4\u30EB\u751F\u6210",
      rationale: "\u91D1\u878D\u6A5F\u95A2\u9023\u643A\u306E\u4E8B\u5B9F\u4E0A\u306E\u30C7\u30D5\u30A1\u30AF\u30C8",
      priority: "P0",
      required_modules: ["finance"],
      required_dictionaries: ["finance"],
      required_templates: [],
      estimated_quality_lift: 8
    },
    {
      feature: "\u91D1\u5546\u6CD5\u9069\u5408\u6027\u539F\u5247 \u81EA\u52D5\u30C1\u30A7\u30C3\u30AF (75\u6B73/\u6295\u8CC7\u7D4C\u9A13/\u7D14\u8CC7\u7523)",
      rationale: "\u91D1\u878D\u5546\u54C1\u53D6\u5F15\u696D\u306E\u8AAC\u660E\u8CAC\u4EFB\u3067\u5FC5\u9808",
      priority: "P1",
      required_modules: ["finance", "laws_extended"],
      required_dictionaries: ["finance"],
      required_templates: ["Contract"],
      estimated_quality_lift: 6
    }
  ],
  retail: [
    {
      feature: "\u666F\u8868\u6CD5 + \u7279\u5546\u6CD5 \u30DE\u30FC\u30B1\u30B3\u30D4\u30FC\u691C\u8A3C",
      rationale: "EC/\u5C0F\u58F2\u306E\u8CA9\u4FC3\u6587\u8A00\u306F\u666F\u8868\u6CD5\u7B2C5\u6761 (\u512A\u826F\u8AA4\u8A8D/\u6709\u5229\u8AA4\u8A8D) \u9055\u53CD\u30EA\u30B9\u30AF",
      priority: "P0",
      required_modules: ["marketing_compliance"],
      required_dictionaries: ["retail"],
      required_templates: [],
      estimated_quality_lift: 7
    },
    {
      feature: "RFM\u5206\u6790 + LTV\u4E88\u6E2C",
      rationale: "\u9867\u5BA2\u30BB\u30B0\u30E1\u30F3\u30C8\u5225\u306E\u6253\u3061\u624B\u306E\u6839\u62E0\u4ED8\u3051",
      priority: "P1",
      required_modules: ["customer_journey"],
      required_dictionaries: ["retail"],
      required_templates: ["Report"],
      estimated_quality_lift: 5
    }
  ],
  it: [
    {
      feature: "SES\u5951\u7D04\u66F8 + 36\u5354\u5B9A \u81EA\u52D5\u30C1\u30A7\u30C3\u30AF",
      rationale: "\u52B4\u57FA\u6CD5+\u6D3E\u9063\u6CD5\u306E\u30EA\u30B9\u30AF\u304C\u96C6\u4E2D\u3059\u308B\u696D\u7A2E",
      priority: "P1",
      required_modules: ["laws", "hr_payroll"],
      required_dictionaries: ["it"],
      required_templates: ["Contract"],
      estimated_quality_lift: 6
    }
  ]
};
var COMMON_BACKBONE = [
  {
    feature: "save_guarantee.ts \u306B\u3088\u308B\u5168 CRUD \u9632\u5FA1\u5C64",
    rationale: "Phase 6 \u30D0\u30B0\u4E88\u9632DNA: 23502/UNIQUE/FK/\u697D\u89B3\u30ED\u30C3\u30AF \u591A\u767A\u9632\u6B62",
    priority: "P0",
    required_modules: ["save_guarantee", "bug_prevention"],
    required_dictionaries: [],
    required_templates: [],
    estimated_quality_lift: 8
  },
  {
    feature: "\u30ED\u30FC\u30EB\u8A2D\u8A08 (admin/user \u5C0F\u6587\u5B57\u7D71\u4E00) + RBAC",
    rationale: "\u904E\u53BB\u4E8B\u4F8B: \u30ED\u30FC\u30EB\u5927\u6587\u5B57\u6DF7\u5165\u3067 SSO/RBAC \u8AA4\u52D5\u4F5C\u591A\u767A",
    priority: "P0",
    required_modules: [],
    required_dictionaries: [],
    required_templates: [],
    estimated_quality_lift: 5
  },
  {
    feature: "\u76E3\u67FB\u30ED\u30B0 + WORM\u4FDD\u7BA1",
    rationale: "\u500B\u60C5\u6CD5\u7B2C26\u6761 R4\u6539\u6B63\u5BFE\u5FDC + J-SOX ITGC",
    priority: "P1",
    required_modules: ["security_audit", "incident"],
    required_dictionaries: [],
    required_templates: [],
    estimated_quality_lift: 6
  }
];
function recommendFeatures(inference, coverage = [], usage = []) {
  const out = [];
  if (inference.industry) {
    const bundle = INDUSTRY_FEATURE_BUNDLE[inference.industry];
    if (bundle) out.push(...bundle);
  }
  out.push(...COMMON_BACKBONE);
  const lowQualityDomain = coverage.find(
    (c) => c.domain === inference.industry && (c.avg_quality_score ?? 100) < 80
  );
  if (lowQualityDomain) {
    out.push({
      feature: `${inference.industry} \u696D\u7A2E\u306E\u54C1\u8CEA\u30D9\u30F3\u30C1\u30DE\u30FC\u30AF\u5F37\u5316 (\u73FE\u72B6 ${lowQualityDomain.avg_quality_score})`,
      rationale: "\u904E\u53BB\u30BB\u30C3\u30B7\u30E7\u30F3\u306E\u5E73\u5747\u54C1\u8CEA\u30B9\u30B3\u30A2\u304C\u95BE\u5024\u672A\u6E80",
      priority: "P0",
      required_modules: ["learning_analytics", "usage_insights"],
      required_dictionaries: inference.industry ? [inference.industry] : [],
      required_templates: [],
      estimated_quality_lift: 10
    });
  }
  if (usage.some((u) => u.module === "marketing_compliance" && u.trend_30d === "rising")) {
    out.push({
      feature: "marketing_compliance.ts \u306B\u3088\u308B\u666F\u8868\u6CD5\u30D0\u30CA\u30FC\u691C\u8A3C",
      rationale: "\u76F4\u8FD130\u65E5\u3067\u5229\u7528\u7387\u4E0A\u6607\u4E2D\u306E\u4EBA\u6C17\u30E2\u30B8\u30E5\u30FC\u30EB",
      priority: "P1",
      required_modules: ["marketing_compliance"],
      required_dictionaries: [],
      required_templates: [],
      estimated_quality_lift: 4
    });
  }
  return dedupePreservingOrder(out);
}
function dedupePreservingOrder(arr) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const r of arr) {
    if (seen.has(r.feature)) continue;
    seen.add(r.feature);
    out.push(r);
  }
  return out;
}
function selectTopRecommendations(recs, options = {}) {
  const { maxP0 = 5, maxP1 = 5, maxP2 = 3 } = options;
  const p0 = recs.filter((r) => r.priority === "P0").slice(0, maxP0);
  const p1 = recs.filter((r) => r.priority === "P1").slice(0, maxP1);
  const p2 = recs.filter((r) => r.priority === "P2").slice(0, maxP2);
  return [...p0, ...p1, ...p2];
}

// ../../../.claude/skills/soloptilink-boost/japan-link/japan-entry.ts
function emit(obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
}
function buildJapanInjection(industry, task, roles) {
  if (!industry && !task) {
    return {
      has_data: false,
      inference_block_markdown: "\u3010Japan \u81EA\u52D5\u9069\u7528\u3011\u696D\u7A2E\u30FB\u4F9D\u983C\u6587\u304C\u7121\u3044\u305F\u3081\u9069\u7528\u306A\u3057\u3002",
      injection_lines_for_agents: []
    };
  }
  const baseLaws = recommendLaws(industry || "");
  const extLaws = recommendExtendedLaws(industry || "");
  const laws = Array.from(/* @__PURE__ */ new Set([...baseLaws, ...extLaws]));
  const inference = {
    industry: industry || void 0,
    roles: roles.length ? roles : void 0,
    scope: "new"
  };
  let recs = recommendFeatures(inference);
  try {
    recs = selectTopRecommendations(recs, 6) ?? recs;
  } catch {
  }
  const lines = [];
  lines.push(
    `\u672C\u30B7\u30B9\u30C6\u30E0\u306F\u65E5\u672C\u306E\u4EE5\u4E0B\u306E\u6CD5\u4EE4\u306B\u6E96\u62E0\u3057\u3066\u8A2D\u8A08\u30FB\u5B9F\u88C5\u3059\u308B\u3053\u3068: ${laws.join(" / ")}\u3002\u7279\u306B\u30A4\u30F3\u30DC\u30A4\u30B9\u5236\u5EA6(\u9069\u683C\u8ACB\u6C42\u66F8\u767A\u884C\u4E8B\u696D\u8005\u767B\u9332\u756A\u53F7\u306E\u4FDD\u6301\u30FB\u7A0E\u7387\u5225\u306E\u7AEF\u6570\u51E6\u7406)\u3001\u96FB\u5B50\u5E33\u7C3F\u4FDD\u5B58\u6CD5(\u96FB\u5B50\u53D6\u5F15\u30C7\u30FC\u30BF\u306E\u4FDD\u5B58\u8981\u4EF6\u30FB\u30BF\u30A4\u30E0\u30B9\u30BF\u30F3\u30D7)\u3001\u500B\u4EBA\u60C5\u5831\u4FDD\u8B77\u6CD5(\u5B89\u5168\u7BA1\u7406\u63AA\u7F6E\u30FB\u5229\u7528\u76EE\u7684\u660E\u793A)\u306F\u5E33\u7968\u30FBDB\u8A2D\u8A08\u306B\u53CD\u6620\u3059\u308B\u3053\u3068\u3002`
  );
  const topFeatures = recs.slice(0, 4);
  for (const r of topFeatures) {
    const tmpl = r.required_templates?.length ? ` / \u5FC5\u8981\u5E33\u7968=${r.required_templates.join("\u30FB")}` : "";
    lines.push(
      `\u512A\u5148\u5B9F\u88C5\u6A5F\u80FD\u300E${r.feature}\u300F(\u512A\u5148\u5EA6${r.priority}): ${r.rationale}${tmpl}\u3002`
    );
  }
  const allTemplates = Array.from(
    new Set(recs.flatMap((r) => r.required_templates ?? []))
  ).slice(0, 8);
  if (allTemplates.length > 0) {
    lines.push(
      `\u65E5\u672C\u306E\u696D\u52D9\u3067\u5FC5\u8981\u306A\u5E33\u7968/\u69D8\u5F0F\u3092\u51FA\u529B\u3067\u304D\u308B\u3088\u3046\u306B\u3059\u308B\u3053\u3068: ${allTemplates.join(" / ")}\u3002`
    );
  }
  const block = [];
  block.push("\u3010Japan \u81EA\u52D5\u9069\u7528\u3011\u65E5\u672C\u6CD5\u4EE4\u30FB\u696D\u7A2E\u77E5\u8B58\u30EC\u30A4\u30E4\u30FC");
  if (industry) block.push(`- \u696D\u7A2E: ${industry}`);
  block.push(`- \u9069\u7528\u6CD5\u4EE4: ${laws.join(" / ")}`);
  if (topFeatures.length > 0)
    block.push(`- \u512A\u5148\u6A5F\u80FD: ${topFeatures.map((r) => r.feature).join(" / ")}`);
  if (allTemplates.length > 0) block.push(`- \u5FC5\u8981\u5E33\u7968: ${allTemplates.join(" / ")}`);
  return {
    has_data: true,
    inference_block_markdown: block.join("\n"),
    injection_lines_for_agents: lines
  };
}
function runRecall() {
  const industry = (process.env.JP_INDUSTRY ?? "").trim();
  const task = (process.env.JP_TASK ?? "").trim();
  const roles = (process.env.JP_ROLES ?? "").split(",").map((s) => s.trim()).filter(Boolean);
  const out = buildJapanInjection(industry, task, roles);
  emit({ ok: true, mode: "recall", ...out });
}
function runSelftest() {
  const failures = [];
  try {
    const pos = buildJapanInjection("construction", "\u5EFA\u8A2D\u696D\u306E\u539F\u4FA1\u7BA1\u7406\u30B7\u30B9\u30C6\u30E0", []);
    if (!pos.has_data) failures.push("\u5EFA\u8A2D\u696D\u3067 has_data=false");
    const joined = pos.injection_lines_for_agents.join("\n");
    if (!/建設業法/.test(joined)) failures.push("\u5EFA\u8A2D\u696D\u6CD5\u304C\u6CE8\u5165\u3055\u308C\u306A\u3044");
    if (!/インボイス/.test(joined)) failures.push("\u30A4\u30F3\u30DC\u30A4\u30B9\u5236\u5EA6\u304C\u6CE8\u5165\u3055\u308C\u306A\u3044");
    const unknown = buildJapanInjection("staffing-agency", "", []);
    if (!unknown.has_data) failures.push("\u672A\u77E5\u696D\u7A2E\u3067 has_data=false");
    const ju = unknown.injection_lines_for_agents.join("\n");
    if (!/インボイス制度/.test(ju) || !/電子帳簿保存法/.test(ju) || !/個人情報保護法/.test(ju))
      failures.push("\u672A\u77E5\u696D\u7A2E\u3067\u57FA\u672C3\u6CD5\u304C\u63C3\u308F\u306A\u3044");
    const empty = buildJapanInjection("", "", []);
    if (empty.has_data) failures.push("\u7A7A\u5165\u529B\u3067 has_data=true (no-op\u3067\u306A\u3044)");
    if (empty.injection_lines_for_agents.length !== 0)
      failures.push("\u7A7A\u5165\u529B\u3067\u6CE8\u5165\u6587\u304C\u751F\u6210\u3055\u308C\u305F");
  } catch (e) {
    failures.push("selftest \u4F8B\u5916: " + e.message);
  }
  emit({ ok: failures.length === 0, mode: "selftest", failures });
  process.exit(failures.length === 0 ? 0 : 1);
}
var arg = process.argv[2] ?? "";
if (arg === "--selftest") {
  runSelftest();
} else {
  try {
    runRecall();
  } catch (e) {
    emit({
      ok: false,
      mode: "recall",
      has_data: false,
      inference_block_markdown: "",
      injection_lines_for_agents: [],
      error: e.message
    });
  }
}
