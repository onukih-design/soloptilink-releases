#!/usr/bin/env bash
# publish.sh - ゲームを各配信先向けにパッケージング
# /soloptilink-game の Step 8 で呼ばれる

set -euo pipefail
IFS=$'\n\t'

TARGET=""
PROJECT=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --target)  TARGET="$2";  shift 2;;
    --project) PROJECT="$2"; shift 2;;
    --help|-h)
      echo "使い方: bash publish.sh --target <web|itch.io|steam|appstore|playstore> --project <dir>"
      exit 0;;
    *) echo "[ERR] 未知の引数: $1" >&2; exit 2;;
  esac
done

[[ -z "$TARGET"  ]] && { echo "[ERR] --target 未指定"; exit 2; }
[[ -z "$PROJECT" ]] && { echo "[ERR] --project 未指定"; exit 2; }
[[ -d "$PROJECT" ]] || { echo "[ERR] プロジェクト未検出: $PROJECT"; exit 3; }

cd "$PROJECT"

echo "📦 [publish] 配信パッケージング: $TARGET"

case "$TARGET" in
  web)
    npm run build
    echo "✅ web: dist/ をホスティング(Vercel/Netlify/GitHub Pages)に配置してください"
    ;;
  itch.io)
    npm run build
    ZIP="dist-itch.zip"
    (cd dist && zip -r "../$ZIP" .)
    cat > .itch.toml <<EOF
[[actions]]
name = "play"
path = "index.html"
scope = "browser"
EOF
    echo "✅ itch.io: $ZIP を作成しました"
    echo "    アップロード: butler push $ZIP <user>/<game>:web"
    ;;
  steam)
    echo "ℹ️ Steam配信は Godot(godotエンジン)プロジェクトでのみ完全自動化されます"
    echo "    Steamworks SDK の手動設定が必要です: https://partner.steamgames.com/"
    ;;
  appstore|playstore)
    echo "ℹ️ Capacitor を初期化してネイティブビルドを作成します"
    if ! command -v cap >/dev/null 2>&1; then
      npm install -D @capacitor/cli @capacitor/core
    fi
    npx cap init "$(basename "$PROJECT")" "com.soloptilink.$(basename "$PROJECT" | tr '[:upper:]' '[:lower:]')" --web-dir=dist 2>/dev/null || true
    npm run build
    if [[ "$TARGET" == "appstore" ]]; then
      npx cap add ios
      npx cap copy ios
      echo "✅ iOS プロジェクトを生成しました: ios/"
      echo "    Xcode で開く: npx cap open ios"
    else
      npx cap add android
      npx cap copy android
      echo "✅ Android プロジェクトを生成しました: android/"
      echo "    Android Studio で開く: npx cap open android"
    fi
    ;;
  *)
    echo "[ERR] 未対応ターゲット: $TARGET"
    echo "    対応: web | itch.io | steam | appstore | playstore"
    exit 4;;
esac
