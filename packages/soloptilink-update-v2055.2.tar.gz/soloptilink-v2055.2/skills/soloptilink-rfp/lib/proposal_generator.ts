/**
 * Proposal Generator - 日本SI標準フォーマットの提案書生成
 *
 * 出力: 提案書 .docx 用の構造化データ + Markdown版 (anthropic-skills:docx 経由で .docx 化)
 */

import type { RfpDna } from './rfp_parser';
import type { EstimateResult } from './cost_estimator';
import type { WbsResult } from './wbs_generator';

export interface CompanyInfo {
  name: string;
  name_kana?: string;
  address: string;
  phone?: string;
  email?: string;
  representative?: string;
  license_no?: string;
  capital_jpy?: number;
  established?: string;
  employees?: number;
  website?: string;
}

export interface SimilarCase {
  client_name?: string;
  industry: string;
  scale: string;
  duration_months: number;
  technologies: string[];
  outcome: string;
}

export interface ProposalDocument {
  meta: {
    generated_at: string;
    project_name: string;
    proposer_company: CompanyInfo;
    client_name: string;
    proposal_date: string;
    proposal_version: string;
  };
  sections: ProposalSection[];
  appendices: ProposalSection[];
}

export interface ProposalSection {
  section_id: string;
  title: string;
  content: string;
  subsections?: ProposalSection[];
  tables?: ProposalTable[];
  diagrams?: { type: string; mermaid?: string; description: string }[];
}

export interface ProposalTable {
  caption: string;
  headers: string[];
  rows: string[][];
}

export interface GenerateProposalInput {
  rfp: RfpDna;
  estimate?: EstimateResult;
  wbs?: WbsResult;
  proposer_company: CompanyInfo;
  client_name?: string;
  approach?: 'waterfall' | 'agile' | 'hybrid';
  similar_cases?: SimilarCase[];
  team_structure?: TeamStructure;
}

export interface TeamStructure {
  pm: { name: string; experience_years: number; profile?: string };
  architect?: { name: string; experience_years: number; profile?: string };
  lead_engineer?: { name: string; experience_years: number; profile?: string };
  members: { role: string; count: number }[];
}

export function generateProposal(input: GenerateProposalInput): ProposalDocument {
  const { rfp, proposer_company } = input;
  const proposalDate = new Date().toISOString().slice(0, 10);
  const projectName = rfp.goal.primary;

  const sections: ProposalSection[] = [
    buildIntroduction(rfp, proposer_company, input.client_name),
    buildOverview(rfp, input.approach ?? 'waterfall'),
    buildSystemRequirements(rfp),
    buildArchitecture(rfp, input.approach ?? 'waterfall'),
    buildSchedule(input.wbs),
    buildTeamStructure(input.team_structure),
    buildMethodology(input.approach ?? 'waterfall'),
    buildCost(input.estimate),
    buildRiskManagement(rfp),
    buildSimilarCases(input.similar_cases ?? []),
    buildCompanyProfile(proposer_company),
    buildCommitment(rfp),
  ];

  const appendices: ProposalSection[] = [
    buildRfpDnaAppendix(rfp),
    buildImplicitRequirementsAppendix(rfp),
    buildLegalCompliance(rfp),
  ];

  return {
    meta: {
      generated_at: new Date().toISOString(),
      project_name: projectName,
      proposer_company,
      client_name: input.client_name ?? '貴社',
      proposal_date: proposalDate,
      proposal_version: '1.0',
    },
    sections,
    appendices,
  };
}

function buildIntroduction(rfp: RfpDna, company: CompanyInfo, clientName?: string): ProposalSection {
  return {
    section_id: '1',
    title: 'はじめに',
    content: [
      `${clientName ?? '貴社'}におかれましては、平素より格別のご高配を賜り厚く御礼申し上げます。`,
      '',
      `この度ご提示いただきましたRFPに基づき、以下のとおりご提案申し上げます。`,
      '',
      `本提案は、${rfp.goal.primary}を実現することを主目的とし、`,
      rfp.goal.business_drivers.length > 0 ? `特に「${rfp.goal.business_drivers.join('」「')}」 という背景課題に対する解決策を提示するものです。` : '',
      '',
      `弊社${company.name}は、これまで多数の${rfp.meta.industry_ja ?? '業務システム'}構築実績を有しており、`,
      `本プロジェクトにおいても確実な成果を提供させていただきます。`,
    ].filter(Boolean).join('\n'),
  };
}

function buildOverview(rfp: RfpDna, approach: string): ProposalSection {
  return {
    section_id: '2',
    title: '提案概要',
    content: [
      `本プロジェクトでは、${rfp.goal.primary}を達成するため、以下のアプローチで開発を進めます。`,
      '',
      `**期待される効果**:`,
      ...rfp.goal.success_metrics.map((m) => `- ${m}`),
      '',
      `**開発手法**: ${approach === 'waterfall' ? 'ウォーターフォール型 (要件確定 → 段階的進捗)' : approach === 'agile' ? 'アジャイル型 (スプリント単位反復)' : 'ハイブリッド型 (要件定義はウォーターフォール、実装はアジャイル)'}`,
      '',
      `**主要機能**:`,
      ...rfp.scope.in_scope.slice(0, 8).map((s) => `- ${s}`),
    ].filter(Boolean).join('\n'),
  };
}

function buildSystemRequirements(rfp: RfpDna): ProposalSection {
  const implicitTable: ProposalTable = {
    caption: '暗黙要件 (RFPから自動抽出)',
    headers: ['キーワード', '優先度', '推奨機能', '理由'],
    rows: rfp.implicit_requirements.map((r) => [
      r.trigger_keyword,
      r.priority,
      r.inferred_features.slice(0, 3).join(' / '),
      r.rationale,
    ]),
  };

  return {
    section_id: '3',
    title: 'システム要件',
    content: [
      `## 機能要件`,
      ...rfp.scope.in_scope.map((s, i) => `${i + 1}. ${s}`),
      '',
      `## 非機能要件`,
      `- **可用性**: SLO 99.9% (年間ダウンタイム < 8.76時間)`,
      `- **性能**: 通常時応答 < 200ms / ピーク時 < 500ms`,
      `- **セキュリティ**: OWASP Top 10対策、TLS 1.3、暗号化保管`,
      `- **保守性**: コードカバレッジ80%+、技術文書整備`,
      `- **可観測性**: ヘルスチェック、メトリクス、ログ集約、アラート`,
      '',
      `## 制約条件`,
      ...rfp.constraints.technical.map((c) => `- 技術: ${c}`),
      ...rfp.constraints.legal.map((c) => `- 法令: ${c}`),
      rfp.constraints.budget ? `- 予算: ¥${rfp.constraints.budget.toLocaleString()}` : '',
      rfp.constraints.deadline ? `- 納期: ${rfp.constraints.deadline}` : '',
    ].filter(Boolean).join('\n'),
    tables: [implicitTable],
  };
}

function buildArchitecture(rfp: RfpDna, approach: string): ProposalSection {
  const stack = recommendStack(rfp);
  return {
    section_id: '4',
    title: 'システム構成',
    content: [
      `## アーキテクチャ概要`,
      `${approach === 'agile' ? '段階的構築可能なモノリス→マイクロサービス遷移可能なモジュラーモノリス構成' : '安定運用重視の3層アーキテクチャ (フロントエンド / バックエンド / データベース)'}を採用します。`,
      '',
      `## 技術スタック`,
      `- **フロントエンド**: ${stack.frontend.join(' / ')}`,
      `- **バックエンド**: ${stack.backend.join(' / ')}`,
      `- **データベース**: ${stack.database.join(' / ')}`,
      `- **インフラ**: ${stack.infra.join(' / ')}`,
      `- **CI/CD**: ${stack.cicd.join(' / ')}`,
      `- **監視**: ${stack.monitoring.join(' / ')}`,
      '',
      `## 選定理由`,
      `- 日本市場での豊富な実績・人材確保容易性`,
      `- 長期保守を考慮したエコシステムの活発さ`,
      `- セキュリティパッチ対応の迅速性`,
      `- 業界標準ライブラリのサポート`,
    ].join('\n'),
    diagrams: [
      {
        type: 'system_architecture',
        mermaid: `graph LR
  User[ユーザ] --> CDN[CDN/WAF]
  CDN --> LB[Load Balancer]
  LB --> Web[Web App<br/>${stack.frontend[0]}]
  Web --> API[API Server<br/>${stack.backend[0]}]
  API --> DB[(${stack.database[0]})]
  API --> Cache[(Redis)]
  API --> Queue[Message Queue]
  API --> Monitoring[${stack.monitoring[0]}]`,
        description: 'システム全体構成図 (3層+監視レイヤー)',
      },
    ],
  };
}

function recommendStack(rfp: RfpDna): {
  frontend: string[];
  backend: string[];
  database: string[];
  infra: string[];
  cicd: string[];
  monitoring: string[];
} {
  const isPublic = rfp.meta.client_type === '公共' || rfp.meta.client_type === '自治体';
  const isMobile = rfp.implicit_requirements.some((r) => r.trigger_keyword === 'モバイル');
  return {
    frontend: [
      isMobile ? 'Next.js 15 (PWA対応)' : 'Next.js 15',
      'React 19',
      'Tailwind CSS v4',
      'shadcn/ui',
    ],
    backend: ['Node.js 22 LTS', 'TypeScript 5.6', 'Hono / Express', 'Prisma ORM'],
    database: [isPublic ? 'PostgreSQL 16 (オンプレ可)' : 'PostgreSQL 16 (RDS/Neon)'],
    infra: [isPublic ? 'オンプレ + ガバメントクラウド' : 'Vercel / AWS'],
    cicd: ['GitHub Actions', 'Docker', 'Terraform'],
    monitoring: ['Sentry', 'Datadog', 'CloudWatch'],
  };
}

function buildSchedule(wbs?: WbsResult): ProposalSection {
  if (!wbs) {
    return {
      section_id: '5',
      title: '開発スケジュール',
      content: 'WBSは別添資料をご参照ください。',
    };
  }
  return {
    section_id: '5',
    title: '開発スケジュール',
    content: [
      `**期間**: ${wbs.meta.project_start} 〜 ${wbs.meta.project_end}`,
      `**総工数**: ${wbs.meta.total_effort_md} 人月`,
      '',
      `## 主要マイルストーン`,
      ...wbs.milestones.map((m) => `- ${m.date}: ${m.name}`),
    ].join('\n'),
    tables: [
      {
        caption: 'フェーズ別スケジュール',
        headers: ['フェーズ', '開始', '終了', '日数'],
        rows: wbs.root.children.map((c) => [
          c.name,
          new Date(new Date(wbs.meta.project_start).getTime() + c.start_offset_days * 86400000).toISOString().slice(0, 10),
          new Date(new Date(wbs.meta.project_start).getTime() + c.end_offset_days * 86400000).toISOString().slice(0, 10),
          String(c.duration_days),
        ]),
      },
    ],
  };
}

function buildTeamStructure(team?: TeamStructure): ProposalSection {
  return {
    section_id: '6',
    title: '実施体制',
    content: team
      ? [
          `## プロジェクト体制`,
          `- **PM**: ${team.pm.name} (経験 ${team.pm.experience_years}年)`,
          team.architect ? `- **アーキテクト**: ${team.architect.name} (経験 ${team.architect.experience_years}年)` : '',
          team.lead_engineer ? `- **リードエンジニア**: ${team.lead_engineer.name} (経験 ${team.lead_engineer.experience_years}年)` : '',
          '',
          `## メンバー`,
          ...team.members.map((m) => `- ${m.role} × ${m.count}名`),
        ].filter(Boolean).join('\n')
      : '体制図は別途調整の上、契約締結時にご提示します。',
  };
}

function buildMethodology(approach: string): ProposalSection {
  if (approach === 'agile') {
    return {
      section_id: '7',
      title: '開発手法',
      content: [
        `## アジャイル開発 (Scrum)`,
        `- スプリント長: 2週間`,
        `- スプリントイベント: プランニング / デイリースクラム / レビュー / レトロ`,
        `- プロダクトバックログによる継続的な優先度調整`,
        `- スプリント毎の動作するインクリメント納品`,
        '',
        `## 品質保証`,
        `- TDD/BDD によるテスト駆動開発`,
        `- 継続的インテグレーション (CI)`,
        `- コードレビュー (Pull Request 必須)`,
        `- 自動化テスト (ユニット/統合/E2E)`,
      ].join('\n'),
    };
  }
  return {
    section_id: '7',
    title: '開発手法',
    content: [
      `## ウォーターフォール開発 (V字モデル)`,
      `- 各フェーズの成果物を明確化、レビュー・承認の上次フェーズへ`,
      `- 要件定義 → 基本設計 → 詳細設計 → 実装 → 結合テスト → 受入テスト`,
      `- 各設計フェーズに対応する逆向きのテスト工程を実施`,
      '',
      `## 品質保証`,
      `- 設計書レビュー (3者レビュー: 担当者/レビュアー/PM)`,
      `- コードレビュー (必須)`,
      `- ユニットテスト (カバレッジ80%+)`,
      `- 結合テスト・システムテスト・受入テスト`,
      `- セキュリティテスト (OWASP ZAP / 脆弱性診断)`,
    ].join('\n'),
  };
}

function buildCost(estimate?: EstimateResult): ProposalSection {
  if (!estimate) {
    return {
      section_id: '8',
      title: '概算費用',
      content: '見積書は別添資料をご参照ください。',
    };
  }
  return {
    section_id: '8',
    title: '概算費用',
    content: [
      `## 総合計`,
      `**¥${estimate.total_with_tax.toLocaleString()}** (税込)`,
      '',
      `内訳: 税抜 ¥${estimate.total_before_tax.toLocaleString()} + 消費税 ¥${estimate.tax.amount.toLocaleString()}`,
      '',
      `## 支払条件`,
      ...estimate.payment_terms.schedule.map(
        (s) => `- ${s.milestone}: ¥${s.amount.toLocaleString()} (${(s.ratio * 100).toFixed(0)}%)`
      ),
      `> ${estimate.payment_terms.note}`,
    ].join('\n'),
    tables: [
      {
        caption: 'フェーズ別内訳',
        headers: ['フェーズ', '工数 (人月)', '単価 (円)', '金額 (円)'],
        rows: estimate.phases.map((p) => [
          p.phase_name_ja,
          String(p.effort_man_months),
          p.rate_blended.toLocaleString(),
          p.amount.toLocaleString(),
        ]),
      },
    ],
  };
}

function buildRiskManagement(rfp: RfpDna): ProposalSection {
  return {
    section_id: '9',
    title: 'リスクマネジメント',
    content: 'プロジェクトで想定される主要リスクと対策を以下に示します。',
    tables: [
      {
        caption: 'リスク一覧',
        headers: ['カテゴリ', 'リスク', '発生確率', '影響度', '対策'],
        rows: rfp.risks.map((r) => [r.category, r.description, r.likelihood, r.impact, r.mitigation]),
      },
    ],
  };
}

function buildSimilarCases(cases: SimilarCase[]): ProposalSection {
  if (cases.length === 0) {
    return {
      section_id: '10',
      title: '類似実績',
      content: '弊社の類似実績は別途ヒアリングにてご紹介させていただきます。',
    };
  }
  return {
    section_id: '10',
    title: '類似実績',
    content: '弊社の代表的な類似実績を以下に示します。',
    tables: [
      {
        caption: '類似実績',
        headers: ['業種', '規模', '期間', '主要技術', '成果'],
        rows: cases.map((c) => [c.industry, c.scale, `${c.duration_months}ヶ月`, c.technologies.join(' / '), c.outcome]),
      },
    ],
  };
}

function buildCompanyProfile(c: CompanyInfo): ProposalSection {
  return {
    section_id: '11',
    title: '会社概要',
    content: [
      `**会社名**: ${c.name}${c.name_kana ? ` (${c.name_kana})` : ''}`,
      `**所在地**: ${c.address}`,
      c.phone ? `**電話**: ${c.phone}` : '',
      c.email ? `**メール**: ${c.email}` : '',
      c.representative ? `**代表者**: ${c.representative}` : '',
      c.license_no ? `**許認可**: ${c.license_no}` : '',
      c.capital_jpy ? `**資本金**: ¥${c.capital_jpy.toLocaleString()}` : '',
      c.established ? `**設立**: ${c.established}` : '',
      c.employees ? `**従業員数**: ${c.employees}名` : '',
      c.website ? `**Webサイト**: ${c.website}` : '',
    ].filter(Boolean).join('\n'),
  };
}

function buildCommitment(rfp: RfpDna): ProposalSection {
  return {
    section_id: '12',
    title: '弊社からのコミットメント',
    content: [
      `1. **品質**: ${rfp.goal.success_metrics.length > 0 ? rfp.goal.success_metrics.join(' / ') : 'お客様要件の確実な実現'}にコミットいたします。`,
      `2. **納期**: ${rfp.constraints.deadline ?? '合意期限'}を遵守し、進捗状況は週次でご報告します。`,
      `3. **コミュニケーション**: 定例会議 + 専用チャットチャネル + 緊急連絡窓口を提供します。`,
      `4. **保守**: リリース後のバグ修正は無償保証 (検収後30日)、その後は別途保守契約にて対応します。`,
      `5. **法令遵守**: ${rfp.constraints.legal.join(' / ') || '関連法令'}を遵守し、コンプライアンス対応を確実に実施します。`,
    ].join('\n'),
  };
}

function buildRfpDnaAppendix(rfp: RfpDna): ProposalSection {
  return {
    section_id: 'A1',
    title: '付録A: RFP分析結果 (RFP-DNA)',
    content: [
      `**業種**: ${rfp.meta.industry_ja ?? '指定なし'}`,
      `**顧客タイプ**: ${rfp.meta.client_type}`,
      `**規模感**: ${rfp.meta.scale}`,
      '',
      `## 抽出した目的`,
      `- 主目的: ${rfp.goal.primary}`,
      `- 背景課題: ${rfp.goal.business_drivers.join(' / ')}`,
      '',
      `## スコープ`,
      `- 対象: ${rfp.scope.in_scope.join(' / ')}`,
      `- 利用者: ${rfp.scope.target_users.join(' / ')}`,
    ].join('\n'),
  };
}

function buildImplicitRequirementsAppendix(rfp: RfpDna): ProposalSection {
  return {
    section_id: 'A2',
    title: '付録B: 暗黙要件一覧',
    content: '本提案では、RFPから業界標準として暗黙的に要求される機能群も含めて見積・スケジュールに織り込んでいます。',
    tables: [
      {
        caption: '暗黙要件一覧',
        headers: ['キーワード', '優先度', '推奨機能群'],
        rows: rfp.implicit_requirements.map((r) => [
          r.trigger_keyword,
          r.priority,
          r.inferred_features.join(' / '),
        ]),
      },
    ],
  };
}

function buildLegalCompliance(rfp: RfpDna): ProposalSection {
  return {
    section_id: 'A3',
    title: '付録C: 法令遵守',
    content: [
      `本プロジェクトでは以下の法令・規格に準拠した開発を実施します:`,
      ...rfp.constraints.legal.map((l) => `- ${l}`),
      '',
      `### 標準対応`,
      `- 個人情報保護法 (R4改正): 第26条 漏えい時5日以内速報`,
      `- 電子帳簿保存法 (R4改正): タイムスタンプ + 検索要件`,
      `- インボイス制度 (R5施行): 適格請求書 + 登録番号 (T+13桁)`,
      `- 労働基準法: 開発メンバーの36協定遵守`,
    ].join('\n'),
  };
}

/**
 * 提案書を Markdown として出力 (.docx 化前のレビュー用)
 */
export function formatProposalAsMarkdown(proposal: ProposalDocument): string {
  const lines: string[] = [];
  lines.push(`# ${proposal.meta.project_name} ご提案書`);
  lines.push('');
  lines.push(`**${proposal.meta.client_name} 様**`);
  lines.push('');
  lines.push(`提案日: ${proposal.meta.proposal_date}`);
  lines.push(`提案者: ${proposal.meta.proposer_company.name}`);
  lines.push(`バージョン: ${proposal.meta.proposal_version}`);
  lines.push('');
  lines.push('---');
  lines.push('');
  for (const section of proposal.sections) {
    renderSection(section, lines);
  }
  lines.push('');
  lines.push('## 付録');
  lines.push('');
  for (const ap of proposal.appendices) {
    renderSection(ap, lines);
  }
  return lines.join('\n');
}

function renderSection(section: ProposalSection, lines: string[]): void {
  lines.push(`## ${section.section_id}. ${section.title}`);
  lines.push('');
  lines.push(section.content);
  lines.push('');
  if (section.tables) {
    for (const t of section.tables) {
      lines.push(`### ${t.caption}`);
      lines.push('');
      lines.push(`| ${t.headers.join(' | ')} |`);
      lines.push(`| ${t.headers.map(() => '---').join(' | ')} |`);
      for (const row of t.rows) {
        lines.push(`| ${row.join(' | ')} |`);
      }
      lines.push('');
    }
  }
  if (section.diagrams) {
    for (const d of section.diagrams) {
      lines.push(`### ${d.description}`);
      if (d.mermaid) {
        lines.push('```mermaid');
        lines.push(d.mermaid);
        lines.push('```');
      }
      lines.push('');
    }
  }
}
