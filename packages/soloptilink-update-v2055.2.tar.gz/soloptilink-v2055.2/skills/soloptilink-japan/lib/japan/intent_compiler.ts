/**
 * Intent Compiler v1 - 日本語要件→構造化要件書 変換エンジン
 *
 * 曖昧な日本語指示から、実装に必要な要素を抽出・構造化する。
 * 「作りたいものをしっかり作り込む」の起点。
 *
 * Output 構造:
 *   ParsedIntent {
 *     purpose: string;           // 何のために作るか
 *     targetUsers: string[];      // 誰が使うか
 *     mainFeatures: string[];     // 主機能
 *     industry?: string;          // 業種（20辞書のキー）
 *     laws?: string[];            // 適用法令
 *     forms?: string[];           // 必要帳票
 *     scope: 'new' | 'modify' | 'add' | 'integrate';
 *     priority: 'high' | 'medium' | 'low';
 *     confidence: number;         // 0-100
 *     gaps: string[];             // 推論できなかった要素
 *   }
 */

// =============================================================================
// 型定義
// =============================================================================
export interface ParsedIntent {
  purpose: string;
  targetUsers: string[];
  mainFeatures: string[];
  industry?: string;
  laws?: string[];
  forms?: string[];
  scope: 'new' | 'modify' | 'add' | 'integrate';
  priority: 'high' | 'medium' | 'low';
  confidence: number;
  gaps: string[];
}

// =============================================================================
// 辞書: キーワード → 構造化
// =============================================================================
const INDUSTRY_KEYWORDS: Record<string, string[]> = {
  construction: ['建設', '建築工事', '土木', '工事', '施工', '現場監督', '一括下請', '建設業許可'],
  manufacturing: ['製造', '工場', '生産', 'BOM', 'ロット', '品質管理', 'ISO9001', 'IATF16949'],
  healthcare: ['医療', '病院', '診療所', 'クリニック', '介護', '患者', 'カルテ', 'レセプト'],
  professional: ['税理士', '社労士', '行政書士', '弁護士', '司法書士', '士業', '顧問先', '申告'],
  retail: ['小売', '店舗', 'POS', 'EC', 'SKU', '在庫', '棚卸', '会員', 'ポイント'],
  food_service: ['飲食', 'レストラン', 'カフェ', 'メニュー', 'テーブル', '予約', 'HACCP'],
  transport: ['タクシー', 'バス', 'トラック', '運送', '配送', '運行', '点呼'],
  logistics: ['物流', '倉庫', '出荷', 'ピッキング', '入庫', '出庫', 'WMS'],
  real_estate: ['不動産', '賃貸', '売買', '仲介', '宅建', '物件', '重要事項'],
  architecture: ['建築設計', '設計事務所', '確認申請', '建築士', '図面', 'CAD', 'BIM'],
  it: ['システム開発', 'SES', 'SaaS', 'Webサイト', 'アプリ', 'サーバー', 'クラウド'],
  advertising: ['広告', 'マーケティング', 'キャンペーン', 'LP', 'リスティング', 'SNS運用'],
  beauty: ['美容室', 'エステ', 'ネイル', 'サロン', 'カット', 'カラー', 'パーマ'],
  fitness: ['ジム', 'フィットネス', 'パーソナル', 'ヨガ', 'ピラティス', 'インストラクター'],
  education: ['学習塾', '予備校', '家庭教師', '講師', '生徒', '模試', '偏差値'],
  childcare: ['保育園', 'こども園', '学童', 'ベビーシッター', '園児', '保育士', '連絡帳'],
  agriculture: ['農業', '稲作', '畑作', '果樹', '畜産', '圃場', '農薬'],
  fishery: ['漁業', '水産', '養殖', '漁船', '市場', '競り'],
  hotel: ['ホテル', '旅館', '民泊', 'チェックイン', '宿泊', '客室'],
  bridal: ['結婚式', 'ウェディング', 'ブライダル', '新郎新婦', '披露宴'],
};

const LAW_KEYWORDS: Record<string, string[]> = {
  'インボイス制度': ['インボイス', '適格請求書', '登録番号', 'T+13桁'],
  '電子帳簿保存法': ['電帳法', '電子帳簿', 'タイムスタンプ', '電子取引'],
  '個人情報保護法': ['個情法', '個人情報', 'プライバシー', '要配慮', '同意'],
  'マイナンバー法': ['マイナンバー', 'マイナ', '個人番号'],
  '労働基準法': ['労基', '36協定', '残業', '有給', '就業規則'],
  '下請法': ['下請', '3条書面', '支払遅延'],
  '建設業法': ['建設業許可', '主任技術者', '監理技術者'],
  '金融商品取引法': ['金商法', '適合性', '目論見書'],
  '食品衛生法': ['食品衛生', 'HACCP', 'アレルゲン'],
  '医療法': ['医療法', '医師法', '診療報酬'],
  '宅地建物取引業法': ['宅建業法', '重要事項', '37条書面'],
};

const FORM_KEYWORDS: Record<string, string[]> = {
  '請求書': ['請求', 'インボイス'],
  '見積書': ['見積', '御見積'],
  '注文書': ['注文', '発注', '注文書'],
  '納品書': ['納品', '出荷'],
  '領収書': ['領収', 'レシート'],
  '検収書': ['検収'],
  '契約書': ['契約', '契約書'],
  '秘密保持契約': ['NDA', '秘密保持'],
  '業務委託契約': ['業務委託', '準委任'],
  '覚書': ['覚書'],
  '通知書': ['通知書'],
  '申請書': ['申請'],
  '報告書': ['報告書', 'レポート'],
  '議事録': ['議事録', 'ミーティング'],
  '源泉徴収票': ['源泉徴収', '源泉徴収票'],
  '支払調書': ['支払調書'],
  '支払通知書': ['支払通知'],
  '給与明細': ['給与明細'],
};

const SCOPE_KEYWORDS: Array<{ scope: ParsedIntent['scope']; keywords: string[] }> = [
  { scope: 'new', keywords: ['作って', '構築', '開発', '新しく', '一から', 'システムを', 'ゼロから'] },
  { scope: 'modify', keywords: ['修正', '変更', 'バグ', '直して', '改修', 'リファクタ'] },
  { scope: 'add', keywords: ['追加', '足して', '機能を', '実装して', '対応して'] },
  { scope: 'integrate', keywords: ['連携', '統合', 'インテグレーション', 'API接続'] },
];

const ROLE_KEYWORDS: Record<string, string[]> = {
  '経営者': ['経営者', '社長', '代表', 'オーナー'],
  '管理者': ['管理者', '部長', 'マネージャー', 'アドミン'],
  '経理': ['経理', '会計', '財務'],
  '作業員': ['作業員', '現場', 'スタッフ', '職人'],
  '顧客': ['顧客', 'お客様', 'カスタマー', '利用者'],
  '管理職': ['管理職', '役員', '執行役員'],
};

// =============================================================================
// メイン関数
// =============================================================================
export function compileIntent(promptText: string): ParsedIntent {
  const text = promptText.toLowerCase();
  const textRaw = promptText;
  const gaps: string[] = [];

  // 業種判定（スコア制）
  let industry: string | undefined;
  let bestScore = 0;
  for (const [ind, keywords] of Object.entries(INDUSTRY_KEYWORDS)) {
    const score = keywords.reduce((s, k) => s + (textRaw.includes(k) ? 1 : 0), 0);
    if (score > bestScore) { bestScore = score; industry = ind; }
  }
  if (!industry) gaps.push('業種');

  // 法令判定
  const laws: string[] = [];
  for (const [law, keywords] of Object.entries(LAW_KEYWORDS)) {
    if (keywords.some(k => textRaw.includes(k))) laws.push(law);
  }

  // 帳票判定
  const forms: string[] = [];
  for (const [form, keywords] of Object.entries(FORM_KEYWORDS)) {
    if (keywords.some(k => textRaw.includes(k))) forms.push(form);
  }

  // スコープ判定
  let scope: ParsedIntent['scope'] = 'new';
  for (const sk of SCOPE_KEYWORDS) {
    if (sk.keywords.some(k => textRaw.includes(k))) { scope = sk.scope; break; }
  }

  // ユーザー判定
  const targetUsers: string[] = [];
  for (const [role, keywords] of Object.entries(ROLE_KEYWORDS)) {
    if (keywords.some(k => textRaw.includes(k))) targetUsers.push(role);
  }
  if (targetUsers.length === 0) {
    targetUsers.push(industry === 'professional' ? '士業者とクライアント' : '社内ユーザー');
    gaps.push('対象ユーザー（推定で補完）');
  }

  // 主機能抽出: 「〜管理」「〜機能」「〜を作る」等のパターン
  const mainFeatures: string[] = [];
  const featurePatterns = [
    /([一-龥ぁ-んァ-ヴ]{2,})管理/g,
    /([一-龥ぁ-んァ-ヴ]{2,})機能/g,
    /([一-龥ぁ-んァ-ヴ]{2,})システム/g,
  ];
  for (const p of featurePatterns) {
    const matches = textRaw.matchAll(p);
    for (const m of matches) {
      const feat = m[0];
      if (!mainFeatures.includes(feat)) mainFeatures.push(feat);
    }
  }
  // 動詞ベースの抽出: 「〜できる」「〜する」
  const verbMatches = textRaw.matchAll(/([一-龥ぁ-んァ-ヴ]{2,6})(できる|したい|する|作成|表示)/g);
  for (const m of verbMatches) {
    const feat = m[0];
    if (!mainFeatures.includes(feat)) mainFeatures.push(feat);
  }
  if (mainFeatures.length === 0) gaps.push('主機能');

  // 優先度
  let priority: 'high' | 'medium' | 'low' = 'medium';
  if (/(緊急|至急|早急|本気|完璧|フルスペック|ガチ|絶対)/.test(textRaw)) priority = 'high';
  if (/(とりあえず|試しに|簡単な|シンプルな)/.test(textRaw)) priority = 'low';

  // 目的抽出（「〜のため」「〜したい」）
  let purpose = '';
  const purposeMatch = textRaw.match(/(.{5,40})(のため|ために|したい|欲しい|する必要)/);
  if (purposeMatch) purpose = purposeMatch[1].trim();
  else purpose = mainFeatures.length > 0 ? mainFeatures.slice(0, 2).join('・') + 'を実現' : '業務効率化';

  // Confidence計算
  let confidence = 50;
  if (industry) confidence += 15;
  if (laws.length > 0) confidence += 10;
  if (forms.length > 0) confidence += 10;
  if (targetUsers.length > 0 && !gaps.includes('対象ユーザー（推定で補完）')) confidence += 10;
  if (mainFeatures.length >= 2) confidence += 5;
  confidence = Math.min(100, confidence);

  return {
    purpose,
    targetUsers,
    mainFeatures,
    industry,
    laws: laws.length > 0 ? laws : undefined,
    forms: forms.length > 0 ? forms : undefined,
    scope,
    priority,
    confidence,
    gaps,
  };
}

// =============================================================================
// マークダウン要件書に変換
// =============================================================================
export function intentToMarkdown(intent: ParsedIntent, projectName: string): string {
  const lines: string[] = [];
  lines.push(`# ${projectName} 要件定義書 (Intent Compiler v1 自動生成)`);
  lines.push('');
  lines.push(`生成日時: ${new Date().toISOString()}`);
  lines.push(`信頼度: ${intent.confidence}% ${intent.confidence >= 80 ? '✅ 高' : intent.confidence >= 60 ? '⚠ 中' : '❌ 低'}`);
  lines.push('');
  lines.push('## 1. 目的');
  lines.push(intent.purpose);
  lines.push('');
  lines.push('## 2. 対象ユーザー');
  intent.targetUsers.forEach(u => lines.push(`- ${u}`));
  lines.push('');
  lines.push('## 3. 主要機能');
  if (intent.mainFeatures.length > 0) intent.mainFeatures.forEach(f => lines.push(`- ${f}`));
  else lines.push('- （推論できず - 追加ヒアリング推奨）');
  lines.push('');
  if (intent.industry) {
    lines.push('## 4. 業種');
    lines.push(`**${intent.industry}** - ドメイン辞書 \`domains/${intent.industry}.json\` を参照`);
    lines.push('');
  }
  if (intent.laws && intent.laws.length > 0) {
    lines.push('## 5. 適用法令');
    intent.laws.forEach(l => lines.push(`- ${l}`));
    lines.push('');
  }
  if (intent.forms && intent.forms.length > 0) {
    lines.push('## 6. 必要帳票');
    intent.forms.forEach(f => lines.push(`- ${f}`));
    lines.push('');
  }
  lines.push('## 7. スコープ');
  const scopeLabel = { new: '新規開発', modify: '既存改修', add: '機能追加', integrate: '統合・連携' };
  lines.push(`- ${scopeLabel[intent.scope]}`);
  lines.push(`- 優先度: ${intent.priority === 'high' ? '高' : intent.priority === 'low' ? '低' : '中'}`);
  lines.push('');
  if (intent.gaps.length > 0) {
    lines.push('## 8. ⚠ 推論不足領域（ユーザー確認推奨）');
    intent.gaps.forEach(g => lines.push(`- ${g}`));
    lines.push('');
  }
  lines.push('---');
  lines.push('*この要件書で開発を開始します。修正があればご指示ください。*');
  return lines.join('\n');
}

// =============================================================================
// CLI 実行エントリポイント
// =============================================================================
export function runCLI(args: string[]): void {
  if (args.length === 0) {
    console.error('Usage: intent_compiler "<日本語の要件テキスト>"');
    process.exit(1);
  }
  const text = args.join(' ');
  const intent = compileIntent(text);
  const projectName = intent.industry ? `${intent.industry}_system` : 'new_system';
  console.log(intentToMarkdown(intent, projectName));
  console.log('\n--- JSON ---');
  console.log(JSON.stringify(intent, null, 2));
}
