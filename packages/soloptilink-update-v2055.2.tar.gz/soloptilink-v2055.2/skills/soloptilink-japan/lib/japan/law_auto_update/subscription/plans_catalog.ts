/**
 * Phase 46-LU-6 / Subscription Plans Catalog
 *
 * 法務 SaaS としての料金プラン定義。
 * Free → Pro → Enterprise → LegalFirm の4段階。
 * 各プランで使える機能・上限・SLA を構造化。
 *
 * 注意: 本ファイルはプランカタログ定義のみ。実際の課金は billing/ で行う。
 */

export type PlanTier = 'free' | 'pro' | 'enterprise' | 'legal_firm';

export interface PlanFeatures {
  /** RAG 検索の回数上限 (月次) */
  rag_queries_per_month: number;
  /** コンプライアンススキャン回数 */
  compliance_scans_per_month: number;
  /** 契約書テンプレ生成回数 */
  contracts_per_month: number;
  /** リスク評価実行回数 */
  risk_assessments_per_month: number;
  /** 改正アラートメール配信先 (人数) */
  alert_recipients: number;
  /** マルチテナント (子テナント) 数 */
  child_tenants: number;
  /** Webhook 登録数 */
  webhooks: number;
  /** PDF/DOCX エクスポート上限 (件/月) */
  exports_per_month: number;
  /** API キー本数 */
  api_keys: number;
  /** API レート (req/min) */
  api_rate_per_min: number;
  /** プレミアム機能アクセス */
  premium_features: PremiumFeature[];
}

export type PremiumFeature =
  | 'legal_advisor_multi_turn' // 法務AIアドバイザー
  | 'omega_legal_bridge' // ARTE-Omega連携
  | 'citation_network_full' // 引用ネットワーク完全版
  | 'comparative_law_full' // 海外比較法完全版
  | 'amendment_real_time_alert' // 改正リアルタイムアラート
  | 'custom_compliance_rules' // カスタムコンプラルール
  | 'tenant_dna_integration' // Tenant DNA連携
  | 'audit_log_extended' // 監査ログ延長保管
  | 'sso_saml_oidc' // SSO/SAML/OIDC
  | 'dedicated_support' // 専任サポート
  | 'private_corpus_upload' // 自社規程アップロード
  | 'judicial_writeup_template'; // 訴訟書面テンプレ

export interface SlaTier {
  uptime_pct: number;
  response_time_first_p99_hours: number;
  data_retention_months: number;
  backup_frequency: 'daily' | 'weekly' | 'monthly';
}

export interface PlanDefinition {
  tier: PlanTier;
  display_name: string;
  short_description: string;
  monthly_price_jpy: number;
  annual_price_jpy: number;
  features: PlanFeatures;
  sla: SlaTier;
  /** プラン推奨対象 */
  recommended_for: string[];
  /** 上位プランへのアップグレードトリガ (使用量超過の警告基準) */
  upgrade_triggers: {
    rag_usage_pct: number; // 80%以上で警告
    compliance_usage_pct: number;
  };
}

export const SUBSCRIPTION_PLANS: PlanDefinition[] = [
  {
    tier: 'free',
    display_name: 'Free',
    short_description: '個人開発者・学生・趣味利用向け。基本機能を制限付きで提供',
    monthly_price_jpy: 0,
    annual_price_jpy: 0,
    features: {
      rag_queries_per_month: 100,
      compliance_scans_per_month: 30,
      contracts_per_month: 5,
      risk_assessments_per_month: 5,
      alert_recipients: 1,
      child_tenants: 0,
      webhooks: 0,
      exports_per_month: 5,
      api_keys: 1,
      api_rate_per_min: 10,
      premium_features: [],
    },
    sla: { uptime_pct: 99.0, response_time_first_p99_hours: 72, data_retention_months: 3, backup_frequency: 'weekly' },
    recommended_for: ['個人開発者', '学生', 'PoC評価'],
    upgrade_triggers: { rag_usage_pct: 80, compliance_usage_pct: 70 },
  },
  {
    tier: 'pro',
    display_name: 'Pro',
    short_description: '中小企業の法務担当・SI事業者向け。実務利用に十分な上限',
    monthly_price_jpy: 29800,
    annual_price_jpy: 298000, // 2ヶ月分お得
    features: {
      rag_queries_per_month: 5000,
      compliance_scans_per_month: 1000,
      contracts_per_month: 200,
      risk_assessments_per_month: 100,
      alert_recipients: 5,
      child_tenants: 0,
      webhooks: 3,
      exports_per_month: 200,
      api_keys: 5,
      api_rate_per_min: 60,
      premium_features: [
        'legal_advisor_multi_turn',
        'citation_network_full',
        'amendment_real_time_alert',
      ],
    },
    sla: { uptime_pct: 99.5, response_time_first_p99_hours: 24, data_retention_months: 12, backup_frequency: 'daily' },
    recommended_for: ['中小企業 法務担当者', 'SIer社内利用', 'スタートアップ'],
    upgrade_triggers: { rag_usage_pct: 80, compliance_usage_pct: 80 },
  },
  {
    tier: 'enterprise',
    display_name: 'Enterprise',
    short_description: '大企業・上場企業向け。全機能解禁 + SSO + 監査ログ延長',
    monthly_price_jpy: 198000,
    annual_price_jpy: 1980000,
    features: {
      rag_queries_per_month: 100000,
      compliance_scans_per_month: 20000,
      contracts_per_month: 5000,
      risk_assessments_per_month: 2000,
      alert_recipients: 50,
      child_tenants: 10,
      webhooks: 20,
      exports_per_month: 5000,
      api_keys: 30,
      api_rate_per_min: 600,
      premium_features: [
        'legal_advisor_multi_turn',
        'omega_legal_bridge',
        'citation_network_full',
        'comparative_law_full',
        'amendment_real_time_alert',
        'custom_compliance_rules',
        'tenant_dna_integration',
        'audit_log_extended',
        'sso_saml_oidc',
        'dedicated_support',
        'private_corpus_upload',
      ],
    },
    sla: { uptime_pct: 99.9, response_time_first_p99_hours: 4, data_retention_months: 60, backup_frequency: 'daily' },
    recommended_for: ['大企業 法務部門', '上場企業', '監査法人', '医療法人グループ'],
    upgrade_triggers: { rag_usage_pct: 85, compliance_usage_pct: 85 },
  },
  {
    tier: 'legal_firm',
    display_name: 'Legal Firm',
    short_description: '法律事務所/特化型ファーム向け。子テナント無制限 + 訴訟書面 + 専任CSM',
    monthly_price_jpy: 498000,
    annual_price_jpy: 4980000,
    features: {
      rag_queries_per_month: 500000,
      compliance_scans_per_month: 100000,
      contracts_per_month: 50000,
      risk_assessments_per_month: 20000,
      alert_recipients: 500,
      child_tenants: 1000,
      webhooks: 200,
      exports_per_month: 50000,
      api_keys: 200,
      api_rate_per_min: 3000,
      premium_features: [
        'legal_advisor_multi_turn',
        'omega_legal_bridge',
        'citation_network_full',
        'comparative_law_full',
        'amendment_real_time_alert',
        'custom_compliance_rules',
        'tenant_dna_integration',
        'audit_log_extended',
        'sso_saml_oidc',
        'dedicated_support',
        'private_corpus_upload',
        'judicial_writeup_template',
      ],
    },
    sla: { uptime_pct: 99.95, response_time_first_p99_hours: 2, data_retention_months: 120, backup_frequency: 'daily' },
    recommended_for: ['法律事務所 (BigLaw / Boutique)', '弁護士会', '司法書士法人', '会計士法人'],
    upgrade_triggers: { rag_usage_pct: 90, compliance_usage_pct: 90 },
  },
];

export function getPlanByTier(tier: PlanTier): PlanDefinition | undefined {
  return SUBSCRIPTION_PLANS.find((p) => p.tier === tier);
}

export function comparePlans(tiers: PlanTier[]): Array<Partial<Record<keyof PlanFeatures, number | string>>> {
  return tiers.map((t) => {
    const p = getPlanByTier(t);
    if (!p) return {};
    return {
      tier: t,
      monthly_price_jpy: p.monthly_price_jpy,
      ...p.features,
    } as Partial<Record<keyof PlanFeatures, number | string>>;
  });
}

export function recommendPlan(input: {
  rag_queries_estimated_monthly: number;
  team_size: number;
  industries?: string[];
  is_legal_firm?: boolean;
  needs_sso?: boolean;
}): { plan: PlanDefinition; reasoning: string[] } {
  const reasoning: string[] = [];
  if (input.is_legal_firm) {
    reasoning.push('法律事務所向けの専用プランを推奨');
    return { plan: getPlanByTier('legal_firm')!, reasoning };
  }
  if (input.needs_sso || input.rag_queries_estimated_monthly > 5000) {
    reasoning.push('SSO要件あり または 月次クエリ 5000 超');
    return { plan: getPlanByTier('enterprise')!, reasoning };
  }
  if (input.rag_queries_estimated_monthly > 100 || input.team_size > 3) {
    reasoning.push('業務利用規模 (チーム3名超 or クエリ100超/月)');
    return { plan: getPlanByTier('pro')!, reasoning };
  }
  reasoning.push('個人/小規模利用に最適');
  return { plan: getPlanByTier('free')!, reasoning };
}

export function countSubscriptionPlans(): { total: number; total_premium_features: number } {
  let total = 0;
  for (const p of SUBSCRIPTION_PLANS) total += p.features.premium_features.length;
  return { total: SUBSCRIPTION_PLANS.length, total_premium_features: total };
}
