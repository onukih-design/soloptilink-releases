/**
 * Phase 46-LU-4 / 学説論争 20 件
 *
 * 民法・刑法・憲法・行政法・労働法・知財・税法の主要論点について、
 * 通説 / 有力説 / 少数説 / 判例の立場 を構造化する。
 *
 * 出典: 学術論文・コンメンタール・基本書 (要約のみ。本文転載なし)
 */

export type Field = 'constitution' | 'civil' | 'criminal' | 'administrative' | 'labor' | 'ip' | 'tax' | 'commercial';

export interface ScholarlyDoctrine {
  topic_id: string;
  field: Field;
  topic_name: string;
  legal_article?: string;
  /** 各説のポジション */
  positions: Array<{
    name: '通説' | '有力説' | '少数説' | '判例の立場' | '実務' | '近時の有力説';
    summary: string;
    /** 主唱者・代表的見解 */
    proponents?: string[];
  }>;
  /** 実務への帰結 */
  practical_consequence: string;
}

export const SCHOLARLY_DOCTRINES: ScholarlyDoctrine[] = [
  // ============ 民法 ============
  {
    topic_id: 'civ_intention_theory',
    field: 'civil',
    topic_name: '意思主義 vs 表示主義 (錯誤の効果論)',
    legal_article: '民法第95条',
    positions: [
      { name: '通説', summary: '意思主義: 真意と異なる表示があれば原則無効' },
      { name: '近時の有力説', summary: '表示主義: 表示への信頼を保護 (R2.4改正は折衷的)' },
      { name: '判例の立場', summary: '最判S29.2.12 動機の錯誤の表示有無で判断' },
    ],
    practical_consequence: 'R2.4改正民法95条で「動機の表示」を要件化',
  },
  {
    topic_id: 'civ_subrogation',
    field: 'civil',
    topic_name: '物上代位の理論 (担保物権の追及力)',
    legal_article: '民法第304条/372条',
    positions: [
      { name: '通説', summary: '価値代表説: 担保価値が代位目的物に移転',
        proponents: ['我妻'] },
      { name: '有力説', summary: '物権的請求権説: 担保物権自体が代位の対象に及ぶ' },
      { name: '判例の立場', summary: '最判H10.1.30 賃料債権への物上代位を肯定' },
    ],
    practical_consequence: 'ファイナンスの実務 (証券化/賃料担保) に直結',
  },
  {
    topic_id: 'civ_pierce_corporate',
    field: 'civil',
    topic_name: '法人格否認の法理',
    legal_article: '民法 (一般法理) + 会社法第3条',
    positions: [
      { name: '通説', summary: '法人格否認の二類型 (濫用/形骸化)',
        proponents: ['江頭'] },
      { name: '判例の立場', summary: '最判S44.2.27 (法形骸化) + 最判S48.10.26 (法人格濫用)' },
      { name: '少数説', summary: '一元説 (法形骸化に統一)' },
    ],
    practical_consequence: '親子会社・形骸会社の責任追及で頻出',
  },
  {
    topic_id: 'civ_unfair_enrichment',
    field: 'civil',
    topic_name: '不当利得の本質 (衡平説 vs 類型論)',
    legal_article: '民法第703条',
    positions: [
      { name: '通説 (類型論)', summary: '給付/侵害/支出/求償の4類型で別個論理を適用',
        proponents: ['四宮'] },
      { name: '少数説 (衡平説)', summary: '正義公平の一般原則として統一', proponents: ['我妻'] },
    ],
    practical_consequence: '転用物訴権・三角関係の処理で結論が変わる',
  },

  // ============ 刑法 ============
  {
    topic_id: 'crim_actus_reus',
    field: 'criminal',
    topic_name: '実行行為の概念 (危険説 vs 行為無価値)',
    legal_article: '刑法第43条 (未遂犯)',
    positions: [
      { name: '通説 (結果無価値)', summary: '実行行為=結果発生の現実的危険を有する行為',
        proponents: ['前田', '中山'] },
      { name: '有力説 (行為無価値)', summary: '法益侵害の現実的危険+規範違反性',
        proponents: ['大塚'] },
      { name: '判例の立場', summary: '結果回避義務違反説に近い (最判H21.3.26)' },
    ],
    practical_consequence: '不能犯/着手時期/予備の処罰範囲が変わる',
  },
  {
    topic_id: 'crim_conspiracy',
    field: 'criminal',
    topic_name: '共謀共同正犯の理論的根拠',
    legal_article: '刑法第60条',
    positions: [
      { name: '通説', summary: '共同意思主体説 → 行為支配説',
        proponents: ['団藤', '大塚'] },
      { name: '判例の立場', summary: '最大判S33.5.28 (練馬事件) 共同実行の意思+客観的協同' },
      { name: '近時の有力説', summary: '機能的行為支配説' },
    ],
    practical_consequence: '組織犯罪の首魁・末端共犯者の評価',
  },
  {
    topic_id: 'crim_self_defense',
    field: 'criminal',
    topic_name: '正当防衛と緊急避難の補充性',
    legal_article: '刑法第36条/37条',
    positions: [
      { name: '通説', summary: '正当防衛は補充性不要 / 緊急避難は補充性必要',
        proponents: ['大塚'] },
      { name: '有力説', summary: '正当防衛にも限定的な補充性' },
      { name: '判例の立場', summary: '最判S58.4.4 過剰防衛の処罰 (刑減免の裁量)' },
    ],
    practical_consequence: '正当防衛の成立範囲 + 過剰防衛の処罰',
  },

  // ============ 憲法 ============
  {
    topic_id: 'const_indirect_application',
    field: 'constitution',
    topic_name: '私人間効力 (間接適用説 vs 直接適用説)',
    legal_article: '日本国憲法第14条 等',
    positions: [
      { name: '通説 (間接適用説)', summary: '憲法は民法90条等を介して私人間に適用',
        proponents: ['芦部', '佐藤幸治'] },
      { name: '判例の立場', summary: '最大判S48.12.12 (三菱樹脂事件) 間接適用説採用' },
      { name: '少数説', summary: '無効力説 / 直接適用説' },
    ],
    practical_consequence: '労働契約の差別禁止・私的団体の人権配慮',
  },
  {
    topic_id: 'const_judicial_review_test',
    field: 'constitution',
    topic_name: '違憲審査基準 (二重基準 vs 厳格な合理性)',
    legal_article: '日本国憲法第13条/14条/21条',
    positions: [
      { name: '通説', summary: '二重基準: 精神的自由は厳格審査 / 経済的自由は合理性',
        proponents: ['芦部', '宍戸'] },
      { name: '判例の立場', summary: '合理的関連性基準 (猿払事件) → LRAテスト (堀越事件)' },
      { name: '近時の有力説', summary: '厳格な合理性審査 (中間審査) の活用' },
    ],
    practical_consequence: '表現規制立法の合憲性判断',
  },
  {
    topic_id: 'const_governance_act',
    field: 'constitution',
    topic_name: '統治行為論の射程',
    legal_article: '司法権 (76条)',
    positions: [
      { name: '通説', summary: '高度の政治性ある行為は司法審査原則対象外',
        proponents: ['芦部'] },
      { name: '判例の立場', summary: '苫米地事件 (最大判S35.6.8) 採用 / 砂川事件 部分採用' },
      { name: '少数説', summary: '統治行為論否定 (人権侵害の場合は審査必須)' },
    ],
    practical_consequence: '国会解散・条約合憲性の司法判断',
  },

  // ============ 行政法 ============
  {
    topic_id: 'admin_act_definition',
    field: 'administrative',
    topic_name: '処分性の概念 (公権力性 + 法効果性)',
    legal_article: '行政事件訴訟法第3条第2項',
    positions: [
      { name: '通説', summary: '公権力性 + 直接具体的法効果',
        proponents: ['塩野', '宇賀'] },
      { name: '判例の立場', summary: '最判H17.7.15 (環境影響評価) 処分性の判断枠組み拡張' },
      { name: '近時の有力説', summary: '実効的権利救済の観点から処分性拡大' },
    ],
    practical_consequence: '抗告訴訟の門戸開放 (公共事業/行政指導)',
  },
  {
    topic_id: 'admin_discretion',
    field: 'administrative',
    topic_name: '行政裁量の司法統制',
    legal_article: '行訴法第30条',
    positions: [
      { name: '通説', summary: '裁量の濫用/逸脱を司法審査',
        proponents: ['芝池'] },
      { name: '判例の立場', summary: 'マクリーン事件 (最大判S53.10.4) 広範裁量+逸脱濫用基準' },
      { name: '近時の有力説', summary: '判断過程審査の徹底 (重要な考慮要素の遺漏)' },
    ],
    practical_consequence: '在留更新・許認可拒否・処分取消訴訟',
  },

  // ============ 労働法 ============
  {
    topic_id: 'labor_employee_concept',
    field: 'labor',
    topic_name: '労働者性の判断 (使用従属性 vs 経済的従属性)',
    legal_article: '労働基準法第9条 / 労組法第3条',
    positions: [
      { name: '通説', summary: '使用従属性 (指揮命令+専属性+報酬性)',
        proponents: ['菅野'] },
      { name: '判例の立場', summary: '最判H17.6.3 (関西医大研修医) 労基法上の労働者性肯定' },
      { name: '近時の有力説', summary: '経済的従属性も労組法上の労働者性に算入 (UberEats都労委)' },
    ],
    practical_consequence: 'ギグワーカー・フリーランス・業務委託の労働者性',
  },
  {
    topic_id: 'labor_dismissal_abuse',
    field: 'labor',
    topic_name: '解雇権濫用の判断要素',
    legal_article: '労働契約法第16条',
    positions: [
      { name: '通説', summary: '客観的合理性 + 社会的相当性',
        proponents: ['菅野', '荒木'] },
      { name: '判例の立場', summary: '高知放送事件 (最判S52.1.31) 解雇権濫用法理確立' },
    ],
    practical_consequence: '整理解雇4要件・能力不足解雇の判断',
  },

  // ============ 知財 ============
  {
    topic_id: 'ip_doctrine_of_equivalents',
    field: 'ip',
    topic_name: '均等論の要件 (ボールスプライン 5 要件)',
    legal_article: '特許法第70条',
    positions: [
      { name: '通説', summary: 'ボールスプライン 5 要件 を厳格適用',
        proponents: ['田村善之', '渋谷'] },
      { name: '判例の立場', summary: '最判H10.2.24 (ボールスプライン)' },
      { name: '近時の有力説', summary: '5要件中の本質的部分の判定で出願人の意思を重視' },
    ],
    practical_consequence: '特許侵害の認定範囲',
  },
  {
    topic_id: 'ip_use_as_trademark',
    field: 'ip',
    topic_name: '商標的使用論 (出所識別機能の有無)',
    legal_article: '商標法第26条第1項第6号',
    positions: [
      { name: '通説', summary: '需要者が出所識別標識として認識する使用態様か',
        proponents: ['田村'] },
      { name: '判例の立場', summary: 'カブカブ事件 (知財高判R5.6.8)' },
    ],
    practical_consequence: '記述的表示・装飾的使用の侵害該当性',
  },

  // ============ 税法 ============
  {
    topic_id: 'tax_substance_over_form',
    field: 'tax',
    topic_name: '実質課税の原則 (経済実質説 vs 法律実質説)',
    legal_article: '所得税法第12条',
    positions: [
      { name: '通説 (法律実質説)', summary: '法律的所得帰属を実質的に判断',
        proponents: ['金子'] },
      { name: '少数説 (経済実質説)', summary: '経済的成果から判断' },
      { name: '判例の立場', summary: '法律実質説に近い (最判S43.10.31)' },
    ],
    practical_consequence: '所得帰属者の判定 / 名義借りの否認',
  },
  {
    topic_id: 'tax_anti_avoidance',
    field: 'tax',
    topic_name: '租税回避と否認の限界',
    legal_article: '法人税法第132条 / 通則法第65条',
    positions: [
      { name: '通説', summary: '同族会社の行為計算否認は経済合理性で判断',
        proponents: ['金子'] },
      { name: '判例の立場', summary: '最判H6.6.13 / 武富士事件 H23.2.18 (個別否認規定の厳格解釈)' },
      { name: '近時の有力説', summary: 'GAAR (一般否認規定) 導入の議論' },
    ],
    practical_consequence: 'タックス・プランニング・国際租税回避',
  },

  // ============ 商事 ============
  {
    topic_id: 'comm_business_judgment',
    field: 'commercial',
    topic_name: '経営判断原則の射程',
    legal_article: '会社法第330条 / 民法第644条',
    positions: [
      { name: '通説', summary: '判断過程と内容に著しい不合理さがなければ違反なし',
        proponents: ['江頭', '神田'] },
      { name: '判例の立場', summary: '最判H22.7.15 (アパマンショップ) 経営判断原則を明示的に採用' },
      { name: '近時の有力説', summary: '内部統制構築義務違反として独立に判断' },
    ],
    practical_consequence: '取締役の任務懈怠責任の判定',
  },
];

export function findDoctrinesByField(field: Field): ScholarlyDoctrine[] {
  return SCHOLARLY_DOCTRINES.filter((d) => d.field === field);
}

export function searchDoctrineByKeyword(keyword: string): ScholarlyDoctrine[] {
  const lower = keyword.toLowerCase();
  return SCHOLARLY_DOCTRINES.filter((d) =>
    d.topic_name.toLowerCase().includes(lower)
    || d.positions.some((p) => p.summary.toLowerCase().includes(lower))
    || (d.legal_article ?? '').toLowerCase().includes(lower),
  );
}

export function countScholarlyDoctrines(): { total: number; by_field: Record<Field, number>; total_positions: number } {
  const byField: Record<Field, number> = {
    constitution: 0, civil: 0, criminal: 0, administrative: 0,
    labor: 0, ip: 0, tax: 0, commercial: 0,
  };
  let positions = 0;
  for (const d of SCHOLARLY_DOCTRINES) {
    byField[d.field]++;
    positions += d.positions.length;
  }
  return { total: SCHOLARLY_DOCTRINES.length, by_field: byField, total_positions: positions };
}
