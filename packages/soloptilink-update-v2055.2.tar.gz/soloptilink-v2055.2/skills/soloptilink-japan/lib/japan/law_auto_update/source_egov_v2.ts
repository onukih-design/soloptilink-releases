/**
 * @fileoverview Phase 46-LU / Legal Update Auto-Learner
 *
 * e-Gov 法令API v2 実通信クライアント (JSON対応 / 2026-03-15 リリース版準拠)
 *
 * Base URL: https://laws.e-gov.go.jp/api/2
 * 公式仕様: Swagger UI = /api/2/swagger-ui, Redoc = /api/2/redoc/
 *
 * 既存 lib/japan/law_tracker.ts は I/F とモッククライアントのみだったため
 * 本モジュールで実通信レイヤーを完成させる。
 *
 * 設計指針:
 *  - fetch ベース (Node 20+ / Bun / Browser 共通)
 *  - ETag + If-None-Match で帯域節約(★現行 e-Gov v2 は Cache-Control: no-store で ETag を返さないため
 *    実効ゼロ=将来 API が ETag 対応した時のための備え。現状は素のGETとして動く・S7敵対監査で正直化)
 *  - 429 → exponential backoff (max 5 retry, 1s→2s→4s→8s→16s)
 *  - レート制限 1 req/sec (Token Bucket)
 *  - timeout 30s
 *  - 出典記載自動付与 (Attribution / e-Gov 公的データ利用規則 v1.0 準拠)
 *  - DI 可能: fetch 実装を外部から注入できる
 *  - error は LegalUpdateError として正規化
 */

import type {
  EgovApiClient,
  EgovLawSummary,
  EgovLawTextChunk,
  LawCategory,
} from '../law_tracker';
import { rateLimited } from './rate_limiter';
import { attachAttribution, buildEgovAttribution } from './attribution';

// ============================================================================
// 設定
// ============================================================================

export const EGOV_V2_BASE = 'https://laws.e-gov.go.jp/api/2';

/**
 * e-Gov 法令API v2 の実エンドポイント(一次ソースで確定・S7/L21-WK07)。
 *   裏取り: OpenAPI 仕様 https://laws.e-gov.go.jp/api/2/swagger-ui/lawapi-v2.yaml
 *           Swagger UI https://laws.e-gov.go.jp/api/2/swagger-ui ・Redoc /api/2/redoc/
 *   ★v2 は利用登録・APIキー不要の公開API(owner手続き不要)=巡回基盤を owner 残から外せる。
 *   JSON 標準対応(v1 は XML のみ)。/law_data は asof(特定時点)指定可。
 */
export const EGOV_V2_ENDPOINTS = {
  /** 法令検索(キーワード/種別/期間) */
  laws: '/laws',
  /** 法令本文取得(law_id_or_num_or_revision_id) */
  lawData: '/law_data/{id}',
  /** 改正履歴取得(law_id_or_num) */
  lawRevisions: '/law_revisions/{id}',
  /** 全文検索 */
  keyword: '/keyword',
} as const;

/** エンドポイント確定状態(L21-WK07-EGOV-ENDPOINT 軸が参照)。'confirmed'=一次ソース裏取り済。 */
export const EGOV_V2_ENDPOINT_STATUS: 'confirmed' | 'unconfirmed' = 'confirmed';
export const EGOV_V2_OPENAPI_URL = 'https://laws.e-gov.go.jp/api/2/swagger-ui/lawapi-v2.yaml';

const DEFAULT_TIMEOUT_MS = 30_000;
const DEFAULT_MAX_RETRIES = 5;
const DEFAULT_USER_AGENT = 'SoloptiLinkAI-LawAutoUpdate/1.0 (+https://soloptilink.com/)';

// ============================================================================
// 型
// ============================================================================

/** API v2 検索エンドポイント想定パラメータ (実エンドポイントは Swagger 参照) */
export interface EgovSearchParams {
  /** キーワード (法令名/通称) */
  keyword?: string;
  /** 法令種別: Constitution / Act / CabinetOrder / MinisterialOrdinance / Rule */
  lawType?: 'Constitution' | 'Act' | 'CabinetOrder' | 'MinisterialOrdinance' | 'Rule';
  /** 公布日(以降) YYYY-MM-DD */
  promulgationDateFrom?: string;
  /** 公布日(以前) YYYY-MM-DD */
  promulgationDateTo?: string;
  /** ページ */
  page?: number;
  /** 1ページあたり件数 (max 100) */
  limit?: number;
}

/** API v2 法令本文取得レスポンスの最小型 (JSON簡易版) */
export interface EgovLawDataResponse {
  law_id: string;
  law_title: string;
  law_num: string;
  promulgation_date: string;
  last_update_date?: string;
  /** 条文配列 (XML→JSON 変換後) */
  articles: Array<{
    article_num: string;
    article_caption?: string;
    paragraphs?: Array<{
      paragraph_num?: string;
      sentence?: string;
      items?: Array<{ item_num?: string; sentence?: string }>;
    }>;
    /** XML→JSON 変換のフラット表現 (簡易版) */
    text?: string;
  }>;
  /** ETag (キャッシュ用) */
  _etag?: string;
}

/** v2 /law_data 実レスポンス(ネスト構造・一次ソース確認・S7/L21-WK07) */
export interface EgovLawDataV2 {
  law_info?: { law_id?: string; law_num?: string; promulgation_date?: string; [k: string]: unknown };
  revision_info?: { law_title?: string; updated?: string; amendment_enforcement_date?: string; [k: string]: unknown };
  /** 条文本文(XML→JSON 木: {tag, attr, children}) */
  law_full_text?: LawFullTextNode | null;
  [k: string]: unknown;
}

/** law_full_text の木ノード(タグ/属性/子。子は文字列(テキスト)かネストノード) */
export interface LawFullTextNode {
  tag?: string;
  attr?: Record<string, string>;
  children?: Array<LawFullTextNode | string>;
}

/**
 * law_full_text 木から条文テキストを EgovLawTextChunk[] に抽出する(S7/L21-WK07)。
 *   - Article タグの attr.Num を articleNum 文脈として引き継ぐ。
 *   - 文字列リーフ(children 内の非空 str)を text として収集。空白のみは捨てる。
 *   - 条文が無い布告等は articleNum を '0' とする(空にしない)。
 */
export function extractLawTextChunks(root: LawFullTextNode): EgovLawTextChunk[] {
  const chunks: EgovLawTextChunk[] = [];
  const walk = (node: LawFullTextNode | string, articleNum: string): void => {
    if (typeof node === 'string') {
      const t = node.trim();
      if (t) chunks.push({ articleNum: articleNum || '0', text: t });
      return;
    }
    if (!node || typeof node !== 'object') return;
    let art = articleNum;
    if (node.tag === 'Article') art = String(node.attr?.Num ?? art ?? '0');
    for (const c of node.children ?? []) walk(c, art);
  };
  walk(root, '0');
  return chunks;
}

export interface EgovV2ClientOptions {
  baseUrl?: string;
  timeoutMs?: number;
  maxRetries?: number;
  userAgent?: string;
  /** DI: fetch 実装 (テスト用にモック注入) */
  fetchImpl?: typeof fetch;
  /** ETag キャッシュ (key=lawId, value=etag) */
  etagCache?: Map<string, string>;
  /** レート制限を無効化 (テスト用) */
  disableRateLimit?: boolean;
  /** API キー (将来 v3 で要求される可能性に備える) */
  apiKey?: string;
}

export class LegalUpdateError extends Error {
  constructor(
    public readonly code:
      | 'TIMEOUT'
      | 'RATE_LIMIT'
      | 'NOT_FOUND'
      | 'NOT_MODIFIED'
      | 'PARSE_FAILED'
      | 'NETWORK'
      | 'INVALID_RESPONSE',
    message: string,
    public readonly cause?: unknown,
  ) {
    super(message);
    this.name = 'LegalUpdateError';
  }
}

// ============================================================================
// クライアント本体
// ============================================================================

export class EgovV2Client implements EgovApiClient {
  private readonly baseUrl: string;
  private readonly timeoutMs: number;
  private readonly maxRetries: number;
  private readonly userAgent: string;
  private readonly fetchImpl: typeof fetch;
  private readonly etagCache: Map<string, string>;
  private readonly disableRateLimit: boolean;
  private readonly apiKey?: string;

  constructor(opts: EgovV2ClientOptions = {}) {
    this.baseUrl = opts.baseUrl ?? EGOV_V2_BASE;
    this.timeoutMs = opts.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    this.maxRetries = opts.maxRetries ?? DEFAULT_MAX_RETRIES;
    this.userAgent = opts.userAgent ?? DEFAULT_USER_AGENT;
    // 実行環境に fetch がない場合は明示エラー
    const candidate = opts.fetchImpl ?? (typeof fetch === 'function' ? fetch : undefined);
    if (!candidate) {
      throw new Error(
        'EgovV2Client: fetch implementation not available. Node 20+ または fetchImpl を注入してください。',
      );
    }
    this.fetchImpl = candidate;
    this.etagCache = opts.etagCache ?? new Map();
    this.disableRateLimit = opts.disableRateLimit ?? false;
    this.apiKey = opts.apiKey;
  }

  /** 法令検索 (キーワード/カテゴリ/期間) */
  async searchLaws(keyword: string, _category?: LawCategory): Promise<EgovLawSummary[]> {
    const params = new URLSearchParams();
    // ★v2 /laws は『keyword』検索パラメータを持たない(全文検索は別 /keyword)。法令名での絞り込みは
    //   law_title が正(一次ソース実レスポンスで確認・S7/L21-WK07 敵対監査で keyword 無視バグを是正)。
    if (keyword) params.set('law_title', keyword);
    // 実エンドポイント /laws は OpenAPI(lawapi-v2.yaml)で確定済(S7/L21-WK07・EGOV_V2_ENDPOINTS.laws)。
    const url = `${this.baseUrl}${EGOV_V2_ENDPOINTS.laws}?${params.toString()}`;
    const raw = await this.requestJson<{ laws: unknown[] }>(url, { method: 'GET' });
    const list = Array.isArray((raw as { laws?: unknown[] }).laws)
      ? (raw as { laws: unknown[] }).laws
      : [];
    return list.map((row) => this.toLawSummary(row));
  }

  async fetchLawSummary(lawId: string): Promise<EgovLawSummary> {
    if (!lawId || typeof lawId !== 'string') {
      throw new LegalUpdateError('INVALID_RESPONSE', 'lawId は必須');
    }
    // ★v2 /law_data は {law_info, revision_info, law_full_text, ...} のネスト構造(一次ソース確認)。
    //   旧コードの data.law_id/law_title は v2 で存在しない(常に undefined)=summary 取得バグを是正。
    const url = `${this.baseUrl}${EGOV_V2_ENDPOINTS.lawData.replace('{id}', encodeURIComponent(lawId))}`;
    const data = await this.requestJson<EgovLawDataV2>(url, { method: 'GET' });
    const li = data.law_info ?? {};
    const ri = data.revision_info ?? {};
    return {
      lawId: String(li.law_id ?? lawId),
      lawTitle: String(ri.law_title ?? ''),
      lawNum: String(li.law_num ?? ''),
      promulgationDate: String(li.promulgation_date ?? ''),
      lastUpdateDate: ri.updated ? String(ri.updated) : ri.amendment_enforcement_date ? String(ri.amendment_enforcement_date) : undefined,
    };
  }

  async fetchLawText(lawId: string): Promise<EgovLawTextChunk[]> {
    if (!lawId) throw new LegalUpdateError('INVALID_RESPONSE', 'lawId は必須');
    // ★v2 /law_data は条文を law_full_text({tag,attr,children} の XML→JSON 木)で返す(articles キーは無い)。
    //   旧コードの data.articles は常に undefined で chunks=[] 恒常だった(S7 敵対監査 R1 で is_real 判明)=是正。
    // 1) law_id 直で全文取得を試行。
    const direct = await this.tryFetchFullText(lawId);
    if (direct) return extractLawTextChunks(direct);
    // 2) ★law_id 直が 404(全文ファイル無し)の法令(例: 介護保険法)は /law_revisions から版IDを解決し
    //    CurrentEnforced→PreviousEnforced(新しい順)で全文を持つ版を探す(S7敵対監査R2 で『revision_id経由なら
    //    全文取得可』が判明=『全文非提供』の誤判定を是正)。外部API礼節のため試行数を上限する。
    const revIds = await this.resolveFullTextRevisionIds(lawId);
    for (const rid of revIds) {
      if (rid === lawId) continue;
      const tree = await this.tryFetchFullText(rid);
      if (tree) return extractLawTextChunks(tree);
    }
    // 3) いずれの版でも全文ファイルが無い=真に全文非提供(『改正なし』でなく『取得不能』として呼出側が区別)。
    return [];
  }

  /** /law_data/{id} を引いて law_full_text 木を返す(404=全文無しは null・エラーで巡回を止めない)。 */
  private async tryFetchFullText(id: string): Promise<LawFullTextNode | null> {
    const url = `${this.baseUrl}${EGOV_V2_ENDPOINTS.lawData.replace('{id}', encodeURIComponent(id))}`;
    try {
      const data = await this.requestJson<EgovLawDataV2>(url, { method: 'GET' });
      return data.law_full_text && typeof data.law_full_text === 'object' ? (data.law_full_text as LawFullTextNode) : null;
    } catch (e) {
      if (e instanceof LegalUpdateError && e.code === 'NOT_FOUND') return null;
      throw e;
    }
  }

  /** /law_revisions/{lawId} から全文取得を試す版ID列を作る(CurrentEnforced→PreviousEnforced 新しい順・上限 max 件)。 */
  private async resolveFullTextRevisionIds(lawId: string, max = 4): Promise<string[]> {
    const url = `${this.baseUrl}${EGOV_V2_ENDPOINTS.lawRevisions.replace('{id}', encodeURIComponent(lawId))}`;
    let data: { revisions?: Array<{ law_revision_id?: string; current_revision_status?: string }> };
    try {
      data = await this.requestJson(url, { method: 'GET' });
    } catch {
      return [];
    }
    const revs = data.revisions ?? [];
    const pick = (status: string) =>
      revs.filter((r) => r.current_revision_status === status).map((r) => r.law_revision_id);
    const ordered = [...pick('CurrentEnforced'), ...pick('PreviousEnforced')].filter(
      (x): x is string => typeof x === 'string' && x.length > 0,
    );
    return ordered.slice(0, max);
  }

  /**
   * 指定日以降に最終更新された法令の ID 一覧を取得。
   * (v2 公式に最終更新ベース検索が無い場合は last_update_date を都度比較)
   */
  async listRecentlyUpdatedLawIds(_sinceISO: string): Promise<string[]> {
    // ★正直化(S7敵対監査): v2 /laws に updated_from/updated_to パラメータは在るが、実測で件数が
    //   絞られず(全件返却)期待通りのインクリメンタル抽出にならなかった=信頼できる since 抽出は未確立。
    //   よって巡回の正経路は LAW_CATALOG(catalog_full.ts)列挙 or law_title 検索→last_update_date 比較
    //   (SourceRegistry.orchestrate / calendar_sync)。本メソッドは確証が取れるまで空配列(過大実装しない)。
    return [];
  }

  // --------------------------------------------------------------------------
  // 内部
  // --------------------------------------------------------------------------

  private toLawSummary(row: unknown): EgovLawSummary {
    // v2 /laws の行は {law_info:{law_id,law_num,promulgation_date}, revision_info:{law_title,updated,...}}
    // のネスト構造(一次ソース実レスポンスで確認・S7/L21-WK07)。平坦キーは後方互換フォールバック。
    const r = (row && typeof row === 'object' ? row : {}) as Record<string, any>;
    const li = (r.law_info ?? {}) as Record<string, any>;
    const ri = (r.revision_info ?? {}) as Record<string, any>;
    // ★/laws 行は current_revision_info も持つ(現在施行中の最新版)。最新施行日は current_revision_info を優先し、
    //   無ければ revision_info にフォールバック(S7敵対監査: 将来改正で乖離した際に古い施行日を掴むのを防ぐ)。
    const cri = (r.current_revision_info ?? {}) as Record<string, any>;
    const freshest =
      cri.amendment_enforcement_date ?? cri.updated ?? ri.updated ?? ri.amendment_enforcement_date ?? r.last_update_date;
    return {
      lawId: String(li.law_id ?? r.law_id ?? r.lawId ?? ''),
      lawTitle: String(ri.law_title ?? cri.law_title ?? r.law_title ?? r.lawTitle ?? ''),
      lawNum: String(li.law_num ?? r.law_num ?? r.lawNum ?? ''),
      promulgationDate: String(li.promulgation_date ?? r.promulgation_date ?? r.promulgationDate ?? ''),
      lastUpdateDate: freshest ? String(freshest) : undefined,
    };
  }

  private async requestJson<T>(url: string, init: RequestInit): Promise<T> {
    // ★2026-08-01: 出典表示の連絡先 (EGOV_LIVE_ATTRIBUTION_CONTACT) を **通信前に** 解決する。
    //   ライブ巡回が有効なのに未設定なら EgovAttributionContactMissingError を投げ、
    //   外向きの実通信そのものを行わない (ダミーで埋めて体裁だけ整える実装にしない)。
    //   kill-switch: SOLOPTILINK_EGOV_ATTRIBUTION_ENFORCE=off で従来動作。
    const attribution = buildEgovAttribution();

    const headers: Record<string, string> = {
      Accept: 'application/json',
      'User-Agent': this.userAgent,
      ...((init.headers as Record<string, string>) ?? {}),
    };
    if (this.apiKey) headers['Authorization'] = `Bearer ${this.apiKey}`;

    // ETag: lawId をキャッシュキーに使う (URL末尾 path 部)
    const cacheKey = url;
    const cachedEtag = this.etagCache.get(cacheKey);
    if (cachedEtag) headers['If-None-Match'] = cachedEtag;

    let lastErr: unknown;
    for (let attempt = 0; attempt <= this.maxRetries; attempt++) {
      try {
        const exec = async (): Promise<T> => {
          const ctrl = new AbortController();
          const t = setTimeout(() => ctrl.abort(), this.timeoutMs);
          let res: Response;
          try {
            res = await this.fetchImpl(url, { ...init, headers, signal: ctrl.signal });
          } catch (err) {
            if ((err as { name?: string }).name === 'AbortError') {
              throw new LegalUpdateError('TIMEOUT', `e-Gov API timeout: ${url}`, err);
            }
            throw new LegalUpdateError('NETWORK', `e-Gov API network error: ${url}`, err);
          } finally {
            clearTimeout(t);
          }

          if (res.status === 304) {
            throw new LegalUpdateError('NOT_MODIFIED', `Not modified: ${url}`);
          }
          if (res.status === 404) {
            throw new LegalUpdateError('NOT_FOUND', `Law not found: ${url}`);
          }
          if (res.status === 429) {
            const retryAfter = res.headers.get('Retry-After');
            throw new LegalUpdateError(
              'RATE_LIMIT',
              `Rate limited (Retry-After=${retryAfter ?? 'unset'})`,
            );
          }
          if (!res.ok) {
            const body = await res.text().catch(() => '');
            throw new LegalUpdateError(
              'INVALID_RESPONSE',
              `e-Gov API ${res.status}: ${body.slice(0, 200)}`,
            );
          }

          // ETag 更新
          const newEtag = res.headers.get('ETag');
          if (newEtag) this.etagCache.set(cacheKey, newEtag);

          let parsed: T;
          try {
            parsed = (await res.json()) as T;
          } catch (err) {
            throw new LegalUpdateError('PARSE_FAILED', 'JSON parse failed', err);
          }
          return attachAttribution(parsed, attribution) as T;
        };

        if (this.disableRateLimit) {
          return await exec();
        }
        return await rateLimited('egov_v2', exec);
      } catch (err) {
        lastErr = err;
        if (err instanceof LegalUpdateError) {
          if (err.code === 'NOT_FOUND' || err.code === 'NOT_MODIFIED' || err.code === 'PARSE_FAILED') {
            throw err; // 再試行しても無意味
          }
          if (err.code === 'RATE_LIMIT' || err.code === 'TIMEOUT' || err.code === 'NETWORK') {
            const backoff = Math.min(16_000, 1000 * 2 ** attempt);
            await sleep(backoff);
            continue;
          }
        }
        throw err;
      }
    }
    throw lastErr instanceof Error
      ? lastErr
      : new LegalUpdateError('NETWORK', `e-Gov API max retries exceeded: ${url}`);
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * デフォルトのシングルトン (テスト時は new EgovV2Client(opts) で差し替え可能)
 */
let _defaultClient: EgovV2Client | undefined;
export function getDefaultEgovV2Client(): EgovV2Client {
  if (!_defaultClient) _defaultClient = new EgovV2Client();
  return _defaultClient;
}
export function setDefaultEgovV2Client(client: EgovV2Client): void {
  _defaultClient = client;
}
