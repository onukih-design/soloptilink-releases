/**
 * Phase 46-LU-6 / Usage Metering & Billing
 *
 * テナント別の利用量計測と Stripe 風の請求書生成。
 * 実際の決済処理は外部 (Stripe/PayPal/銀行振込) に委譲し、
 * 本モジュールは利用量から請求金額を計算するロジックを担う。
 *
 *  - 月次定額 (プラン基本料金)
 *  - 従量課金 (上限超過分)
 *  - 利用ベース費目: API 追加クエリ / 追加ストレージ / 追加ユーザー
 *  - 請求書 PDF 生成は document_exporter と連動
 */

import type { PlanTier } from '../subscription/plans_catalog';
import { getPlanByTier } from '../subscription/plans_catalog';
import type { QuotaField } from '../rate_limiting/plan_quota';

export interface MeteringEvent {
  event_id: string;
  tenant_id: string;
  timestamp: string;
  resource: QuotaField | 'storage_gb' | 'extra_user';
  quantity: number;
  /** メタデータ */
  metadata?: { api_endpoint?: string; user_id?: string };
}

const METERING_EVENTS: MeteringEvent[] = [];

export function recordEvent(input: Omit<MeteringEvent, 'event_id' | 'timestamp'>): MeteringEvent {
  const ev: MeteringEvent = {
    event_id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    timestamp: new Date().toISOString(),
    ...input,
  };
  METERING_EVENTS.push(ev);
  return ev;
}

export interface UsageSummary {
  tenant_id: string;
  period_start: string;
  period_end: string;
  plan_tier: PlanTier;
  by_resource: Record<string, number>;
  total_events: number;
}

export function summarizeUsage(input: { tenant_id: string; period_start: string; period_end: string; plan_tier: PlanTier }): UsageSummary {
  const events = METERING_EVENTS.filter((e) =>
    e.tenant_id === input.tenant_id
    && e.timestamp >= input.period_start
    && e.timestamp <= input.period_end,
  );
  const byResource: Record<string, number> = {};
  for (const e of events) byResource[e.resource] = (byResource[e.resource] ?? 0) + e.quantity;
  return {
    tenant_id: input.tenant_id,
    period_start: input.period_start,
    period_end: input.period_end,
    plan_tier: input.plan_tier,
    by_resource: byResource,
    total_events: events.length,
  };
}

/**
 * オーバーレート単価 (プラン上限超過時の従量課金)
 */
const OVERAGE_RATES: Record<string, number> = {
  rag_queries_per_month: 5, // 1クエリ ¥5
  compliance_scans_per_month: 30,
  contracts_per_month: 200,
  risk_assessments_per_month: 100,
  exports_per_month: 50,
  storage_gb: 100, // 1GB ¥100/月
  extra_user: 1500, // 1ユーザー ¥1500/月
};

export interface InvoiceLine {
  description: string;
  quantity: number;
  unit_price_jpy: number;
  subtotal_jpy: number;
}

export interface Invoice {
  invoice_id: string;
  tenant_id: string;
  period_start: string;
  period_end: string;
  plan_tier: PlanTier;
  lines: InvoiceLine[];
  subtotal_jpy: number;
  tax_rate: number;
  tax_jpy: number;
  total_jpy: number;
  issued_at: string;
  due_at: string;
  status: 'draft' | 'issued' | 'paid' | 'overdue' | 'void';
  /** 適格請求書登録番号 (T+13桁) */
  registration_number?: string;
}

export function generateInvoice(input: {
  tenant_id: string;
  plan_tier: PlanTier;
  period_start: string;
  period_end: string;
  registration_number?: string;
}): Invoice {
  const plan = getPlanByTier(input.plan_tier);
  const usage = summarizeUsage(input);
  const lines: InvoiceLine[] = [];

  // 月額基本料金
  if (plan && plan.monthly_price_jpy > 0) {
    lines.push({
      description: `${plan.display_name} プラン 月額料金`,
      quantity: 1,
      unit_price_jpy: plan.monthly_price_jpy,
      subtotal_jpy: plan.monthly_price_jpy,
    });
  }

  // オーバー
  if (plan) {
    for (const [resource, used] of Object.entries(usage.by_resource)) {
      if (!(resource in OVERAGE_RATES)) continue;
      const planLimit = (plan.features as Record<string, number>)[resource];
      if (typeof planLimit !== 'number') continue;
      const overage = Math.max(0, used - planLimit);
      if (overage > 0) {
        const rate = OVERAGE_RATES[resource];
        lines.push({
          description: `${resource} 超過分`,
          quantity: overage,
          unit_price_jpy: rate,
          subtotal_jpy: overage * rate,
        });
      }
    }
  }

  // ストレージ・追加ユーザー (もし発生していれば)
  for (const r of ['storage_gb', 'extra_user'] as const) {
    if (!usage.by_resource[r]) continue;
    const q = usage.by_resource[r];
    const rate = OVERAGE_RATES[r];
    lines.push({
      description: r,
      quantity: q,
      unit_price_jpy: rate,
      subtotal_jpy: q * rate,
    });
  }

  const subtotal = lines.reduce((acc, l) => acc + l.subtotal_jpy, 0);
  const taxRate = 0.10;
  const tax = Math.floor(subtotal * taxRate);
  const total = subtotal + tax;

  const issuedAt = new Date().toISOString();
  const due = new Date();
  due.setDate(due.getDate() + 30);

  return {
    invoice_id: `inv_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    tenant_id: input.tenant_id,
    period_start: input.period_start,
    period_end: input.period_end,
    plan_tier: input.plan_tier,
    lines,
    subtotal_jpy: subtotal,
    tax_rate: taxRate,
    tax_jpy: tax,
    total_jpy: total,
    issued_at: issuedAt,
    due_at: due.toISOString(),
    status: 'draft',
    registration_number: input.registration_number,
  };
}

/**
 * インボイス制度 (R5.10) 適格請求書チェック
 */
export function validateRegistrationNumber(num?: string): { valid: boolean; reason?: string } {
  if (!num) return { valid: false, reason: '登録番号未指定 (適格請求書要件未充足)' };
  if (!/^T\d{13}$/.test(num)) return { valid: false, reason: 'フォーマット不一致 (T+13桁数字必須)' };
  return { valid: true };
}

export function renderInvoiceMarkdown(inv: Invoice): string {
  const lines: string[] = [];
  lines.push(`# 請求書 — ${inv.invoice_id}`);
  lines.push('');
  lines.push(`発行日: ${inv.issued_at.slice(0, 10)} / 支払期限: ${inv.due_at.slice(0, 10)}`);
  lines.push(`対象期間: ${inv.period_start.slice(0, 10)} ~ ${inv.period_end.slice(0, 10)}`);
  if (inv.registration_number) lines.push(`登録番号: ${inv.registration_number} (適格請求書)`);
  lines.push('');
  lines.push('| 項目 | 数量 | 単価 (¥) | 小計 (¥) |');
  lines.push('|---|---:|---:|---:|');
  for (const l of inv.lines) {
    lines.push(`| ${l.description} | ${l.quantity} | ${l.unit_price_jpy.toLocaleString()} | ${l.subtotal_jpy.toLocaleString()} |`);
  }
  lines.push(`| **小計** | | | **${inv.subtotal_jpy.toLocaleString()}** |`);
  lines.push(`| 消費税 (${(inv.tax_rate * 100).toFixed(0)}%) | | | ${inv.tax_jpy.toLocaleString()} |`);
  lines.push(`| **合計** | | | **¥${inv.total_jpy.toLocaleString()}** |`);
  return lines.join('\n');
}

export function countMeteringEvents(): { total: number; tenants: number } {
  const tenants = new Set<string>();
  for (const e of METERING_EVENTS) tenants.add(e.tenant_id);
  return { total: METERING_EVENTS.length, tenants: tenants.size };
}

export function _resetBillingForTests(): void {
  METERING_EVENTS.length = 0;
}
