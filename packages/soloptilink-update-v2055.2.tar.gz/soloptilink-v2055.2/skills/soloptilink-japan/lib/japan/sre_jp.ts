/**
 * @fileoverview Phase 12 - SRE 日本適応版 DNA
 *
 * Google SRE 本 + 日本企業の運用実態 (営業時間/休業日/情報システム部門特性)
 * を統合した日本仕様の SRE モジュール:
 *   - 営業時間別 SLO (オフィスアワー/夜間/休日)
 *   - エラーバジェット (休業日除外計算)
 *   - 日本祝日カレンダー (内閣府発表ベース)
 *   - 障害対応の TOIL 削減判定
 *   - オンコール体制 (情報システム部の慣習: 平日対応中心 + 夜間SES)
 *   - サポートデスク (お客様窓口) との連動
 *   - リリースカレンダー (年末年始/GW/お盆 凍結期間)
 */

// ============================================================================
// 日本祝日 (内閣府ベース・主要年度)
// ============================================================================

/**
 * 【参考データ】2024/2025 の固定表。
 *
 * ★この表は 2025-11-24 で終端しており、2026 年以降を含まない。
 *   以前はこの表が既定値だったため、2026 年以降の祝日がすべて平日と判定されていた。
 *   現在の既定は下の computeJapaneseHolidays() による算出 (国民の祝日に関する法律に基づく)。
 *   本定数は既存呼び出し (明示的に表を渡す経路) との互換のために残している。
 */
export const JP_HOLIDAYS_2024_2025: { date: string; name: string }[] = [
  // 2024 (令和6年)
  { date: '2024-01-01', name: '元日' },
  { date: '2024-01-08', name: '成人の日' },
  { date: '2024-02-11', name: '建国記念の日' },
  { date: '2024-02-12', name: '建国記念の日 振替休日' },
  { date: '2024-02-23', name: '天皇誕生日' },
  { date: '2024-03-20', name: '春分の日' },
  { date: '2024-04-29', name: '昭和の日' },
  { date: '2024-05-03', name: '憲法記念日' },
  { date: '2024-05-04', name: 'みどりの日' },
  { date: '2024-05-05', name: 'こどもの日' },
  { date: '2024-05-06', name: 'こどもの日 振替休日' },
  { date: '2024-07-15', name: '海の日' },
  { date: '2024-08-11', name: '山の日' },
  { date: '2024-08-12', name: '山の日 振替休日' },
  { date: '2024-09-16', name: '敬老の日' },
  { date: '2024-09-22', name: '秋分の日' },
  { date: '2024-09-23', name: '秋分の日 振替休日' },
  { date: '2024-10-14', name: 'スポーツの日' },
  { date: '2024-11-03', name: '文化の日' },
  { date: '2024-11-04', name: '文化の日 振替休日' },
  { date: '2024-11-23', name: '勤労感謝の日' },
  // 2025 (令和7年)
  { date: '2025-01-01', name: '元日' },
  { date: '2025-01-13', name: '成人の日' },
  { date: '2025-02-11', name: '建国記念の日' },
  { date: '2025-02-23', name: '天皇誕生日' },
  { date: '2025-02-24', name: '天皇誕生日 振替休日' },
  { date: '2025-03-20', name: '春分の日' },
  { date: '2025-04-29', name: '昭和の日' },
  { date: '2025-05-03', name: '憲法記念日' },
  { date: '2025-05-04', name: 'みどりの日' },
  { date: '2025-05-05', name: 'こどもの日' },
  { date: '2025-05-06', name: 'こどもの日 振替休日' },
  { date: '2025-07-21', name: '海の日' },
  { date: '2025-08-11', name: '山の日' },
  { date: '2025-09-15', name: '敬老の日' },
  { date: '2025-09-23', name: '秋分の日' },
  { date: '2025-10-13', name: 'スポーツの日' },
  { date: '2025-11-03', name: '文化の日' },
  { date: '2025-11-23', name: '勤労感謝の日' },
  { date: '2025-11-24', name: '勤労感謝の日 振替休日' },
];

// ============================================================================
// 祝日の算出 (国民の祝日に関する法律)
//   固定表は年を跨ぐと必ず破綻するため、法律の規則から算出する。
//   - ハッピーマンデー (成人の日/海の日/敬老の日/スポーツの日) は「第N月曜」で算出
//   - 春分の日/秋分の日は確立された近似式 (1980-2099 用の定数) で算出
//   - 振替休日 (日曜と重なった場合) / 国民の休日 (祝日に挟まれた平日) も算出
//   - 算出範囲外の年は「黙って平日」と答えず、判定不能として扱う
// ============================================================================

/** 算出可能な最小年 (平成元年。これ以前は法改正履歴が別体系のため対象外) */
export const JP_HOLIDAY_CALC_MIN_YEAR = 1989;
/** 算出可能な最大年 (春分・秋分の近似式が有効な範囲) */
export const JP_HOLIDAY_CALC_MAX_YEAR = 2099;

/** 算出範囲外・日付として解釈できない入力を「平日」と誤答しないためのエラー */
export class HolidayRangeError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'HolidayRangeError';
  }
}

export type HolidayKind = 'national_holiday' | 'substitute' | 'citizens_holiday';

export interface JapaneseHoliday {
  date: string;
  name: string;
  kind: HolidayKind;
}

export interface HolidayInfo {
  date: string;
  /** 算出可能な範囲か */
  supported: boolean;
  /** 祝日か。supported=false のときは null (=判定不能。false=平日 と混同しない) */
  holiday: boolean | null;
  name: string | null;
  kind: HolidayKind | null;
  /** supported=false のときの理由 (日本語) */
  reason?: string;
}

function pad2(n: number): string {
  return String(n).padStart(2, '0');
}

function ymd(y: number, m: number, d: number): string {
  return `${y}-${pad2(m)}-${pad2(d)}`;
}

/** UTC 基準の曜日 (0=日曜) */
function dayOfWeek(y: number, m: number, d: number): number {
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}

/** その月の第 n 月曜日の日 */
function nthMonday(y: number, m: number, n: number): number {
  const firstDow = dayOfWeek(y, m, 1);
  const firstMonday = 1 + ((8 - firstDow) % 7);
  return firstMonday + 7 * (n - 1);
}

/** 春分日 (1980-2099 用の近似式) */
export function vernalEquinoxDay(year: number): number {
  return Math.floor(20.8431 + 0.242194 * (year - 1980) - Math.floor((year - 1980) / 4));
}

/** 秋分日 (1980-2099 用の近似式) */
export function autumnalEquinoxDay(year: number): number {
  return Math.floor(23.2488 + 0.242194 * (year - 1980) - Math.floor((year - 1980) / 4));
}

/** 一度きりの祝日 (皇室行事・オリンピック特例) */
const ONE_TIME_HOLIDAYS: Record<number, Array<{ date: string; name: string }>> = {
  1989: [{ date: '1989-02-24', name: '昭和天皇の大喪の礼' }],
  1990: [{ date: '1990-11-12', name: '即位礼正殿の儀' }],
  1993: [{ date: '1993-06-09', name: '皇太子徳仁親王の結婚の儀' }],
  2019: [
    { date: '2019-05-01', name: '天皇の即位の日' },
    { date: '2019-10-22', name: '即位礼正殿の儀' },
  ],
};

/** 年内の法定祝日 (振替休日・国民の休日を含まない) */
function baseHolidays(year: number): Array<{ date: string; name: string }> {
  const out: Array<{ date: string; name: string }> = [];
  const add = (m: number, d: number, name: string) => out.push({ date: ymd(year, m, d), name });

  add(1, 1, '元日');
  // 成人の日: 2000年からハッピーマンデー (1月第2月曜)
  if (year >= 2000) add(1, nthMonday(year, 1, 2), '成人の日');
  else add(1, 15, '成人の日');

  add(2, 11, '建国記念の日');
  // 天皇誕生日: 〜2018=12/23 (平成) / 2019=なし / 2020〜=2/23 (令和)
  if (year >= 2020) add(2, 23, '天皇誕生日');

  add(3, vernalEquinoxDay(year), '春分の日');

  // 4/29: 2007年から昭和の日 (それ以前はみどりの日)
  add(4, 29, year >= 2007 ? '昭和の日' : 'みどりの日');
  add(5, 3, '憲法記念日');
  // 5/4: 2007年からみどりの日 (それ以前は国民の休日として自動算出される)
  if (year >= 2007) add(5, 4, 'みどりの日');
  add(5, 5, 'こどもの日');

  // 海の日: 1996年新設(7/20)→2003年から7月第3月曜。2020/2021 はオリンピック特例
  if (year === 2020) add(7, 23, '海の日');
  else if (year === 2021) add(7, 22, '海の日');
  else if (year >= 2003) add(7, nthMonday(year, 7, 3), '海の日');
  else if (year >= 1996) add(7, 20, '海の日');

  // 山の日: 2016年新設。2020/2021 はオリンピック特例
  if (year === 2020) add(8, 10, '山の日');
  else if (year === 2021) add(8, 8, '山の日');
  else if (year >= 2016) add(8, 11, '山の日');

  // 敬老の日: 2003年から9月第3月曜
  if (year >= 2003) add(9, nthMonday(year, 9, 3), '敬老の日');
  else add(9, 15, '敬老の日');

  add(9, autumnalEquinoxDay(year), '秋分の日');

  // 体育の日→スポーツの日 (2020改称)。2000年から10月第2月曜。2020/2021 はオリンピック特例
  const sportsName = year >= 2020 ? 'スポーツの日' : '体育の日';
  if (year === 2020) add(7, 24, sportsName);
  else if (year === 2021) add(7, 23, sportsName);
  else if (year >= 2000) add(10, nthMonday(year, 10, 2), sportsName);
  else add(10, 10, sportsName);

  add(11, 3, '文化の日');
  add(11, 23, '勤労感謝の日');

  // 天皇誕生日 (平成): 12/23 は 2018 年まで
  if (year <= 2018) add(12, 23, '天皇誕生日');

  for (const h of ONE_TIME_HOLIDAYS[year] ?? []) out.push(h);

  return out.sort((a, b) => a.date.localeCompare(b.date));
}

function shiftDate(date: string, days: number): string {
  const [y, m, d] = date.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1, d + days));
  return ymd(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate());
}

function isSunday(date: string): boolean {
  const [y, m, d] = date.split('-').map(Number);
  return dayOfWeek(y, m, d) === 0;
}

const HOLIDAY_CACHE = new Map<number, JapaneseHoliday[]>();

/**
 * 指定年の祝日 (法定祝日 + 国民の休日 + 振替休日) を算出する。
 * @throws HolidayRangeError 算出可能範囲外の年
 */
export function computeJapaneseHolidays(year: number): JapaneseHoliday[] {
  if (!Number.isInteger(year) || year < JP_HOLIDAY_CALC_MIN_YEAR || year > JP_HOLIDAY_CALC_MAX_YEAR) {
    throw new HolidayRangeError(
      `${year} 年の祝日は算出対象外です (算出可能な範囲は ${JP_HOLIDAY_CALC_MIN_YEAR}〜${JP_HOLIDAY_CALC_MAX_YEAR} 年)`,
    );
  }
  const cached = HOLIDAY_CACHE.get(year);
  if (cached) return cached;

  const base = baseHolidays(year);
  const byDate = new Map<string, JapaneseHoliday>();
  for (const h of base) byDate.set(h.date, { date: h.date, name: h.name, kind: 'national_holiday' });

  // 国民の休日: 前日・翌日がともに祝日である平日 (日曜を除く)
  const citizens: JapaneseHoliday[] = [];
  for (const h of base) {
    const candidate = shiftDate(h.date, 1);
    if (byDate.has(candidate)) continue;
    if (isSunday(candidate)) continue;
    if (!byDate.has(shiftDate(candidate, 1))) continue;
    citizens.push({ date: candidate, name: '国民の休日', kind: 'citizens_holiday' });
  }
  for (const c of citizens) byDate.set(c.date, c);

  // 振替休日: 祝日が日曜に当たる場合
  //   2007年以降=その後の最も近い「休日でない日」/ 2006年以前=翌日が休日でない場合のみ
  for (const h of base) {
    if (!isSunday(h.date)) continue;
    if (year >= 2007) {
      let candidate = shiftDate(h.date, 1);
      while (byDate.has(candidate)) candidate = shiftDate(candidate, 1);
      byDate.set(candidate, { date: candidate, name: `${h.name} 振替休日`, kind: 'substitute' });
    } else {
      const candidate = shiftDate(h.date, 1);
      if (!byDate.has(candidate)) {
        byDate.set(candidate, { date: candidate, name: `${h.name} 振替休日`, kind: 'substitute' });
      }
    }
  }

  const result = [...byDate.values()]
    .filter((h) => h.date.startsWith(`${year}-`))
    .sort((a, b) => a.date.localeCompare(b.date));
  HOLIDAY_CACHE.set(year, result);
  return result;
}

/** 'YYYY-MM-DD' (ISO 日時も可) を年月日に分解。解釈できなければ null */
function parseDateParts(date: string): { y: number; m: number; d: number } | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(date ?? '').trim());
  if (!m) return null;
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const d = Number(m[3]);
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
  const check = new Date(Date.UTC(y, mo - 1, d));
  if (check.getUTCFullYear() !== y || check.getUTCMonth() + 1 !== mo || check.getUTCDate() !== d) return null;
  return { y, m: mo, d };
}

/**
 * 祝日判定の詳細 (例外を投げない版)。
 * 算出できない場合は holiday=null / supported=false を返す (=「平日」と答えない)。
 */
export function getHolidayInfo(date: string): HolidayInfo {
  const key = String(date ?? '').slice(0, 10);
  const parts = parseDateParts(key);
  if (!parts) {
    return {
      date: key, supported: false, holiday: null, name: null, kind: null,
      reason: `日付として解釈できないため祝日を判定できません (期待形式: YYYY-MM-DD / 入力: ${String(date)})`,
    };
  }
  if (parts.y < JP_HOLIDAY_CALC_MIN_YEAR || parts.y > JP_HOLIDAY_CALC_MAX_YEAR) {
    return {
      date: key, supported: false, holiday: null, name: null, kind: null,
      reason: `${parts.y} 年は祝日の算出対象外です (算出可能な範囲は ${JP_HOLIDAY_CALC_MIN_YEAR}〜${JP_HOLIDAY_CALC_MAX_YEAR} 年)`,
    };
  }
  const hit = computeJapaneseHolidays(parts.y).find((h) => h.date === key);
  return {
    date: key,
    supported: true,
    holiday: !!hit,
    name: hit?.name ?? null,
    kind: hit?.kind ?? null,
  };
}

/**
 * 祝日判定。
 * @param date 'YYYY-MM-DD'
 * @param holidays 明示的に祝日表を渡した場合はその表で判定する (従来互換)。
 *                 省略時は法律に基づく算出値で判定する。
 * @throws HolidayRangeError 表を渡さず、かつ算出範囲外/不正な日付のとき
 *         (黙って false=平日 を返すと 2026 年以降の祝日が全部平日になるため)
 */
export function isJapaneseHoliday(date: string, holidays?: { date: string }[]): boolean {
  const key = String(date ?? '').slice(0, 10);
  if (holidays) return holidays.some((h) => h.date === key);
  const info = getHolidayInfo(key);
  if (!info.supported) throw new HolidayRangeError(info.reason ?? '祝日を判定できません');
  return info.holiday === true;
}

/** 祝日名 (祝日でなければ null)。表を渡さない場合は算出値を使う */
export function holidayNameOf(date: string, holidays?: { date: string; name?: string }[]): string | null {
  const key = String(date ?? '').slice(0, 10);
  if (holidays) return holidays.find((h) => h.date === key)?.name ?? null;
  return getHolidayInfo(key).name;
}

export interface BusinessDayInfo {
  date: string;
  /** unmeasurable = 算出範囲外/不正入力で判定できない */
  status: 'business_day' | 'weekend' | 'holiday' | 'unmeasurable';
  holidayName?: string;
  reason?: string;
}

/** 営業日判定の詳細 (例外を投げない版) */
export function getBusinessDayInfo(date: string): BusinessDayInfo {
  const key = String(date ?? '').slice(0, 10);
  const parts = parseDateParts(key);
  const info = getHolidayInfo(key);
  if (!parts || !info.supported) {
    return { date: key, status: 'unmeasurable', reason: info.reason };
  }
  const dow = dayOfWeek(parts.y, parts.m, parts.d);
  if (dow === 0 || dow === 6) return { date: key, status: 'weekend' };
  if (info.holiday) return { date: key, status: 'holiday', holidayName: info.name ?? undefined };
  return { date: key, status: 'business_day' };
}

/**
 * 営業日判定 (土日・祝日・振替休日・国民の休日を除く)。
 * @throws HolidayRangeError 算出範囲外/不正な日付のとき (判定できないものを営業日と答えない)
 */
export function isBusinessDay(date: string): boolean {
  const info = getBusinessDayInfo(date);
  if (info.status === 'unmeasurable') {
    throw new HolidayRangeError(info.reason ?? `${date} は営業日を判定できません`);
  }
  return info.status === 'business_day';
}

// ============================================================================
// SLO (営業時間別)
// ============================================================================

export type SLOWindow = 'business_hours' | 'after_hours' | 'weekend' | 'holiday' | 'all_24x7';

export interface SLODefinition {
  serviceName: string;
  window: SLOWindow;
  /** 目標可用性 % (例: 99.9) */
  availabilityPct: number;
  /** 目標レイテンシ p99 (ms) */
  latencyP99Ms?: number;
  /** 目標エラー率 % */
  errorRatePct?: number;
}

export const STANDARD_SLOS: SLODefinition[] = [
  { serviceName: '基幹業務系API', window: 'business_hours', availabilityPct: 99.95, latencyP99Ms: 500, errorRatePct: 0.1 },
  { serviceName: '基幹業務系API', window: 'after_hours', availabilityPct: 99.0, latencyP99Ms: 2000, errorRatePct: 1.0 },
  { serviceName: '社内ポータル', window: 'business_hours', availabilityPct: 99.9, latencyP99Ms: 1000 },
  { serviceName: '社外公開API', window: 'all_24x7', availabilityPct: 99.95, latencyP99Ms: 800, errorRatePct: 0.1 },
  { serviceName: '夜間バッチ', window: 'after_hours', availabilityPct: 99.5 },
];

// ============================================================================
// エラーバジェット (営業日のみ計算するモード)
// ============================================================================

export interface ErrorBudgetCalc {
  serviceName: string;
  window: SLOWindow;
  totalMinutes: number;
  allowedDowntimeMinutes: number;
  consumedDowntimeMinutes: number;
  remainingBudgetMinutes: number;
  burnRate: number;
  exhausted: boolean;
}

export function calcErrorBudget(input: {
  slo: SLODefinition;
  /** 期間 (日) */
  periodDays: number;
  /** 期間内の合計ダウンタイム分 */
  consumedDowntimeMinutes: number;
  /** true: 営業日のみカウント / false: 全日 */
  businessDayOnly?: boolean;
}): ErrorBudgetCalc {
  // 1日 = 営業時間 9h or 24h
  const minutesPerDay = input.slo.window === 'business_hours' ? 9 * 60 : 24 * 60;
  let activeDays = input.periodDays;
  if (input.businessDayOnly) {
    // ざっくり 5/7 (週末除外) — 祝日まで厳密にしたい場合は呼び出し側で実日数を渡す
    activeDays = Math.round(input.periodDays * (5 / 7));
  }
  const totalMinutes = activeDays * minutesPerDay;
  const allowedDowntimeMinutes = Math.round(totalMinutes * (1 - input.slo.availabilityPct / 100));
  const remaining = allowedDowntimeMinutes - input.consumedDowntimeMinutes;
  const burnRate = allowedDowntimeMinutes === 0 ? 0 : input.consumedDowntimeMinutes / allowedDowntimeMinutes;
  return {
    serviceName: input.slo.serviceName,
    window: input.slo.window,
    totalMinutes,
    allowedDowntimeMinutes,
    consumedDowntimeMinutes: input.consumedDowntimeMinutes,
    remainingBudgetMinutes: remaining,
    burnRate: Math.round(burnRate * 1000) / 1000,
    exhausted: remaining <= 0,
  };
}

// ============================================================================
// リリース凍結カレンダー (年末年始/GW/お盆)
// ============================================================================

export interface ReleaseFreezeWindow {
  name: string;
  startDate: string;
  endDate: string;
  reason: string;
  allowEmergencyOnly: boolean;
}

/**
 * 【要年次更新】この凍結期間は 2024/2025 の固定値。
 * 凍結期間は法律ではなく各社の運用方針で決まるため自動算出していない。
 * 2026 年以降を判定したい場合は、呼び出し側で当年の期間を渡すこと
 * (渡さないと年末年始/GW/お盆の凍結判定は効かない)。
 */
export const STANDARD_RELEASE_FREEZE_WINDOWS: ReleaseFreezeWindow[] = [
  { name: '年末年始凍結', startDate: '2024-12-28', endDate: '2025-01-05', reason: '保守要員不在 + 取引先休業', allowEmergencyOnly: true },
  { name: 'GW凍結', startDate: '2025-04-29', endDate: '2025-05-06', reason: 'GW10連休対応', allowEmergencyOnly: true },
  { name: 'お盆凍結', startDate: '2025-08-11', endDate: '2025-08-15', reason: 'お盆休業', allowEmergencyOnly: true },
  { name: '月末月初', startDate: '*-*-28', endDate: '*-*-03', reason: '会計/請求処理ピーク', allowEmergencyOnly: false },
];

export function isWithinFreezeWindow(date: string, freeze: ReleaseFreezeWindow[] = STANDARD_RELEASE_FREEZE_WINDOWS): { frozen: boolean; window?: ReleaseFreezeWindow } {
  const d = new Date(date);
  for (const w of freeze) {
    if (w.startDate.includes('*')) continue; // 月末月初パターンは別ロジック
    const s = new Date(w.startDate);
    const e = new Date(w.endDate);
    if (d >= s && d <= e) return { frozen: true, window: w };
  }
  // 月末月初判定
  const dom = d.getUTCDate();
  if (dom >= 28 || dom <= 3) {
    return { frozen: true, window: freeze.find((w) => w.name === '月末月初') };
  }
  return { frozen: false };
}

// ============================================================================
// オンコール体制 (日本仕様)
// ============================================================================

export interface OncallSchedule {
  primary: string;
  secondary?: string;
  manager?: string;
  shift: 'business_hours' | 'after_hours' | 'weekend';
  date: string;
}

export function suggestOncallShift(input: {
  teamSize: number;
  isB2B: boolean;
  serviceType: 'internal' | 'customer_facing';
}): { rotation: 'weekly' | 'daily' | 'no_oncall'; recommendation: string } {
  if (input.teamSize < 3 && !input.isB2B) {
    return { rotation: 'no_oncall', recommendation: '人員不足のため、夜間障害は外部SES (NOC) 委託を推奨' };
  }
  if (input.serviceType === 'internal') {
    return { rotation: 'weekly', recommendation: '社内システムは平日日中対応、夜間障害は翌営業日対応で OK' };
  }
  return { rotation: 'daily', recommendation: '24x7 対応のため、デイリーローテーション推奨。連続出勤は2日まで' };
}

// ============================================================================
// TOIL 削減 (定型運用作業の自動化判定)
// ============================================================================

export interface ToilTask {
  taskName: string;
  /** 月あたり実施回数 */
  monthlyExecutions: number;
  /** 1回あたり所要時間 (分) */
  minutesPerExecution: number;
  /** 自動化難易度 */
  automationDifficulty: 'low' | 'medium' | 'high';
}

export function evaluateToilReduction(tasks: ToilTask[]): { task: ToilTask; monthlyMinutes: number; recommendAutomation: boolean; estimatedRoiMonths: number }[] {
  return tasks.map((t) => {
    const monthlyMinutes = t.monthlyExecutions * t.minutesPerExecution;
    const automationCostMinutes = t.automationDifficulty === 'low' ? 600 : t.automationDifficulty === 'medium' ? 2400 : 9600;
    const recommend = monthlyMinutes >= 60 && (automationCostMinutes / monthlyMinutes) <= 12;
    const roiMonths = monthlyMinutes === 0 ? Infinity : Math.round((automationCostMinutes / monthlyMinutes) * 10) / 10;
    return { task: t, monthlyMinutes, recommendAutomation: recommend, estimatedRoiMonths: roiMonths };
  });
}

export const SRE_JP_REFS = {
  CABINET_HOLIDAYS_CSV: 'https://www8.cao.go.jp/chosei/shukujitsu/syukujitsu.csv',
  GOOGLE_SRE_BOOK: 'https://sre.google/books/',
};
