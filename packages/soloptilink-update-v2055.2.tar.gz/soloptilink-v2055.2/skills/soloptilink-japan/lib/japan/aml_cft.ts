/**
 * SoloptiLinkAI Phase 45-GV1 — AML/CFT (Anti-Money Laundering / Combating Financing of Terrorism)
 *
 * 犯罪収益移転防止法 (犯収法) + FATF 第4次審査対応 + リスクベースアプローチ (RBA)。
 *
 * カバー範囲:
 *  - 取引時確認 (犯収法4条) + 厳格な顧客管理 (4条2項) + 疑わしい取引届出 (8条)
 *  - 確認記録 (6条) + 取引記録 (7条) の保存義務 (取引終了後7年間)
 *  - FATF 第4次審査 (R3年報告書 + R6再評価) — 重点改善8項目
 *  - PEPs (Politically Exposed Persons) スクリーニング
 *  - 反社チェック 5要件 (正面捜査+暴排条項+反社DB+警察連携+定期スクリーニング)
 *  - 国連制裁リスト (1267委員会, 北朝鮮, イラン) + 米国OFAC SDN List
 *  - 暗号資産交換業者の AML/CFT 義務 (資金決済法 R元改正)
 *  - 法人実質的支配者 (UBO: Ultimate Beneficial Owner) 確認 (R6.4 法人番号通知制度)
 *
 * なぜClaude Codeに作れないか:
 *   FATF 審査結果は日本固有の改善要請 (Customer Due Diligence + Beneficial Ownership) であり、
 *   特に法人番号制度との突合・反社データベース連携・PEPs リストは
 *   日本の金融機関・士業・暗号資産業者だけが必要とする情報。
 */

// ───────────────────────────────────────────────
// 型定義
// ───────────────────────────────────────────────

/** 特定事業者 (犯収法2条) — AML/CFT 義務を負う主体 */
export type SpecifiedBusiness =
  | "bank" // 銀行 (1号)
  | "credit_card" // クレジットカード (2号)
  | "money_lender" // 貸金業者 (3号)
  | "fx_dealer" // 金融商品取引業者 (4号)
  | "insurer" // 保険会社 (5号)
  | "real_estate" // 宅地建物取引業者 (12号)
  | "precious_metal" // 宝石貴金属取扱業者 (13号)
  | "lawyer" // 弁護士 (15号)
  | "judicial_scrivener" // 司法書士 (16号)
  | "tax_accountant" // 税理士 (17号)
  | "cpa" // 公認会計士 (18号)
  | "administrative_scrivener" // 行政書士 (19号)
  | "crypto_exchange" // 暗号資産交換業者 (R元改正で追加)
  | "trust_company"; // 信託会社

/** 取引時確認の対象取引 (犯収法4条1項各号) */
export type ConfirmationTarget =
  | "ordinary" // 通常の取引時確認 (新規口座開設等)
  | "high_value_cash_200" // 200万円超 現金取引 (4条1項1号 + 政令)
  | "wire_transfer_100" // 10万円超 現金振込 (4条1項2号 + 政令)
  | "ongoing"; // 継続的取引 (4条1項3号)

export type RiskLevel = "low" | "medium" | "high" | "prohibited";

/** PEPs 区分 (政府高官等) */
export type PEPsCategory =
  | "domestic_pep" // 国内PEPs
  | "foreign_pep" // 外国PEPs (4条2項 + 政令12条)
  | "international_org" // 国際機関
  | "family_or_close" // PEPs の家族・密接関係者
  | "none";

export interface CustomerProfile {
  customer_id: string;
  customer_type: "individual" | "corporate";
  full_name: string;
  full_name_kana?: string;
  date_of_birth?: string; // YYYY-MM-DD (個人)
  corporate_number?: string; // 法人番号13桁 (法人)
  address?: string;
  business_purpose?: string;
  occupation?: string;
  pep_category?: PEPsCategory;
  country: string; // ISO 3166-1 alpha-2 ("JP" 等)
  ubo?: BeneficialOwner[]; // 法人の場合の実質的支配者
  is_sanctioned?: boolean; // 制裁リスト一致
}

/** 実質的支配者 (UBO) — 25%超の議決権/出資保有者または重要影響力保有者 */
export interface BeneficialOwner {
  full_name: string;
  date_of_birth?: string;
  ownership_percent: number; // 議決権/出資保有率 (0-100)
  is_pep: boolean;
  country: string;
}

export interface TransactionContext {
  transaction_id: string;
  amount_yen: number;
  currency: string; // "JPY", "USD", etc.
  channel: "atm" | "branch" | "online" | "mobile" | "wire" | "crypto";
  is_cash: boolean;
  is_cross_border: boolean;
  destination_country?: string;
  business_relationship_age_days?: number;
}

// ───────────────────────────────────────────────
// 取引時確認 (犯収法4条)
// ───────────────────────────────────────────────

/** 確認記録の保存期間 (犯収法6条 + 規則20条) */
export const CONFIRMATION_RECORD_RETENTION_YEARS = 7;
/** 取引記録の保存期間 (犯収法7条 + 規則22条) */
export const TRANSACTION_RECORD_RETENTION_YEARS = 7;
/** 厳格な顧客管理を要する金額閾値 (政令12条1項3号) */
export const HIGH_VALUE_CASH_THRESHOLD_YEN = 2_000_000;
/** 現金振込の本人確認義務閾値 (政令7条1項) */
export const CASH_TRANSFER_THRESHOLD_YEN = 100_000;

/**
 * 取引時確認が必要かを判定 (4条1項)
 */
export function requiresConfirmation(
  ctx: TransactionContext,
  is_new_relationship: boolean,
): { required: boolean; reason: string } {
  if (is_new_relationship) return { required: true, reason: "新規取引 (4条1項柱書)" };
  if (ctx.is_cash && ctx.amount_yen > HIGH_VALUE_CASH_THRESHOLD_YEN) {
    return { required: true, reason: `現金取引 ${HIGH_VALUE_CASH_THRESHOLD_YEN}円超 (政令12条1項3号)` };
  }
  if (ctx.is_cash && ctx.channel === "wire" && ctx.amount_yen > CASH_TRANSFER_THRESHOLD_YEN) {
    return { required: true, reason: `現金振込 ${CASH_TRANSFER_THRESHOLD_YEN}円超 (政令7条1項)` };
  }
  return { required: false, reason: "確認不要 (継続的取引かつ閾値以下)" };
}

/**
 * 厳格な顧客管理 (Enhanced Due Diligence) 要否判定 — 犯収法4条2項
 */
export function requiresEnhancedDueDiligence(
  customer: CustomerProfile,
  ctx: TransactionContext,
): { eddRequired: boolean; reasons: string[] } {
  const reasons: string[] = [];
  if (customer.pep_category === "foreign_pep") reasons.push("外国PEPs (4条2項3号 + 政令12条)");
  if (customer.pep_category === "family_or_close") reasons.push("外国PEPsの家族・密接関係者 (4条2項3号)");
  if (customer.is_sanctioned) reasons.push("制裁リスト該当 (国連/OFAC/外為法)");
  if (customer.country && HIGH_RISK_COUNTRIES.includes(customer.country)) {
    reasons.push(`ハイリスク国: ${customer.country} (FATF Call for Action)`);
  }
  if (ctx.destination_country && HIGH_RISK_COUNTRIES.includes(ctx.destination_country)) {
    reasons.push(`送金先がハイリスク国: ${ctx.destination_country}`);
  }
  if (ctx.is_cross_border && ctx.amount_yen > HIGH_VALUE_CASH_THRESHOLD_YEN) {
    reasons.push("国際送金 200万円超");
  }
  if (customer.customer_type === "corporate") {
    const hasHighOwnership = (customer.ubo ?? []).some((u) => u.ownership_percent >= 25);
    if (!hasHighOwnership) reasons.push("実質的支配者 (UBO) 25%超不在 — UBO 確認強化必要");
  }
  return { eddRequired: reasons.length > 0, reasons };
}

// ───────────────────────────────────────────────
// 疑わしい取引届出 (犯収法8条) — STR/SAR
// ───────────────────────────────────────────────

/** 疑わしい取引の典型類型 (金融庁ガイドライン + JAFIC 参考事例) */
export type SuspiciousActivityType =
  | "structuring" // 分割入金 (200万円閾値直下を繰り返す)
  | "unusual_cash" // 業態に不相応な現金取引
  | "rapid_movement" // 受け入れ後すぐ第三者へ送金
  | "geographic_anomaly" // 取引相手国がハイリスク
  | "beneficial_owner_obscured" // UBO の意図的な不開示
  | "shell_company" // ペーパーカンパニーの可能性
  | "pep_anomaly" // PEPs による説明不能な取引
  | "sanctions_evasion" // 制裁回避手法 (船舶名変更, 第三国経由)
  | "trade_based_ml" // 貿易を装ったマネロン (TBML)
  | "crypto_layering" // 暗号資産による多段ウォレット移動
  | "false_documentation"; // 虚偽書類の提出

export interface SuspiciousActivityReport {
  report_id: string;
  customer_id: string;
  transaction_id?: string;
  activity_types: SuspiciousActivityType[];
  total_amount_yen: number;
  detection_date: string;
  filed_to_jafic: boolean; // JAFIC (警察庁刑事局組織犯罪対策部) への届出済か
  filed_at?: string;
  narrative: string;
}

/**
 * 疑わしい取引のスコアリング (簡易版)
 * 30点以上で SAR 推奨、60点以上で SAR 必須
 */
export function scoreSuspicion(types: SuspiciousActivityType[], ctx: TransactionContext): {
  score: number;
  recommendation: "no_action" | "monitor" | "file_str";
} {
  const weights: Record<SuspiciousActivityType, number> = {
    structuring: 35,
    unusual_cash: 25,
    rapid_movement: 30,
    geographic_anomaly: 35,
    beneficial_owner_obscured: 40,
    shell_company: 45,
    pep_anomaly: 30,
    sanctions_evasion: 70, // 即座に SAR 必須
    trade_based_ml: 35,
    crypto_layering: 40,
    false_documentation: 50,
  };
  let score = types.reduce((s, t) => s + (weights[t] ?? 0), 0);
  if (ctx.amount_yen >= 10_000_000) score += 10;
  if (ctx.is_cross_border) score += 5;
  const recommendation = score >= 60 ? "file_str" : score >= 30 ? "monitor" : "no_action";
  return { score, recommendation };
}

// ───────────────────────────────────────────────
// FATF 第4次審査 (Mutual Evaluation Report)
// ───────────────────────────────────────────────

/**
 * 日本の FATF 第4次審査 (R3.8.30 公表) で重点改善要請を受けた8項目
 * R6 再評価 (Follow-up) で半数が "Largely Compliant" に改善見込
 */
export const FATF_4TH_PRIORITY_ITEMS: Array<{
  recommendation_no: number;
  topic: string;
  rating_2021: "C" | "LC" | "PC" | "NC"; // Compliant/Largely/Partially/Non
  jp_action: string;
}> = [
  { recommendation_no: 10, topic: "Customer Due Diligence", rating_2021: "PC", jp_action: "犯収法 R6改正で UBO 強化" },
  { recommendation_no: 11, topic: "Record Keeping", rating_2021: "LC", jp_action: "7年保存徹底" },
  { recommendation_no: 12, topic: "PEPs", rating_2021: "PC", jp_action: "外国PEPsスクリーニングDB整備" },
  { recommendation_no: 22, topic: "DNFBPs (士業/不動産/宝石)", rating_2021: "PC", jp_action: "士業会の実務指針強化" },
  { recommendation_no: 24, topic: "Beneficial Ownership of Legal Persons", rating_2021: "PC", jp_action: "法人番号通知制度 R6.4" },
  { recommendation_no: 28, topic: "Regulation of DNFBPs", rating_2021: "PC", jp_action: "監督指針強化" },
  { recommendation_no: 35, topic: "Sanctions", rating_2021: "PC", jp_action: "外為法制裁の即時履行体制" },
  { recommendation_no: 38, topic: "Mutual Legal Assistance", rating_2021: "LC", jp_action: "国際刑事共助の迅速化" },
];

/**
 * リスクベースアプローチ (RBA) — 4軸でリスク評価
 * 各軸 1-5 のスコアで合計を算出
 */
export interface RbaRiskScore {
  country_risk: number; // 1-5
  customer_risk: number; // 1-5
  product_risk: number; // 1-5
  channel_risk: number; // 1-5
}

export function calcRbaRisk(s: RbaRiskScore): { total: number; level: RiskLevel } {
  const total = s.country_risk + s.customer_risk + s.product_risk + s.channel_risk;
  const level: RiskLevel =
    total >= 17 ? "prohibited" : total >= 13 ? "high" : total >= 9 ? "medium" : "low";
  return { total, level };
}

// ───────────────────────────────────────────────
// 制裁リスト + ハイリスク国
// ───────────────────────────────────────────────

/** FATF Call for Action 国 (R6 時点) — DPRK/イラン/ミャンマー */
export const HIGH_RISK_COUNTRIES = ["KP", "IR", "MM"] as const;

/** FATF Increased Monitoring 国 (Grey List) - 主要なもの (R6.10 時点参考) */
export const FATF_GREY_LIST_COUNTRIES = [
  "AL", "BB", "BF", "CM", "HR", "CG", "JM", "ML",
  "MZ", "NG", "PH", "SN", "SS", "SY", "TR", "UG", "VN", "YE",
] as const;

/** 国連制裁リスト分類 */
export type SanctionsList =
  | "un_1267_isil_aq" // ISIL (Da'esh) Al-Qaida (1267)
  | "un_1718_dprk" // DPRK
  | "un_2231_iran" // Iran
  | "ofac_sdn" // OFAC SDN
  | "ofac_consolidated" // OFAC Consolidated
  | "uk_hmt" // UK HMT Financial Sanctions
  | "eu_consolidated" // EU Consolidated
  | "moftee_jp"; // 日本 外為法 25/48条 (財務省)

export interface SanctionsHit {
  list: SanctionsList;
  matched_name: string;
  match_score: number; // 0-100 (Levenshtein/Jaro-Winkler)
  comment?: string;
}

/**
 * 制裁スクリーニング判定
 * match_score >= 85 で確実な hit、70-84 でレビュー、それ以下は false-positive
 */
export function evaluateSanctionsHit(hits: SanctionsHit[]): {
  blocked: boolean;
  review: boolean;
  reasons: string[];
} {
  const blocked = hits.some((h) => h.match_score >= 85);
  const review = hits.some((h) => h.match_score >= 70 && h.match_score < 85);
  const reasons = hits
    .filter((h) => h.match_score >= 70)
    .map((h) => `${h.list} ${h.matched_name} (score=${h.match_score})`);
  return { blocked, review, reasons };
}

// ───────────────────────────────────────────────
// 反社チェック 5要件 (暴力団排除条例 + 全銀協 暴排ガイドライン)
// ───────────────────────────────────────────────

export interface AntisocialCheck {
  frontline_screening: boolean; // 1) 反社DB初期照合
  exclusion_clause_signed: boolean; // 2) 暴排条項の同意取得
  database_match: boolean; // 3) 業界DB (全銀協/JBA/警察庁データベース) 照合
  police_consultation: boolean; // 4) 警察庁/暴追センター 照会
  periodic_rescreening: boolean; // 5) 定期再スクリーニング (年次推奨)
}

export function evaluateAntisocialCheck(c: AntisocialCheck): {
  passed: boolean;
  missing: string[];
} {
  const missing: string[] = [];
  if (!c.frontline_screening) missing.push("正面捜査 (反社DB初期照合)");
  if (!c.exclusion_clause_signed) missing.push("暴排条項 (反社会的勢力排除条項) 同意");
  if (!c.database_match) missing.push("業界DB (全銀協/警察庁) 照合");
  if (!c.police_consultation) missing.push("警察庁/暴追センター 照会");
  if (!c.periodic_rescreening) missing.push("定期再スクリーニング (年次)");
  return { passed: missing.length === 0, missing };
}

// ───────────────────────────────────────────────
// 暗号資産交換業者の AML/CFT (資金決済法 R元改正)
// ───────────────────────────────────────────────

/**
 * Travel Rule (FATF Rec.16): 暗号資産送金時に送金人/受取人情報を伝達
 * 日本では JVCEA 自主規制で 30万円超の送金から義務化 (R5.6)
 */
export const CRYPTO_TRAVEL_RULE_THRESHOLD_YEN = 300_000;

export interface CryptoTransferContext {
  amount_yen_equiv: number;
  asset: string; // BTC/ETH/USDT etc
  originator_known: boolean;
  beneficiary_vasp_known: boolean; // 受取側 VASP (Virtual Asset Service Provider) 確認済か
}

export function requiresTravelRule(c: CryptoTransferContext): {
  required: boolean;
  missing: string[];
} {
  const required = c.amount_yen_equiv >= CRYPTO_TRAVEL_RULE_THRESHOLD_YEN;
  const missing: string[] = [];
  if (required) {
    if (!c.originator_known) missing.push("送金人情報 (originator)");
    if (!c.beneficiary_vasp_known) missing.push("受取VASP情報");
  }
  return { required, missing };
}
