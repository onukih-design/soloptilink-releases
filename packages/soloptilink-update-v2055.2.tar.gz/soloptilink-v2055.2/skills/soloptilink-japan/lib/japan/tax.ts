/**
 * 消費税・源泉徴収計算ユーティリティ
 */

export type TaxRate = 'standard' | 'reduced' | 'exempt' | 'nontaxable';

/**
 * 消費税額の計算 (税抜→税込 / 税込→税抜)
 */
export function calcTax(
  amount: number,
  rate: TaxRate,
  mode: 'exclusive' | 'inclusive' = 'exclusive'
): { base: number; tax: number; total: number } {
  const rateValue = rate === 'standard' ? 0.10 : rate === 'reduced' ? 0.08 : 0;
  if (mode === 'exclusive') {
    const tax = Math.floor(amount * rateValue);
    return { base: amount, tax, total: amount + tax };
  } else {
    const base = Math.floor(amount / (1 + rateValue));
    const tax = amount - base;
    return { base, tax, total: amount };
  }
}

/**
 * 源泉徴収税額の計算 (個人事業主・フリーランス向け)
 *
 * - デザイン・原稿料・講演料等: 100万円以下 → 10.21% / 100万円超 → (額-100万)×20.42%+102,100円
 * - 司法書士等: 1万円控除後 × 10.21%
 * - ホステス等: 控除後 × 10.21%
 */
export function calcWithholdingTax(
  amount: number,
  type: 'creative' | 'judicial' | 'hostess'
): { withholding: number; netPayment: number } {
  let withholding = 0;
  if (type === 'creative') {
    if (amount <= 1_000_000) withholding = Math.floor(amount * 0.1021);
    else withholding = Math.floor((amount - 1_000_000) * 0.2042 + 102_100);
  } else if (type === 'judicial') {
    withholding = Math.floor(Math.max(0, amount - 10_000) * 0.1021);
  } else if (type === 'hostess') {
    const deduction = 5_000; // 日額控除
    withholding = Math.floor(Math.max(0, amount - deduction) * 0.1021);
  }
  return { withholding, netPayment: amount - withholding };
}

/**
 * 給与所得者の源泉徴収 (月額表・簡易版, 実運用では国税庁の月額表を参照)
 */
export function calcSalaryWithholding(monthlySalary: number, dependents: number): number {
  // 簡易計算: 社会保険料概算を15%と仮定
  const socialInsurance = monthlySalary * 0.15;
  const taxable = monthlySalary - socialInsurance;
  // 扶養控除1人あたり約1,700円控除
  const base =
    taxable <= 88_000 ? 0 :
    taxable <= 100_000 ? 200 :
    taxable <= 150_000 ? 800 :
    taxable <= 250_000 ? (taxable - 150_000) * 0.05 + 800 :
    taxable <= 500_000 ? (taxable - 250_000) * 0.10 + 5_800 :
    (taxable - 500_000) * 0.20 + 30_800;
  return Math.max(0, Math.floor(base - dependents * 1_700));
}

/**
 * インボイス方式の税率別集計
 */
export function summarizeByRate(
  items: Array<{ amount: number; rate: TaxRate }>
): Record<TaxRate, { subtotal: number; tax: number }> {
  const summary: Record<TaxRate, { subtotal: number; tax: number }> = {
    standard: { subtotal: 0, tax: 0 },
    reduced: { subtotal: 0, tax: 0 },
    exempt: { subtotal: 0, tax: 0 },
    nontaxable: { subtotal: 0, tax: 0 },
  };
  for (const it of items) {
    summary[it.rate].subtotal += it.amount;
  }
  summary.standard.tax = Math.floor(summary.standard.subtotal * 0.10);
  summary.reduced.tax = Math.floor(summary.reduced.subtotal * 0.08);
  return summary;
}
