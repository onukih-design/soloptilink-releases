/**
 * SoloptiLinkAI Phase 44-IP — 特許 (Patent)
 *
 * 特許法 + PCT国際出願 + 日本特許庁 (JPO) 業務支援。
 *
 * カバー範囲:
 *  - 特許要件 (発明性 + 産業上の利用可能性 + 新規性 + 進歩性 + 先願)
 *  - 出願手続 (出願→方式審査→出願公開18ヶ月→出願審査請求3年→実体審査→査定)
 *  - 拒絶理由通知 + 意見書/補正書
 *  - 特許権設定登録 + 存続期間 (出願日から20年)
 *  - 維持年金 (1〜3年/4〜6年/7〜9年/10〜25年 累進)
 *  - PCT 国際出願 (優先日から30/31ヶ月以内に各国移行)
 *  - パリ条約優先権 (12ヶ月以内)
 *  - 特許侵害判定 (文言侵害 + 均等侵害)
 *  - 職務発明 (特許法35条 R3.4施行)
 */

export type PatentApplicationStatus =
  | "filed" // 出願済
  | "formality_review" // 方式審査
  | "published" // 出願公開 (18ヶ月)
  | "request_for_examination" // 出願審査請求
  | "under_examination" // 実体審査中
  | "office_action" // 拒絶理由通知
  | "amendment_filed" // 補正書提出
  | "allowed" // 特許査定
  | "rejected" // 拒絶査定
  | "appeal" // 拒絶査定不服審判
  | "registered" // 特許権設定登録
  | "abandoned" // 放棄
  | "expired" // 存続期間満了
  | "invalidated"; // 無効

export interface PatentApplication {
  application_no: string; // 特願2024-123456
  publication_no?: string; // 特開2026-098765 (出願公開後)
  registration_no?: string; // 特許第7,654,321号 (登録後)
  title: string;
  applicant: string;
  inventor: string[];
  filing_date: string;
  priority_date?: string; // パリ条約優先権主張時
  priority_country?: string;
  publication_date?: string;
  exam_request_date?: string;
  registration_date?: string;
  expiry_date?: string;
  status: PatentApplicationStatus;
  ipc_classification?: string[]; // 国際特許分類 (G06F/H04L等)
}

// 特許要件チェック (29条)
export interface PatentabilityCheck {
  is_invention: boolean; // 自然法則の利用 + 技術的思想の創作
  industrial_applicability: boolean; // 産業上利用可能
  novelty: boolean; // 新規性 (29条1項)
  inventive_step: boolean; // 進歩性 (29条2項)
  first_to_file: boolean; // 先願 (39条)
  not_excluded: boolean; // 不特許事由なし (32条 公序良俗等)
}

export function evaluatePatentability(check: PatentabilityCheck): {
  patentable: boolean;
  rejection_reasons: string[];
} {
  const reasons: string[] = [];
  if (!check.is_invention) reasons.push("発明該当性なし (特許法2条1項) - 単なる発見/数学公式/人為的取り決めは不可");
  if (!check.industrial_applicability) reasons.push("産業上利用可能性なし (29条1項柱書) - 個人的/学術的/医療行為のみは不可");
  if (!check.novelty) reasons.push("新規性なし (29条1項各号) - 公知/公用/刊行物記載");
  if (!check.inventive_step) reasons.push("進歩性なし (29条2項) - 当業者が容易に発明できた");
  if (!check.first_to_file) reasons.push("先願に劣後 (39条)");
  if (!check.not_excluded) reasons.push("不特許事由 (32条 公序良俗反 / 公衆衛生害)");
  return { patentable: reasons.length === 0, rejection_reasons: reasons };
}

// 出願公開・審査請求の期限管理
export const PUBLICATION_MONTHS = 18;
export const EXAMINATION_REQUEST_YEARS = 3;
export const PATENT_TERM_YEARS = 20;

export interface PatentDeadlines {
  publication_due: string;
  examination_request_due: string;
  expiry_date: string;
}

export function calcPatentDeadlines(filingDate: string): PatentDeadlines {
  const filing = new Date(filingDate);
  const pub = new Date(filing);
  pub.setMonth(pub.getMonth() + PUBLICATION_MONTHS);
  const exam = new Date(filing);
  exam.setFullYear(exam.getFullYear() + EXAMINATION_REQUEST_YEARS);
  const expiry = new Date(filing);
  expiry.setFullYear(expiry.getFullYear() + PATENT_TERM_YEARS);
  return {
    publication_due: pub.toISOString().slice(0, 10),
    examination_request_due: exam.toISOString().slice(0, 10),
    expiry_date: expiry.toISOString().slice(0, 10),
  };
}

// 維持年金 (特許料 - 累進制)
export const MAINTENANCE_FEES_R6: { year_range: [number, number]; per_year_jpy: number; per_claim_jpy: number }[] = [
  { year_range: [1, 3], per_year_jpy: 4_300, per_claim_jpy: 300 },
  { year_range: [4, 6], per_year_jpy: 10_300, per_claim_jpy: 800 },
  { year_range: [7, 9], per_year_jpy: 24_800, per_claim_jpy: 1_900 },
  { year_range: [10, 25], per_year_jpy: 59_400, per_claim_jpy: 4_600 },
];

export function calcMaintenanceFee(year: number, claimsCount: number): number {
  if (year < 1 || year > PATENT_TERM_YEARS) return 0;
  const tier = MAINTENANCE_FEES_R6.find(([t]) => year >= t.year_range[0] && year <= t.year_range[1]);
  // 構造修正
  const found = MAINTENANCE_FEES_R6.find((t) => year >= t.year_range[0] && year <= t.year_range[1]);
  if (!found) return 0;
  return found.per_year_jpy + claimsCount * found.per_claim_jpy;
}

// PCT 国際出願 (国際移行期限)
export type PctMemberCountry = "JP" | "US" | "EP" | "CN" | "KR" | "DE" | "GB" | "FR" | "AU" | "CA";

export interface PctTimeline {
  international_filing_date: string;
  priority_date: string;
  international_publication_due: string; // 18ヶ月
  national_phase_deadline: { country: PctMemberCountry; deadline: string }[];
}

const NATIONAL_PHASE_MONTHS: Record<PctMemberCountry, number> = {
  JP: 30, US: 30, EP: 31, CN: 30, KR: 31, DE: 30, GB: 31, FR: 30, AU: 31, CA: 30,
};

export function calcPctNationalPhase(priorityDate: string, internationalFilingDate: string): PctTimeline {
  const priority = new Date(priorityDate);
  const intlPub = new Date(priority);
  intlPub.setMonth(intlPub.getMonth() + 18);
  const nationalDeadlines = (Object.keys(NATIONAL_PHASE_MONTHS) as PctMemberCountry[]).map((country) => {
    const dl = new Date(priority);
    dl.setMonth(dl.getMonth() + NATIONAL_PHASE_MONTHS[country]);
    return { country, deadline: dl.toISOString().slice(0, 10) };
  });
  return {
    international_filing_date: internationalFilingDate,
    priority_date: priorityDate,
    international_publication_due: intlPub.toISOString().slice(0, 10),
    national_phase_deadline: nationalDeadlines,
  };
}

// パリ条約優先権 (12ヶ月以内)
export function isPrioirtyClaimValid(firstFilingDate: string, secondFilingDate: string): boolean {
  const first = new Date(firstFilingDate);
  const limit = new Date(first);
  limit.setMonth(limit.getMonth() + 12);
  return new Date(secondFilingDate) <= limit;
}

// 特許侵害判定
export interface InfringementClaim {
  patent_claim: string; // 特許請求の範囲
  defendant_product: string; // 被疑侵害品
  literal_match: boolean; // 文言侵害
  equivalent_match?: { all_5_requirements_met: boolean; analysis: string }; // 均等侵害
  defenses?: ("research_exemption" | "experimental_use" | "first_sale" | "expiry" | "invalidity")[];
}

// 均等侵害の5要件 (最高裁H10.2.24 ボールスプライン事件)
export const EQUIVALENT_INFRINGEMENT_REQUIREMENTS = [
  "1. 構成要件の差異が本質的部分でない",
  "2. 置換可能性 (作用効果同一)",
  "3. 置換容易性 (当業者が侵害行為時容易)",
  "4. 公知技術と同一/容易ではない",
  "5. 意識的除外 (出願経過で除外していない)",
] as const;

export function evaluateInfringement(claim: InfringementClaim): {
  infringes: boolean;
  basis: "literal" | "equivalent" | "none";
  defenses_applied: string[];
} {
  if (claim.defenses?.includes("expiry") || claim.defenses?.includes("invalidity")) {
    return { infringes: false, basis: "none", defenses_applied: claim.defenses };
  }
  if (claim.literal_match) {
    return { infringes: true, basis: "literal", defenses_applied: claim.defenses ?? [] };
  }
  if (claim.equivalent_match?.all_5_requirements_met) {
    return { infringes: true, basis: "equivalent", defenses_applied: claim.defenses ?? [] };
  }
  return { infringes: false, basis: "none", defenses_applied: claim.defenses ?? [] };
}

// 職務発明 (特許法35条 R3.4施行)
export interface EmployeeInvention {
  inventor_employee_id: string;
  invention_id: string;
  invention_date: string;
  is_within_scope_of_duties: boolean; // 職務範囲内
  is_developed_by_employer_resources: boolean; // 会社設備使用
  has_prior_assignment_clause: boolean; // 事前承継規定あり
}

export interface JobInventionResolution {
  belongs_to: "employer" | "employee";
  reasonable_compensation_required: boolean; // 相当の利益
  notes: string[];
}

export function classifyEmployeeInvention(inv: EmployeeInvention): JobInventionResolution {
  const notes: string[] = [];
  // 職務発明: 職務範囲 + 会社資源
  const isJobInvention = inv.is_within_scope_of_duties && inv.is_developed_by_employer_resources;
  if (!isJobInvention) {
    notes.push("非職務発明 (自由発明) - 従業員に原始帰属");
    return { belongs_to: "employee", reasonable_compensation_required: false, notes };
  }
  // 職務発明 + 事前承継規定あり → R3.4施行で原始的に使用者帰属
  if (inv.has_prior_assignment_clause) {
    notes.push("職務発明 + 事前承継規定 → 特許法35条3項により原始的に使用者帰属");
    notes.push("相当の利益 (35条4項): 金銭/留学/昇進等の経済的利益が必要");
    return { belongs_to: "employer", reasonable_compensation_required: true, notes };
  }
  // 規定なし → 従業員帰属だが、使用者は通常実施権あり
  notes.push("職務発明 + 規定なし → 従業員帰属 / 使用者は通常実施権 (35条1項)");
  return { belongs_to: "employee", reasonable_compensation_required: false, notes };
}
