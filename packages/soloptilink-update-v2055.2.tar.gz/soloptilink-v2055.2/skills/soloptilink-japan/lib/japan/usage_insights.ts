/**
 * SoloptiLinkAI Phase 16 — Usage Insights Engine
 *
 * 顧客の利用パターンを横断分析し、
 *  - どの業種でどのモジュールが頻出か
 *  - どのフェーズで時間を消費しているか
 *  - どのフックがブロッカーになっているか
 * を可視化する。
 *
 * 学習データ (sessions / strategy_scores / quality scores) を入力に、
 * 顧客個別チューニングのための行動可能なインサイトを返す。
 */

import type { SessionRollup, StrategyRecord, ErrorPattern } from "./learning_analytics.ts";

export interface ModuleUsage {
  module: string;
  total_sessions: number;
  domains: Record<string, number>;
  trend_30d: "rising" | "flat" | "declining";
}

export interface PhaseTiming {
  phase: string;
  avg_duration_ms: number;
  p95_duration_ms: number;
  sample_count: number;
  flagged_slow: boolean;
}

export interface HookBlocker {
  hook: string;
  block_count: number;
  unblock_strategy?: string;
}

export interface UsageInsight {
  module_usage: ModuleUsage[];
  phase_timings: PhaseTiming[];
  hook_blockers: HookBlocker[];
  underused_modules: string[];
  candidates_for_promotion: string[];
}

const SLOW_PHASE_THRESHOLD_MS = 60_000;

export function summarizeModuleUsage(sessions: SessionRollup[]): ModuleUsage[] {
  const agg = new Map<string, ModuleUsage>();
  const recentCutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;
  const recentCount = new Map<string, number>();
  const olderCount = new Map<string, number>();

  for (const s of sessions) {
    const ts = Date.parse(s.ts);
    const isRecent = !Number.isNaN(ts) && ts >= recentCutoff;
    for (const m of s.modules_used ?? []) {
      const cur = agg.get(m) ?? {
        module: m,
        total_sessions: 0,
        domains: {},
        trend_30d: "flat",
      };
      cur.total_sessions += 1;
      const dom = s.domain ?? "unknown";
      cur.domains[dom] = (cur.domains[dom] ?? 0) + 1;
      agg.set(m, cur);
      if (isRecent) recentCount.set(m, (recentCount.get(m) ?? 0) + 1);
      else olderCount.set(m, (olderCount.get(m) ?? 0) + 1);
    }
  }

  for (const u of agg.values()) {
    const recent = recentCount.get(u.module) ?? 0;
    const older = olderCount.get(u.module) ?? 0;
    if (recent > older * 1.3) u.trend_30d = "rising";
    else if (recent < older * 0.7) u.trend_30d = "declining";
    else u.trend_30d = "flat";
  }

  return [...agg.values()].sort((a, b) => b.total_sessions - a.total_sessions);
}

export interface PhaseLog {
  phase: string;
  duration_ms: number;
  ts?: string;
}

export function summarizePhaseTimings(logs: PhaseLog[]): PhaseTiming[] {
  const byPhase = new Map<string, number[]>();
  for (const l of logs) {
    if (!Number.isFinite(l.duration_ms) || l.duration_ms < 0) continue;
    const cur = byPhase.get(l.phase) ?? [];
    cur.push(l.duration_ms);
    byPhase.set(l.phase, cur);
  }
  const out: PhaseTiming[] = [];
  for (const [phase, arr] of byPhase) {
    const sorted = [...arr].sort((a, b) => a - b);
    const avg = sorted.reduce((a, b) => a + b, 0) / sorted.length;
    const p95Index = Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95));
    const p95 = sorted[p95Index];
    out.push({
      phase,
      avg_duration_ms: Math.round(avg),
      p95_duration_ms: Math.round(p95),
      sample_count: sorted.length,
      flagged_slow: avg >= SLOW_PHASE_THRESHOLD_MS,
    });
  }
  return out.sort((a, b) => b.avg_duration_ms - a.avg_duration_ms);
}

export interface HookEvent {
  hook: string;
  outcome: "blocked" | "passed";
  resolution?: string;
}

export function summarizeHookBlockers(events: HookEvent[]): HookBlocker[] {
  const agg = new Map<string, HookBlocker>();
  for (const e of events) {
    if (e.outcome !== "blocked") continue;
    const cur = agg.get(e.hook) ?? { hook: e.hook, block_count: 0 };
    cur.block_count += 1;
    if (e.resolution && !cur.unblock_strategy) cur.unblock_strategy = e.resolution;
    agg.set(e.hook, cur);
  }
  return [...agg.values()].sort((a, b) => b.block_count - a.block_count);
}

const ALL_LIB_MODULES = [
  "architecture", "bcp", "bug_prevention", "case_law", "compliance_ledger",
  "drawings", "eseal", "estimates", "excel_pivot", "fax_ocr", "finance",
  "i18n", "incident", "intent_compiler", "kana", "keigo", "knowledge_index",
  "law_tracker", "laws", "laws_extended", "longterm_care", "medical",
  "observability", "pattern_library", "postal", "public_sector", "regional_laws",
  "ringi", "save_guarantee", "security_audit", "sre_jp", "tax",
  "visual_confirm", "wareki", "workflow_engine",
  // Phase 16
  "learning_analytics", "usage_insights", "feature_recommender",
  "hr_payroll", "marketing_compliance", "customer_journey",
];

export function deriveUnderusedModules(usage: ModuleUsage[]): string[] {
  const used = new Set(usage.map((u) => u.module));
  return ALL_LIB_MODULES.filter((m) => !used.has(m));
}

export function buildUsageInsight(
  sessions: SessionRollup[],
  phaseLogs: PhaseLog[],
  hookEvents: HookEvent[],
): UsageInsight {
  const module_usage = summarizeModuleUsage(sessions);
  const phase_timings = summarizePhaseTimings(phaseLogs);
  const hook_blockers = summarizeHookBlockers(hookEvents);
  const underused = deriveUnderusedModules(module_usage);
  const candidates_for_promotion = module_usage
    .filter((u) => u.trend_30d === "rising")
    .slice(0, 5)
    .map((u) => u.module);
  return {
    module_usage,
    phase_timings,
    hook_blockers,
    underused_modules: underused,
    candidates_for_promotion,
  };
}

export function topDomainsForModule(usage: ModuleUsage, top = 3): { domain: string; count: number }[] {
  return Object.entries(usage.domains)
    .map(([domain, count]) => ({ domain, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, top);
}

export function correlateModulesAndErrors(
  sessions: SessionRollup[],
  errors: ErrorPattern[],
): { module: string; correlated_errors: string[] }[] {
  const moduleToDomains = new Map<string, Set<string>>();
  for (const s of sessions) {
    for (const m of s.modules_used ?? []) {
      const set = moduleToDomains.get(m) ?? new Set<string>();
      if (s.domain) set.add(s.domain);
      moduleToDomains.set(m, set);
    }
  }
  const out: { module: string; correlated_errors: string[] }[] = [];
  for (const [module, domains] of moduleToDomains) {
    const correlated = errors
      .filter((e) => domains.has(e.domain) && e.fix_success_rate < 50)
      .map((e) => e.error_type);
    if (correlated.length > 0) out.push({ module, correlated_errors: correlated });
  }
  return out;
}

export function strategySuccessByModule(
  sessions: SessionRollup[],
  strategies: StrategyRecord[],
): Record<string, { success: number; failure: number; success_rate: number }> {
  const sessionByModule = new Map<string, SessionRollup[]>();
  for (const s of sessions) {
    for (const m of s.modules_used ?? []) {
      const arr = sessionByModule.get(m) ?? [];
      arr.push(s);
      sessionByModule.set(m, arr);
    }
  }
  const out: Record<string, { success: number; failure: number; success_rate: number }> = {};
  for (const [module] of sessionByModule) {
    const matched = strategies.filter((str) => str.key.includes(module));
    const success = matched.filter((s) => s.result === "success").length;
    const failure = matched.filter((s) => s.result === "failure").length;
    const total = success + failure;
    out[module] = {
      success,
      failure,
      success_rate: total === 0 ? 0 : Number((success / total).toFixed(3)),
    };
  }
  return out;
}
