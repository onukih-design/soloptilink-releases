/**
 * SoloptiLinkAI Phase 45 — ビジネスと人権 / 人権デューデリジェンス対応
 *
 * 国連指導原則 (UNGP 2011) + 経済産業省「責任あるサプライチェーン等における人権尊重の
 * ためのガイドライン」(R4.9) + 政府「サプライチェーンの人権・環境デューデリジェンス
 * 推進法 (検討中)」 + EU CSDDD (2024年7月発効) + 紛争鉱物 (Dodd-Frank 1502条) を統合。
 *
 * カバー範囲:
 *  - UNGP 3 pillars (Protect / Respect / Remedy)
 *  - 人権方針 (Human Rights Policy) の策定
 *  - 人権 DD プロセス (特定 → 評価 → 是正 → 追跡 → 開示 + 苦情処理メカニズム)
 *  - サプライチェーン人権リスク (児童労働 / 強制労働 / ハラスメント / 結社の自由)
 *  - 紛争鉱物 (3TG: タンタル/錫/タングステン/金 + コバルト)
 *  - 米国 UFLPA (新疆ウイグル強制労働防止法 2022) / EU 強制労働品禁止規則 (2024)
 *  - 国内ハラスメント (パワハラ防止法 R4.4 + マタハラ・セクハラ・ジェンダー)
 *  - 苦情処理メカニズム (Operational-Level Grievance Mechanism)
 */

export type HumanRightsRiskCategory =
  | "child_labor" // 児童労働
  | "forced_labor" // 強制労働
  | "discrimination" // 差別
  | "harassment_pwh" // パワハラ
  | "harassment_sxh" // セクハラ
  | "harassment_mtn" // マタハラ
  | "freedom_of_association" // 結社の自由
  | "wage_below_minimum" // 最低賃金未満
  | "excessive_working_hours" // 長時間労働
  | "occupational_safety" // 労働安全衛生
  | "privacy_data" // プライバシー
  | "indigenous_rights" // 先住民権利
  | "land_rights" // 土地権
  | "vulnerable_workers"; // 技能実習生・外国人労働者

export interface SupplyChainTier {
  tier: 0 | 1 | 2 | 3; // 0=自社 / 1=直接 / 2=二次 / 3=三次以下
  supplier_id: string;
  supplier_name: string;
  country: string; // ISO 3166 alpha-2
  industry: string;
  high_risk_country?: boolean;
  audited_at?: string;
  identified_risks: HumanRightsRiskCategory[];
}

export interface HrDdFinding {
  rule: string;
  category?: HumanRightsRiskCategory;
  severity: "info" | "watch" | "warning" | "violation" | "remediation_required";
  hint: string;
}

/** 高リスク国 (US Dept of Labor TVPRA + 米国UFLPA + Walk Free GSI 等を統合した目安) */
const HIGH_RISK_COUNTRIES = new Set([
  "CN-XJ", // 新疆ウイグル
  "MM", // ミャンマー
  "KP", // 北朝鮮
  "AF", // アフガニスタン
  "BD", // バングラデシュ
  "IN", // インド (建設・繊維)
  "PK", // パキスタン
  "ID", // インドネシア
  "VN", // ベトナム
  "UZ", // ウズベキスタン
  "MM", // ミャンマー
  "KH", // カンボジア
  "ER", // エリトリア
  "CD", // コンゴ民主共和国 (3TG)
  "ZW", // ジンバブエ
]);

export function isHighRiskCountry(countryCode: string): boolean {
  return HIGH_RISK_COUNTRIES.has(countryCode.toUpperCase());
}

/** UNGP 3 pillars + DD 6 step プロセス成熟度評価 */
export interface DdMaturityProfile {
  has_human_rights_policy: boolean;
  policy_approved_by_board: boolean;
  policy_published: boolean;
  conducts_periodic_assessment: boolean; // 定期的影響評価
  has_grievance_mechanism: boolean;
  publishes_annual_report: boolean;
  trains_staff: boolean;
}

export function evaluateDdMaturity(
  m: DdMaturityProfile,
): HrDdFinding[] {
  const findings: HrDdFinding[] = [];
  if (!m.has_human_rights_policy) {
    findings.push({
      rule: "UNGP原則16 + 経産省GL Step 1 (人権方針)",
      severity: "violation",
      hint: "人権方針が未策定。UNGP原則16に基づき、(1)取締役会承認/(2)社内外専門家からの助言/(3)組織全体に適用/(4)取引先への期待表明/(5)社内伝達/(6)公開を満たす方針を策定。",
    });
  } else {
    if (!m.policy_approved_by_board) {
      findings.push({
        rule: "UNGP原則16 (経営トップコミットメント)",
        severity: "warning",
        hint: "人権方針が取締役会承認を得ていない。経営トップ承認は UNGP の必須要件。",
      });
    }
    if (!m.policy_published) {
      findings.push({
        rule: "UNGP原則16 (公開)",
        severity: "warning",
        hint: "人権方針が外部公開されていない。Web/CSR報告書/統合報告書で英訳付公開を推奨。",
      });
    }
  }
  if (!m.conducts_periodic_assessment) {
    findings.push({
      rule: "UNGP原則18 (人権影響評価)",
      severity: "warning",
      hint: "定期的な人権影響評価未実施。最低年1回 + 重大な事業変更時 (M&A・新国進出) に実施。",
    });
  }
  if (!m.has_grievance_mechanism) {
    findings.push({
      rule: "UNGP原則29 (苦情処理メカニズム)",
      severity: "violation",
      hint: "苦情処理メカニズム不在。労働者・地域コミュニティ・サプライヤー従業員から直接アクセス可能なホットライン (匿名可) + 報復禁止 + 第三者運営 を整備。",
    });
  }
  if (!m.publishes_annual_report) {
    findings.push({
      rule: "UNGP原則21 + EU CSRD (情報開示)",
      severity: "advice",
      hint: "人権 DD 結果の年次開示未実施。サステナビリティ報告書 / 統合報告書で開示。EU CSRD は 2024 年から段階適用。",
    });
  }
  return findings;
}

/** サプライチェーン人権リスク評価 */
export function assessSupplyChainTier(
  t: SupplyChainTier,
): HrDdFinding[] {
  const findings: HrDdFinding[] = [];

  if (isHighRiskCountry(t.country)) {
    findings.push({
      rule: "サプライチェーン人権 DD (高リスク国)",
      severity: "watch",
      hint: `${t.supplier_name} (${t.country}) は高リスク国。詳細監査 (3rd party audit / SMETA / RBA / Sedex) を年1回以上実施。`,
    });
  }

  if (t.country === "CN" && t.industry.match(/textile|cotton|tomato|polysilicon|solar/i)) {
    findings.push({
      rule: "米国 UFLPA (新疆ウイグル強制労働防止法 2022)",
      severity: "warning",
      hint: `中国×綿/トマト/ポリシリコン/太陽光は新疆関与の rebuttable presumption。米国輸出時は出所証明 (DNA tracing/Oritain 等) 必須。`,
    });
  }

  if (t.identified_risks.includes("child_labor")) {
    findings.push({
      rule: "ILO138 (最低就業年齢) + ILO182 (最悪形態の児童労働)",
      category: "child_labor",
      severity: "remediation_required",
      hint: "児童労働判明 → 即時是正計画策定 (子供の福祉優先 / 教育移行支援 / 家族収入補填) + ILO/Save the Children 等の専門家連携。即時取引停止は子供を路頭に迷わせるため非推奨。",
    });
  }

  if (t.identified_risks.includes("forced_labor")) {
    findings.push({
      rule: "ILO29 + ILO105 (強制労働撤廃) + UFLPA",
      category: "forced_labor",
      severity: "remediation_required",
      hint: "強制労働判明 → 国際機関 (IOM/ILO) 連携 + 賠償 + 是正後継続評価。EU 強制労働品禁止規則 (2024年12月施行) で輸入禁止対象。",
    });
  }

  return findings;
}

/** 紛争鉱物 (3TG + コバルト) Due Diligence */
export type ConflictMineral = "tantalum" | "tin" | "tungsten" | "gold" | "cobalt";

export interface MineralSourcing {
  mineral: ConflictMineral;
  smelter_name: string;
  smelter_country: string;
  rmap_certified: boolean; // RMI Responsible Minerals Assurance Process
  source_region: string; // 原産地: DRC / 周辺国 / その他
}

export function checkConflictMinerals(
  records: MineralSourcing[],
): HrDdFinding[] {
  const findings: HrDdFinding[] = [];
  const drcAdjacent = ["CD", "AO", "BI", "CF", "RW", "TZ", "UG", "ZM"];

  for (const r of records) {
    const drcSourced =
      r.source_region === "DRC" ||
      drcAdjacent.includes(r.source_region.toUpperCase());

    if (drcSourced && !r.rmap_certified) {
      findings.push({
        rule: "Dodd-Frank 1502条 + OECD Conflict Minerals Guidance",
        severity: "violation",
        hint: `${r.mineral} を ${r.source_region} から調達、製錬所 ${r.smelter_name} は RMAP 未認証。SEC Form SD 提出義務 (米国上場) + EU紛争鉱物規則 (2021年1月) 違反リスク。`,
      });
    }

    if (r.mineral === "cobalt" && r.source_region === "CD") {
      findings.push({
        rule: "コバルト児童労働 (Amnesty 2016 + DOL TVPRA)",
        severity: "warning",
        hint: "DRC コバルトは artisanal mining での児童労働懸念。Cobalt Refinery Supply Chain Due Diligence Standard (RMI) 認証経由のみ調達。",
      });
    }
  }

  return findings;
}

/** 国内ハラスメント (パワハラ防止法 R4.4全面適用) */
export interface HarassmentIncident {
  incident_id: string;
  category: "pwh" | "sxh" | "mtn" | "kth" | "lgbtq";
  reported_at: string;
  acknowledged_at?: string;
  investigation_started_at?: string;
  resolved_at?: string;
  retaliation_measures_in_place: boolean;
}

export function checkHarassmentResponse(
  i: HarassmentIncident,
): HrDdFinding[] {
  const findings: HrDdFinding[] = [];
  const reported = Date.parse(i.reported_at);
  if (Number.isNaN(reported)) return findings;

  // 対応着手の遅延 (実務目安: 7日以内)
  if (!i.acknowledged_at) {
    findings.push({
      rule: "労働施策総合推進法 30条の2 (パワハラ防止)",
      category: i.category === "sxh" ? "harassment_sxh" : "harassment_pwh",
      severity: "warning",
      hint: "ハラスメント申告に対する受領通知未実施。7日以内の通知が実務標準。",
    });
  }

  if (i.acknowledged_at) {
    const ack = Date.parse(i.acknowledged_at);
    if (ack - reported > 7 * 24 * 60 * 60 * 1000) {
      findings.push({
        rule: "実務統制 (ハラスメント受領)",
        severity: "warning",
        hint: "受領まで7日超過。実務上の不利益取扱い疑念。",
      });
    }
  }

  if (!i.retaliation_measures_in_place) {
    findings.push({
      rule: "労働施策総合推進法 30条の2第2項 (報復禁止)",
      severity: "violation",
      hint: "申告者への報復防止措置未配置。配置転換配慮 + 上長への注意 + 別ライン報告経路を整備。",
    });
  }

  return findings;
}

/** 統合 DD レポート生成 */
export function buildHrDdReport(input: {
  org_name: string;
  fiscal_year: number;
  maturity: DdMaturityProfile;
  supply_chain: SupplyChainTier[];
  minerals?: MineralSourcing[];
}): string {
  const ddFindings = evaluateDdMaturity(input.maturity);
  const scFindings = input.supply_chain.flatMap((t) =>
    assessSupplyChainTier(t),
  );
  const mineralFindings = input.minerals
    ? checkConflictMinerals(input.minerals)
    : [];
  const all = [...ddFindings, ...scFindings, ...mineralFindings];
  const violations = all.filter(
    (f) => f.severity === "violation" || f.severity === "remediation_required",
  );

  return `# ${input.org_name} 人権DD報告書 ${input.fiscal_year}年度

## 1. 経営トップコミットメント
当社は UNGP に賛同し、サプライチェーン全体での人権尊重に取り組む。

## 2. 人権 DD プロセス成熟度
- 方針策定: ${input.maturity.has_human_rights_policy ? "○" : "✗"}
- 取締役会承認: ${input.maturity.policy_approved_by_board ? "○" : "✗"}
- 苦情処理メカニズム: ${input.maturity.has_grievance_mechanism ? "○" : "✗"}
- 定期評価: ${input.maturity.conducts_periodic_assessment ? "○" : "✗"}

## 3. サプライチェーン評価
- 評価対象 Tier: ${input.supply_chain.length} 社
- 高リスク国所在: ${input.supply_chain.filter((t) => isHighRiskCountry(t.country)).length} 社

## 4. 是正措置必須案件
${violations.length === 0 ? "本年度はなし" : violations.map((v) => `- ${v.rule}: ${v.hint}`).join("\n")}

## 5. 苦情処理メカニズム
- 受付経路: ホットライン (匿名可) / 第三者運営
- 報復禁止: 規程明文化済
`;
}
