/**
 * @fileoverview Phase 11 - 医療ドメイン DNA
 *
 * 「診療報酬点数表」「レセプト電算処理システム」「オンライン資格確認」
 * 「HL7 FHIR JP Core」「HPKI 認証」「電子カルテ標準化」を実装。
 *
 * Claude Code は「点数があります」「レセプトとは…」レベルで止まる。
 * 本モジュールは:
 *   1. 診療報酬点数の構造化 (基本診療料 / 特掲診療料 / 加算)
 *   2. 2024年診療報酬改定 (令和6年度) を反映した点数 DB スケルトン
 *   3. レセプト電算 UKE フォーマット (固定長 CSV) のレコード型定義
 *   4. オンライン資格確認 (マイナ保険証) 連携 I/F
 *   5. HL7 FHIR JP Core プロファイル準拠の Patient/Encounter/Observation
 *   6. HPKI (医療従事者) 電子署名要件チェック
 *   7. 個人情報保護法 + 医療情報安全管理ガイドライン (3省2ガイドライン) 適合性
 *   8. 医薬品コード (YJ コード / 個別医薬品コード)
 *   9. 病名 ICD-10 + レセプト電算処理用傷病名マスタ
 */

// ============================================================================
// Types
// ============================================================================

/** 診療科コード (主要 30 科) */
export type DepartmentCode =
  | 'internal'        // 内科
  | 'pediatrics'      // 小児科
  | 'surgery'         // 外科
  | 'orthopedic'      // 整形外科
  | 'plastic'         // 形成外科
  | 'dermatology'     // 皮膚科
  | 'urology'         // 泌尿器科
  | 'obgyn'           // 産婦人科
  | 'ophthalmology'   // 眼科
  | 'ent'             // 耳鼻咽喉科
  | 'psychiatry'      // 精神科
  | 'neurology'       // 神経内科
  | 'cardiology'      // 循環器内科
  | 'gastroenterology' // 消化器内科
  | 'respiratory'     // 呼吸器内科
  | 'nephrology'      // 腎臓内科
  | 'endocrinology'   // 内分泌内科
  | 'hematology'      // 血液内科
  | 'oncology'        // 腫瘍内科
  | 'rehabilitation'  // リハビリテーション科
  | 'anesthesiology'  // 麻酔科
  | 'radiology'       // 放射線科
  | 'pathology'       // 病理診断科
  | 'emergency'       // 救急科
  | 'dental'          // 歯科
  | 'oral_surgery'    // 口腔外科
  | 'home_care'       // 在宅医療
  | 'palliative'      // 緩和ケア
  | 'general'         // 総合診療
  | 'other';

/** 保険種別 */
export type InsuranceType =
  | 'employees_health'    // 健康保険 (協会けんぽ・組合健保)
  | 'national_health'     // 国民健康保険
  | 'late_elder'          // 後期高齢者医療
  | 'public_assistance'   // 生活保護
  | 'specific_disease'    // 特定疾患
  | 'workers_comp'        // 労災
  | 'auto_insurance'      // 自賠責
  | 'self_pay';           // 自費

/** 診療報酬点数表エントリ (1点 = 10円) */
export interface MedicalFeeItem {
  /** 区分番号 (例: A000 初診料) */
  code: string;
  /** 名称 */
  name: string;
  category: 'basic' | 'special' | 'addition' | 'inpatient' | 'home_care' | 'rehab' | 'inspection' | 'imaging' | 'injection' | 'surgery' | 'anesthesia' | 'pathology' | 'medication' | 'material';
  /** 点数 (1点=10円) */
  points: number;
  /** 算定要件 */
  requirements?: string;
  /** 加算可能項目 (区分番号) */
  additions?: string[];
  /** 改定: 'R6' = 令和6年度改定 */
  revision: 'R4' | 'R6';
}

/** 標準診療報酬テーブル (代表値・実運用は厚労省告示参照必須) */
export const STANDARD_MEDICAL_FEES: MedicalFeeItem[] = [
  // 基本診療料
  { code: 'A000', name: '初診料', category: 'basic', points: 291, revision: 'R6' },
  { code: 'A001', name: '再診料', category: 'basic', points: 75, revision: 'R6' },
  { code: 'A002', name: '外来診療料', category: 'basic', points: 76, revision: 'R6' },
  { code: 'A100', name: '一般病棟入院基本料 (急性期一般入院料1)', category: 'inpatient', points: 1688, revision: 'R6' },
  { code: 'A101', name: '療養病棟入院基本料 (療養病棟入院料1)', category: 'inpatient', points: 1813, revision: 'R6' },

  // 特掲診療料 (検査の代表)
  { code: 'D007', name: '血液化学検査', category: 'inspection', points: 11, revision: 'R6' },
  { code: 'D025', name: '基本的検体検査実施料', category: 'inspection', points: 140, revision: 'R6' },

  // 画像診断
  { code: 'E001', name: '写真診断 (単純撮影)', category: 'imaging', points: 85, revision: 'R6' },
  { code: 'E101', name: 'CT撮影 (16列以上64列未満)', category: 'imaging', points: 900, revision: 'R6' },
  { code: 'E202', name: 'MRI撮影 (1.5T以上3T未満)', category: 'imaging', points: 1330, revision: 'R6' },

  // 処置・手術
  { code: 'K000', name: '創傷処理 (筋肉・臓器に達しないもの 5cm未満)', category: 'surgery', points: 530, revision: 'R6' },
  { code: 'K721', name: '内視鏡的大腸ポリープ・粘膜切除術 (長径2cm未満)', category: 'surgery', points: 5000, revision: 'R6' },

  // 在宅医療
  { code: 'C000', name: '往診料', category: 'home_care', points: 720, revision: 'R6' },
  { code: 'C001', name: '在宅患者訪問診療料 (同一建物居住者以外)', category: 'home_care', points: 888, revision: 'R6' },

  // リハビリテーション
  { code: 'H001', name: '脳血管疾患等リハビリテーション料 (Ⅰ)', category: 'rehab', points: 245, revision: 'R6' },
  { code: 'H002', name: '運動器リハビリテーション料 (Ⅰ)', category: 'rehab', points: 185, revision: 'R6' },

  // R6 新設 (DX 関連)
  { code: 'A000-DX', name: '医療DX推進体制整備加算', category: 'addition', points: 8, revision: 'R6', requirements: 'マイナ保険証利用率 + オンライン資格確認 + 電子処方箋' },
  { code: 'A000-OQ', name: 'オンライン資格確認システム導入加算', category: 'addition', points: 4, revision: 'R6' },
];

// ============================================================================
// 算定: 診療報酬の総点数 → 円
// ============================================================================

/** 1点 = 10円 (健康保険適用) */
export const FEE_PER_POINT_YEN = 10;

/** 患者負担割合 */
export type CopayRatio = 0 | 0.1 | 0.2 | 0.3;

export function calcInsuranceFee(input: {
  items: { code: string; quantity?: number }[];
  copayRatio: CopayRatio;
  feeTable?: MedicalFeeItem[];
}): { totalPoints: number; totalYen: number; copayYen: number; insurerYen: number } {
  const table = input.feeTable ?? STANDARD_MEDICAL_FEES;
  let totalPoints = 0;
  for (const it of input.items) {
    const fee = table.find((f) => f.code === it.code);
    if (!fee) continue;
    totalPoints += fee.points * (it.quantity ?? 1);
  }
  const totalYen = totalPoints * FEE_PER_POINT_YEN;
  const copayYen = Math.round(totalYen * input.copayRatio / 10) * 10; // 10円未満四捨五入
  const insurerYen = totalYen - copayYen;
  return { totalPoints, totalYen, copayYen, insurerYen };
}

// ============================================================================
// レセプト電算 UKE フォーマット (簡易型定義)
// ============================================================================

/**
 * UKE: 医科レセプト電算処理仕様書のレコード型 (主要レコードのみ)
 * 実運用は厚労省「電子レセプトに関する仕様書」を参照。
 */
export interface UKERecord {
  recordType: 'MN' | 'IR' | 'RE' | 'HO' | 'KO' | 'KH' | 'SY' | 'SI' | 'IY' | 'TO' | 'CO' | 'SJ' | 'GO';
  /** カラム配列 (固定長 or カンマ区切り) */
  columns: (string | number)[];
}

export function buildUKEHeader(input: {
  insurerNumberJp: string; // 8 桁 (保険者番号)
  patientId: string;
  yearMonth: string; // YYYYMM
}): UKERecord {
  return {
    recordType: 'IR', // 医療機関情報
    columns: [
      'IR',
      input.insurerNumberJp,
      input.yearMonth,
      input.patientId,
    ],
  };
}

// ============================================================================
// オンライン資格確認 (マイナ保険証)
// ============================================================================

export interface OqsRequest {
  /** マイナンバーカードの利用者証明用電子証明書のシリアル */
  certificateSerial: string;
  /** 医療機関コード (10桁) */
  medicalInstitutionCode: string;
  /** 受診日 YYYY-MM-DD */
  visitDate: string;
}

export interface OqsResponse {
  /** 資格情報 */
  insuranceInfo: {
    insurerNumberJp: string;
    insuredCardSymbol: string;
    insuredCardNumber: string;
    branchNumber: string;
    insuredName: string;
    birthDate: string; // YYYY-MM-DD
    sex: 'M' | 'F';
    qualificationDate: string;
    expiryDate?: string;
  };
  /** 限度額適用認定証情報 */
  highCostInfo?: {
    applicationCategory: string;
    validityStart: string;
    validityEnd: string;
  };
  /** 特定疾病療養受療証情報 */
  specificDiseaseInfo?: {
    diseaseCode: string;
    validityStart: string;
  };
  /** 診療情報 (薬剤情報・特定健診結果) */
  consentMedicalInfo: boolean;
  consentSpecialHealthInfo: boolean;
}

// ============================================================================
// HL7 FHIR JP Core プロファイル (主要リソース)
// ============================================================================

export interface FhirPatientJp {
  resourceType: 'Patient';
  id: string;
  identifier: { system: string; value: string }[]; // マイナンバー or 患者ID
  name: {
    use: 'official';
    family: string;
    given: string[];
    /** カナ (extension で表現) */
    extension?: { url: string; valueString: string }[];
  }[];
  gender: 'male' | 'female' | 'other' | 'unknown';
  birthDate: string;
  address?: {
    postalCode: string;
    prefecture: string;
    city: string;
    line: string[];
  }[];
}

export interface FhirEncounterJp {
  resourceType: 'Encounter';
  id: string;
  status: 'planned' | 'arrived' | 'in-progress' | 'finished' | 'cancelled';
  class: { code: 'AMB' | 'IMP' | 'EMER' | 'HH'; display: string };
  subject: { reference: string }; // Patient/xxx
  period: { start: string; end?: string };
  serviceProvider: { reference: string }; // Organization/xxx
}

// ============================================================================
// HPKI 電子署名チェック (医療従事者)
// ============================================================================

/**
 * HPKI: Healthcare Public Key Infrastructure
 * 医師・歯科医師・薬剤師等の国家資格情報を電子証明書に格納。
 */
export function checkHPKICompliance(input: {
  certificateIssuer: 'JMA' | 'JPHA' | 'JDA' | 'MEDIS' | 'other';
  professionType: 'physician' | 'dentist' | 'pharmacist' | 'nurse' | 'midwife' | 'public_health_nurse' | 'radiology_tech' | 'clinical_lab_tech';
  certificateValid: boolean;
  containsLicenseNumber: boolean;
  containsExpiry: boolean;
  hashAlgorithm: 'SHA-1' | 'SHA-256' | 'SHA-384' | 'SHA-512';
}): { ok: boolean; reasons: string[] } {
  const reasons: string[] = [];
  if (!input.certificateValid) reasons.push('証明書が有効期限切れ');
  if (!input.containsLicenseNumber) reasons.push('国家資格番号が証明書に含まれていない');
  if (!input.containsExpiry) reasons.push('有効期限フィールド欠落');
  if (input.hashAlgorithm === 'SHA-1') reasons.push('SHA-1 は脆弱・SHA-256 以上必須');
  if (input.certificateIssuer === 'other') reasons.push('HPKI 認定認証局 (JMA/JPHA/JDA/MEDIS) を使うこと');
  return { ok: reasons.length === 0, reasons };
}

// ============================================================================
// 3省2ガイドライン (個情法 + 医療情報安全管理) 適合性
// ============================================================================

/**
 * 3省2ガイドライン:
 *   - 厚労省「医療情報システムの安全管理に関するガイドライン」
 *   - 経産省・総務省「医療情報を取り扱う情報システム・サービスの提供事業者における安全管理ガイドライン」
 */
export function check3Sho2Guideline(input: {
  encryptionAtRest: boolean;
  encryptionInTransit: boolean;
  accessControl: 'rbac' | 'abac' | 'discretionary' | 'none';
  auditLogRetentionYears: number;
  twoFactorAuth: boolean;
  backupOffsite: boolean;
  bcpDocumented: boolean;
  vendorContract3PartyAgreement: boolean;
  staffTrainingFrequencyMonths: number;
}): { passed: boolean; failures: string[]; score: number } {
  const failures: string[] = [];
  let score = 0;

  if (input.encryptionAtRest) score += 12; else failures.push('保存時暗号化が必要');
  if (input.encryptionInTransit) score += 12; else failures.push('通信時暗号化 (TLS1.2+) が必要');
  if (['rbac', 'abac'].includes(input.accessControl)) score += 12;
  else failures.push('RBAC/ABAC によるアクセス制御が必要');
  if (input.auditLogRetentionYears >= 6) score += 12; else failures.push('監査ログ 6年以上保管が必要');
  if (input.twoFactorAuth) score += 10; else failures.push('管理者二要素認証が必要');
  if (input.backupOffsite) score += 10; else failures.push('オフサイトバックアップが必要');
  if (input.bcpDocumented) score += 10; else failures.push('BCP 文書化が必要');
  if (input.vendorContract3PartyAgreement) score += 12; else failures.push('外部委託先との三者間契約が必要');
  if (input.staffTrainingFrequencyMonths <= 12) score += 10; else failures.push('年1回以上の職員教育が必要');

  return { passed: failures.length === 0, failures, score };
}

// ============================================================================
// 医薬品コード (YJ コード)
// ============================================================================

/** YJ コード: 12桁の医薬品コード */
export interface MedicationYj {
  yjCode: string; // 12 桁
  productName: string;
  genericName: string;
  dosageForm: string; // 錠剤/カプセル/注射剤等
  unit: string; // 1錠/1mL/1g 等
  unitPriceYen: number; // 薬価
  isGeneric: boolean;
}

// ============================================================================
// 病名マスタ (ICD-10 + レセプト電算処理用傷病名マスタ)
// ============================================================================

export interface DiseaseMaster {
  /** ICD-10 コード */
  icd10: string;
  /** 標準病名 (レセプト電算用) */
  standardName: string;
  /** よみ */
  reading: string;
  /** 修飾語 (急性/慢性等) */
  modifiers?: string[];
}

export const COMMON_DISEASES: DiseaseMaster[] = [
  { icd10: 'I10', standardName: '本態性高血圧症', reading: 'ホンタイセイコウケツアツショウ' },
  { icd10: 'E11', standardName: '2型糖尿病', reading: 'ニガタトウニョウビョウ' },
  { icd10: 'J45', standardName: '気管支喘息', reading: 'キカンシゼンソク', modifiers: ['急性', '慢性'] },
  { icd10: 'K29', standardName: '胃炎', reading: 'イエン', modifiers: ['急性', '慢性'] },
  { icd10: 'M16', standardName: '股関節症', reading: 'コカンセツショウ' },
  { icd10: 'F32', standardName: 'うつ病エピソード', reading: 'ウツビョウエピソード' },
];

// ============================================================================
// Default exports
// ============================================================================

export const MEDICAL_DOMAIN_REFS = {
  // 診療報酬改定 (現行=令和8年度)。2026-07-31 に生存確認済み。
  // 旧参照先 (0000188411_00038.html) は 404 化していた — 手書きの一次情報 URL は放置すると腐るため、
  // lib/japan/primary-source-ingest が定期巡回して 404 を検知する (sources/medical.json)。
  REVENUE_TABLE_URL: 'https://www.mhlw.go.jp/stf/newpage_67729.html',
  // 機械可読マスタ (点数・薬価・算定ルール) の配布元。値の取得はこちらが一次情報。
  FEE_MASTER_DOWNLOAD_URL: 'https://shinryohoshu.mhlw.go.jp/shinryohoshu/downloadMenu/',
  FEE_RULE_TABLE_URL: 'https://www.ssk.or.jp/seikyushiharai/tensuhyo/ikashika/index.html',
  ONLINE_QUALIFICATION_URL: 'https://www.iryohokenjyoho-portalsite.jp/',
  HPKI_PORTAL_URL: 'https://www.medis.or.jp/8_hpki/',
  HL7_FHIR_JP_CORE: 'https://jpfhir.jp/fhir/core/',
};
