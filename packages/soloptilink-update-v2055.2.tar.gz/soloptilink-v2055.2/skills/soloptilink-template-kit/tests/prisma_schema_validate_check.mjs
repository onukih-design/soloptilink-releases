/**
 * soloptilink-template-kit / 生成 Prisma スキーマ実走検証ゲート
 * (2026-08-01 新設 — GATE-ID: TK-PRISMA-VALIDATE)
 *
 * ## 何を守るゲートか
 * 「kit を実際に展開し、出てきた prisma/schema.prisma に本物の `prisma validate` を掛ける」。
 *
 * ## なぜ要るのか (このゲートが無かったために起きた事故)
 * kits/medical_overlay.json は要配慮個人情報の暗号化を意図して独自型 `EncryptedString` を
 * 12 フィールドに宣言していたが、scaffolder 側に変換が実装されておらず、型名がそのまま
 * Prisma スキーマへ出ていた。Prisma に該当型は無いため、medical / medical_overlay の
 * 生成物は `prisma validate` が通らない状態だった。
 * 既存ゲートは kit JSON の静的検査と scaffolder のソース文字列検査までで、
 * **「展開して検証する」軸が 1 本も無かった**ため、今日まで検出されなかった。
 *
 * ## 両側判定 (born-passing 対策)
 * 健全側だけを見るゲートは「常に合格する飾り」になりうる。本ゲートは自分自身に
 * 欠陥注入を掛け、**欠陥キットで確かに不合格になること**を毎回実走で証明する。
 *   - 健全側: 実 kits/*.json 全件 → prisma validate PASS
 *   - 欠陥側 1: 未定義の独自型を持つ合成 kit → prisma validate FAIL を検出できる
 *   - 欠陥側 2: EncryptedString を持つ kit で暗号化実装が生成されない → 検出できる
 *
 * ## 未測定を合格にしない
 * typescript / prisma CLI が使えない環境では PASS を出さず、
 * 終了コード 2 (UNMEASURED) で「測っていない」ことを明示して落ちる。
 *
 * 実行: node tests/prisma_schema_validate_check.mjs
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync, writeFileSync, mkdirSync, rmSync, existsSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';

const require_ = createRequire(import.meta.url);
const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const WORK = join(tmpdir(), `tk-prisma-validate-${process.pid}`);

/** prisma validate は datasource の env() を解決するため DATABASE_URL を要求する。 */
const VALIDATE_ENV = {
  ...process.env,
  DATABASE_URL: 'postgresql://validate:validate@127.0.0.1:5432/validate',
};

// ---------------------------------------------------------------------------
// 前提ツールの実在確認 (無ければ「未測定」で落とす。合格にはしない)
// ---------------------------------------------------------------------------

function loadTypeScript() {
  const candidates = ['typescript'];
  try {
    const root = execFileSync('npm', ['root', '-g'], { encoding: 'utf8', timeout: 30000 }).trim();
    if (root) candidates.push(join(root, 'typescript'));
  } catch { /* npm 不在は下で扱う */ }
  for (const c of candidates) {
    try { return require_(c); } catch { /* 次の候補 */ }
  }
  return null;
}

function prismaCliAvailable() {
  try {
    execFileSync('npx', ['--no-install', 'prisma', '--version'],
      { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 120000 });
    return true;
  } catch { return false; }
}

const ts = loadTypeScript();
const prismaOk = ts ? prismaCliAvailable() : false;
if (!ts || !prismaOk) {
  const missing = [!ts && 'typescript', !prismaOk && 'prisma CLI'].filter(Boolean).join(' / ');
  console.error(`UNMEASURED: ${missing} が使えないため、生成 Prisma スキーマを検証できませんでした。`);
  console.error('このゲートは未測定を合格として記録しません。上記を用意してから再実行してください。');
  process.exit(2);
}

// ---------------------------------------------------------------------------
// 実 scaffolder のロード (再実装しない・本体 lib/*.ts をそのまま実行する)
// ---------------------------------------------------------------------------

function transpileLib(outDir) {
  mkdirSync(outDir, { recursive: true });
  for (const f of ['kit_loader.ts', 'scaffolder.ts', 'kit_overlay_resolver.ts', 'index.ts']) {
    const src = readFileSync(join(ROOT, 'lib', f), 'utf8');
    const js = ts.transpileModule(src, {
      compilerOptions: {
        module: ts.ModuleKind.ESNext,
        target: ts.ScriptTarget.ES2022,
        isolatedModules: true,
      },
      fileName: f,
    }).outputText.replace(/from '\.\/(kit_loader|scaffolder|kit_overlay_resolver)'/g, "from './$1.mjs'");
    writeFileSync(join(outDir, f.replace(/\.ts$/, '.mjs')), js, 'utf8');
  }
  return join(outDir, 'index.mjs');
}

rmSync(WORK, { recursive: true, force: true });
mkdirSync(WORK, { recursive: true });
const kitLib = await import(pathToFileURL(transpileLib(join(WORK, 'lib'))).href);

/** 実際に prisma validate を走らせる。{ ok, out } を返す。 */
function prismaValidate(schemaPath) {
  try {
    const out = execFileSync('npx', ['--no-install', 'prisma', 'validate', '--schema', schemaPath],
      { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 180000, env: VALIDATE_ENV });
    return { ok: true, out };
  } catch (e) {
    return { ok: false, out: `${e.stdout ?? ''}${e.stderr ?? ''}` };
  }
}

function walk(dir, acc = []) {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) walk(p, acc); else acc.push(p);
  }
  return acc;
}

/** kit を展開し、prisma validate の結果まで返す (このゲートの中核判定)。 */
function scaffoldAndValidate(kitId, label = kitId) {
  const target = join(WORK, 'out', label);
  const report = kitLib.scaffoldKit(kitId, target);
  const schema = join(target, 'prisma', 'schema.prisma');
  assert.ok(existsSync(schema), `${label}: prisma/schema.prisma が生成されていない`);
  const v = prismaValidate(schema);
  return { target, report, schema, valid: v.ok, output: v.out, files: walk(target).length };
}

const KIT_IDS = readdirSync(join(ROOT, 'kits'))
  .filter((f) => f.endsWith('.json'))
  .map((f) => f.replace(/\.json$/, ''))
  .sort();

// ===========================================================================
// 健全側: 実在する全 kit の生成 Prisma スキーマが prisma validate を通ること
// ===========================================================================

test('A-1: kits/ に kit が 1 件以上ある (検体ゼロで空回りしない)', () => {
  assert.ok(KIT_IDS.length >= 10, `kits/ の検体数が少なすぎる: ${KIT_IDS.length}`);
});

for (const kitId of KIT_IDS) {
  test(`A-2: ${kitId} — 展開した prisma/schema.prisma が prisma validate を通る`, () => {
    const r = scaffoldAndValidate(kitId);
    assert.ok(
      r.valid,
      `${kitId}: prisma validate 不合格\n${r.output.replace(/\x1b\[[0-9;]*m/g, '').slice(0, 1500)}`,
    );
  });
}

test('A-3: 生成された schema.prisma に Prisma 非対応の独自型が残っていない', () => {
  const KNOWN_SCALARS = new Set([
    'String', 'Boolean', 'Int', 'BigInt', 'Float', 'Decimal', 'DateTime', 'Json', 'Bytes', 'Unsupported',
  ]);
  for (const kitId of KIT_IDS) {
    const schemaPath = join(WORK, 'out', kitId, 'prisma', 'schema.prisma');
    const text = readFileSync(schemaPath, 'utf8');
    const declared = new Set(
      [...text.matchAll(/^(?:model|enum|type)\s+([A-Za-z0-9_]+)\s*\{/gm)].map((m) => m[1]),
    );
    const unknown = [];
    let inBlock = false;
    for (const line of text.split('\n')) {
      if (/^(model|enum|type)\s+/.test(line)) { inBlock = !/^enum\s+/.test(line); continue; }
      if (line.startsWith('}')) { inBlock = false; continue; }
      if (!inBlock) continue;
      const m = line.match(/^\s{2}([A-Za-z_][A-Za-z0-9_]*)\s+([A-Za-z_][A-Za-z0-9_]*)(\[\])?\??/);
      if (!m) continue;
      const type = m[2];
      if (!KNOWN_SCALARS.has(type) && !declared.has(type)) unknown.push(`${kitId}: ${m[1]} ${type}`);
    }
    assert.deepEqual(unknown, [], `未定義の型が Prisma スキーマに残っている: ${unknown.join(', ')}`);
  }
});

// ===========================================================================
// 欠陥側 1: 未定義の独自型を持つ kit を注入し、本ゲートが確かに落ちること
// ===========================================================================

function writeFixtureKit(dir, kitId, extraField) {
  mkdirSync(dir, { recursive: true });
  const kit = {
    kit_id: kitId,
    name_ja: '欠陥注入用フィクスチャ',
    name_en: 'defect injection fixture',
    industry: 'test',
    industry_ja: 'テスト',
    description: '両側判定のための欠陥注入用フィクスチャ kit。実運用では使用しない。',
    use_case: 'ゲートが欠陥を確かに検出することの実証専用。',
    stack: { framework: 'next', ui: 'tailwind', orm: 'prisma', db: 'postgres', auth: 'next-auth' },
    domain_dictionary_ref: 'soloptilink-japan/domains/test.json',
    applicable_laws: ['個人情報保護法', '医師法'],
    prisma_models: [
      { model: 'FixtureA', fields: [{ name: 'id', type: 'String', unique: true }, extraField] },
      { model: 'FixtureB', fields: [{ name: 'id', type: 'String', unique: true }, { name: 'code', type: 'String' }] },
      { model: 'FixtureC', fields: [{ name: 'id', type: 'String', unique: true }, { name: 'value', type: 'Int' }] },
    ],
    routes: [
      { path: '/dashboard', purpose: 'dashboard', type: 'dashboard' },
      { path: '/fixture-a', purpose: 'a list' },
      { path: '/fixture-b', purpose: 'b list' },
      { path: '/fixture-c', purpose: 'c list' },
      { path: '/api/fixture-a', purpose: 'a api' },
    ],
    report_templates: ['R1', 'R2'],
    dashboard_kpis: ['K1', 'K2'],
    estimated_completion_percent: 90,
    scaffold_outputs: { files_count: 20, lines_count_approx: 2000, estimated_setup_minutes: 3 },
  };
  writeFileSync(join(dir, `${kitId}.json`), JSON.stringify(kit, null, 2), 'utf8');
  return kit;
}

/** フィクスチャ kits/ ディレクトリを一時的に差し替えて実行する。 */
function withFixtureKitsDir(dir, fn) {
  const saved = process.env.SOLOPTILINK_TEMPLATE_KIT_DIR;
  process.env.SOLOPTILINK_TEMPLATE_KIT_DIR = dir;
  try { return fn(); } finally {
    if (saved === undefined) delete process.env.SOLOPTILINK_TEMPLATE_KIT_DIR;
    else process.env.SOLOPTILINK_TEMPLATE_KIT_DIR = saved;
  }
}

test('B-1: [欠陥注入] 未定義の独自型を持つ kit は prisma validate に落ち、本ゲートが検出する', () => {
  const dir = join(WORK, 'fixtures', 'undefined-type');
  // 名前は scaffolder の enum 推定ヒューリスティクスに当たらないものを選ぶ
  // (当たると自動で enum が生成され、欠陥が消えてしまう)
  writeFixtureKit(dir, 'fixture_broken', { name: 'secret', type: 'NoSuchScalar' });
  const r = withFixtureKitsDir(dir, () => scaffoldAndValidate('fixture_broken', 'fixture_broken'));

  assert.equal(r.valid, false, '欠陥注入した kit が prisma validate を通ってしまった (ゲートが機能していない)');
  const plain = r.output.replace(/\x1b\[[0-9;]*m/g, '');
  assert.match(plain, /NoSuchScalar/, 'prisma が未定義型を指摘していない');
  assert.match(plain, /is neither a built-in type/, '想定した検出理由ではない');
});

test('B-2: [欠陥注入] 健全な合成 kit は同じ経路で合格する (落ち方の作為が無いことの対照)', () => {
  const dir = join(WORK, 'fixtures', 'healthy');
  writeFixtureKit(dir, 'fixture_healthy', { name: 'secret', type: 'String' });
  const r = withFixtureKitsDir(dir, () => scaffoldAndValidate('fixture_healthy', 'fixture_healthy'));
  assert.ok(r.valid, `健全な合成 kit が落ちた (ゲートが常時 FAIL になっている)\n${r.output.slice(0, 800)}`);
});

// ===========================================================================
// EncryptedString: 設計意図 (要配慮個人情報の暗号化) が実装に到達しているか
// ===========================================================================

const CRYPTO_FILES = [
  'src/lib/crypto/encrypted-fields.ts',
  'src/lib/crypto/field-encryption.ts',
  'src/lib/crypto/prisma-encryption-extension.ts',
];

/**
 * EncryptedString を宣言している実 kit を列挙する。
 *
 * 判定は **overlay 適用後 (=実際に scaffold される姿)** で行う。生の kits/*.json を見ると
 * medical.json 自身は EncryptedString を持たないため、overlay 経由で暗号化フィールドが
 * 入る medical を取りこぼす (この取りこぼしは本ゲート作成時に実際に踏んだ)。
 */
function kitsWithEncryptedFields() {
  const hits = [];
  for (const kitId of KIT_IDS) {
    const kit = kitLib.loadKitWithOverlay(kitId);
    const models = Array.isArray(kit.prisma_models) ? kit.prisma_models : [];
    const n = models.reduce(
      (a, m) => a + (m.fields ?? []).filter((f) => f.type === 'EncryptedString').length, 0);
    if (n > 0) hits.push({ kitId, count: n, kit });
  }
  return hits;
}

test('C-1: EncryptedString を宣言した kit では暗号化実装が生成物に同梱される', () => {
  const hits = kitsWithEncryptedFields();
  assert.ok(hits.length > 0, 'EncryptedString を使う kit が 1 件も無い (検体ゼロで空回りしている)');
  for (const { kitId } of hits) {
    const target = join(WORK, 'out', kitId);
    for (const rel of CRYPTO_FILES) {
      assert.ok(existsSync(join(target, rel)), `${kitId}: ${rel} が生成されていない (暗号化の設計意図が未到達)`);
    }
    const db = readFileSync(join(target, 'src', 'lib', 'db.ts'), 'utf8');
    assert.match(db, /withFieldEncryption/, `${kitId}: db.ts が暗号化 Extension を通していない`);
    const env = readFileSync(join(target, '.env.example'), 'utf8');
    assert.match(env, /FIELD_ENCRYPTION_KEY/, `${kitId}: .env.example に鍵の設定手順が無い`);
  }
});

test('C-2: EncryptedString フィールドは Prisma 上 String になり、暗号文である旨が残る', () => {
  for (const { kitId, kit } of kitsWithEncryptedFields()) {
    const schema = readFileSync(join(WORK, 'out', kitId, 'prisma', 'schema.prisma'), 'utf8');
    assert.ok(!/\bEncryptedString\b/.test(schema), `${kitId}: schema.prisma に EncryptedString が残っている`);
    let checked = 0;
    for (const m of kit.prisma_models ?? []) {
      for (const f of (m.fields ?? []).filter((x) => x.type === 'EncryptedString')) {
        const re = new RegExp(`^\\s{2}${f.name}\\s+String\\b.*encrypted:true`, 'm');
        assert.match(schema, re, `${kitId}.${m.model}.${f.name}: String + encrypted:true 注記になっていない`);
        checked += 1;
      }
    }
    assert.ok(checked > 0, `${kitId}: 検査対象フィールドが 0 件`);
  }
});

test('C-3: 暗号化対象を持たない kit には暗号化ファイルを増やさない (既存生成物を太らせない)', () => {
  const encrypted = new Set(kitsWithEncryptedFields().map((h) => h.kitId));
  for (const kitId of KIT_IDS) {
    if (encrypted.has(kitId)) continue;
    for (const rel of CRYPTO_FILES) {
      assert.ok(!existsSync(join(WORK, 'out', kitId, rel)),
        `${kitId}: 暗号化対象が無いのに ${rel} が生成されている`);
    }
  }
});

test('C-4: [欠陥注入] EncryptedString を持つのに暗号化実装が出ない場合は C-1 が落ちる', () => {
  // scaffolder が EncryptedString を素通しした「事故当時の状態」を合成 kit で再現する。
  const dir = join(WORK, 'fixtures', 'encrypted');
  writeFixtureKit(dir, 'fixture_encrypted', { name: 'secret', type: 'EncryptedString' });
  const r = withFixtureKitsDir(dir, () => scaffoldAndValidate('fixture_encrypted', 'fixture_encrypted'));

  // 健全側: 現行実装なら valid かつ暗号化ファイルが揃う
  assert.ok(r.valid, `EncryptedString を含む合成 kit が prisma validate に落ちた\n${r.output.slice(0, 800)}`);
  for (const rel of CRYPTO_FILES) {
    assert.ok(existsSync(join(r.target, rel)), `${rel} が生成されていない`);
  }

  // 欠陥側: 暗号化ファイルを 1 本削ると C-1 と同じ判定が確かに落ちること
  const victim = join(r.target, CRYPTO_FILES[1]);
  rmSync(victim);
  assert.throws(
    () => {
      for (const rel of CRYPTO_FILES) {
        assert.ok(existsSync(join(r.target, rel)), `${rel} が生成されていない (暗号化の設計意図が未到達)`);
      }
    },
    /field-encryption\.ts/,
    '暗号化実装が欠けても検出できない (C-1 が飾りになっている)',
  );
});

test('C-5: 生成された暗号化実装が実走で往復する (平文が暗号文に置き換わることの実証)', async () => {
  const hits = kitsWithEncryptedFields();
  const { kitId, kit } = hits[0];
  const gen = join(WORK, 'out', kitId, 'src', 'lib', 'crypto');
  const runDir = join(WORK, 'crypto-run');
  mkdirSync(join(runDir, 'node_modules', '@prisma', 'client'), { recursive: true });
  writeFileSync(join(runDir, 'package.json'), JSON.stringify({ type: 'module' }), 'utf8');
  writeFileSync(join(runDir, 'node_modules', '@prisma', 'client', 'package.json'),
    JSON.stringify({ name: '@prisma/client', type: 'module', main: 'index.js' }), 'utf8');
  writeFileSync(join(runDir, 'node_modules', '@prisma', 'client', 'index.js'),
    'export const Prisma = { defineExtension: (x) => x };\nexport class PrismaClient {}\n', 'utf8');
  for (const f of ['encrypted-fields', 'field-encryption', 'prisma-encryption-extension']) {
    const js = ts.transpileModule(readFileSync(join(gen, `${f}.ts`), 'utf8'), {
      compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022, isolatedModules: true },
    }).outputText.replace(/from '\.\/(encrypted-fields|field-encryption)'/g, "from './$1.js'");
    writeFileSync(join(runDir, `${f}.js`), js, 'utf8');
  }

  const fe = await import(pathToFileURL(join(runDir, 'field-encryption.js')).href);
  const ext = await import(pathToFileURL(join(runDir, 'prisma-encryption-extension.js')).href);

  const savedKey = process.env.FIELD_ENCRYPTION_KEY;
  try {
    // 鍵未設定なら平文保存へ倒れず例外で止まること (fail-safe)
    delete process.env.FIELD_ENCRYPTION_KEY;
    assert.throws(() => fe.encryptField('要配慮個人情報'), /FIELD_ENCRYPTION_KEY/,
      '鍵未設定でも暗号化なしで通ってしまう (平文保存へ倒れている)');

    process.env.FIELD_ENCRYPTION_KEY = Buffer.alloc(32, 7).toString('base64');
    const PLAIN = '主訴: 胸痛。既往に狭心症あり。';
    const cipher = fe.encryptField(PLAIN);
    assert.ok(fe.isEncrypted(cipher), '暗号文の形式になっていない');
    assert.ok(!cipher.includes(PLAIN), '暗号文に平文が残っている');
    assert.equal(fe.decryptField(cipher), PLAIN, '往復で元の平文に戻らない');
    assert.notEqual(fe.encryptField(PLAIN), fe.encryptField(PLAIN), '同一平文の暗号文が固定 (IV が乱数でない)');

    // Extension が DB へ渡る直前に暗号化していること
    const model = (kit.prisma_models ?? []).find((m) => (m.fields ?? []).some((f) => f.type === 'EncryptedString'));
    const field = model.fields.find((f) => f.type === 'EncryptedString').name;
    let seen;
    const out = await ext.fieldEncryptionExtension.query.$allModels.$allOperations({
      model: model.model,
      operation: 'create',
      args: { data: { [field]: PLAIN } },
      query: async (a) => { seen = a; return { ...a.data }; },
    });
    assert.ok(fe.isEncrypted(seen.data[field]), 'DB へ渡る値が平文のまま');
    assert.equal(out[field], PLAIN, '読み出し時に復号されていない');
  } finally {
    if (savedKey === undefined) delete process.env.FIELD_ENCRYPTION_KEY;
    else process.env.FIELD_ENCRYPTION_KEY = savedKey;
  }
});

test('Z: 一時ディレクトリの後始末', () => {
  rmSync(WORK, { recursive: true, force: true });
  assert.ok(!existsSync(WORK));
});
