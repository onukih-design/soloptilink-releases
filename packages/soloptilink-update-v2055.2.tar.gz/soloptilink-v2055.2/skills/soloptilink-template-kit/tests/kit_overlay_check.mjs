#!/usr/bin/env node
/**
 * soloptilink-template-kit / kit_overlay_resolver born-passing 両側弁別テスト
 *
 * ## テスト方針
 *
 * node 18 では TS を直接実行できないため、以下の two-layer 検証を行う:
 *
 * ### Layer 1: 純 JS 参考実装 (`resolverReference`) の挙動テスト
 *   ├─ (a) overlay あり + kill-switch on → merge 結果に engine_refs 上乗せ
 *   ├─ (b) overlay 削除 → base のみ (engine_refs 不在)
 *   ├─ (c) kill-switch off (ENABLE_KIT_OVERLAY=off) → overlay 存在しても base のみ
 *   └─ (d) silently 昇格禁止 → merge 結果の kit_id は常に base の kit_id
 *
 * ### Layer 2: TS 実装 (`lib/kit_overlay_resolver.ts`) と参考実装の等価性 grep
 *   ├─ ENABLE_KIT_OVERLAY 環境変数参照が TS に存在
 *   ├─ overlay_of 判定ロジックが TS に存在
 *   ├─ kit_id / overlay_of の silently 昇格禁止ロジックが TS に存在
 *   └─ overlay off キーワード (off / false / 0 / no) を TS 側も認識
 *
 * ### Layer 3: 統合効果テスト (実 kits/ 上での動線)
 *   ├─ listKits() 相当 (kits/*.json 全走査) で base=medical を必ず含む (industry='medical' 検索の base 動線)
 *   └─ overlay ファイル (medical_overlay.json) 削除→復元の md5 一致確認
 *
 * 実行:
 *   node tests/kit_overlay_check.mjs
 *
 * 期待: pass >= 12 / fail = 0
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, existsSync, writeFileSync, mkdtempSync, rmSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { createHash } from 'node:crypto';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '..');

// ---------------------------------------------------------------------------
// 純 JS 参考実装 (Layer 1)
// 本ロジックは lib/kit_overlay_resolver.ts の直訳。TS 側を改変する場合は
// 本ファイルも同時に更新すること (Layer 2 の等価性 grep が乖離を検出する)。
// ---------------------------------------------------------------------------

const resolverReference = {
  overlayEnabled(env = process.env) {
    const raw = (env.ENABLE_KIT_OVERLAY ?? '').trim().toLowerCase();
    if (raw === '') return true;
    if (raw === 'off' || raw === 'false' || raw === '0' || raw === 'no') return false;
    return true;
  },
  applyOverlay(base, overlay) {
    const merged = JSON.parse(JSON.stringify(base));
    for (const [key, value] of Object.entries(overlay)) {
      if (key === 'kit_id' || key === 'overlay_of') continue;
      merged[key] = value;
    }
    return merged;
  },
  findOverlayFor(base_kit_id, kitsDir) {
    if (!existsSync(kitsDir)) return null;
    const files = readdirSync(kitsDir);
    for (const f of files) {
      if (!f.endsWith('.json')) continue;
      const path = join(kitsDir, f);
      try {
        const raw = JSON.parse(readFileSync(path, 'utf8'));
        if (raw && typeof raw === 'object' && raw.overlay_of === base_kit_id) {
          return { file: path, raw };
        }
      } catch { /* skip corrupt files */ }
    }
    return null;
  },
  loadKitWithOverlay(base_kit_id, kitsDir, env = process.env) {
    const basePath = join(kitsDir, `${base_kit_id}.json`);
    if (!existsSync(basePath)) throw new Error(`base kit not found: ${basePath}`);
    const base = JSON.parse(readFileSync(basePath, 'utf8'));
    if (!this.overlayEnabled(env)) return base;
    const found = this.findOverlayFor(base_kit_id, kitsDir);
    if (!found) return base;
    return this.applyOverlay(base, found.raw);
  },
};

// ---------------------------------------------------------------------------
// fixture 生成 (tmp ディレクトリに base + overlay を配置)
// ---------------------------------------------------------------------------

function createFixtureKitsDir() {
  const dir = mkdtempSync(join(tmpdir(), 'kit-overlay-test-'));
  // 最小のvalid base kit
  const base = {
    kit_id: 'fixture_base',
    name_ja: 'テスト用ベースキット',
    industry: 'test',
    description: 'born-passing 両側弁別用の fixture ベース kit。',
    use_case: 'テスト専用。実運用kitではない。',
    stack: { framework: 'x', ui: 'x', orm: 'x', db: 'x', auth: 'x' },
    domain_dictionary_ref: 'soloptilink-japan/domains/test.json',
    applicable_laws: ['法1', '法2'],
    prisma_models: [
      { model: 'ModelA', fields: [{ name: 'id', type: 'String' }, { name: 'name', type: 'String' }] },
      { model: 'ModelB', fields: [{ name: 'id', type: 'String' }, { name: 'code', type: 'String' }] },
      { model: 'ModelC', fields: [{ name: 'id', type: 'String' }, { name: 'value', type: 'Int' }] },
    ],
    routes: [
      { path: '/dashboard', purpose: 'dashboard' },
      { path: '/a', purpose: 'a list' },
      { path: '/b', purpose: 'b list' },
      { path: '/c', purpose: 'c list' },
      { path: '/api/a', purpose: 'a api' },
    ],
    report_templates: ['R1', 'R2'],
    dashboard_kpis: ['K1', 'K2'],
    estimated_completion_percent: 90,
    scaffold_outputs: { files_count: 20, lines_count_approx: 2000, estimated_setup_minutes: 3 },
  };
  writeFileSync(join(dir, 'fixture_base.json'), JSON.stringify(base, null, 2));
  // overlay
  const overlay = {
    kit_id: 'fixture_overlay',
    overlay_of: 'fixture_base',
    engine_refs: {
      functions: ['calcFoo', 'calcBar'],
      evidence: '/api/foo → calcFoo / /api/bar → calcBar',
    },
    phase_c_disclosure: {
      scope: ['接続X', '接続Y'],
      disclosure_line: 'Phase C 実接続 (接続X/Y) は接続テストボタンまで実装。実接続は次回リリース時に段階提供。',
    },
    overlay_note: 'テスト用 overlay',
  };
  writeFileSync(join(dir, 'fixture_overlay.json'), JSON.stringify(overlay, null, 2));
  return { dir, base, overlay };
}

function md5(buf) {
  return createHash('md5').update(buf).digest('hex');
}

// ---------------------------------------------------------------------------
// Layer 1: 参考実装の両側弁別
// ---------------------------------------------------------------------------

test('L1-a: overlay あり + kill-switch on → merge 結果に engine_refs / phase_c_disclosure が乗る', () => {
  const { dir } = createFixtureKitsDir();
  try {
    const merged = resolverReference.loadKitWithOverlay('fixture_base', dir, {});
    assert.equal(merged.kit_id, 'fixture_base', 'silently 昇格禁止: kit_id は base のまま');
    assert.ok(merged.engine_refs, 'engine_refs が上乗せされる');
    assert.deepEqual(merged.engine_refs.functions, ['calcFoo', 'calcBar']);
    assert.ok(merged.phase_c_disclosure, 'phase_c_disclosure が上乗せされる');
    assert.equal(merged.phase_c_disclosure.disclosure_line.includes('接続テストボタンまで'), true);
    assert.equal(merged.overlay_of, undefined, 'overlay_of は結果に露出しない');
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('L1-b: overlay ファイル削除 → base のみ (engine_refs 不在)', () => {
  const { dir } = createFixtureKitsDir();
  try {
    rmSync(join(dir, 'fixture_overlay.json'));
    const merged = resolverReference.loadKitWithOverlay('fixture_base', dir, {});
    assert.equal(merged.kit_id, 'fixture_base');
    assert.equal(merged.engine_refs, undefined, 'engine_refs 不在=base のみ');
    assert.equal(merged.phase_c_disclosure, undefined);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('L1-c: kill-switch off (ENABLE_KIT_OVERLAY=off) → overlay 存在しても base のみ', () => {
  const { dir } = createFixtureKitsDir();
  try {
    const merged = resolverReference.loadKitWithOverlay('fixture_base', dir, { ENABLE_KIT_OVERLAY: 'off' });
    assert.equal(merged.kit_id, 'fixture_base');
    assert.equal(merged.engine_refs, undefined, 'kill-switch off で overlay 無視');
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('L1-c-2: kill-switch 各値 (false/0/no) も off として扱う', () => {
  const { dir } = createFixtureKitsDir();
  try {
    for (const v of ['false', '0', 'no', 'FALSE', 'Off']) {
      const merged = resolverReference.loadKitWithOverlay('fixture_base', dir, { ENABLE_KIT_OVERLAY: v });
      assert.equal(merged.engine_refs, undefined, `kill-switch value="${v}" → overlay 無視`);
    }
    // on 側 (未設定含む) は overlay 適用
    for (const v of ['', 'on', 'true', '1', 'yes']) {
      const merged = resolverReference.loadKitWithOverlay('fixture_base', dir, { ENABLE_KIT_OVERLAY: v });
      assert.ok(merged.engine_refs, `kill-switch value="${v}" → overlay 適用`);
    }
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('L1-d: silently 昇格禁止 → merge 結果の kit_id は常に base の kit_id', () => {
  const { dir } = createFixtureKitsDir();
  try {
    const merged = resolverReference.loadKitWithOverlay('fixture_base', dir, {});
    assert.equal(merged.kit_id, 'fixture_base');
    assert.notEqual(merged.kit_id, 'fixture_overlay');
    // 逆に overlay 自身を loadKit した場合は overlay として扱う (silently 昇格ではない=明示選択)
    const overlaySelf = JSON.parse(readFileSync(join(dir, 'fixture_overlay.json'), 'utf8'));
    assert.equal(overlaySelf.kit_id, 'fixture_overlay');
    assert.equal(overlaySelf.overlay_of, 'fixture_base');
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('L1-d-2: 空overlay (overlay_of 一致するがフィールド無し) は base をそのまま返す', () => {
  const dir = mkdtempSync(join(tmpdir(), 'kit-overlay-empty-'));
  try {
    const base = {
      kit_id: 'e_base', name_ja: 'x', industry: 'x', description: 'x'.repeat(20), use_case: 'x'.repeat(20),
      stack: { framework: 'x', ui: 'x', orm: 'x', db: 'x', auth: 'x' },
      domain_dictionary_ref: 'soloptilink-japan/domains/test.json',
      applicable_laws: ['x', 'y'],
      prisma_models: [{ model: 'A', fields: [{ name: 'id', type: 'String' }, { name: 'v', type: 'Int' }] }, { model: 'B', fields: [{ name: 'id', type: 'String' }, { name: 'v', type: 'Int' }] }, { model: 'C', fields: [{ name: 'id', type: 'String' }, { name: 'v', type: 'Int' }] }],
      routes: [{ path: '/a', purpose: 'x' }, { path: '/b', purpose: 'x' }, { path: '/c', purpose: 'x' }, { path: '/d', purpose: 'x' }, { path: '/e', purpose: 'x' }],
      report_templates: ['R1', 'R2'], dashboard_kpis: ['K1', 'K2'],
      estimated_completion_percent: 90,
      scaffold_outputs: { files_count: 1, lines_count_approx: 1, estimated_setup_minutes: 1 },
    };
    writeFileSync(join(dir, 'e_base.json'), JSON.stringify(base));
    writeFileSync(join(dir, 'e_overlay.json'), JSON.stringify({ kit_id: 'e_overlay', overlay_of: 'e_base' }));
    const merged = resolverReference.loadKitWithOverlay('e_base', dir, {});
    assert.equal(merged.kit_id, 'e_base');
    assert.equal(merged.engine_refs, undefined);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

// ---------------------------------------------------------------------------
// Layer 2: TS 実装との等価性 grep
// ---------------------------------------------------------------------------

test('L2-a: TS 実装が ENABLE_KIT_OVERLAY 環境変数を参照する', () => {
  const ts = readFileSync(join(ROOT, 'lib', 'kit_overlay_resolver.ts'), 'utf8');
  assert.match(ts, /ENABLE_KIT_OVERLAY/, 'TS に ENABLE_KIT_OVERLAY 参照');
  assert.match(ts, /overlayEnabled/, 'TS に overlayEnabled 関数定義');
});

test('L2-b: TS 実装が overlay_of 判定と silently 昇格禁止ロジックを持つ', () => {
  const ts = readFileSync(join(ROOT, 'lib', 'kit_overlay_resolver.ts'), 'utf8');
  assert.match(ts, /overlay_of/, 'TS に overlay_of 判定');
  assert.match(ts, /kit_id.*overlay_of|overlay_of.*kit_id/s, 'TS に kit_id と overlay_of の除外');
  assert.match(ts, /applyOverlay/, 'TS に applyOverlay 関数定義');
});

test('L2-c: TS 実装が off/false/0/no を kill-switch off として認識', () => {
  const ts = readFileSync(join(ROOT, 'lib', 'kit_overlay_resolver.ts'), 'utf8');
  for (const kw of ['off', 'false', '0', 'no']) {
    assert.match(ts, new RegExp(`'${kw}'`), `TS に kill-switch value '${kw}' 認識`);
  }
});

test('L2-d: TS 実装が loadKitWithOverlay / findOverlayFor 公開 API を持つ', () => {
  const ts = readFileSync(join(ROOT, 'lib', 'kit_overlay_resolver.ts'), 'utf8');
  assert.match(ts, /export function loadKitWithOverlay/);
  assert.match(ts, /export function findOverlayFor/);
  assert.match(ts, /export function resolveKitWithOverlay/);
});

test('L2-e: index.ts が scaffoldKit 経路で loadKitWithOverlay を呼ぶ (overlay 消費配線)', () => {
  const idx = readFileSync(join(ROOT, 'lib', 'index.ts'), 'utf8');
  assert.match(idx, /loadKitWithOverlay/, 'index.ts が loadKitWithOverlay を import');
  assert.match(idx, /scaffoldKit[\s\S]{0,500}loadKitWithOverlay/, 'scaffoldKit が loadKitWithOverlay を呼ぶ');
});

// ---------------------------------------------------------------------------
// Layer 3: 統合効果テスト (実 kits/ 上での動線)
// ---------------------------------------------------------------------------

test('L3-a: 実 kits/ の base=medical が listKits() 相当で必ず見える (industry=medical 検索の base 動線)', () => {
  const kitsDir = join(ROOT, 'kits');
  const files = readdirSync(kitsDir).filter((f) => f.endsWith('.json'));
  assert.ok(files.includes('medical.json'), 'medical.json が kits/ に存在');
  const raw = JSON.parse(readFileSync(join(kitsDir, 'medical.json'), 'utf8'));
  assert.equal(raw.kit_id, 'medical');
  assert.equal(raw.industry, 'medical', 'industry=medical で hit する');
});

/**
 * baseline 更新履歴 (更新するときは必ず理由を残すこと)
 *
 * - lib/scaffolder.ts : 02c7992e… → 5f969e85… (2026-08-01)
 *   理由: kit 定義の独自型 `EncryptedString` に対する変換が scaffolder に実装されておらず、
 *         型名がそのまま Prisma スキーマへ出力されていた。Prisma に該当型は無いため
 *         medical / medical_overlay の生成物は `prisma validate` を通らなかった
 *         (要配慮個人情報の暗号化という設計意図が実装に未到達)。
 *         保管型を String (暗号文) にマップし、アプリ層の暗号化実装
 *         (src/lib/crypto/*) を生成物へ同梱する変更を入れたため baseline を更新した。
 *         回帰は tests/prisma_schema_validate_check.mjs が実 `prisma validate` で守る
 *         (旧 scaffolder に戻すと同ゲートが 7 件不合格になることを実走で確認済み)。
 */
test('L3-b: kit_loader.ts / scaffolder.ts / kit.schema.json / skill-sot-guard.sh の SHA-256 baseline 保持', () => {
  const baseline = {
    'lib/kit_loader.ts': '200a678118513b1e11d3250ac93759102ff81138c1b07929ea47e70dca0ed685',
    'lib/scaffolder.ts': '5f969e850828458e6f409d502b0f46e98ace03f267e6293e21911b402a567fdd',
    'schemas/kit.schema.json': '8e63df136f5426dfaf1e769462b28d026bb4db9ecbf872fc3eab7a1a4daf2699',
    'kits/medical.json': 'ae3362b80d07c12d03d172cfa3ebab241c35e42e9e2330f79870e10259b6d7f6',
    'kits/care.json': '82a600799eb5a480fb13b6c78ea7e91e0ba38fc4cf30e23c06e3f9cd1dca3dc7',
  };
  for (const [rel, expected] of Object.entries(baseline)) {
    const path = join(ROOT, rel);
    const buf = readFileSync(path);
    const actual = createHash('sha256').update(buf).digest('hex');
    assert.equal(actual, expected, `${rel} SHA-256 unchanged`);
  }
});

test('L3-c: medical.json 25 キー構造 (実測 baseline) が保持されている', () => {
  const raw = JSON.parse(readFileSync(join(ROOT, 'kits', 'medical.json'), 'utf8'));
  const keys = Object.keys(raw);
  assert.equal(keys.length, 25, `medical.json は 25 キー (実測 baseline)`);
  const expectedKeys = ['kit_id', 'name_ja', 'name_en', 'industry', 'industry_ja', 'description', 'use_case', 'stack', 'domain_dictionary_ref', 'applicable_laws', 'terminology', 'mandatory_fields', 'legal_rules', 'ui_hints', 'prisma_models', 'routes', 'ui_pages', 'api_routes', 'report_templates', 'dashboard_kpis', 'mobile_priority', 'integration_hooks', 'estimated_completion_percent', 'remaining_customizations', 'scaffold_outputs'];
  for (const k of expectedKeys) assert.ok(keys.includes(k), `medical.json に ${k} キー存在`);
});
