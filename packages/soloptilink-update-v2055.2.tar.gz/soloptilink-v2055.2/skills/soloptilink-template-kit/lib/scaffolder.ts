/**
 * soloptilink-template-kit / scaffolder
 *
 * KitDefinition を入力として、ターゲットディレクトリに Next.js 15 ベースの
 * 90% 完成プロジェクトを書き出す。
 *
 *   scaffold(kit, targetDir, options) -> ScaffoldReport
 *
 * 出力ファイル群:
 *   - package.json / tsconfig.json / next.config.ts / tailwind.config.ts
 *   - postcss.config.mjs / .env.example / .gitignore
 *   - prisma/schema.prisma / prisma/seed.ts
 *   - src/app/layout.tsx / src/app/page.tsx (ダッシュボード)
 *   - src/app/(domain)/<resource>/page.tsx (一覧)
 *   - src/app/(domain)/<resource>/[id]/page.tsx (詳細)
 *   - src/app/(domain)/<resource>/new/page.tsx (新規作成)
 *   - src/app/api/<resource>/route.ts (CRUD API)
 *   - src/lib/db.ts / src/lib/validators.ts
 *   - src/components/ui/{button,card,input,label,table}.tsx
 *   - README.md / docs/DESIGN_CONTRACT.md
 */

import { mkdirSync, writeFileSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import type { KitDefinition, KitField, KitPrismaModel, KitRoute } from './kit_loader';

// ---------------------------------------------------------------------------
// 型
// ---------------------------------------------------------------------------

export interface ScaffoldOptions {
  /** ja (default) / en */
  locale?: 'ja' | 'en';
  /** 既存ディレクトリの上書きを許可するか (default: true) */
  overwrite?: boolean;
}

export interface ScaffoldReport {
  kit_id: string;
  target_dir: string;
  files_written: string[];
  total_lines: number;
  setup_minutes: number;
}

// ---------------------------------------------------------------------------
// 内部ユーティリティ
// ---------------------------------------------------------------------------

function ensureDir(dir: string): void {
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
}

function writeOut(absPath: string, content: string, report: ScaffoldReport): void {
  ensureDir(dirname(absPath));
  writeFileSync(absPath, content, 'utf8');
  report.files_written.push(absPath);
  report.total_lines += content.split('\n').length;
}

function toKebabCase(s: string): string {
  return s
    .replace(/([a-z0-9])([A-Z])/g, '$1-$2')
    .replace(/_/g, '-')
    .toLowerCase();
}

function toPascalCase(s: string): string {
  return s
    .replace(/[-_](.)/g, (_, c) => c.toUpperCase())
    .replace(/^(.)/, (_, c) => c.toUpperCase());
}

/**
 * route の path から resource 名を取り出す。
 * "/api/projects" -> "projects"
 * "/projects/[id]" -> "projects"
 */
function resourceFromPath(path: string): string | undefined {
  const segs = path.split('/').filter(Boolean);
  if (segs.length === 0) return undefined;
  if (segs[0] === 'api') return segs[1];
  return segs[0];
}

function uniqueResources(routes: KitRoute[]): string[] {
  const set = new Set<string>();
  for (const r of routes) {
    if (r.type === 'dashboard') continue;
    const res = r.resource ?? resourceFromPath(r.path);
    if (res && !res.includes('[') && !res.includes('dashboard')) {
      set.add(res);
    }
  }
  return Array.from(set).sort();
}

// ---------------------------------------------------------------------------
// Prisma スキーマ生成
// ---------------------------------------------------------------------------

function prismaTypeMap(field: KitField): string {
  const t = field.type;
  // enum 名らしきもの (大文字始まり, "DateTime" 以外)
  if (/^[A-Z][A-Za-z0-9]*$/.test(t) && t !== 'DateTime' && t !== 'String' && t !== 'Int' && t !== 'Float' && t !== 'Decimal' && t !== 'Boolean' && t !== 'Json' && t !== 'Bytes' && t !== 'BigInt') {
    return t; // enum 参照
  }
  return t;
}

function buildPrismaModel(model: KitPrismaModel): string {
  const lines: string[] = [];
  lines.push(`model ${model.model} {`);
  for (const f of model.fields) {
    if (f.name === '@updatedAt') continue;
    if (f.description?.includes('@updatedAt')) {
      lines.push(`  ${f.name} ${prismaTypeMap(f)} @updatedAt`);
      continue;
    }
    let line = `  ${f.name} ${prismaTypeMap(f)}`;
    const opts: string[] = [];
    if (f.required === false) line += '?';
    if (f.unique) opts.push('@unique');
    if (f.name === 'id') opts.push('@id');
    if (f.default !== undefined) {
      const dv = String(f.default);
      if (dv === 'cuid()' || dv === 'uuid()' || dv === 'now()' || dv === 'autoincrement()') {
        opts.push(`@default(${dv})`);
      } else if (/^-?\d+(\.\d+)?$/.test(dv)) {
        opts.push(`@default(${dv})`);
      } else if (dv === 'true' || dv === 'false') {
        opts.push(`@default(${dv})`);
      } else if (/^[A-Z_]+$/.test(dv)) {
        // enum 値
        opts.push(`@default(${dv})`);
      } else {
        opts.push(`@default("${dv}")`);
      }
    }
    if (opts.length > 0) line += ' ' + opts.join(' ');
    if (f.description) line += ` /// ${f.description}`;
    lines.push(line);
  }
  // relations は簡易ヒントのみコメント追加
  if (model.relations && model.relations.length > 0) {
    lines.push('  // relations:');
    for (const r of model.relations) {
      lines.push(`  //   ${r.type} ${r.model}` + (r.field ? ` (field: ${r.field})` : '') + (r.back ? ` (back: ${r.back})` : ''));
    }
  }
  lines.push('}');
  return lines.join('\n');
}

function buildPrismaSchema(kit: KitDefinition): string {
  const enumsCollected = new Map<string, string[]>();
  // 仮の enum 値: status 系はモデルから推測してダミー値を入れておく
  for (const m of kit.prisma_models) {
    for (const f of m.fields) {
      const t = f.type;
      if (/Status|Type|Category|Severity|Action|Outcome|Channel|Method|Priority|Mode|Rank|Source|Stage|Gender|CareLevel|Judgement|Inspection|MovementType|FeeUnit|ReceiptStatus|ApprovalAction|ReimbursementStatus|TaxCategory|StudentStatus|EnrollmentStatus|ExamType/i.test(t)
          && !['DateTime', 'String', 'Int', 'Float', 'Decimal', 'Boolean', 'Json', 'Bytes', 'BigInt'].includes(t)) {
        if (!enumsCollected.has(t)) {
          enumsCollected.set(t, defaultEnumValuesFor(t));
        }
      }
    }
  }

  const out: string[] = [];
  out.push('// Prisma schema generated by soloptilink-template-kit');
  out.push('// kit_id: ' + kit.kit_id);
  out.push('');
  out.push('generator client {');
  out.push('  provider = "prisma-client-js"');
  out.push('}');
  out.push('');
  out.push('datasource db {');
  out.push('  provider = "postgresql"');
  out.push('  url      = env("DATABASE_URL")');
  out.push('}');
  out.push('');
  for (const m of kit.prisma_models) {
    out.push(buildPrismaModel(m));
    out.push('');
  }
  for (const [name, vals] of enumsCollected.entries()) {
    out.push(`enum ${name} {`);
    for (const v of vals) out.push(`  ${v}`);
    out.push('}');
    out.push('');
  }
  return out.join('\n');
}

function defaultEnumValuesFor(name: string): string[] {
  const lname = name.toLowerCase();
  if (lname.includes('projectstatus')) return ['PLANNING', 'IN_PROGRESS', 'COMPLETED', 'ON_HOLD', 'CANCELLED'];
  if (lname.includes('estimatestatus')) return ['DRAFT', 'SENT', 'APPROVED', 'REJECTED'];
  if (lname.includes('purchaseorderstatus') || lname.includes('purchasestatus')) return ['DRAFT', 'SENT', 'CONFIRMED', 'DELIVERED', 'PAID'];
  if (lname.includes('invoicestatus')) return ['DRAFT', 'SENT', 'PAID', 'OVERDUE', 'CANCELLED', 'UNPAID'];
  if (lname.includes('salesorderstatus') || lname === 'salesorderstatus') return ['OPEN', 'IN_PRODUCTION', 'SHIPPED', 'CLOSED', 'CANCELLED'];
  if (lname.includes('productionstatus')) return ['PLANNED', 'IN_PROGRESS', 'INSPECTING', 'DONE', 'CANCELLED'];
  if (lname.includes('inspectiontype')) return ['INCOMING', 'IN_PROCESS', 'FINAL'];
  if (lname.includes('judgement')) return ['OK', 'NG', 'PENDING'];
  if (lname.includes('propertystatus')) return ['AVAILABLE', 'PENDING', 'RENTED', 'SOLD', 'CLOSED'];
  if (lname.includes('propertytype')) return ['APARTMENT', 'HOUSE', 'LAND', 'OFFICE', 'WAREHOUSE', 'SHOP', 'PARKING'];
  if (lname.includes('mediationtype')) return ['EXCLUSIVE_FULL', 'EXCLUSIVE', 'GENERAL'];
  if (lname.includes('leasetype')) return ['NORMAL', 'FIXED_TERM'];
  if (lname.includes('paymentstatus')) return ['PENDING', 'PAID', 'PARTIAL', 'OVERDUE'];
  if (lname.includes('clienttype')) return ['CORPORATION', 'INDIVIDUAL', 'SOLE_PROPRIETOR'];
  if (lname.includes('feeunit')) return ['MONTHLY', 'PER_CASE', 'HOURLY', 'ANNUAL'];
  if (lname.includes('casecategory')) return ['TAX', 'LABOR', 'ADMIN', 'LITIGATION', 'OTHER'];
  if (lname.includes('casestatus')) return ['OPEN', 'IN_PROGRESS', 'WAITING', 'CLOSED'];
  if (lname.includes('auditaction')) return ['VIEW', 'CREATE', 'UPDATE', 'DELETE', 'EXPORT'];
  if (lname.includes('gender')) return ['MALE', 'FEMALE', 'OTHER', 'UNDECLARED'];
  if (lname.includes('carelevel')) return ['SUPPORT_1', 'SUPPORT_2', 'CARE_1', 'CARE_2', 'CARE_3', 'CARE_4', 'CARE_5'];
  if (lname.includes('servicetype')) return ['VISIT_CARE', 'VISIT_NURSING', 'DAY_SERVICE', 'SHORT_STAY', 'OTHER'];
  if (lname.includes('incidentcategory')) return ['FALL', 'MEDICATION', 'CHOKING', 'INFECTION', 'OTHER'];
  if (lname.includes('incidentseverity')) return ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
  if (lname.includes('claimstatus')) return ['DRAFT', 'SUBMITTED', 'ACCEPTED', 'REJECTED', 'PAID'];
  if (lname.includes('planstatus')) return ['DRAFT', 'ACTIVE', 'EXPIRED'];
  if (lname.includes('receiptstatus')) return ['DRAFT', 'SUBMITTED', 'CONFIRMED', 'REBATED'];
  if (lname.includes('studentstatus')) return ['ACTIVE', 'PAUSED', 'WITHDRAWN', 'GRADUATED'];
  if (lname.includes('enrollmentstatus')) return ['ACTIVE', 'COMPLETED', 'CANCELLED'];
  if (lname.includes('examtype')) return ['REGULAR', 'MOCK', 'INTERNAL', 'NATIONAL'];
  if (lname.includes('accountrank')) return ['S', 'A', 'B', 'C'];
  if (lname.includes('leadsource')) return ['WEB', 'REFERRAL', 'EVENT', 'COLD_CALL', 'OTHER'];
  if (lname.includes('leadstatus')) return ['NEW', 'CONTACTED', 'QUALIFIED', 'CONVERTED', 'LOST'];
  if (lname.includes('opportunitystage')) return ['PROSPECT', 'QUALIFY', 'PROPOSAL', 'NEGOTIATE', 'CLOSE'];
  if (lname.includes('opportunityoutcome')) return ['WON', 'LOST', 'CANCELLED'];
  if (lname.includes('activitytype')) return ['VISIT', 'CALL', 'EMAIL', 'MEETING', 'OTHER'];
  if (lname.includes('taskstatus')) return ['TODO', 'IN_PROGRESS', 'DONE', 'CANCELLED'];
  if (lname.includes('priority')) return ['LOW', 'MEDIUM', 'HIGH', 'URGENT'];
  if (lname.includes('orderchannel')) return ['STORE', 'EC', 'PHONE', 'OTHER'];
  if (lname.includes('paymentmethod')) return ['CASH', 'CARD', 'BANK_TRANSFER', 'QR', 'INVOICE'];
  if (lname.includes('orderstatus')) return ['RECEIVED', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED'];
  if (lname.includes('shipmentstatus')) return ['PENDING', 'SHIPPED', 'DELIVERED', 'RETURNED'];
  if (lname.includes('movementtype')) return ['IN', 'OUT', 'ADJUSTMENT', 'WASTE'];
  if (lname.includes('customertype')) return ['INDIVIDUAL', 'CORPORATION'];
  if (lname.includes('expensestatus')) return ['DRAFT', 'PENDING', 'APPROVED', 'REJECTED', 'PAID'];
  if (lname.includes('approvalaction')) return ['APPROVE', 'REJECT', 'COMMENT', 'RETURN'];
  if (lname.includes('reimbursementstatus')) return ['SCHEDULED', 'PAID', 'FAILED'];
  if (lname.includes('taxcategory')) return ['STANDARD', 'REDUCED', 'EXEMPT', 'NONTAXABLE'];
  // フォールバック: 汎用ステータス
  return ['ACTIVE', 'INACTIVE', 'PENDING'];
}

// ---------------------------------------------------------------------------
// 各ファイルの中身ビルダー
// ---------------------------------------------------------------------------

function buildPackageJson(kit: KitDefinition): string {
  const pkg = {
    name: `${kit.kit_id}-app`,
    version: '0.1.0',
    private: true,
    scripts: {
      dev: 'next dev',
      build: 'next build',
      start: 'next start',
      lint: 'next lint',
      'db:generate': 'prisma generate',
      'db:migrate': 'prisma migrate dev',
      'db:seed': 'tsx prisma/seed.ts',
    },
    dependencies: {
      next: '15.0.0',
      react: '19.0.0',
      'react-dom': '19.0.0',
      '@prisma/client': '^5.20.0',
      'next-auth': '^5.0.0-beta.20',
      zod: '^3.23.0',
      clsx: '^2.1.0',
      'class-variance-authority': '^0.7.0',
      'lucide-react': '^0.452.0',
    },
    devDependencies: {
      typescript: '^5.6.0',
      '@types/node': '^22.7.0',
      '@types/react': '^19.0.0',
      '@types/react-dom': '^19.0.0',
      tailwindcss: '^4.0.0',
      postcss: '^8.4.0',
      autoprefixer: '^10.4.0',
      prisma: '^5.20.0',
      tsx: '^4.19.0',
      vitest: '^2.1.0',
      '@biomejs/biome': '^1.9.0',
    },
  };
  return JSON.stringify(pkg, null, 2) + '\n';
}

function buildTsconfig(): string {
  return JSON.stringify(
    {
      compilerOptions: {
        target: 'ES2022',
        lib: ['dom', 'dom.iterable', 'esnext'],
        allowJs: true,
        skipLibCheck: true,
        strict: true,
        noEmit: true,
        esModuleInterop: true,
        module: 'esnext',
        moduleResolution: 'bundler',
        resolveJsonModule: true,
        isolatedModules: true,
        jsx: 'preserve',
        incremental: true,
        plugins: [{ name: 'next' }],
        paths: { '@/*': ['./src/*'] },
      },
      include: ['next-env.d.ts', '**/*.ts', '**/*.tsx', '.next/types/**/*.ts'],
      exclude: ['node_modules'],
    },
    null,
    2,
  ) + '\n';
}

function buildNextConfig(): string {
  return `import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  reactStrictMode: true,
  experimental: {
    typedRoutes: true,
  },
};

export default nextConfig;
`;
}

function buildTailwindConfig(): string {
  return `import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './src/app/**/*.{ts,tsx}',
    './src/components/**/*.{ts,tsx}',
    './src/pages/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};

export default config;
`;
}

function buildPostcss(): string {
  return `export default {
  plugins: {
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
};
`;
}

function buildEnvExample(kit: KitDefinition): string {
  return `# DATABASE
DATABASE_URL="postgresql://user:password@localhost:5432/${kit.kit_id}"

# AUTH (next-auth v5)
AUTH_SECRET="change-me-in-production"
AUTH_URL="http://localhost:3000"

# STORAGE (画像/PDF添付など)
S3_BUCKET=""
S3_REGION=""
S3_ACCESS_KEY=""
S3_SECRET_KEY=""
`;
}

function buildGitignore(): string {
  return `node_modules
.next
.env
.env.local
.DS_Store
dist
coverage
*.log
prisma/dev.db
`;
}

function buildLayout(kit: KitDefinition): string {
  return `import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: '${kit.name_ja}',
  description: '${kit.description.replace(/'/g, "\\'")}',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ja">
      <body className="min-h-screen bg-gray-50 text-gray-900 antialiased">
        <header className="border-b bg-white">
          <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between">
            <h1 className="text-lg font-bold">${kit.name_ja}</h1>
            <nav className="text-sm text-gray-600">
              <a href="/" className="px-2 hover:underline">ダッシュボード</a>
            </nav>
          </div>
        </header>
        <main className="mx-auto max-w-7xl px-4 py-6">{children}</main>
      </body>
    </html>
  );
}
`;
}

function buildGlobalsCss(): string {
  return `@import "tailwindcss";

:root {
  --foreground: 17 24 39;
  --background: 249 250 251;
}
`;
}

function buildDashboardPage(kit: KitDefinition): string {
  const kpis = kit.dashboard_kpis;
  const cards = kpis
    .map(
      (k) =>
        `        <div className="rounded-lg border bg-white p-4 shadow-sm">
          <div className="text-sm text-gray-500">${k}</div>
          <div className="mt-2 text-2xl font-bold">--</div>
        </div>`,
    )
    .join('\n');

  const resources = uniqueResources(kit.routes);
  const navLinks = resources
    .map((r) => `          <a href="/${r}" className="rounded-md border bg-white px-3 py-2 hover:bg-gray-100">${r}</a>`)
    .join('\n');

  return `export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">${kit.name_ja} ダッシュボード</h2>
        <p className="text-sm text-gray-600 mt-1">${kit.description}</p>
      </div>

      <section>
        <h3 className="text-lg font-semibold mb-3">主要KPI</h3>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
${cards}
        </div>
      </section>

      <section>
        <h3 className="text-lg font-semibold mb-3">クイックリンク</h3>
        <nav className="flex flex-wrap gap-2 text-sm">
${navLinks}
        </nav>
      </section>

      <section className="rounded-lg border bg-white p-4 shadow-sm">
        <h3 className="text-lg font-semibold mb-2">残り10%カスタマイズ</h3>
        <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
${(kit.remaining_customizations ?? []).map((c) => `          <li>${c}</li>`).join('\n')}
        </ul>
      </section>
    </div>
  );
}
`;
}

function buildResourceListPage(resource: string, kit: KitDefinition): string {
  const Title = toPascalCase(resource);
  return `import Link from 'next/link';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function ${Title}ListPage() {
  // const items = await prisma.${camelOf(resource)}.findMany({ take: 100, orderBy: { createdAt: 'desc' } });
  const items: Array<{ id: string; name?: string; code?: string }> = [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">${resource} 一覧</h2>
        <Link
          href={\`/${resource}/new\`}
          className="rounded-md bg-blue-600 px-3 py-1.5 text-white text-sm hover:bg-blue-700"
        >
          新規作成
        </Link>
      </div>
      <div className="rounded-lg border bg-white shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-left">
            <tr>
              <th className="px-3 py-2">ID</th>
              <th className="px-3 py-2">コード</th>
              <th className="px-3 py-2">名称</th>
              <th className="px-3 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 ? (
              <tr>
                <td className="px-3 py-6 text-center text-gray-500" colSpan={4}>
                  データがありません
                </td>
              </tr>
            ) : (
              items.map((it) => (
                <tr key={it.id} className="border-t">
                  <td className="px-3 py-2 font-mono text-xs">{it.id}</td>
                  <td className="px-3 py-2">{it.code ?? ''}</td>
                  <td className="px-3 py-2">{it.name ?? ''}</td>
                  <td className="px-3 py-2">
                    <Link href={\`/${resource}/\${it.id}\`} className="text-blue-600 hover:underline">
                      詳細
                    </Link>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
`;
}

function camelOf(resource: string): string {
  // "daily-reports" -> "dailyReport" (Prisma の慣習: model 名は単数だが、ここでは安全策で単純変換)
  const single = resource.endsWith('s') ? resource.slice(0, -1) : resource;
  return single.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
}

function buildResourceDetailPage(resource: string): string {
  const Title = toPascalCase(resource);
  return `import { prisma } from '@/lib/db';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

export default async function ${Title}DetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  // const item = await prisma.${camelOf(resource)}.findUnique({ where: { id } });
  const item: { id: string; name?: string; code?: string } | null = null;

  if (!item) {
    return (
      <div className="space-y-4">
        <h2 className="text-xl font-bold">${resource} 詳細</h2>
        <p className="text-gray-600">データが見つかりません (id: {id})</p>
        <Link href={\`/${resource}\`} className="text-blue-600 hover:underline">一覧に戻る</Link>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">${resource} 詳細</h2>
      <div className="rounded-lg border bg-white p-4 shadow-sm space-y-2 text-sm">
        <div><span className="font-semibold">ID:</span> {item.id}</div>
        <div><span className="font-semibold">コード:</span> {item.code}</div>
        <div><span className="font-semibold">名称:</span> {item.name}</div>
      </div>
      <Link href={\`/${resource}\`} className="text-blue-600 hover:underline">一覧に戻る</Link>
    </div>
  );
}
`;
}

function buildResourceNewPage(resource: string): string {
  const Title = toPascalCase(resource);
  return `'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ${Title}NewPage() {
  const router = useRouter();
  const [submitting, setSubmitting] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitting(true);
    const fd = new FormData(e.currentTarget);
    const payload = Object.fromEntries(fd.entries());
    const res = await fetch('/api/${resource}', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
    });
    setSubmitting(false);
    if (res.ok) router.push('/${resource}');
  }

  return (
    <div className="space-y-4 max-w-xl">
      <h2 className="text-xl font-bold">${resource} 新規作成</h2>
      <form onSubmit={onSubmit} className="space-y-3 rounded-lg border bg-white p-4 shadow-sm">
        <label className="block">
          <span className="text-sm font-medium">コード</span>
          <input name="code" className="mt-1 w-full rounded-md border px-3 py-2 text-sm" required />
        </label>
        <label className="block">
          <span className="text-sm font-medium">名称</span>
          <input name="name" className="mt-1 w-full rounded-md border px-3 py-2 text-sm" required />
        </label>
        <button
          type="submit"
          disabled={submitting}
          className="rounded-md bg-blue-600 px-4 py-2 text-sm text-white hover:bg-blue-700 disabled:opacity-50"
        >
          {submitting ? '送信中…' : '保存'}
        </button>
      </form>
    </div>
  );
}
`;
}

function buildApiRoute(resource: string): string {
  return `import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { z } from 'zod';

const CreateSchema = z.object({
  code: z.string().min(1).max(64),
  name: z.string().min(1).max(255),
});

export async function GET() {
  // const items = await prisma.${camelOf(resource)}.findMany({ take: 100 });
  const items: unknown[] = [];
  return NextResponse.json({ items });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = CreateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  // const created = await prisma.${camelOf(resource)}.create({ data: parsed.data });
  const created = { id: 'demo', ...parsed.data };
  return NextResponse.json({ item: created }, { status: 201 });
}
`;
}

function buildDbLib(): string {
  return `import { PrismaClient } from '@prisma/client';

declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

export const prisma =
  global.__prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') {
  global.__prisma = prisma;
}
`;
}

function buildValidatorsLib(kit: KitDefinition): string {
  // 1 つの代表モデルで zod を生成する (テンプレ示唆)
  const m = kit.prisma_models[0];
  const fields: string[] = [];
  for (const f of m.fields) {
    if (f.name === 'id' || f.name === 'createdAt' || f.name === 'updatedAt') continue;
    let zType = 'z.string()';
    if (f.type === 'Int' || f.type === 'BigInt') zType = 'z.number().int()';
    else if (f.type === 'Float' || f.type === 'Decimal') zType = 'z.number()';
    else if (f.type === 'Boolean') zType = 'z.boolean()';
    else if (f.type === 'DateTime') zType = 'z.coerce.date()';
    else if (f.type === 'Json') zType = 'z.unknown()';
    if (f.required === false) zType += '.optional()';
    fields.push(`  ${f.name}: ${zType},`);
  }
  return `import { z } from 'zod';

/**
 * ${m.model} の zod スキーマ (新規作成 + 部分更新).
 * 他のモデルも同様の形式で追加してください。
 */
export const ${m.model}CreateSchema = z.object({
${fields.join('\n')}
});

export const ${m.model}UpdateSchema = ${m.model}CreateSchema.partial();

export type ${m.model}CreateInput = z.infer<typeof ${m.model}CreateSchema>;
export type ${m.model}UpdateInput = z.infer<typeof ${m.model}UpdateSchema>;
`;
}

function buildShadcnButton(): string {
  return `import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { clsx } from 'clsx';

const buttonVariants = cva(
  'inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 disabled:opacity-50',
  {
    variants: {
      variant: {
        default: 'bg-blue-600 text-white hover:bg-blue-700',
        outline: 'border bg-white hover:bg-gray-50',
        ghost: 'hover:bg-gray-100',
      },
      size: {
        default: 'h-9 px-4',
        sm: 'h-8 px-3 text-xs',
        lg: 'h-10 px-6',
      },
    },
    defaultVariants: { variant: 'default', size: 'default' },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, ...props }, ref) => (
    <button ref={ref} className={clsx(buttonVariants({ variant, size }), className)} {...props} />
  ),
);
Button.displayName = 'Button';
`;
}

function buildShadcnCard(): string {
  return `import * as React from 'react';
import { clsx } from 'clsx';

export const Card = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={clsx('rounded-lg border bg-white shadow-sm', className)} {...props} />
  ),
);
Card.displayName = 'Card';

export const CardHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={clsx('p-4 border-b', className)} {...props} />
);

export const CardTitle = ({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) => (
  <h3 className={clsx('text-lg font-semibold', className)} {...props} />
);

export const CardContent = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={clsx('p-4', className)} {...props} />
);
`;
}

function buildShadcnInput(): string {
  return `import * as React from 'react';
import { clsx } from 'clsx';

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => (
    <input
      ref={ref}
      className={clsx('w-full rounded-md border px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500', className)}
      {...props}
    />
  ),
);
Input.displayName = 'Input';
`;
}

function buildShadcnLabel(): string {
  return `import * as React from 'react';
import { clsx } from 'clsx';

export const Label = React.forwardRef<HTMLLabelElement, React.LabelHTMLAttributes<HTMLLabelElement>>(
  ({ className, ...props }, ref) => (
    <label ref={ref} className={clsx('text-sm font-medium', className)} {...props} />
  ),
);
Label.displayName = 'Label';
`;
}

function buildShadcnTable(): string {
  return `import * as React from 'react';
import { clsx } from 'clsx';

export const Table = ({ className, ...props }: React.HTMLAttributes<HTMLTableElement>) => (
  <table className={clsx('w-full text-sm', className)} {...props} />
);
export const THead = ({ className, ...props }: React.HTMLAttributes<HTMLTableSectionElement>) => (
  <thead className={clsx('bg-gray-50 text-left', className)} {...props} />
);
export const TBody = ({ className, ...props }: React.HTMLAttributes<HTMLTableSectionElement>) => (
  <tbody className={className} {...props} />
);
export const Tr = ({ className, ...props }: React.HTMLAttributes<HTMLTableRowElement>) => (
  <tr className={clsx('border-t', className)} {...props} />
);
export const Th = ({ className, ...props }: React.ThHTMLAttributes<HTMLTableCellElement>) => (
  <th className={clsx('px-3 py-2 font-semibold', className)} {...props} />
);
export const Td = ({ className, ...props }: React.TdHTMLAttributes<HTMLTableCellElement>) => (
  <td className={clsx('px-3 py-2', className)} {...props} />
);
`;
}

function buildSeed(kit: KitDefinition): string {
  // 1 つ目のモデルから 3 件のダミーデータを作る
  const m = kit.prisma_models[0];
  const camel = camelOf(toKebabCase(m.model));
  const sampleField = m.fields.find((f) => f.name === 'name' || f.name === 'title') ?? m.fields[1] ?? m.fields[0];
  const codeField = m.fields.find((f) => f.name === 'code');
  const samples: string[] = [];
  for (let i = 1; i <= 3; i += 1) {
    const obj: Record<string, string> = {};
    if (codeField) obj[codeField.name] = `${kit.kit_id.toUpperCase()}-${String(i).padStart(3, '0')}`;
    if (sampleField && sampleField.name !== codeField?.name) obj[sampleField.name] = `サンプル ${i}`;
    samples.push(
      '    ' + JSON.stringify(obj).replace(/"([^"]+)":/g, '$1:'),
    );
  }
  return `import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const samples = [
${samples.join(',\n')},
  ];
  for (const data of samples) {
    // await prisma.${camel}.upsert({ where: { code: (data as any).code }, update: data, create: data });
    console.log('seed sample:', data);
  }
  console.log('seeded ${samples.length} ${m.model} sample(s).');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
`;
}

function buildReadme(kit: KitDefinition): string {
  return `# ${kit.name_ja}

${kit.description}

## クイックスタート

\`\`\`bash
# 1. 依存関係インストール
npm install

# 2. 環境変数
cp .env.example .env
# DATABASE_URL を編集してください

# 3. DB セットアップ
npm run db:generate
npm run db:migrate
npm run db:seed

# 4. 開発サーバー
npm run dev
# -> http://localhost:3000
\`\`\`

## 含まれるもの (90% 完成)

- ${kit.scaffold_outputs.files_count} files / 約 ${kit.scaffold_outputs.lines_count_approx} 行
- セットアップ目安: ${kit.scaffold_outputs.estimated_setup_minutes} 分
- 完成度: ${kit.estimated_completion_percent}%

### 主要ページ

${kit.routes.map((r) => `- \`${r.path}\` — ${r.purpose}`).join('\n')}

### Prisma モデル

${kit.prisma_models.map((m) => `- **${m.model}**${m.description ? ` — ${m.description}` : ''}`).join('\n')}

### ダッシュボード KPI

${kit.dashboard_kpis.map((k) => `- ${k}`).join('\n')}

### 帳票テンプレート

${kit.report_templates.map((r) => `- ${r}`).join('\n')}

## 適用法令

${kit.applicable_laws.map((l) => `- ${l}`).join('\n')}

## 残り 10% カスタマイズ

${(kit.remaining_customizations ?? []).map((c) => `- ${c}`).join('\n')}

## ライセンス

このプロジェクトは soloptilink-template-kit によって生成されました。
詳細は docs/DESIGN_CONTRACT.md を参照してください。
`;
}

function buildDesignContract(kit: KitDefinition): string {
  return `# 設計契約 (DESIGN CONTRACT)

> 本ドキュメントは soloptilink-template-kit が出力した設計の根拠を示します。
> kit_id: \`${kit.kit_id}\` / 生成日: \`${new Date().toISOString().slice(0, 10)}\`

## 1. プロジェクト概要

- **名称**: ${kit.name_ja}
- **業種**: ${kit.industry_ja ?? kit.industry}
- **完成度**: ${kit.estimated_completion_percent}%
- **想定ユースケース**: ${kit.use_case}

## 2. 技術スタック

${Object.entries(kit.stack)
  .map(([k, v]) => `- **${k}**: ${v}`)
  .join('\n')}

## 3. 適用法令

${kit.applicable_laws.map((l) => `- ${l}`).join('\n')}

## 4. ドメイン辞書

本キットは \`${kit.domain_dictionary_ref}\` を参照しています。
用語/必須項目/法令ルールはこの辞書のスキーマに基づきます。

## 5. 機能一覧

### ページ (UI)

${kit.routes.filter((r) => r.type !== 'api').map((r) => `- \`${r.path}\` — ${r.purpose}`).join('\n')}

### API

${kit.routes.filter((r) => r.type === 'api').map((r) => `- \`${r.path}\` — ${r.purpose}`).join('\n')}

## 6. データモデル

${kit.prisma_models
  .map((m) => {
    const head = `### ${m.model}${m.description ? ` — ${m.description}` : ''}`;
    const fields = m.fields
      .map((f) => `- \`${f.name}\`: ${f.type}${f.required === false ? ' (optional)' : ''}${f.description ? ` — ${f.description}` : ''}`)
      .join('\n');
    return `${head}\n\n${fields}`;
  })
  .join('\n\n')}

## 7. ダッシュボード KPI

${kit.dashboard_kpis.map((k) => `- ${k}`).join('\n')}

## 8. 帳票テンプレート

${kit.report_templates.map((r) => `- ${r}`).join('\n')}

## 9. 残り 10% カスタマイズ

${(kit.remaining_customizations ?? []).map((c) => `- ${c}`).join('\n')}

## 10. テスト方針

- 単体テスト: vitest
- E2E テスト: playwright (任意)
- リント: biome

## 11. 受け入れ基準

- \`npm run dev\` がエラーなく起動する
- 主要ページの SSR が成功する (status 200)
- 一覧ページからの新規作成→詳細表示の往復が成功する
- Prisma migrate + seed が完了する
`;
}

// ---------------------------------------------------------------------------
// 公開 API
// ---------------------------------------------------------------------------

/**
 * KitDefinition を targetDir に書き出す。
 */
export function scaffold(
  kit: KitDefinition,
  targetDir: string,
  options: ScaffoldOptions = {},
): ScaffoldReport {
  const overwrite = options.overwrite ?? true;
  if (existsSync(targetDir) && !overwrite) {
    throw new Error(`target directory already exists: ${targetDir}`);
  }
  const report: ScaffoldReport = {
    kit_id: kit.kit_id,
    target_dir: targetDir,
    files_written: [],
    total_lines: 0,
    setup_minutes: kit.scaffold_outputs.estimated_setup_minutes,
  };

  ensureDir(targetDir);

  // ルート
  writeOut(join(targetDir, 'package.json'), buildPackageJson(kit), report);
  writeOut(join(targetDir, 'tsconfig.json'), buildTsconfig(), report);
  writeOut(join(targetDir, 'next.config.ts'), buildNextConfig(), report);
  writeOut(join(targetDir, 'tailwind.config.ts'), buildTailwindConfig(), report);
  writeOut(join(targetDir, 'postcss.config.mjs'), buildPostcss(), report);
  writeOut(join(targetDir, '.env.example'), buildEnvExample(kit), report);
  writeOut(join(targetDir, '.gitignore'), buildGitignore(), report);
  writeOut(join(targetDir, 'README.md'), buildReadme(kit), report);

  // docs
  writeOut(join(targetDir, 'docs', 'DESIGN_CONTRACT.md'), buildDesignContract(kit), report);

  // prisma
  writeOut(join(targetDir, 'prisma', 'schema.prisma'), buildPrismaSchema(kit), report);
  writeOut(join(targetDir, 'prisma', 'seed.ts'), buildSeed(kit), report);

  // src/lib
  writeOut(join(targetDir, 'src', 'lib', 'db.ts'), buildDbLib(), report);
  writeOut(join(targetDir, 'src', 'lib', 'validators.ts'), buildValidatorsLib(kit), report);

  // src/components/ui
  writeOut(join(targetDir, 'src', 'components', 'ui', 'button.tsx'), buildShadcnButton(), report);
  writeOut(join(targetDir, 'src', 'components', 'ui', 'card.tsx'), buildShadcnCard(), report);
  writeOut(join(targetDir, 'src', 'components', 'ui', 'input.tsx'), buildShadcnInput(), report);
  writeOut(join(targetDir, 'src', 'components', 'ui', 'label.tsx'), buildShadcnLabel(), report);
  writeOut(join(targetDir, 'src', 'components', 'ui', 'table.tsx'), buildShadcnTable(), report);

  // src/app/layout, page, globals.css
  writeOut(join(targetDir, 'src', 'app', 'layout.tsx'), buildLayout(kit), report);
  writeOut(join(targetDir, 'src', 'app', 'page.tsx'), buildDashboardPage(kit), report);
  writeOut(join(targetDir, 'src', 'app', 'globals.css'), buildGlobalsCss(), report);

  // resources
  const resources = uniqueResources(kit.routes);
  for (const r of resources) {
    const base = join(targetDir, 'src', 'app', '(domain)', r);
    writeOut(join(base, 'page.tsx'), buildResourceListPage(r, kit), report);
    writeOut(join(base, '[id]', 'page.tsx'), buildResourceDetailPage(r), report);
    writeOut(join(base, 'new', 'page.tsx'), buildResourceNewPage(r), report);

    // API
    writeOut(
      join(targetDir, 'src', 'app', 'api', r, 'route.ts'),
      buildApiRoute(r),
      report,
    );
  }

  return report;
}
