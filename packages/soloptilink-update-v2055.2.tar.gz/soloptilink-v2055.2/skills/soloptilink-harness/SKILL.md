---
name: soloptilink-harness
description: "SoloptiLinkAI v2055.2 - 「ハーネスセットアップ」「テスト実行」「品質チェック」「ハーネスで確認」等で起動。ZIP展開→本体更新→ハーネス配置→テスト→修復を100%達成まで自動ループする統合セットアップ。"
argument-hint: "[ZIPパス or 'test' or 'heal' or 'sync']"
allowed-tools: Bash, Read, Write, Edit, Glob, Grep, Agent
---

# SoloptiLinkAI v2055.2 - テストハーネス統合セットアップスキル (harness-engine v26.0)


## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

## 機能概要

SoloptiLinkAI + テストハーネス統合セットアップ v26.0 - ZIPから展開→本体更新→ハーネス配置→テスト実行→失敗修復→100%達成まで自動ループ。「ハーネスセットアップ」「テスト実行」「品質チェック」「ハーネスで確認」等で使用。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

## 概要
SoloptiLinkAI本体とテストハーネスを統合的にセットアップ・テスト・修復するスキル。
「ハーネスセットアップして」の一言で全自動。

## 実行フロー

### Step 1: 環境検出
```bash
# SoloptiLinkAI本体の存在確認
SL="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
[[ -d "$SL" ]] && echo "本体: $SL ($(head -1 $SL/VERSION 2>/dev/null))" || echo "本体未インストール"

# プロジェクトディレクトリの検出
PROJECT=$(pwd)
[[ -f "$PROJECT/harness.sh" ]] && echo "ハーネス: $PROJECT/harness.sh (v$(grep HARNESS_VERSION $PROJECT/harness.sh | head -1 | grep -o '[0-9.]*'))" || echo "ハーネス未検出"
```

### Step 2: ZIPからのセットアップ（引数にZIPパスがある場合）
1. ZIPを一時ディレクトリに展開
2. `harness.sh` → プロジェクトルートにコピー
3. `.harness/` → プロジェクトルートにコピー
4. CI設定 → `.github/`, `.circleci/`, `.gitlab-ci.yml` にコピー
5. `lib/*.sh` → `~/.soloptilink/lib/` に同期
6. `chain.sh` → `~/.soloptilink/chain.sh` に同期
7. テスト用ファイル → `~/.soloptilink/tests/` に同期

### Step 3: テスト実行
```bash
cd "$PROJECT" && ./harness.sh full 2>&1
```

### Step 4: 失敗があれば自動修復
失敗パターン別の修復:
- **モジュールロード失敗**: `_mr_register` の引数形式を名前付きに変換
- **バージョン不整合**: `chain.sh`のVERSIONを`lib/core/`ヘッダに反映
- **関数/API不在**: `chain.sh`にスタブ関数を追加

### Step 5: 再テスト → 100%確認
修復後に `./harness.sh full` を再実行。100%になるまで最大3ループ。

### Step 6: 同期確認
```bash
./harness.sh sync
```
プロジェクト↔本体の差分がゼロであることを確認。

## サブコマンド対応

引数に応じて実行内容を変える:
- `(なし)` or `setup`: フルセットアップ（Step 1-6）
- `test`: テストのみ実行（Step 3）
- `heal`: テスト失敗の自動修復（Step 4）
- `sync`: 同期チェック（Step 6）
- `sync apply`: プロジェクト→本体に同期
- `sync pull`: 本体→プロジェクトに同期
- `status`: 現在の状態レポート

## 出力
- テスト結果サマリー（パス率、失敗件数、ドメイン別健全性）
- 修復レポート（修復した内容と結果）
- 同期レポート（差分ファイル一覧）
