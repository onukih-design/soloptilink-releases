#!/usr/bin/env bash
# ============================================================================
# Migration v2054_pfp178_cgate_timeout — 完成ゲート Stop hook の timeout 遡及是正
# ============================================================================
# 背景 (PFP-178 / NDC事案 2026-07-23):
#   完成ゲート (boost-completion-gate-hook.sh) の本体処理は実測66秒以上かかるが、
#   Stop hook の timeout は未指定 (ハーネス既定60秒) または 30秒 で登録されており、
#   ブロック判定が出力される前にプロセスごと殺され「完成宣言が無審査で素通り」していた。
#   hook 本体は v2054.5 で watchdog+予算自己較正により時間内判定を自力保証するが、
#   フル検証を時間内に完走させるため timeout も 240秒 へ遡及是正する。
# 冪等: 既に 240 以上なら NOOP。settings.json が無い/壊れている場合は安全に素通り。
# ============================================================================
set -uo pipefail

MIG_NAME="v2054_pfp178_cgate_timeout"
SL_DIR="$HOME/.soloptilink"
STATE_FILE="$SL_DIR/.migration-state.json"
mig_log() { printf '[%s] %s %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || echo '-')" "$MIG_NAME" "$1"; }

# 顧客環境依存ガード (customer-env-lint / v2052.5 事案クラス): python3 不在の顧客端末では
# この timeout 昇格 migration を安全にスキップする。昇格が無くても完成ゲート hook の watchdog
# 外殻がハーネス既定 timeout (60s) から締切を引いてフェイルクローズするため、判定消失は起きない
# (PFP-178 の多層防御)。python3 が在る環境でのみ 240 秒へ昇格して余裕を持たせる。
if ! command -v python3 >/dev/null 2>&1; then
  mig_log "SKIP_NO_PYTHON3 (watchdog がハーネス既定 timeout でフェイルクローズするため安全)"
  exit 0
fi

# R6 (refuter): settings.json と settings.local.json を両方是正する。Claude Code は
# settings.local.json を後勝ちで適用するため、local に低 timeout の Stop hook が登録されて
# いると main だけ 240 にしても実効 timeout は local の低い値のまま (watchdog がその低値で
# フェイルクローズするので判定消失はしないが、余裕を持たせるため両方を 240 へ揃える)。
_MIG_TOUCHED_ANY=0
for SETTINGS_FILE in "$HOME/.claude/settings.json" "$HOME/.claude/settings.local.json"; do
[ -f "$SETTINGS_FILE" ] || continue

RESULT="$(SETTINGS_FILE="$SETTINGS_FILE" python3 - <<'PY' 2>/dev/null
import json, os
sp = os.environ["SETTINGS_FILE"]
try:
    with open(sp) as f:
        d = json.load(f)
except Exception:
    print("ABORT_UNREADABLE"); raise SystemExit
if not isinstance(d, dict):
    print("ABORT_NOT_DICT"); raise SystemExit
changed = 0
for m in (d.get("hooks", {}).get("Stop") or []):
    for h in (m.get("hooks") or []):
        if "boost-completion-gate-hook.sh" in (h.get("command") or ""):
            try:
                cur = int(h.get("timeout") or 0)
            except Exception:
                cur = 0
            if cur < 240:
                h["timeout"] = 240
                changed += 1
if changed:
    tmp = sp + ".tmp-pfp178"
    with open(tmp, "w") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(tmp, sp)
    print("APPLIED:%d" % changed)
else:
    print("NOOP_ALREADY_OK")
PY
)" || { mig_log "PY_FAILED ($SETTINGS_FILE / retryable)"; continue; }

mig_log "RESULT $(basename "$SETTINGS_FILE")=${RESULT:-empty}"
case "$RESULT" in APPLIED:*|NOOP_ALREADY_OK) _MIG_TOUCHED_ANY=1 ;; esac
done   # for SETTINGS_FILE

if [ "$_MIG_TOUCHED_ANY" = "1" ]; then
        RESULT="NOOP_ALREADY_OK"
else
        RESULT="SKIP_NO_SETTINGS"
fi

case "$RESULT" in
    APPLIED:*|NOOP_ALREADY_OK)
        if [ -f "$STATE_FILE" ]; then
            STATE_FILE="$STATE_FILE" MIG_NAME="$MIG_NAME" python3 -c "
import json, os
p = os.environ['STATE_FILE']
try:
    with open(p) as f:
        d = json.load(f)
except Exception:
    d = {}
a = d.setdefault('applied', [])
if os.environ['MIG_NAME'] not in a:
    a.append(os.environ['MIG_NAME'])
with open(p, 'w') as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
" 2>/dev/null || echo "{\"applied\":[\"$MIG_NAME\"]}" > "$STATE_FILE"
        else
            echo "{\"applied\":[\"$MIG_NAME\"]}" > "$STATE_FILE"
        fi
        mig_log "APPLIED_STATE_RECORDED"
        ;;
    *)
        mig_log "NOT_RECORDED (${RESULT:-empty}) — 次回再試行"
        ;;
esac

exit 0
