---
name: soloptilink-template-kit
description: "SoloptiLinkAI v2055.1 - 「テンプレ」「ひな形」「90%完成」「工事台帳」「物件管理」「介護記録」「レセプト」「学籍管理」「経費精算」「kit」等で起動。中小企業の基幹システム10種を90%完成テンプレで3分立ち上げする。"
argument-hint: "[--kit construction|drawing|manufacturing|real_estate|legal|care|medical|education|crm|order|expense] [--target-dir <dir>] [--list] [--describe <kit>] [--locale ja|en]"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, Agent"
---

# SoloptiLinkAI v2055.1 - Template Kit (90%完成スキャフォールドエンジン)


## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

## 機能概要

SoloptiLinkAI v1.0 Template Kit - 日本の中小企業がよく作る基幹システム10種を「90%完成テンプレ」として3分でスキャフォールド。Claude Code が毎回フルスクラッチで生成するのに対し、本スキルは業種別の「あと10%だけカスタマイズすれば動く」プロジェクトを即座に立ち上げる。10種kit: 工事台帳/受発注台帳/物件管理/案件管理/介護記録/レセプト管理/学籍管理/顧客管理/受注管理/経費精算。「テンプレ」「スキャフォールド」「ひな形」「90%完成」「3分で立ち上げ」「工事台帳」「物件管理」「介護記録」「レセプト」「学籍管理」「受発注台帳」「案件管理」「顧客管理」「経費精算」「受注管理」「kit」「ベース作って」等で起動。営業現場で『これすぐ使えます』と言える瞬間を作る対 Claude Code 差別化スキル。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

Claude Code が毎回フルスクラッチでコード生成するのに対して、本スキルは**日本の中小企業がよく作る基幹システム**を業種別 90% 完成テンプレとして即座に立ち上げる。3分後には `npm install && npm run dev` で動くプロジェクトが手に入る。営業現場で「これすぐ使えます」と言える瞬間を作る、対 Claude Code 差別化戦略の中核施策。

## 対 Claude Code 差別化

| 観点 | Claude Code | SoloptiLinkAI Template Kit |
|------|-------------|---------------------------|
| 業種知識 | 一般論 | ✅ 日本の業種辞書 (建設業法/宅建業法/介護保険法...) を埋め込み済み |
| 起動速度 | フルスクラッチ毎回数十分 | ✅ 3分で 30+ ファイル生成 |
| 法令適合 | 都度プロンプトで指示 | ✅ kit 設計時に法令ルール反映済 |
| 帳票テンプレ | 都度生成 | ✅ 工事日報/レセプト/ケアプラン等を最初から内蔵 |
| ダッシュボード KPI | 都度議論 | ✅ 業種別 KPI を最初から配線 |
| 残作業 | 全工程 | ✅ ロゴ/カラー/勘定科目連携先 等の 10% のみ |

### kit_id 命名規則 (schemas/kit.schema.json '^[a-z][a-z_]+$' 準拠)

- snake_case のみ・**数字非許容** (kit.schema.json L27 pattern 実測)
- 誤例: `medical_v2` (数字含・違反) / `MedicalOverlay` (大文字違反)
- 正例: `medical_overlay` / `dispensing_pharmacy` / `home_nursing`

## 利用可能な14種 Kit (2026-08-01 図面管理を追加)

| kit_id | 日本語名 | 業種 | 想定ユーザー |
|--------|---------|------|-------------|
| construction | 工事台帳キット | 建設業 | 工務店/建設会社 |
| drawing | 図面管理キット | 建設業 (図面管理) | 図面が実在する案件を持つ工務店/建設会社/専門工事業者/設計事務所 |
| manufacturing | 受発注台帳キット | 製造業 | 中小製造業/部品メーカー |
| real_estate | 物件管理キット | 不動産業 | 賃貸/売買仲介/管理会社 |
| legal | 案件管理キット | 士業 | 税理士/社労士/行政書士/弁護士事務所 |
| care | 介護記録キット | 介護 | 訪問介護/居宅介護支援/特養 |
| medical | レセプト管理キット (医科・base) | 医療 | 診療所/クリニック |
| medical_overlay | レセプト管理キット (医科・overlay) | 医療 | Phase Bエンジン接地レイヤ (base=medical に自動適用) |
| dispensing_pharmacy | 調剤薬局キット | 医療 (調剤) | 保険薬局/院内薬剤部 |
| home_nursing | 訪問看護キット | 医療/介護 | 訪問看護ステーション |
| education | 学籍管理キット | 教育 | 学習塾/予備校/家庭教師 |
| crm | 顧客管理キット | B2B営業 | 中小SaaS/SIer/卸売 |
| order | 受注管理キット | 一般 | 小売/卸売/EC |
| expense | 経費精算キット | 一般 | バックオフィス共通 |

## コマンド

```bash
# 1. 全 kit を一覧
/soloptilink-template-kit --list

# 2. kit の詳細を見る
/soloptilink-template-kit --describe construction

# 3. 工事台帳キットを /tmp/my-app/ にスキャフォールド
/soloptilink-template-kit --kit construction --target-dir /tmp/my-app

# 4. 多言語化 (英語UI)
/soloptilink-template-kit --kit crm --target-dir /tmp/my-crm --locale en
```

## 各 kit に含まれるもの

```
my-app/
├── package.json                     # Next.js 15 + Prisma 5 + Tailwind v4 + shadcn/ui v2 + Auth.js v5 + zod
├── tsconfig.json
├── next.config.ts
├── tailwind.config.ts
├── postcss.config.mjs
├── prisma/
│   ├── schema.prisma                # kit の prisma_models から生成
│   └── seed.ts                      # サンプルデータ 3件以上
├── src/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx                 # ダッシュボード (業種別 KPI)
│   │   ├── (domain)/<resource>/page.tsx          # 一覧
│   │   ├── (domain)/<resource>/[id]/page.tsx     # 詳細
│   │   ├── (domain)/<resource>/new/page.tsx      # 新規作成
│   │   └── api/<resource>/route.ts               # CRUD API
│   ├── lib/
│   │   ├── db.ts                    # Prisma client
│   │   └── validators.ts            # zod
│   └── components/
│       └── ui/                      # shadcn/ui v2
├── docs/
│   └── DESIGN_CONTRACT.md           # 機能一覧/適用法令/残り10%
├── README.md                        # セットアップ手順
└── .env.example
```

## 出力規模 (例: 工事台帳キット)

- ファイル数: 30+
- 行数: ~4500
- セットアップ時間: 3分
- 完成度: 90% (残作業: ロゴ/カラー/勘定科目連携先)

## 内部アーキテクチャ

```
soloptilink-template-kit/
├── SKILL.md                       # 本ファイル
├── README.md                      # スキル概要
├── kits/                          # 14種 kit 設計図 (2026-08-01: 図面管理を追加)
│   ├── construction.json
│   ├── drawing.json               # 図面管理 (2026-08-01 新設・T-018)
│   ├── manufacturing.json
│   ├── real_estate.json
│   ├── legal.json
│   ├── care.json
│   ├── medical.json               # base=医科レセプト
│   ├── medical_overlay.json       # overlay (medical に engine_refs+phase_c_disclosure を上乗せ)
│   ├── dispensing_pharmacy.json   # 調剤薬局レセプト (2026-07-09 新設)
│   ├── home_nursing.json          # 訪問看護 (2026-07-09 新設)
│   ├── education.json
│   ├── crm.json
│   ├── order.json
│   └── expense.json
├── lib/
│   ├── kit_loader.ts              # JSON Schema 検証 + 一覧/詳細 (無編集・SHA-256 baseline 維持)
│   ├── scaffolder.ts              # ディレクトリ生成エンジン (SHA-256 baseline 管理・変更時は理由記載+baseline 更新)
│   ├── kit_overlay_resolver.ts    # 2026-07-09 新設 — overlay 非破壊マージ + kill-switch ENABLE_KIT_OVERLAY
│   └── index.ts                   # 公開API: scaffoldKit() → loadKitWithOverlay 経由に更新
├── schemas/
│   └── kit.schema.json            # KitDefinition の JSON Schema (無編集・SHA-256 baseline 維持)
├── examples/
│   ├── 01_construction_scaffold.ts
│   └── 02_list_kits.ts
└── tests/
    ├── template_kit_check.mjs     # node:test (33 ケース)
    ├── kit_overlay_check.mjs      # 2026-07-09 新設 — overlay 両側弁別 born-passing (14 ケース)
    └── prisma_schema_validate_check.mjs  # 2026-08-01 新設 — 全 kit を展開し実 prisma validate (24 ケース)
```

## ドメイン辞書連携

各 kit は `~/.claude/skills/soloptilink-japan/domains/` の業種辞書を参照:

| kit_id | 参照辞書 |
|--------|---------|
| construction | construction.json |
| drawing | construction.json (図面管理は工事案件と同じ建設業辞書を参照) |
| manufacturing | manufacturing.json |
| real_estate | real_estate.json |
| legal | professional.json |
| care | healthcare.json + longterm_care |
| medical | healthcare.json + pharmacy.json |
| medical_overlay | healthcare.json (base=medical の overlay) |
| dispensing_pharmacy | pharmacy.json |
| home_nursing | healthcare.json (医療分) + longterm_care (介護分) |
| education | education.json |
| crm | retail.json (顧客管理参考) |
| order | retail.json + manufacturing.json |
| expense | hr.json (経費精算は人事労務領域) |

これにより、用語/必須フィールド/法令ルール/帳票テンプレが日本のリアルな業務に合致する。

## 図面管理キット (drawing) の設計規約 (2026-08-01 新設・T-018)

### 位置づけ: construction の拡張ではなく単独 kit

図面が実在する案件で必要になる機能は `lib/drawing-link/manifest.json` に要件として定義済みだったが、雛形が無いため毎回ゼロから作られていた。これを 90% 完成テンプレとして起こしたもの。

- **construction.json を拡張しなかった理由**: manifest の policy に「図面が無い案件では完全な no-op (過剰注入しない)」とある。construction に図面 5 モデルを混ぜると、図面が存在しない工事案件にも図面テーブルが常時生成され、この原則に反する。
- **overlay (overlay_of: construction) にしなかった理由**: overlay は base kit_id を指定した全ての展開に自動適用される。つまり図面の無い工事案件にも必ず乗るため、同じく no-op 原則に反する。
- **単独 kit にした結果**: 図面が実在する案件でのみ `--kit drawing` を選択する。工事台帳と併用する場合は `DrawingProjectLink.projectCode` (工事番号) と `projectId` で construction の `Project` と相互参照する。

### 単価を製品側で作らない (最重要・破ると誤った見積が出る)

図面から決まるのは**数量だけ**である。単価・歩掛り・許容差の閾値は**利用者入力**とし、製品側で数値を作らない。

| 製品側が算出してよい | 利用者が入力する |
|---------------------|-----------------|
| 数量 / 面積 / 周長 / 個数 / 長さ | 単価 / 歩掛り / 許容差の閾値 / 金額 |

- `QuantityTakeoff.unitPrice` / `.amount` / `AreaDiscrepancy.toleranceRate` は **既定値を持たない任意フィールド**とする
- UI は単価欄を空欄で初期表示し、利用者が入力するまで金額を算出しない
- 恒久ゲート: `tests/template_kit_check.mjs` の「単価・金額・許容差の閾値に既定値を持たない」で既定値の混入を検出する (欠陥注入で不合格になることを実証済み)

### 面積不一致アラート (図面案件の中核価値)

`AreaDiscrepancy` は図面に**記載された**面積 (`notedArea`) と、読み取って**算出した**面積 (`computedArea`) の両方を保持し、差と差率を持つ。記載と作図の食い違いは見積誤りに直結するため、`blocksEstimate` により**見積を確定する前に確認を促す**。確認結果は `judgement` (OK/NG/PENDING) に記録する。

### scaffolder 契約への適合 (scaffolder.ts は SHA-256 baseline 管理)

`lib/scaffolder.ts` は原則無編集 (SHA-256 baseline 固定) のため、生成される Prisma が妥当になるよう **kit 定義側**で以下を守る:

- **enum 型名は `defaultEnumValuesFor()` が解決できるものだけを使う**。drawing kit は `DrawingStatus` (→ ACTIVE/INACTIVE/PENDING) と `Judgement` (→ OK/NG/PENDING) のみを使い、既定値は必ずその値集合に含める。解決されない新 enum 名を使うと、生成される `@default(...)` が enum に存在しない値になり `prisma validate` が落ちる。
- **String 型に全大文字の既定値を置かない**。scaffolder は `/^[A-Z_]+$/` の既定値を enum 値とみなし引用符なしで出力するため、`field String @default(ACTIVE)` となり不正になる。分類値は String + 説明での列挙とし、既定値を置かないか非全大文字にする。
- **scaffolder が解釈できない独自型を新設しない**。現在 scaffolder が解釈する独自型は `EncryptedString` のみ (下記)。それ以外の未知の型名はそのまま Prisma へ出力され `prisma validate` が落ちる。
- 上記は `tests/template_kit_check.mjs` の生成器契約ガードと、`tests/prisma_schema_validate_check.mjs` の実 `prisma validate` で全 kit を横断的に検査する。

#### baseline を更新してよい場合と手順

kit 定義側で回避できない欠陥 (生成器そのものの実装漏れ) を直す場合に限り、scaffolder.ts を変更してよい。手順:

1. 変更前に両ミラーをバックアップする (`~/.soloptilink/.backups/`)
2. `node tests/prisma_schema_validate_check.mjs` で **変更前の実測**を取る (どの kit が落ちているか)
3. 実装後、同ゲートで全 kit PASS を実走確認する
4. `tests/kit_overlay_check.mjs` の `L3-b` baseline を新 SHA-256 に更新し、**更新理由をコメントで残す**
5. **旧実装へ戻すとゲートが落ちること**を実走で確認する (両側判定・ゲートが飾りでないことの証明)
6. 本体 `~/.soloptilink/skills/` と配布ミラー `~/.claude/skills/` の両方を同期する
   (SKILL.md の SoT は `~/.claude/commands/soloptilink-template-kit.md`。ここを直さないと
    skill-sot-guard の heal が両ミラーを旧版へ巻き戻す)

### 要配慮個人情報の暗号化 (独自型 `EncryptedString`)

kit 定義の `type: "EncryptedString"` は、**要配慮個人情報を at-rest 暗号化して保管する**フィールドの宣言。
medical_overlay が SOAP 診療録・傷病名・投薬歴・バイタル・被保険者番号の 12 フィールドで使う。

scaffolder は次のように扱う (2026-08-01 実装。それ以前は変換が未実装で `prisma validate` が落ちていた):

| 層 | 生成物 |
|----|--------|
| Prisma 保管型 | `String` (暗号文) + `/// encrypted:true (要配慮個人情報・暗号文で保管)` 注記 |
| 対象一覧 (SoT) | `src/lib/crypto/encrypted-fields.ts` (kit 定義からの自動生成) |
| 暗号化本体 | `src/lib/crypto/field-encryption.ts` (AES-256-GCM・Node 標準 crypto のみ・外部依存なし) |
| 透過適用 | `src/lib/crypto/prisma-encryption-extension.ts` (Prisma Client Extension) |
| 配線 | `src/lib/db.ts` が Extension 適用済み client のみを export |
| 鍵の設定手順 | `.env.example` の `FIELD_ENCRYPTION_KEY` / `_KEY_ID` / `_KEYS_OLD` |
| 利用者への明示 | 生成物 README の「要配慮個人情報の暗号化 (必読)」節 |

設計上の約束:

- **鍵未設定なら例外で停止する。平文保存へは倒れない** (要配慮個人情報が黙って平文で残ることを防ぐ)
- 保管形式は `enc:v1:<keyId>:<iv>:<authTag>:<ciphertext>`。keyId 埋め込みにより鍵ローテーション中も旧鍵で復号できる
- **暗号文は DB 側の部分一致検索・並べ替えができない**。検索が必要な項目は `EncryptedString` にしない
- 本テンプレが担保するのは**アプリケーション経路の at-rest 暗号化まで**。DB バックアップ・監査ログ・エクスポート先の保護は別途必要 (生成物 README に明記)

### manifest.json の 7 要件との対応

`kits/drawing.json` の `manifest_requirement_map` が要件キーごとにモデルと画面を明示する。この対応表は `tests/template_kit_check.mjs` が実 `manifest.json` と突き合わせ、**要件の取りこぼしと、実在しないモデル/画面への参照**を検出する。

| manifest 要件 | モデル | 主な画面 |
|--------------|--------|---------|
| drawing_registry | Drawing | /drawings, /drawings/[id] |
| revision_control | DrawingRevision | /drawing-revisions, /drawings/[id]/revisions |
| drawing_project_link | DrawingProjectLink | /drawing-project-links |
| quantity_record | QuantityTakeoff | /quantity-takeoffs, /quantity-takeoffs/[id] |
| area_discrepancy_alert | AreaDiscrepancy | /area-discrepancies, /area-discrepancies/[id] |
| drawing_read_view | DrawingRevision + QuantityTakeoff | /drawing-revisions/[id] |
| file_format_guidance | Drawing (sourceFormat/formatSupport/formatGuidance) | /drawings, /drawings/[id], /drawings/formats |

図面読取エンジンが書き込んだ表題欄・レイヤ・寸法の記載値は `DrawingRevision` の Json フィールドに版ごとに保持し、`/drawing-revisions/[id]` が読取レポート閲覧画面になる。

## overlay 消費規則 (2026-07-09 追加・PFP-143 系統 kit の Phase B エンジン接地レイヤ)

### 目的

既存 kit JSON (例: `medical.json`) を**無編集のまま**、Phase B エンジン (`lib/japan/medical-billing/*`, `lib/japan/emr-core/*`) への接地情報 (`engine_refs`) と Phase C 実接続の正直開示 (`phase_c_disclosure`) を追加するための構造。共有本体 SHA-256 (kit_loader.ts / scaffolder.ts / kit.schema.json / skill-sot-guard.sh) を触らずに Phase B エンジンをテンプレに繋げる。

### 動作 (プログラム経路・lib/kit_overlay_resolver.ts)

- `scaffoldKit(kit_id, ...)` は内部で `loadKitWithOverlay(kit_id)` を呼び、`kit_id` に対応する overlay (`overlay_of: <kit_id>` を持つ他の JSON) が `kits/` に存在すれば、非破壊で `engine_refs` / `phase_c_disclosure` / その他追加フィールドを上乗せする。
- `kit_loader.ts` の低レベル API (`loadKit`) は overlay を無視する (下位互換=silently 昇格禁止)。
- **返り値の `kit_id` は常に base の kit_id** (`medical_overlay` ではない・silently 昇格しない)。

### 動作 (LLM 経路・SKILL.md 消費側の規則)

1. `industry='medical'` の kit を新規生成する場合、`scaffoldKit('medical', ...)` を呼ぶ (overlay は自動適用される)。
2. overlay 自身の kit_id (`medical_overlay`) を **直接** `scaffoldKit('medical_overlay', ...)` で指定した場合は、その overlay ファイル自身が base として扱われる (明示選択・silently 昇格ではない)。
3. `listKits()` は base kit と overlay kit の**両方**を並存表示する (overlay は隠さない=検索の透明性を保つ)。

### kill-switch

- **`ENABLE_KIT_OVERLAY=off`** (or `false` / `0` / `no`) で overlay 適用を停止し、base kit のみで従来動作に完全復帰。
- 障害時の安全弁として、環境変数一つで即座に旧挙動へ戻せる。

### base kit=medical.json 到達動線の破壊禁止

- overlay 導入前後で `industry='medical'` 検索の base 動線 (medical.json ヒット) は破壊されない。`listKits()` は base + overlay の両方を返す。
- base kit の SHA-256 は無編集 (物理ファイルを touch しない・返り値のオブジェクトのみ変わる)。
- kill-switch off で base 単独動線に完全復帰できる (障害時の完全復帰保証)。

### born-passing 両側弁別

`tests/kit_overlay_check.mjs` で 14 テスト全 PASS を維持する:
- overlay あり=engine_refs 上乗せ ∧ overlay 削除=base のみ
- kill-switch off=base のみ ∧ silently 昇格禁止 (kit_id=base 不変)
- kit_loader/scaffolder/schema/skill-sot-guard/medical/care SHA-256 baseline 保持

### 誇大表示禁止 (Phase C 実接続の正直開示)

3業態kit (`dispensing_pharmacy`, `home_nursing`, `medical_overlay`) は `phase_c_disclosure` で以下を正直に開示する:
- Phase C 実接続 (オンライン資格確認 / 電子処方箋 (HPKI 署名) / 国保連伝送 / マイナ保険証読取) は **接続テストボタンまで** の実装
- 実接続は **次回リリース時** (go:embed バイナリ payload 再ビルド) に段階提供
- 生成物 README にも同じ内容を明示 (顧客可視の誇大表示禁止)

## 実行例

```bash
# 工事台帳キットを生成
$ /soloptilink-template-kit --kit construction --target-dir /tmp/koji-daicho-app

✓ kit 読み込み: construction (建設業)
✓ ターゲット作成: /tmp/koji-daicho-app/
✓ package.json 書き出し
✓ Prisma スキーマ生成 (5 models: Project/Estimate/PurchaseOrder/Invoice/DailyReport)
✓ ダッシュボード生成 (KPI: 進行中工事/粗利率/キャッシュフロー/次回検査日)
✓ 一覧/詳細/新規ページ生成 (12 routes)
✓ API ルート生成 (28 routes)
✓ 帳票テンプレ生成 (工事日報/週報/月次出来高/見積書/注文書/請求書)
✓ DESIGN_CONTRACT.md 書き出し
✓ README.md 書き出し
✓ .env.example 書き出し

完了: 48 files, 4500 lines, 3 min setup
残り10%: ロゴ・カラー、勘定科目連携先(奉行/freee)、建設業許可番号
```

## セルフチェック

```bash
cd ~/.claude/skills/soloptilink-template-kit
node tests/template_kit_check.mjs
# 期待: 33 ケース PASS

node tests/kit_overlay_check.mjs
# 期待: 14 ケース PASS

node tests/prisma_schema_validate_check.mjs
# 期待: 24 ケース PASS (全 kit を実際に展開し、実 prisma validate に掛ける)
# 注意: typescript と prisma CLI が要る。無い場合は PASS ではなく終了コード 2 (未測定) で落ちる
```

## 認証

```bash
SOLOPTILINK_BIN=""
if [ -f ~/.soloptilink/soloptilink ]; then SOLOPTILINK_BIN="./soloptilink"
elif [ -f ~/.soloptilink/soloptilink.exe ]; then SOLOPTILINK_BIN="./soloptilink.exe"
fi
AUTH_CHECK=$(cd ~/.soloptilink 2>/dev/null && ${SOLOPTILINK_BIN:-./soloptilink} --status 2>&1)
if echo "$AUTH_CHECK" | grep -q "承認済み"; then
  echo "AUTHORIZED"
else
  echo "UNAUTHORIZED"
fi
```
