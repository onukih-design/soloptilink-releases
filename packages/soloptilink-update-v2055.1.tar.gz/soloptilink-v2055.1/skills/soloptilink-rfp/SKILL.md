---
name: soloptilink-rfp
description: "SoloptiLinkAI v2055.1 - 「提案書作って」「見積出して」「RFPに回答」「概算見積」「WBS作って」「プロジェクト計画書」「請負契約書」「準委任契約書」等で起動。日本SI受託の受注フロー文書を一括生成する。"
argument-hint: "[RFPファイル or 案件概要] [--mode proposal|estimate|wbs|contract|all] [--contract-type 請負|準委任|派遣] [--industry 建設|製造|医療|介護|不動産|...] [--scale small|medium|large|enterprise] [--client-type 民間|公共|自治体] [--include-handoff] [--locale ja|en]"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, Agent, WebSearch, AskUserQuestion, TodoWrite"
---

# SoloptiLinkAI v2055.1 - RFP-to-Proposal Engine


## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

## 機能概要

SoloptiLinkAI v1.0 RFP-to-Proposal Engine - 日本のSI受託開発の受注フロー (RFP受領→提案書→概算見積→WBS→契約書) を自動化。RFP/RFI を読み込み、提案書 (.docx) + 概算見積 (内訳明細付) + WBS + プロジェクト計画書 + 契約書 (請負/準委任) を一括生成。Claude Code が触れない日本SI市場のラストワンマイル独占。「提案書作って」「見積出して」「RFPに回答」「概算見積」「WBS作って」「プロジェクト計画書」「請負契約書」「準委任契約書」等で起動。日本の中小SIer/受託開発会社向け。提案勝率向上 + 工数50%削減を目標。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

Claude Code が触れない**日本のSI受託開発の受注フロー全体**を自動化するスキル。

## 対 Claude Code 差別化

| 工程 | Claude Code | SoloptiLinkAI-RFP |
|------|------------|-------------------|
| RFP/RFI 読み込み | ❌ 標準サポートなし | ✅ PDF/DOCX/XLSX/MD 全形式 + 暗黙要件抽出 |
| 提案書生成 | ⚠️ テキストレベル | ✅ 日本SI標準フォーマット .docx (表紙+目次+全章) |
| 概算見積 | ❌ | ✅ 工数積算 + 単価表 + 諸経費 + 消費税 + 内訳明細 |
| WBS生成 | ⚠️ 雑な箇条書き | ✅ 5階層 WBS + 依存関係 + マイルストーン + ガントチャート |
| 契約書生成 | ❌ | ✅ 請負/準委任/派遣 3種別 + 業界慣習対応 |
| 暗黙要件抽出 | ❌ | ✅ 「監視機能」→ Sentry/Datadog/CloudWatch 自動推論 |
| 単価表 | ❌ | ✅ 業種別/職位別の市場単価DB内蔵 |
| 提案勝率向上 | - | ✅ 競合比較 + 差別化提示 + リスク軽減策 |

## Step 0: 端末認証 (BOOST と同一)

```bash
SOLOPTILINK_BIN=""; if [ -f ~/.soloptilink/soloptilink ]; then SOLOPTILINK_BIN="./soloptilink"; elif [ -f ~/.soloptilink/soloptilink.exe ]; then SOLOPTILINK_BIN="./soloptilink.exe"; fi
AUTH_CHECK=$(cd ~/.soloptilink 2>/dev/null && ${SOLOPTILINK_BIN:-./soloptilink} --status 2>&1); if echo "$AUTH_CHECK" | grep -q "承認済み"; then echo "AUTHORIZED"; else echo "UNAUTHORIZED"; fi
```

`UNAUTHORIZED` の場合、認証案内を表示して処理中止。

## Step 1: RFP/RFI 取り込み

ユーザーが指定したファイル or 案件概要を読み込み、構造化:

```typescript
import { parseRfp } from './lib/rfp_parser';

const rfp = await parseRfp({
  source: 'path/to/rfp.pdf' | 'path/to/rfp.docx' | 'path/to/rfp.md' | 'inline_text',
  industry: 'construction',  // ドメイン辞書から推論
  client_type: '民間',
});

// 出力: { goal, scope, constraints, deliverables, deadline, budget_hint, evaluators, risks }
```

### 抽出する項目 (RFP-DNA)

1. **業務目的** (goal): 何のために作るのか
2. **業務範囲** (scope): 機能一覧 / 対象ユーザー / データ量
3. **制約条件** (constraints): 技術・予算・期間・法令・既存資産
4. **成果物** (deliverables): 設計書/コード/テスト/運用手順/教育
5. **納期** (deadline): 開発期間 / マイルストーン
6. **予算ヒント** (budget_hint): 明示 or 推定 (規模感から逆算)
7. **評価者** (evaluators): 経営層 / 情シス / 現場 / 外部監査
8. **暗黙要件** (implicit_requirements):
   - 「ログイン」→ MFA / SSO / パスワード強度 / アカウントロック
   - 「ダッシュボード」→ KPI集計 / グラフ / フィルタ / エクスポート
   - 「監視」→ ヘルスチェック / アラート / SLO / インシデント対応
   - 「セキュリティ」→ OWASP Top 10 / 暗号化 / 監査ログ
9. **リスク要因** (risks): 期間タイト / 要件曖昧 / 既存資産制約

## Step 2: 提案書生成 (`--mode proposal`)

日本SI標準フォーマットで提案書 .docx を生成:

```typescript
import { generateProposal } from './lib/proposal_generator';

const proposal = await generateProposal({
  rfp,
  company_info: { name, address, license_no, contact },
  approach: 'agile' | 'waterfall' | 'hybrid',
  team_structure: { pm, lead, developer, tester, designer },
  similar_cases: [...],
});
```

### 提案書の章構成 (日本SI標準)

1. 表紙 (案件名 / 提案先 / 提案日 / 提案者)
2. はじめに (背景理解 / 提案趣旨)
3. 提案概要 (システム全体像 / 期待効果)
4. システム要件 (機能要件 / 非機能要件 / 制約条件)
5. システム構成 (アーキテクチャ図 / 技術スタック / インフラ構成)
6. 開発スケジュール (WBS 概要 + ガントチャート)
7. 実施体制 (役割分担 / 役職 / 経歴)
8. 開発手法 (ウォーターフォール / アジャイル / 品質保証)
9. 概算費用 (内訳 / 支払条件 / 消費税)
10. リスクマネジメント (主要リスク / 対策 / エスカレーション)
11. 類似実績 (3〜5件)
12. 補足 (御社へのコミットメント / 質疑応答)

### 類似実績章のデータソース (案件台帳連携)

第11章「類似実績」の `similar_cases` 構築時は、まず `bash ~/.soloptilink/lib/engagement-ledger.sh portfolio list --industry <該当業種>` を実行し、案件台帳の実績カードがあれば優先的に引用する。台帳に該当実績がない場合のみ、ユーザへのヒアリング等で補完する。

## Step 3: 概算見積生成 (`--mode estimate`)

```typescript
import { generateEstimate } from './lib/cost_estimator';

const estimate = await generateEstimate({
  rfp,
  rate_table: 'standard' | 'enterprise' | 'public_sector',
  expense_ratio: 0.10,  // 諸経費比率
  tax_rate: 0.10,
});
```

### 見積の構成

| 項目 | 内訳 | 単価 (円/人月) | 工数 (人月) | 金額 (円) |
|------|------|---------------|-------------|----------|
| 要件定義 | PM + Lead | 1,200,000 | 1.0 | 1,200,000 |
| 基本設計 | Lead + Dev | 900,000 | 2.0 | 1,800,000 |
| 詳細設計 | Dev | 800,000 | 2.0 | 1,600,000 |
| 実装 | Dev × 3 | 800,000 | 6.0 | 4,800,000 |
| 結合テスト | Tester + Dev | 700,000 | 2.0 | 1,400,000 |
| 受入テスト立会 | PM | 1,200,000 | 0.5 | 600,000 |
| **小計** | | | **13.5** | **11,400,000** |
| 諸経費 (10%) | | | | 1,140,000 |
| **合計 (税抜)** | | | | **12,540,000** |
| 消費税 (10%) | | | | 1,254,000 |
| **総合計 (税込)** | | | | **13,794,000** |

### 単価テーブル (`lib/rate_table.ts`)

| 役職 | 標準単価 (円/人月) | エンタープライズ | 公共機関 |
|------|-------------------|------------------|---------|
| PM (10年+) | 1,200,000 | 1,500,000 | 1,800,000 |
| アーキテクト | 1,500,000 | 1,800,000 | 2,000,000 |
| Lead Eng (5年+) | 900,000 | 1,200,000 | 1,400,000 |
| Mid Eng (3-5年) | 800,000 | 950,000 | 1,100,000 |
| Junior Eng (-3年) | 600,000 | 700,000 | 800,000 |
| Tester | 700,000 | 850,000 | 950,000 |
| デザイナー | 750,000 | 900,000 | 1,000,000 |

## Step 4: WBS生成 (`--mode wbs`)

5階層 WBS + 依存関係 + マイルストーン:

```typescript
import { generateWbs } from './lib/wbs_generator';

const wbs = await generateWbs({
  rfp,
  total_duration_weeks: 24,
  team_size: 5,
  approach: 'waterfall',
});
```

### WBS フォーマット

```
1. プロジェクト全体
  1.1. 要件定義フェーズ (Week 1-3)
    1.1.1. キックオフミーティング
    1.1.2. ステークホルダーヒアリング
    1.1.3. 業務要件確定
    1.1.4. 非機能要件確定
    1.1.5. 要件定義書レビュー → 承認
  1.2. 基本設計フェーズ (Week 4-7)
    1.2.1. システム構成設計
    1.2.2. DB論理設計
    1.2.3. 画面設計 (ワイヤー)
    1.2.4. API設計
    1.2.5. 基本設計書レビュー → 承認
  ...
```

## Step 5: 契約書生成 (`--mode contract`)

請負契約 / 準委任契約 / 派遣契約 を業界慣習に沿って生成:

```typescript
import { generateContract } from './lib/contract_generator';

const contract = await generateContract({
  type: '請負' | '準委任' | '派遣',
  parties: { contractor, client },
  scope: rfp.scope,
  deliverables: rfp.deliverables,
  deadline: rfp.deadline,
  amount: estimate.total_with_tax,
  payment_terms: '検収後30日',  // 下請法60日上限
});
```

### 契約書の章構成 (日本SI標準)

1. 表題 (請負契約書 / 準委任契約書)
2. 当事者 (甲 / 乙)
3. 目的 / 業務範囲
4. 契約金額 / 支払条件 / 消費税
5. 納期 / 検収
6. 知的財産権 (著作権 / プログラム権)
7. 秘密保持
8. 個人情報保護
9. 瑕疵担保 / 契約不適合責任
10. 損害賠償
11. 解除
12. 反社会的勢力排除
13. 紛争解決 (合意管轄裁判所)
14. 印紙税
15. 別紙 (要件詳細 / 体制図 / スケジュール)

### 契約類型別の重要差分

| 項目 | 請負契約 | 準委任契約 | 派遣契約 |
|------|---------|-----------|---------|
| 完成義務 | あり | なし (善管注意義務) | なし |
| 指揮命令権 | 受託者 | 受託者 | 派遣先 |
| 瑕疵担保 | あり (民法636条/562条) | なし | なし |
| 報酬 | 完成成果に対し | 工数 (人月) | 派遣料金 |
| 請負代金支払時期 | 完成・検収後 | 月次 | 月次 |
| 偽装請負リスク | 高 (35条処分) | 中 | 派遣許可必須 |

## Step 6: 全モード一括実行 (`--mode all`)

提案書 + 見積 + WBS + 契約書 + プロジェクト計画書 を一括生成 (依頼から納品までフルセット)。

## 業種別カスタマイズ (soloptilink-japan 連携)

`--industry` 指定時、`~/.claude/skills/soloptilink-japan/domains/<industry>.json` を読み込み、業種固有の:
- 用語 (terminology)
- 必須項目 (mandatory_fields)
- 適用法令 (applicable_laws)
- 帳票テンプレ (report_templates)

を提案書・見積・契約書に自動反映。

### 業種別の見積調整

| 業種 | 工数係数 | 理由 |
|------|---------|------|
| 建設業 | 1.2x | 工事台帳/積算複雑 |
| 製造業 | 1.1x | EDI/MRP統合 |
| 医療 | 1.5x | 3省2GL/レセプト/HPKI |
| 介護 | 1.4x | 介護報酬/LIFE/科学的介護 |
| 公共/自治体 | 1.6x | 入札/検査調書/標準ガイドライン |
| 金融 | 1.5x | FISC/全銀/反社チェック |
| 不動産 | 1.2x | 35条書面/レインズ/宅建業法 |

## 出力フォーマット

| 種類 | フォーマット | 用途 |
|------|------------|------|
| 提案書 | .docx (anthropic-skills:docx 経由) | クライアントへ提示 |
| 見積書 | .xlsx + .pdf | 内訳明細 / 印紙税対応 |
| WBS | .xlsx (ガントチャート) + .md | プロジェクト管理ツール取込 |
| 契約書 | .docx | 製本 / 押印用 |
| プロジェクト計画書 | .docx + .md | キックオフ資料 |

## 出力配置

デフォルト: `<カレントディレクトリ>/docs/proposal/`
- `01_proposal.docx`
- `02_estimate.xlsx`
- `03_wbs.xlsx`
- `04_contract_<type>.docx`
- `05_project_plan.docx`
- `metadata.json` (RFP-DNA + 生成パラメータ)

## 統合スキル

- `/soloptilink-japan`: 業種辞書 / 法令DNA / 帳票テンプレ
- `/soloptilink-acceptance`: 検収フェーズ (RFP→検収まで)
- `/soloptilink-handoff`: 運用引継ぎ
- `anthropic-skills:docx`: .docx 生成エンジン
- `anthropic-skills:xlsx`: .xlsx 見積/WBS

## 引数の解釈

| 引数 | 動作 |
|------|------|
| 引数なし | インタラクティブモード (ユーザに案件概要を確認) |
| ファイルパス | RFP/RFI ファイルを読み込み |
| `--mode proposal` | 提案書のみ生成 |
| `--mode estimate` | 見積のみ生成 |
| `--mode wbs` | WBS のみ生成 |
| `--mode contract` | 契約書のみ生成 |
| `--mode all` (デフォルト) | フルセット生成 |
| `--contract-type 請負|準委任|派遣` | 契約類型指定 |
| `--industry <業種>` | 業種固有カスタマイズ (japan ドメイン辞書連携) |
| `--scale small|medium|large|enterprise` | 規模別工数調整 (0.5x / 1.0x / 1.8x / 3.0x) |
| `--client-type 民間|公共|自治体` | 単価テーブル切替 |
| `--include-handoff` | 運用引継ぎ計画も同時生成 |
| `--locale ja|en` | 言語選択 (英語版は概算ベース) |

## 使用例

```
/soloptilink-rfp 建設業向け工事原価管理システムの提案書一式を作って --industry 建設 --scale medium

/soloptilink-rfp ./RFP_NTT_2026.pdf --mode all --contract-type 請負 --client-type 民間

/soloptilink-rfp 案件概要: 介護施設向けケアプラン作成支援システム --industry 介護 --scale large --include-handoff

/soloptilink-rfp --mode estimate --industry 公共 --scale enterprise (公共機関向けの大規模見積のみ)
```

## セッション継続ルール

このスキル起動後、`.soloptilink-rfp-session.json` がプロジェクトに作成され、以降の会話で:
- 「見積金額調整して」→ 既存見積を再計算
- 「WBSにテストフェーズ追加して」→ 既存WBSを更新
- 「契約書を準委任に変更して」→ 契約書を再生成

として継続的に操作可能。

セッションファイル `.soloptilink-rfp-session.json` の保存直後には `bash ~/.soloptilink/lib/engagement-ledger.sh ingest .soloptilink-rfp-session.json` を実行し、案件台帳 (Engagement Ledger) に自動登録する。
