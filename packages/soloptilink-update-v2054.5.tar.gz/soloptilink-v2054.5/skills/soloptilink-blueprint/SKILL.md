---
name: soloptilink-blueprint
description: "SoloptiLinkAI v2054.5 - 「DBL」「業種辞書」「業種設計」「テンプレ展開」「業種比較」「業種カバレッジ」「business blueprint」等で起動。業種辞書の表示・検索・差分・展開・採点を行う照会インターフェイス。"
---

# SoloptiLinkAI v2054.5 - /soloptilink-blueprint — Domain Blueprint Library Query Interface


## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

## 機能概要

SoloptiLinkAI v2028.0 Domain Blueprint Library (DBL) クエリインターフェイス - 業種辞書の詳細表示・検索・差分・展開・採点を CLI から行う。「business blueprint」「DBL」「業種辞書」「業種設計」「テンプレ展開」「業種比較」「業種カバレッジ」「ironドーム雛形」「営業システム雛形」「建設システム雛形」「医療システム雛形」「物流システム雛形」「不動産システム雛形」等で起動。生成計画 P0/P1/P2 化に直結する Iron-Dome Recommender の上流照会層。 — 管理者専用機能 (RPB 展開) と顧客向け機能 (DBL 引照) を分離。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

SoloptiLinkAI v2028.0 で導入された **Iron-Dome Generator** の中核アセット **Domain Blueprint Library (DBL)** を CLI から照会するスキル。

## 用途

1. **業種ブループリントの詳細表示**: 「建設業ならどんな機能/帳票/法令/競合が標準か」を即時取得
2. **業種比較**: 2業種の差分を可視化 (例: medical vs longterm_care)
3. **横断キーワード検索**: 「電子契約」を含む業種を全リストアップ
4. **完成度採点**: 全38業種の Blueprint Completeness をランキング表示
5. **iron-dome 雛形展開**: 業種特化の RPB を一時ディレクトリに展開
6. **生成計画プレビュー**: Iron-Dome Recommender の P0/P1/P2 を業種指定で先読み

## サブコマンド一覧

```bash
# 全業種一覧 (簡易)
/soloptilink-blueprint --list

# 全業種ランキング (Diamond/Platinum/Gold/Reject)
/soloptilink-blueprint --rank

# 特定業種の DBL 全体表示
/soloptilink-blueprint --industry construction

# 特定フィールドだけ表示
/soloptilink-blueprint --industry medical --field laws
/soloptilink-blueprint --industry retail --field competitors
/soloptilink-blueprint --industry real_estate --field kpis
/soloptilink-blueprint --industry logistics --field panels

# 横断キーワード検索
/soloptilink-blueprint --search "電子契約"
/soloptilink-blueprint --search "インボイス"

# 2業種の差分
/soloptilink-blueprint --diff construction architecture
/soloptilink-blueprint --diff medical longterm_care

# Blueprint Completeness 採点 (validator 経由)
/soloptilink-blueprint --completeness
/soloptilink-blueprint --completeness --industry healthcare

# Iron-Dome Recommender 先読み (P0/P1/P2 件数のみ)
/soloptilink-blueprint --recommend construction
/soloptilink-blueprint --recommend _generic_business

# RPB 雛形を一時ディレクトリに展開 (管理者モードのみ)
/soloptilink-blueprint --industry construction --target-dir /tmp/myproject

# 内部スコア (_internal_score) の閲覧 (管理者モードのみ)
/soloptilink-blueprint --industry retail --show-internal-score
```

## アーキテクチャ

`/soloptilink-blueprint` は薄い CLI ラッパで、本体ロジックは:

| 層 | パス |
|---|---|
| DBL 本体 | `~/.claude/skills/soloptilink-japan/domains/*.json` (38業種) |
| Validator | `~/.claude/skills/soloptilink-japan/contrib/validate_domain_v2028.sh` |
| Recommender | `~/.soloptilink/lib/iron-dome/generation-recommender.mjs` |
| RPB | `~/.soloptilink/.iron-dome-rpb/reference-projects/<industry>/` (管理者専用) |
| Internal score strip | `~/.soloptilink/lib/distribution/strip-internal-scores.mjs` |

## 顧客モード vs 管理者モード

- **顧客モード** (`/.admin_mode` 不在):
  - DBL 引照 / 比較 / 検索 / 採点 / Recommender 先読み は使用可
  - **`_internal_score` フィールドは strip された状態でのみ表示**
  - RPB 展開 (`--target-dir`) はSKIP (RPB 全体が EXCLUDE_LIST 対象)

- **管理者モード** (`/.admin_mode` 存在):
  - 全機能利用可
  - RPB を `--target-dir` で展開
  - `_internal_score` フィールドの閲覧 (`--show-internal-score`)

## CLI 実装

本体: `~/.claude/skills/soloptilink-blueprint/cli/blueprint-query.sh`

```bash
#!/usr/bin/env bash
# soloptilink-blueprint CLI dispatcher

SUBCOMMAND="$1"
shift || true

case "$SUBCOMMAND" in
  --list|--rank|--industry|--search|--diff|--completeness|--recommend)
    # 主要サブコマンドは下記実装に委譲
    exec bash ~/.claude/skills/soloptilink-blueprint/cli/blueprint-query.sh "$SUBCOMMAND" "$@"
    ;;
  *)
    cat <<EOF
SoloptiLinkAI v2028.0 — Domain Blueprint Library

Usage:
  /soloptilink-blueprint --list                           # 全業種一覧
  /soloptilink-blueprint --rank                           # ランキング表示
  /soloptilink-blueprint --industry <key>                 # 業種詳細
  /soloptilink-blueprint --industry <key> --field <name>  # 特定フィールドのみ
  /soloptilink-blueprint --search "<keyword>"             # 横断検索
  /soloptilink-blueprint --diff <key1> <key2>             # 2業種比較
  /soloptilink-blueprint --completeness                   # 採点
  /soloptilink-blueprint --recommend <key>                # Recommender先読み

Available industries (38):
$(ls ~/.claude/skills/soloptilink-japan/domains/*.json | xargs -n1 basename | sed 's/.json$//' | column -c 80)
EOF
    ;;
esac
```

## BOOST との関係

- BOOST は **生成時に DBL を自動引照** する (Step 0.62.6)
- `/soloptilink-blueprint` は **明示的に DBL を照会したい時** (営業現場/設計レビュー/業種カバー確認) に使う
- 営業マンが「建設業向けに何を作れますか?」と顧客に聞かれた時、即座に Blueprint を見せて差別化アングルを語れる

## 配布除外

- スキル本体 (SKILL.md + cli/) は配布可 — 顧客が DBL を引けるようにする
- ただし `--show-internal-score` と `--target-dir` (RPB 展開) は管理者モードでのみ動作
- 顧客環境で `/soloptilink-blueprint --industry retail` を実行した場合、`_internal_score` キーは **strip された状態で表示**される
