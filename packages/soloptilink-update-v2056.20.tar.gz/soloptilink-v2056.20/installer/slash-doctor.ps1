﻿# =============================================================================
# SoloptiLinkAI - スラッシュの一覧に出るかの診断 (slash-doctor) Windows 版
# =============================================================================
# 2026-11-11 新設。共通の決めごとは lib/slash-doctor/SPEC.md。
#   Mac・Linux (bash 版)、Claude Desktop のチャット連携 (Go の diagnose_slash) と
#   同じ判定の言葉 (符丁) と同じ案内文を使う。案内文を直すときは 3 つの入口を同時に直す。
#
# 【なぜ要るか】
#   導入が「完了」と出ても、お客様の Claude Code のスラッシュの一覧に
#   /soloptilink-boost (全力で作る) が本当に出るかを、誰も確かめていなかった。
#   古い版・置き場所の欠け・設定の場所の切り替え・Code でない画面など、出ない道筋が
#   いくつもあり、どれだったかをお客様の端末から知る手段も無かった (調査報告書 2026-11-11)。
#
# 【使い方】
#   powershell -NoProfile -ExecutionPolicy Bypass -File slash-doctor.ps1 -Mode check|fix|report
#       [-Json] [-NoProbe] [-Entry installer-windows|doctor-cli|...] [-EngineDir <本体の置き場>]
#     check  … 調べるだけ (Claude Code が読む場所は書き換えない・当社へは何も送らない)
#     fix    … 調べて、/soloptilink-boost の置き場所が欠けていれば本体から置き直す
#     report … 直前の check / fix で保存した結果 (個人の情報を含まない) を当社へ届ける。保存した結果が
#              無いときだけ check (置き直しなし) を 1 回行ってから届ける (Mac の bash 版と同じ)。
#              登録と試用の状態だけは、送るときの今の値にする。
#     結果の保存先: <本体の置き場>\var\slash-doctor\last.json (本体が無いときは一時フォルダの
#              soloptilink-slash-probe\state\last.json)。中身は当社へ送る形 (SPEC 4 節) と同じ
#     -Json    … 結果を JSON 1 つだけで返す (導入の台本が読む)
#     -NoProbe … Claude Code を起動して測る工程 (SPEC の 6) を行わない
#     -Entry   … installer-windows / installer-mac / installer-linux / doctor-cli / mcp (既定 doctor-cli・Mac の bash 版と同じ)
#
# 【停止のスイッチ】
#   SOLOPTILINK_SLASH_DOCTOR=off … 診断そのものを行わない
#   SOLOPTILINK_SLASH_PROBE=off  … 実測だけ行わない (PROBE_SKIPPED)
#   SOLOPTILINK_SLASH_REPORT=off … 当社へ送らない
#
# 【終了コード】Mac の bash 版と同じ。check / fix: 0 = VISIBLE、1 = PLACED_UNVERIFIED、2 = NOT_VISIBLE
#               report・停止スイッチで行わなかったとき・診断そのものが落ちたとき: 0
#   ★どんな失敗でも導入を止めない。例外はこの台本の中で受け止める。
#
# 【実測で起動する Claude Code の環境 (2026-11-11 実測にもとづく・Mac の bash 版と同じ)】
#   決めごとの命令は、init の行を出した 11〜13 ミリ秒後に本体 (Anthropic) へ問い合わせ (約 105KB) を送る。
#   ログイン済みの端末では init を読んで直ちに止めても 5 回中 5 回届いた (Mac 側の担当の実測)。
#   お客様が診断を動かすたびに費用・利用枠が減らないよう、起動する子 (実測と --version) にだけ次をする:
#     ① ANTHROPIC_BASE_URL を手元の閉じた番号 (http://127.0.0.1:9) へ向ける
#     ② HTTPS_PROXY・HTTP_PROXY・ALL_PROXY (大文字・小文字とも) も閉じた番号へ。NO_PROXY は外す
#     ③ SOLOPTILINK_API_URL も閉じた番号へ (当社の自動更新のフックが確認の時刻を書いて、本物の確認が遅れるのを防ぐ)
#     ④ 会話の中で動いているときの印 (CLAUDECODE・CLAUDE_CODE_*・CLAUDE_AGENT_SDK_*) を外す
#     ⑤ 標準入力を閉じる (閉じないと 3 秒待たされる)
#   あわせて DISABLE_AUTOUPDATER=1・CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1 を渡す。CLAUDE_CONFIG_DIR はお客様の設定なので残す。
#
# 【書き方の決まり】
#   ・お客様の Windows は Windows PowerShell 5.1 が標準。三項演算子・??・-AsHashtable など
#     PowerShell 7 だけの書き方は使わない。
#   ・この Mac で確かめるための pwsh 7 でも動くよう、Windows だけの命令 (robocopy・taskkill)
#     は Windows のときだけ使う。
#   ・置き直しは導入の STEP 8.5 と同じ規則 (管理者専用は置かない・入れ替える前に控えを取る・
#     robocopy /E /IS)。ただし、正しく置かれているものには触れない。
#   ・本体が無い・古い端末、管理者の端末 (.admin_mode)、試用が終わった端末、退去済みの端末、
#     登録が取り消された端末 (DEVICE_REVOKED) では置き直さない
#     (試用の終了後・取り消しの後は引き取りを打ち消さない・Mac の bash 版と同じ)。
#
# 【2026-11-11 追記 (SPEC 7 節)】
#   ・控えの置き場は <本体の置き場>\var\slash-doctor\backups\<時刻>\ (skills\<名前> と commands\<名前>.md)。
#     3 つの入口で同じ場所。以前は設定の場所の _backups で、解約の片付け (lib/evict) が一度も見ない場所だった。
#   ・端末の承認待ち (DEVICE_PENDING_APPROVAL) と取り消し (DEVICE_REVOKED) を、起動用プログラムが残す記録から見分ける。
#   ・当社へ送る直前に本文を調べ、@・HOME のパス・利用者名・端末名が入っていたら送らずに
#     <本体の置き場>\var\slash-doctor\history.log へ「送らなかった (理由)」を残す (値そのものは書かない)。
#   ・実測の Claude Code に --no-session-persistence を付け、お客様の .claude\projects に会話の記録を残さない。
# =============================================================================

[CmdletBinding()]
param(
    [ValidateSet('check', 'fix', 'report')]
    [string]$Mode = 'check',
    [switch]$Json,
    [switch]$NoProbe,
    [ValidateSet('installer-windows', 'installer-mac', 'installer-linux', 'doctor-cli', 'mcp')]
    [string]$Entry = 'doctor-cli',
    [string]$EngineDir = '',
    [ValidateRange(1, 600)]
    [int]$ProbeTimeoutSec = 45
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'

# -----------------------------------------------------------------------------
# お客様への案内文 (SPEC 3 節と一字一句同じ。直すときは SPEC と 3 つの入口を同時に直す)
# -----------------------------------------------------------------------------
$script:MsgVisible = 'Claude Code のスラッシュの一覧に『/soloptilink-boost』（全力で作る）が出ることを確かめました。Claude Desktop をお使いの場合は、左上の『Code』の画面で新しい会話を開き、入力欄に /soloptilink-boost と入力してください。'
$script:MsgFixed = '機能の置き場所が欠けていたため、置き直しました。'
$script:MsgSkillsMissing = '機能を Claude Code が読む場所へ置けませんでした。Claude Desktop と Claude Code を終了してから、セットアップをもう一度実行してください。'
$script:MsgEngineTooOld = 'お使いの SoloptiLinkAI が古い版です（この版にはスラッシュの一覧に出す処理がありません）。ダウンロードのリンクから最新版を取り直して、セットアップをもう一度実行してください。'
$script:MsgClaudeMissing = 'Claude Code が見つかりませんでした。Claude Desktop の『Code』の画面を一度開くか、セットアップをもう一度実行してください（Claude Code は自動で入ります）。'
$script:MsgProbeNotVisible = '置き場所は正しいのに、Claude Code の一覧に出ませんでした。Claude Desktop をいったん終了して開き直し、『Code』の画面で新しい会話を開いてください。それでも出ない場合は、この画面の写真を nomura.y@soloptilink.com へお送りください。'
$script:MsgCommonNote = 'スラッシュの一覧に出るのは、Claude Desktop の『Code』の画面（または Claude Code）だけです。普通のチャット画面では出ません。また、Code の画面を使うには有料の Claude プラン（Pro / Max / Team / Enterprise）が必要です。'
$script:MsgTrialEnded = '無料お試しの期間が終わっています。続けてお使いになる場合は、担当の者へ有料プランへの切り替えをお申し付けください。'
# SPEC 1 節の「実測できなかったときに言う文」(Mac の bash 版と同じく文末に「。」を付ける)
$script:MsgUnverified = '置き場所までは確かめました。画面での表示はまだ確かめていません。'
# ★SPEC 3 節に文が無い DESKTOP_RUNNING の案内 (SPEC 9 の「新しい会話を開く案内」。共通化を提案中・実測できなかったときだけ出す)
#   本体が無い (ENGINE_MISSING) ときは、Mac の bash 版と同じく「置けませんでした」の文を使う (新しい文は作らない)。
$script:MsgDesktopRunning = 'Claude Desktop が開いています。新しく置いた機能は、Claude Desktop をいったん終了して開き直し、『Code』の画面で新しい会話を開くと読み込まれます。'
# 端末の承認待ち・取り消し (SPEC 7 節・T1-067・3 つの入口で同じ文・総合にかかわらず出す)
$script:MsgDevicePending = '担当の承認をお待ちください。承認されるとメールでお知らせします。'
$script:MsgDeviceRevoked = 'この端末の利用の登録が取り消されています。担当の者へご連絡ください。'

# 管理者専用のメニュー (導入の STEP 8.5 と同じ一覧。配布物の SKILL.md の admin_only: true と .admin-only の印も除外する)
$script:AdminNames = @('soloptilink-deploy', 'soloptilink-release', 'soloptilink-doctor', 'soloptilink-arte')
$script:BoostName = 'soloptilink-boost'
# スラッシュの一覧に出す処理が入った最初の版 (2056.6・2026-09-03)
$script:MinEngineMajor = 2056
$script:MinEngineMinor = 6
$script:DefaultApiBase = 'https://admin-dashboard-blue-alpha-78.vercel.app/api/v1'

# Windows かどうか (PowerShell 5.1 には $IsWindows が無いため、ここで決める)
$script:OnWindows = ([System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT)

# -----------------------------------------------------------------------------
# 場所を決める
# -----------------------------------------------------------------------------
function Get-SdHome {
    if ($env:USERPROFILE) { return [string]$env:USERPROFILE }
    if ($HOME) { return [string]$HOME }
    return [Environment]::GetFolderPath('UserProfile')
}

$script:HomeDir = Get-SdHome
if (-not $EngineDir) { $EngineDir = Join-Path $script:HomeDir '.soloptilink' }
$script:EngineDir = $EngineDir
$script:ConfigOverride = $false
$script:ConfigDir = Join-Path $script:HomeDir '.claude'
if ($env:CLAUDE_CONFIG_DIR -and ([string]$env:CLAUDE_CONFIG_DIR).Trim()) {
    $script:ConfigDir = ([string]$env:CLAUDE_CONFIG_DIR).Trim()
    $script:ConfigOverride = $true
}

# -----------------------------------------------------------------------------
# 結果の入れ物
# -----------------------------------------------------------------------------
$script:Codes = New-Object System.Collections.ArrayList
function Add-SdCode([string]$Code) {
    if ($Code -and -not $script:Codes.Contains($Code)) { [void]$script:Codes.Add($Code) }
}
function Remove-SdCode([string]$Code) {
    while ($script:Codes.Contains($Code)) { $script:Codes.Remove($Code) }
}
function Test-SdCode([string]$Code) { return $script:Codes.Contains($Code) }

$script:EngineVersion = ''
$script:ClaudePath = ''
$script:ClaudeVersion = ''
$script:InstallKind = 'unknown'
$script:DeviceId = ''
$script:Fixed = $false
$script:PlacedCount = 0
$script:FailedNames = @()
$script:TrialText = @()
$script:Notes = New-Object System.Collections.ArrayList
$script:Probe = [ordered]@{ ran = $false; seconds = 0; pid = 0; note = '' }

function Add-SdNote([string]$Note) { if ($Note) { [void]$script:Notes.Add($Note) } }

# オブジェクトに指定の項目があるかを安全に調べる (StrictMode で 0 件の項目一覧に触れると止まるため)
function Test-SdProp($Obj, [string]$Name) {
    if ($null -eq $Obj) { return $false }
    foreach ($p in $Obj.PSObject.Properties) { if ($p.Name -eq $Name) { return $true } }
    return $false
}

# -----------------------------------------------------------------------------
# 外の命令を、打ち切りの時間つきで動かす
# -----------------------------------------------------------------------------
function New-SdStartInfo([string]$File, [string]$ArgLine, [string]$WorkDir) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $ext = [System.IO.Path]::GetExtension($File)
    if ($script:OnWindows -and (($ext -ieq '.cmd') -or ($ext -ieq '.bat'))) {
        # .cmd (npm で入れた Claude Code) は cmd.exe を通して動かす
        $comspec = [string]$env:ComSpec
        if (-not $comspec) { $comspec = 'cmd.exe' }
        $psi.FileName = $comspec
        $psi.Arguments = '/d /s /c ""' + $File + '" ' + $ArgLine + '"'
    } else {
        $psi.FileName = $File
        $psi.Arguments = $ArgLine
    }
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.RedirectStandardInput = $true
    $psi.CreateNoWindow = $true
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    $psi.StandardOutputEncoding = $utf8
    $psi.StandardErrorEncoding = $utf8
    if ($WorkDir) { $psi.WorkingDirectory = $WorkDir }
    return $psi
}

# 実測で起動する Claude Code にだけ渡す環境 (冒頭の①〜④)。本体と当社への問い合わせを端末の外へ出さない
$script:ClosedEndpoint = 'http://127.0.0.1:9'
function Set-SdClaudeEnv($Psi) {
    $envs = $Psi.EnvironmentVariables
    $drop = @()
    foreach ($k in @($envs.Keys)) {
        $name = [string]$k
        if (($name -ieq 'CLAUDECODE') -or ($name -like 'CLAUDE_CODE_*') -or ($name -like 'CLAUDE_AGENT_SDK_*') -or ($name -ieq 'NO_PROXY')) {
            $drop += $name
        }
    }
    foreach ($name in $drop) { $envs.Remove($name) }
    foreach ($name in @('SOLOPTILINK_API_URL', 'ANTHROPIC_BASE_URL', 'HTTPS_PROXY', 'HTTP_PROXY', 'ALL_PROXY')) {
        $envs[$name] = $script:ClosedEndpoint
    }
    if (-not $script:OnWindows) {
        # Windows の環境変数は大文字・小文字を区別しない (上の 3 つで小文字の名前も塞がる)
        foreach ($name in @('https_proxy', 'http_proxy', 'all_proxy')) { $envs[$name] = $script:ClosedEndpoint }
    }
    $envs['DISABLE_AUTOUPDATER'] = '1'
    $envs['CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC'] = '1'
}

# 子と、その子が起こした工程をまとめて止める
#   ★init を出した直後に子が新しい工程を起こすと、子孫の数え上げと止める操作の間に生まれた工程が取り残される
#     (2026-11-11 の試験で、init のすぐ後に起こした sleep が残った)。
#     Mac・Linux: 先に親を一時停止 (SIGSTOP) させてから一団を止める (止まっている親は新しい工程を起こせない)。
#     Windows: 親が先に終わっても子の「親の番号」は書き換わらないので、止めたあとに親の番号で残りを拾って止める
#     (番号の使い回しで別の工程を止めないよう、親より後に起動したものだけ)。
function Stop-SdProcessTree($Proc) {
    if ($null -eq $Proc) { return }
    $alive = $false
    try { $alive = -not $Proc.HasExited } catch { return }
    if (-not $alive) { return }
    $rootId = 0
    $started = $null
    try { $rootId = $Proc.Id; $started = $Proc.StartTime } catch { }
    if ($script:OnWindows) {
        # PowerShell 5.1 の Kill() は孫を止められない (cmd.exe 経由の node が残る) ため taskkill /T を使う
        try { & taskkill.exe /PID $rootId /T /F 2>$null | Out-Null } catch { }
        $global:LASTEXITCODE = 0
        try { if (-not $Proc.HasExited) { $Proc.Kill() } } catch { }
        Start-Sleep -Milliseconds 300
        try {
            foreach ($c in @(Get-CimInstance -ClassName Win32_Process -Filter ('ParentProcessId={0}' -f $rootId) -ErrorAction Stop)) {
                if ($started -and $c.CreationDate -and ($c.CreationDate -lt $started)) { continue }
                & taskkill.exe /PID $c.ProcessId /T /F 2>$null | Out-Null
            }
        } catch { }
        $global:LASTEXITCODE = 0
    } else {
        if (Test-Path -LiteralPath '/bin/kill') {
            # ★呼び出し記号 (& /bin/kill) で動かすと pwsh が戻ってこないことがあった (2026-11-11 実測) ため、
            #   工程として起こして最大 2 秒だけ待つ
            try {
                $ks = New-Object System.Diagnostics.ProcessStartInfo
                $ks.FileName = '/bin/kill'
                $ks.Arguments = ('-STOP {0}' -f $rootId)
                $ks.UseShellExecute = $false
                $ks.RedirectStandardOutput = $true
                $ks.RedirectStandardError = $true
                $ks.RedirectStandardInput = $true
                $kp = [System.Diagnostics.Process]::Start($ks)
                try { $kp.StandardInput.Close() } catch { }
                [void]$kp.WaitForExit(2000)
            } catch { }
        }
        try { $Proc.Kill($true) } catch { try { $Proc.Kill() } catch { } }
    }
    try { [void]$Proc.WaitForExit(5000) } catch { }
}

function Invoke-SdCapture([string]$File, [string]$ArgLine, [int]$TimeoutMs, [string]$WorkDir, [bool]$ClaudeEnv) {
    $res = [ordered]@{ ok = $false; out = ''; code = -1 }
    $p = $null
    try {
        $psi = New-SdStartInfo $File $ArgLine $WorkDir
        if ($ClaudeEnv) { Set-SdClaudeEnv $psi }
        $p = [System.Diagnostics.Process]::Start($psi)
        try { $p.StandardInput.Close() } catch { }
        $outTask = $p.StandardOutput.ReadToEndAsync()
        $null = $p.StandardError.ReadToEndAsync()
        if (-not $p.WaitForExit($TimeoutMs)) {
            Stop-SdProcessTree $p
            return $res
        }
        $p.WaitForExit()
        $res.code = $p.ExitCode
        try { if ($outTask.Wait(3000)) { $res.out = [string]$outTask.Result } } catch { }
        $res.ok = $true
    } catch {
        Stop-SdProcessTree $p
    }
    return $res
}

# -----------------------------------------------------------------------------
# SKILL.md / commands の .md の先頭 (frontmatter) を調べる
#   'missing' = 無い・空 / 'bad' = 先頭が --- でない・name: が無い・名前が違う / 'ok'
# -----------------------------------------------------------------------------
function Get-SdMdState([string]$Path, [string]$ExpectName) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return 'missing' }
    $len = 0
    try { $len = (Get-Item -LiteralPath $Path -Force -ErrorAction Stop).Length } catch { return 'missing' }
    if ($len -le 0) { return 'missing' }
    $lines = @()
    try { $lines = @(Get-Content -LiteralPath $Path -TotalCount 200 -Encoding UTF8 -ErrorAction Stop) } catch { return 'bad' }
    if ($lines.Count -lt 3) { return 'bad' }
    $first = ([string]$lines[0]).TrimStart([char]0xFEFF).Trim()
    if ($first -ne '---') { return 'bad' }
    $name = ''
    $closed = $false
    for ($i = 1; $i -lt $lines.Count; $i++) {
        $l = [string]$lines[$i]
        if ($l.Trim() -eq '---') { $closed = $true; break }
        if ($l -match '^name:\s*(.*?)\s*$') { $name = $matches[1].Trim().Trim('"').Trim("'") }
    }
    if (-not $closed) { return 'bad' }
    if (-not $name) { return 'bad' }
    if ($ExpectName -and ($name -ne $ExpectName)) { return 'bad' }
    return 'ok'
}

function Test-SdReparse([string]$Path) {
    try {
        $it = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
        return [bool]($it.Attributes -band [System.IO.FileAttributes]::ReparsePoint)
    } catch { return $false }
}

# -----------------------------------------------------------------------------
# 1. 本体の置き場と版
# -----------------------------------------------------------------------------
function Test-SdEngine {
    if (-not (Test-Path -LiteralPath $script:EngineDir -PathType Container)) { Add-SdCode 'ENGINE_MISSING'; return }
    $vf = Join-Path $script:EngineDir 'VERSION'
    $raw = ''
    if (Test-Path -LiteralPath $vf -PathType Leaf) {
        try { $raw = [System.IO.File]::ReadAllText($vf) } catch { $raw = '' }
    }
    $raw = ([string]$raw).TrimStart([char]0xFEFF).Trim()
    if (-not ($raw -match '^[vV]?(\d+)\.(\d+)')) { Add-SdCode 'ENGINE_MISSING'; return }
    $major = [long]$matches[1]
    $minor = [long]$matches[2]
    $script:EngineVersion = ('{0}.{1}' -f $major, $minor)
    if (($major -gt $script:MinEngineMajor) -or (($major -eq $script:MinEngineMajor) -and ($minor -ge $script:MinEngineMinor))) {
        Add-SdCode 'ENGINE_OK'
    } else {
        Add-SdCode 'ENGINE_TOO_OLD'
    }
}

# -----------------------------------------------------------------------------
# 3・4. 置き場所と先頭の形 (/soloptilink-boost を見る)
# -----------------------------------------------------------------------------
function Get-SdBoostState {
    $skillMd = Join-Path (Join-Path (Join-Path $script:ConfigDir 'skills') $script:BoostName) 'SKILL.md'
    $cmdMd = Join-Path (Join-Path $script:ConfigDir 'commands') ($script:BoostName + '.md')
    $s = Get-SdMdState $skillMd $script:BoostName
    $c = Get-SdMdState $cmdMd $script:BoostName
    if (($s -eq 'missing') -or ($c -eq 'missing')) { return 'missing' }
    if (($s -eq 'bad') -or ($c -eq 'bad')) { return 'bad' }
    return 'ok'
}

function Test-SdEvicted {
    if ([string]$env:SOLOPTILINK_EVICT_GUARD -eq 'off') { return $false }
    $cands = @(
        (Join-Path $script:ConfigDir '.soloptilink-evicted.json'),
        (Join-Path (Join-Path $script:HomeDir '.claude') '.soloptilink-evicted.json')
    )
    if ($env:SL_EVICT_TOMBSTONE) { $cands += [string]$env:SL_EVICT_TOMBSTONE }
    foreach ($p in $cands) { if ($p -and (Test-Path -LiteralPath $p -PathType Leaf)) { return $true } }
    return $false
}

function Test-SdAdminOnly([string]$SrcDir, [string]$Name) {
    if ($script:AdminNames -contains $Name) { return $true }
    if (Test-Path -LiteralPath (Join-Path $SrcDir '.admin-only')) { return $true }
    $sk = Join-Path $SrcDir 'SKILL.md'
    try {
        $head = (Get-Content -LiteralPath $sk -TotalCount 30 -Encoding UTF8 -ErrorAction Stop) -join "`n"
        if ($head -match '(?m)^admin_only:\s*true\s*$') { return $true }
    } catch { }
    return $false
}

# フォルダの中身を写す (Windows は導入と同じ robocopy の流儀)
function Copy-SdTree([string]$Src, [string]$Dst, [switch]$Overwrite) {
    if ($script:OnWindows) {
        if ($Overwrite) {
            & robocopy.exe "$Src" "$Dst" /E /IS /NFL /NDL /NJH /NJS /R:2 /W:2 | Out-Null
        } else {
            & robocopy.exe "$Src" "$Dst" /E /NFL /NDL /NJH /NJS /R:1 /W:1 | Out-Null
        }
        $rc = $LASTEXITCODE
        $global:LASTEXITCODE = 0
        return ($rc -lt 8)
    }
    try {
        if (-not (Test-Path -LiteralPath $Dst)) { New-Item -ItemType Directory -Path $Dst -Force -ErrorAction Stop | Out-Null }
        foreach ($ch in @(Get-ChildItem -LiteralPath $Src -Force -ErrorAction Stop)) {
            Copy-Item -LiteralPath $ch.FullName -Destination $Dst -Recurse -Force -ErrorAction Stop
        }
        return $true
    } catch { return $false }
}

# 置き直す前の控えの置き場 (SPEC 7 節・3 つの入口で同じ): <本体の置き場>\var\slash-doctor\backups\<時刻>
#   中は skills\<名前>\ と commands\<名前>.md。リンク (再解析点) の置き場には書かない (そのときは '' を返す)。
#   ★本体の置き場の中に置く理由: 解約の片付け (lib/evict) は本体の置き場の中を全部数え、当社の配布物と同じものだけを
#     取り除き、それ以外 (お客様が手を入れていたもの) はお客様の控えの ZIP へ写して残す。設定の場所の _backups は
#     一度も見ていなかった (2026-11-11 審査の所見)。
function Get-SdBackupRoot([string]$Stamp) {
    $var = Join-Path $script:EngineDir 'var'
    $sd = Join-Path $var 'slash-doctor'
    $bk = Join-Path $sd 'backups'
    foreach ($p in @($var, $sd, $bk)) {
        if ((Test-Path -LiteralPath $p) -and (Test-SdReparse $p)) { return '' }
    }
    return (Join-Path $bk $Stamp)
}

# 1 つのメニューの控えを取る (フォルダは skills\<名前>、呼び出し口は commands\<名前>.md)
function Save-SdBackup([string]$BkRoot, [string]$Name, [string]$Tgt, [string]$CmdFile, [bool]$WithDir) {
    if ($WithDir -and (Test-Path -LiteralPath $Tgt)) {
        if (-not (Copy-SdTree $Tgt (Join-Path (Join-Path $BkRoot 'skills') $Name))) { throw 'backup-failed' }
    }
    if (Test-Path -LiteralPath $CmdFile) {
        $cmdBk = Join-Path $BkRoot 'commands'
        if (-not (Test-Path -LiteralPath $cmdBk)) { New-Item -ItemType Directory -Path $cmdBk -Force -ErrorAction Stop | Out-Null }
        Copy-Item -LiteralPath $CmdFile -Destination (Join-Path $cmdBk ($Name + '.md')) -Force -ErrorAction Stop
    }
}

# 本体の skills から、欠けている・壊れているメニューだけを置き直す
#   ★正しく置かれているものには触れない (お客様が手を入れていても消さない)。
#   ★入れ替える前に控えを取る (<本体の置き場>\var\slash-doctor\backups\<日時>)。
#   ★管理者専用は置かない。リンク (再解析点) になっている置き場には触れない。
function Invoke-SdPlace {
    $src = Join-Path $script:EngineDir 'skills'
    if (-not (Test-Path -LiteralPath $src -PathType Container)) { Add-SdNote 'fix: engine-skills-missing'; return }
    $boostSrc = Join-Path (Join-Path $src $script:BoostName) 'SKILL.md'
    if ((Get-SdMdState $boostSrc $script:BoostName) -ne 'ok') { Add-SdNote 'fix: engine-boost-unusable'; return }

    $skillsDst = Join-Path $script:ConfigDir 'skills'
    $cmdsDst = Join-Path $script:ConfigDir 'commands'
    try {
        if (-not (Test-Path -LiteralPath $skillsDst)) { New-Item -ItemType Directory -Path $skillsDst -Force -ErrorAction Stop | Out-Null }
        if (-not (Test-Path -LiteralPath $cmdsDst)) { New-Item -ItemType Directory -Path $cmdsDst -Force -ErrorAction Stop | Out-Null }
    } catch { Add-SdNote 'fix: cannot-create-config-dir'; return }

    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $bkRoot = Get-SdBackupRoot $stamp
    if (-not $bkRoot) { Add-SdNote 'fix: backup-root-is-link'; return }

    foreach ($d in @(Get-ChildItem -LiteralPath $src -Directory -Force -ErrorAction SilentlyContinue)) {
        $name = $d.Name
        $srcMd = Join-Path $d.FullName 'SKILL.md'
        if (-not (Test-Path -LiteralPath $srcMd -PathType Leaf)) { continue }
        if (Test-SdAdminOnly $d.FullName $name) { continue }
        if ((Get-SdMdState $srcMd '') -ne 'ok') { continue }   # 配布物の側が壊れているものは置かない

        $tgt = Join-Path $skillsDst $name
        $cmdFile = Join-Path $cmdsDst ($name + '.md')
        $sState = Get-SdMdState (Join-Path $tgt 'SKILL.md') ''
        $cState = Get-SdMdState $cmdFile ''
        if (($sState -eq 'ok') -and ($cState -eq 'ok')) { continue }

        try {
            if ((Test-SdReparse $tgt) -or (Test-SdReparse $cmdFile)) { throw 'reparse-point' }
            $copiedDir = $false
            # 入れ替える前に控えを取る (フォルダを置き直すときはフォルダも・呼び出し口は在れば必ず)
            Save-SdBackup $bkRoot $name $tgt $cmdFile ($sState -ne 'ok')
            if ($sState -ne 'ok') {
                if (Test-Path -LiteralPath $tgt) {
                    Remove-Item -LiteralPath $tgt -Recurse -Force -ErrorAction Stop
                }
                if (-not (Copy-SdTree $d.FullName $tgt -Overwrite)) { throw 'copy-failed' }
                $copiedDir = $true
            }
            Copy-Item -LiteralPath $srcMd -Destination $cmdFile -Force -ErrorAction Stop
            # 写しが途中で切れていないことを、元と写しの大きさで確かめる (今回写したものだけ)
            $a = (Get-Item -LiteralPath $srcMd -Force).Length
            $c = (Get-Item -LiteralPath $cmdFile -Force).Length
            if ($a -ne $c) { throw 'size-mismatch' }
            if ($copiedDir) {
                $b = (Get-Item -LiteralPath (Join-Path $tgt 'SKILL.md') -Force).Length
                if ($a -ne $b) { throw 'size-mismatch' }
            }
            $script:PlacedCount++
        } catch {
            $script:FailedNames += $name
            Add-SdNote ('fix: {0} failed ({1})' -f $name, $_.Exception.Message)
        }
    }
}

# 置き直してよい端末か (理由はメモにだけ残す・Mac の bash 版の _sd_fix_allowed と同じ)
function Test-SdFixAllowed([bool]$Evicted) {
    if ($Evicted) { Add-SdNote 'fix: skipped-evicted'; return $false }
    if (-not (Test-SdCode 'ENGINE_OK')) { Add-SdNote 'fix: skipped-engine-not-ok'; return $false }
    if (Test-Path -LiteralPath (Join-Path $script:EngineDir '.admin_mode')) { Add-SdNote 'fix: skipped-admin-mode'; return $false }
    if (Test-SdCode 'TRIAL_ENDED') { Add-SdNote 'fix: skipped-trial-ended'; return $false }
    if (Test-SdCode 'DEVICE_REVOKED') { Add-SdNote 'fix: skipped-device-revoked'; return $false }
    return $true
}

# フォルダの中身が同じか (配布物の側にあるファイルが、置き場に同じ中身であるか)
function Test-SdSameTree([string]$Src, [string]$Dst) {
    if (-not (Test-Path -LiteralPath $Dst -PathType Container)) { return $false }
    $srcRoot = (Get-Item -LiteralPath $Src -Force).FullName.TrimEnd('\', '/')
    foreach ($f in @(Get-ChildItem -LiteralPath $Src -Recurse -File -Force -ErrorAction SilentlyContinue)) {
        $rel = $f.FullName.Substring($srcRoot.Length).TrimStart('\', '/')
        $other = Join-Path $Dst $rel
        if (-not (Test-Path -LiteralPath $other -PathType Leaf)) { return $false }
        try {
            $a = [System.IO.File]::ReadAllBytes($f.FullName)
            $b = [System.IO.File]::ReadAllBytes($other)
        } catch { return $false }
        if ($a.Length -ne $b.Length) { return $false }
        for ($i = 0; $i -lt $a.Length; $i++) { if ($a[$i] -ne $b[$i]) { return $false } }
    }
    return $true
}

# 置き場所は正しく見えるのに一覧に出ないとき: /soloptilink-boost の中身が本体の正本と違えば、控えを取って置き直す
#   (Mac の bash 版の強制の置き直しと同じ。中身が同じなら置き直しても変わらないので何もしない)
function Invoke-SdForcePlaceBoost {
    $src = Join-Path (Join-Path $script:EngineDir 'skills') $script:BoostName
    $srcMd = Join-Path $src 'SKILL.md'
    if ((Get-SdMdState $srcMd $script:BoostName) -ne 'ok') { return $false }
    $tgt = Join-Path (Join-Path $script:ConfigDir 'skills') $script:BoostName
    $cmdFile = Join-Path (Join-Path $script:ConfigDir 'commands') ($script:BoostName + '.md')
    $sameCmd = $false
    try {
        if (Test-Path -LiteralPath $cmdFile -PathType Leaf) {
            $sameCmd = ([System.IO.File]::ReadAllText($srcMd) -ceq [System.IO.File]::ReadAllText($cmdFile))
        }
    } catch { $sameCmd = $false }
    if ($sameCmd -and (Test-SdSameTree $src $tgt)) { Add-SdNote 'refix: boost-same-as-engine'; return $false }
    if ((Test-SdReparse $tgt) -or (Test-SdReparse $cmdFile)) { Add-SdNote 'refix: reparse-point'; return $false }
    $bkRoot = Get-SdBackupRoot (Get-Date -Format 'yyyyMMdd-HHmmss')
    if (-not $bkRoot) { Add-SdNote 'refix: backup-root-is-link'; return $false }
    try {
        Save-SdBackup $bkRoot $script:BoostName $tgt $cmdFile $true
        if (Test-Path -LiteralPath $tgt) {
            Remove-Item -LiteralPath $tgt -Recurse -Force -ErrorAction Stop
        }
        if (-not (Copy-SdTree $src $tgt -Overwrite)) { throw 'copy-failed' }
        Copy-Item -LiteralPath $srcMd -Destination $cmdFile -Force -ErrorAction Stop
        $script:PlacedCount++
        return $true
    } catch {
        $script:FailedNames += $script:BoostName
        Add-SdNote ('refix: failed ({0})' -f $_.Exception.Message)
        return $false
    }
}

# -----------------------------------------------------------------------------
# 5. Claude Code の実行ファイルと版
# -----------------------------------------------------------------------------
function Find-SdClaude {
    $cands = @()
    try {
        foreach ($c in @(Get-Command -Name 'claude' -CommandType Application -ErrorAction SilentlyContinue)) {
            $src = ''
            if (Test-SdProp $c 'Source') { $src = [string]$c.Source }
            if (-not $src -and (Test-SdProp $c 'Path')) { $src = [string]$c.Path }
            if ($src) { $cands += $src }
        }
    } catch { }
    if ($script:OnWindows) {
        $cands += (Join-Path $script:HomeDir '.local\bin\claude.exe')
        $cands += (Join-Path $script:HomeDir '.local\bin\claude.cmd')
        if ($env:LOCALAPPDATA) {
            $cands += (Join-Path ([string]$env:LOCALAPPDATA) 'Programs\claude\claude.exe')
            $cands += (Join-Path ([string]$env:LOCALAPPDATA) 'Programs\claude\claude.cmd')
        }
        # .exe を .cmd より先に使う (cmd.exe を挟まない方が止めやすい)
        $exe = @($cands | Where-Object { $_ -match '\.exe$' })
        $rest = @($cands | Where-Object { $_ -notmatch '\.exe$' })
        $cands = @($exe) + @($rest)
    } else {
        $cands += (Join-Path (Join-Path (Join-Path $script:HomeDir '.local') 'bin') 'claude')
    }
    foreach ($p in $cands) {
        if ($p -and (Test-Path -LiteralPath $p -PathType Leaf)) { return [string]$p }
    }
    return ''
}

function Test-SdClaude {
    $script:ClaudePath = Find-SdClaude
    if (-not $script:ClaudePath) { Add-SdCode 'CLAUDE_CODE_MISSING'; return }
    Add-SdCode 'CLAUDE_CODE_FOUND'
    $r = Invoke-SdCapture $script:ClaudePath '--version' 15000 '' $true
    if ($r.ok -and ([string]$r.out -match '(\d+\.\d+\.\d+)')) { $script:ClaudeVersion = $matches[1] }
}

# -----------------------------------------------------------------------------
# 6. 実測: 起動直後の「使える機能の一覧」に soloptilink-boost があるか
#   作業場所は空の一時フォルダ (お客様の案件のフォルダで起動しない)。init を読んだら直ちに止める
#   (本体への問い合わせの前)。上限は 45 秒。
# -----------------------------------------------------------------------------
# 起動確認の作業場所: <一時フォルダ>\soloptilink-slash-probe\work (固定の名前。結果の控え state とは分ける)
function Get-SdProbeWorkDir {
    return (Join-Path (Join-Path ([System.IO.Path]::GetTempPath()) 'soloptilink-slash-probe') 'work')
}

# 作業場所を消す。消してよいのは「固定の名前で終わる当社のフォルダ」で「リンク (別の場所への近道) でない」ときだけ。
#   戻り値: 消せた・もともと無い = $true / 消してはいけない・消せなかった = $false
function Remove-SdProbeWorkDir([string]$dir) {
    try {
        if (-not (Test-Path -LiteralPath $dir)) { return $true }
        $leaf = Split-Path -Leaf $dir
        $parentLeaf = Split-Path -Leaf (Split-Path -Parent $dir)
        if (($leaf -ne 'work') -or ($parentLeaf -ne 'soloptilink-slash-probe')) { return $false }
        foreach ($d in @($dir, (Split-Path -Parent $dir))) {
            $it = Get-Item -LiteralPath $d -Force -ErrorAction Stop
            if (($it.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { return $false }
        }
        Remove-Item -LiteralPath $dir -Recurse -Force -ErrorAction Stop
        if (Test-Path -LiteralPath $dir) { return $false }
        # 親 (soloptilink-slash-probe) は中身が空のときだけ消す (結果の控え state などが在れば残す)
        $parent = Split-Path -Parent $dir
        try {
            if (@(Get-ChildItem -LiteralPath $parent -Force -ErrorAction Stop).Count -eq 0) {
                Remove-Item -LiteralPath $parent -Force -ErrorAction SilentlyContinue
            }
        } catch { }
        return $true
    } catch {
        return $false
    }
}

function Invoke-SdProbe {
    foreach ($c in @('PROBE_VISIBLE', 'PROBE_NOT_VISIBLE', 'PROBE_TIMEOUT', 'PROBE_SKIPPED')) { Remove-SdCode $c }
    $script:Probe.note = ''
    if (($NoProbe) -or ([string]$env:SOLOPTILINK_SLASH_PROBE -eq 'off')) { Add-SdCode 'PROBE_SKIPPED'; return }
    if (-not $script:ClaudePath) { Add-SdCode 'PROBE_SKIPPED'; return }   # SPEC 6 節 6: claude が無いときも付ける

    # ★2026-11-11 審査の不承認 1 の直し: 作業場所は当社の固定の名前のフォルダの中の work だけにする。
    #   作れなかったときは、一時フォルダ全体などへ切り替えずに、起動確認そのものをやめる
    #   (切り替えた先を最後に丸ごと消すと、お客様や他のソフトの一時ファイルが消えるため)。
    $work = Get-SdProbeWorkDir
    if (-not (Remove-SdProbeWorkDir $work)) {
        Add-SdNote 'probe: workdir-not-removable'
        Add-SdCode 'PROBE_SKIPPED'
        return
    }
    try {
        New-Item -ItemType Directory -Path $work -Force -ErrorAction Stop | Out-Null
    } catch {
        Add-SdNote ('probe: workdir-failed ({0})' -f $_.Exception.Message)
        Add-SdCode 'PROBE_SKIPPED'
        return
    }
    # 作れたと返っても実在しないことがある (親がファイルのときなど) ので、フォルダとして在るかを確かめる
    if (-not (Test-Path -LiteralPath $work -PathType Container)) {
        Add-SdNote 'probe: workdir-missing'
        Add-SdCode 'PROBE_SKIPPED'
        return
    }

    $script:Probe.ran = $true
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $deadlineMs = [long]$ProbeTimeoutSec * 1000
    $p = $null
    $init = $null
    $exitedEarly = $false
    try {
        # --no-session-persistence: お客様の .claude\projects に会話の記録を残さない (-p のときだけ効く・SPEC 7 節)
        $psi = New-SdStartInfo $script:ClaudePath '-p ok --output-format stream-json --verbose --max-turns 1 --no-session-persistence' $work
        Set-SdClaudeEnv $psi
        $p = [System.Diagnostics.Process]::Start($psi)
        $script:Probe.pid = $p.Id
        try { $p.StandardInput.Close() } catch { }
        $null = $p.StandardError.ReadToEndAsync()
        $lineTask = $null
        while ($true) {
            $left = $deadlineMs - $sw.ElapsedMilliseconds
            if ($left -le 0) { break }
            if ($null -eq $lineTask) { $lineTask = $p.StandardOutput.ReadLineAsync() }
            $waitMs = [int][Math]::Min(500, $left)
            $done = $false
            try { $done = $lineTask.Wait($waitMs) } catch { $exitedEarly = $true; break }
            if (-not $done) { continue }
            $line = $lineTask.Result
            $lineTask = $null
            if ($null -eq $line) { $exitedEarly = $true; break }
            if ($line -notmatch '"subtype"\s*:\s*"init"') { continue }
            $obj = $null
            try { $obj = $line | ConvertFrom-Json -ErrorAction Stop } catch { continue }
            if ((Test-SdProp $obj 'type') -and (Test-SdProp $obj 'subtype') -and ($obj.type -eq 'system') -and ($obj.subtype -eq 'init')) {
                $init = $obj
                break
            }
        }
    } catch {
        $exitedEarly = $true
        Add-SdNote ('probe: start-failed ({0})' -f $_.Exception.Message)
    } finally {
        # 一覧を読んだら (読めなくても) 直ちに止める
        Stop-SdProcessTree $p
    }
    $script:Probe.seconds = [Math]::Round($sw.Elapsed.TotalSeconds, 1)
    $null = Remove-SdProbeWorkDir $work

    if ($null -eq $init) {
        # 時間内に一覧を読めなかった (途中で終わった場合も、表示されないとは言えないので未確認として扱う)
        if ($exitedEarly) { $script:Probe.note = 'exited-without-init' } else { $script:Probe.note = 'timeout' }
        Add-SdCode 'PROBE_TIMEOUT'
        return
    }
    if ((Test-SdProp $init 'claude_code_version') -and $init.claude_code_version) {
        $script:ClaudeVersion = [string]$init.claude_code_version
    }
    $found = $false
    if (Test-SdProp $init 'slash_commands') {
        foreach ($sc in @($init.slash_commands)) {
            $n = ([string]$sc).Trim().TrimStart('/')
            if ($n -eq $script:BoostName) { $found = $true; break }
        }
    }
    if ($found) { Add-SdCode 'PROBE_VISIBLE' } else { Add-SdCode 'PROBE_NOT_VISIBLE' }
}

# -----------------------------------------------------------------------------
# 7. 端末の登録の状態
# -----------------------------------------------------------------------------
function Test-SdDevice {
    foreach ($c in @('DEVICE_REGISTERED', 'DEVICE_NOT_REGISTERED', 'DEVICE_PENDING_APPROVAL', 'DEVICE_REVOKED')) { Remove-SdCode $c }
    $act = Join-Path $script:EngineDir 'activation.json'
    $plan = ''
    if (Test-Path -LiteralPath $act -PathType Leaf) {
        Add-SdCode 'DEVICE_REGISTERED'
        try {
            $o = [System.IO.File]::ReadAllText($act) | ConvertFrom-Json -ErrorAction Stop
            if (Test-SdProp $o 'device_id') {
                $id = [string]$o.device_id
                # 端末の番号だけを送る (形が違うものは送らない)
                if ($id -match '^[A-Za-z0-9_.:-]{1,128}$') { $script:DeviceId = $id }
            }
            if (Test-SdProp $o 'plan_kind') { $plan = [string]$o.plan_kind }
        } catch { Add-SdNote 'device: activation-unreadable' }
    } else {
        Add-SdCode 'DEVICE_NOT_REGISTERED'
    }
    if (($plan -eq 'trial') -or (Test-Path -LiteralPath (Join-Path (Join-Path $script:EngineDir '.free-trial') 'marker.json'))) {
        $script:InstallKind = 'trial'
    } elseif (Test-Path -LiteralPath $act -PathType Leaf) {
        # 種類が書かれていない登録 (試用の仕組みより前からのお客様) は有料と数える (Mac の bash 版と同じ)
        $script:InstallKind = 'paid'
    }
    # 承認待ち・取り消しの見分け (T1-067・SPEC 7 節・Mac の bash 版と同じ規則)。起動用プログラムが端末に残す記録だけを読む。
    #   取り消し: .license-revoked の印、または license.json の status が revoked・rejected・suspended・contract_expired
    #   承認待ち: .activation-pending.json の記録、または license.json の status が pending (license.json が approved なら言わない)
    $lst = ''
    $lic = Join-Path $script:EngineDir 'license.json'
    if ((Test-Path -LiteralPath $lic -PathType Leaf) -and -not (Test-SdReparse $lic)) {
        try {
            $lo = [System.IO.File]::ReadAllText($lic) | ConvertFrom-Json -ErrorAction Stop
            if (Test-SdProp $lo 'status') { $lst = ([string]$lo.status).Trim().ToLowerInvariant() }
        } catch { Add-SdNote 'device: license-unreadable' }
    }
    $revokedMark = Join-Path $script:EngineDir '.license-revoked'
    $pendingMark = Join-Path $script:EngineDir '.activation-pending.json'
    $revoked = ((Test-Path -LiteralPath $revokedMark -PathType Leaf) -and -not (Test-SdReparse $revokedMark)) -or
        (@('revoked', 'rejected', 'suspended', 'contract_expired') -contains $lst)
    $pending = ((Test-Path -LiteralPath $pendingMark -PathType Leaf) -and -not (Test-SdReparse $pendingMark)) -or ($lst -eq 'pending')
    if ($revoked) { Add-SdCode 'DEVICE_REVOKED' }
    elseif ($pending -and ($lst -ne 'approved')) { Add-SdCode 'DEVICE_PENDING_APPROVAL' }
}

# -----------------------------------------------------------------------------
# 8. 試用の状態
#   ★entitlement.sh gate ではなく、その内側の free-trial.sh gate を読む。
#     entitlement.sh gate は試用中だと「機能を使った」記録と送信を起こすため、診断が利用の回数を数えてしまう。
#     1 行目の語 (NOT-TRIAL / TRIAL-ACTIVE / TRIAL-ENDED / TRIAL-SKILL-NOT-INCLUDED) は同じ。
# -----------------------------------------------------------------------------
function Find-SdBash {
    $c = @()
    if ($script:OnWindows) {
        if ($env:ProgramFiles) { $c += (Join-Path ([string]$env:ProgramFiles) 'Git\bin\bash.exe') }
        if (${env:ProgramFiles(x86)}) { $c += (Join-Path ([string]${env:ProgramFiles(x86)}) 'Git\bin\bash.exe') }
        if ($env:LOCALAPPDATA) { $c += (Join-Path ([string]$env:LOCALAPPDATA) 'Programs\Git\bin\bash.exe') }
        foreach ($g in @(Get-Command -Name 'bash' -CommandType Application -ErrorAction SilentlyContinue)) {
            $s = ''
            if (Test-SdProp $g 'Source') { $s = [string]$g.Source }
            # System32 の bash.exe は WSL への入口で、Windows の場所を読めない
            if ($s -and ($s -notmatch '\\System32\\')) { $c += $s }
        }
    } else {
        $c += '/bin/bash'
        $c += '/usr/bin/bash'
    }
    foreach ($p in $c) { if ($p -and (Test-Path -LiteralPath $p -PathType Leaf)) { return [string]$p } }
    return ''
}

function Test-SdTrial {
    $marked = ($script:InstallKind -eq 'trial')
    if (-not $marked) { Add-SdCode 'NOT_TRIAL'; return }
    $gate = Join-Path (Join-Path (Join-Path $script:EngineDir 'lib') 'free-trial') 'free-trial.sh'
    $bash = Find-SdBash
    if ((-not $bash) -or (-not (Test-Path -LiteralPath $gate -PathType Leaf))) { Add-SdNote 'trial: unavailable'; return }
    $r = Invoke-SdCapture $bash ('"' + $gate + '" gate ' + $script:BoostName) 8000 '' $false
    if (-not $r.ok) { Add-SdNote 'trial: timeout'; return }
    $lines = @(([string]$r.out) -split "`r?`n" | Where-Object { $_ -ne $null })
    $first = ''
    if ($lines.Count -gt 0) { $first = ([string]$lines[0]).Trim() }
    switch ($first) {
        'NOT-TRIAL' { Add-SdCode 'NOT_TRIAL' }
        'TRIAL-ACTIVE' { Add-SdCode 'TRIAL_ACTIVE' }
        'TRIAL-ENDED' { Add-SdCode 'TRIAL_ENDED' }
        'TRIAL-SKILL-NOT-INCLUDED' {
            Add-SdCode 'TRIAL_SKILL_NOT_INCLUDED'
            # 案内は試用の関所が出す文をそのまま使う (2 行目以降)
            $script:TrialText = @($lines | Select-Object -Skip 1 | Where-Object { ([string]$_).Trim() })
        }
        default { Add-SdNote 'trial: unreadable' }
    }
}

# -----------------------------------------------------------------------------
# 9. Claude Desktop が起動中か
# -----------------------------------------------------------------------------
function Test-SdDesktop {
    try {
        foreach ($pr in @(Get-Process -Name 'Claude' -ErrorAction SilentlyContinue)) {
            $path = ''
            try { $path = [string]$pr.Path } catch { $path = '' }
            if (-not $path) { continue }
            # Claude Code の実行ファイル (~\.local\bin・~/.local/share/claude) は Desktop ではない
            if ($path -match '[\\/]\.local[\\/]') { continue }
            if ($script:ClaudePath -and ($path -ieq $script:ClaudePath)) { continue }
            Add-SdCode 'DESKTOP_RUNNING'
            return
        }
    } catch { }
}

# -----------------------------------------------------------------------------
# 当社へ届ける (SPEC 4 節。個人の情報は送らない・3 秒で諦める・送れなくても止めない)
# -----------------------------------------------------------------------------
function Get-SdApiBase {
    $u = ([string]$env:SOLOPTILINK_API_URL).Trim()
    if (-not $u) { return $script:DefaultApiBase }
    # 起動用プログラム (license.go の validateAPIBaseURL) と同じ範囲の宛先にだけ送る
    $uri = $null
    try { $uri = New-Object System.Uri($u) } catch { return '' }
    if ($uri.UserInfo -or $uri.Query -or $uri.Fragment) { return '' }
    $h = $uri.Host.Trim('[', ']')
    if (($uri.Scheme -eq 'https') -and (@('admin-dashboard-blue-alpha-78.vercel.app', 'localhost', '127.0.0.1', '::1') -contains $h)) {
        return $u.TrimEnd('/')
    }
    if (($uri.Scheme -eq 'http') -and (@('localhost', '127.0.0.1') -contains $h) -and (-not $uri.IsDefaultPort)) {
        return $u.TrimEnd('/')
    }
    return ''
}

# お客様の「送らない」ご指定を守る (lib\telemetry-consent.contract の取り決めを読む。名前は書き写さない)
#   取り決めを読めないときは送らない (起動用プログラムの telemetrySendingEnabled と同じ倒れ方)。
function Test-SdSendAllowed {
    $roots = @($script:EngineDir, (Join-Path $script:HomeDir '.soloptilink'))
    $kv = $null
    foreach ($r in $roots) {
        $f = Join-Path (Join-Path $r 'lib') 'telemetry-consent.contract'
        if (-not (Test-Path -LiteralPath $f -PathType Leaf)) { continue }
        $kv = @{}
        try {
            foreach ($l in @(Get-Content -LiteralPath $f -Encoding UTF8 -ErrorAction Stop)) {
                $t = ([string]$l).Trim()
                if ((-not $t) -or $t.StartsWith('#')) { continue }
                $i = $t.IndexOf('=')
                if ($i -lt 1) { continue }
                $kv[$t.Substring(0, $i).Trim()] = $t.Substring($i + 1).Trim()
            }
        } catch { $kv = $null; continue }
        break
    }
    if ($null -eq $kv) { return $false }
    foreach ($k in @('TELEMETRY_OPTOUT_FILE_NAME', 'TELEMETRY_OPTOUT_ENV_NAME', 'TELEMETRY_BASE_DIR_ENV_NAME', 'AUTH_EGRESS_STOP_FILE_NAME', 'AUTH_EGRESS_STOP_ENV_NAME')) {
        if (-not $kv.ContainsKey($k) -or -not $kv[$k]) { return $false }
    }
    $stopWords = @('1', 'true', 'TRUE', 'yes', 'YES')
    foreach ($envKey in @($kv['TELEMETRY_OPTOUT_ENV_NAME'], $kv['AUTH_EGRESS_STOP_ENV_NAME'])) {
        $v = [string][Environment]::GetEnvironmentVariable([string]$envKey)
        if ($stopWords -ccontains $v.Trim()) { return $false }
    }
    $bases = @((Join-Path $script:HomeDir '.soloptilink'), $script:EngineDir)
    $baseEnv = [string][Environment]::GetEnvironmentVariable([string]$kv['TELEMETRY_BASE_DIR_ENV_NAME'])
    if ($baseEnv.Trim()) { $bases += $baseEnv.Trim() }
    foreach ($b in $bases) {
        foreach ($mk in @($kv['TELEMETRY_OPTOUT_FILE_NAME'], $kv['AUTH_EGRESS_STOP_FILE_NAME'])) {
            if (Test-Path -LiteralPath (Join-Path $b ([string]$mk))) { return $false }
        }
    }
    return $true
}

function Get-SdOs {
    if ($script:OnWindows) { return 'windows' }
    if (Test-Path -LiteralPath '/System/Library/CoreServices') { return 'darwin' }
    return 'linux'
}

function Get-SdArch {
    $a = [string]$env:PROCESSOR_ARCHITEW6432
    if (-not $a) { $a = [string]$env:PROCESSOR_ARCHITECTURE }
    if (-not $a) {
        try { $a = [string][System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture } catch { $a = '' }
    }
    switch -Regex ($a) {
        '^(amd64|x64)$' { return 'amd64' }
        '^arm64$' { return 'arm64' }
        '^x86$' { return '386' }
        default { return ([string]$a).ToLowerInvariant() }
    }
}

function Get-SdReportBody([string]$Overall) {
    $codes = @($script:Codes | ForEach-Object { [string]$_ })
    $entryWord = $Entry
    $payload = [ordered]@{
        schema              = 1
        device_id           = $script:DeviceId
        install_kind        = $script:InstallKind
        engine_version      = $script:EngineVersion
        os                  = (Get-SdOs)
        arch                = (Get-SdArch)
        claude_code_version = $script:ClaudeVersion
        entry               = $entryWord
        overall             = $Overall
        codes               = $codes
        fixed               = [bool]$script:Fixed
        ts                  = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
    }
    return (ConvertTo-Json -InputObject $payload -Compress -Depth 4)
}

# 端末の記録 (<本体の置き場>\var\slash-doctor\history.log・Mac の bash 版と同じ置き場と形)。
#   退去済みの端末・本体が無い端末には書かない。書けなくても止めない。
function Write-SdHistory([string]$Line) {
    try {
        if ((Get-Variable -Name Evicted -Scope Script -ErrorAction SilentlyContinue) -and $script:Evicted) { return }
        if (-not (Test-Path -LiteralPath $script:EngineDir -PathType Container)) { return }
        $dir = Join-Path (Join-Path $script:EngineDir 'var') 'slash-doctor'
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null }
        $ts = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
        [System.IO.File]::AppendAllText((Join-Path $dir 'history.log'), ('{0} {1}' -f $ts, $Line) + "`n", (New-Object System.Text.UTF8Encoding($false)))
    } catch { }
}

# >>> SD-PII-CHECK-BEGIN
# 送る直前の検査 (T1-090・SPEC 7 節・Mac の bash 版の _sd_pii_reason と同じ規則)。
#   本文に個人の情報らしいものが入っていたら、その種類の名前を返す (無ければ '')。値そのものは返さない・記録しない。
#   見るもの: @ (メールアドレス)・HOME のパス (JSON の \\ の形も)・利用者のフォルダらしいパス・利用者名・端末名。
#   利用者名と端末名は、決まった語しか入らない項目 (符丁・版・機種・入口の名前・時刻) を除いた残りだけで比べる。
#   3 文字より短い名前は比べない。大文字と小文字は区別しない。
function Get-SdPiiReason([string]$Body) {
    if ($Body.Contains('@')) { return 'メールアドレス' }
    foreach ($h in @([string]$env:USERPROFILE, [string]$env:HOME, [string]$script:HomeDir)) {
        if ((-not $h) -or ($h.Length -lt 4)) { continue }
        if (($Body.IndexOf($h, [StringComparison]::OrdinalIgnoreCase) -ge 0) -or
            ($Body.IndexOf($h.Replace('\', '\\'), [StringComparison]::OrdinalIgnoreCase) -ge 0)) { return 'HOME のパス' }
    }
    if ($Body -match '(?i)(/Users/|/home/|\\Users\\)') { return '利用者のフォルダのパス' }
    $rest = [regex]::Replace($Body, '"codes":\[[^\]]*\]', '')
    $rest = [regex]::Replace($rest, '"schema":\d+', '')
    $rest = [regex]::Replace($rest, '"fixed":(true|false)', '')
    $rest = [regex]::Replace($rest, '"(install_kind|engine_version|os|arch|claude_code_version|entry|overall|ts)":"[^"]*"', '')
    $rest = $rest.Replace('"device_id":', '').ToLowerInvariant()
    $names = @([string]$env:USERNAME, [string]$env:USER, [string]$env:LOGNAME)
    try { $names += [string][Environment]::UserName } catch { }
    if ($script:HomeDir) { $names += [string](Split-Path -Leaf $script:HomeDir) }
    foreach ($n in $names) {
        $l = ([string]$n).Trim().ToLowerInvariant()
        if (($l.Length -ge 3) -and $rest.Contains($l)) { return '利用者名' }
    }
    $hosts = @([string]$env:COMPUTERNAME)
    try { $hosts += [string][Environment]::MachineName } catch { }
    try { $hosts += [string][System.Net.Dns]::GetHostName() } catch { }
    foreach ($n in $hosts) {
        $l = ([string]$n).Trim().ToLowerInvariant()
        foreach ($s in @($l, ($l -split '\.')[0])) {
            if (($s.Length -ge 3) -and $rest.Contains($s)) { return '端末名' }
        }
    }
    return ''
}
# <<< SD-PII-CHECK-END

function Send-SdReport([string]$Body) {
    if ([string]$env:SOLOPTILINK_SLASH_REPORT -eq 'off') { return 'off' }
    if (-not (Test-SdSendAllowed)) { return 'consent-stopped' }
    $base = Get-SdApiBase
    if (-not $base) { return 'destination-not-allowed' }
    if ([System.Text.Encoding]::UTF8.GetByteCount($Body) -gt 2048) { return 'too-large' }
    # 送る直前の検査 (T1-090): 個人の情報らしいものが入っていたら送らずに、端末の記録へ理由だけを残す
    $why = Get-SdPiiReason $Body
    if ($why) {
        Write-SdHistory ('REPORT_BLOCKED 送らなかった（理由: {0}らしい値が本文に入っていた）' -f $why)
        return 'pii-blocked'
    }
    $client = $null
    try {
        try { Add-Type -AssemblyName System.Net.Http -ErrorAction Stop } catch { }
        try {
            [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor [System.Net.SecurityProtocolType]::Tls12
        } catch { }
        $client = New-Object System.Net.Http.HttpClient
        $client.Timeout = [TimeSpan]::FromSeconds(3)
        $content = New-Object System.Net.Http.StringContent($Body, (New-Object System.Text.UTF8Encoding($false)), 'application/json')
        $task = $client.PostAsync($base + '/install/slash-check', $content)
        $done = $false
        try { $done = $task.Wait(3000) } catch {
            # 通信の側の 3 秒の打ち切り (取り消し) が先に来たときも「時間切れ」として記録する
            $ex = $_.Exception
            while ($null -ne $ex) {
                if ($ex -is [System.OperationCanceledException]) { return 'timeout' }
                $ex = $ex.InnerException
            }
            return 'failed'
        }
        if (-not $done) { return 'timeout' }
        $code = [int]$task.Result.StatusCode
        if (($code -ge 200) -and ($code -lt 300)) { return 'sent' }
        return ('http-{0}' -f $code)
    } catch {
        return 'failed'
    } finally {
        if ($null -ne $client) { try { $client.Dispose() } catch { } }
    }
}

# -----------------------------------------------------------------------------
# 総合の判定と案内文 (SPEC 2 節・3 節)
# -----------------------------------------------------------------------------
function Get-SdOverall {
    if (Test-SdCode 'PROBE_VISIBLE') { return 'VISIBLE' }
    $placed = (Test-SdCode 'SKILLS_PLACED') -and (Test-SdCode 'FRONTMATTER_OK')
    $unmeasured = (Test-SdCode 'PROBE_SKIPPED') -or (Test-SdCode 'PROBE_TIMEOUT') -or (Test-SdCode 'CLAUDE_CODE_MISSING')
    if ($placed -and $unmeasured -and -not (Test-SdCode 'PROBE_NOT_VISIBLE')) { return 'PLACED_UNVERIFIED' }
    return 'NOT_VISIBLE'
}

function Get-SdMessages([string]$Overall) {
    $m = New-Object System.Collections.ArrayList
    if (Test-SdCode 'FIXED_REPLACED') { [void]$m.Add($script:MsgFixed) }
    if ($Overall -eq 'VISIBLE') {
        [void]$m.Add($script:MsgVisible)
    } elseif ($Overall -eq 'PLACED_UNVERIFIED') {
        [void]$m.Add($script:MsgUnverified)
        if (Test-SdCode 'CLAUDE_CODE_MISSING') { [void]$m.Add($script:MsgClaudeMissing) }
    } else {
        $saidSkills = $false
        if ((Test-SdCode 'ENGINE_MISSING') -or (Test-SdCode 'SKILLS_MISSING') -or (Test-SdCode 'FRONTMATTER_BAD')) {
            [void]$m.Add($script:MsgSkillsMissing)
            $saidSkills = $true
        }
        if (Test-SdCode 'CLAUDE_CODE_MISSING') { [void]$m.Add($script:MsgClaudeMissing) }
        if ((Test-SdCode 'PROBE_NOT_VISIBLE') -and (-not $saidSkills)) { [void]$m.Add($script:MsgProbeNotVisible) }
    }
    if (Test-SdCode 'ENGINE_TOO_OLD') { [void]$m.Add($script:MsgEngineTooOld) }
    if (Test-SdCode 'TRIAL_ENDED') { [void]$m.Add($script:MsgTrialEnded) }
    if (Test-SdCode 'TRIAL_SKILL_NOT_INCLUDED') { foreach ($tx in $script:TrialText) { [void]$m.Add([string]$tx) } }
    if (Test-SdCode 'DEVICE_REVOKED') { [void]$m.Add($script:MsgDeviceRevoked) }
    if (Test-SdCode 'DEVICE_PENDING_APPROVAL') { [void]$m.Add($script:MsgDevicePending) }
    # 開いている Desktop の案内は、実測できなかったときだけ足す (出ない・出たときの案内は SPEC の文が開き直しまで述べている)
    if ((Test-SdCode 'DESKTOP_RUNNING') -and ($Overall -eq 'PLACED_UNVERIFIED')) { [void]$m.Add($script:MsgDesktopRunning) }
    [void]$m.Add($script:MsgCommonNote)
    return @($m | ForEach-Object { [string]$_ })
}

function Write-SdResult($Result) {
    if ($Json) {
        Write-Output (ConvertTo-Json -InputObject $Result -Compress -Depth 5)
        return
    }
    $label = ''
    switch ([string]$Result.overall) {
        'VISIBLE' { $label = 'スラッシュの一覧に出ることを確かめました' }
        'PLACED_UNVERIFIED' { $label = '置き場所までは確かめました (画面での表示はまだ確かめていません)' }
        'NOT_VISIBLE' { $label = 'スラッシュの一覧に出ない状態です' }
        default { $label = '診断を最後まで行えませんでした' }
    }
    Write-Host ''
    Write-Host ('[slash-doctor] /soloptilink-boost の確認: {0} ({1})' -f $label, [string]$Result.overall)
    foreach ($msg in @($Result.messages)) { Write-Host ('  ・{0}' -f $msg) }
    # お問い合わせのときに読み上げてもらう記号 (Mac の bash 版と同じ形)
    Write-Host ('  （お問い合わせ用の記号: {0} {1}）' -f [string]$Result.overall, (@($Result.codes) -join ' '))
    Write-Host ''
}

# -----------------------------------------------------------------------------
# 本体
# -----------------------------------------------------------------------------
if ([string]$env:SOLOPTILINK_SLASH_DOCTOR -eq 'off') {
    if ($Json) {
        Write-Output '{"schema":1,"disabled":true,"overall":"","codes":[],"fixed":false,"messages":[]}'
    } else {
        Write-Host '[slash-doctor] 診断は止める指定 (SOLOPTILINK_SLASH_DOCTOR=off) のため行いませんでした。'
    }
    exit 0
}

# -----------------------------------------------------------------------------
# 結果の保存と読み戻し (report 用・Mac の bash 版の _sd_save_last / _sd_load_last と同じ考え方)
# -----------------------------------------------------------------------------
function Get-SdLastPath {
    if (Test-Path -LiteralPath $script:EngineDir -PathType Container) {
        return (Join-Path (Join-Path (Join-Path $script:EngineDir 'var') 'slash-doctor') 'last.json')
    }
    return (Join-Path (Join-Path (Join-Path ([System.IO.Path]::GetTempPath()) 'soloptilink-slash-probe') 'state') 'last.json')
}

function Save-SdLast([string]$Overall) {
    try {
        $path = Get-SdLastPath
        $dir = Split-Path -Parent $path
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null }
        $tmp = $path + '.tmp.' + $PID
        [System.IO.File]::WriteAllText($tmp, (Get-SdReportBody $Overall), (New-Object System.Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $tmp -Destination $path -Force -ErrorAction Stop
    } catch { Add-SdNote 'save: failed' }
}

# 保存した結果を読み戻す。読めた項目だけ戻し、形の違う値は捨てる。読めなければ $null
function Read-SdLast {
    $path = Get-SdLastPath
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $null }
    $o = $null
    try { $o = [System.IO.File]::ReadAllText($path) | ConvertFrom-Json -ErrorAction Stop } catch { return $null }
    if (-not (Test-SdProp $o 'overall')) { return $null }
    $ov = [string]$o.overall
    if (@('VISIBLE', 'PLACED_UNVERIFIED', 'NOT_VISIBLE') -notcontains $ov) { return $null }
    if (Test-SdProp $o 'codes') {
        foreach ($c in @($o.codes)) { if ([string]$c -match '^[A-Z_]+$') { Add-SdCode ([string]$c) } }
    }
    if ((Test-SdProp $o 'engine_version') -and ([string]$o.engine_version -match '^[0-9.]*$')) { $script:EngineVersion = [string]$o.engine_version }
    if ((Test-SdProp $o 'claude_code_version') -and ([string]$o.claude_code_version -match '^[0-9.]*$')) { $script:ClaudeVersion = [string]$o.claude_code_version }
    if ((Test-SdProp $o 'fixed') -and ($o.fixed -eq $true)) { $script:Fixed = $true }
    return $ov
}

# check / fix の全体 (SPEC 1〜9)。総合の判定を返す
function Invoke-SdFullCheck([bool]$WantFix) {
    Test-SdEngine
    if ($script:ConfigOverride) { Add-SdCode 'CONFIG_DIR_OVERRIDE' } else { Add-SdCode 'CONFIG_DIR_DEFAULT' }
    # 置き直してよいか (試用の終了) を先に知るため、登録と試用は置き直しより前に調べる (Mac の bash 版と同じ順)
    Test-SdDevice
    Test-SdTrial

    $state = Get-SdBoostState
    if (($state -ne 'ok') -and $WantFix -and (Test-SdFixAllowed $script:Evicted)) {
        Invoke-SdPlace
        $after = Get-SdBoostState
        if (($after -eq 'ok') -and ($script:PlacedCount -gt 0)) { $script:Fixed = $true }
        $state = $after
    }

    Test-SdClaude
    Test-SdDesktop
    # 実測は置き場所の状態にかかわらず行う (SPEC 6 節 7: 先頭が壊れていても一覧に出ることがある・Mac の bash 版と同じ)
    Invoke-SdProbe
    # 置き場所は正しく見えるのに出ないとき: 中身が本体の正本と違えば置き直し、1 回だけ測り直す
    if ((Test-SdCode 'PROBE_NOT_VISIBLE') -and ($state -eq 'ok') -and $WantFix -and (-not $script:Fixed) -and (Test-SdFixAllowed $script:Evicted)) {
        if (Invoke-SdForcePlaceBoost) {
            $script:Fixed = $true
            $state = Get-SdBoostState
            Invoke-SdProbe
        }
    }

    if ($state -eq 'missing') { Add-SdCode 'SKILLS_MISSING' }
    else {
        Add-SdCode 'SKILLS_PLACED'
        if ($state -eq 'ok') { Add-SdCode 'FRONTMATTER_OK' } else { Add-SdCode 'FRONTMATTER_BAD' }
    }
    if ($script:Fixed) { Add-SdCode 'FIXED_REPLACED' }
    return (Get-SdOverall)
}

$script:ExitCode = 0
try {
    $script:Evicted = Test-SdEvicted
    if ($script:Evicted) { Add-SdNote 'evicted: no-fix-no-save-no-report' }
    $reportState = 'not-requested'
    $fromSaved = $false
    if ($Mode -eq 'report') {
        # 直前に保存した結果を送る。無いときだけ check (置き直しなし) を 1 回行ってから送る (Mac の bash 版と同じ)
        $overall = ''
        if ($script:Evicted) {
            $reportState = 'evicted'
        } else {
            $saved = Read-SdLast
            if ($saved) {
                $fromSaved = $true
                $overall = $saved
                # 登録と試用の状態だけは今の値にする (導入の最後には登録が済んでいることがあるため)
                foreach ($c in @('DEVICE_REGISTERED', 'DEVICE_NOT_REGISTERED', 'DEVICE_PENDING_APPROVAL', 'DEVICE_REVOKED', 'NOT_TRIAL', 'TRIAL_ACTIVE', 'TRIAL_ENDED', 'TRIAL_SKILL_NOT_INCLUDED')) { Remove-SdCode $c }
                Test-SdDevice
                Test-SdTrial
            } else {
                $overall = Invoke-SdFullCheck $false
                Save-SdLast $overall
            }
            $reportState = Send-SdReport (Get-SdReportBody $overall)
            # 送れたか・送らなかったかを端末の記録に残す (Mac の bash 版の REPORT 行と同じ考え方。送らなかった理由は上で記録済み)
            if ($reportState -ne 'pii-blocked') { Write-SdHistory ('REPORT ' + $reportState) }
        }
    } else {
        $overall = Invoke-SdFullCheck ($Mode -eq 'fix')
        # 退去済みの端末には何も書かない
        if (-not $script:Evicted) { Save-SdLast $overall }
    }
    $msgs = @()
    if ($overall) { $msgs = @(Get-SdMessages $overall) } else { $msgs = @($script:MsgCommonNote) }
    $result = [ordered]@{
        schema              = 1
        entry               = $Entry
        mode                = $Mode
        overall             = $overall
        codes               = @($script:Codes | ForEach-Object { [string]$_ })
        fixed               = [bool]$script:Fixed
        placed              = [int]$script:PlacedCount
        failed              = @($script:FailedNames)
        messages            = $msgs
        engine_version      = $script:EngineVersion
        claude_code_version = $script:ClaudeVersion
        install_kind        = $script:InstallKind
        config_dir_override = [bool]$script:ConfigOverride
        probe               = $script:Probe
        report              = $reportState
        from_saved          = [bool]$fromSaved
        notes               = @($script:Notes | ForEach-Object { [string]$_ })
    }
    Write-SdResult $result
    # 終了コードは Mac の bash 版と同じ (report は送れたかどうかに関わらず 0)
    if ($Mode -ne 'report') {
        if ($overall -eq 'PLACED_UNVERIFIED') { $script:ExitCode = 1 }
        elseif ($overall -eq 'NOT_VISIBLE') { $script:ExitCode = 2 }
    }
} catch {
    # 診断そのものが落ちても、導入は止めない。何も確かめられなかったことだけを返す
    $err = [string]$_.Exception.Message
    $result = [ordered]@{
        schema   = 1
        entry    = $Entry
        mode     = $Mode
        overall  = ''
        codes    = @($script:Codes | ForEach-Object { [string]$_ })
        fixed    = [bool]$script:Fixed
        messages = @($script:MsgCommonNote)
        error    = $err
    }
    try { Write-SdResult $result } catch { }
    $script:ExitCode = 0
}
exit $script:ExitCode
