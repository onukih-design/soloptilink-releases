#!/usr/bin/env bash
# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# ============================================================
# v2056.14 — お客様の端末で動いていない会話終了時の採点フックを外す (2026-10-26 新設)
# ------------------------------------------------------------
# 【何が起きていたか (砂箱で実走して確かめた)】
#   v2031_omega_install.sh が会話の終わり (Stop) に soloptilink-omega-hook を登録するが、
#   採点の部品 (lib/quality-fortresses/*vigintifortress*.sh) は配布物の作成時に必ず取り除かれる。
#   そのためお客様の端末では毎回「未実施」を出すだけで、しかも Stop の標準出力は
#   お客様にもモデルにも届かない。会話が終わるたびに動かない処理を待たせていた (死配線)。
#   登録の側 (v2031) は 10/26 に「部品が 0 件なら登録しない」へ直した。本 migration は
#   既に登録されてしまった端末から、その登録だけを外す。
#
# 【守っていること】
#   ・採点の部品が 1 つでもある端末 (管理者端末・将来部品を配る版) では何もしない
#   ・管理者端末 (.admin_mode) では何もしない
#   ・外すのは command に soloptilink-omega-hook を含む登録だけ。他の登録・並びには触らない
#   ・settings.json が壊れている / 想定外の形なら 1 バイトも書き換えない。書く前に控えを取る
#   ・停止スイッチ: SOLOPTILINK_OMEGA_UNWIRE=off
# ============================================================
set -u
MIG_NAME="v2056.14_omega_dead_hook_unwire"
SL_DIR="${SOLOPTILINK_DIR:-${SOLOPTILINK_HOME:-$HOME/.soloptilink}}"
CLAUDE_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
SETTINGS_FILE="${CLAUDE_SETTINGS:-$CLAUDE_DIR/settings.json}"
BACKUP_DIR="$CLAUDE_DIR/.backups"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"

mig_log() { echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true; }

_ou_state() {
    OU_STATE_FILE="$STATE_FILE" OU_MIG_NAME="$MIG_NAME" OU_AT="$(date -u '+%Y-%m-%dT%H:%M:%SZ')" python3 -c '
import json, os
sf = os.environ["OU_STATE_FILE"]
try:
    d = json.load(open(sf, encoding="utf-8"))
except Exception:
    d = {}
if not isinstance(d, dict):
    d = {}
d[os.environ["OU_MIG_NAME"]] = {"applied_at": os.environ["OU_AT"]}
tmp = sf + ".tmp.%d" % os.getpid()
json.dump(d, open(tmp, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
os.replace(tmp, sf)
' 2>>"$LOG_FILE"
}

mig_apply() {
    mkdir -p "$SL_DIR" 2>/dev/null || true
    mig_log "START"
    case "$(printf '%s' "${SOLOPTILINK_OMEGA_UNWIRE:-on}" | tr 'A-Z' 'a-z')" in
        off|0|false|no|disabled) mig_log "KILL_SWITCH -> NOOP (retryable)"; return 0 ;;
    esac
    if [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; then
        mig_log "ALREADY_APPLIED -> NOOP"; return 0
    fi
    if [ -f "$SL_DIR/.admin_mode" ]; then mig_log "ADMIN -> NOOP"; _ou_state; return 0; fi
    if ls "$SL_DIR"/lib/quality-fortresses/*vigintifortress*.sh >/dev/null 2>&1; then
        mig_log "採点の部品があるため登録を残します -> NOOP"; _ou_state; return 0
    fi
    command -v python3 >/dev/null 2>&1 || { mig_log "PRECONDITION_FAILED python3 (retryable)"; return 0; }
    if [ ! -f "$SETTINGS_FILE" ] || ! grep -q "soloptilink-omega-hook" "$SETTINGS_FILE" 2>/dev/null; then
        mig_log "登録なし -> NOOP"; _ou_state; return 0
    fi
    mkdir -p "$BACKUP_DIR" 2>/dev/null || true
    local bk="$BACKUP_DIR/settings.json.pre-${MIG_NAME}-$(date +%Y%m%dT%H%M%S)"
    cp -p "$SETTINGS_FILE" "$bk" 2>/dev/null || { mig_log "BACKUP_FAILED (retryable)"; return 0; }
    local res
    res="$(OU_SETTINGS="$SETTINGS_FILE" python3 -c '
import json, os, sys
p = os.environ["OU_SETTINGS"]
try:
    d = json.load(open(p, encoding="utf-8"))
except Exception:
    print("ABORT_UNPARSABLE"); sys.exit(0)
if not isinstance(d, dict) or not isinstance(d.get("hooks"), dict):
    print("ABORT_SHAPE"); sys.exit(0)
removed = 0
for ev, arr in list(d["hooks"].items()):
    if not isinstance(arr, list):
        continue
    keep = []
    for m in arr:
        if isinstance(m, dict) and isinstance(m.get("hooks"), list):
            hs = [h for h in m["hooks"] if not (isinstance(h, dict) and "soloptilink-omega-hook" in str(h.get("command") or ""))]
            removed += len(m["hooks"]) - len(hs)
            if not hs and m["hooks"]:
                continue
            m["hooks"] = hs
        keep.append(m)
    d["hooks"][ev] = keep
tmp = p + ".tmp.%d" % os.getpid()
with open(tmp, "w", encoding="utf-8") as f:
    json.dump(d, f, indent=2, ensure_ascii=False); f.write("\n")
os.replace(tmp, p)
print("REMOVED %d" % removed)
' 2>>"$LOG_FILE")"
    if ! OU_SETTINGS="$SETTINGS_FILE" python3 -c 'import json,os; json.load(open(os.environ["OU_SETTINGS"],encoding="utf-8"))' >/dev/null 2>&1; then
        cp -p "$bk" "$SETTINGS_FILE" 2>/dev/null || true
        mig_log "POSTCHECK_FAILED -> 控えから戻しました"; return 0
    fi
    case "$res" in
        REMOVED*) mig_log "DONE ($res)"; _ou_state ;;
        *)        mig_log "SKIPPED ($res) -> 設定に触れず次回やり直します" ;;
    esac
    return 0
}

mig_selftest() {
    local self root pass=0 fail=0
    self="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
    root="/tmp/soloptilink-ou-selftest-$$"
    mkdir -p "$root" || return 1
    _t() { if [ "$2" = "$3" ]; then pass=$((pass+1)); echo "  PASS  $1"; else fail=$((fail+1)); echo "  FAIL  $1 (期待=$2 実際=$3)"; fi; }
    _mk() { mkdir -p "$root/$1/sl/lib" "$root/$1/claude"
        printf '{"hooks":{"Stop":[{"matcher":"*","hooks":[{"type":"command","command":"bash ~/.soloptilink/lib/soloptilink-omega-hook.sh"},{"type":"command","command":"bash ~/.soloptilink/lib/hooks/response-gate.sh"}]}],"PreToolUse":[{"matcher":"Bash","hooks":[{"type":"command","command":"x"}]}]},"model":"m"}\n' > "$root/$1/claude/settings.json"; }
    _run() { local n="$1"; shift; env -u CLAUDE_SETTINGS "$@" SOLOPTILINK_DIR="$root/$n/sl" CLAUDE_CONFIG_DIR="$root/$n/claude" bash "$self" >/dev/null 2>&1; }
    _has() { grep -c "$2" "$root/$1/claude/settings.json" 2>/dev/null | tr -d ' '; }
    _mk o1; _run o1
    _t "O1 部品の無い端末で採点フックだけが外れる" "0" "$(_has o1 soloptilink-omega-hook)"
    _t "O1 同じ区切りの他のフックと他の設定は残る" "1/1/1" "$(_has o1 response-gate.sh)/$(_has o1 '"command": "x"')/$(_has o1 '"model": "m"')"
    _mk o2; mkdir -p "$root/o2/sl/lib/quality-fortresses"; : > "$root/o2/sl/lib/quality-fortresses/a-vigintifortress-b.sh"; _run o2
    _t "O2 対照: 部品がある端末では外さない" "1" "$(_has o2 soloptilink-omega-hook)"
    _mk o3; : > "$root/o3/sl/.admin_mode"; _run o3
    _t "O3 管理者端末では外さない" "1" "$(_has o3 soloptilink-omega-hook)"
    _mk o4; _run o4 SOLOPTILINK_OMEGA_UNWIRE=off
    _t "O4 停止スイッチで外さない" "1" "$(_has o4 soloptilink-omega-hook)"
    mkdir -p "$root/o5/sl/lib" "$root/o5/claude"; printf '{"hooks": {"Stop": [ soloptilink-omega-hook' > "$root/o5/claude/settings.json"
    local b5; b5="$(python3 -c 'import hashlib,sys; print(hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest())' "$root/o5/claude/settings.json")"; _run o5
    _t "O5 壊れた設定は書き換えない" "$b5" "$(python3 -c 'import hashlib,sys; print(hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest())' "$root/o5/claude/settings.json")"
    python3 -c "import shutil; shutil.rmtree('/tmp/soloptilink-ou-selftest-$$', ignore_errors=True)"
    echo "  ---- 合計 $((pass+fail)) 件: PASS ${pass} / FAIL ${fail}"
    [ "$fail" -eq 0 ]
}

case "${1:-apply}" in
    selftest) echo "採点フックの死配線の取り外し (v2056.14) 自己検査 (砂箱・両側)"; mig_selftest; exit $? ;;
    apply|"") mig_apply; exit 0 ;;
    *) echo "使い方: $0 [apply|selftest]" >&2; exit 2 ;;
esac
