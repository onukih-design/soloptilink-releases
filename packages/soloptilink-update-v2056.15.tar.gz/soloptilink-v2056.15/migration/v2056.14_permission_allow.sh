#!/usr/bin/env bash
# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# ============================================================
# v2056.14 — 当社の台本だけを、確認画面なしで動かせるようにする (2026-10-26 新設)
# ------------------------------------------------------------
# 【何が起きていたか (公式の説明と実物で確かめた)】
#   スキルの許可指定 (allowed-tools) は、スキルを呼んだその手番にしか効かない
#   (出典: https://code.claude.com/docs/en/skills)。お客様が 2 通目を送った時点で消え、
#   以後は本体の台本 (bash ~/.soloptilink/...) を動かすたびに確認画面が出ていた。
#   導入の台本も更新の台本も、お客様の許可設定 (permissions.allow) に何も足していなかった。
#
# 【何をするか】
#   ~/.claude/settings.json の permissions.allow に、当社の台本の置き場だけを狭く許す
#   規則を足す (書式の出典: https://code.claude.com/docs/en/permissions)。
#     ・許すのは「当社の置き場の台本を bash / python3 / node で動かす」ことと、
#       当社の置き場と当社のスキルの文書を読むことだけ。削除・外への送信・
#       お客様の他のファイルへの書き込みは一切含めない。
#     ・置き場の外へ抜ける書き方 (~/.soloptilink/../…) は ask に入れ、従来どおり確認する
#       (ask は allow より先に評価される)。
#   お客様が自分で入れた規則には一切触らない (足すだけ・消さない・並びも変えない)。
#
# 【守っていること】
#   ・settings.json が壊れている / 想定外の形のときは 1 バイトも書き換えない
#   ・書く前に控えを取り、書いた後に JSON として読めなければ控えから戻す
#   ・全部の規則が入ったことを数えてから「適用済み」と記録する (足りなければ次回やり直す)
#   ・停止スイッチ: SOLOPTILINK_PERMISSION_ALLOW=off (何も書かない・次回やり直せる)
#
# 使い方:
#   bash migration/v2056.14_permission_allow.sh            適用する (何度実行しても同じ結果)
#   bash migration/v2056.14_permission_allow.sh selftest   砂箱で両側を確かめる
# ============================================================
set -u
MIG_NAME="v2056.14_permission_allow"
SL_DIR="${SOLOPTILINK_DIR:-${SOLOPTILINK_HOME:-$HOME/.soloptilink}}"
CLAUDE_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
SETTINGS_FILE="${CLAUDE_SETTINGS:-$CLAUDE_DIR/settings.json}"
BACKUP_DIR="$CLAUDE_DIR/.backups"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"

mig_log() {
    echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}

# 規則の正典 (ここが唯一の出典)。足す側と数える側の両方がこの関数を読む。
_pa_rules_py() {
    cat <<'PYEOF'
PREFIXES = [
    "bash ~/",
    'bash "$HOME/',
    "bash $HOME/",
    "python3 ~/",
    "python3 -I ~/",
    "node ~/",
]
ALLOW = [f"Bash({p}.soloptilink/*)" for p in PREFIXES] + [
    "Bash(~/.soloptilink/soloptilink *)",
    "Read(~/.soloptilink/**)",
    "Read(~/.claude/skills/soloptilink*/**)",
    "Read(~/.claude/skills/suishin-drawing-engine/**)",
    "Read(~/.claude/commands/soloptilink*)",
]
# 置き場の外へ抜ける書き方は、従来どおり確認する
ASK = []
for p in PREFIXES:
    ASK.append(f"Bash({p}.soloptilink/../*)")
    ASK.append(f"Bash({p}.soloptilink/*/../*)")
PYEOF
}

_pa_write_py() {
    {
        _pa_rules_py
        cat <<'PYEOF'
import json, os, sys
settings = os.environ["PA_SETTINGS"]
if os.path.exists(settings):
    try:
        with open(settings, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        print("ABORT_UNPARSABLE"); sys.exit(0)
    if not isinstance(data, dict):
        print("ABORT_NOT_DICT"); sys.exit(0)
else:
    data = {}
perms = data.setdefault("permissions", {})
if not isinstance(perms, dict):
    print("ABORT_PERMISSIONS_NOT_DICT"); sys.exit(0)
added = 0
for key, rules in (("allow", ALLOW), ("ask", ASK)):
    arr = perms.setdefault(key, [])
    if not isinstance(arr, list):
        print("ABORT_%s_NOT_LIST" % key.upper()); sys.exit(0)
    for r in rules:
        if r not in arr:
            arr.append(r); added += 1
os.makedirs(os.path.dirname(settings) or ".", exist_ok=True)
tmp = settings + ".tmp.%d" % os.getpid()
with open(tmp, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
    f.write("\n")
os.replace(tmp, settings)
print("WIRED added=%d" % added)
PYEOF
    } > "$1"
}

_pa_count_py() {
    {
        _pa_rules_py
        cat <<'PYEOF'
import json, os
try:
    d = json.load(open(os.environ["PA_SETTINGS"], encoding="utf-8"))
    p = d.get("permissions") or {}
    a = p.get("allow") or []; k = p.get("ask") or []
    n = sum(1 for r in ALLOW if r in a) + sum(1 for r in ASK if r in k)
    print("%d/%d" % (n, len(ALLOW) + len(ASK)))
except Exception:
    print("-1/%d" % (len(ALLOW) + len(ASK)))
PYEOF
    } > "$1"
}

mig_apply() {
    mkdir -p "$SL_DIR" "$CLAUDE_DIR" "$BACKUP_DIR" 2>/dev/null || true
    mig_log "START"
    case "$(printf '%s' "${SOLOPTILINK_PERMISSION_ALLOW:-on}" | tr 'A-Z' 'a-z')" in
        off|0|false|no|disabled)
            mig_log "KILL_SWITCH SOLOPTILINK_PERMISSION_ALLOW=off -> NOOP (retryable)"
            return 0 ;;
    esac
    if [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; then
        mig_log "ALREADY_APPLIED -> NOOP"
        return 0
    fi
    if ! command -v python3 >/dev/null 2>&1; then
        mig_log "PRECONDITION_FAILED python3 not found (retryable)"
        return 0
    fi
    local work="$SL_DIR/.migration-work/${MIG_NAME}"
    mkdir -p "$work" 2>/dev/null || { mig_log "PRECONDITION_FAILED work dir (retryable)"; return 0; }
    local ts; ts="$(date +%Y%m%dT%H%M%S)"
    local bk="$BACKUP_DIR/settings.json.pre-${MIG_NAME}-${ts}"
    if [ -f "$SETTINGS_FILE" ]; then
        cp -p "$SETTINGS_FILE" "$bk" 2>/dev/null || true
        mig_log "BACKUP $bk"
    fi
    _pa_write_py "$work/wire.py"
    local res
    res="$(PA_SETTINGS="$SETTINGS_FILE" python3 "$work/wire.py" 2>>"$LOG_FILE")"
    if [ -f "$SETTINGS_FILE" ] && ! PA_SETTINGS="$SETTINGS_FILE" python3 -c 'import json,os; json.load(open(os.environ["PA_SETTINGS"],encoding="utf-8"))' >/dev/null 2>&1; then
        mig_log "POSTCHECK_FAILED settings.json が JSON として読めない -> 控えから戻します"
        [ -f "$bk" ] && cp -p "$bk" "$SETTINGS_FILE" 2>/dev/null || true
        return 0
    fi
    case "$res" in
        WIRED*) mig_log "WIRE_SUCCESS ($res)" ;;
        *)      mig_log "WIRE_SKIPPED ($res) -> お客様の設定に触れず、state を書かずに次回やり直します"
                return 0 ;;
    esac
    _pa_count_py "$work/count.py"
    local cnt; cnt="$(PA_SETTINGS="$SETTINGS_FILE" python3 "$work/count.py" 2>/dev/null)"
    case "$cnt" in
        */*) [ "${cnt%%/*}" = "${cnt##*/}" ] || { mig_log "VERIFY_INCOMPLETE ${cnt} -> state を書かず再試行可能にします"; return 0; } ;;
        *)   mig_log "VERIFY_FAILED (${cnt}) -> 再試行可能"; return 0 ;;
    esac
    local at; at="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    PA_STATE_FILE="$STATE_FILE" PA_MIG_NAME="$MIG_NAME" PA_AT="$at" python3 -c '
import json, os
sf = os.environ["PA_STATE_FILE"]
try:
    data = json.load(open(sf, encoding="utf-8"))
except Exception:
    data = {}
if not isinstance(data, dict):
    data = {}
data[os.environ["PA_MIG_NAME"]] = {"applied_at": os.environ["PA_AT"]}
tmp = sf + ".tmp.%d" % os.getpid()
with open(tmp, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
os.replace(tmp, sf)
' 2>>"$LOG_FILE"
    mig_log "DONE applied_at=${at} rules=${cnt}"
    return 0
}

# ------------------------------------------------------------
# selftest — 砂箱の仮想 HOME で実走する (宣言を読むだけにしない)
#   P1 設定ファイルが無い端末 → 規則がすべて入り JSON として読める
#   P2 二度実行しても規則が増えない (冪等)
#   P3 お客様が先に入れた規則と他の設定は 1 つも消えず、並びも変わらない
#   P4 settings.json が壊れているとき、1 バイトも書き換えない
#   P5 permissions が想定外の形 (文字列) のとき、1 バイトも書き換えない
#   P6 停止スイッチ off で何も書かない
#   P7 対照: 規則を 1 つ欠いた状態は「適用済み」と記録されない
# ------------------------------------------------------------
mig_selftest() {
    local self root pass=0 fail=0
    self="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
    root="/tmp/soloptilink-pa-selftest-$$"
    mkdir -p "$root" || return 1
    _t() { if [ "$2" = "$3" ]; then pass=$((pass+1)); echo "  PASS  $1"; else fail=$((fail+1)); echo "  FAIL  $1 (期待=$2 実際=$3)"; fi; }
    _run() { local n="$1"; shift; mkdir -p "$root/$n/sl" "$root/$n/claude"
        env -u CLAUDE_SETTINGS "$@" SOLOPTILINK_DIR="$root/$n/sl" SOLOPTILINK_HOME="$root/$n/sl" CLAUDE_CONFIG_DIR="$root/$n/claude" bash "$self" >/dev/null 2>&1; }
    _cnt() { _pa_count_py "$root/count.py"; PA_SETTINGS="$1" python3 "$root/count.py" 2>/dev/null; }
    _sum() { python3 -c 'import hashlib,sys; print(hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest())' "$1" 2>/dev/null; }   # 照合値の道具は端末により無いので python3 で測る
    local full; _pa_count_py "$root/count.py"; full="$(PA_SETTINGS=/nonexistent python3 "$root/count.py" | sed 's#^-1/##')"

    _run p1; _t "P1 設定の無い端末に全規則が入る" "${full}/${full}" "$(_cnt "$root/p1/claude/settings.json")"
    _t "P1 適用済みと記録される" "yes" "$(grep -q "\"${MIG_NAME}\"" "$root/p1/sl/.migration-state.json" 2>/dev/null && echo yes || echo no)"

    rm -f "$root/p1/sl/.migration-state.json"; _run p1
    _t "P2 二度目でも規則が増えない" "$(( full ))" "$(PA_SETTINGS="$root/p1/claude/settings.json" python3 -c 'import json,os; p=json.load(open(os.environ["PA_SETTINGS"]))["permissions"]; print(len(p["allow"])+len(p["ask"]))')"

    mkdir -p "$root/p3/claude"
    printf '{"model":"x","permissions":{"allow":["Bash(npm test)"],"deny":["Read(./.env)"]},"hooks":{"Stop":[]}}\n' > "$root/p3/claude/settings.json"
    _run p3
    _t "P3 お客様の規則が先頭のまま残る" "Bash(npm test)" "$(PA_SETTINGS="$root/p3/claude/settings.json" python3 -c 'import json,os; print(json.load(open(os.environ["PA_SETTINGS"]))["permissions"]["allow"][0])')"
    _t "P3 拒否の規則と他の設定が残る" "Read(./.env)|x|yes" "$(PA_SETTINGS="$root/p3/claude/settings.json" python3 -c 'import json,os; d=json.load(open(os.environ["PA_SETTINGS"])); print(d["permissions"]["deny"][0]+"|"+d["model"]+"|"+("yes" if "Stop" in d["hooks"] else "no"))')"

    mkdir -p "$root/p4/claude"; printf '{"permissions": {"allow": [' > "$root/p4/claude/settings.json"
    local b4; b4="$(_sum "$root/p4/claude/settings.json")"; _run p4
    _t "P4 壊れた設定は書き換えない" "$b4" "$(_sum "$root/p4/claude/settings.json")"
    _t "P4 適用済みと記録しない" "no" "$(grep -q "\"${MIG_NAME}\"" "$root/p4/sl/.migration-state.json" 2>/dev/null && echo yes || echo no)"

    mkdir -p "$root/p5/claude"; printf '{"permissions":"strict"}\n' > "$root/p5/claude/settings.json"
    local b5; b5="$(_sum "$root/p5/claude/settings.json")"; _run p5
    _t "P5 想定外の形の設定は書き換えない" "$b5" "$(_sum "$root/p5/claude/settings.json")"

    _run p6 SOLOPTILINK_PERMISSION_ALLOW=off
    _t "P6 停止スイッチで何も書かない" "no" "$([ -f "$root/p6/claude/settings.json" ] && echo yes || echo no)"

    mkdir -p "$root/p7/claude"
    printf '{"permissions":{"allow":"Bash(x)"}}\n' > "$root/p7/claude/settings.json"; _run p7
    _t "P7 対照: 入れられなかった端末は適用済みにならない" "no" "$(grep -q "\"${MIG_NAME}\"" "$root/p7/sl/.migration-state.json" 2>/dev/null && echo yes || echo no)"

    python3 -c "import shutil; shutil.rmtree('/tmp/soloptilink-pa-selftest-$$', ignore_errors=True)"
    echo "  ---- 合計 $((pass+fail)) 件: PASS ${pass} / FAIL ${fail}"
    [ "$fail" -eq 0 ]
}

case "${1:-apply}" in
    selftest) echo "当社の台本の許可 (v2056.14) 自己検査 (砂箱・両側)"; mig_selftest; exit $? ;;
    apply|"") mig_apply; exit 0 ;;
    *) echo "使い方: $0 [apply|selftest]" >&2; exit 2 ;;
esac
