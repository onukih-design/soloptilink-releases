# 要件SoT台帳・ヒアリング取込・図面読取・意図カルテ・UXコンセプト の全手順

> 2026-10-17 (V-09): 本書の節は `SKILL.md` 本文から移したもので、文言は本文にあったときのままです。本文には要点と、本書を読む引き金を残しています。

## Step 0.65〜0.67 の各 Step の要約 (SKILL.md 本文から移した原文)

- **Step 0.65 ヒアリング済み要件の自動取り込み**: `/soloptilink-hearing` が保存したセッションを自動検出し、確定情報 (業種・規模・必須モジュール・該当規制・業務フロー) を全ロールへ注入する。**曖昧点は推測で埋めず**「構築前確認質問」として顧客提示する。ヒアリング確定業種は再推論より優先 (再ヒアリング禁止)。
- **Step 0.66 図面資産の自動読取**: 案件フォルダに図面が実在する場合のみ発火し、読み取れた事実 (工事名・図面名・尺度・室面積・部品個数・記載面積との不一致) を要件化する。**数量は実測値なので手入力させず初期データに流し込む。単価・歩掛りは図面から決まらないため利用者入力とし、こちらで数値を作らない。**
- **Step 0.67 意図カルテ**: 依頼文とヒアリングの目的から「誰の / どんな状態を / どう変えたいか / なぜ / 何を大事にするか」を組み立て、**業種知識より先に**全ロールへ配る。抽出できなくても**質問せず**、業種の標準的な思想を仮置きして「こう理解しました」と 1 行提示して進む。思想が決めるのは画面構成・指標・通知先・語りかけ・差別化機能。**法令・算定式・帳票の法定記載事項・認証・権限分離・監査ログ・暗号化は思想では変えない**(緩める要望は採用しない)。


> この文書は `/soloptilink-boost` 本文から分離された詳細手順です。本文の該当 Step から指示された時に読みます。

## Step 0.54: 計画書類の取り込みと要件SoT台帳の発行 (PFP-FOLLOWTHROUGH / v2056.1 NEW・**分母を先に固定する**)

owner 実測 (2026-08-21):「ZIP を入れたときに長い指示を書かないと、最後まで完璧に開発してくれない。実際に全く終わってもないのに『終わりました』という形で勝手に終わらせられるケースが起きている」。

**真因**: その案件で満たすべき要件が**何件あるのか**という分母がどこにも無かった。分母が無ければ「主要機能は完成」で終わらせられる。長い指示文はその分母を人手で与えていただけであり、本来は本体が機械で確定させるべきものだった。**この Step がその肩代わりをする。**

**実行タイミング**: Step 1.1 でプロジェクトディレクトリを作った直後・**実装に着手する前**。Step 0.65 (ヒアリング取り込み) より前。

```bash
RL=~/.soloptilink/lib/requirement-ledger/requirement-ledger.sh
# ① 計画書類 (ZIP / フォルダ / 個別ファイル) を機械で全件読み、要件の総数を確定する
#    md / txt / docx / xlsx / pptx / csv は追加部品なしで読める。PDF は読めた/読めないを正直に記録する。
bash "$RL" intake "$PROJECT_DIR" "<計画書類のあるフォルダ または ZIP のフルパス>"
# ② 全ロールへ配る注入ブロックを取り、$TARGET_TASK へ追記する (他の Step と同じ流儀)
RLB="$(bash "$RL" context "$PROJECT_DIR" 2>/dev/null)"
if [ -n "$RLB" ]; then TARGET_TASK="${TARGET_TASK}

${RLB}"; fi
```

**自動判定で済ませたいとき** (計画書らしい書類が在れば取り込み、無ければ何もしない):

```bash
bash "$RL" auto "$PROJECT_DIR" "<探索するフォルダ>"
```

**発行されるもの**:
- `$PROJECT_DIR/要件SoT台帳.md` — 1要件1行。列は REQ-ID / 出典 / 要求の要旨 / 種別 / 完了条件 / 状態 / 証跡 / 前提
- `$PROJECT_DIR/未達・未検算一覧.md` — 検査のたびに更新される
- 総数 N が確定し、**以後この N が完成判定の唯一の分母**になる

**台帳は機械が全行を先に作る。** 要旨・出典・種別は原本から自動で埋まっているので、各波で「完了条件 / 状態 / 証跡 / 前提」を精錬していく。**行を足す必要も、減らす必要も無い。** 原本にお客様の要求番号 (REQ-2-1 / FR-01 等) が書かれている場合はそのまま温存される。

**状態は次の 5 語だけを使う** (他の語を書くと完成ゲートが不合格にする):

| 状態 | 意味 | 書くときの条件 |
|---|---|---|
| 未着手 | まだ手を付けていない | — |
| 実装済(未検証) | 作ったが実際に動かしていない | — |
| 実物到達 | 生成物の実経路 (画面または HTTP) で動くことを確かめた | **証跡欄に「何をどう動かしたか」が必要** |
| 未検算 | 測れなかった・データが足りない | **証跡欄に理由が必要**（正直に立てるのが正しい） |
| 対象外 | 今回の範囲外と判断した | **証跡欄に理由が必要** |

**波ごとの規律**:
1. 1 波終わるごとに該当行の状態と証跡を更新する
2. `bash "$RL" summary "$PROJECT_DIR"` が返す一行 (「台帳 n/N 件が実物到達、未検算 c 件、対象外 d 件、残り e 件」) を**そのまま顧客可視の進捗報告に使ってよい** (内部用語なし)
3. 「未着手」「実装済(未検証)」が 1 行でも残っている間は完成ではない。実装波 → 実経路検証 → 敵対的検証波 を繰り返す

**やってはいけないこと** (いずれも完成ゲートが検出して物理ブロックする):
- 台帳の行を削って「未達ゼロ」にする — 削られた行は必ず未達として出る
- 証跡なしで「実物到達」と書く
- 理由なしで「未検算」「対象外」にする
- 「ほぼ完了」「対応済み」等、5 語以外の状態語を書く

**測れなかったものは、黙って外さず「未検算」として理由つきで残す。** 正直に出すと赤くなる構造にすると、項目ごと消して緑にする動きが出るため、**理由つきの未検算は正当な完成状態として通る** (2026-08-19 構造計算監査の教訓)。未検算が 1 件でもあるときは、その一覧を完了報告の**先頭**に出す。

**読めなかった書類は必ず開示される**。台帳の冒頭に「読み取れていない書類」として出るので、完成報告でもお客様に伝える (分母に含まれていないことを隠さない)。PDF はこの端末に読取部品が無いと読めないため、その場合は同じ内容の Word / テキスト版をご用意いただくよう日本語で案内する。

**計画書が読めなかった / 要件を 1 件も起こせなかったとき**: 台帳は**作られない** (要件 0 件の台帳は「全 0 件が到達済み」として素通りするため、作らせない)。読めなかった書類が名指しで出るので、**同じ内容の Word / テキスト版をご用意いただくよう日本語で案内する**。それでも台帳を使わないと判断した場合だけ、理由を添えて対象外にする:

```bash
bash "$RL" waive "$PROJECT_DIR" "<なぜ台帳を使わないのか>"
```

理由なしでは対象外にできない (黙って印を消す経路は無い)。対象外にした事実と理由は記録として残る。

**再開時** (中断・翌日・コンテキスト切れ): `intake` を撃ち直さない (既存の台帳が温存され、前回の状態は踏み潰されない)。`bash "$RL" status "$PROJECT_DIR"` で残りを確認し、「実物到達」以外の行だけを対象に続きを実行する。台帳がそのまま引き継ぎ書になる。

**顧客可視出力**: 「計画書類から要件を N 件起こしました。以後この N 件を分母として進捗をご報告します」と**日本語一文**で伝える。コマンド・JSON・内部用語は貼らない。

**kill-switch**: `SOLOPTILINK_REQUIREMENT_LEDGER=off` (台帳を使わない従来挙動)。健全性: `bash "$RL" selftest` (両側弁別 16 軸)。

### 計画書類を渡された案件の納品物 (出力先にそろえる)

| # | 納品物 | 誰が作るか |
|---|---|---|
| 1 | 動くシステム一式 (起動手順つき README) | 実装波 |
| 2 | `要件SoT台帳.md` — 全行の状態と証跡が埋まったもの | 台帳エンジンが発行・各波で精錬 |
| 3 | `未達・未検算一覧.md` — 1 件も無ければ「なし」と明記 | 検査のたびに自動更新 |
| 4 | `検証記録.md` — 何をどう動かして確かめたかを日本語で | 検証波 |
| 5 | `セキュリティ診断報告書.html` / `品質証明書.html` | 完成ゲート |
| 6 | 運用手順書・README (日本語) | 仕上げ波 |

**引き継ぎの形**: `要件SoT台帳.md` がそのまま引き継ぎ書になる。中断・翌日・別セッションからでも「続きをやって」「完成させて」「リリースして」の一言で再開できる状態を、各波の終わりに必ず保つ (状態と証跡を書き切ってから止まる)。

### 小さなご依頼をブーストで受けたときの振る舞い

ブーストは常に最大編成 (Step 0.515) なので、ボタン 1 つの修正でも全ロールが編成される。この回は**担当外のロールが「担当外」と正直に申告してよい許可**が自動で配られる (推測で所見を書かせない)。編成数は減らさず、質だけを守る形。通常のフル構築では従来どおり、業種違いのロールにだけ許可が配られる。

---

## Step 0.65: ヒアリング済み要件の自動取り込み（Hearing → BOOST 連携 / hearing-link）

`/soloptilink-hearing`(要件ヒアリングエンジン)が Step 3 で保存した `.soloptilink-hearing-session.json`(RFP-DNA 互換)を **`$PROJECT_DIR` で自動検出**し、ヒアリング済みの確定情報(業種・事業規模・必須モジュール・該当規制・業務フロー)を全105ロールへ自動注入する。**曖昧点(ambiguities)は推測で埋めず、「構築前確認質問」として顧客提示ラインに変換して注入**(hearing 側の捏造禁止規約を継承)。研修A認定オペレーターの動線「ヒアリング→構築」の口頭転記断絶(Step 0.7 が再ヒアリングする問題)を根絶する。**hearing 本体・hearing-engine.sh は無編集参照**・連携専用フォルダ `hearing-link/` に自己完結。

**実行タイミング**: プロジェクトディレクトリを解決した直後(Step 1.1 の後)・Step 0.7/0.8 の前。`--workspace` に `$PROJECT_DIR` を渡す。

```bash
node ~/.claude/skills/soloptilink-boost/hearing-link/hearing-bridge.mjs \
  --workspace "$PROJECT_DIR"   # 出力は1行JSON
```

**業種→DBL 再解決は書かない(重要)**: bridge は セッションJSON 内の `dbl` フィールド(detected/low_confidence/unregistered 三値相当)と `hearing.industry` をそのまま読取専用消費する。DBL の正規エンジンは `~/.soloptilink/lib/hearing-engine.sh`(CLI 契約: `sheet "<業種フレーズ>"` / `digest "<dbl名>"` — 変更禁止)が単独 SoT。CLI 契約の流用改変・独自再実装は禁止(V9 で静的検査済み)。

**結果の適用 (has_data=true のときのみ)**:
- `injection_lines_for_agents`(確定業種・事業規模・必須モジュール・該当規制・業務フロー・実装前確認ガード)の各行を **`$TARGET_TASK` に追記**する。Step 2.A の `plan` が全105ロールへ自動注入する(orchestrator 無編集)。
- **これらはハード制約**として実装する: ヒアリング確定業種は Step 0.7 事業推論・Step 0.8 DBL Auto-Detect の再推論より優先(再ヒアリング禁止・研修A動線の口頭転記断絶を根絶)。ヒアリング確定モジュール一覧は構築スコープの下限で、汎用CRUD止まりへの後退・機能削減を禁ずる。曖昧点は回答が得られるまで該当機能を仮実装しない。
- `pre_build_confirmation_questions`(曖昧点を `[要確認] <元文言> — この点はどう扱いますか?` 形式に**変換**したもの・元文字列を破棄せず温存)は顧客に **確認質問として日本語で提示**する。**推測・確定値での穴埋めは絶対にしない(捏造禁止)**。
- `purpose`(ヒアリングで聞き取った**システム化の目的**= `rfp_dna.goal`)は、注入行の**先頭**に置かれる。この目的は Step 0.67 意図カルテの入力になり、画面構成・指標・通知先・差別化機能を導く最上位の拠り所になる。**業種より先に置く**(思想が上位・業種辞書は土台)。ただし法令要件・算定式・帳票の法定記載事項・認証/権限分離/監査ログ/暗号化の最低線は目的では変えない(思想不変域)。
- 目的を取り込めなかった場合(`rfp_dna` はあるが `goal` が無い・型違い・空・注入検知)は `silent_drop_warnings` に**必ず**理由が出る。**無警告で目的が消えることはない**(T-I0-A で根治)。
- `inference_block_markdown` は `$PROJECT_DIR/agent-evidence/hearing-recall.md` に保存され設計入力になる。

**三状態(絶対)**:
- ① セッションJSON あり + スキーマ健全 → 注入到達(`has_data=true` / `session_state=present_valid`)。
- ② セッションJSON なし → 完全 no-op(`has_data=false` / `session_state=absent`)。**hearing なし顧客への過剰注入は禁止**。
- ③ セッションJSON あり + 破損/スキーマNG → 安全スキップ(`has_data=false` / `session_state=corrupt_or_schema_mismatch`)。**推測補完せず素通り**。

**engagement-ledger の扱い(寛容設計継承)**: bridge は engagement-ledger を**読取のみ**(配置有無を JSON に記録するだけ)。ledger 更新は `/soloptilink-hearing` 側で完結する仕様。未配置環境では JSON にその旨を出して素通り。

**最優先指令の遵守**: セッションJSON なし・破損・失敗はすべて **no-op で素通り**(bridge は常に exit 0)。no-op のときは顧客文に何も出さない。has_data=true のときだけ「ヒアリング済みの業種・要件を反映して構築します(曖昧点は実装前に確認します)」と**日本語一文**で伝える。内部用語・JSON・コマンドは出さない。

**kill-switch**: `ENABLE_HEARING_LINK=off`(`false`/`0` も可)で完全 no-op(旧挙動=素通り・障害時の安全弁)。既定は on。

**保守(管理者)**: hearing-entry.ts を更新したら `bash ~/.claude/skills/soloptilink-boost/hearing-link/build-bundle.sh` でバンドル再生成。健全性は `node ~/.claude/skills/soloptilink-boost/hearing-link/verify-hearing-bridge.mjs`(born-passing 40軸: 三状態+欠陥検知+kill-switch+陳腐化+独自DBL再解決の禁止+目的貫通の両側 V38-V40)。詳細は `hearing-link/README.md`。同型機構の先行例は `executive-link/`(Step 0.55)・`tenant-dna-link/`(Step 0.95)・`japan-link/`(Step 0.88)。

---

## Step 0.66: 図面資産の自動読取と要件化（Drawing → BOOST 連携 / drawing-link）

案件フォルダに**図面ファイルが実在する**場合、その図面を機械的に読み取り、読み取れた事実
(図面表題欄の工事名・図面名・図番・尺度／室ごとの面積・周長／部品個数／図面記載面積と算出面積の
不一致)と、図面が実在する案件で業務システムに必要な機能要件を全ロールへ自動注入する。
「図面を渡したのに図面管理機能が入っていない」「図面の数量を手入力し直している」を根絶する。

> **図面が会話の途中で渡されたとき・図面から図面を描き起こすとき**
> - この Step は開始時に案件フォルダにある図面しか拾わない。**会話の途中で図面が渡された場合も、図面として扱う**
>   （読むのは図面作成モードの手順。線の太さで壁を決めず、室名は元図面に書かれた位置で決める）。
> - **受け取った図面から天井伏図・現況図などを描き起こしたら、完成と告げる前に必ず元図面との重ね合わせ検査
>   （`~/.soloptilink/lib/drawing-verify/drawing-verify.sh verify`）に合格させる。** 会話を終える時点で見張り
>   （`lib/hooks/drawing-verify-guard.sh`）が照合の記録を確かめ、無ければ差し戻す。
> - **面積の合計が契約面積と合ったことを、形や部屋の名前が正しい証拠にしない。** 低い間仕切りで区切られた部屋の一角を、
>   面積が合うように別の部屋の名前で呼んでしまう取り違えが起こりうるため、形と部屋の名前は必ず元図面で確かめる。

**活性化条件は業種辞書ではなく「図面ファイルの実在」**。図面が置かれている事実が最も強い
シグナルであり、業種が未検出・未登録の顧客でも拾えるため。図面が無ければ完全な no-op。

**実行タイミング**: Step 0.65 の後・Step 0.7 事業推論の前。`$PROJECT_DIR` を渡す。

```bash
mkdir -p "$PROJECT_DIR/.soloptilink"; printf '%s' "$TARGET_TASK" > "$PROJECT_DIR/.soloptilink/task-text.txt"
_dl_blk="$(bash ~/.soloptilink/lib/drawing-link/drawing-link.sh digest "$PROJECT_DIR" "${SOLOPTILINK_DETECTED_DBL:-}" "$PROJECT_DIR/.soloptilink/task-text.txt" 2>/dev/null || true)"
if [ -n "$_dl_blk" ]; then TARGET_TASK="${TARGET_TASK}

${_dl_blk}"; fi
bash ~/.soloptilink/lib/drawing-link/drawing-link.sh report "$PROJECT_DIR" >/dev/null 2>&1 || true
```

**結果の適用 (図面が実在するときのみ)**:
- digest の各行を **`$TARGET_TASK` に追記**する。Step 2.A の `plan` が全ロールへ波及させる (orchestrator 無編集)。
- 注入された機能要件は**この案件の実装スコープの下限**として扱う (図面台帳・版数管理・図面と工事の紐付け・数量拾い結果の保持・記載面積との不一致アラート・読取レポート閲覧画面)。汎用CRUD止まりへの後退を禁ずる。
- 読み取れた**数量は実測値**なので、生成物では手入力させず初期データとして流し込む。**単価・歩掛りは図面から決まらないため利用者入力**とし、こちらで数値を作らない。
- 図面記載面積と算出面積の不一致が報告された場合、生成物にアラート機能を実装し、完成報告でもお客様に伝える (見積確定前の確認を促す)。
- 読取結果は `$PROJECT_DIR/agent-evidence/drawing-read.md` に保存され設計入力になる。

**そのまま読めない形式の扱い**: JWW/JWC・P21 は「CAD 側で DXF へ書き出せば読める」と案内を出す
(黙って落とさない)。スキャン図面は時間と費用が大きいため**自動実行せず**、必要である旨を提示に留める。
読取部品が未導入の環境では、不足部品と導入コマンド 1 行を日本語で案内し、要件には何も注入しない。

**最優先指令の遵守**: 図面なし・読取失敗・部品未導入はすべて **no-op で素通り** (ブリッジは常に exit 0)。
no-op のときは顧客文に何も出さない。図面を読めたときだけ「お預かりした図面 N 件を読み取り、
図面名・尺度・室面積を設計に反映します」と**日本語一文**で伝える。コマンド・内部用語は出さない。

**kill-switch**: `ENABLE_DRAWING_LINK=off` で完全 no-op。上限は `DRAWING_LINK_MAX_FILES` (既定 50 件) ・ `DRAWING_LINK_SCAN_DEPTH` (既定 4 階層) と
`DRAWING_LINK_SOFT_CAP` (既定 4000 字)。

**保守(管理者)**: 健全性は `bash ~/.soloptilink/lib/drawing-link/drawing-link.sh selftest` (11軸: 図面なし no-op /
検出 / 事実転記 / 不一致検出 / 日本語注入 / 単価非捏造 / 上限 / 保存 / kill-switch / 未対応形式案内 /
エンジン不在時の graceful)。読取エンジン本体は `lib/drawing-reader/` (selftest 118軸・検証軸 L61) で、
本ブリッジは CLI 経由でのみ呼ぶ (エンジン無編集・出典を一意に保つ)。

---

## Step 0.67: 意図カルテ — 思想を業種知識より先に配る (I-2 / I-3 / v2056 NEW)

憲章 第3条3-4「思想がシステムを作っていく」を構造にする工程。従来は**業種がシステムを作る**構造で、「介護システムを作って」と言えば誰が言っても同じ骨格が出ていた。しかし同じ介護でも「職員の残業をなくしたい」「家族との関係を作りたい」「地域のハブになりたい」は**まったく違うシステム**であるべき。本 Step は依頼文と Step 0.65 で取り込んだ**システム化の目的**から意図カルテを組み立て、**業種知識 (Step 0.8 DBL / Step 0.88 Japan) より先に**全ロールへ配る。**順序が意味を持つ**(思想が上位・業種辞書はそれを実現する土台)。

**実行タイミング**: Step 0.66 の後・Step 0.7 事業推論の前。`$PROJECT_DIR` を渡す。

```bash
mkdir -p "$PROJECT_DIR/.soloptilink"; printf '%s' "$TARGET_TASK" > "$PROJECT_DIR/.soloptilink/task-text.txt"
ICH_BLOCK="$(bash ~/.soloptilink/lib/first-boot-perfect/intent-charter.sh generate "$PROJECT_DIR" \
  --dbl "${SOLOPTILINK_DETECTED_DBL:-}" --task-file "$PROJECT_DIR/.soloptilink/task-text.txt" 2>/dev/null)"
if [ -n "$ICH_BLOCK" ]; then
  TARGET_TASK="${TARGET_TASK}

${ICH_BLOCK}"
fi
```

**意図カルテの 5 項目**: 誰の / どんな状態を / どう変えたいか / なぜそれを / 何を大事にするか。Step 0.65 で取り込んだ `purpose` (ヒアリングの `rfp_dna.goal`) があれば「どう変えたいか」の出所として最優先で使う。

**★抽出できないときに止まらない (最重要)**: 意図が語られていなくても**質問しない**。業種の標準的な思想を仮置きし、「こう理解しました」を 1 行で提示して進む。憲章は「コードを書けない人が作れた」を原体験としており、**意図を語れない人を切り捨ててはいけない**。既存の「質問はデフォルト OFF・推測で補完し前提を 1 行ずつ明示」の設計と同じ規律で動く — **推測して進み、推測したことを開示する**。

**思想が決める領域 (思想可変域 / `intent_shaped`)**:
- 最初の画面に何を置くか / 何を指標にするか / 誰に何を通知するか / どんな言葉で語りかけるか / どの差別化機能を作るか

**思想では変えない領域 (思想不変域 / `fixed_floor`)**:
- 法令要件 / 算定式 (介護報酬・診療報酬・消費税の端数処理) / 帳票の法定記載事項 / 認証 / 権限分離 / 監査ログ / 暗号化
- **「うちは自由な社風だから権限を緩くしたい」は聞かない。** 緩める要望は採用せず `rejected_overrides` に記録し、注入ブロックで「採用しない」ことを明示する。意図カルテが不変域を書き換えていた場合、`generate` は注入ブロックを出さずに**止まる**(自己検査 `assert_floor` が発火)。

**用語について (T-I0-J)**: 憲章は「可変層 / 不変層」と書くが、本体では既に**『可変層』が別の意味(規模層 / scale layers)**で使われている。二重の意味を避けるため、実装名と本文の呼称は**思想可変域 (`intent_shaped`) / 思想不変域 (`fixed_floor`)** に統一する。既存の規模層には一切影響しない。

**結果の適用**:
- `$PROJECT_DIR/.soloptilink/intent-charter.json` (機械可読) と `$PROJECT_DIR/agent-evidence/intent-charter.md` (人間可読・設計入力) が発行される
- context_block が `$TARGET_TASK` に追記され、Step 2.A の `plan` が全ロールへ注入する
- Step 0.985 の UX-First Concept はこの意図カルテを読み、主要動線・ダッシュボード指標・ペルソナ・語りかけを**思想から**導く (業種の標準形へ戻さない)

**顧客可視出力**: 「◯◯を実現するためのシステムとして設計します(こう理解しました: …)」と**日本語一文**で伝えてよい。推測で置いた前提があるときは必ずその 1 行も添える。JSON・コマンド・内部用語は顧客文に貼らない。

**kill-switch**: `ENABLE_INTENT_CHARTER=off` で完全 no-op (旧挙動=意図カルテなし・業種主導)。既定 on。python3 不在時も no-op で素通り。

**保守 (管理者)**: `bash ~/.soloptilink/lib/first-boot-perfect/intent-charter.sh selftest` (健全側 7 + 欠陥側 4 + kill-switch の両側検証)。思想差分の常設検査は検証軸 `L205-INTENT-DRIVEN`。SoT: `intent-charter.sh`。
---

## Step 0.985: UX-First Concept 定義 (PFP-159 / v2050.3 NEW・「最初を決める」設計思想)

owner 要求 (2026-07-09): 「見た目と使いやすさと機能重視のシステム開発を最優先」「最初を決めて、そこから作っていくイメージ」。従来の SoloptiLinkAI は業務ロジック優先 (DBL→機能→CRUD) だが、本 Step で **UX/UI コンセプト定義を業務ロジック確定より前** に行い、全 105 ロールへ意思決定を先に届ける。素の CRUD (表とフォームだけ並べる) を構造的に禁ずる。

**実行タイミング**: Step 0.98 の後・Step 0.99 (Rich UI 既定教典) の前。事業推論 (Step 0.7) と DBL 検出 (Step 0.8) の結果に加え、**Step 0.67 の意図カルテ (`.soloptilink/intent-charter.json`) を読む**。意図カルテがある場合、主要動線・ダッシュボード指標・ペルソナ・語りかけは**思想から**導かれ、業種の標準形へは戻さない (T-I0-C)。意図カルテが無い環境では従来どおり業種既定で動く。

```bash
# UX Concept Gate: 業種+DBL+タスク文から Silent Inference でトーン/情報アーキ/主要動線を確定
mkdir -p "$PROJECT_DIR/.soloptilink"; printf '%s' "$TARGET_TASK" > "$PROJECT_DIR/.soloptilink/task-text.txt"
UCG_BLOCK="$(bash ~/.soloptilink/lib/first-boot-perfect/ux-concept-gate.sh generate "$PROJECT_DIR" \
  --dbl "${SOLOPTILINK_DETECTED_DBL:-}" --task-file "$PROJECT_DIR/.soloptilink/task-text.txt" 2>/dev/null)"
if [ -n "$UCG_BLOCK" ]; then
  TARGET_TASK="${TARGET_TASK}

${UCG_BLOCK}"
fi
```

**推論内容**:
- **トーン** (5種): professional / friendly / minimal / rich / playful — 業種から自動選択 (介護→friendly-professional / EC→rich / 経営層→professional 等)
- **情報アーキ**: sidebar / tabs / task-centric / dashboard-first
- **主要ペルソナ** (2-3人): 業種別に自動列挙 (介護→ケアマネ+介護スタッフ / EC→顧客+店舗運営 等)
- **主要動線 3 本**: 1 本目は**思想由来の最重要動線**、2 本目以降が業種別の標準フロー (意図カルテが無ければ全て業種別)
- **ダッシュボード優先度**: KPI枚数・主要グラフ種別・**KPI に何を出すか (思想が決める)**
- **CRUD 設計方針**: 一覧=RichListPage+RichTable / 詳細=RichDetailView / フォーム=RichForm+RichFormField (全 `@/lib/rich-ui-templates` から import)

**結果の適用**:
- `$PROJECT_DIR/.soloptilink/ux-concept.json` (機械可読) と `$PROJECT_DIR/agent-evidence/ux-concept.md` (人間可読・設計入力) が発行される
- context_block (「UX-First Concept・必須遵守」ブロック) が `$TARGET_TASK` に追記され、Step 2.A の `plan` が全 105 ロールへ自動注入する
- 全ロールは業務ロジックの前に UX コンセプトを設計の基盤として実装する
- 素の CRUD (表とフォームだけ並べる) は PFP-160 (次の完成ゲート) が静的検出で FAIL/BLOCK

**Silent Inference**: 業種+タスク文の内容から安全デフォルトを自動決定する (質問しない)。owner は生成された `.soloptilink/ux-concept.json` を手修正すれば全 role に再注入される。

**Kill-switch**: `ENABLE_UX_CONCEPT_GATE=off` で完全 no-op (旧挙動=UX Concept 定義なし)。既定 on。

**顧客可視出力**: 生成後に「UX コンセプト (トーン: X / 主要ペルソナ: Y / 主要動線: Z) を確定して設計に反映します」と日本語一文で伝えてよい。JSON・コマンドは顧客文に貼らない。

**保守 (管理者)**: `bash ~/.soloptilink/lib/first-boot-perfect/ux-concept-gate.sh selftest`。SoT: `ux-concept-gate.sh`。

---

