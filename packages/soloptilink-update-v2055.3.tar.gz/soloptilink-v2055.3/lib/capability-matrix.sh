#!/usr/bin/env bash
# ==============================================================================
# capability-matrix.sh — 対応可否早見表ジェネレータ (T-260 / 設計D-1派生)
#
# 背景(なぜ必要か):
#   「できること/できないこと」の結論が営業の手元に無く、受注してはいけない案件
#   (書き戻し不可の連携・対応範囲外の製図 等)を受けてしまう事故を防ぐため、
#   営業向けの1枚早見表を辞書から機械生成する(手書きの二重管理をしない)。
#
# 生成元(2ソース・いずれもデータSoT):
#   (a) lib/capability-matrix/boundaries.json — 自社の能力境界台帳(連携以外の可否)
#   (b) integrations/*.json の feasibility 節  — 外部サービス連携の可否(T-220 成果)
#
# サブコマンド:
#   rows      結合済みの行データを JSON で出力(検証軸 L156 が機械照合に使う)
#   generate  営業向け早見表 Markdown を stdout に出力(内部用語を含めない)
#   write     generate の結果を正準出力先へ原子的に書き出す
#             (既定: lib/capability-matrix/capability-matrix.ja.md)
#   selftest  両側判定: 健全ソース=生成成功+全行含有+内部用語ゼロ /
#             欠陥検体(台帳欠落・内部用語混入)=確実に失敗すること
#
# 呼出元(本番): lib/sales/sales-bridge.sh capability-matrix — 営業フローの入口
# @run-evidence: lib/capability-matrix/capability-matrix.ja.md
# kill-switch: SOLOPTILINK_CAPABILITY_MATRIX=off で無効化(write/generate は no-op)
# 環境変数:
#   CAPMATRIX_BOUNDARIES  能力境界台帳のパス (default: $SL/lib/capability-matrix/boundaries.json)
#   CAPMATRIX_IBL_DIR     連携辞書ディレクトリ (default: $SL/integrations)
#   CAPMATRIX_OUT         write の出力先 (default: $SL/lib/capability-matrix/capability-matrix.ja.md)
# 終了コード: 0=正常 / 2=生成元の欠落・破損(fail-closed: 部分生成はしない) / 3=内部用語混入
#
# (c) 2026 SoloptiLink Inc. - All rights reserved. 営業秘密 / 著作権法・不正競争防止法で保護
# ==============================================================================
set -uo pipefail

SL="${SOLOPTILINK_HOME:-$HOME/.soloptilink}"
BOUNDARIES="${CAPMATRIX_BOUNDARIES:-$SL/lib/capability-matrix/boundaries.json}"
IBL_SRC_DIR="${CAPMATRIX_IBL_DIR:-$SL/integrations}"
OUT="${CAPMATRIX_OUT:-$SL/lib/capability-matrix/capability-matrix.ja.md}"

# --- 生成本体 (mode: rows|generate) ------------------------------------------
_capmatrix_py() {
  local mode="$1"
  MODE="$mode" BOUNDARIES="$BOUNDARIES" IBL_SRC_DIR="$IBL_SRC_DIR" python3 - <<'PY'
import json, os, sys, glob, datetime, re

mode = os.environ["MODE"]
bpath = os.environ["BOUNDARIES"]
ibl_dir = os.environ["IBL_SRC_DIR"]

# fail-closed: 生成元が欠落・破損なら部分生成せずエラー終了(exit 2)
if not os.path.isfile(bpath):
    print(f"エラー: 能力境界台帳が見つかりません: {bpath}", file=sys.stderr)
    sys.exit(2)
try:
    bdata = json.load(open(bpath))
    brows = bdata["boundaries"]
    assert isinstance(brows, list) and brows
except Exception as e:
    print(f"エラー: 能力境界台帳を読み取れません: {e}", file=sys.stderr)
    sys.exit(2)

_FJ = {"yes": "可", "conditional": "条件付き", "no": "不可"}
today = datetime.date.today()
FRESH_DAYS = int(os.environ.get("IBL_FRESHNESS_DAYS", "180"))

def _stale_mark(va):
    """verified_at が閾値超過なら注意マークを返す(未記録も要再確認)"""
    if not va:
        return "(要再確認)"
    try:
        d = datetime.date.fromisoformat(str(va))
    except ValueError:
        return "(要再確認)"
    return "(要再確認)" if (today - d).days > FRESH_DAYS else ""

rows = []   # {source, id, item, verdict, cond, alt, verified_at}

# (b) 連携系: integrations/*.json の feasibility 節から読み書き2行ずつ起こす
for f in sorted(glob.glob(os.path.join(ibl_dir, "*.json"))):
    b = os.path.basename(f)
    if b.startswith("_"):
        continue
    try:
        d = json.load(open(f))
    except Exception:
        continue
    fz = d.get("feasibility") or {}
    if not fz:
        continue
    name = d.get("display_name") or d.get("connector") or b[:-5]
    va = fz.get("verified_at") or ""
    rec = fz.get("recommended_pattern_ja") or ""
    dr = fz.get("directions") or {}
    for dkey, dlabel in (("read", "読み取り"), ("write", "書き込み")):
        dd = dr.get(dkey) or {}
        if not dd:
            continue
        verdict = _FJ.get(dd.get("feasible"), "未評価")
        cond = dd.get("method_ja") or dd.get("note_ja") or ""
        if dd.get("risk_ja"):
            cond = (cond + " / " if cond else "") + f"リスク: {dd['risk_ja']}"
        if not cond:
            cond = "—"
        rows.append({
            "source": "feasibility", "id": f"{d.get('connector', b[:-5])}:{dkey}",
            "item": f"{name} 連携({dlabel})", "verdict": verdict,
            "cond": cond, "alt": rec or "—", "verified_at": va,
        })

# (a) 能力系: boundaries.json
for r in brows:
    rows.append({
        "source": "boundaries", "id": r.get("id", ""),
        "item": r.get("item_ja", ""), "verdict": r.get("verdict", "未評価"),
        "cond": r.get("condition_ja") or "—",
        "alt": r.get("alternative_ja") or "—",
        "verified_at": r.get("verified_at", ""),
    })

if mode == "rows":
    print(json.dumps({"generated_at": today.isoformat(), "rows": rows}, ensure_ascii=False, indent=2))
    sys.exit(0)

# generate: 営業向け Markdown(内部用語を含めない)
def cell(s):
    return str(s).replace("|", "／").replace("\n", " ")

L = []
L.append("<!-- 本ファイルは自動生成です(生成器: lib/capability-matrix.sh / 元データ: 能力境界台帳 + 連携可否ナレッジ)。直接編集しないでください -->")
L.append("# 対応可否 早見表")
L.append("")
L.append(f"作成日: {today.isoformat()}")
L.append("")
L.append("ご提案・お見積りの前に本表をご確認ください。「不可」の項目は現時点でお受けできません(代替のご提案をご利用ください)。「条件付き」の項目は、条件・補足に記載の前提が満たせる場合のみお受けできます。")
L.append("")

feas = [r for r in rows if r["source"] == "feasibility"]
caps = [r for r in rows if r["source"] == "boundaries"]

def table(title, rs):
    L.append(f"## {title}")
    L.append("")
    L.append("| 項目 | 可否 | 条件・補足 | 代替のご提案 | 最終確認日 |")
    L.append("| --- | --- | --- | --- | --- |")
    for r in rs:
        va = r["verified_at"] or "未記録"
        L.append(f"| {cell(r['item'])} | **{cell(r['verdict'])}** | {cell(r['cond'])} | {cell(r['alt'])} | {cell(va)}{_stale_mark(r['verified_at'])} |")
    L.append("")

table("外部サービスとの連携", feas)
table("開発・受注範囲(自社能力)", caps)

L.append(f"※ 最終確認日から {FRESH_DAYS} 日を超えた項目、および(要再確認)の付いた項目は、ご提案前に最新状況の再確認をお願いします。")
L.append("※ 本表は社内データから自動生成されています。個別の行を手で書き換えず、元データの更新をご依頼ください。")

out = "\n".join(L)

# 自己防衛: 営業向け出力に内部用語(PFP番号・ゲート名・内部パス等)が混入したら
# 出力せずに失敗する(exit 3)。HTMLコメント(非表示)は検査対象から除外する。
visible = re.sub(r"<!--.*?-->", "", out, flags=re.S)
jargon = re.compile(r"PFP-[0-9]+|verify\.d|gates-manifest|structural-defenses|chain\.sh|\.soloptilink/|[A-Za-z0-9_-]+\.sh\b|SKILL\.md")
m = jargon.search(visible)
if m:
    print(f"エラー: 営業向け出力に内部用語が混入しています: '{m.group(0)}' — 元データ(条件・補足/代替案)から内部用語を除去してください", file=sys.stderr)
    sys.exit(3)

print(out)
PY
}

_write() {
  local tmp
  tmp="$(mktemp "${TMPDIR:-/tmp}/capmatrix.XXXXXX")" || return 2
  if ! _capmatrix_py generate > "$tmp"; then
    local rc=$?
    rm -f "$tmp"
    return "$rc"
  fi
  mkdir -p "$(dirname "$OUT")" || { rm -f "$tmp"; return 2; }
  mv "$tmp" "$OUT" || { rm -f "$tmp"; return 2; }
  echo "早見表を書き出しました: $OUT"
}

# --- selftest (両側判定・実走) ------------------------------------------------
_selftest() {
  local ok=1 t
  t="$(mktemp -d "${TMPDIR:-/tmp}/capmatrix-st.XXXXXX")" || return 1

  # [健全側] 実データから生成でき、必須行が全て含まれ、内部用語ゼロ
  local out
  if out="$(bash "${BASH_SOURCE[0]}" generate 2>/dev/null)"; then
    local miss=0 item
    for item in "機械製図" "3Dモデルからの投影図" "バーコード/QRコード読取" "PLC・センサー・シリアル機器" \
                "ビル空調" "他社が構築した既存システム" "中規模病院" "自治体案件" "サロンボード"; do
      grep -q "$item" <<<"$out" || { echo "  NG(健全側): 必須行が出力に無い: $item"; miss=1; }
    done
    [[ $miss -eq 0 ]] && echo "  OK(健全側): 生成成功・必須9項目すべて含有" || ok=0
    local ban=$(grep -cE "PFP-[0-9]+|verify\.d|gates-manifest" <<<"$out" || true)
    [[ "$ban" -eq 0 ]] && echo "  OK(健全側): 内部用語ゼロ" || { echo "  NG(健全側): 内部用語が混入"; ok=0; }
  else
    echo "  NG(健全側): 実データからの生成に失敗"
    ok=0
  fi

  # [欠陥側A] 台帳欠落 → fail-closed で非0終了すること(部分生成しない)
  if CAPMATRIX_BOUNDARIES="$t/nonexistent.json" bash "${BASH_SOURCE[0]}" generate >/dev/null 2>&1; then
    echo "  NG(欠陥側A): 台帳欠落でも生成が成功してしまった(fail-open)"
    ok=0
  else
    echo "  OK(欠陥側A): 台帳欠落で生成拒否(fail-closed)"
  fi

  # [欠陥側B] 内部用語が台帳に混入 → 出力せず exit 3 で失敗すること
  python3 - "$BOUNDARIES" "$t/jargon.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
d["boundaries"][0]["condition_ja"] = "PFP-999 ゲートと verify.d レーンが前提"
json.dump(d, open(sys.argv[2], "w"), ensure_ascii=False)
PY
  CAPMATRIX_BOUNDARIES="$t/jargon.json" bash "${BASH_SOURCE[0]}" generate >/dev/null 2>&1
  local rc=$?
  if [[ $rc -eq 3 ]]; then
    echo "  OK(欠陥側B): 内部用語混入を検出し出力拒否(exit 3)"
  else
    echo "  NG(欠陥側B): 内部用語混入を素通し(exit $rc)"
    ok=0
  fi

  rm -rf "$t"
  if [[ $ok -eq 1 ]]; then
    echo "SELFTEST: PASS (健全=生成成功+9項目+用語ゼロ / 欠陥=fail-closed+用語検出)"
    return 0
  fi
  echo "SELFTEST: FAIL"
  return 1
}

# --- dispatch (selftest は kill-switch の影響を受けず常に弁別を実行) ----------
CMD="${1:-generate}"
if [[ "$CMD" == "selftest" ]]; then _selftest; exit $?; fi
if [[ "${SOLOPTILINK_CAPABILITY_MATRIX:-on}" == "off" ]]; then
  echo "(capability-matrix は kill-switch により無効化されています)" >&2
  exit 0
fi
case "$CMD" in
  rows)     _capmatrix_py rows ;;
  generate) _capmatrix_py generate ;;
  write)    _write ;;
  *) echo "usage: capability-matrix.sh {rows|generate|write|selftest}" >&2; exit 2 ;;
esac
