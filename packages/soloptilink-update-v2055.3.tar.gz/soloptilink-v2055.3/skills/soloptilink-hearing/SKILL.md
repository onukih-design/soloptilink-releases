---
name: soloptilink-hearing
description: "SoloptiLinkAI v2055.3 - 「ヒアリング」「ヒアリングシート」「要件を聞き出す」「議事録から要件」「文字起こしから要件」「要件ヒアリング」「ヒアリング結果まとめて」等で起動。業種別ヒアリングシートの生成と、議事録/文字起こしからの要件構造化を行う要件抽出エンジン。"
argument-hint: "[業種フレーズ or 議事録/文字起こしテキスト] [--digest <dbl名>] [--structure (構造化モードへ直行)] [--out <保存先ディレクトリ>]"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, AskUserQuestion, TodoWrite"
---

# SoloptiLinkAI v2055.3 - Hearing Engine (要件ヒアリング)


## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

## 機能概要

SoloptiLinkAI v1.0 Hearing Engine - 受託開発の最上流「要件ヒアリング」を業種辞書 (DBL) の知識で武装するスキル。業種フレーズ一言から、その業界のモデル・画面・業務ロジック・法令を「質問の種」として取り込み、顧客にそのまま見せられる業種別ヒアリングシート (日本語・7カテゴリ) を生成する。さらに、ヒアリング後の議事録・文字起こしテキストを貼り付けるだけで {業種/事業規模/必須モジュール/該当規制/業務フロー/曖昧点} に構造化し、後続の /soloptilink-rfp (提案書・見積) や /soloptilink-boost (構築) にそのまま引き継げる形で保存する。「ヒアリング」「ヒアリングシート」「要件を聞き出す」「議事録から要件」等で起動。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 特にこのスキルは「顧客に見せる質問リスト」を作るため、生成するヒアリングシート本文にも内部用語 (DBL/dbl名/grade/JSONキー名/スキル名) を一切出さないこと。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

## Step 0: 端末認証 (BOOST と同一)

```bash
SOLOPTILINK_BIN=""; if [ -f ~/.soloptilink/soloptilink ]; then SOLOPTILINK_BIN="./soloptilink"; elif [ -f ~/.soloptilink/soloptilink.exe ]; then SOLOPTILINK_BIN="./soloptilink.exe"; fi
AUTH_CHECK=$(cd ~/.soloptilink 2>/dev/null && ${SOLOPTILINK_BIN:-./soloptilink} --status 2>&1); if echo "$AUTH_CHECK" | grep -q "承認済み"; then echo "AUTHORIZED"; else echo "UNAUTHORIZED"; fi
```

`UNAUTHORIZED` の場合、認証案内を表示して処理中止。

## Step 1: 業種特定 (質問の種の取得)

ユーザーの業種フレーズ (例:「保育園の管理システム」) を hearing-engine に渡し、質問の種を取得する:

```bash
bash ~/.soloptilink/lib/hearing-engine.sh sheet "<業種フレーズ>"
```

出力 JSON の読み方 (この status 分岐に必ず従う):

| status | 意味 | Step 2 での扱い |
|--------|------|----------------|
| `detected` | 業種特定成功 (confident=true) | `question_seeds` (models/pages/business_logic/regulations/keywords/kpi_targets) を `hearing_axes` の7カテゴリに割り付けて質問を具体化する。各 axis の `dbl_material` が対応キー |
| `low_confidence` | 候補はあるが確信度低 | `candidate_preview` の業種が合っているかを AskUserQuestion で先にユーザーへ確認。確認できたら `digest "<dbl名>"` で要点を取得して具体化。否定されたら汎用7軸で進める |
| `unregistered` | DBL 未登録業種 | `hearing_axes` の汎用7軸を業種フレーズの文脈に合わせて言い換えて使う |

補助コマンド (業種確定後の深掘り素材):

```bash
bash ~/.soloptilink/lib/hearing-engine.sh digest "<dbl名>"
```

`notes_for_claude` 配列には状況別の展開指示が入っているので必ず読むこと。エンジンが exit 2 (環境エラー) の場合も処理は止めず、汎用7軸 (下記 Step 2 の7カテゴリ) を自力で展開してシート生成を続行する。

## Step 2: 業種別ヒアリングシート生成

Step 1 の素材から、**顧客にそのまま渡せる日本語の質問リスト**を生成する。

7カテゴリ構成 (固定・hearing_axes と同一):

| # | カテゴリ | DBL 知識での具体化 |
|---|---------|------------------|
| ① | 業務フロー | pages/business_logic の業務名を使い「〇〇 (例: 登降園の記録) は今どう運用していますか」と実名で聞く |
| ② | 現在の困りごと | kpi_targets/business_logic から業界の典型痛点 (例: 加算算定漏れ・請求差戻し) を選択肢として提示 |
| ③ | 帳票・データ | models/seed_data の実体名 (例: 児童票・指導計画・請求データ) を帳票候補として列挙し有無を確認 |
| ④ | 例外処理・繁忙期 | business_logic/enums からキャンセル・訂正・月次締め等の例外系を業界文脈で聞く |
| ⑤ | 関係法令・規制対応 | regulations の法令名・保存年限・届出を具体名で聞く (例:「児童福祉法に基づく記録の保存はどうされていますか」) |
| ⑥ | 既存システム・連携先 | keywords から業界の定番システム・連携先を候補提示して突合 |
| ⑦ | 利用者・権限 | models の User/role 構造から想定ロールを提示し実際の役割分担を確認 |

生成ルール:
- 質問数は各カテゴリ 5〜10問・合計 40〜60問。回答記入欄 (表形式) 付き。
- 業界用語は質問文に活かすが、初出時は括弧で平易な補足を添える。
- detected の場合、汎用質問の言い換えだけで済ませず、question_seeds の固有名詞を最低各カテゴリ2問以上に織り込む。
- シート冒頭に「ご回答はわかる範囲で結構です。空欄は当日のお打ち合わせで伺います」の一文を入れる。
- シート本文に内部用語 (dbl 名・grade・JSON キー名・SoloptiLinkAI のスキル名) を出さない。

保存先 (Markdown):

```
<プロジェクト>/ヒアリングシート_<業種>.md
```

`<業種>` は日本語の業種名 (例: ヒアリングシート_保育園.md)。`--out` 指定時はそのディレクトリ配下に保存。保存後、ユーザーには「どの質問から聞くべきか」上位5問の優先順位も日本語で添える。

## Step 3: ヒアリング結果の構造化

ユーザーが議事録・文字起こしテキストを貼り付けたら (または `--structure` 指定時)、以下を抽出して構造化する。**書かれている事実のみ抽出し、推測で埋めない。不明な点はすべて「曖昧点」に回す (捏造禁止)。**

抽出6項目: 業種 / 事業規模 / 必須モジュール / 該当規制 / 業務フロー / 曖昧点

保存先: `<プロジェクト>/.soloptilink-hearing-session.json` — `.soloptilink-rfp-session.json` 互換 (RFP-DNA 構造に整合) の形式:

```json
{
  "skill": "soloptilink-hearing",
  "status": "hearing",
  "created_at": "<ISO8601>",
  "industry_phrase": "<Step 1 の業種フレーズ>",
  "dbl": "<検出 dbl 名 or unregistered>",
  "hearing": {
    "industry": "<業種 (日本語)>",
    "business_scale": "<事業規模 (拠点数/利用者数/職員数/売上規模など議事録の事実)>",
    "required_modules": ["<必須モジュール>", "..."],
    "applicable_regulations": ["<該当規制・法令>", "..."],
    "workflow": ["<業務フローの手順を時系列で>", "..."],
    "ambiguities": ["<曖昧点・未確認事項>", "..."]
  },
  "rfp_dna": {
    "goal": "<システム化の目的>",
    "scope": ["<対象業務範囲>"],
    "constraints": ["<制約 (予算/期限/環境/体制)>"],
    "deliverables": ["<期待成果物>"],
    "deadline": "<納期 (不明なら空文字)>",
    "budget_hint": "<予算感 (不明なら空文字)>",
    "evaluators": ["<意思決定者・評価者>"],
    "risks": ["<リスク>"],
    "implicit_requirements": ["<明言されていないが業種上必須の暗黙要件 (DBL の regulations/business_logic から補完し、補完であることを明記)>"]
  }
}
```

`rfp_dna` は /soloptilink-rfp の Step 1 (RFP-DNA: goal/scope/constraints/deliverables/deadline/budget_hint/evaluators/risks + implicit_requirements) と同じキー構成にすること。これにより /soloptilink-rfp が議事録なしでもこのセッションから提案書・見積を生成できる。

保存直後に案件台帳 (Engagement Ledger) へ自動登録する (status=hearing はセッション JSON の `"status": "hearing"` フィールドで伝達):

```bash
[ -f ~/.soloptilink/lib/engagement-ledger.sh ] && bash ~/.soloptilink/lib/engagement-ledger.sh ingest .soloptilink-hearing-session.json || true
```

engagement-ledger.sh が未配置の環境ではスキップし (エラーにしない)、セッション JSON の保存だけで完了とする。

構造化の完了報告では、抽出結果の要約 (生 JSON ではなく日本語の箇条書き) と、`ambiguities` を「次回確認すべき追加質問リスト」に変換して提示する。

## Step 4: 次アクション案内

構造化完了後、ユーザーに次の選択肢を日本語で案内する:

| 次アクション | 起動 | 引き継がれるもの |
|------------|------|----------------|
| 提案書・概算見積・WBS・契約書の作成 | `/soloptilink-rfp` | `.soloptilink-hearing-session.json` の `rfp_dna` (RFP-DNA 互換) |
| 業務システムの構築開始 | `/soloptilink-boost` | 業種・必須モジュール・該当規制・業務フロー |
| ヒアリング続行 | このスキルのまま | 曖昧点の追加質問リスト |

曖昧点が3件以上残っている場合は「先に曖昧点を潰してから見積に進むこと」を推奨として添える。

## 出力配置

デフォルト: `<カレントディレクトリ>/`
- `ヒアリングシート_<業種>.md` (Step 2)
- `.soloptilink-hearing-session.json` (Step 3 / RFP-DNA 互換)

## 引数の解釈

| 引数 | 動作 |
|------|------|
| 引数なし | インタラクティブモード (ユーザに業種・案件概要を確認して Step 1 へ) |
| 業種フレーズ | Step 1 → Step 2 (ヒアリングシート生成) |
| 議事録/文字起こしテキスト or ファイルパス | Step 3 (構造化) へ直行 |
| `--digest <dbl名>` | 指定業種辞書の要点 digest のみ表示 (日本語要約で提示) |
| `--structure` | 構造化モードへ直行 (テキスト貼り付けを促す) |
| `--out <ディレクトリ>` | 出力先ディレクトリ指定 |

## 使用例

```
/soloptilink-hearing 保育園の管理システム (→ 保育園向けヒアリングシート生成)

/soloptilink-hearing 訪問介護事業所のシステム入替を検討しているお客様に聞くことをまとめて

/soloptilink-hearing --structure (→ 議事録を貼り付けて要件構造化)

/soloptilink-hearing ./議事録_20260613_株式会社サンプル.txt (→ ファイルから構造化)

/soloptilink-hearing --digest long-term-care (→ 介護業種辞書の要点確認)
```

## セッション継続ルール

このスキル起動後、`.soloptilink-hearing-session.json` がプロジェクトに作成され、以降の会話で:
- 「シートに〇〇の質問を足して」→ 既存ヒアリングシートを更新
- 「議事録貼るね」→ Step 3 構造化を実行 (2回目以降は既存セッションにマージ)
- 「曖昧点まとめて」→ ambiguities を追加質問リストとして再提示
- 「提案書に進んで」→ /soloptilink-rfp へ引き継ぎ

として継続的に操作可能。

セッションファイル `.soloptilink-hearing-session.json` を更新するたびに `bash ~/.soloptilink/lib/engagement-ledger.sh ingest .soloptilink-hearing-session.json` を再実行し、案件台帳 (Engagement Ledger) の状態を最新化する (未配置環境ではスキップ)。

## 統合スキル

- `/soloptilink-rfp`: 提案書・概算見積・WBS・契約書 (ヒアリング結果を RFP-DNA として引き継ぐ)
- `/soloptilink-boost`: 業務システム構築 (業種・必須モジュールを引き継ぐ)
- `/soloptilink-blueprint`: 業種辞書 (DBL) の照会・比較
- `/soloptilink-fde`: 案件台帳 (Engagement Ledger) の横断管理
