/**
 * soloptilink-template-kit / scaffolder
 *
 * KitDefinition を入力として、ターゲットディレクトリに Next.js 15 ベースの
 * 90% 完成プロジェクトを書き出す。
 *
 *   scaffold(kit, targetDir, options) -> ScaffoldReport
 *
 * 出力ファイル群:
 *   - package.json / tsconfig.json / next.config.ts / tailwind.config.ts
 *   - postcss.config.mjs / .env.example / .gitignore
 *   - prisma/schema.prisma / prisma/seed.ts
 *   - src/app/layout.tsx / src/app/page.tsx (ダッシュボード)
 *   - src/app/(domain)/<resource>/page.tsx (一覧)
 *   - src/app/(domain)/<resource>/[id]/page.tsx (詳細)
 *   - src/app/(domain)/<resource>/new/page.tsx (新規作成)
 *   - src/app/api/<resource>/route.ts (CRUD API)
 *   - src/lib/db.ts / src/lib/validators.ts
 *   - src/components/ui/{button,card,input,label,table}.tsx
 *   - README.md / docs/DESIGN_CONTRACT.md
 */

import { mkdirSync, writeFileSync, appendFileSync, existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join, dirname } from 'node:path';
import type { KitDefinition, KitField, KitPrismaModel, KitRoute } from './kit_loader';

// ---------------------------------------------------------------------------
// 型
// ---------------------------------------------------------------------------

export interface ScaffoldOptions {
  /** ja (default) / en */
  locale?: 'ja' | 'en';
  /** 既存ディレクトリの上書きを許可するか (default: true) */
  overwrite?: boolean;
}

/**
 * バックアップ手段 (scripts/backup.sh + docs/RESTORE.md) の同梱結果。
 * status の意味:
 *   applied     … ゲートの apply が走り、実体が生成物に入った
 *   unmeasured  … ゲート本体が見つからず同梱できたか測れていない (合格ではない)
 *   failed      … ゲートは走ったのに実体が入らなかった (scaffold を止める)
 *   off         … kill-switch TEMPLATE_KIT_BACKUP_RESTORE=off で意図的に外した
 */
export interface BackupRestoreOutcome {
  status: 'applied' | 'unmeasured' | 'failed' | 'off';
  detail_ja: string;
  files: string[];
}

export interface ScaffoldReport {
  kit_id: string;
  target_dir: string;
  files_written: string[];
  total_lines: number;
  setup_minutes: number;
  /** PFP-111 バックアップ手段の同梱結果 (2026-08-06 / T-311 追加) */
  backup_restore?: BackupRestoreOutcome;
}

// ---------------------------------------------------------------------------
// 内部ユーティリティ
// ---------------------------------------------------------------------------

function ensureDir(dir: string): void {
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
}

function writeOut(absPath: string, content: string, report: ScaffoldReport): void {
  ensureDir(dirname(absPath));
  writeFileSync(absPath, content, 'utf8');
  report.files_written.push(absPath);
  report.total_lines += content.split('\n').length;
}

/** 既に書き出したファイルへ追記する (行数だけ加算し、二重計上しない) */
function appendOut(absPath: string, extra: string, report: ScaffoldReport): void {
  appendFileSync(absPath, extra, 'utf8');
  report.total_lines += extra.split('\n').length - 1;
}

// ---------------------------------------------------------------------------
// PFP-111 バックアップ手段の同梱 (2026-08-06 / T-311 新設)
//
// 【なぜ scaffolder が自前でテンプレを持たないか】
//   scripts/backup.sh と docs/RESTORE.md の中身は、本体ゲート
//   lib/first-boot-perfect/backup-restore-gate.sh のヒアドキュメント (_apply_r1 / _apply_r2)
//   が唯一の正典である。ここで同じ内容を書き写すと定義が 2 箇所になり、
//   「どちらが本物か分からない」を作る (実際に当社で繰り返してきた欠陥クラス)。
//   そのため kit 経路は **ゲートの apply を呼ぶだけ** にしてある。
//   DATABASE_URL の種別 (SQLite / PostgreSQL) 判定も、ゲート側の実装をそのまま使う。
//
// 【実測 (2026-08-06)】
//   これを入れる前、kit 展開経路の生成物には backup / RESTORE の実体が 1 件も無かった
//   (scaffolder.ts を grep してヒット 0)。boost 経路だけがゲート経由で装備されていた。
// ---------------------------------------------------------------------------

/** 本体ゲートの所在。SOLOPTILINK_HOME を優先し、無ければ ~/.soloptilink を見る。 */
function backupRestoreGatePath(): string | null {
  const home =
    process.env.SOLOPTILINK_HOME ?? join(process.env.HOME ?? '', '.soloptilink');
  const p = join(home, 'lib', 'first-boot-perfect', 'backup-restore-gate.sh');
  return existsSync(p) ? p : null;
}

/**
 * 生成物へバックアップ手段を同梱する (ゲートの apply を呼ぶ)。
 *
 * kill-switch: TEMPLATE_KIT_BACKUP_RESTORE=off (既定 on)
 *
 * ゲートが見つからない環境では「入れたつもり」にせず unmeasured を返す。
 * ゲートは走ったのに実体が入らなかった場合は例外で止める (黙って欠けた生成物を
 * 完成として返さない)。
 */
export function applyBackupRestore(targetDir: string): BackupRestoreOutcome {
  if ((process.env.TEMPLATE_KIT_BACKUP_RESTORE ?? 'on') === 'off') {
    return {
      status: 'off',
      detail_ja:
        'kill-switch TEMPLATE_KIT_BACKUP_RESTORE=off のため、バックアップ手段を同梱していません',
      files: [],
    };
  }
  const gate = backupRestoreGatePath();
  if (gate === null) {
    return {
      status: 'unmeasured',
      detail_ja:
        'backup-restore-gate.sh が見つからず、バックアップ手段を同梱できたか測れていません' +
        ' (SOLOPTILINK_HOME を指定するか、生成後に手動でゲートの apply を実行してください)',
      files: [],
    };
  }
  // ゲートは STRICT 設定次第で終了コード 1 を返す。判定は終了コードではなく
  // 「実体が置かれたか」で行う (是正が目的であり、判定はこの後のゲート run が行う)。
  try {
    execFileSync('bash', [gate, 'apply', targetDir], {
      stdio: 'ignore',
      timeout: 120_000,
    });
  } catch {
    /* 終了コードは見ない (下でファイルの実在を確かめる) */
  }
  const backup = join(targetDir, 'scripts', 'backup.sh');
  const restore = join(targetDir, 'docs', 'RESTORE.md');
  const files = [backup, restore].filter((f) => existsSync(f));
  if (files.length < 2) {
    throw new Error(
      'バックアップ手段の同梱に失敗しました: ' +
        `${gate} apply を実行しましたが scripts/backup.sh / docs/RESTORE.md が生成物に入りませんでした` +
        ` (実在したのは ${files.length} / 2 件)。生成物を不完全なまま返さないため中断します。`,
    );
  }
  return {
    status: 'applied',
    detail_ja:
      'PFP-111 ゲートの apply により scripts/backup.sh と docs/RESTORE.md を同梱しました' +
      ' (テンプレの正典はゲート側の 1 箇所)',
    files,
  };
}

function toKebabCase(s: string): string {
  return s
    .replace(/([a-z0-9])([A-Z])/g, '$1-$2')
    .replace(/_/g, '-')
    .toLowerCase();
}

function toPascalCase(s: string): string {
  return s
    .replace(/[-_](.)/g, (_, c) => c.toUpperCase())
    .replace(/^(.)/, (_, c) => c.toUpperCase());
}

/**
 * route の path から resource 名を取り出す。
 * "/api/projects" -> "projects"
 * "/projects/[id]" -> "projects"
 */
function resourceFromPath(path: string): string | undefined {
  const segs = path.split('/').filter(Boolean);
  if (segs.length === 0) return undefined;
  if (segs[0] === 'api') return segs[1];
  return segs[0];
}

function uniqueResources(routes: KitRoute[]): string[] {
  const set = new Set<string>();
  for (const r of routes) {
    if (r.type === 'dashboard') continue;
    const res = r.resource ?? resourceFromPath(r.path);
    if (res && !res.includes('[') && !res.includes('dashboard')) {
      set.add(res);
    }
  }
  return Array.from(set).sort();
}

// ---------------------------------------------------------------------------
// 宣言ルート駆動の生成計画 (routePlan) — 2026-08-06 新設 / T-301
//
// ## なぜ必要か (2026-08-05 実測の事故)
// scaffold() は kit.routes を uniqueResources() で「リソース名」に潰してからしか
// 使っておらず、1 リソースあたり固定 4 ファイルを書き出すだけだった。その結果
// 全 14 kit で宣言 331 ルート中 150 本が生成されず、しかも README / 設計契約は
// kit.routes を無条件に全件列挙していたため、**実体の無い画面をお客様に
// 「主要ページ」として約束**していた。
//
// routePlan() は宣言ルート 1 本ごとに「生成先ファイル」と「この版で生成するか」
// と「生成しない理由」を返す唯一の判断元。scaffold() / buildReadme() /
// buildDesignContract() は全てここを見る (判断が 2 か所に分かれないようにする)。
//
// ## 生成する / 生成しない の線引き (判断基準・破ると空約束か虚偽実装になる)
//  生成する:
//   - 画面 (list / detail / new / edit / report / dashboard) すべての階層。
//     画面は「入れ物 + 空状態」までを雛形として出すことに意味があり、
//     中身を偽らない限り正直な成果物になる。
//   - リソース CRUD に素直に対応する API のみ:
//       /api/<resource>            コレクション (一覧 + 追加)
//       /api/<resource>/[id]       単体 (取得 + 更新 + 削除)
//       /api/dashboard/kpi         宣言済み KPI の参照 (値は未集計として null を返す)
//  生成しない (宣言には残し、README / 設計契約で正直に開示する):
//   - 業務処理を伴う API (計算 / 出力 / 取消 / 匿名化 / 外部接続試験 など)。
//     中身の無い実装を置くと「保存したふり・計算したふり」になるため作らない。
//   - 保存先 / 更新先の API が生成されない new / edit 画面。
//     押しても保存できないボタンは空約束になるため画面ごと作らない。
//   - 同じ階層に別名の可変セグメントが既にあるルート (Next.js がビルドできない)。
// ---------------------------------------------------------------------------

/** routePlan が返す生成物の種別。 */
export type RoutePlanKind =
  | 'dashboard-root'
  | 'dashboard-alias'
  | 'list'
  | 'detail'
  | 'new'
  | 'edit'
  | 'report'
  | 'api-collection'
  | 'api-item'
  | 'api-kpi'
  | 'none';

/** 宣言ルート 1 本に対する生成計画。 */
export interface RoutePlanEntry {
  /** kit 定義の宣言そのもの */
  route: KitRoute;
  /** 生成先ファイル (targetDir からの相対パス)。生成しない場合も「本来の置き場」を示す */
  file: string;
  /** この版で実際に生成するか */
  generated: boolean;
  /** 生成物の種別 */
  kind: RoutePlanKind;
  /** generated=false の理由 (日本語。顧客提示文書へそのまま載る) */
  reason?: string;
  /** new / edit 画面が実際に保存 / 更新に使う API のリソース名 (生成する場合のみ) */
  writeResource?: string;
}

/**
 * kill-switch: 宣言ルート駆動の生成を使うか。
 * 既定 on。`TEMPLATE_KIT_DECLARED_ROUTES=off` で 2026-08-06 以前の挙動
 * (uniqueResources による 4 点セット展開のみ) に完全復帰する。
 */
export function declaredRoutesEnabled(): boolean {
  const v = process.env.TEMPLATE_KIT_DECLARED_ROUTES;
  return String(v ?? 'on').trim().toLowerCase() !== 'off';
}

function segmentsOf(routePath: string): string[] {
  return routePath.split('/').filter(Boolean);
}

function isDynamicSegment(seg: string): boolean {
  return seg.startsWith('[') && seg.endsWith(']');
}

/** src/app/(domain)/<segs...>/page.tsx */
function uiPageFile(segs: string[]): string {
  return join('src', 'app', '(domain)', ...segs, 'page.tsx');
}

/** src/app/api/<segs...>/route.ts */
function apiRouteFile(segs: string[]): string {
  return join('src', 'app', 'api', ...segs, 'route.ts');
}

const ROOT_DASHBOARD_FILE = join('src', 'app', 'page.tsx');

/** 生成しない理由の定型文 (顧客提示文書にそのまま載るので日本語で書く)。 */
const REASON_BUSINESS_API =
  '業務処理を伴う API のため、この版では雛形を生成していません (中身の無い実装で「処理したふり」を作らない方針)';
const REASON_NO_WRITE_API = '保存先 / 更新先の API がこの版に無いため、押しても保存できない画面を作らない判断です';
const REASON_SEGMENT_CONFLICT =
  '同じ階層に別名の可変セグメントが既にあり、Next.js がビルドできない構成になるためです';
const REASON_KILL_SWITCH =
  'kill-switch TEMPLATE_KIT_DECLARED_ROUTES=off により、宣言ルート駆動の生成を止めています';

/** 宣言ルート 1 本を「どのファイルとして生成しうるか」に分類する (生成可否はまだ決めない)。 */
function classifyRoute(route: KitRoute): { file: string; kind: RoutePlanKind; reason?: string } {
  const segs = segmentsOf(route.path);

  if (route.type === 'dashboard') {
    if (segs.length === 0) return { file: ROOT_DASHBOARD_FILE, kind: 'dashboard-root' };
    return { file: uiPageFile(segs), kind: 'dashboard-alias' };
  }

  if (segs[0] === 'api' || route.type === 'api') {
    const rest = segs[0] === 'api' ? segs.slice(1) : segs;
    if (rest.length === 2 && rest[0] === 'dashboard' && rest[1] === 'kpi') {
      return { file: apiRouteFile(rest), kind: 'api-kpi' };
    }
    if (rest.length === 1 && !isDynamicSegment(rest[0])) {
      return { file: apiRouteFile(rest), kind: 'api-collection' };
    }
    if (rest.length === 2 && !isDynamicSegment(rest[0]) && isDynamicSegment(rest[1])) {
      return { file: apiRouteFile(rest), kind: 'api-item' };
    }
    return { file: apiRouteFile(rest), kind: 'none', reason: REASON_BUSINESS_API };
  }

  if (segs.length === 0) {
    return { file: ROOT_DASHBOARD_FILE, kind: 'dashboard-root' };
  }

  const last = segs[segs.length - 1];
  let kind: RoutePlanKind;
  if (last === 'new') kind = 'new';
  else if (last === 'edit') kind = 'edit';
  else if (route.type === 'edit') kind = 'edit';
  else if (route.type === 'detail') kind = 'detail';
  else if (route.type === 'report') kind = 'report';
  else kind = 'list';
  return { file: uiPageFile(segs), kind };
}

/**
 * 画面ルートが保存 / 更新に使う API のリソース名の候補 (優先順)。
 *
 * kit によって routes[].resource の付け方が揺れている (URL のコレクション名を書く kit と、
 * モデル名の単数形を書く kit がある) ため、宣言 → パス由来 の順に候補を出し、
 * 実際に API が生成される方を呼出側が選ぶ。どちらも無ければ画面ごと生成しない。
 */
function writeTargetCandidates(route: KitRoute, kind: RoutePlanKind): string[] {
  const segs = segmentsOf(route.path);
  const cands: string[] = [];
  if (route.resource) cands.push(route.resource);
  if (kind === 'new') {
    // /patients/[id]/consents/new -> consents / /users/new -> users
    const parent = segs[segs.length - 2];
    if (parent && !isDynamicSegment(parent)) cands.push(parent);
  } else if (kind === 'edit') {
    const head = resourceFromPath(route.path);
    if (head) cands.push(head);
  }
  return cands.filter((c, i) => c && !c.includes('[') && cands.indexOf(c) === i);
}

/** 旧挙動 (kill-switch off) で必ず生成されるファイル集合。 */
function legacyFileSet(kit: KitDefinition): Set<string> {
  const files = new Set<string>([ROOT_DASHBOARD_FILE]);
  for (const r of uniqueResources(kit.routes)) {
    files.add(uiPageFile([r]));
    files.add(uiPageFile([r, '[id]']));
    files.add(uiPageFile([r, 'new']));
    files.add(apiRouteFile([r]));
  }
  return files;
}

/** 可変セグメントの占有表に 1 ファイルを登録する。衝突していれば衝突相手を返す。 */
function claimDynamicSegments(file: string, claims: Map<string, string>): string | null {
  const segs = file.split(sepOf(file));
  let dir = '';
  for (const s of segs) {
    if (isDynamicSegment(s)) {
      const prev = claims.get(dir);
      if (prev && prev !== s) return prev;
      claims.set(dir, s);
    }
    dir = `${dir}/${s}`;
  }
  return null;
}

/** join() が使った区切り文字 (Windows の \ / POSIX の / 両対応)。 */
function sepOf(p: string): string {
  return p.includes('\\') ? '\\' : '/';
}

/** scaffold() と routePlan() が共有する生成計画。 */
interface GenerationPlan {
  /** 宣言ルート 1 本ごとの計画 */
  declared: RoutePlanEntry[];
  /** 旧来の 4 点セットを出すリソースと、その [id] 階層に使う可変セグメント名 */
  resources: { resource: string; detailSegment: string | null }[];
}

function buildGenerationPlan(kit: KitDefinition): GenerationPlan {
  const enabled = declaredRoutesEnabled();
  const legacy = legacyFileSet(kit);
  const resources = uniqueResources(kit.routes);

  // 1) 分類
  const classified = kit.routes.map((route) => ({ route, ...classifyRoute(route) }));

  // 2) 保存 / 更新先 API が出るかどうか (new / edit 画面の生成可否に効く)
  const apiFiles = new Set<string>(resources.map((r) => apiRouteFile([r])));
  for (const c of classified) {
    if (c.kind === 'api-collection' || c.kind === 'api-item' || c.kind === 'api-kpi') apiFiles.add(c.file);
  }
  const hasItemApi = (resource: string) => {
    for (const c of classified) {
      if (c.kind !== 'api-item') continue;
      const rest = segmentsOf(c.route.path).slice(1);
      if (rest[0] === resource) return true;
    }
    return false;
  };

  // 3) 宣言ルートの可否を確定する。宣言側を先に可変セグメントの占有表へ入れる
  //    (宣言が正典。旧来の [id] 自動生成より優先する)。
  const claims = new Map<string, string>();
  const declared: RoutePlanEntry[] = [];
  for (const c of classified) {
    let generated = c.kind !== 'none';
    let reason = c.reason;
    let writeResource: string | undefined;

    if (generated && !enabled) {
      // kill-switch off: 旧挙動で出るファイルだけが「生成される」
      if (!legacy.has(c.file)) {
        generated = false;
        reason = REASON_KILL_SWITCH;
      }
    }

    if (generated && (c.kind === 'new' || c.kind === 'edit')) {
      const cands = writeTargetCandidates(c.route, c.kind);
      writeResource = cands.find((r) => (c.kind === 'new' ? apiFiles.has(apiRouteFile([r])) : hasItemApi(r)));
      if (!writeResource) {
        generated = false;
        reason = REASON_NO_WRITE_API;
      }
    }

    if (generated && enabled) {
      const conflict = claimDynamicSegments(c.file, claims);
      if (conflict) {
        generated = false;
        reason = REASON_SEGMENT_CONFLICT;
      }
    }

    declared.push({
      route: c.route,
      file: c.file,
      generated,
      kind: c.kind,
      reason: generated ? undefined : reason,
      writeResource: generated ? writeResource : undefined,
    });
  }

  // 4) 旧来の 4 点セット。[id] 階層が宣言側の可変セグメントと衝突するなら詳細は出さない
  const resourcePlan = resources.map((resource) => {
    if (!enabled) return { resource, detailSegment: '[id]' };
    const dir = `/${uiPageFile([resource]).split(sepOf(uiPageFile([resource]))).slice(0, -1).join('/')}`;
    const claimed = claims.get(dir);
    if (claimed && claimed !== '[id]') return { resource, detailSegment: null };
    return { resource, detailSegment: '[id]' };
  });

  return { declared, resources: resourcePlan };
}

/**
 * 宣言ルート 1 本ごとの生成計画を返す。
 *
 * 判断は buildGenerationPlan() に一本化してあり、scaffold() が実際に書き出す
 * ファイルとここが返す file は必ず一致する (突合ゲート
 * tests/route_generation_check.mjs が両者を実 scaffold で照合する)。
 */
export function routePlan(kit: KitDefinition): RoutePlanEntry[] {
  return buildGenerationPlan(kit).declared;
}

// ---------------------------------------------------------------------------
// Prisma スキーマ生成
// ---------------------------------------------------------------------------

/**
 * kit 定義の独自型 `EncryptedString` (要配慮個人情報の at-rest 暗号化必須フィールド)。
 *
 * Prisma には該当する組込み型が無いため、**保管型は String (暗号文)** にマップし、
 * 平文↔暗号文の変換はアプリケーション層 (Prisma Client Extension) が担う。
 * 対象フィールド一覧は生成物の `src/lib/crypto/encrypted-fields.ts` に SoT として出力する。
 */
export const ENCRYPTED_FIELD_TYPE = 'EncryptedString';

/** 暗号化対象フィールドを model 単位で集める。無ければ空 Map。 */
export function encryptedFieldMap(kit: KitDefinition): Map<string, string[]> {
  const map = new Map<string, string[]>();
  for (const m of kit.prisma_models) {
    const names = m.fields.filter((f) => f.type === ENCRYPTED_FIELD_TYPE).map((f) => f.name);
    if (names.length > 0) map.set(m.model, names);
  }
  return map;
}

/** 暗号化対象フィールドを 1 つでも持つ kit か。 */
export function hasEncryptedFields(kit: KitDefinition): boolean {
  return encryptedFieldMap(kit).size > 0;
}

// ---------------------------------------------------------------------------
// blind index (暗号化列に対する完全一致検索) — 2026-08-06 新設 / T-302
//
// ## なぜ必要か (2026-08-05 実測の穴)
// dispensing_pharmacy kit は Patient に familyNameIndex / kanaIndex という
// 索引列を宣言し、routes も「氏名検索は blind index 使用」と約束していたが、
// **索引値を計算する実装をどこも生成していなかった**。氏名を暗号化した瞬間に
// 氏名検索が黙って 0 件を返す (暗号文への部分一致は決して当たらない) 状態になる。
// 「検索できます」と書いてあるのに検索できない画面を出荷しないため、
// 索引の算出を生成器の責務として通電する。
//
// ## kit 定義での宣言のしかた (索引列側に書く)
//   { "name": "familyName",      "type": "EncryptedString" }
//   { "name": "familyNameIndex", "type": "String", "blind_index_of": "familyName" }
//
// ## この仕組みで【できないこと】(生成物 README にも同じ内容を出す)
//   - 部分一致・前方一致・並べ替え・範囲検索は成立しない (完全一致のみ)
//   - pepper が漏れると氏名候補の総当たり照合が可能になる
// ---------------------------------------------------------------------------

/** kit 定義 field の任意キー。kit.schema.json は field に additionalProperties を許容している。 */
type KitFieldWithBlindIndex = KitField & { blind_index_of?: string };

/** blind index 1 組 (索引列 ← 平文列)。 */
export interface BlindIndexPair {
  /** 索引列 (HMAC-SHA256 の hex を保持する列) */
  index: string;
  /** 索引の元になる平文列 */
  source: string;
  /** 元列が EncryptedString か (false = 暗号化していない列への索引 = 宣言ミスの疑い) */
  sourceEncrypted: boolean;
}

/**
 * blind index の宣言を model 単位で集める。宣言が無ければ空 Map。
 *
 * 実在しない列を指す宣言は **例外で止める**。黙って読み飛ばすと
 * 「索引列はあるが常に空 → 氏名検索が常に 0 件」という、
 * エラーを出さずに壊れている生成物がそのまま出荷されるため。
 */
export function blindIndexEnabled(): boolean {
  const v = (process.env.TEMPLATE_KIT_BLIND_INDEX ?? 'on').trim().toLowerCase();
  return !(v === 'off' || v === 'false' || v === '0' || v === 'no');
}

/** 退避弁の状態に関係なく「宣言があるか」だけを見る (無効化中の正直な開示に使う)。 */
function blindIndexDeclaredRaw(kit: KitDefinition): boolean {
  return kit.prisma_models.some((m) =>
    (m.fields as KitFieldWithBlindIndex[]).some((f) => Boolean(f.blind_index_of)),
  );
}

export function blindIndexMap(kit: KitDefinition): Map<string, BlindIndexPair[]> {
  const map = new Map<string, BlindIndexPair[]>();
  // 無効化スイッチ (既定 on)。off で 2026-08-06 以前の挙動 (索引を生成しない) へ完全復帰する。
  // ★off にすると暗号化列に対する完全一致検索が成立しなくなる。その事実は
  //   buildBlindIndexReadmeSection() が生成物 README に必ず書き出す (黙って壊さない)。
  if (!blindIndexEnabled()) return map;
  for (const m of kit.prisma_models) {
    const pairs: BlindIndexPair[] = [];
    for (const f of m.fields as KitFieldWithBlindIndex[]) {
      const source = f.blind_index_of;
      if (!source) continue;
      const src = m.fields.find((x) => x.name === source);
      if (!src) {
        throw new Error(
          `kit 定義エラー (${kit.kit_id}): ${m.model}.${f.name} の blind_index_of="${source}" が` +
            ` 同じモデルに存在しません。索引の元になる列名を修正してください。`,
        );
      }
      pairs.push({ index: f.name, source, sourceEncrypted: src.type === ENCRYPTED_FIELD_TYPE });
    }
    if (pairs.length > 0) map.set(m.model, pairs);
  }
  return map;
}

/** blind index の宣言を 1 つでも持つ kit か。 */
export function hasBlindIndex(kit: KitDefinition): boolean {
  return blindIndexMap(kit).size > 0;
}

function prismaTypeMap(field: KitField): string {
  const t = field.type;
  // EncryptedString は Prisma の組込み型ではない。保管型は String (暗号文) にマップし、
  // 暗号化・復号は生成物の Prisma Client Extension が担当する。
  if (t === ENCRYPTED_FIELD_TYPE) return 'String';
  // enum 名らしきもの (大文字始まり, "DateTime" 以外)
  if (/^[A-Z][A-Za-z0-9]*$/.test(t) && t !== 'DateTime' && t !== 'String' && t !== 'Int' && t !== 'Float' && t !== 'Decimal' && t !== 'Boolean' && t !== 'Json' && t !== 'Bytes' && t !== 'BigInt') {
    return t; // enum 参照
  }
  return t;
}

function buildPrismaModel(model: KitPrismaModel): string {
  const lines: string[] = [];
  lines.push(`model ${model.model} {`);
  for (const f of model.fields) {
    if (f.name === '@updatedAt') continue;
    if (f.description?.includes('@updatedAt')) {
      lines.push(`  ${f.name} ${prismaTypeMap(f)} @updatedAt`);
      continue;
    }
    let line = `  ${f.name} ${prismaTypeMap(f)}`;
    const opts: string[] = [];
    if (f.required === false) line += '?';
    if (f.unique) opts.push('@unique');
    if (f.name === 'id') opts.push('@id');
    // 主キーに既定値が無いと、登録のたびに ID を外から渡さないと保存できない。
    // kit 定義が既定値を宣言していない場合は生成器が cuid() を補う
    // (実測 2026-08-06: 全 114 モデル中 44 件が既定値の宣言を持たず、
    //  そのまま生成すると create() が「id が足りない」で型検査に落ちていた)。
    const supplyId = f.name === 'id' && f.default === undefined && prismaTypeMap(f) === 'String';
    if (supplyId) opts.push('@default(cuid())');
    // createdAt / updatedAt も同じ理由で補完する。システム列は画面の入力項目に出さないため、
    // 既定値が無いままだと登録処理が成立しない (実測 2026-08-06: medical / medical_overlay /
    // dispensing_pharmacy の 4 モデルが createdAt 既定値なしで create() の型検査に落ちていた)。
    const supplyCreatedAt = f.name === 'createdAt' && f.default === undefined && f.type === 'DateTime';
    if (supplyCreatedAt) opts.push('@default(now())');
    const supplyUpdatedAt = f.name === 'updatedAt' && f.default === undefined && f.type === 'DateTime';
    if (supplyUpdatedAt) opts.push('@updatedAt');
    if (f.default !== undefined) {
      const dv = String(f.default);
      if (dv === 'cuid()' || dv === 'uuid()' || dv === 'now()' || dv === 'autoincrement()') {
        opts.push(`@default(${dv})`);
      } else if (/^-?\d+(\.\d+)?$/.test(dv)) {
        opts.push(`@default(${dv})`);
      } else if (dv === 'true' || dv === 'false') {
        opts.push(`@default(${dv})`);
      } else if (/^[A-Z_]+$/.test(dv)) {
        // enum 値
        opts.push(`@default(${dv})`);
      } else {
        opts.push(`@default("${dv}")`);
      }
    }
    if (opts.length > 0) line += ' ' + opts.join(' ');
    // EncryptedString は保管型 String (暗号文) にマップ済み。復号せず読むと暗号文である事実を
    // スキーマ上に必ず残す (実装が落ちても「平文だと誤解される」ことを防ぐ)。
    const encMark = f.type === ENCRYPTED_FIELD_TYPE ? 'encrypted:true (要配慮個人情報・暗号文で保管)' : '';
    const autoMark = supplyId || supplyCreatedAt || supplyUpdatedAt
      ? 'kit 定義に既定値の宣言が無いため生成器が既定値を補完 (システム列)'
      : '';
    const doc = [encMark, autoMark, f.description].filter(Boolean).join(' / ');
    if (doc) line += ` /// ${doc}`;
    lines.push(line);
  }
  // relations は簡易ヒントのみコメント追加
  if (model.relations && model.relations.length > 0) {
    lines.push('  // relations:');
    for (const r of model.relations) {
      lines.push(`  //   ${r.type} ${r.model}` + (r.field ? ` (field: ${r.field})` : '') + (r.back ? ` (back: ${r.back})` : ''));
    }
  }
  lines.push('}');
  return lines.join('\n');
}

function buildPrismaSchema(kit: KitDefinition): string {
  const enumsCollected = new Map<string, string[]>();
  // 仮の enum 値: status 系はモデルから推測してダミー値を入れておく
  for (const m of kit.prisma_models) {
    for (const f of m.fields) {
      const t = f.type;
      if (t === ENCRYPTED_FIELD_TYPE) continue; // 暗号化フィールドは enum ではなく String (暗号文)
      if (/Status|Type|Category|Severity|Action|Outcome|Channel|Method|Priority|Mode|Rank|Source|Stage|Gender|CareLevel|Judgement|Inspection|MovementType|FeeUnit|ReceiptStatus|ApprovalAction|ReimbursementStatus|TaxCategory|StudentStatus|EnrollmentStatus|ExamType/i.test(t)
          && !['DateTime', 'String', 'Int', 'Float', 'Decimal', 'Boolean', 'Json', 'Bytes', 'BigInt'].includes(t)) {
        if (!enumsCollected.has(t)) {
          enumsCollected.set(t, defaultEnumValuesFor(t));
        }
      }
    }
  }

  const out: string[] = [];
  out.push('// Prisma schema generated by soloptilink-template-kit');
  out.push('// kit_id: ' + kit.kit_id);
  out.push('');
  out.push('generator client {');
  out.push('  provider = "prisma-client-js"');
  out.push('}');
  out.push('');
  out.push('datasource db {');
  out.push('  provider = "postgresql"');
  out.push('  url      = env("DATABASE_URL")');
  out.push('}');
  out.push('');
  for (const m of kit.prisma_models) {
    out.push(buildPrismaModel(m));
    out.push('');
  }
  for (const [name, vals] of enumsCollected.entries()) {
    out.push(`enum ${name} {`);
    for (const v of vals) out.push(`  ${v}`);
    out.push('}');
    out.push('');
  }
  return out.join('\n');
}

function defaultEnumValuesFor(name: string): string[] {
  const lname = name.toLowerCase();
  if (lname.includes('projectstatus')) return ['PLANNING', 'IN_PROGRESS', 'COMPLETED', 'ON_HOLD', 'CANCELLED'];
  if (lname.includes('estimatestatus')) return ['DRAFT', 'SENT', 'APPROVED', 'REJECTED'];
  if (lname.includes('purchaseorderstatus') || lname.includes('purchasestatus')) return ['DRAFT', 'SENT', 'CONFIRMED', 'DELIVERED', 'PAID'];
  if (lname.includes('invoicestatus')) return ['DRAFT', 'SENT', 'PAID', 'OVERDUE', 'CANCELLED', 'UNPAID'];
  if (lname.includes('salesorderstatus') || lname === 'salesorderstatus') return ['OPEN', 'IN_PRODUCTION', 'SHIPPED', 'CLOSED', 'CANCELLED'];
  if (lname.includes('productionstatus')) return ['PLANNED', 'IN_PROGRESS', 'INSPECTING', 'DONE', 'CANCELLED'];
  if (lname.includes('inspectiontype')) return ['INCOMING', 'IN_PROCESS', 'FINAL'];
  if (lname.includes('judgement')) return ['OK', 'NG', 'PENDING'];
  if (lname.includes('propertystatus')) return ['AVAILABLE', 'PENDING', 'RENTED', 'SOLD', 'CLOSED'];
  if (lname.includes('propertytype')) return ['APARTMENT', 'HOUSE', 'LAND', 'OFFICE', 'WAREHOUSE', 'SHOP', 'PARKING'];
  if (lname.includes('mediationtype')) return ['EXCLUSIVE_FULL', 'EXCLUSIVE', 'GENERAL'];
  if (lname.includes('leasetype')) return ['NORMAL', 'FIXED_TERM'];
  if (lname.includes('paymentstatus')) return ['PENDING', 'PAID', 'PARTIAL', 'OVERDUE'];
  if (lname.includes('clienttype')) return ['CORPORATION', 'INDIVIDUAL', 'SOLE_PROPRIETOR'];
  if (lname.includes('feeunit')) return ['MONTHLY', 'PER_CASE', 'HOURLY', 'ANNUAL'];
  if (lname.includes('casecategory')) return ['TAX', 'LABOR', 'ADMIN', 'LITIGATION', 'OTHER'];
  if (lname.includes('casestatus')) return ['OPEN', 'IN_PROGRESS', 'WAITING', 'CLOSED'];
  if (lname.includes('auditaction')) return ['VIEW', 'CREATE', 'UPDATE', 'DELETE', 'EXPORT'];
  if (lname.includes('gender')) return ['MALE', 'FEMALE', 'OTHER', 'UNDECLARED'];
  if (lname.includes('carelevel')) return ['SUPPORT_1', 'SUPPORT_2', 'CARE_1', 'CARE_2', 'CARE_3', 'CARE_4', 'CARE_5'];
  if (lname.includes('servicetype')) return ['VISIT_CARE', 'VISIT_NURSING', 'DAY_SERVICE', 'SHORT_STAY', 'OTHER'];
  if (lname.includes('incidentcategory')) return ['FALL', 'MEDICATION', 'CHOKING', 'INFECTION', 'OTHER'];
  if (lname.includes('incidentseverity')) return ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
  if (lname.includes('claimstatus')) return ['DRAFT', 'SUBMITTED', 'ACCEPTED', 'REJECTED', 'PAID'];
  if (lname.includes('planstatus')) return ['DRAFT', 'ACTIVE', 'EXPIRED'];
  if (lname.includes('receiptstatus')) return ['DRAFT', 'SUBMITTED', 'CONFIRMED', 'REBATED'];
  if (lname.includes('studentstatus')) return ['ACTIVE', 'PAUSED', 'WITHDRAWN', 'GRADUATED'];
  if (lname.includes('enrollmentstatus')) return ['ACTIVE', 'COMPLETED', 'CANCELLED'];
  if (lname.includes('examtype')) return ['REGULAR', 'MOCK', 'INTERNAL', 'NATIONAL'];
  if (lname.includes('accountrank')) return ['S', 'A', 'B', 'C'];
  if (lname.includes('leadsource')) return ['WEB', 'REFERRAL', 'EVENT', 'COLD_CALL', 'OTHER'];
  if (lname.includes('leadstatus')) return ['NEW', 'CONTACTED', 'QUALIFIED', 'CONVERTED', 'LOST'];
  if (lname.includes('opportunitystage')) return ['PROSPECT', 'QUALIFY', 'PROPOSAL', 'NEGOTIATE', 'CLOSE'];
  if (lname.includes('opportunityoutcome')) return ['WON', 'LOST', 'CANCELLED'];
  if (lname.includes('activitytype')) return ['VISIT', 'CALL', 'EMAIL', 'MEETING', 'OTHER'];
  if (lname.includes('taskstatus')) return ['TODO', 'IN_PROGRESS', 'DONE', 'CANCELLED'];
  if (lname.includes('priority')) return ['LOW', 'MEDIUM', 'HIGH', 'URGENT'];
  if (lname.includes('orderchannel')) return ['STORE', 'EC', 'PHONE', 'OTHER'];
  if (lname.includes('paymentmethod')) return ['CASH', 'CARD', 'BANK_TRANSFER', 'QR', 'INVOICE'];
  if (lname.includes('orderstatus')) return ['RECEIVED', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED'];
  if (lname.includes('shipmentstatus')) return ['PENDING', 'SHIPPED', 'DELIVERED', 'RETURNED'];
  if (lname.includes('movementtype')) return ['IN', 'OUT', 'ADJUSTMENT', 'WASTE'];
  if (lname.includes('customertype')) return ['INDIVIDUAL', 'CORPORATION'];
  if (lname.includes('expensestatus')) return ['DRAFT', 'PENDING', 'APPROVED', 'REJECTED', 'PAID'];
  if (lname.includes('approvalaction')) return ['APPROVE', 'REJECT', 'COMMENT', 'RETURN'];
  if (lname.includes('reimbursementstatus')) return ['SCHEDULED', 'PAID', 'FAILED'];
  if (lname.includes('taxcategory')) return ['STANDARD', 'REDUCED', 'EXEMPT', 'NONTAXABLE'];
  // フォールバック: 汎用ステータス
  return ['ACTIVE', 'INACTIVE', 'PENDING'];
}

// ---------------------------------------------------------------------------
// 各ファイルの中身ビルダー
// ---------------------------------------------------------------------------

function buildPackageJson(kit: KitDefinition): string {
  const pkg = {
    name: `${kit.kit_id}-app`,
    version: '0.1.0',
    private: true,
    scripts: {
      dev: 'next dev',
      build: 'next build',
      start: 'next start',
      lint: 'next lint',
      'db:generate': 'prisma generate',
      'db:migrate': 'prisma migrate dev',
      'db:seed': 'tsx prisma/seed.ts',
    },
    dependencies: {
      next: '15.0.0',
      react: '19.0.0',
      'react-dom': '19.0.0',
      '@prisma/client': '^5.20.0',
      'next-auth': '^5.0.0-beta.20',
      zod: '^3.23.0',
      clsx: '^2.1.0',
      'class-variance-authority': '^0.7.0',
      'lucide-react': '^0.452.0',
    },
    devDependencies: {
      typescript: '^5.6.0',
      '@types/node': '^22.7.0',
      '@types/react': '^19.0.0',
      '@types/react-dom': '^19.0.0',
      tailwindcss: '^4.0.0',
      postcss: '^8.4.0',
      autoprefixer: '^10.4.0',
      prisma: '^5.20.0',
      tsx: '^4.19.0',
      vitest: '^2.1.0',
      '@biomejs/biome': '^1.9.0',
    },
  };
  return JSON.stringify(pkg, null, 2) + '\n';
}

function buildTsconfig(): string {
  return JSON.stringify(
    {
      compilerOptions: {
        target: 'ES2022',
        lib: ['dom', 'dom.iterable', 'esnext'],
        allowJs: true,
        skipLibCheck: true,
        strict: true,
        noEmit: true,
        esModuleInterop: true,
        module: 'esnext',
        moduleResolution: 'bundler',
        resolveJsonModule: true,
        isolatedModules: true,
        jsx: 'preserve',
        incremental: true,
        plugins: [{ name: 'next' }],
        paths: { '@/*': ['./src/*'] },
      },
      include: ['next-env.d.ts', '**/*.ts', '**/*.tsx', '.next/types/**/*.ts'],
      exclude: ['node_modules'],
    },
    null,
    2,
  ) + '\n';
}

function buildNextConfig(): string {
  return `import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  reactStrictMode: true,
  experimental: {
    typedRoutes: true,
  },
};

export default nextConfig;
`;
}

function buildTailwindConfig(): string {
  return `import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './src/app/**/*.{ts,tsx}',
    './src/components/**/*.{ts,tsx}',
    './src/pages/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};

export default config;
`;
}

function buildPostcss(): string {
  return `export default {
  plugins: {
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
};
`;
}

function buildEnvExample(kit: KitDefinition): string {
  const encMap = encryptedFieldMap(kit);
  const encBlock = encMap.size === 0 ? '' : `
# FIELD ENCRYPTION (要配慮個人情報の at-rest 暗号化 / 必須)
#   対象: ${Array.from(encMap.entries()).map(([m, f]) => `${m}(${f.join(',')})`).join(' / ')}
#   鍵生成: node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
#   未設定のまま起動すると、対象フィールドの読み書きは例外で停止します (平文保存へは倒れません)。
FIELD_ENCRYPTION_KEY=""
FIELD_ENCRYPTION_KEY_ID="k1"
# 鍵ローテーション中のみ旧鍵を設定する (keyId:base64 をカンマ区切り・復号専用)
FIELD_ENCRYPTION_KEYS_OLD=""
`;
  const bixMap = blindIndexMap(kit);
  const bixBlock = bixMap.size === 0 ? '' : `
# BLIND INDEX (暗号化列の完全一致検索用 pepper / 必須)
#   対象: ${Array.from(bixMap.entries()).map(([m, ps]) => `${m}(${ps.map((p) => `${p.index}<-${p.source}`).join(',')})`).join(' / ')}
#   生成: node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
#   ★FIELD_ENCRYPTION_KEY とは別の値にすること。pepper が漏れると氏名の総当たり照合が可能になります。
#   ★成立するのは完全一致検索のみです (部分一致・前方一致・並べ替えは成立しません)。
#   ★pepper を変更した場合は索引列を全件再計算する必要があります。
FIELD_ENCRYPTION_INDEX_PEPPER=""
`;
  return `# DATABASE
DATABASE_URL="postgresql://user:password@localhost:5432/${kit.kit_id}"

# AUTH (next-auth v5)
AUTH_SECRET="change-me-in-production"
AUTH_URL="http://localhost:3000"

# STORAGE (画像/PDF添付など)
S3_BUCKET=""
S3_REGION=""
S3_ACCESS_KEY=""
S3_SECRET_KEY=""
${encBlock}${bixBlock}`;
}

function buildGitignore(): string {
  return `node_modules
.next
.env
.env.local
.DS_Store
dist
coverage
*.log
prisma/dev.db
`;
}

function buildLayout(kit: KitDefinition): string {
  return `import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: '${kit.name_ja}',
  description: '${kit.description.replace(/'/g, "\\'")}',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ja">
      <body className="min-h-screen bg-gray-50 text-gray-900 antialiased">
        <header className="border-b bg-white">
          <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between">
            <h1 className="text-lg font-bold">${kit.name_ja}</h1>
            <nav className="text-sm text-gray-600">
              <a href="/" className="px-2 hover:underline">ダッシュボード</a>
            </nav>
          </div>
        </header>
        <main className="mx-auto max-w-7xl px-4 py-6">{children}</main>
      </body>
    </html>
  );
}
`;
}

function buildGlobalsCss(): string {
  return `@import "tailwindcss";

:root {
  --foreground: 17 24 39;
  --background: 249 250 251;
}
`;
}

function buildDashboardPage(kit: KitDefinition): string {
  const kpis = kit.dashboard_kpis;
  const cards = kpis
    .map(
      (k) =>
        `        <div className="rounded-lg border bg-white p-4 shadow-sm">
          <div className="text-sm text-gray-500">${k}</div>
          <div className="mt-2 text-2xl font-bold">--</div>
        </div>`,
    )
    .join('\n');

  const resources = uniqueResources(kit.routes);
  const navLinks = resources
    .map((r) => `          <a href="/${r}" className="rounded-md border bg-white px-3 py-2 hover:bg-gray-100">${r}</a>`)
    .join('\n');

  return `export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">${kit.name_ja} ダッシュボード</h2>
        <p className="text-sm text-gray-600 mt-1">${kit.description}</p>
      </div>

      <section>
        <h3 className="text-lg font-semibold mb-3">主要KPI</h3>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
${cards}
        </div>
      </section>

      <section>
        <h3 className="text-lg font-semibold mb-3">クイックリンク</h3>
        <nav className="flex flex-wrap gap-2 text-sm">
${navLinks}
        </nav>
      </section>

      <section className="rounded-lg border bg-white p-4 shadow-sm">
        <h3 className="text-lg font-semibold mb-2">残り10%カスタマイズ</h3>
        <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
${(kit.remaining_customizations ?? []).map((c) => `          <li>${c}</li>`).join('\n')}
        </ul>
      </section>
    </div>
  );
}
`;
}

/** 使う整形関数だけを import する 1 行。 */
function formatImportsOf(specs: InputSpec[]): string {
  const names = Array.from(new Set(specs.map(formatterOf))).sort();
  return names.length > 0 ? `import { ${names.join(', ')} } from '@/lib/format';\n` : '';
}

/**
 * 一覧テーブルの JSX。列はモデルの実フィールドから作る。
 * detailResource を渡すと「詳細」リンク列を足す (詳細画面を生成した場合のみ)。
 */
function listTableJsx(columns: InputSpec[], detailResource: string | null): string {
  const colCount = columns.length + 1 + (detailResource === null ? 0 : 1);
  const heads = ['              <th className="px-3 py-2">ID</th>'];
  for (const c of columns) heads.push(`              <th className="px-3 py-2">${jsxText(c.label)}</th>`);
  if (detailResource !== null) heads.push('              <th className="px-3 py-2"></th>');

  const cells = ['                  <td className="px-3 py-2 font-mono text-xs">{item.id}</td>'];
  for (const c of columns) {
    cells.push(`                  <td className="px-3 py-2">{${formatterOf(c)}(item.${c.name})}</td>`);
  }
  if (detailResource !== null) {
    cells.push(`                  <td className="px-3 py-2">
                    <Link href={\`/${detailResource}/\${item.id}\`} className="text-blue-600 hover:underline">
                      詳細
                    </Link>
                  </td>`);
  }

  return `        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-left">
            <tr>
${heads.join('\n')}
            </tr>
          </thead>
          <tbody>
            {items.length === 0 ? (
              <tr>
                <td className="px-3 py-6 text-center text-gray-500" colSpan={${colCount}}>
                  データがありません
                </td>
              </tr>
            ) : (
              items.map((item) => (
                <tr key={item.id} className="border-t">
${cells.join('\n')}
                </tr>
              ))
            )}
          </tbody>
        </table>`;
}

/** 未解決の資源で使う「取れていないことを隠さない」空テーブル。 */
function unresolvedTableJsx(reason: string): string {
  return `        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-left">
            <tr>
              <th className="px-3 py-2">ID</th>
              <th className="px-3 py-2">コード</th>
              <th className="px-3 py-2">名称</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="px-3 py-6 text-center text-gray-500" colSpan={3}>
                この画面のデータ取得はこの版では有効になっていません。理由: ${jsxText(reason)}
              </td>
            </tr>
          </tbody>
        </table>`;
}

function buildResourceListPage(
  resource: string,
  kit: KitDefinition,
  binding: ResourceModelBinding,
  hasDetail: boolean,
): string {
  const Title = toPascalCase(resource);
  const model = binding.model;
  const heading = shortTitleOf(model?.description, resource);

  if (!model) {
    return `import Link from 'next/link';

export const dynamic = 'force-dynamic';

/**
 * ${resource} 一覧
 *
 * この画面のデータ取得は有効になっていません。
 * 理由: ${safeText(binding.reason ?? '不明')}
 */
export default function ${Title}ListPage() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">${jsxText(heading)} 一覧</h2>
      </div>
      <div className="rounded-lg border bg-white shadow-sm overflow-x-auto">
${unresolvedTableJsx(binding.reason ?? '不明')}
      </div>
      <Link href="/" className="text-blue-600 hover:underline">ダッシュボードに戻る</Link>
    </div>
  );
}
`;
  }

  const columns = listColumnsOf(kit, model);
  return `import Link from 'next/link';
import { prisma } from '@/lib/db';
${formatImportsOf(columns)}
export const dynamic = 'force-dynamic';

/**
 * ${resource} 一覧 — Prisma モデル ${model.model} から生成
 * (資源名とモデルの対応は kit 定義の prisma_models が出典)
 */
export default async function ${Title}ListPage() {
  const items = await prisma.${delegateOf(model)}.findMany({ take: 100, orderBy: ${orderByOf(model)} });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">${jsxText(heading)} 一覧</h2>
        <Link
          href="/${resource}/new"
          className="rounded-md bg-blue-600 px-3 py-1.5 text-white text-sm hover:bg-blue-700"
        >
          新規作成
        </Link>
      </div>
      <div className="rounded-lg border bg-white shadow-sm overflow-x-auto">
${listTableJsx(columns, hasDetail ? resource : null)}
      </div>
    </div>
  );
}
`;
}

/** Prisma Client のプロパティ名は先頭小文字 (model Drawing -> prisma.drawing)。 */
function lowerFirst(s: string): string {
  return s.length > 0 ? s[0].toLowerCase() + s.slice(1) : s;
}

// ===========================================================================
// 資源名 → Prisma モデルの解決 (2026-08-06 新設 / T-312)
//
// ## なぜ必要か (2026-08-06 実測)
// これ以前は資源名から `camelOf()` でモデル名を**推測**していた。実測の解決成功率は
// 132 件中 59 件 (45%) で、次の 4 家族で破綻していた:
//   - 複数形: activities -> prisma.activitie / properties -> prisma.propertie
//   - アンダースコア: dispensing_record -> prisma.dispensing_record
//   - 名前が対応しない: incidents -> IncidentReport / claims -> MonthlyClaim
//   - モデルが存在しない導線: dashboard / retention / security / phase_c
// さらに生成される CreateSchema は {code, name} 固定で、全 114 モデル中 111 件 (97%) が
// それ以外の必須項目を持つため、prisma.create() は型でも実行時でも通らなかった。
// 生成物の検査 (route_generation_check の A-3) は構文しか見ないため、この破綻は
// 緑のまま素通りし、お客様の手元でビルドが落ちていた。
//
// ## ここでの方針 — 推測をやめる
//   1. kit が `routes[].model` を宣言していれば、それが最優先 (kit 定義が明示した対応)
//   2. 資源名を正規化 (小文字英数化 + 単数形候補 + 全モデル共通の接頭辞除去) して
//      prisma_models の model 名と突き合わせる
//   3. どちらでも決まらない資源は **解決できない**として扱い、画面と API は 501 のまま
//      残し、README / 設計契約に理由付きで開示する
// 存在しない `prisma.xxx` を埋めた生成物は、この経路からは出ない。
// ===========================================================================

/**
 * kill-switch: 生成物に実際の prisma 呼び出しを埋めるか。
 * 既定 on。`TEMPLATE_KIT_PRISMA_WIRING=off` で 2026-08-06 以前の挙動
 * (取得はコメント / 書き込みは 501) に完全復帰する。
 */
export function prismaWiringEnabled(): boolean {
  return String(process.env.TEMPLATE_KIT_PRISMA_WIRING ?? 'on').trim().toLowerCase() !== 'off';
}

/** 比較用の正規化 (小文字の英数字だけにする)。"area-discrepancies" -> "areadiscrepancies" */
function normalizeName(s: string): string {
  return s.replace(/[^A-Za-z0-9]/g, '').toLowerCase();
}

/**
 * 資源名の単数形候補。英語の一般則だけを使い、**候補は必ず prisma_models と
 * 突き合わせてから採用する** (候補作りは推測だが、採用は実在確認済み)。
 */
function singularCandidates(raw: string): string[] {
  const base = normalizeName(raw);
  const out = new Set<string>([base]);
  if (/ies$/.test(base) && base.length > 4) out.add(`${base.slice(0, -3)}y`);
  if (/ses$/.test(base) && base.length > 4) out.add(`${base.slice(0, -3)}sis`);
  if (/(sh|ch|s|x|z)es$/.test(base) && base.length > 3) out.add(base.slice(0, -2));
  if (/s$/.test(base) && !/ss$/.test(base) && base.length > 2) out.add(base.slice(0, -1));
  return Array.from(out);
}

/**
 * 全モデルが共有する PascalCase の接頭辞 (例: medical_overlay の "Overlay")。
 * overlay kit はモデル名に業務名でない接頭辞が付くため、これを外した名前でも
 * 引けるようにする。共有していなければ空文字。
 */
function sharedModelPrefix(models: KitPrismaModel[]): string {
  if (models.length < 2) return '';
  const wordsOf = (m: string): string[] => m.match(/[A-Z][a-z0-9]*/g) ?? [];
  const first = wordsOf(models[0].model);
  let common = first.length;
  for (const m of models.slice(1)) {
    const w = wordsOf(m.model);
    let i = 0;
    while (i < common && i < w.length && w[i] === first[i]) i += 1;
    common = i;
  }
  const prefix = first.slice(0, common).join('');
  if (prefix.length < 3) return '';
  // 接頭辞そのものと同名のモデルがあるなら、外すと衝突するので使わない
  if (models.some((m) => m.model === prefix)) return '';
  return prefix;
}

/** 資源名 1 つに対する解決結果。model が無いものは reason に日本語の理由が入る。 */
export interface ResourceModelBinding {
  resource: string;
  model?: KitPrismaModel;
  /** declared = kit の routes[].model 宣言 / derived = 資源名とモデル名の突合 */
  source?: 'declared' | 'derived';
  /** 解決できなかった理由 (顧客提示文書へそのまま載る) */
  reason?: string;
}

const REASON_WIRING_KILL_SWITCH =
  'kill-switch TEMPLATE_KIT_PRISMA_WIRING=off により、生成物への prisma 呼び出しの埋め込みを止めています';

function reasonModelUnresolved(resource: string): string {
  return (
    `kit 定義の prisma_models に、資源名「${resource}」と対応するモデルが見つからないためです` +
    ' (モデル名を推測して、存在しない prisma 呼び出しを埋めることはしません。' +
    ` kit 定義側の routes[].model に対応するモデル名を明記すると、この導線も保存・取得が有効になります)`
  );
}

/** kit 1 つ分のモデル索引。 */
interface ModelIndex {
  /** 正規化した名前 -> モデル (prisma_models だけを出典にする) */
  byKey: Map<string, KitPrismaModel>;
  /** kit が routes[].model で明示宣言した 資源名 -> モデル */
  declared: Map<string, KitPrismaModel>;
}

/** そのルートが「自分のコレクション」として名乗る資源名 (複数可)。 */
function resourceKeysOfRoute(route: KitRoute): string[] {
  const keys: string[] = [];
  if (route.resource && !route.resource.includes('[')) keys.push(route.resource);
  const segs = segmentsOf(route.path);
  if (segs.length > 0) {
    if (segs[0] === 'api' || route.type === 'api') {
      const rest = segs.slice(segs[0] === 'api' ? 1 : 0);
      if (rest.length > 0 && !isDynamicSegment(rest[0])) keys.push(rest[0]);
    } else if (route.type !== 'dashboard') {
      keys.push(collectionOf(segs));
    }
  }
  return keys.filter((k, i) => Boolean(k) && keys.indexOf(k) === i);
}

function buildModelIndex(kit: KitDefinition): ModelIndex {
  const byKey = new Map<string, KitPrismaModel>();
  const prefix = sharedModelPrefix(kit.prisma_models);
  const add = (key: string, m: KitPrismaModel): void => {
    if (key && !byKey.has(key)) byKey.set(key, m);
  };
  for (const m of kit.prisma_models) add(normalizeName(m.model), m);
  if (prefix) {
    for (const m of kit.prisma_models) {
      if (m.model.startsWith(prefix)) add(normalizeName(m.model.slice(prefix.length)), m);
    }
  }

  const declared = new Map<string, KitPrismaModel>();
  for (const route of kit.routes) {
    const declaredModel = route.model;
    if (!declaredModel) continue;
    const m = kit.prisma_models.find((x) => x.model === declaredModel);
    if (!m) {
      throw new Error(
        `kit 定義エラー (${kit.kit_id}): ルート "${route.path}" が model "${declaredModel}" を指していますが、` +
          ' prisma_models にそのモデルがありません。モデル名の綴りを確認してください。',
      );
    }
    for (const key of resourceKeysOfRoute(route)) {
      const prev = declared.get(key);
      if (prev && prev.model !== m.model) {
        throw new Error(
          `kit 定義エラー (${kit.kit_id}): 資源「${key}」に ${prev.model} と ${m.model} の 2 つのモデルが宣言されています。` +
            ' routes[].model の宣言を 1 つに揃えてください。',
        );
      }
      declared.set(key, m);
    }
  }
  return { byKey, declared };
}

const MODEL_INDEX_CACHE = new WeakMap<KitDefinition, ModelIndex>();

function modelIndexOf(kit: KitDefinition): ModelIndex {
  let idx = MODEL_INDEX_CACHE.get(kit);
  if (idx === undefined) {
    idx = buildModelIndex(kit);
    MODEL_INDEX_CACHE.set(kit, idx);
  }
  return idx;
}

/**
 * 資源名に対応する Prisma モデルを返す。
 * 見つからないときは model を返さず、理由 (日本語) だけを返す。
 */
export function modelBindingOf(kit: KitDefinition, resource: string): ResourceModelBinding {
  if (!prismaWiringEnabled()) return { resource, reason: REASON_WIRING_KILL_SWITCH };
  const index = modelIndexOf(kit);
  const declared = index.declared.get(resource);
  if (declared) return { resource, model: declared, source: 'declared' };
  for (const key of singularCandidates(resource)) {
    const m = index.byKey.get(key);
    if (m) return { resource, model: m, source: 'derived' };
  }
  return { resource, reason: reasonModelUnresolved(resource) };
}

/**
 * 複数の資源名候補から解決する (URL のコレクション名と kit の resource 宣言は
 * 揺れているため、先に解決できた方を採る)。全部だめなら最初の理由を返す。
 */
function bindingForKeys(kit: KitDefinition, keys: (string | undefined)[]): ResourceModelBinding {
  const cands = keys.filter((k): k is string => k !== undefined && k.length > 0 && !k.includes('['));
  let first: ResourceModelBinding | null = null;
  for (const k of cands) {
    const b = modelBindingOf(kit, k);
    if (b.model) return b;
    first = first ?? b;
  }
  return first ?? { resource: '', reason: '資源名を特定できないためです' };
}

/** Prisma Client の delegate 名 (model Drawing -> prisma.drawing)。 */
function delegateOf(model: KitPrismaModel): string {
  return lowerFirst(model.model);
}

/** そのモデルが createdAt を持つか (並び順に使えるか)。 */
function hasCreatedAt(model: KitPrismaModel): boolean {
  return model.fields.some((f) => f.name === 'createdAt');
}

/** findMany の並び順。createdAt が無ければ id 昇順にする (存在しない列で並べない)。 */
function orderByOf(model: KitPrismaModel): string {
  return hasCreatedAt(model) ? "{ createdAt: 'desc' }" : "{ id: 'asc' }";
}

// ---------------------------------------------------------------------------
// モデルのフィールド → 入力項目 / 表示項目
// ---------------------------------------------------------------------------

/** 画面ラベルの既定訳 (kit 定義に description が無いフィールド用)。 */
const COMMON_LABELS_JA: Record<string, string> = {
  id: 'ID',
  code: 'コード',
  name: '名称',
  title: '件名',
  status: '状態',
  amount: '金額',
  quantity: '数量',
  unitPrice: '単価',
  note: '備考',
  memo: 'メモ',
  email: 'メールアドレス',
  phone: '電話番号',
  address: '住所',
  startDate: '開始日',
  endDate: '終了日',
  dueDate: '期限',
  createdAt: '作成日時',
  updatedAt: '更新日時',
};

type InputKind = 'text' | 'int' | 'number' | 'date' | 'datetime' | 'boolean' | 'enum' | 'json' | 'relation';

interface RelationTarget {
  model: KitPrismaModel;
  /** 選択肢の表示に使う列 (無ければ ID をそのまま出す) */
  labelField: KitField | null;
  /** 画面コンポーネントが受け取る props 名 (例: customerIdOptions) */
  prop: string;
}

interface InputSpec {
  field: KitField;
  name: string;
  label: string;
  kind: InputKind;
  /** create 時に必ず値が要るか (既定値のある列は false) */
  required: boolean;
  encrypted: boolean;
  enumValues: string[];
  relation?: RelationTarget;
}

const SYSTEM_FIELD_NAMES = new Set(['id', 'createdAt', 'updatedAt']);

function isSystemField(f: KitField): boolean {
  return SYSTEM_FIELD_NAMES.has(f.name) || (f.description?.includes('@updatedAt') ?? false);
}

/** 画面に出す日本語ラベル。kit 定義の description を先頭の一句だけ使う。 */
function labelOf(f: KitField): string {
  const raw = (f.description ?? '').trim();
  if (raw && !raw.includes('@updatedAt')) {
    const head = raw.split(/[。\n(（]/)[0].trim();
    if (head.length > 0 && head.length <= 40) return head;
  }
  return COMMON_LABELS_JA[f.name] ?? f.name;
}

/** 選択肢の表示に使える列 (先に見つかったもの)。 */
const LABEL_FIELD_ORDER = ['name', 'title', 'code', 'fullName', 'subject', 'label'];

function labelFieldOf(m: KitPrismaModel): KitField | null {
  for (const n of LABEL_FIELD_ORDER) {
    const f = m.fields.find((x) => x.name === n);
    if (f && (f.type === 'String' || f.type === ENCRYPTED_FIELD_TYPE)) return f;
  }
  return null;
}

/** その列が他モデルの ID を指しているか (指しているなら選択肢にする)。 */
function relationTargetOf(
  kit: KitDefinition,
  model: KitPrismaModel,
  f: KitField,
): KitPrismaModel | null {
  if (f.type !== 'String' || f.name === 'id' || !/Id$/.test(f.name)) return null;
  const rel = (model.relations ?? []).find((r) => r.field === f.name);
  if (rel) {
    const m = kit.prisma_models.find((x) => x.model === rel.model);
    if (m) return m;
  }
  return modelIndexOf(kit).byKey.get(normalizeName(f.name.slice(0, -2))) ?? null;
}

function inputSpecOf(kit: KitDefinition, model: KitPrismaModel, f: KitField): InputSpec {
  const base = {
    field: f,
    name: f.name,
    label: labelOf(f),
    required: f.required !== false && f.default === undefined,
    encrypted: f.type === ENCRYPTED_FIELD_TYPE,
    enumValues: [] as string[],
  };
  const t = f.type;
  if (t === 'Int' || t === 'BigInt') return { ...base, kind: 'int' };
  if (t === 'Float' || t === 'Decimal') return { ...base, kind: 'number' };
  if (t === 'Boolean') return { ...base, kind: 'boolean' };
  if (t === 'Json') return { ...base, kind: 'json' };
  if (t === 'DateTime') {
    const datetime = /At$|Time$/.test(f.name);
    return { ...base, kind: datetime ? 'datetime' : 'date' };
  }
  if (t !== 'String' && t !== ENCRYPTED_FIELD_TYPE) {
    // enum 参照。prisma スキーマに出す値と同じ一覧を使う (2 か所に持たない)
    return { ...base, kind: 'enum', enumValues: defaultEnumValuesFor(t) };
  }
  const target = relationTargetOf(kit, model, f);
  if (target) {
    // 関連 ID の見出しは、kit 定義に説明が無ければ関連先の名称を使う
    // (顧客が読む画面に customerId のような内部名を出さない)
    const label = f.description ? base.label : shortTitleOf(target.description, target.model);
    return {
      ...base,
      label,
      kind: 'relation',
      relation: { model: target, labelField: labelFieldOf(target), prop: `${f.name}Options` },
    };
  }
  return { ...base, kind: 'text' };
}

/** create / update の入力になりうる列 (システム列を除く)。 */
function inputSpecsOf(kit: KitDefinition, model: KitPrismaModel): InputSpec[] {
  return model.fields.filter((f) => !isSystemField(f)).map((f) => inputSpecOf(kit, model, f));
}

/** 入力フォームに出す列 = 「値が無いと保存できない」必須項目のみ。 */
function requiredInputSpecsOf(kit: KitDefinition, model: KitPrismaModel): InputSpec[] {
  return inputSpecsOf(kit, model).filter((s) => s.required);
}

/** 一覧の列 (先頭 5 列まで。Json は一覧に向かないので除く)。 */
function listColumnsOf(kit: KitDefinition, model: KitPrismaModel): InputSpec[] {
  return inputSpecsOf(kit, model)
    .filter((s) => s.kind !== 'json')
    .slice(0, 5);
}

/** zod の型式。 */
function zodExprOf(s: InputSpec): string {
  const opt = s.required ? '' : '.optional()';
  switch (s.kind) {
    case 'int':
      return `z.coerce.number().int()${opt}`;
    case 'number':
      return `z.coerce.number()${opt}`;
    case 'date':
    case 'datetime':
      return `z.coerce.date()${opt}`;
    case 'boolean':
      return `booleanInput${opt}`;
    case 'json':
      return `jsonInput${opt}`;
    case 'enum':
      return `z.enum([${s.enumValues.map((v) => `'${v}'`).join(', ')}])${opt}`;
    default:
      return s.required ? "z.string().min(1, '入力してください')" : 'z.string().optional()';
  }
}

/** 一覧 / 詳細で値を整形する関数名 (src/lib/format.ts)。 */
function formatterOf(s: InputSpec): string {
  switch (s.kind) {
    case 'date':
      return 'formatDate';
    case 'datetime':
      return 'formatDateTime';
    case 'int':
    case 'number':
      return 'formatNumber';
    case 'boolean':
      return 'formatBoolean';
    case 'json':
      return 'formatJson';
    default:
      return 'formatText';
  }
}

/** 編集画面の初期値を Prisma の取得結果から作る式 (文字列に揃える)。 */
function initialValueExprOf(s: InputSpec, itemVar: string): string {
  const ref = `${itemVar}.${s.name}`;
  switch (s.kind) {
    case 'date':
      return s.required ? `${ref}.toISOString().slice(0, 10)` : `${ref} === null ? '' : ${ref}.toISOString().slice(0, 10)`;
    case 'datetime':
      return s.required ? `${ref}.toISOString().slice(0, 16)` : `${ref} === null ? '' : ${ref}.toISOString().slice(0, 16)`;
    case 'json':
      return `JSON.stringify(${ref} ?? '')`;
    default:
      return s.required ? `String(${ref})` : `${ref} === null ? '' : String(${ref})`;
  }
}

/** フォーム 1 項目分の JSX。 */
function formControlOf(s: InputSpec, indent: string): string {
  const req = s.required ? ' required' : '';
  const cls = 'className="mt-1 w-full rounded-md border px-3 py-2 text-sm"';
  const dv = `defaultValue={initial?.${s.name} ?? ''}`;
  const mark = s.required ? '<span className="text-red-600" aria-hidden="true"> *</span>' : '';
  const note = s.encrypted
    ? `\n${indent}  <span className="mt-1 block text-xs text-gray-500">要配慮個人情報のため暗号化して保管します</span>`
    : '';
  let control: string;
  switch (s.kind) {
    case 'int':
      control = `<input type="number" step="1" name="${s.name}" ${dv}${req} ${cls} />`;
      break;
    case 'number':
      control = `<input type="number" step="0.01" name="${s.name}" ${dv}${req} ${cls} />`;
      break;
    case 'date':
      control = `<input type="date" name="${s.name}" ${dv}${req} ${cls} />`;
      break;
    case 'datetime':
      control = `<input type="datetime-local" name="${s.name}" ${dv}${req} ${cls} />`;
      break;
    case 'boolean':
      control = `<select name="${s.name}" defaultValue={initial?.${s.name} ?? 'false'}${req} ${cls}>
${indent}    <option value="true">はい</option>
${indent}    <option value="false">いいえ</option>
${indent}  </select>`;
      break;
    case 'enum':
      control = `<select name="${s.name}" ${dv}${req} ${cls}>
${indent}    <option value="">選択してください</option>
${s.enumValues.map((v) => `${indent}    <option value="${v}">${v}</option>`).join('\n')}
${indent}  </select>`;
      break;
    case 'relation':
      control = `<select name="${s.name}" ${dv}${req} ${cls}>
${indent}    <option value="">選択してください</option>
${indent}    {${s.relation?.prop ?? `${s.name}Options`}.map((option) => (
${indent}      <option key={option.value} value={option.value}>{option.label}</option>
${indent}    ))}
${indent}  </select>`;
      break;
    case 'json':
      control = `<textarea name="${s.name}" rows={4} ${dv}${req} ${cls} placeholder='{"key": "value"}' />`;
      break;
    default:
      control = `<input type="text" name="${s.name}" ${dv}${req} ${cls} />`;
  }
  return `${indent}<label className="block">
${indent}  <span className="text-sm font-medium">${jsxText(s.label)}${mark}</span>
${indent}  ${control}${note}
${indent}</label>`;
}

/** 詳細画面の項目行 (モデルの実フィールドから作る)。 */
function detailRowsJsx(specs: InputSpec[]): string {
  const rows = ['        <div><span className="font-semibold">ID:</span> <span className="font-mono text-xs">{item.id}</span></div>'];
  for (const s of specs) {
    rows.push(
      `        <div><span className="font-semibold">${jsxText(s.label)}:</span> {${formatterOf(s)}(item.${s.name})}</div>`,
    );
  }
  return rows.join('\n');
}

function buildResourceDetailPage(
  resource: string,
  kit: KitDefinition,
  binding: ResourceModelBinding,
): string {
  const Title = toPascalCase(resource);
  const model = binding.model;

  if (!model) {
    return `import Link from 'next/link';

export const dynamic = 'force-dynamic';

/**
 * ${resource} 詳細
 *
 * この画面のデータ取得は有効になっていません。
 * 理由: ${safeText(binding.reason ?? '不明')}
 */
export default async function ${Title}DetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">${resource} 詳細</h2>
      <p className="text-gray-600">
        この画面のデータ取得はこの版では有効になっていません (id: {id})。理由: ${jsxText(binding.reason ?? '不明')}
      </p>
      <Link href="/${resource}" className="text-blue-600 hover:underline">一覧に戻る</Link>
    </div>
  );
}
`;
  }

  const specs = inputSpecsOf(kit, model);
  const heading = shortTitleOf(model.description, resource);
  return `import Link from 'next/link';
import { notFound } from 'next/navigation';
import { prisma } from '@/lib/db';
${formatImportsOf(specs)}
export const dynamic = 'force-dynamic';

/**
 * ${resource} 詳細 — Prisma モデル ${model.model} から生成
 */
export default async function ${Title}DetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const item = await prisma.${delegateOf(model)}.findUnique({ where: { id } });

  if (item === null) {
    notFound();
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">${jsxText(heading)} 詳細</h2>
      <div className="rounded-lg border bg-white p-4 shadow-sm space-y-2 text-sm">
${detailRowsJsx(specs)}
      </div>
      <Link href="/${resource}" className="text-blue-600 hover:underline">一覧に戻る</Link>
    </div>
  );
}
`;
}

// ---------------------------------------------------------------------------
// 入力フォーム (クライアントコンポーネント) と、それを載せる画面
//
// 画面はサーバコンポーネントにして、関連 ID の選択肢や編集時の初期値を
// prisma から取ってからフォームへ渡す。フォーム側は 'use client' で送信を担う。
// ---------------------------------------------------------------------------

/** フォーム 1 つ分の生成指示。 */
interface FormBuildSpec {
  componentName: string;
  mode: 'create' | 'edit';
  model: KitPrismaModel;
  /** 送信先 /api/<apiResource> (edit は /api/<apiResource>/<id>) */
  apiResource: string;
  /** 画面に出す入力項目 */
  specs: InputSpec[];
  /** 親の可変セグメントから決まる項目 (hidden で送る) */
  fixed: { name: string; label: string }[];
}

/** 生成物のファイル 1 本 (画面の隣に置く部品)。 */
interface ExtraFile {
  /** 画面ファイルからの相対名 (例: create-form.tsx) */
  fileName: string;
  content: string;
}

const CREATE_FORM_FILE = 'create-form.tsx';
const EDIT_FORM_FILE = 'edit-form.tsx';

/** フォームが受け取る props の型定義部分。 */
function formPropsTypeOf(spec: FormBuildSpec): { members: string[]; destructure: string[] } {
  const members: string[] = [];
  const destructure: string[] = [];
  for (const s of spec.specs) {
    if (s.kind === 'relation' && s.relation) {
      members.push(`  ${s.relation.prop}: Option[];`);
      destructure.push(s.relation.prop);
    }
  }
  for (const f of spec.fixed) {
    members.push(`  ${f.name}: string;`);
    destructure.push(f.name);
  }
  if (spec.mode === 'edit') {
    members.push('  itemId: string;');
    destructure.push('itemId');
  }
  members.push('  redirectHref: string;');
  destructure.push('redirectHref');
  members.push(`  initial?: ${spec.componentName}Values;`);
  destructure.push('initial');
  return { members, destructure };
}

function buildFormComponent(spec: FormBuildSpec): string {
  const { members, destructure } = formPropsTypeOf(spec);
  const valueMembers = spec.specs.map((s) => `  ${s.name}?: string;`);
  const controls = spec.specs.map((s) => formControlOf(s, '        ')).join('\n');
  const hidden = spec.fixed
    .map((f) => `        <input type="hidden" name="${f.name}" value={${f.name}} />`)
    .join('\n');
  const endpoint =
    spec.mode === 'edit' ? `\`/api/${spec.apiResource}/\${itemId}\`` : `'/api/${spec.apiResource}'`;
  const method = spec.mode === 'edit' ? 'PUT' : 'POST';
  const actionLabel = spec.mode === 'edit' ? '更新' : '保存';
  const optionType = spec.specs.some((s) => s.kind === 'relation')
    ? "export interface Option {\n  value: string;\n  label: string;\n}\n\n"
    : '';

  return `'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

${optionType}/** ${spec.model.model} の入力値 (すべて文字列。変換は API 側の zod が行う) */
export interface ${spec.componentName}Values {
${valueMembers.length > 0 ? valueMembers.join('\n') : '  [key: string]: string | undefined;'}
}

/** API が返した日本語のメッセージがあればそれを出し、無ければ状況に応じた文言を出す。 */
function messageOf(detail: unknown, status: number): string {
  if (detail !== null && typeof detail === 'object' && 'message' in detail) {
    const message = (detail as { message?: unknown }).message;
    if (typeof message === 'string' && message.length > 0) return message;
  }
  if (status === 400) return '入力内容に誤りがあります。項目をご確認のうえ、もう一度お試しください。';
  if (status === 404) return '対象のデータが見つかりませんでした。一覧に戻って再度お試しください。';
  if (status === 409) return 'すでに同じ内容が登録されています。重複しない値を入力してください。';
  return '${actionLabel}できませんでした。時間をおいて、もう一度お試しください。';
}

export function ${spec.componentName}({
${destructure.map((d) => `  ${d},`).join('\n')}
}: {
${members.join('\n')}
}) {
  const router = useRouter();
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    setSubmitting(true);
    setErrorMessage(null);

    const payload: Record<string, string> = {};
    for (const [key, value] of new FormData(form).entries()) {
      payload[key] = String(value);
    }

    const res = await fetch(${endpoint}, {
      method: '${method}',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
    }).catch(() => null);
    setSubmitting(false);

    if (res === null) {
      setErrorMessage('サーバーに接続できませんでした。通信状況をご確認のうえ、もう一度お試しください。');
      return;
    }
    if (res.ok) {
      router.push(redirectHref);
      router.refresh();
      return;
    }
    const detail: unknown = await res.json().catch(() => null);
    setErrorMessage(messageOf(detail, res.status));
  }

  return (
    <form onSubmit={onSubmit} className="space-y-3 rounded-lg border bg-white p-4 shadow-sm">
      {errorMessage !== null ? (
        <p role="alert" className="rounded-md border border-red-300 bg-red-50 px-3 py-2 text-sm text-red-700">
          {errorMessage}
        </p>
      ) : null}
${hidden.length > 0 ? `${hidden}\n` : ''}${controls}
      <button
        type="submit"
        disabled={submitting}
        className="rounded-md bg-blue-600 px-4 py-2 text-sm text-white hover:bg-blue-700 disabled:opacity-50"
      >
        {submitting ? '送信中…' : '${actionLabel}'}
      </button>
    </form>
  );
}
`;
}

/** 関連 ID の選択肢を prisma から取る行 (サーバコンポーネント側)。 */
function relationOptionLines(specs: InputSpec[]): { lines: string[]; props: string[] } {
  const lines: string[] = [];
  const props: string[] = [];
  for (const s of specs) {
    if (s.kind !== 'relation' || !s.relation) continue;
    const target = s.relation.model;
    const lf = s.relation.labelField;
    let label: string;
    if (lf === null) label = 'row.id';
    else if (lf.required === false) label = `row.${lf.name} === null ? row.id : String(row.${lf.name})`;
    else label = `String(row.${lf.name})`;
    lines.push(
      `  const ${s.relation.prop} = (await prisma.${delegateOf(target)}.findMany({ take: 200, orderBy: ${orderByOf(target)} }))` +
        `\n    .map((row) => ({ value: row.id, label: ${label} }));`,
    );
    props.push(s.relation.prop);
  }
  return { lines, props };
}

/**
 * 資源の新規作成画面。
 * モデルが解決できた資源では、必須項目の入力フォームを生成して実際に保存する。
 * 解決できない資源では保存先 API が 501 を返すため、画面も理由を日本語で表示する。
 */
function buildResourceNewPage(
  resource: string,
  kit: KitDefinition,
  binding: ResourceModelBinding,
): { page: string; extra: ExtraFile | null } {
  const Title = toPascalCase(resource);
  const model = binding.model;

  if (!model) {
    return {
      page: `import Link from 'next/link';

/**
 * ${resource} 新規作成
 *
 * 保存先 /api/${resource} は登録処理を有効にしていないため 501 を返す。
 * 押しても保存できない入力欄を並べず、理由をそのまま日本語で表示する。
 * 理由: ${safeText(binding.reason ?? '不明')}
 */
export default function ${Title}NewPage() {
  return (
    <div className="space-y-4 max-w-xl">
      <h2 className="text-xl font-bold">${resource} 新規作成</h2>
      <p role="alert" className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-800">
        この画面の登録処理はこの版では有効になっていません。理由: ${jsxText(binding.reason ?? '不明')}
      </p>
      <Link href="/${resource}" className="text-blue-600 hover:underline">一覧に戻る</Link>
    </div>
  );
}
`,
      extra: null,
    };
  }

  const specs = requiredInputSpecsOf(kit, model);
  const componentName = `${Title}CreateForm`;
  const { lines, props } = relationOptionLines(specs);
  const heading = shortTitleOf(model.description, resource);
  const needsPrisma = lines.length > 0;

  const page = `import Link from 'next/link';
${needsPrisma ? "import { prisma } from '@/lib/db';\n" : ''}import { ${componentName} } from './${CREATE_FORM_FILE.replace(/\.tsx$/, '')}';

export const dynamic = 'force-dynamic';

/**
 * ${resource} 新規作成 — Prisma モデル ${model.model} の必須項目から生成
 */
export default async function ${Title}NewPage() {
${lines.join('\n')}${lines.length > 0 ? '\n' : ''}
  return (
    <div className="space-y-4 max-w-2xl">
      <h2 className="text-xl font-bold">${jsxText(heading)} 新規作成</h2>
      <${componentName}${props.map((p) => ` ${p}={${p}}`).join('')} redirectHref="/${resource}" />
      <Link href="/${resource}" className="text-blue-600 hover:underline">一覧に戻る</Link>
    </div>
  );
}
`;

  return {
    page,
    extra: {
      fileName: CREATE_FORM_FILE,
      content: buildFormComponent({
        componentName,
        mode: 'create',
        model,
        apiResource: resource,
        specs,
        fixed: [],
      }),
    },
  };
}

/**
 * コレクション API (/api/<resource>)。
 * 取得はコメントを外せば動く形、登録は未実装のあいだ 501 を返す。
 * 固定値を返して「保存したふり」をしないことがこのファイルの契約
 * (単体 API buildApiItemRoute と同じ方針。2026-08-06 / T-301 追補で統一)。
 */
/** prisma へ渡す data リテラル (キーを明示するので、型検査が過不足を捕まえる)。 */
function dataLiteralLines(specs: InputSpec[], src: string, indent: string): string {
  return specs.map((s) => `${indent}${s.name}: ${src}.${s.name},`).join('\n');
}

function buildApiRoute(resource: string, kit: KitDefinition, binding: ResourceModelBinding): string {
  const model = binding.model;
  if (!model) {
    return `import { NextResponse } from 'next/server';

/**
 * /api/${resource}
 *
 * この API はデータの読み書きを有効にしていない。
 * 理由: ${safeText(binding.reason ?? '不明')}
 * 固定値を返して「保存したふり」「取得できたふり」はしない。
 */
export async function GET() {
  return NextResponse.json({
    items: [],
    measured: false,
    message: 'この一覧の取得処理はこの版では有効になっていません。未取得を 0 件と混同しないよう measured=false を返します。',
    reason: ${jsString(binding.reason ?? '不明')},
  });
}

export async function POST() {
  return NextResponse.json(
    {
      message: 'この登録処理はこの版では有効になっていません。',
      reason: ${jsString(binding.reason ?? '不明')},
    },
    { status: 501 },
  );
}
`;
  }

  const specs = inputSpecsOf(kit, model);
  const delegate = delegateOf(model);
  return `import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { apiErrorOf } from '@/lib/api-error';
import { ${model.model}CreateSchema } from '@/lib/validators';

export const dynamic = 'force-dynamic';

/**
 * /api/${resource} — Prisma モデル ${model.model}
 * 入力の検証は ${model.model}CreateSchema (kit 定義の必須項目から生成) が行う。
 */
export async function GET() {
  try {
    const items = await prisma.${delegate}.findMany({ take: 100, orderBy: ${orderByOf(model)} });
    // 実際に取得しているので measured=true (未取得を 0 件と取り違えないための印)
    return NextResponse.json({ items, measured: true });
  } catch (error) {
    const failure = apiErrorOf(error, '取得');
    return NextResponse.json(failure.body, { status: failure.status });
  }
}

export async function POST(req: Request) {
  const body: unknown = await req.json().catch(() => null);
  const parsed = ${model.model}CreateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { message: '入力内容に誤りがあります。項目をご確認ください。', errors: parsed.error.flatten().fieldErrors },
      { status: 400 },
    );
  }
  try {
    const created = await prisma.${delegate}.create({
      data: {
${dataLiteralLines(specs, 'parsed.data', '        ')}
      },
    });
    return NextResponse.json({ item: created }, { status: 201 });
  } catch (error) {
    const failure = apiErrorOf(error, '登録');
    return NextResponse.json(failure.body, { status: failure.status });
  }
}
`;
}

// ---------------------------------------------------------------------------
// 宣言ルート由来の画面 / API ビルダー (2026-08-06 新設 / T-301)
//
// 共通方針: 中身を偽らない。取得できていないものは空状態として表示し、
// 実装していない書き込みは 501 を返す。固定値で「できているふり」をしない。
// ---------------------------------------------------------------------------

/** 宣言ルートのパスから React コンポーネント名を作る。 */
function componentNameOf(segs: string[], suffix: string): string {
  const base = segs
    .map((s) => (isDynamicSegment(s) ? s.slice(1, -1) : s))
    .map((s) => toPascalCase(s))
    .join('');
  return `${base || 'Root'}${suffix}`;
}

/** パスに含まれる可変セグメント名 (例 /patients/[id]/consents/[consentId] -> ['id','consentId'])。 */
function dynamicParamsOf(segs: string[]): string[] {
  return segs.filter(isDynamicSegment).map((s) => s.slice(1, -1));
}

/** 一覧 / 詳細のデータ源になるコレクション名 (末尾の静的セグメント)。 */
function collectionOf(segs: string[]): string {
  for (let i = segs.length - 1; i >= 0; i -= 1) {
    if (!isDynamicSegment(segs[i]) && segs[i] !== 'new' && segs[i] !== 'edit') return segs[i];
  }
  return segs[0] ?? 'items';
}

/** 生成物のコード内に日本語をそのまま置くための素朴なエスケープ (改行と記号のみ)。 */
function safeText(s: string): string {
  return String(s ?? '').replace(/\r?\n/g, ' ').replace(/\*\//g, '* /');
}

/**
 * JSX の本文として置くテキストのエスケープ (2026-08-06 / T-312)。
 *
 * kit 定義の説明文には `{draft, finalized, exported}` のような波括弧や不等号が入る。
 * これを素通しすると JSX が「式」と解釈して、存在しない変数を参照する生成物になる
 * (実測: 型検査ゲート新設時に medical / medical_overlay / dispensing_pharmacy の
 *  3 kit で計 30 件以上の未定義変数エラーとして表面化した)。
 */
function jsxText(s: string): string {
  return safeText(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\{/g, '&#123;')
    .replace(/\}/g, '&#125;');
}

/** 生成コードの文字列リテラルとして安全に埋め込む (引用符・改行を含んでも壊れない)。 */
function jsString(s: string): string {
  return JSON.stringify(String(s ?? ''));
}

/**
 * 見出しに使う短い日本語。kit 定義の説明文は段落まるごとのことがあるため、
 * 先頭の一句だけを使い、長すぎる場合は資源名にフォールバックする。
 */
function shortTitleOf(text: string | undefined, fallback: string): string {
  const raw = (text ?? '').trim();
  if (raw.length === 0) return fallback;
  const head = raw.split(/[。\n(（]/)[0].trim();
  if (head.length === 0 || head.length > 30) return fallback;
  return head;
}

/** 親の可変セグメントから決まる絞り込み条件 (例: /patients/[id]/consents -> patientId)。 */
interface ParentBinding {
  param: string;
  field: string;
  label: string;
}

function parentBindingsOf(
  kit: KitDefinition,
  model: KitPrismaModel,
  segs: string[],
  ownParam: string | null,
): ParentBinding[] {
  const out: ParentBinding[] = [];
  for (let i = 0; i < segs.length; i += 1) {
    if (!isDynamicSegment(segs[i])) continue;
    const param = segs[i].slice(1, -1);
    if (param === ownParam) continue;
    const parent = segs[i - 1];
    if (!parent || isDynamicSegment(parent)) continue;
    const parentModel = modelBindingOf(kit, parent).model;
    if (!parentModel) continue;
    const fieldName = `${lowerFirst(parentModel.model)}Id`;
    const f = model.fields.find((x) => x.name === fieldName);
    if (!f) continue;
    out.push({ param, field: fieldName, label: labelOf(f) });
  }
  return out;
}

/** Next.js 15 の params (Promise) を受け取るサーバコンポーネントの雛形。 */
function buildDeclaredListPage(
  route: KitRoute,
  kind: RoutePlanKind,
  kit: KitDefinition,
  binding: ResourceModelBinding,
): string {
  const segs = segmentsOf(route.path);
  const params = dynamicParamsOf(segs);
  const name = componentNameOf(segs, 'Page');
  const collection = collectionOf(segs);
  const backHref = `/${segs[0]}`;
  const model = binding.model;
  const title = shortTitleOf(model?.description, collection);
  const heading = kind === 'report' ? `${title} 帳票` : `${title} 一覧`;
  const sig = params.length > 0
    ? `{ params }: { params: Promise<{ ${params.map((p) => `${p}: string`).join('; ')} }> }`
    : '';
  const awaitLine = params.length > 0
    ? `  const { ${params.join(', ')} } = await params;\n`
    : '';
  const contextRow = params.length > 0
    ? `      <p className="text-sm text-gray-600">対象: ${params.map((p) => `${p}=`).join('')}{${params.join(' + \'/\' + ')}}</p>\n`
    : '';

  if (!model) {
    return `import Link from 'next/link';

export const dynamic = 'force-dynamic';

/**
 * ${safeText(route.path)} — ${safeText(route.purpose)}
 *
 * この画面のデータ取得は有効になっていません。
 * 理由: ${safeText(binding.reason ?? '不明')}
 */
export default async function ${name}(${sig}) {
${awaitLine}  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold">${jsxText(heading)}</h2>
        <p className="text-sm text-gray-600 mt-1">${jsxText(route.purpose)}</p>
      </div>
${contextRow}      <div className="rounded-lg border bg-white shadow-sm overflow-x-auto">
${unresolvedTableJsx(binding.reason ?? '不明')}
      </div>
      <Link href="${backHref}" className="text-blue-600 hover:underline">一覧に戻る</Link>
    </div>
  );
}
`;
  }

  const columns = listColumnsOf(kit, model);
  const parents = parentBindingsOf(kit, model, segs, null);
  const where = parents.length > 0
    ? `where: { ${parents.map((p) => `${p.field}: ${p.param}`).join(', ')} }, `
    : '';

  return `import Link from 'next/link';
import { prisma } from '@/lib/db';
${formatImportsOf(columns)}
export const dynamic = 'force-dynamic';

/**
 * ${safeText(route.path)} — ${safeText(route.purpose)}
 * Prisma モデル ${model.model} から生成
 */
export default async function ${name}(${sig}) {
${awaitLine}  const items = await prisma.${delegateOf(model)}.findMany({ ${where}take: 100, orderBy: ${orderByOf(model)} });

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold">${jsxText(heading)}</h2>
        <p className="text-sm text-gray-600 mt-1">${jsxText(route.purpose)}</p>
      </div>
${contextRow}      <div className="rounded-lg border bg-white shadow-sm overflow-x-auto">
${listTableJsx(columns, null)}
      </div>
      <Link href="${backHref}" className="text-blue-600 hover:underline">一覧に戻る</Link>
    </div>
  );
}
`;
}

/** 宣言された詳細画面 (ネストを含む)。 */
function buildDeclaredDetailPage(
  route: KitRoute,
  kit: KitDefinition,
  binding: ResourceModelBinding,
): string {
  const segs = segmentsOf(route.path);
  const params = dynamicParamsOf(segs);
  const name = componentNameOf(segs, 'Page');
  const collection = collectionOf(segs);
  const backHref = `/${segs[0]}`;
  const model = binding.model;
  const heading = `${shortTitleOf(model?.description, collection)} 詳細`;
  const sig = params.length > 0
    ? `{ params }: { params: Promise<{ ${params.map((p) => `${p}: string`).join('; ')} }> }`
    : '';
  const awaitLine = params.length > 0
    ? `  const { ${params.join(', ')} } = await params;\n`
    : '';

  // 対象を特定する可変セグメントが無い詳細画面は、どのデータを表示するのか決まらない
  const ownParam = params.length > 0 ? params[params.length - 1] : null;
  const reason = model !== undefined && ownParam === null
    ? 'この画面のパスに対象を特定する可変セグメント ([id] など) が無く、どのデータを表示するのか決まらないためです'
    : (binding.reason ?? '不明');

  if (!model || ownParam === null) {
    const paramRows = params
      .map((p) => `        <div><span className="font-semibold">${p}:</span> {${p}}</div>`)
      .join('\n');
    return `import Link from 'next/link';

export const dynamic = 'force-dynamic';

/**
 * ${safeText(route.path)} — ${safeText(route.purpose)}
 *
 * この画面のデータ取得は有効になっていません。
 * 理由: ${safeText(reason)}
 */
export default async function ${name}(${sig}) {
${awaitLine}  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold">${jsxText(heading)}</h2>
        <p className="text-sm text-gray-600 mt-1">${jsxText(route.purpose)}</p>
      </div>
      <div className="rounded-lg border bg-white p-4 shadow-sm space-y-2 text-sm">
${paramRows}
        <p className="text-gray-500">
          この画面のデータ取得はこの版では有効になっていません。理由: ${jsxText(reason)}
        </p>
      </div>
      <Link href="${backHref}" className="text-blue-600 hover:underline">一覧に戻る</Link>
    </div>
  );
}
`;
  }

  const specs = inputSpecsOf(kit, model);
  return `import Link from 'next/link';
import { notFound } from 'next/navigation';
import { prisma } from '@/lib/db';
${formatImportsOf(specs)}
export const dynamic = 'force-dynamic';

/**
 * ${safeText(route.path)} — ${safeText(route.purpose)}
 * Prisma モデル ${model.model} から生成
 */
export default async function ${name}(${sig}) {
${awaitLine}  const item = await prisma.${delegateOf(model)}.findUnique({ where: { id: ${ownParam} } });

  if (item === null) {
    notFound();
  }

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold">${jsxText(heading)}</h2>
        <p className="text-sm text-gray-600 mt-1">${jsxText(route.purpose)}</p>
      </div>
      <div className="rounded-lg border bg-white p-4 shadow-sm space-y-2 text-sm">
${detailRowsJsx(specs)}
      </div>
      <Link href="${backHref}" className="text-blue-600 hover:underline">一覧に戻る</Link>
    </div>
  );
}
`;
}

/** JSX 属性として渡す遷移先 (可変セグメントがあればテンプレートリテラルにする)。 */
function hrefAttrOf(segs: string[]): string {
  const hasParam = segs.some(isDynamicSegment);
  const path = segs
    .map((s) => (isDynamicSegment(s) ? `\${${s.slice(1, -1)}}` : s))
    .join('/');
  return hasParam ? `{\`/${path}\`}` : `"/${path}"`;
}

/** 宣言された新規作成画面 (ネストを含む)。保存先 API が生成される場合のみ呼ばれる。 */
function buildDeclaredNewPage(
  route: KitRoute,
  apiResource: string,
  kit: KitDefinition,
  binding: ResourceModelBinding,
): { page: string; extra: ExtraFile | null } {
  const segs = segmentsOf(route.path);
  const params = dynamicParamsOf(segs);
  const name = componentNameOf(segs, 'Page');
  const backHref = `/${segs[0]}`;
  const model = binding.model;
  const sig = params.length > 0
    ? `{ params }: { params: Promise<{ ${params.map((p) => `${p}: string`).join('; ')} }> }`
    : '';
  const awaitLine = params.length > 0
    ? `  const { ${params.join(', ')} } = await params;\n`
    : '';

  if (!model) {
    return {
      page: `import Link from 'next/link';

/**
 * ${safeText(route.path)} — ${safeText(route.purpose)}
 *
 * 保存先 /api/${apiResource} は登録処理を有効にしていないため 501 を返す。
 * 押しても保存できない入力欄を並べず、理由をそのまま日本語で表示する。
 * 理由: ${safeText(binding.reason ?? '不明')}
 */
export default async function ${name}(${sig}) {
${awaitLine}  return (
    <div className="space-y-4 max-w-xl">
      <h2 className="text-xl font-bold">新規作成</h2>
      <p className="text-sm text-gray-600">${jsxText(route.purpose)}</p>
      <p role="alert" className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-800">
        この画面の登録処理はこの版では有効になっていません。理由: ${jsxText(binding.reason ?? '不明')}
      </p>
      <Link href="${backHref}" className="text-blue-600 hover:underline">一覧に戻る</Link>
    </div>
  );
}
`,
      extra: null,
    };
  }

  const parents = parentBindingsOf(kit, model, segs, null);
  const fixedNames = new Set(parents.map((p) => p.field));
  const specs = requiredInputSpecsOf(kit, model).filter((s) => !fixedNames.has(s.name));
  const componentName = componentNameOf(segs, 'Form');
  const { lines, props } = relationOptionLines(specs);
  const needsPrisma = lines.length > 0;
  const fixedAttrs = parents.map((p) => ` ${p.field}={${p.param}}`).join('');
  const redirectAttr = hrefAttrOf(segs.slice(0, -1));

  const page = `import Link from 'next/link';
${needsPrisma ? "import { prisma } from '@/lib/db';\n" : ''}import { ${componentName} } from './${CREATE_FORM_FILE.replace(/\.tsx$/, '')}';

export const dynamic = 'force-dynamic';

/**
 * ${safeText(route.path)} — ${safeText(route.purpose)}
 * Prisma モデル ${model.model} の必須項目から生成
 */
export default async function ${name}(${sig}) {
${awaitLine}${lines.join('\n')}${lines.length > 0 ? '\n' : ''}
  return (
    <div className="space-y-4 max-w-2xl">
      <h2 className="text-xl font-bold">新規作成</h2>
      <p className="text-sm text-gray-600">${jsxText(route.purpose)}</p>
      <${componentName}${props.map((p) => ` ${p}={${p}}`).join('')}${fixedAttrs} redirectHref=${redirectAttr} />
      <Link href="${backHref}" className="text-blue-600 hover:underline">一覧に戻る</Link>
    </div>
  );
}
`;

  return {
    page,
    extra: {
      fileName: CREATE_FORM_FILE,
      content: buildFormComponent({
        componentName,
        mode: 'create',
        model,
        apiResource,
        specs,
        fixed: parents.map((p) => ({ name: p.field, label: p.label })),
      }),
    },
  };
}

/** 宣言された編集画面。更新先の単体 API が生成される場合のみ呼ばれる。 */
function buildDeclaredEditPage(
  route: KitRoute,
  apiResource: string,
  kit: KitDefinition,
  binding: ResourceModelBinding,
): { page: string; extra: ExtraFile | null } {
  const segs = segmentsOf(route.path);
  const params = dynamicParamsOf(segs);
  const name = componentNameOf(segs, 'Page');
  const backHref = `/${segs[0]}`;
  const model = binding.model;
  const sig = params.length > 0
    ? `{ params }: { params: Promise<{ ${params.map((p) => `${p}: string`).join('; ')} }> }`
    : '';
  const awaitLine = params.length > 0
    ? `  const { ${params.join(', ')} } = await params;\n`
    : '';

  // 対象を特定する可変セグメントが無い編集画面は、どのデータを更新するのか決まらない
  const ownParam = params.length > 0 ? params[params.length - 1] : null;
  const reason = model
    ? 'この画面のパスに対象を特定する可変セグメント ([id] など) が無く、どのデータを更新するのか決まらないためです'
    : (binding.reason ?? '不明');

  if (!model || ownParam === null) {
    return {
      page: `import Link from 'next/link';

/**
 * ${safeText(route.path)} — ${safeText(route.purpose)}
 *
 * 更新処理を有効にしていない画面。押しても保存できない入力欄は並べない。
 * 理由: ${safeText(reason)}
 */
export default async function ${name}(${sig}) {
${awaitLine}  return (
    <div className="space-y-4 max-w-xl">
      <h2 className="text-xl font-bold">編集</h2>
      <p className="text-sm text-gray-600">${jsxText(route.purpose)}</p>
      <p role="alert" className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-800">
        この画面の更新処理はこの版では有効になっていません。理由: ${jsxText(reason)}
      </p>
      <Link href="${backHref}" className="text-blue-600 hover:underline">一覧に戻る</Link>
    </div>
  );
}
`,
      extra: null,
    };
  }

  const parents = parentBindingsOf(kit, model, segs, ownParam);
  const fixedNames = new Set(parents.map((p) => p.field));
  const specs = requiredInputSpecsOf(kit, model).filter((s) => !fixedNames.has(s.name));
  const componentName = componentNameOf(segs, 'Form');
  const { lines, props } = relationOptionLines(specs);
  const fixedAttrs = parents.map((p) => ` ${p.field}={${p.param}}`).join('');
  const initialLines = specs
    .map((s) => `    ${s.name}: ${initialValueExprOf(s, 'item')},`)
    .join('\n');

  const page = `import Link from 'next/link';
import { notFound } from 'next/navigation';
import { prisma } from '@/lib/db';
import { ${componentName} } from './${EDIT_FORM_FILE.replace(/\.tsx$/, '')}';

export const dynamic = 'force-dynamic';

/**
 * ${safeText(route.path)} — ${safeText(route.purpose)}
 * Prisma モデル ${model.model} から生成 (初期値は取得結果、更新先は /api/${apiResource}/[${ownParam}])
 */
export default async function ${name}(${sig}) {
${awaitLine}  const item = await prisma.${delegateOf(model)}.findUnique({ where: { id: ${ownParam} } });

  if (item === null) {
    notFound();
  }

  const initial = {
${initialLines}
  };
${lines.length > 0 ? `${lines.join('\n')}\n` : ''}
  return (
    <div className="space-y-4 max-w-2xl">
      <h2 className="text-xl font-bold">編集</h2>
      <p className="text-sm text-gray-600">${jsxText(route.purpose)}</p>
      <${componentName}${props.map((p) => ` ${p}={${p}}`).join('')}${fixedAttrs} itemId={${ownParam}} initial={initial} redirectHref="${backHref}" />
      <Link href="${backHref}" className="text-blue-600 hover:underline">一覧に戻る</Link>
    </div>
  );
}
`;

  return {
    page,
    extra: {
      fileName: EDIT_FORM_FILE,
      content: buildFormComponent({
        componentName,
        mode: 'edit',
        model,
        apiResource,
        specs,
        fixed: parents.map((p) => ({ name: p.field, label: p.label })),
      }),
    },
  };
}

/**
 * 単体リソース API (/api/<resource>/[id])。
 * 取得はコメントを外せば動く形、更新 / 削除は未実装のあいだ 501 を返す。
 * 固定値を返して「保存したふり」をしないことがこのファイルの契約。
 */
function buildApiItemRoute(
  resource: string,
  param: string,
  kit: KitDefinition,
  binding: ResourceModelBinding,
): string {
  const model = binding.model;
  if (!model) {
    return `import { NextResponse } from 'next/server';

type RouteContext = { params: Promise<{ ${param}: string }> };

/**
 * /api/${resource}/[${param}]
 *
 * この API はデータの読み書きを有効にしていない。
 * 理由: ${safeText(binding.reason ?? '不明')}
 */
export async function GET(_req: Request, ctx: RouteContext) {
  const { ${param} } = await ctx.params;
  return NextResponse.json(
    {
      message: 'この取得処理はこの版では有効になっていません。',
      reason: ${jsString(binding.reason ?? '不明')},
      ${param},
    },
    { status: 501 },
  );
}

export async function PUT(_req: Request, ctx: RouteContext) {
  const { ${param} } = await ctx.params;
  return NextResponse.json(
    {
      message: 'この更新処理はこの版では有効になっていません。',
      reason: ${jsString(binding.reason ?? '不明')},
      ${param},
    },
    { status: 501 },
  );
}

export async function DELETE(_req: Request, ctx: RouteContext) {
  const { ${param} } = await ctx.params;
  return NextResponse.json(
    {
      message: 'この削除処理はこの版では有効になっていません。',
      reason: ${jsString(binding.reason ?? '不明')},
      ${param},
    },
    { status: 501 },
  );
}
`;
  }

  const specs = inputSpecsOf(kit, model);
  const delegate = delegateOf(model);
  return `import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { apiErrorOf } from '@/lib/api-error';
import { ${model.model}UpdateSchema } from '@/lib/validators';

export const dynamic = 'force-dynamic';

type RouteContext = { params: Promise<{ ${param}: string }> };

/**
 * /api/${resource}/[${param}] — Prisma モデル ${model.model}
 */
export async function GET(_req: Request, ctx: RouteContext) {
  const { ${param} } = await ctx.params;
  try {
    const item = await prisma.${delegate}.findUnique({ where: { id: ${param} } });
    if (item === null) {
      return NextResponse.json({ message: '対象のデータが見つかりませんでした。' }, { status: 404 });
    }
    return NextResponse.json({ item });
  } catch (error) {
    const failure = apiErrorOf(error, '取得');
    return NextResponse.json(failure.body, { status: failure.status });
  }
}

export async function PUT(req: Request, ctx: RouteContext) {
  const { ${param} } = await ctx.params;
  const body: unknown = await req.json().catch(() => null);
  const parsed = ${model.model}UpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { message: '入力内容に誤りがあります。項目をご確認ください。', errors: parsed.error.flatten().fieldErrors },
      { status: 400 },
    );
  }
  try {
    const updated = await prisma.${delegate}.update({
      where: { id: ${param} },
      data: {
${dataLiteralLines(specs, 'parsed.data', '        ')}
      },
    });
    return NextResponse.json({ item: updated });
  } catch (error) {
    const failure = apiErrorOf(error, '更新');
    return NextResponse.json(failure.body, { status: failure.status });
  }
}

export async function DELETE(_req: Request, ctx: RouteContext) {
  const { ${param} } = await ctx.params;
  try {
    const deleted = await prisma.${delegate}.delete({ where: { id: ${param} } });
    return NextResponse.json({ item: deleted });
  } catch (error) {
    const failure = apiErrorOf(error, '削除');
    return NextResponse.json(failure.body, { status: failure.status });
  }
}
`;
}

/**
 * ダッシュボード KPI 参照 API (/api/dashboard/kpi)。
 * 集計クエリは業種ごとに異なるためこの版では実装しない。0 で埋めると
 * 「集計できていて 0 件」と誤読されるため、未集計は null で返し measured=false を明示する。
 */
function buildDashboardKpiRoute(kit: KitDefinition): string {
  const labels = kit.dashboard_kpis.map((k) => JSON.stringify(k)).join(', ');
  const counted = prismaWiringEnabled() ? kit.prisma_models.slice(0, 10) : [];
  if (counted.length === 0) {
    return `import { NextResponse } from 'next/server';

/** kit 定義に宣言された KPI の見出し。値の集計はこの版では未実装。 */
const DECLARED_KPIS: string[] = [${labels}];

export async function GET() {
  return NextResponse.json({
    generated_at: new Date().toISOString(),
    measured: false,
    note: 'KPI の集計クエリはこの版では未実装です。未集計を 0 と混同しないよう value は null を返します。',
    kpis: DECLARED_KPIS.map((label) => ({ label, value: null })),
  });
}
`;
  }
  const countLines = counted
    .map((m) => `      { model: '${m.model}', count: await prisma.${delegateOf(m)}.count() },`)
    .join('\n');
  return `import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { apiErrorOf } from '@/lib/api-error';

/** kit 定義に宣言された KPI の見出し。集計式は業種ごとに異なるためこの版では未実装。 */
const DECLARED_KPIS: string[] = [${labels}];

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    // 件数は実際に数える (ここは measured=true)
    const record_counts = [
${countLines}
    ];
    return NextResponse.json({
      generated_at: new Date().toISOString(),
      record_counts,
      // 宣言された KPI の集計式はこの版では未実装。0 と混同しないよう value は null。
      kpis: DECLARED_KPIS.map((label) => ({ label, value: null, measured: false })),
      note: '登録件数は実際に数えています。宣言された KPI の集計式はこの版では未実装のため value は null です。',
    });
  } catch (error) {
    const failure = apiErrorOf(error, '取得');
    return NextResponse.json(failure.body, { status: failure.status });
  }
}
`;
}

/** /dashboard など、ルート直下ダッシュボードの別名パス。実体を二重に持たない。 */
function buildDashboardAliasPage(route: KitRoute, depth: number): string {
  const up = '../'.repeat(depth);
  return `/**
 * ${safeText(route.path)} — ${safeText(route.purpose)}
 *
 * ルート直下のダッシュボード (src/app/page.tsx) と同じ画面。
 * 実体を 2 か所に持たないよう再エクスポートしている。
 */
export { default } from '${up}page';
`;
}

function buildDbLib(kit?: KitDefinition): string {
  const encrypted = kit ? hasEncryptedFields(kit) : false;
  if (!encrypted) {
    return `import { PrismaClient } from '@prisma/client';

declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

export const prisma =
  global.__prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') {
  global.__prisma = prisma;
}
`;
  }
  // 暗号化対象フィールドを持つ kit では、必ず暗号化 Extension を通した Client のみを公開する。
  return `import { PrismaClient } from '@prisma/client';
import { withFieldEncryption } from './crypto/prisma-encryption-extension';

/**
 * 要配慮個人情報の at-rest 暗号化 (${kit!.kit_id})
 *
 * kit 定義で type=EncryptedString を宣言したフィールドは、DB へ書く直前に暗号化し、
 * 読み出した直後に復号する。素の PrismaClient を export しないのは、
 * 復号経路を通らない読み書きが混在すると暗号文と平文が同居してしまうため。
 */
declare global {
  // eslint-disable-next-line no-var
  var __prisma: ReturnType<typeof buildClient> | undefined;
}

function buildClient() {
  return withFieldEncryption(
    new PrismaClient({
      log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
    }),
  );
}

export const prisma = global.__prisma ?? buildClient();

if (process.env.NODE_ENV !== 'production') {
  global.__prisma = prisma;
}
`;
}

/**
 * 暗号化対象フィールド一覧 (kit 定義 type=EncryptedString の写像)。
 * このファイルが生成物側の SoT であり、Extension とテストの双方がここだけを見る。
 */
function buildEncryptedFieldsMap(kit: KitDefinition): string {
  const map = encryptedFieldMap(kit);
  const entries: string[] = [];
  for (const [model, fields] of map.entries()) {
    entries.push(`  ${model}: [${fields.map((f) => `'${f}'`).join(', ')}],`);
  }
  return `/**
 * 暗号化対象フィールド定義 (自動生成 / kit_id=${kit.kit_id})
 *
 * kit 定義で type=EncryptedString と宣言されたフィールドの一覧。
 * 手で編集せず、kit 定義側を直して再生成してください。
 *
 * 対象: ${map.size} モデル / ${Array.from(map.values()).reduce((a, b) => a + b.length, 0)} フィールド
 */
export const ENCRYPTED_FIELDS: Record<string, readonly string[]> = {
${entries.join('\n')}
} as const;

/** Prisma の model 名 (先頭小文字) → 定義キーの対応。 */
export function encryptedFieldsOfModel(model: string | undefined): readonly string[] {
  if (!model) return [];
  const direct = ENCRYPTED_FIELDS[model];
  if (direct) return direct;
  const pascal = model.charAt(0).toUpperCase() + model.slice(1);
  return ENCRYPTED_FIELDS[pascal] ?? [];
}
`;
}

/** AES-256-GCM によるフィールド単位暗号化 (Node 標準 crypto のみ・外部依存なし)。 */
function buildFieldEncryptionLib(kit: KitDefinition): string {
  return `import { createCipheriv, createDecipheriv, randomBytes, timingSafeEqual } from 'node:crypto';

/**
 * フィールド単位の at-rest 暗号化 (AES-256-GCM / kit_id=${kit.kit_id})
 *
 * 保管形式: \`enc:v1:<keyId>:<iv(base64)>:<authTag(base64)>:<ciphertext(base64)>\`
 * - keyId は鍵ローテーションのために暗号文へ埋め込む (OverlayEncryptionKey.keyId 相当)
 * - 鍵は環境変数から読む。アプリ内にハードコードしない。
 *
 * ## 必要な環境変数
 * - \`FIELD_ENCRYPTION_KEY\`      : 現行鍵 (base64 32 バイト)
 * - \`FIELD_ENCRYPTION_KEY_ID\`   : 現行鍵の識別子 (既定 'k1')
 * - \`FIELD_ENCRYPTION_KEYS_OLD\` : 旧鍵 (任意・\`keyId:base64,keyId:base64\` 形式・復号のみに使用)
 *
 * 鍵生成例: \`node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"\`
 */

const PREFIX = 'enc:v1:';

export class FieldEncryptionKeyError extends Error {}

function decodeKey(raw: string, label: string): Buffer {
  const buf = Buffer.from(raw.trim(), 'base64');
  if (buf.length !== 32) {
    throw new FieldEncryptionKeyError(
      \`\${label} は base64 エンコードされた 32 バイト (AES-256) である必要があります (実測 \${buf.length} バイト)\`,
    );
  }
  return buf;
}

/** 現行鍵。未設定なら fail-loud (平文で保存へフォールバックしない)。 */
export function currentKey(): { keyId: string; key: Buffer } {
  const raw = process.env.FIELD_ENCRYPTION_KEY;
  if (!raw) {
    throw new FieldEncryptionKeyError(
      '環境変数 FIELD_ENCRYPTION_KEY が未設定です。要配慮個人情報を平文で保存しないため処理を中止しました。' +
        ' .env.example の手順に従って鍵を設定してください。',
    );
  }
  return { keyId: process.env.FIELD_ENCRYPTION_KEY_ID?.trim() || 'k1', key: decodeKey(raw, 'FIELD_ENCRYPTION_KEY') };
}

/** 復号用の鍵表 (現行鍵 + 旧鍵)。鍵ローテーション中の読み出しを止めないため。 */
export function keyRing(): Map<string, Buffer> {
  const ring = new Map<string, Buffer>();
  const cur = currentKey();
  ring.set(cur.keyId, cur.key);
  const old = process.env.FIELD_ENCRYPTION_KEYS_OLD;
  if (old) {
    for (const pair of old.split(',')) {
      const idx = pair.indexOf(':');
      if (idx <= 0) continue;
      const id = pair.slice(0, idx).trim();
      if (!id || ring.has(id)) continue;
      ring.set(id, decodeKey(pair.slice(idx + 1), \`FIELD_ENCRYPTION_KEYS_OLD[\${id}]\`));
    }
  }
  return ring;
}

/** 既に暗号文か (二重暗号化と、平文の取り違えを防ぐ)。 */
export function isEncrypted(value: unknown): boolean {
  return typeof value === 'string' && value.startsWith(PREFIX);
}

/** 平文 → 暗号文。既に暗号文ならそのまま返す (二重暗号化しない)。 */
export function encryptField(plain: string): string {
  if (isEncrypted(plain)) return plain;
  const { keyId, key } = currentKey();
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return PREFIX + [keyId, iv.toString('base64'), tag.toString('base64'), enc.toString('base64')].join(':');
}

/** 暗号文 → 平文。暗号文でなければそのまま返す (移行期の平文レコードを壊さない)。 */
export function decryptField(stored: string): string {
  if (!isEncrypted(stored)) return stored;
  const [keyId, ivB64, tagB64, dataB64] = stored.slice(PREFIX.length).split(':');
  const key = keyRing().get(keyId);
  if (!key) {
    throw new FieldEncryptionKeyError(
      \`暗号文の鍵 ID '\${keyId}' に対応する鍵が見つかりません。FIELD_ENCRYPTION_KEYS_OLD に旧鍵を設定してください。\`,
    );
  }
  const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(ivB64, 'base64'));
  decipher.setAuthTag(Buffer.from(tagB64, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(dataB64, 'base64')), decipher.final()]).toString('utf8');
}

/** 暗号文の鍵 ID を取り出す (鍵ローテーションの再暗号化バッチ用)。 */
export function keyIdOf(stored: string): string | null {
  if (!isEncrypted(stored)) return null;
  return stored.slice(PREFIX.length).split(':')[0] ?? null;
}

/** 定数時間比較 (暗号文の同値判定が必要な場合に使う)。 */
export function safeEquals(a: string, b: string): boolean {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  return ba.length === bb.length && timingSafeEqual(ba, bb);
}
`;
}

/**
 * blind index (暗号化列に対する完全一致検索用の決定的ハッシュ) の算出実装。
 * blind_index_of を宣言した kit のみ生成する。
 */
function buildBlindIndexLib(kit: KitDefinition): string {
  const map = blindIndexMap(kit);
  const entries: string[] = [];
  for (const [model, pairs] of map.entries()) {
    entries.push(
      `  ${model}: [${pairs.map((p) => `{ index: '${p.index}', source: '${p.source}' }`).join(', ')}],`,
    );
  }
  const total = Array.from(map.values()).reduce((a, b) => a + b.length, 0);
  return `import { createHmac } from 'node:crypto';

/**
 * blind index — 暗号化列に対する完全一致検索 (自動生成 / kit_id=${kit.kit_id})
 *
 * 暗号文は DB 側で検索・並べ替えができない。氏名のように「暗号化したいが
 * 完全一致検索だけは要る」列については、平文から HMAC-SHA256(pepper, 正規化済み平文)
 * を計算して索引列に保持し、検索は索引列の完全一致で行う。
 *
 * 対象: ${map.size} モデル / ${total} 組。手で編集せず kit 定義側を直して再生成してください。
 *
 * ## 必要な環境変数
 * - \`FIELD_ENCRYPTION_INDEX_PEPPER\` : blind index 用 pepper (base64 32 バイト以上)
 *   生成例: node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
 *
 * ## 必ず理解しておくこと (できないことを隠さない)
 * - **成立するのは完全一致だけ**。部分一致・前方一致・並べ替え・範囲検索は成立しない。
 * - pepper が漏れると、氏名候補を総当たりでハッシュ照合して特定できる。
 *   pepper は暗号鍵と同等に扱い、\`FIELD_ENCRYPTION_KEY\` とは別の値にすること。
 * - 同じ平文は常に同じ索引値になる (決定的)。同姓が何件あるかは索引列から分かる。
 * - pepper を変えたら索引列を全件再計算する必要がある (暗号文と違い keyId を埋め込めない)。
 */

export class BlindIndexKeyError extends Error {}

/** kit 定義の blind_index_of 宣言の写像 (この生成物における SoT)。 */
export const BLIND_INDEX_FIELDS: Record<string, readonly { index: string; source: string }[]> = {
${entries.join('\n')}
} as const;

function pepper(): Buffer {
  const raw = process.env.FIELD_ENCRYPTION_INDEX_PEPPER;
  if (!raw) {
    throw new BlindIndexKeyError(
      '環境変数 FIELD_ENCRYPTION_INDEX_PEPPER が未設定です。索引をハッシュ無しで保存しないため処理を中止しました。' +
        ' .env.example の手順に従って pepper を設定してください。',
    );
  }
  const buf = Buffer.from(raw.trim(), 'base64');
  if (buf.length < 32) {
    throw new BlindIndexKeyError(
      \`FIELD_ENCRYPTION_INDEX_PEPPER は base64 で 32 バイト以上である必要があります (実測 \${buf.length} バイト)\`,
    );
  }
  return buf;
}

/**
 * 照合ゆれの吸収 (Unicode NFKC 正規化 → 前後空白除去 → 小文字化)。
 * 全角/半角・大文字/小文字の違いで «同じ氏名なのに当たらない» を防ぐ。
 * 索引を作るときと検索するときで必ず同じ関数を通すこと。
 */
export function normalizeForIndex(value: string): string {
  return value.normalize('NFKC').trim().toLowerCase();
}

/** 平文 → 索引値 (hex 64 文字)。 */
export function blindIndex(plain: string): string {
  return createHmac('sha256', pepper()).update(normalizeForIndex(plain), 'utf8').digest('hex');
}

/** model 名 (先頭小文字でも可) から blind index の組を引く。 */
export function blindIndexPairsOfModel(
  model: string | undefined,
): readonly { index: string; source: string }[] {
  if (!model) return [];
  const direct = BLIND_INDEX_FIELDS[model];
  if (direct) return direct;
  const pascal = model.charAt(0).toUpperCase() + model.slice(1);
  return BLIND_INDEX_FIELDS[pascal] ?? [];
}

/**
 * 検索条件の断片を組む。
 *   prisma.patient.findMany({ where: blindIndexWhere('Patient', 'familyName', q) })
 *
 * 宣言の無い列を渡したら例外で止める。暗号文への部分一致検索へ黙って落とすと
 * 「エラーは出ないが常に 0 件」という最も気づきにくい壊れ方になるため。
 */
export function blindIndexWhere(model: string, source: string, value: string): Record<string, string> {
  const pair = blindIndexPairsOfModel(model).find((p) => p.source === source);
  if (!pair) {
    throw new BlindIndexKeyError(
      \`\${model}.\${source} には blind index が宣言されていません。暗号化列は完全一致でも検索できないため、\` +
        ' kit 定義に索引列と blind_index_of 宣言を追加してから検索してください。',
    );
  }
  return { [pair.index]: blindIndex(value) };
}
`;
}

/** Prisma Client Extension: 書込み前に暗号化し、読出し後に復号する。 */
function buildPrismaEncryptionExtension(kit: KitDefinition): string {
  // blind index を宣言している kit だけ、索引列の自動算出を織り込む。
  const bix = hasBlindIndex(kit);
  const bixImport = bix ? "import { blindIndex, blindIndexPairsOfModel } from './blind-index';\n" : '';
  const bixDoc = bix
    ? ' * - 書込みの直前に blind index 列 (blind-index.ts の宣言) を平文から算出して埋める\n'
    : '';
  const bixFn = bix
    ? `
function applyBlindIndex(
  value: unknown,
  pairs: readonly { index: string; source: string }[],
): unknown {
  if (Array.isArray(value)) return value.map((v) => applyBlindIndex(v, pairs));
  if (!value || typeof value !== 'object') return value;
  const src = value as AnyRecord;
  const out: AnyRecord = { ...src };
  for (const p of pairs) {
    const v = out[p.source];
    const plain =
      typeof v === 'string'
        ? v
        : v && typeof v === 'object' && typeof (v as AnyRecord).set === 'string'
          ? ((v as AnyRecord).set as string)
          : undefined;
    // 平文が来ていないとき (部分更新で対象列を触っていない・既に暗号文) は索引を触らない。
    // 暗号文から索引は作れないため、ここで無理に上書きすると索引が壊れる。
    if (plain === undefined || isEncrypted(plain)) continue;
    out[p.index] = blindIndex(plain);
  }
  return out;
}
`
    : '';
  // 書込み時の変換。blind index は【暗号化より先】に走らせる (平文でないと索引が作れない)。
  const wrap = (slot: string) =>
    bix
      ? `encryptPayload(applyBlindIndex(nextArgs.${slot}, pairs), fields)`
      : `encryptPayload(nextArgs.${slot}, fields)`;
  const pairsLine = bix ? '        const pairs = blindIndexPairsOfModel(model);\n' : '';
  const shortCircuit = bix
    ? 'if (fields.length === 0 && pairs.length === 0) return query(args);'
    : 'if (fields.length === 0) return query(args);';
  return `import { Prisma } from '@prisma/client';
import { encryptedFieldsOfModel } from './encrypted-fields';
import { decryptField, encryptField, isEncrypted } from './field-encryption';
${bixImport}
/**
 * 要配慮個人情報の透過暗号化 Extension (kit_id=${kit.kit_id})
 *
 * - 書込み (create / update / upsert / createMany / updateMany) の直前に対象フィールドを暗号化
 * - 読出し (find* / create / update / delete などの返り値) の直後に復号
 * - 対象フィールドは \`encrypted-fields.ts\` (kit 定義から自動生成) だけを見る
${bixDoc} *
 * 注意: 暗号文に対する DB 側の部分一致検索・並べ替えは成立しません。
 *       検索が必要な項目は kit 定義で EncryptedString にせず、別途ハッシュ列等を設計してください。
 */

type AnyRecord = Record<string, unknown>;

function encryptPayload(value: unknown, fields: readonly string[]): unknown {
  if (Array.isArray(value)) return value.map((v) => encryptPayload(v, fields));
  if (!value || typeof value !== 'object') return value;
  const src = value as AnyRecord;
  const out: AnyRecord = { ...src };
  for (const f of fields) {
    const v = out[f];
    if (typeof v === 'string') {
      out[f] = encryptField(v);
    } else if (v && typeof v === 'object' && typeof (v as AnyRecord).set === 'string') {
      // Prisma の { set: value } 形式
      out[f] = { ...(v as AnyRecord), set: encryptField((v as AnyRecord).set as string) };
    }
  }
  return out;
}

function decryptResult(value: unknown, fields: readonly string[]): unknown {
  if (Array.isArray(value)) return value.map((v) => decryptResult(v, fields));
  if (!value || typeof value !== 'object') return value;
  const src = value as AnyRecord;
  const out: AnyRecord = { ...src };
  for (const f of fields) {
    const v = out[f];
    if (typeof v === 'string' && isEncrypted(v)) out[f] = decryptField(v);
  }
  return out;
}

${bixFn}
const WRITE_OPS = new Set(['create', 'createMany', 'createManyAndReturn', 'update', 'updateMany', 'upsert']);

export const fieldEncryptionExtension = Prisma.defineExtension({
  name: 'soloptilink-field-encryption',
  query: {
    $allModels: {
      async $allOperations({ model, operation, args, query }: any) {
        const fields = encryptedFieldsOfModel(model);
${pairsLine}        ${shortCircuit}

        let nextArgs = args;
        if (WRITE_OPS.has(operation) && args && typeof args === 'object') {
          nextArgs = { ...args };
          if ('data' in nextArgs) nextArgs.data = ${wrap('data')};
          if ('create' in nextArgs) nextArgs.create = ${wrap('create')};
          if ('update' in nextArgs) nextArgs.update = ${wrap('update')};
        }

        const result = await query(nextArgs);
        return decryptResult(result, fields);
      },
    },
  },
});

/** PrismaClient に暗号化 Extension を適用する。 */
export function withFieldEncryption<T>(client: T) {
  return (client as any).\$extends(fieldEncryptionExtension) as T;
}
`;
}

/**
 * 全モデルの入力スキーマ。
 * 「必須項目は必須・任意項目は任意」を **kit 定義の prisma_models から** 生成するので、
 * prisma.create() が必須項目不足で落ちることがない (2026-08-06 / T-312)。
 */
function buildValidatorsLib(kit: KitDefinition): string {
  const blocks = kit.prisma_models.map((m) => {
    const specs = inputSpecsOf(kit, m);
    const body = specs.length > 0
      ? `{\n${specs.map((s) => `  ${s.name}: ${zodExprOf(s)},`).join('\n')}\n}`
      : '{}';
    return `/** ${m.model}${m.description ? ` — ${m.description}` : ''} */
export const ${m.model}CreateSchema = z.object(${body});

export const ${m.model}UpdateSchema = ${m.model}CreateSchema.partial();

export type ${m.model}CreateInput = z.infer<typeof ${m.model}CreateSchema>;
export type ${m.model}UpdateInput = z.infer<typeof ${m.model}UpdateSchema>;`;
  });

  return `import { z } from 'zod';
import type { Prisma } from '@prisma/client';

/**
 * 入力スキーマ (kit 定義の prisma_models から自動生成)
 *
 * - Create は「値が無いと保存できない項目」を必須にしている
 * - Update は Create の部分適用 (送られた項目だけ更新する)
 * - フォームからは文字列で届くため、数値 / 日付 / 真偽値は zod 側で変換する
 */

/** チェックボックスや選択欄から届く "true" / "on" / "1" を真偽値にする */
const booleanInput = z.preprocess(
  (value) => (typeof value === 'string' ? ['true', 'on', '1'].includes(value) : value),
  z.boolean(),
);

/** テキストエリアから届く JSON 文字列を Prisma の JSON 入力にする */
const jsonInput = z.preprocess(
  (value) => {
    if (typeof value !== 'string') return value;
    try {
      return JSON.parse(value) as unknown;
    } catch {
      return undefined;
    }
  },
  z.custom<Prisma.InputJsonValue>((value) => value !== undefined && value !== null, {
    message: 'JSON 形式で入力してください (例: {"key": "value"})',
  }),
);

${blocks.join('\n\n')}
`;
}

/** 一覧 / 詳細の表示整形。取得できていない値を勝手に 0 や false に見せない。 */
function buildFormatLib(): string {
  return `/**
 * 画面表示用の整形関数
 *
 * 値が無い (null / undefined) ときは空文字にする。0 や false と取り違えないため、
 * 数値・真偽値は「値がある」ときだけ整形する。
 */

export function formatText(value: unknown): string {
  if (value === null || value === undefined) return '';
  return String(value);
}

export function formatDate(value: unknown): string {
  if (value === null || value === undefined) return '';
  const date = value instanceof Date ? value : new Date(String(value));
  return Number.isNaN(date.getTime()) ? '' : date.toLocaleDateString('ja-JP');
}

export function formatDateTime(value: unknown): string {
  if (value === null || value === undefined) return '';
  const date = value instanceof Date ? value : new Date(String(value));
  return Number.isNaN(date.getTime()) ? '' : date.toLocaleString('ja-JP');
}

export function formatNumber(value: unknown): string {
  if (value === null || value === undefined) return '';
  const num = Number(value);
  return Number.isNaN(num) ? '' : num.toLocaleString('ja-JP');
}

export function formatBoolean(value: unknown): string {
  if (value === null || value === undefined) return '';
  return value ? 'はい' : 'いいえ';
}

export function formatJson(value: unknown): string {
  if (value === null || value === undefined) return '';
  try {
    return JSON.stringify(value);
  } catch {
    return '';
  }
}
`;
}

/** API の例外を、利用者に見せてよい日本語へ変換する (内部情報を画面に出さない)。 */
function buildApiErrorLib(): string {
  return `/**
 * API の失敗を「利用者が読める日本語」に変換する
 *
 * 例外の内容 (SQL 文・スタックトレース・テーブル名) をそのまま返すと、
 * 利用者には意味が分からないうえ、内部構造を外に出すことになる。
 * ここで既知のエラーだけを日本語に置き換え、それ以外はサーバのログにだけ残す。
 */

export interface ApiFailure {
  status: number;
  body: { message: string };
}

/** Prisma の既知エラーコードを取り出す (型に依存せず安全に読む) */
function errorCodeOf(error: unknown): string {
  if (typeof error === 'object' && error !== null && 'code' in error) {
    const code = (error as { code?: unknown }).code;
    if (typeof code === 'string') return code;
  }
  return '';
}

export function apiErrorOf(error: unknown, action: '取得' | '登録' | '更新' | '削除'): ApiFailure {
  switch (errorCodeOf(error)) {
    case 'P2002':
      return {
        status: 409,
        body: { message: 'すでに同じ値が登録されています。重複しない値を入力してください。' },
      };
    case 'P2025':
      return { status: 404, body: { message: '対象のデータが見つかりませんでした。' } };
    case 'P2003':
      return {
        status: 400,
        body: { message: '関連するデータが見つかりません。選択内容をご確認ください。' },
      };
    case 'P1001':
    case 'P1017':
      return {
        status: 503,
        body: { message: 'データベースに接続できませんでした。時間をおいて、もう一度お試しください。' },
      };
    default:
      // 想定外の失敗。内容は返さず、サーバ側のログにだけ残す。
      console.error('[api]', action, error);
      return {
        status: 500,
        body: { message: action + 'できませんでした。時間をおいて、もう一度お試しください。' },
      };
  }
}
`;
}

function buildShadcnButton(): string {
  return `import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { clsx } from 'clsx';

const buttonVariants = cva(
  'inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 disabled:opacity-50',
  {
    variants: {
      variant: {
        default: 'bg-blue-600 text-white hover:bg-blue-700',
        outline: 'border bg-white hover:bg-gray-50',
        ghost: 'hover:bg-gray-100',
      },
      size: {
        default: 'h-9 px-4',
        sm: 'h-8 px-3 text-xs',
        lg: 'h-10 px-6',
      },
    },
    defaultVariants: { variant: 'default', size: 'default' },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, ...props }, ref) => (
    <button ref={ref} className={clsx(buttonVariants({ variant, size }), className)} {...props} />
  ),
);
Button.displayName = 'Button';
`;
}

function buildShadcnCard(): string {
  return `import * as React from 'react';
import { clsx } from 'clsx';

export const Card = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={clsx('rounded-lg border bg-white shadow-sm', className)} {...props} />
  ),
);
Card.displayName = 'Card';

export const CardHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={clsx('p-4 border-b', className)} {...props} />
);

export const CardTitle = ({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) => (
  <h3 className={clsx('text-lg font-semibold', className)} {...props} />
);

export const CardContent = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={clsx('p-4', className)} {...props} />
);
`;
}

function buildShadcnInput(): string {
  return `import * as React from 'react';
import { clsx } from 'clsx';

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => (
    <input
      ref={ref}
      className={clsx('w-full rounded-md border px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500', className)}
      {...props}
    />
  ),
);
Input.displayName = 'Input';
`;
}

function buildShadcnLabel(): string {
  return `import * as React from 'react';
import { clsx } from 'clsx';

export const Label = React.forwardRef<HTMLLabelElement, React.LabelHTMLAttributes<HTMLLabelElement>>(
  ({ className, ...props }, ref) => (
    <label ref={ref} className={clsx('text-sm font-medium', className)} {...props} />
  ),
);
Label.displayName = 'Label';
`;
}

function buildShadcnTable(): string {
  return `import * as React from 'react';
import { clsx } from 'clsx';

export const Table = ({ className, ...props }: React.HTMLAttributes<HTMLTableElement>) => (
  <table className={clsx('w-full text-sm', className)} {...props} />
);
export const THead = ({ className, ...props }: React.HTMLAttributes<HTMLTableSectionElement>) => (
  <thead className={clsx('bg-gray-50 text-left', className)} {...props} />
);
export const TBody = ({ className, ...props }: React.HTMLAttributes<HTMLTableSectionElement>) => (
  <tbody className={className} {...props} />
);
export const Tr = ({ className, ...props }: React.HTMLAttributes<HTMLTableRowElement>) => (
  <tr className={clsx('border-t', className)} {...props} />
);
export const Th = ({ className, ...props }: React.ThHTMLAttributes<HTMLTableCellElement>) => (
  <th className={clsx('px-3 py-2 font-semibold', className)} {...props} />
);
export const Td = ({ className, ...props }: React.TdHTMLAttributes<HTMLTableCellElement>) => (
  <td className={clsx('px-3 py-2', className)} {...props} />
);
`;
}

function buildSeed(kit: KitDefinition): string {
  // 1 つ目のモデルから 3 件のダミーデータを作る
  const m = kit.prisma_models[0];
  const camel = delegateOf(m);
  const sampleField = m.fields.find((f) => f.name === 'name' || f.name === 'title') ?? m.fields[1] ?? m.fields[0];
  const codeField = m.fields.find((f) => f.name === 'code');
  const samples: string[] = [];
  for (let i = 1; i <= 3; i += 1) {
    const obj: Record<string, string> = {};
    if (codeField) obj[codeField.name] = `${kit.kit_id.toUpperCase()}-${String(i).padStart(3, '0')}`;
    if (sampleField && sampleField.name !== codeField?.name) obj[sampleField.name] = `サンプル ${i}`;
    samples.push(
      '    ' + JSON.stringify(obj).replace(/"([^"]+)":/g, '$1:'),
    );
  }
  return `import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const samples = [
${samples.join(',\n')},
  ];
  for (const data of samples) {
    // await prisma.${camel}.upsert({ where: { code: (data as any).code }, update: data, create: data });
    console.log('seed sample:', data);
  }
  console.log('seeded ${samples.length} ${m.model} sample(s).');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
`;
}

/** 要配慮個人情報の暗号化まわりの運用手順 (対象フィールドを持つ kit のみ)。 */
function buildEncryptionReadmeSection(kit: KitDefinition): string {
  const map = encryptedFieldMap(kit);
  if (map.size === 0) return '';
  const rows = Array.from(map.entries()).map(([m, f]) => `| ${m} | ${f.join(', ')} |`).join('\n');
  const total = Array.from(map.values()).reduce((a, b) => a + b.length, 0);
  return `
## 要配慮個人情報の暗号化 (必読)

kit 定義で \`EncryptedString\` と宣言された **${map.size} モデル / ${total} フィールド**は、
DB へ**暗号文**で保管します (AES-256-GCM / アプリケーション層で暗号化・復号)。

| モデル | 暗号化フィールド |
|--------|------------------|
${rows}

### 起動前に必ず行うこと

\`\`\`bash
# 32 バイト鍵を生成して .env に設定する
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
# -> FIELD_ENCRYPTION_KEY に貼り付け
\`\`\`

\`FIELD_ENCRYPTION_KEY\` が未設定のまま対象フィールドを読み書きすると**例外で停止**します。
平文保存へ倒れない設計です (要配慮個人情報が黙って平文で残ることを防ぐため)。

### 実装上の制約 (設計時に必ず考慮すること)

- 暗号文に対する **DB 側の部分一致検索・並べ替え・集計はできません**。
  検索が必要な項目は \`EncryptedString\` にせず、別途ハッシュ列などを設計してください。
- 暗号化・復号は \`src/lib/db.ts\` が公開する \`prisma\` を経由した場合のみ働きます。
  素の \`new PrismaClient()\` を別途生成すると**暗号文のまま読み書き**されます。
- 鍵のローテーションは \`FIELD_ENCRYPTION_KEYS_OLD\` に旧鍵を残したまま新鍵へ切替え、
  再暗号化バッチ完走後に旧鍵を外してください。
- **DB のバックアップ・監査ログ・エクスポート先にも同じ保護が要ります。**
  本テンプレが担保するのはアプリケーション経路の at-rest 暗号化までです。
${buildBlindIndexReadmeSection(kit)}
`;
}

/** blind index (暗号化列の完全一致検索) の運用手順。宣言のある kit のみ。 */
function buildBlindIndexReadmeSection(kit: KitDefinition): string {
  const map = blindIndexMap(kit);
  if (map.size === 0) {
    // 宣言はあるのに退避弁で無効化されている場合、黙って「検索できないシステム」を渡さない。
    if (blindIndexDeclaredRaw(kit)) {
      return `
### 暗号化した項目の検索について (重要・現在は無効)

この生成物は \`TEMPLATE_KIT_BLIND_INDEX=off\` で生成されているため、
**暗号化した氏名等に対する完全一致検索の索引が入っていません**。
索引列は存在しますが値が入らないため、氏名検索は常に 0 件になります。
検索が必要な場合は \`TEMPLATE_KIT_BLIND_INDEX=on\` (既定) で生成し直してください。
`;
    }
    return '';
  }
  const rows = Array.from(map.entries())
    .map(([m, ps]) => ps.map((p) => `| ${m} | ${p.source} | ${p.index} |`).join('\n'))
    .join('\n');
  const first = Array.from(map.entries())[0];
  const sampleModel = first[0];
  const samplePair = first[1][0];
  const sampleVar = sampleModel.charAt(0).toLowerCase() + sampleModel.slice(1);
  return `
### 暗号化した項目の検索 (blind index)

暗号文は DB 側で検索できません。下表の項目には**完全一致検索専用の索引列**を併設しています。
索引値は \`src/lib/crypto/blind-index.ts\` が平文から自動算出し、書込み時に暗号化 Extension が埋めます。

| モデル | 平文列 (暗号化) | 索引列 |
|--------|----------------|--------|
${rows}

\`\`\`bash
# pepper を生成して .env に設定する (FIELD_ENCRYPTION_KEY とは別の値にすること)
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
# -> FIELD_ENCRYPTION_INDEX_PEPPER に貼り付け
\`\`\`

\`\`\`ts
import { blindIndexWhere } from '@/lib/crypto/blind-index';

// 検索例: 完全一致でのみ引ける
const rows = await prisma.${sampleVar}.findMany({
  where: blindIndexWhere('${sampleModel}', '${samplePair.source}', query),
});
\`\`\`

**この方式でできないこと (画面設計の前に必ず確認してください)**

- **部分一致・前方一致・あいまい検索・並べ替えはできません。** 完全一致のみです。
  一覧画面の検索欄は「完全一致で検索します」と明示してください。
- pepper が漏れると、氏名候補を総当たりでハッシュ照合して特定できます。
  pepper は暗号鍵と同等の管理をしてください。
- 同じ平文は常に同じ索引値になります。同姓が何件あるかは索引列から分かります。
- pepper を変更した場合は**索引列を全件再計算**する必要があります。
`;
}

// ---------------------------------------------------------------------------
// 顧客提示文書のルート列挙 (README / 設計契約が共有する)
//
// 2026-08-05 以前は kit.routes を無条件に全件列挙していたため、生成していない
// 画面まで「主要ページ」としてお客様に約束していた。列挙は必ず routePlan() の
// generated を経由し、生成していないものは下の見出しで正直に開示する。
// ---------------------------------------------------------------------------

/** 未生成ルートを開示する節の見出し (突合ゲートがこの文字列で本文を分割する)。 */
const UNGENERATED_HEADING = '### この版では生成していない画面';

function generatedRouteLines(
  plan: RoutePlanEntry[],
  filter: (e: RoutePlanEntry) => boolean = () => true,
): string {
  const lines = plan
    .filter((e) => e.generated && filter(e))
    .map((e) => `- \`${e.route.path}\` — ${e.route.purpose}`);
  return lines.length > 0 ? lines.join('\n') : '- (この版では該当するものがありません)';
}

function ungeneratedRouteSection(plan: RoutePlanEntry[]): string {
  const rows = plan.filter((e) => !e.generated);
  if (rows.length === 0) {
    return `${UNGENERATED_HEADING}

この版では、kit 定義に宣言されたルートをすべて生成しています。
`;
  }
  const list = rows
    .map((e) => `- \`${e.route.path}\` — ${e.route.purpose}\n  - 生成していない理由: ${e.reason ?? '不明'}`)
    .join('\n');
  return `${UNGENERATED_HEADING}

以下は kit 定義に宣言はありますが、**この版では画面 / API を生成していません**。
中身の無い実装を置いて「動いているように見えるだけ」のものを作らないための判断です。
必要な場合は業務要件を確認のうえ個別に実装してください。

${list}
`;
}

// ---------------------------------------------------------------------------
// 「どの資源が本当に保存・取得できるか」の開示 (2026-08-06 新設 / T-312)
//
// モデルが解決できた資源だけが実際に prisma を呼ぶ。解決できなかった資源は
// 501 のまま残るので、**それを黙って混ぜない**。README と設計契約の両方に
// 「有効にしている資源」と「有効にしていない資源 + 理由」を出す。
// ---------------------------------------------------------------------------

/** 資源 1 つ分の結線状況。 */
export interface ResourceWiringRow {
  resource: string;
  /** 解決できた Prisma モデル名 */
  model?: string;
  /** 解決できなかった理由 (日本語) */
  reason?: string;
}

/** この版で生成する画面 / API が触る資源と、その結線状況を返す。 */
export function resourceWiring(kit: KitDefinition): ResourceWiringRow[] {
  const plan = buildGenerationPlan(kit);
  const rows = new Map<string, ResourceWiringRow>();
  const record = (keys: (string | undefined)[]): void => {
    const cands = keys.filter((k): k is string => k !== undefined && k.length > 0 && !k.includes('['));
    if (cands.length === 0) return;
    if (rows.has(cands[0])) return;
    const b = bindingForKeys(kit, cands);
    rows.set(cands[0], { resource: cands[0], model: b.model?.model, reason: b.reason });
  };

  for (const { resource } of plan.resources) record([resource]);
  for (const e of plan.declared) {
    if (!e.generated) continue;
    const segs = segmentsOf(e.route.path);
    switch (e.kind) {
      case 'list':
      case 'report':
      case 'detail':
        record([collectionOf(segs), e.route.resource]);
        break;
      case 'new':
      case 'edit':
        record([e.writeResource ?? collectionOf(segs), collectionOf(segs), e.route.resource]);
        break;
      case 'api-collection':
      case 'api-item':
        record([segs[1], e.route.resource]);
        break;
      default:
        break;
    }
  }
  return Array.from(rows.values()).sort((a, b) => a.resource.localeCompare(b.resource));
}

/** README / 設計契約に共通で載せる結線状況の節。 */
function wiringSection(kit: KitDefinition): string {
  const rows = resourceWiring(kit);
  const wired = rows.filter((r) => r.model !== undefined);
  const unwired = rows.filter((r) => r.model === undefined);

  const wiredBlock = wired.length > 0
    ? `| 資源 | Prisma モデル |\n|------|----------------|\n${wired
        .map((r) => `| \`${r.resource}\` | ${r.model} |`)
        .join('\n')}`
    : '(この版では該当するものがありません)';

  const unwiredBlock = unwired.length > 0
    ? `${unwired.map((r) => `- \`${r.resource}\`\n  - 理由: ${r.reason ?? '不明'}`).join('\n')}`
    : '(この版では該当するものがありません。すべての資源で保存・取得が有効です)';

  return `### データの保存・取得を有効にしている資源

一覧・詳細は実際にデータベースから取得し、新規作成・編集・削除は実際に保存します。
入力欄はモデルの必須項目から生成しているため、フォームを埋めれば保存が通ります。

${wiredBlock}

### この版で保存・取得を有効にしていない資源

以下の資源は、kit 定義から対応する Prisma モデルを特定できませんでした。
モデル名を推測して「存在しないデータベース呼び出し」を書くとビルドが落ちるため、
**この版では画面に理由を表示し、API は 501 を返します**（保存できたように見せません）。

${unwiredBlock}
`;
}

function buildReadme(kit: KitDefinition): string {
  const plan = routePlan(kit);
  return `# ${kit.name_ja}

${kit.description}
${buildEncryptionReadmeSection(kit)}
## クイックスタート

\`\`\`bash
# 1. 依存関係インストール
npm install

# 2. 環境変数
cp .env.example .env
# DATABASE_URL を編集してください

# 3. DB セットアップ
npm run db:generate
npm run db:migrate
npm run db:seed

# 4. 開発サーバー
npm run dev
# -> http://localhost:3000
\`\`\`

## 含まれるもの (90% 完成)

- ${kit.scaffold_outputs.files_count} files / 約 ${kit.scaffold_outputs.lines_count_approx} 行
- セットアップ目安: ${kit.scaffold_outputs.estimated_setup_minutes} 分
- 完成度: ${kit.estimated_completion_percent}%

### 主要ページ

${generatedRouteLines(plan)}

${ungeneratedRouteSection(plan)}
${wiringSection(kit)}
### Prisma モデル

${kit.prisma_models.map((m) => `- **${m.model}**${m.description ? ` — ${m.description}` : ''}`).join('\n')}

### ダッシュボード KPI

${kit.dashboard_kpis.map((k) => `- ${k}`).join('\n')}

### 帳票テンプレート

${kit.report_templates.map((r) => `- ${r}`).join('\n')}

## 適用法令

${kit.applicable_laws.map((l) => `- ${l}`).join('\n')}

## 残り 10% カスタマイズ

${(kit.remaining_customizations ?? []).map((c) => `- ${c}`).join('\n')}

## ライセンス

このプロジェクトは soloptilink-template-kit によって生成されました。
詳細は docs/DESIGN_CONTRACT.md を参照してください。
`;
}

function buildDesignContract(kit: KitDefinition): string {
  const plan = routePlan(kit);
  const isApiKind = (e: RoutePlanEntry) => e.kind.startsWith('api-');
  return `# 設計契約 (DESIGN CONTRACT)

> 本ドキュメントは soloptilink-template-kit が出力した設計の根拠を示します。
> kit_id: \`${kit.kit_id}\` / 生成日: \`${new Date().toISOString().slice(0, 10)}\`

## 1. プロジェクト概要

- **名称**: ${kit.name_ja}
- **業種**: ${kit.industry_ja ?? kit.industry}
- **完成度**: ${kit.estimated_completion_percent}%
- **想定ユースケース**: ${kit.use_case}

## 2. 技術スタック

${Object.entries(kit.stack)
  .map(([k, v]) => `- **${k}**: ${v}`)
  .join('\n')}

## 3. 適用法令

${kit.applicable_laws.map((l) => `- ${l}`).join('\n')}

## 4. ドメイン辞書

本キットは \`${kit.domain_dictionary_ref}\` を参照しています。
用語/必須項目/法令ルールはこの辞書のスキーマに基づきます。

## 5. 機能一覧

> 本節に載るのは **この版で実際に生成されるもの** だけです。
> 宣言はあるが生成していないものは末尾の「${UNGENERATED_HEADING.replace('### ', '')}」に列挙します。

### ページ (UI)

${generatedRouteLines(plan, (e) => !isApiKind(e))}

### API

${generatedRouteLines(plan, isApiKind)}

${ungeneratedRouteSection(plan)}
${wiringSection(kit)}
## 6. データモデル

${kit.prisma_models
  .map((m) => {
    const head = `### ${m.model}${m.description ? ` — ${m.description}` : ''}`;
    const fields = m.fields
      .map((f) => `- \`${f.name}\`: ${f.type}${f.required === false ? ' (optional)' : ''}${f.description ? ` — ${f.description}` : ''}`)
      .join('\n');
    return `${head}\n\n${fields}`;
  })
  .join('\n\n')}

## 7. ダッシュボード KPI

${kit.dashboard_kpis.map((k) => `- ${k}`).join('\n')}

## 8. 帳票テンプレート

${kit.report_templates.map((r) => `- ${r}`).join('\n')}

## 9. 残り 10% カスタマイズ

${(kit.remaining_customizations ?? []).map((c) => `- ${c}`).join('\n')}

## 10. テスト方針

- 単体テスト: vitest
- E2E テスト: playwright (任意)
- リント: biome

## 11. 受け入れ基準

- \`npm run dev\` がエラーなく起動する
- 主要ページの SSR が成功する (status 200)
- 一覧ページからの新規作成→詳細表示の往復が成功する
- Prisma migrate + seed が完了する
`;
}

// ---------------------------------------------------------------------------
// 公開 API
// ---------------------------------------------------------------------------

/**
 * KitDefinition を targetDir に書き出す。
 */
export function scaffold(
  kit: KitDefinition,
  targetDir: string,
  options: ScaffoldOptions = {},
): ScaffoldReport {
  const overwrite = options.overwrite ?? true;
  if (existsSync(targetDir) && !overwrite) {
    throw new Error(`target directory already exists: ${targetDir}`);
  }
  const report: ScaffoldReport = {
    kit_id: kit.kit_id,
    target_dir: targetDir,
    files_written: [],
    total_lines: 0,
    setup_minutes: kit.scaffold_outputs.estimated_setup_minutes,
  };

  ensureDir(targetDir);

  // ルート
  writeOut(join(targetDir, 'package.json'), buildPackageJson(kit), report);
  writeOut(join(targetDir, 'tsconfig.json'), buildTsconfig(), report);
  writeOut(join(targetDir, 'next.config.ts'), buildNextConfig(), report);
  writeOut(join(targetDir, 'tailwind.config.ts'), buildTailwindConfig(), report);
  writeOut(join(targetDir, 'postcss.config.mjs'), buildPostcss(), report);
  writeOut(join(targetDir, '.env.example'), buildEnvExample(kit), report);
  writeOut(join(targetDir, '.gitignore'), buildGitignore(), report);
  writeOut(join(targetDir, 'README.md'), buildReadme(kit), report);

  // docs
  writeOut(join(targetDir, 'docs', 'DESIGN_CONTRACT.md'), buildDesignContract(kit), report);

  // prisma
  writeOut(join(targetDir, 'prisma', 'schema.prisma'), buildPrismaSchema(kit), report);
  writeOut(join(targetDir, 'prisma', 'seed.ts'), buildSeed(kit), report);

  // src/lib
  writeOut(join(targetDir, 'src', 'lib', 'db.ts'), buildDbLib(kit), report);
  writeOut(join(targetDir, 'src', 'lib', 'validators.ts'), buildValidatorsLib(kit), report);
  writeOut(join(targetDir, 'src', 'lib', 'format.ts'), buildFormatLib(), report);
  writeOut(join(targetDir, 'src', 'lib', 'api-error.ts'), buildApiErrorLib(), report);

  // blind index だけ宣言して暗号化列が 1 つも無い kit は、索引を書き出す場所 (crypto 一式) が
  // 生成されず「宣言はあるのに実装がどこにも出ない」状態になる。黙って落とすと検索が壊れるので止める。
  if (hasBlindIndex(kit) && !hasEncryptedFields(kit)) {
    throw new Error(
      `kit 定義エラー (${kit.kit_id}): blind_index_of を宣言していますが EncryptedString の列が 1 つもありません。` +
        ' blind index は暗号化列の完全一致検索を成立させるための仕組みです。索引の元列を EncryptedString にするか、blind_index_of 宣言を外してください。',
    );
  }

  // src/lib/crypto (kit 定義に EncryptedString フィールドがある場合のみ)
  if (hasEncryptedFields(kit)) {
    const cryptoDir = join(targetDir, 'src', 'lib', 'crypto');
    writeOut(join(cryptoDir, 'encrypted-fields.ts'), buildEncryptedFieldsMap(kit), report);
    writeOut(join(cryptoDir, 'field-encryption.ts'), buildFieldEncryptionLib(kit), report);
    // blind index (暗号化列の完全一致検索) は宣言のある kit のみ。
    // ★Extension より先に書き出す: Extension が import する側であり、
    //   片方だけ出ると生成物がビルドできない (欠け方を分かりにくくしない)。
    if (hasBlindIndex(kit)) {
      writeOut(join(cryptoDir, 'blind-index.ts'), buildBlindIndexLib(kit), report);
    }
    writeOut(join(cryptoDir, 'prisma-encryption-extension.ts'), buildPrismaEncryptionExtension(kit), report);
  }

  // src/components/ui
  writeOut(join(targetDir, 'src', 'components', 'ui', 'button.tsx'), buildShadcnButton(), report);
  writeOut(join(targetDir, 'src', 'components', 'ui', 'card.tsx'), buildShadcnCard(), report);
  writeOut(join(targetDir, 'src', 'components', 'ui', 'input.tsx'), buildShadcnInput(), report);
  writeOut(join(targetDir, 'src', 'components', 'ui', 'label.tsx'), buildShadcnLabel(), report);
  writeOut(join(targetDir, 'src', 'components', 'ui', 'table.tsx'), buildShadcnTable(), report);

  // src/app/layout, page, globals.css
  writeOut(join(targetDir, 'src', 'app', 'layout.tsx'), buildLayout(kit), report);
  writeOut(join(targetDir, 'src', 'app', 'page.tsx'), buildDashboardPage(kit), report);
  writeOut(join(targetDir, 'src', 'app', 'globals.css'), buildGlobalsCss(), report);

  // 生成計画 (宣言ルート駆動)。同じファイルを 2 度書かないよう相対パスで管理する。
  const plan = buildGenerationPlan(kit);
  const written = new Set<string>([ROOT_DASHBOARD_FILE]);
  const writeRel = (rel: string, content: string): void => {
    if (written.has(rel)) return;
    written.add(rel);
    writeOut(join(targetDir, rel), content, report);
  };

  /** 画面ファイルの隣に部品 (入力フォーム) を置く。 */
  const writeSibling = (pageFile: string, extra: ExtraFile | null): void => {
    if (extra === null) return;
    writeRel(join(dirname(pageFile), extra.fileName), extra.content);
  };

  // resources (旧来の 4 点セット。宣言側が別名の可変セグメントを使う階層では
  // [id] の詳細画面を出さない — 同居すると Next.js がビルドできないため)
  for (const { resource: r, detailSegment } of plan.resources) {
    const binding = modelBindingOf(kit, r);
    const listFile = uiPageFile([r]);
    writeRel(listFile, buildResourceListPage(r, kit, binding, detailSegment !== null));
    if (detailSegment !== null) {
      writeRel(uiPageFile([r, detailSegment]), buildResourceDetailPage(r, kit, binding));
    }
    const newPage = buildResourceNewPage(r, kit, binding);
    const newFile = uiPageFile([r, 'new']);
    writeRel(newFile, newPage.page);
    writeSibling(newFile, newPage.extra);
    writeRel(apiRouteFile([r]), buildApiRoute(r, kit, binding));
  }

  // 宣言ルート由来 (kill-switch TEMPLATE_KIT_DECLARED_ROUTES=off なら generated は
  // 旧挙動で出るものだけになるので、このループは実質何も足さない)
  for (const e of plan.declared) {
    if (!e.generated || written.has(e.file)) continue;
    const segs = segmentsOf(e.route.path);
    switch (e.kind) {
      case 'dashboard-root':
        break; // src/app/page.tsx は上で生成済み
      case 'dashboard-alias':
        writeRel(e.file, buildDashboardAliasPage(e.route, segs.length + 1));
        break;
      case 'list':
      case 'report':
        writeRel(
          e.file,
          buildDeclaredListPage(e.route, e.kind, kit, bindingForKeys(kit, [collectionOf(segs), e.route.resource])),
        );
        break;
      case 'detail':
        writeRel(
          e.file,
          buildDeclaredDetailPage(e.route, kit, bindingForKeys(kit, [collectionOf(segs), e.route.resource])),
        );
        break;
      case 'new': {
        const apiResource = e.writeResource ?? collectionOf(segs);
        const out = buildDeclaredNewPage(
          e.route, apiResource, kit, bindingForKeys(kit, [apiResource, collectionOf(segs), e.route.resource]),
        );
        writeRel(e.file, out.page);
        writeSibling(e.file, out.extra);
        break;
      }
      case 'edit': {
        const apiResource = e.writeResource ?? collectionOf(segs);
        const out = buildDeclaredEditPage(
          e.route, apiResource, kit, bindingForKeys(kit, [apiResource, collectionOf(segs), e.route.resource]),
        );
        writeRel(e.file, out.page);
        writeSibling(e.file, out.extra);
        break;
      }
      case 'api-collection':
        writeRel(e.file, buildApiRoute(segs[1], kit, bindingForKeys(kit, [segs[1], e.route.resource])));
        break;
      case 'api-item':
        writeRel(
          e.file,
          buildApiItemRoute(
            segs[1], segs[2].slice(1, -1), kit, bindingForKeys(kit, [segs[1], e.route.resource]),
          ),
        );
        break;
      case 'api-kpi':
        writeRel(e.file, buildDashboardKpiRoute(kit));
        break;
      default:
        break;
    }
  }

  // バックアップ手段の同梱 (PFP-111)。prisma/schema.prisma と package.json を
  // 書き終えた後でなければゲートが「対象外」と判定するため、必ずここ (最後) で呼ぶ。
  const br = applyBackupRestore(targetDir);
  report.backup_restore = br;
  if (br.status === 'applied') {
    // README に実在するファイルだけを案内する (存在しない画面/ファイルを約束しない)。
    appendOut(
      join(targetDir, 'README.md'),
      [
        '',
        '## バックアップと復元',
        '',
        '- `scripts/backup.sh` … データベースのバックアップを取得します。',
        '- `docs/RESTORE.md` … 復元の手順書 (日本語) です。',
        '',
        '定期実行の設定方法と復元の実演手順は `docs/RESTORE.md` に記載しています。',
        'お引き渡し前に、一度実際に復元できることを確かめてください。',
        '',
      ].join('\n'),
      report,
    );
  }

  return report;
}
