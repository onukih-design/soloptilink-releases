#!/usr/bin/env node
/**
 * soloptilink-template-kit / 文書が参照する「本体の実体」パスの実在ゲート
 *
 * ## なぜ必要か (2026-08-05 実測の事故)
 * medical_overlay.json の phase_c_disclosure.disclosure_line — 医療テンプレの免責文言の
 * SoT (唯一の正典) — が「本kitの Phase C 接続テストは lib/japan/phase-c-stubs 配下の
 * mock 応答のみを返す」と記載していたが、当該ディレクトリは本体に実在しなかった。
 * 同種の参照は home_nursing (lib/security/field-crypto.ts / lib/audit/logger.ts) と
 * dispensing_pharmacy (lib/security/*-middleware.ts) にもあり、いずれも実体が無かった。
 *
 * これらの purpose / description は scaffolder が README.md と docs/DESIGN_CONTRACT.md へ
 * **無条件に転記**するため、実在しないパスがそのまま顧客提示文書へ載る。
 * 既存 4 ゲート (33/14/24/63 軸) にこの軸は 1 本も無かった。
 *
 * ## このゲートが測るもの
 *   A-1: 各 kit JSON が参照する本体モジュールパスがすべて実在する
 *   A-2: 顧客提示文書の SoT (phase_c_disclosure.disclosure_line) が実在しないパスを含まない
 *   B-1: [欠陥注入] 実在しないパスを 1 本混ぜると A-1 が確かに落ちる
 *   B-2: [欠陥注入] disclosure_line に実在しないパスを混ぜると A-2 が確かに落ちる
 *
 * ## 正直な限界 (測っていないこと)
 *   - 生成物側パス (src/... で始まるもの) は本ゲートの対象外。
 *     宣言ルートと生成ファイルの突合は tests/route_generation_check.mjs の担当。
 *   - パスが実在することだけを測る。中身がその説明どおりに振る舞うかは測っていない。
 *
 * 実行: node tests/path_reference_check.mjs
 * 未測定を合格として記録しない (解決起点がひとつも無ければ exit 2)。
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { homedir } from 'node:os';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '..');
const KITS_DIR = process.env.SOLOPTILINK_TEMPLATE_KIT_DIR ?? join(ROOT, 'kits');
const BODY = join(homedir(), '.soloptilink');

/** 本体のモジュール置き場。ここを起点とする表記だけを「本体実体への参照」とみなす。 */
const MODULE_TOPS = ['lib', 'scripts', 'skills', 'tests', 'templates', 'schemas', 'kits'];
const PATH_RE = new RegExp(
  `(?<![\\w/.-])((?:${MODULE_TOPS.join('|')})/[A-Za-z0-9._-]+(?:/[A-Za-z0-9._-]+)*)`, 'g');

/** 拡張子を省いて書かれることがあるため、代表的な拡張子も試す。 */
const SUFFIXES = ['', '.ts', '.tsx', '.js', '.mjs', '.json', '.sh', '.md', '.py'];

const ROOTS = [ROOT, BODY, join(homedir(), '.claude')].filter((p) => existsSync(p));

/** 退役先 (.retired/<日付>-<名>/) — 退役済みモジュールへの履歴参照は欠陥ではない。 */
const RETIRED = existsSync(join(BODY, '.retired'))
  ? readdirSync(join(BODY, '.retired')).map((d) => join(BODY, '.retired', d))
  : [];

if (ROOTS.length === 0) {
  console.error('UNMEASURED: 解決起点 (skill ディレクトリ / ~/.soloptilink / ~/.claude) が'
    + '1 つも見つからないため、パス参照を検査できませんでした。');
  console.error('このゲートは未測定を合格として記録しません。');
  process.exit(2);
}

function resolves(token) {
  for (const r of [...ROOTS, ...RETIRED]) {
    for (const s of SUFFIXES) {
      if (existsSync(join(r, token + s))) return true;
    }
  }
  return false;
}

/** JSON を走査し [jsonPath, 文字列] を列挙する。 */
function* strings(node, path = '') {
  if (node && typeof node === 'object' && !Array.isArray(node)) {
    for (const [k, v] of Object.entries(node)) yield* strings(v, `${path}.${k}`);
  } else if (Array.isArray(node)) {
    for (let i = 0; i < node.length; i += 1) yield* strings(node[i], `${path}[${i}]`);
  } else if (typeof node === 'string') {
    yield [path, node];
  }
}

/** 未解決の参照を [{kit, jsonPath, token}] で返す。 */
function unresolvedRefs(kitId, kit, only = null) {
  const out = [];
  for (const [jsonPath, s] of strings(kit)) {
    if (only && !jsonPath.startsWith(only)) continue;
    // .scaffold.* は生成物側の出力先であり、本体に実在しないのが正常。
    if (jsonPath.startsWith('.scaffold.')) continue;
    for (const m of s.matchAll(PATH_RE)) {
      const token = m[1];
      if (!resolves(token)) out.push({ kit: kitId, jsonPath, token });
    }
  }
  return out;
}

const KIT_IDS = readdirSync(KITS_DIR)
  .filter((f) => f.endsWith('.json'))
  .map((f) => f.replace(/\.json$/, ''))
  .sort();

const KITS = new Map(
  KIT_IDS.map((id) => [id, JSON.parse(readFileSync(join(KITS_DIR, `${id}.json`), 'utf8'))]),
);

function describe(rows) {
  return rows.map((r) => `  ${r.kit}.json ${r.jsonPath} → ${r.token}`).join('\n');
}

test('A-1: 各 kit が参照する本体モジュールパスがすべて実在する', () => {
  assert.ok(KIT_IDS.length > 0, 'kits/ に kit JSON がある');
  const bad = [];
  for (const [id, kit] of KITS) bad.push(...unresolvedRefs(id, kit));
  assert.equal(bad.length, 0,
    `実在しないパスを参照している箇所がある (顧客提示文書へ転記される):\n${describe(bad)}`);
});

test('A-2: 免責文言の SoT (phase_c_disclosure) が実在しないパスを含まない', () => {
  const withDisclosure = [...KITS].filter(([, k]) => k.phase_c_disclosure);
  assert.ok(withDisclosure.length > 0, 'phase_c_disclosure を持つ kit が存在する');
  const bad = [];
  for (const [id, kit] of withDisclosure) {
    bad.push(...unresolvedRefs(id, kit, '.phase_c_disclosure'));
  }
  assert.equal(bad.length, 0,
    `免責文言が実在しないパスを参照している:\n${describe(bad)}`);
});

test('B-1: [欠陥注入] 実在しないパスを混ぜると A-1 が確かに落ちる', () => {
  const probe = {
    description: '検体: lib/japan/this-module-does-not-exist を参照する',
  };
  const bad = unresolvedRefs('__probe__', probe);
  assert.equal(bad.length, 1, '注入した 1 本を検出する');
  assert.equal(bad[0].token, 'lib/japan/this-module-does-not-exist');
});

test('B-2: [欠陥注入] disclosure_line に実在しないパスを混ぜると A-2 が確かに落ちる', () => {
  const probe = {
    phase_c_disclosure: {
      disclosure_line: '本kitの応答は lib/japan/phase-c-stubs 配下の mock のみを返します',
    },
    description: '対象外であることの確認用に lib/japan/another-missing-one も置く',
  };
  const bad = unresolvedRefs('__probe__', probe, '.phase_c_disclosure');
  assert.equal(bad.length, 1, 'disclosure 配下の 1 本だけを検出する (description は対象外)');
  assert.equal(bad[0].token, 'lib/japan/phase-c-stubs');
});

test('B-3: 実在するパスは誤検知しない', () => {
  const real = { description: '本 kit は lib/japan/emr-core を呼ぶ' };
  assert.equal(unresolvedRefs('__probe__', real).length, 0,
    'lib/japan/emr-core は実在するので検出してはならない');
});
