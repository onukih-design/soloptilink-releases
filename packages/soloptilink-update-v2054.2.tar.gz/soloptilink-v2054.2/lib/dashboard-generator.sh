#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v239.0 - Dashboard Generator
# =============================================================================
# アナリティクスダッシュボードの自動生成。
# KPIカード/チャート/フィルタ/エクスポート/リアルタイム更新。
#
# 機能:
#   DG-001: KPIメトリクスカード生成（トレンド付き）
#   DG-002: チャート生成（line/bar/pie/area - Recharts）
#   DG-003: ダッシュボードフィルタ生成（日付範囲/カテゴリ/ステータス）
#   DG-004: CSV/PDFエクスポート生成
#   DG-005: リアルタイムデータ更新生成
#   DG-006: プロジェクトダッシュボード品質スキャン
#
# 全globals: DG_ prefix
# =============================================================================

[[ -n "${_DASHBOARD_GENERATOR_LOADED:-}" ]] && return 0
_DASHBOARD_GENERATOR_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g DG_VERSION="239.0"
declare -g DG_INITIALIZED=false
declare -g DG_GENERATED_COUNT=0
declare -g DG_SCAN_SCORE=100
declare -g DG_ISSUES=""
declare -g DG_ISSUE_COUNT=0

declare -g ENABLE_DG="${ENABLE_DG:-true}"

# =============================================================================
# 初期化
# =============================================================================
dg_init() {
    DG_INITIALIZED=true
    DG_GENERATED_COUNT=0
    DG_SCAN_SCORE=100
    DG_ISSUES=""
    DG_ISSUE_COUNT=0
    return 0
}

dg_init_message() {
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Dashboard Generator v${DG_VERSION} (KPI/Charts/Filters/Export/Realtime)" >&2
}

# =============================================================================
# DG-001: KPIカード生成
# =============================================================================
_dg_generate_kpi_cards() {
    local output_dir="${1:-.}"
    local metrics="${2:-revenue,users,orders,conversion}"

    echo -e "  ${CYAN:-\033[0;36m}[DG]${NC:-\033[0m} Generating KPI cards..." >&2

    local kpi_file="${output_dir}/components/dashboard/KPICards.tsx"
    mkdir -p "$(dirname "$kpi_file")"

    cat > "$kpi_file" <<'KPI_CARDS'
'use client';

interface KPIMetric {
  label: string;
  value: string | number;
  change: number; // percentage change
  changeLabel?: string;
  icon?: React.ReactNode;
  format?: 'number' | 'currency' | 'percent';
}

interface KPICardsProps {
  metrics: KPIMetric[];
  isLoading?: boolean;
}

function formatValue(value: string | number, format?: string): string {
  if (typeof value === 'string') return value;
  switch (format) {
    case 'currency': return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY', maximumFractionDigits: 0 }).format(value);
    case 'percent': return `${value.toFixed(1)}%`;
    default: return new Intl.NumberFormat('ja-JP').format(value);
  }
}

export function KPICards({ metrics, isLoading }: KPICardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-white rounded-lg border p-6 animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-24 mb-3" />
            <div className="h-8 bg-gray-200 rounded w-32 mb-2" />
            <div className="h-3 bg-gray-200 rounded w-20" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {metrics.map((metric, i) => (
        <div key={i} className="bg-white rounded-lg border p-6 hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-medium text-gray-500">{metric.label}</p>
            {metric.icon && <span className="text-gray-400">{metric.icon}</span>}
          </div>
          <p className="text-2xl font-bold text-gray-900">{formatValue(metric.value, metric.format)}</p>
          <div className="flex items-center mt-2">
            <span className={`text-sm font-medium ${metric.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {metric.change >= 0 ? '\u2191' : '\u2193'} {Math.abs(metric.change).toFixed(1)}%
            </span>
            <span className="text-xs text-gray-400 ml-2">{metric.changeLabel ?? '前月比'}</span>
          </div>
        </div>
      ))}
    </div>
  );
}
KPI_CARDS

    DG_GENERATED_COUNT=$((DG_GENERATED_COUNT + 1))
    echo -e "  ${GREEN:-\033[0;32m}[DG]${NC:-\033[0m} Generated: KPI cards" >&2
}

# =============================================================================
# DG-002: チャート生成
# =============================================================================
_dg_generate_charts() {
    local output_dir="${1:-.}"

    echo -e "  ${CYAN:-\033[0;36m}[DG]${NC:-\033[0m} Generating chart components..." >&2

    local chart_file="${output_dir}/components/dashboard/Charts.tsx"
    mkdir -p "$(dirname "$chart_file")"

    cat > "$chart_file" <<'CHARTS_COMP'
'use client';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';

const COLORS = ['#2563eb', '#7c3aed', '#db2777', '#ea580c', '#16a34a', '#0891b2', '#4f46e5', '#c026d3'];

interface ChartProps {
  data: Record<string, any>[];
  title?: string;
  height?: number;
}

interface LineChartProps extends ChartProps {
  lines: { key: string; color?: string; label?: string }[];
  xKey?: string;
}

export function DashboardLineChart({ data, lines, xKey = 'date', title, height = 300 }: LineChartProps) {
  return (
    <div className="bg-white rounded-lg border p-4">
      {title && <h3 className="text-sm font-medium text-gray-700 mb-4">{title}</h3>}
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis dataKey={xKey} tick={{ fontSize: 12 }} stroke="#9ca3af" />
          <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" />
          <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb' }} />
          <Legend />
          {lines.map((line, i) => (
            <Line key={line.key} type="monotone" dataKey={line.key} name={line.label ?? line.key} stroke={line.color ?? COLORS[i % COLORS.length]} strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

interface BarChartProps extends ChartProps {
  bars: { key: string; color?: string; label?: string }[];
  xKey?: string;
  stacked?: boolean;
}

export function DashboardBarChart({ data, bars, xKey = 'name', title, height = 300, stacked = false }: BarChartProps) {
  return (
    <div className="bg-white rounded-lg border p-4">
      {title && <h3 className="text-sm font-medium text-gray-700 mb-4">{title}</h3>}
      <ResponsiveContainer width="100%" height={height}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis dataKey={xKey} tick={{ fontSize: 12 }} stroke="#9ca3af" />
          <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" />
          <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb' }} />
          <Legend />
          {bars.map((bar, i) => (
            <Bar key={bar.key} dataKey={bar.key} name={bar.label ?? bar.key} fill={bar.color ?? COLORS[i % COLORS.length]} stackId={stacked ? 'stack' : undefined} radius={[4, 4, 0, 0]} />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

interface PieChartProps extends ChartProps {
  dataKey: string;
  nameKey?: string;
}

export function DashboardPieChart({ data, dataKey, nameKey = 'name', title, height = 300 }: PieChartProps) {
  return (
    <div className="bg-white rounded-lg border p-4">
      {title && <h3 className="text-sm font-medium text-gray-700 mb-4">{title}</h3>}
      <ResponsiveContainer width="100%" height={height}>
        <PieChart>
          <Pie data={data} dataKey={dataKey} nameKey={nameKey} cx="50%" cy="50%" outerRadius={100} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
            {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

interface AreaChartProps extends ChartProps {
  areas: { key: string; color?: string; label?: string }[];
  xKey?: string;
}

export function DashboardAreaChart({ data, areas, xKey = 'date', title, height = 300 }: AreaChartProps) {
  return (
    <div className="bg-white rounded-lg border p-4">
      {title && <h3 className="text-sm font-medium text-gray-700 mb-4">{title}</h3>}
      <ResponsiveContainer width="100%" height={height}>
        <AreaChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis dataKey={xKey} tick={{ fontSize: 12 }} stroke="#9ca3af" />
          <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" />
          <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb' }} />
          <Legend />
          {areas.map((area, i) => (
            <Area key={area.key} type="monotone" dataKey={area.key} name={area.label ?? area.key} stroke={area.color ?? COLORS[i % COLORS.length]} fill={area.color ?? COLORS[i % COLORS.length]} fillOpacity={0.1} />
          ))}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
CHARTS_COMP

    DG_GENERATED_COUNT=$((DG_GENERATED_COUNT + 1))
    echo -e "  ${GREEN:-\033[0;32m}[DG]${NC:-\033[0m} Generated: chart components (Line/Bar/Pie/Area)" >&2
}

# =============================================================================
# DG-003: ダッシュボードフィルタ生成
# =============================================================================
_dg_generate_filters() {
    local output_dir="${1:-.}"

    echo -e "  ${CYAN:-\033[0;36m}[DG]${NC:-\033[0m} Generating dashboard filters..." >&2

    local filter_file="${output_dir}/components/dashboard/DashboardFilters.tsx"
    mkdir -p "$(dirname "$filter_file")"

    cat > "$filter_file" <<'DASH_FILTERS'
'use client';
import { useState, useCallback } from 'react';

interface DateRange {
  from: string;
  to: string;
}

interface DashboardFilters {
  dateRange: DateRange;
  preset: string;
  category?: string;
  status?: string;
}

interface DashboardFiltersProps {
  onFilterChange: (filters: DashboardFilters) => void;
  categories?: string[];
  statuses?: string[];
}

const PRESETS: Record<string, { label: string; days: number }> = {
  '7d': { label: '7日間', days: 7 },
  '30d': { label: '30日間', days: 30 },
  '90d': { label: '90日間', days: 90 },
  '1y': { label: '1年間', days: 365 },
};

function getDateRange(days: number): DateRange {
  const to = new Date().toISOString().split('T')[0];
  const from = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  return { from, to };
}

export function DashboardFilters({ onFilterChange, categories = [], statuses = [] }: DashboardFiltersProps) {
  const [preset, setPreset] = useState('30d');
  const [dateRange, setDateRange] = useState<DateRange>(getDateRange(30));
  const [category, setCategory] = useState('');
  const [status, setStatus] = useState('');

  const applyFilters = useCallback((overrides?: Partial<DashboardFilters>) => {
    onFilterChange({
      dateRange: overrides?.dateRange ?? dateRange,
      preset: overrides?.preset ?? preset,
      category: overrides?.category ?? category || undefined,
      status: overrides?.status ?? status || undefined,
    });
  }, [dateRange, preset, category, status, onFilterChange]);

  const handlePresetChange = (p: string) => {
    setPreset(p);
    const range = getDateRange(PRESETS[p]?.days ?? 30);
    setDateRange(range);
    applyFilters({ preset: p, dateRange: range });
  };

  return (
    <div className="flex flex-wrap items-center gap-3 p-4 bg-white rounded-lg border">
      {/* Date Presets */}
      <div className="flex gap-1">
        {Object.entries(PRESETS).map(([key, { label }]) => (
          <button key={key} onClick={() => handlePresetChange(key)} className={`px-3 py-1.5 text-sm rounded-md ${preset === key ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
            {label}
          </button>
        ))}
      </div>

      {/* Custom Date Range */}
      <div className="flex items-center gap-2">
        <input type="date" value={dateRange.from} onChange={e => { const r = { ...dateRange, from: e.target.value }; setDateRange(r); setPreset('custom'); applyFilters({ dateRange: r, preset: 'custom' }); }} className="px-2 py-1.5 text-sm border rounded-md" />
        <span className="text-gray-400">〜</span>
        <input type="date" value={dateRange.to} onChange={e => { const r = { ...dateRange, to: e.target.value }; setDateRange(r); setPreset('custom'); applyFilters({ dateRange: r, preset: 'custom' }); }} className="px-2 py-1.5 text-sm border rounded-md" />
      </div>

      {/* Category Filter */}
      {categories.length > 0 && (
        <select value={category} onChange={e => { setCategory(e.target.value); applyFilters({ category: e.target.value }); }} className="px-3 py-1.5 text-sm border rounded-md">
          <option value="">全カテゴリ</option>
          {categories.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      )}

      {/* Status Filter */}
      {statuses.length > 0 && (
        <select value={status} onChange={e => { setStatus(e.target.value); applyFilters({ status: e.target.value }); }} className="px-3 py-1.5 text-sm border rounded-md">
          <option value="">全ステータス</option>
          {statuses.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      )}
    </div>
  );
}
DASH_FILTERS

    DG_GENERATED_COUNT=$((DG_GENERATED_COUNT + 1))
    echo -e "  ${GREEN:-\033[0;32m}[DG]${NC:-\033[0m} Generated: dashboard filters" >&2
}

# =============================================================================
# DG-004: エクスポート生成
# =============================================================================
_dg_generate_export() {
    local output_dir="${1:-.}"

    echo -e "  ${CYAN:-\033[0;36m}[DG]${NC:-\033[0m} Generating dashboard export..." >&2

    local export_file="${output_dir}/lib/dashboard-export.ts"
    mkdir -p "$(dirname "$export_file")"

    cat > "$export_file" <<'DASH_EXPORT'
// Dashboard Export Utilities - Auto-generated by SoloptiLinkAI v239.0

export function exportDashboardCSV(data: Record<string, any>[], filename: string = 'dashboard_export.csv') {
  if (data.length === 0) return;
  const headers = Object.keys(data[0]);
  const bom = '\uFEFF';
  const csv = [
    headers.join(','),
    ...data.map(row => headers.map(h => {
      const v = String(row[h] ?? '');
      return v.includes(',') || v.includes('"') ? `"${v.replace(/"/g, '""')}"` : v;
    }).join(','))
  ].join('\n');
  const blob = new Blob([bom + csv], { type: 'text/csv;charset=utf-8;' });
  downloadBlob(blob, filename);
}

export function exportDashboardJSON(data: Record<string, any>[], filename: string = 'dashboard_export.json') {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  downloadBlob(blob, filename);
}

export async function exportDashboardPDF(elementId: string, filename: string = 'dashboard_report.pdf') {
  // Using html2canvas + jsPDF approach
  try {
    const element = document.getElementById(elementId);
    if (!element) throw new Error('Element not found');
    const html2canvas = (await import('html2canvas')).default;
    const { jsPDF } = await import('jspdf');
    const canvas = await html2canvas(element, { scale: 2, useCORS: true });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('l', 'mm', 'a4');
    const width = pdf.internal.pageSize.getWidth();
    const height = (canvas.height * width) / canvas.width;
    pdf.addImage(imgData, 'PNG', 0, 0, width, height);
    pdf.save(filename);
  } catch (err) {
    console.error('[EXPORT] PDF error:', err);
    throw err;
  }
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}
DASH_EXPORT

    DG_GENERATED_COUNT=$((DG_GENERATED_COUNT + 1))
    echo -e "  ${GREEN:-\033[0;32m}[DG]${NC:-\033[0m} Generated: dashboard export" >&2
}

# =============================================================================
# DG-005: リアルタイム更新生成
# =============================================================================
_dg_generate_real_time() {
    local output_dir="${1:-.}"

    echo -e "  ${CYAN:-\033[0;36m}[DG]${NC:-\033[0m} Generating real-time updates..." >&2

    local rt_file="${output_dir}/hooks/useDashboardData.ts"
    mkdir -p "$(dirname "$rt_file")"

    cat > "$rt_file" <<'REALTIME_HOOK'
'use client';
import useSWR from 'swr';
import { useState, useCallback } from 'react';

interface DashboardData {
  kpis: Record<string, any>[];
  chartData: Record<string, any>[];
  recentActivity: Record<string, any>[];
  lastUpdated: string;
}

interface DashboardFilters {
  dateRange: { from: string; to: string };
  category?: string;
  status?: string;
}

const fetcher = async (url: string) => {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
};

export function useDashboardData(filters?: DashboardFilters) {
  const params = new URLSearchParams();
  if (filters?.dateRange) {
    params.set('from', filters.dateRange.from);
    params.set('to', filters.dateRange.to);
  }
  if (filters?.category) params.set('category', filters.category);
  if (filters?.status) params.set('status', filters.status);

  const queryString = params.toString();
  const url = `/api/dashboard${queryString ? `?${queryString}` : ''}`;

  const { data, error, isLoading, mutate } = useSWR<DashboardData>(url, fetcher, {
    refreshInterval: 30000, // Auto-refresh every 30 seconds
    revalidateOnFocus: true,
    dedupingInterval: 5000,
  });

  const refresh = useCallback(() => mutate(), [mutate]);

  return {
    data, error, isLoading, refresh,
    kpis: data?.kpis ?? [],
    chartData: data?.chartData ?? [],
    recentActivity: data?.recentActivity ?? [],
    lastUpdated: data?.lastUpdated ?? null,
  };
}

// SSE-based real-time updates for critical metrics
export function useLiveMetrics(metricKeys: string[]) {
  const [metrics, setMetrics] = useState<Record<string, number>>({});

  // Only connect if browser supports EventSource
  if (typeof window !== 'undefined' && typeof EventSource !== 'undefined') {
    const eventSource = new EventSource(`/api/dashboard/live?keys=${metricKeys.join(',')}`);
    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        setMetrics(prev => ({ ...prev, ...data }));
      } catch { /* ignore parse errors */ }
    };
    eventSource.onerror = () => { eventSource.close(); };
  }

  return metrics;
}
REALTIME_HOOK

    DG_GENERATED_COUNT=$((DG_GENERATED_COUNT + 1))
    echo -e "  ${GREEN:-\033[0;32m}[DG]${NC:-\033[0m} Generated: real-time dashboard hook" >&2
}

# =============================================================================
# DG-006: プロジェクトダッシュボード品質スキャン
# =============================================================================
_dg_scan_project() {
    local project_dir="${1:-.}"

    [[ "$DG_INITIALIZED" != "true" ]] && dg_init

    echo -e "  ${CYAN:-\033[0;36m}[DG]${NC:-\033[0m} Scanning dashboard quality..." >&2

    local checks=0 passed=0

    # チャートライブラリ存在
    checks=$((checks + 1))
    if [[ -f "${project_dir}/package.json" ]] && grep -qE '"recharts"|"chart\.js"|"d3"|"nivo"' "${project_dir}/package.json" 2>/dev/null; then
        passed=$((passed + 1))
    else
        DG_ISSUES+="[NO_CHART_LIB] チャートライブラリがインストールされていません\n"
        DG_ISSUE_COUNT=$((DG_ISSUE_COUNT + 1))
    fi

    # ダッシュボードAPI存在
    checks=$((checks + 1))
    if find "$project_dir" -type f -name "route.ts" -path "*dashboard*" -not -path "*/node_modules/*" 2>/dev/null | head -1 | grep -q .; then
        passed=$((passed + 1))
    else
        DG_ISSUES+="[NO_DASHBOARD_API] ダッシュボードAPIが見つかりません\n"
        DG_ISSUE_COUNT=$((DG_ISSUE_COUNT + 1))
    fi

    # ローディング状態チェック
    checks=$((checks + 1))
    local dash_files
    dash_files=$(find "$project_dir" -type f \( -name "*.tsx" -o -name "*.jsx" \) -path "*dashboard*" -not -path "*/node_modules/*" 2>/dev/null)
    if [[ -n "$dash_files" ]]; then
        if echo "$dash_files" | xargs grep -l 'isLoading\|loading\|skeleton\|animate-pulse' 2>/dev/null | head -1 | grep -q .; then
            passed=$((passed + 1))
        else
            DG_ISSUES+="[NO_LOADING] ダッシュボードにローディング状態がありません\n"
            DG_ISSUE_COUNT=$((DG_ISSUE_COUNT + 1))
        fi
    else
        passed=$((passed + 1))
    fi

    DG_SCAN_SCORE=$(( checks > 0 ? passed * 100 / checks : 100 ))
    echo -e "  ${CYAN:-\033[0;36m}[DG]${NC:-\033[0m} Dashboard score: ${DG_SCAN_SCORE}/100" >&2
}

# =============================================================================
# レポート
# =============================================================================
dg_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Dashboard Generator v${DG_VERSION} ===${NC:-\033[0m}"
    echo -e "  Generated     : ${DG_GENERATED_COUNT}"
    echo -e "  Score         : ${DG_SCAN_SCORE}/100"
    [[ "$DG_ISSUE_COUNT" -gt 0 ]] && echo -e "  Issues        : ${DG_ISSUE_COUNT}"
}

dg_report_json() {
    cat <<EOF
{"module":"dashboard-generator","version":"${DG_VERSION}","generated":${DG_GENERATED_COUNT},"score":${DG_SCAN_SCORE},"issues":${DG_ISSUE_COUNT}}
EOF
}

dg_score() {
    echo "${DG_SCAN_SCORE:-100}"
}

# =============================================================================
# v59.0: Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "dashboard-generator" \
        --version "239.0" \
        --description "アナリティクスダッシュボード自動生成（KPI/Charts/Filters/Export/Realtime）" \
        --init "dg_init" \
        --report "dg_report" \
        --score "dg_score" \
        --enable-var "ENABLE_DG" \
        --cli-flags "--dashboard-gen:--no-dashboard-gen" \
        --init-msg "dg_init_message"
fi

# v2003.1: source時のexit codeを確実に0にする
true
