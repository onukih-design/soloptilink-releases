#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v120.0 - Contract Generator
# =============================================================================
# バックエンドとフロントエンドの間にAPI契約（単一の真実の源）を作る。
#
# 問題: smart-generation.shがステップ間で成果物を3000文字に切り詰めるため、
#        APIパス・メソッド・型情報が失われ、フロントがバックエンドと不一致になる。
#
# 解決: api_routesステップ完了後にディスク上のファイルを解析し、
#        構造化されたAPI契約JSONを生成。フロントエンド生成時にこの契約を注入。
#
# 契約内容:
#   - models: Prismaスキーマから抽出したモデル・フィールド・リレーション
#   - endpoints: APIルートから抽出したパス・メソッド・リクエスト/レスポンス型
#   - pages: 必要なフロントエンドページ一覧
#
# 全globals: CG_ prefix
# =============================================================================

[[ -n "${_CONTRACT_GENERATOR_LOADED:-}" ]] && return 0
_CONTRACT_GENERATOR_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g CG_VERSION="120.0"
declare -g CG_INITIALIZED=false
declare -g CG_CONTRACT_FILE=""
declare -g CG_MODEL_COUNT=0
declare -g CG_ENDPOINT_COUNT=0
declare -g CG_PAGE_COUNT=0

# =============================================================================
# 初期化
# =============================================================================
cg_init() {
    CG_INITIALIZED=true
    CG_MODEL_COUNT=0
    CG_ENDPOINT_COUNT=0
    CG_PAGE_COUNT=0
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Contract Generator v${CG_VERSION}"
}

# =============================================================================
# Prismaスキーマからモデル情報を抽出
# =============================================================================
cg_extract_from_schema() {
    local project_dir="${1:-.}"
    local schema_file=""

    # Prismaスキーマファイルを探す
    for candidate in \
        "${project_dir}/prisma/schema.prisma" \
        "${project_dir}/schema.prisma" \
        "${project_dir}/db/schema.prisma"; do
        if [[ -f "$candidate" ]]; then
            schema_file="$candidate"
            break
        fi
    done

    [[ -z "$schema_file" ]] && return 1

    local models_json="["
    local first=true
    local current_model=""
    local fields_json=""

    while IFS= read -r line; do
        # モデル定義の開始
        if [[ "$line" =~ ^model[[:space:]]+([A-Za-z_][A-Za-z0-9_]*)[[:space:]]*\{ ]]; then
            if [[ -n "$current_model" && -n "$fields_json" ]]; then
                [[ "$first" != "true" ]] && models_json+=","
                models_json+="{\"name\":\"${current_model}\",\"fields\":[${fields_json}]}"
                first=false
            fi
            current_model="${BASH_REMATCH[1]}"
            fields_json=""
            CG_MODEL_COUNT=$((CG_MODEL_COUNT + 1))
            continue
        fi

        # モデル内のフィールド定義
        if [[ -n "$current_model" && "$line" =~ ^[[:space:]]+([a-zA-Z_][a-zA-Z0-9_]*)[[:space:]]+([A-Za-z\[\]?]+) ]]; then
            local field_name="${BASH_REMATCH[1]}"
            local field_type="${BASH_REMATCH[2]}"

            # @relation, @@index等のディレクティブはスキップ
            [[ "$field_name" == "@@"* ]] && continue
            [[ "$field_name" == "@"* ]] && continue

            local required="true"
            [[ "$field_type" == *"?" ]] && required="false"

            [[ -n "$fields_json" ]] && fields_json+=","
            fields_json+="{\"name\":\"${field_name}\",\"type\":\"${field_type}\",\"required\":${required}}"
        fi

        # モデル定義の終了
        if [[ "$line" =~ ^\} && -n "$current_model" ]]; then
            [[ "$first" != "true" ]] && models_json+=","
            models_json+="{\"name\":\"${current_model}\",\"fields\":[${fields_json}]}"
            first=false
            current_model=""
            fields_json=""
        fi
    done < "$schema_file"

    models_json+="]"
    echo "$models_json"
}

# =============================================================================
# APIルートファイルからエンドポイント情報を抽出
# =============================================================================
cg_extract_from_api() {
    local project_dir="${1:-.}"
    local api_dir=""

    # APIディレクトリを探す
    for candidate in \
        "${project_dir}/app/api" \
        "${project_dir}/src/app/api" \
        "${project_dir}/pages/api"; do
        if [[ -d "$candidate" ]]; then
            api_dir="$candidate"
            break
        fi
    done

    [[ -z "$api_dir" ]] && echo "[]" && return 0

    local endpoints_json="["
    local first=true

    # route.tsファイルを探索
    while IFS= read -r route_file; do
        [[ -z "$route_file" ]] && continue

        # ファイルパスからAPIパスを抽出
        local rel_path="${route_file#${api_dir}}"
        rel_path="${rel_path%/route.ts}"
        rel_path="${rel_path%/route.js}"
        local api_path="/api${rel_path}"

        # 動的セグメントを変換: [id] → :id
        api_path=$(echo "$api_path" | sed 's/\[([^]]*)\]/:\1/g')

        # エクスポートされたHTTPメソッドを検出
        local methods=""
        if grep -qE 'export\s+(async\s+)?function\s+GET' "$route_file" 2>/dev/null; then
            methods+="\"GET\","
        fi
        if grep -qE 'export\s+(async\s+)?function\s+POST' "$route_file" 2>/dev/null; then
            methods+="\"POST\","
        fi
        if grep -qE 'export\s+(async\s+)?function\s+PUT' "$route_file" 2>/dev/null; then
            methods+="\"PUT\","
        fi
        if grep -qE 'export\s+(async\s+)?function\s+PATCH' "$route_file" 2>/dev/null; then
            methods+="\"PATCH\","
        fi
        if grep -qE 'export\s+(async\s+)?function\s+DELETE' "$route_file" 2>/dev/null; then
            methods+="\"DELETE\","
        fi

        # 末尾のカンマを除去
        methods="${methods%,}"

        if [[ -n "$methods" ]]; then
            [[ "$first" != "true" ]] && endpoints_json+=","
            endpoints_json+="{\"path\":\"${api_path}\",\"methods\":[${methods}],\"file\":\"${route_file#${project_dir}/}\"}"
            first=false
            CG_ENDPOINT_COUNT=$((CG_ENDPOINT_COUNT + 1))
        fi
    done < <(find "$api_dir" -name "route.ts" -o -name "route.js" 2>/dev/null | sort)

    endpoints_json+="]"
    echo "$endpoints_json"
}

# =============================================================================
# 必要なフロントエンドページを推定
# =============================================================================
cg_infer_pages() {
    local models_json="$1"

    local pages_json="["
    local first=true

    # モデル名を抽出してページを推定
    local model_names
    model_names=$(echo "$models_json" | grep -oE '"name":"[^"]*"' | sed 's/"name":"//;s/"//' | grep -vE '^(AuditLog|Session|Account|VerificationToken)$')

    while IFS= read -r model; do
        [[ -z "$model" ]] && continue

        local lower_model
        lower_model=$(echo "$model" | tr '[:upper:]' '[:lower:]' | sed 's/\([a-z]\)\([A-Z]\)/\1-\2/g' | tr '[:upper:]' '[:lower:]')
        local plural="${lower_model}s"

        [[ "$first" != "true" ]] && pages_json+=","
        pages_json+="{\"path\":\"/${plural}\",\"type\":\"list\",\"model\":\"${model}\"},"
        pages_json+="{\"path\":\"/${plural}/new\",\"type\":\"create\",\"model\":\"${model}\"},"
        pages_json+="{\"path\":\"/${plural}/[id]\",\"type\":\"detail\",\"model\":\"${model}\"},"
        pages_json+="{\"path\":\"/${plural}/[id]/edit\",\"type\":\"edit\",\"model\":\"${model}\"}"
        first=false
        CG_PAGE_COUNT=$((CG_PAGE_COUNT + 4))
    done <<< "$model_names"

    pages_json+="]"
    echo "$pages_json"
}

# =============================================================================
# 契約JSON生成（メイン関数）
# =============================================================================
cg_generate_contract() {
    local project_dir="${1:-.}"

    local contract_dir="${project_dir}/.soloptilink"
    mkdir -p "$contract_dir" 2>/dev/null || true

    CG_CONTRACT_FILE="${contract_dir}/api-contract.json"

    # 各要素を抽出
    local models
    models=$(cg_extract_from_schema "$project_dir" 2>/dev/null || echo "[]")

    local endpoints
    endpoints=$(cg_extract_from_api "$project_dir" 2>/dev/null || echo "[]")

    local pages
    pages=$(cg_infer_pages "$models" 2>/dev/null || echo "[]")

    # 契約JSONを生成
    cat > "$CG_CONTRACT_FILE" <<EOF
{
  "version": "120.0",
  "generated_at": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "models": ${models},
  "endpoints": ${endpoints},
  "pages": ${pages}
}
EOF

    echo -e "  ${GREEN:-\033[0;32m}✅ [CG] API契約生成完了: ${CG_MODEL_COUNT}モデル, ${CG_ENDPOINT_COUNT}エンドポイント, ${CG_PAGE_COUNT}ページ${NC:-\033[0m}" >&2

    echo "$CG_CONTRACT_FILE"
}

# =============================================================================
# 契約のバリデーション
# フロントエンドのfetch呼び出しが契約のエンドポイントと一致するか検証
# =============================================================================
cg_validate_contract() {
    local project_dir="${1:-.}"
    local contract_file="${2:-${project_dir}/.soloptilink/api-contract.json}"

    [[ ! -f "$contract_file" ]] && echo "契約ファイルが見つかりません" && return 1

    local issues=""
    local issue_count=0

    # フロントエンドのfetch呼び出しを検出
    local frontend_dir=""
    for candidate in "${project_dir}/app" "${project_dir}/src/app" "${project_dir}/src"; do
        [[ -d "$candidate" ]] && frontend_dir="$candidate" && break
    done

    [[ -z "$frontend_dir" ]] && return 0

    # fetch('/api/...') パターンを検索
    while IFS= read -r match; do
        [[ -z "$match" ]] && continue
        local file="${match%%:*}"
        local api_url
        api_url=$(echo "$match" | grep -oE "'/api/[^']*'" | tr -d "'" | head -1)
        [[ -z "$api_url" ]] && api_url=$(echo "$match" | grep -oE '"/api/[^"]*"' | tr -d '"' | head -1)
        [[ -z "$api_url" ]] && continue

        # 動的セグメントを正規化: ${id} → [id]
        local normalized_url
        normalized_url=$(echo "$api_url" | sed 's/\${[^}]*}/[id]/g')

        # 契約に含まれるか確認
        if ! grep -q "\"path\":\"${normalized_url}\"" "$contract_file" 2>/dev/null; then
            # [id]付きパスで再検索
            local base_path
            base_path=$(echo "$normalized_url" | sed 's|/[^/]*$||')
            if ! grep -q "\"path\":\"${base_path}" "$contract_file" 2>/dev/null; then
                issues+="[CONTRACT_MISMATCH] ${file}: fetch(${api_url}) に対応するAPIエンドポイントが契約にありません\n"
                issue_count=$((issue_count + 1))
            fi
        fi
    done < <(grep -rn "fetch\s*(" "$frontend_dir" --include="*.tsx" --include="*.ts" 2>/dev/null | grep -E "/api/" || true)

    if [[ $issue_count -gt 0 ]]; then
        echo -e "## API契約バリデーション: ${issue_count}件の不一致\n${issues}"
        return 1
    fi

    echo -e "  ${GREEN:-\033[0;32m}✅ [CG] 契約バリデーションパス${NC:-\033[0m}" >&2
    return 0
}

# =============================================================================
# 契約をプロンプトに注入（フロントエンド生成用）
# =============================================================================
cg_inject_into_prompt() {
    local contract_file="${1:-}"
    local project_dir="${2:-.}"

    [[ -z "$contract_file" ]] && contract_file="${project_dir}/.soloptilink/api-contract.json"
    [[ ! -f "$contract_file" ]] && return 0

    local contract_content
    contract_content=$(cat "$contract_file" 2>/dev/null || echo "")
    [[ -z "$contract_content" ]] && return 0

    cat <<EOF
## API契約（v120.0 Contract-First Generation - 完全準拠必須）
以下のAPI契約に完全準拠すること。URLパス・HTTPメソッド・型を1文字も変えないこと。
フロントエンドのfetch()呼び出しは、この契約のendpoints.pathと完全一致すること。
ページのルーティングは、この契約のpages.pathと完全一致すること。

\`\`\`json
${contract_content}
\`\`\`

**重要**: 上記契約に存在しないAPIパスをfetch()で呼び出してはいけません。
         上記契約に存在しないページパスにrouter.push()で遷移してはいけません。
EOF
}

# =============================================================================
# 成果物から構造化artifact抽出（3000文字切り詰めの代替）
# =============================================================================
cg_extract_key_artifacts() {
    local step_output="$1"
    local step_name="$2"

    local artifact=""

    case "$step_name" in
        schema)
            # Prismaスキーマのmodel定義部分のみ抽出
            artifact=$(echo "$step_output" | grep -A 100 "^model " | head -200)
            ;;
        types)
            # 型定義・interface・type・enum部分を抽出
            artifact=$(echo "$step_output" | grep -E "^(export\s+)?(type|interface|enum)\s+" | head -50)
            ;;
        api_routes)
            # エクスポートされた関数定義（パスとメソッド）を抽出
            artifact=$(echo "$step_output" | grep -E "(^--- FILE:|export\s+(async\s+)?function\s+(GET|POST|PUT|PATCH|DELETE))" | head -50)
            ;;
        backend_core|services)
            # 関数シグネチャとクラス定義を抽出
            artifact=$(echo "$step_output" | grep -E "(^--- FILE:|export\s+(async\s+)?function|export\s+class)" | head -50)
            ;;
        *)
            # デフォルト: ファイルマーカーと重要な行を抽出
            artifact=$(echo "$step_output" | grep -E "(^--- FILE:|export\s+|import\s+)" | head -80)
            ;;
    esac

    # 抽出結果が少なすぎる場合はフォールバック（5000文字に拡大）
    if [[ ${#artifact} -lt 100 ]]; then
        artifact="${step_output:0:5000}"
    fi

    echo "$artifact"
}

# =============================================================================
# レポート
# =============================================================================
cg_report() {
    echo -e "\n  ${BOLD:-}═══ Contract Generator v${CG_VERSION} ═══${NC:-}"
    echo -e "  モデル数       : ${CG_MODEL_COUNT}"
    echo -e "  エンドポイント数: ${CG_ENDPOINT_COUNT}"
    echo -e "  推定ページ数   : ${CG_PAGE_COUNT}"
    [[ -n "$CG_CONTRACT_FILE" ]] && echo -e "  契約ファイル   : ${CG_CONTRACT_FILE}"
}

cg_report_json() {
    cat <<EOF
{"module":"contract-generator","version":"${CG_VERSION}","models":${CG_MODEL_COUNT},"endpoints":${CG_ENDPOINT_COUNT},"pages":${CG_PAGE_COUNT}}
EOF
}

cg_score() {
    if [[ $CG_ENDPOINT_COUNT -gt 0 ]]; then
        echo 90
    elif [[ "$CG_INITIALIZED" == "true" ]]; then
        echo 50
    else
        echo 0
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "contract-generator" \
        --version "120.0" \
        --description "API契約生成（Frontend-Backend名前不一致を根絶）" \
        --init "cg_init" \
        --report "cg_report" \
        --score "cg_score" \
        --enable-var "ENABLE_CONTRACT_GENERATOR" \
        --cli-flags "--contract-generator:--no-contract-generator"
fi

# v2003.1: source時のexit codeを確実に0にする
true
