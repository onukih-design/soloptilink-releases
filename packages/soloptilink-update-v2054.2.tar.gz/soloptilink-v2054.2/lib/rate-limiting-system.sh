#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v248.0 - Rate Limiting System
# =============================================================================
# レート制限ミドルウェア、リクエストスロットリング、APIティア設定、
# レート制限レスポンスヘッダーを自動生成する。
#
# アルゴリズム対応: Sliding Window, Token Bucket, Fixed Window
#
# 機能:
#   - レート制限ミドルウェア生成
#   - リクエストスロットリング生成
#   - API ティア設定生成
#   - レート制限レスポンスヘッダー生成
#
# 全globals: RLS_ prefix
# =============================================================================

[[ -n "${_RATE_LIMITING_SYSTEM_LOADED:-}" ]] && return 0
_RATE_LIMITING_SYSTEM_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g RLS_VERSION="248.0"
declare -g RLS_INITIALIZED=false
declare -g RLS_MIDDLEWARES_GENERATED=0
declare -g RLS_TIERS_CONFIGURED=0
declare -g RLS_PROJECT_DIR=""
declare -g RLS_LOG_PREFIX="[RLS]"

# =============================================================================
# ログユーティリティ
# =============================================================================
_rls_log() { echo -e "  ${CLR_CYAN:-\033[0;36m}${RLS_LOG_PREFIX}${CLR_NC:-\033[0m} $*" >&2; }
_rls_success() { echo -e "  ${CLR_GREEN:-\033[0;32m}${RLS_LOG_PREFIX} OK${CLR_NC:-\033[0m} $*" >&2; }
_rls_warn() { echo -e "  ${CLR_YELLOW:-\033[0;33m}${RLS_LOG_PREFIX} WARN${CLR_NC:-\033[0m} $*" >&2; }
_rls_error() { echo -e "  ${CLR_RED:-\033[0;31m}${RLS_LOG_PREFIX} ERROR${CLR_NC:-\033[0m} $*" >&2; }

# =============================================================================
# 初期化
# =============================================================================
rls_init() {
    RLS_INITIALIZED=true
    RLS_MIDDLEWARES_GENERATED=0
    RLS_TIERS_CONFIGURED=0
    RLS_PROJECT_DIR="${PROJECT_DIR:-.}"
    return 0
}

# =============================================================================
# レート制限ミドルウェア生成
# =============================================================================
# Sliding Window アルゴリズムを使用したレート制限ミドルウェア。
# In-memory ストア（開発用）+ Redis ストア（本番用）対応。
#
# 使い方: _rls_generate_rate_limiter <output_dir>
# =============================================================================
_rls_generate_rate_limiter() {
    local output_dir="${1:-${RLS_PROJECT_DIR}/lib}"
    local output_file="${output_dir}/rate-limiter.ts"

    [[ "$RLS_INITIALIZED" != "true" ]] && { _rls_error "未初期化"; return 1; }

    _rls_log "レート制限ミドルウェア生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$output_file" <<'TS_RATELIMIT'
// =============================================================================
// SoloptiLinkAI v248.0 - Rate Limiter
// Sliding Window + Token Bucket + Fixed Window アルゴリズム
// =============================================================================

import { NextRequest, NextResponse } from 'next/server';

// --- Types ---
interface RateLimitConfig {
  windowMs: number;      // ウィンドウサイズ (ms)
  maxRequests: number;   // ウィンドウ内の最大リクエスト数
  algorithm?: 'sliding-window' | 'token-bucket' | 'fixed-window';
  keyGenerator?: (req: NextRequest) => string;
  skipFailedRequests?: boolean;
  message?: string;
}

interface RateLimitEntry {
  count: number;
  resetAt: number;
  tokens?: number;
  lastRefill?: number;
}

interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAt: number;
  retryAfter?: number;
}

// --- In-Memory Store ---
class MemoryStore {
  private entries = new Map<string, RateLimitEntry>();
  private cleanupInterval: ReturnType<typeof setInterval> | null = null;

  constructor() {
    // 定期クリーンアップ（メモリリーク防止）
    if (typeof setInterval !== 'undefined') {
      this.cleanupInterval = setInterval(() => this.cleanup(), 60000);
    }
  }

  get(key: string): RateLimitEntry | undefined {
    return this.entries.get(key);
  }

  set(key: string, entry: RateLimitEntry): void {
    this.entries.set(key, entry);
  }

  private cleanup(): void {
    const now = Date.now();
    for (const [key, entry] of this.entries) {
      if (entry.resetAt < now) this.entries.delete(key);
    }
  }

  destroy(): void {
    if (this.cleanupInterval) clearInterval(this.cleanupInterval);
    this.entries.clear();
  }
}

// --- Rate Limiter ---
const store = new MemoryStore();

function defaultKeyGenerator(req: NextRequest): string {
  const forwarded = req.headers.get('x-forwarded-for');
  const ip = forwarded?.split(',')[0]?.trim() || req.headers.get('x-real-ip') || 'unknown';
  return `rl:${ip}`;
}

function checkSlidingWindow(key: string, config: RateLimitConfig): RateLimitResult {
  const now = Date.now();
  const entry = store.get(key);

  if (!entry || entry.resetAt <= now) {
    store.set(key, { count: 1, resetAt: now + config.windowMs });
    return { allowed: true, remaining: config.maxRequests - 1, resetAt: now + config.windowMs };
  }

  if (entry.count >= config.maxRequests) {
    const retryAfter = Math.ceil((entry.resetAt - now) / 1000);
    return { allowed: false, remaining: 0, resetAt: entry.resetAt, retryAfter };
  }

  entry.count++;
  store.set(key, entry);
  return { allowed: true, remaining: config.maxRequests - entry.count, resetAt: entry.resetAt };
}

function checkTokenBucket(key: string, config: RateLimitConfig): RateLimitResult {
  const now = Date.now();
  const entry = store.get(key);
  const refillRate = config.maxRequests / config.windowMs;

  if (!entry) {
    store.set(key, {
      count: 0,
      resetAt: now + config.windowMs,
      tokens: config.maxRequests - 1,
      lastRefill: now,
    });
    return { allowed: true, remaining: config.maxRequests - 1, resetAt: now + config.windowMs };
  }

  // トークン補充
  const elapsed = now - (entry.lastRefill || now);
  const newTokens = Math.min(config.maxRequests, (entry.tokens || 0) + elapsed * refillRate);

  if (newTokens < 1) {
    const waitTime = Math.ceil((1 - newTokens) / refillRate / 1000);
    return { allowed: false, remaining: 0, resetAt: now + waitTime * 1000, retryAfter: waitTime };
  }

  store.set(key, {
    count: entry.count + 1,
    resetAt: now + config.windowMs,
    tokens: newTokens - 1,
    lastRefill: now,
  });

  return { allowed: true, remaining: Math.floor(newTokens - 1), resetAt: now + config.windowMs };
}

function checkFixedWindow(key: string, config: RateLimitConfig): RateLimitResult {
  const now = Date.now();
  const windowStart = Math.floor(now / config.windowMs) * config.windowMs;
  const windowKey = `${key}:${windowStart}`;
  const entry = store.get(windowKey);

  if (!entry) {
    store.set(windowKey, { count: 1, resetAt: windowStart + config.windowMs });
    return { allowed: true, remaining: config.maxRequests - 1, resetAt: windowStart + config.windowMs };
  }

  if (entry.count >= config.maxRequests) {
    const retryAfter = Math.ceil((entry.resetAt - now) / 1000);
    return { allowed: false, remaining: 0, resetAt: entry.resetAt, retryAfter };
  }

  entry.count++;
  store.set(windowKey, entry);
  return { allowed: true, remaining: config.maxRequests - entry.count, resetAt: entry.resetAt };
}

// --- Public API ---
export function rateLimit(config: RateLimitConfig) {
  const {
    algorithm = 'sliding-window',
    keyGenerator = defaultKeyGenerator,
    message = 'リクエスト数が上限に達しました。しばらくしてから再度お試しください。',
  } = config;

  return async function rateLimitMiddleware(req: NextRequest): Promise<NextResponse | null> {
    const key = keyGenerator(req);
    let result: RateLimitResult;

    switch (algorithm) {
      case 'token-bucket':
        result = checkTokenBucket(key, config);
        break;
      case 'fixed-window':
        result = checkFixedWindow(key, config);
        break;
      default:
        result = checkSlidingWindow(key, config);
    }

    if (!result.allowed) {
      return NextResponse.json(
        { error: message, retryAfter: result.retryAfter },
        {
          status: 429,
          headers: {
            'X-RateLimit-Limit': config.maxRequests.toString(),
            'X-RateLimit-Remaining': '0',
            'X-RateLimit-Reset': new Date(result.resetAt).toUTCString(),
            'Retry-After': (result.retryAfter || 60).toString(),
          },
        }
      );
    }

    return null; // Allowed - continue
  };
}

// --- プリセット ---
export const rateLimitPresets = {
  api: { windowMs: 60000, maxRequests: 60, algorithm: 'sliding-window' as const },
  auth: { windowMs: 900000, maxRequests: 5, algorithm: 'sliding-window' as const },
  upload: { windowMs: 3600000, maxRequests: 20, algorithm: 'token-bucket' as const },
  webhook: { windowMs: 60000, maxRequests: 100, algorithm: 'fixed-window' as const },
};
TS_RATELIMIT

    if [[ -f "$output_file" ]]; then
        RLS_MIDDLEWARES_GENERATED=$((RLS_MIDDLEWARES_GENERATED + 1))
        _rls_success "レート制限ミドルウェア生成完了: ${output_file}"
        return 0
    fi
    return 1
}

# =============================================================================
# リクエストスロットリング生成
# =============================================================================
_rls_generate_throttle() {
    local output_dir="${1:-${RLS_PROJECT_DIR}/lib}"
    local output_file="${output_dir}/throttle.ts"

    [[ "$RLS_INITIALIZED" != "true" ]] && { _rls_error "未初期化"; return 1; }

    _rls_log "リクエストスロットリング生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$output_file" <<'TS_THROTTLE'
// =============================================================================
// SoloptiLinkAI v248.0 - Request Throttle (Client-side)
// =============================================================================

/**
 * クライアントサイドのリクエストスロットリング。
 * API 呼び出しを一定間隔に制限し、429 エラーを予防する。
 */
export function createThrottle(intervalMs: number = 1000) {
  let lastCall = 0;
  let pending: ReturnType<typeof setTimeout> | null = null;

  return function throttle<T>(fn: () => Promise<T>): Promise<T> {
    return new Promise((resolve, reject) => {
      const now = Date.now();
      const elapsed = now - lastCall;

      if (elapsed >= intervalMs) {
        lastCall = now;
        fn().then(resolve).catch(reject);
      } else {
        const delay = intervalMs - elapsed;
        if (pending) clearTimeout(pending);
        pending = setTimeout(() => {
          lastCall = Date.now();
          fn().then(resolve).catch(reject);
        }, delay);
      }
    });
  };
}

/**
 * Debounced fetch - 連続入力時に最後のリクエストのみ送信
 */
export function createDebouncedFetch(delayMs: number = 300) {
  let controller: AbortController | null = null;
  let timeout: ReturnType<typeof setTimeout> | null = null;

  return function debouncedFetch(url: string, init?: RequestInit): Promise<Response> {
    // 前のリクエストをキャンセル
    if (controller) controller.abort();
    if (timeout) clearTimeout(timeout);

    return new Promise((resolve, reject) => {
      timeout = setTimeout(() => {
        controller = new AbortController();
        fetch(url, { ...init, signal: controller.signal })
          .then(resolve)
          .catch((err) => {
            if (err.name !== 'AbortError') reject(err);
          });
      }, delayMs);
    });
  };
}

/**
 * Retry with exponential backoff (429 対応)
 */
export async function fetchWithRetry(
  url: string,
  init?: RequestInit,
  options: { maxRetries?: number; baseDelay?: number } = {}
): Promise<Response> {
  const { maxRetries = 3, baseDelay = 1000 } = options;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const response = await fetch(url, init);

    if (response.status !== 429 || attempt === maxRetries) {
      return response;
    }

    const retryAfter = response.headers.get('Retry-After');
    const delay = retryAfter
      ? parseInt(retryAfter, 10) * 1000
      : baseDelay * Math.pow(2, attempt);

    await new Promise((resolve) => setTimeout(resolve, delay));
  }

  throw new Error('Max retries exceeded');
}
TS_THROTTLE

    if [[ -f "$output_file" ]]; then
        _rls_success "スロットリング生成完了: ${output_file}"
        return 0
    fi
    return 1
}

# =============================================================================
# API ティア設定生成
# =============================================================================
_rls_generate_tier_config() {
    local output_dir="${1:-${RLS_PROJECT_DIR}/lib}"
    local output_file="${output_dir}/api-tiers.ts"

    [[ "$RLS_INITIALIZED" != "true" ]] && { _rls_error "未初期化"; return 1; }

    _rls_log "API ティア設定生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$output_file" <<'TS_TIERS'
// =============================================================================
// SoloptiLinkAI v248.0 - API Tier Configuration
// =============================================================================

export interface ApiTier {
  name: string;
  requestsPerMinute: number;
  requestsPerHour: number;
  requestsPerDay: number;
  burstLimit: number;
  features: string[];
}

export const apiTiers: Record<string, ApiTier> = {
  free: {
    name: 'Free',
    requestsPerMinute: 10,
    requestsPerHour: 100,
    requestsPerDay: 1000,
    burstLimit: 5,
    features: ['basic-api', 'read-only'],
  },
  starter: {
    name: 'Starter',
    requestsPerMinute: 30,
    requestsPerHour: 500,
    requestsPerDay: 5000,
    burstLimit: 15,
    features: ['basic-api', 'read-write', 'webhooks'],
  },
  professional: {
    name: 'Professional',
    requestsPerMinute: 60,
    requestsPerHour: 2000,
    requestsPerDay: 20000,
    burstLimit: 30,
    features: ['basic-api', 'read-write', 'webhooks', 'bulk-operations', 'priority-support'],
  },
  enterprise: {
    name: 'Enterprise',
    requestsPerMinute: 300,
    requestsPerHour: 10000,
    requestsPerDay: 100000,
    burstLimit: 100,
    features: ['basic-api', 'read-write', 'webhooks', 'bulk-operations', 'priority-support', 'dedicated-support', 'custom-limits'],
  },
};

export function getTierForUser(plan: string): ApiTier {
  return apiTiers[plan] || apiTiers.free;
}

export function isWithinTierLimits(
  tier: ApiTier,
  currentMinute: number,
  currentHour: number,
  currentDay: number
): { allowed: boolean; reason?: string } {
  if (currentMinute >= tier.requestsPerMinute) {
    return { allowed: false, reason: `Per-minute limit (${tier.requestsPerMinute}) exceeded` };
  }
  if (currentHour >= tier.requestsPerHour) {
    return { allowed: false, reason: `Per-hour limit (${tier.requestsPerHour}) exceeded` };
  }
  if (currentDay >= tier.requestsPerDay) {
    return { allowed: false, reason: `Per-day limit (${tier.requestsPerDay}) exceeded` };
  }
  return { allowed: true };
}
TS_TIERS

    if [[ -f "$output_file" ]]; then
        RLS_TIERS_CONFIGURED=$((RLS_TIERS_CONFIGURED + 1))
        _rls_success "API ティア設定生成完了: ${output_file}"
        return 0
    fi
    return 1
}

# =============================================================================
# レート制限レスポンスヘッダー生成
# =============================================================================
_rls_generate_headers() {
    local output_dir="${1:-${RLS_PROJECT_DIR}/lib}"
    local output_file="${output_dir}/rate-limit-headers.ts"

    [[ "$RLS_INITIALIZED" != "true" ]] && { _rls_error "未初期化"; return 1; }

    _rls_log "レート制限ヘッダーユーティリティ生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$output_file" <<'TS_HEADERS'
// =============================================================================
// SoloptiLinkAI v248.0 - Rate Limit Response Headers
// RFC 6585 / draft-ietf-httpapi-ratelimit-headers 準拠
// =============================================================================

interface RateLimitInfo {
  limit: number;
  remaining: number;
  resetAt: Date;
  policy?: string;
}

/**
 * レート制限ヘッダーを Response に追加する
 */
export function addRateLimitHeaders(
  headers: Headers,
  info: RateLimitInfo
): void {
  // Standard headers
  headers.set('X-RateLimit-Limit', info.limit.toString());
  headers.set('X-RateLimit-Remaining', info.remaining.toString());
  headers.set('X-RateLimit-Reset', Math.ceil(info.resetAt.getTime() / 1000).toString());

  // IETF draft headers
  headers.set('RateLimit-Limit', info.limit.toString());
  headers.set('RateLimit-Remaining', info.remaining.toString());
  headers.set('RateLimit-Reset', Math.ceil((info.resetAt.getTime() - Date.now()) / 1000).toString());

  if (info.policy) {
    headers.set('RateLimit-Policy', info.policy);
  }
}

/**
 * 429 レスポンスを生成する
 */
export function createRateLimitResponse(
  info: RateLimitInfo,
  message?: string
): Response {
  const retryAfter = Math.ceil((info.resetAt.getTime() - Date.now()) / 1000);
  const headers = new Headers({
    'Content-Type': 'application/json',
    'Retry-After': retryAfter.toString(),
  });
  addRateLimitHeaders(headers, info);

  return new Response(
    JSON.stringify({
      error: 'Too Many Requests',
      message: message || 'Rate limit exceeded. Please retry later.',
      retryAfter,
    }),
    { status: 429, headers }
  );
}
TS_HEADERS

    if [[ -f "$output_file" ]]; then
        _rls_success "レート制限ヘッダー生成完了: ${output_file}"
        return 0
    fi
    return 1
}

# =============================================================================
# プロンプト注入
# =============================================================================
_rls_inject_prompt() {
    cat <<'PROMPT'
## [RLS] レート制限ルール

### エンドポイント別制限
- 認証 (login/register): 5回/15分
- API 一般: 60回/分
- ファイルアップロード: 20回/時
- Webhook: 100回/分

### 実装必須事項
- 全 API ルートにレート制限ミドルウェアを適用
- 429 レスポンスに X-RateLimit-* ヘッダーを含める
- Retry-After ヘッダーでクライアントに待機時間を通知
- IP + API Key の組み合わせでキー生成

### クライアント側
- 429 時に Retry-After に従い自動リトライ
- Exponential backoff 実装
- バースト防止のためスロットリング実装
PROMPT
}

# =============================================================================
# レポート
# =============================================================================
rls_report() {
    echo -e "\n  ${BOLD:-}--- Rate Limiting System v${RLS_VERSION} ---${NC:-}"
    echo -e "  ミドルウェア生成  : ${RLS_MIDDLEWARES_GENERATED}"
    echo -e "  ティア設定数      : ${RLS_TIERS_CONFIGURED}"
}

rls_report_json() {
    cat <<EOF
{"module":"rate-limiting-system","version":"${RLS_VERSION}","middlewares":${RLS_MIDDLEWARES_GENERATED},"tiers":${RLS_TIERS_CONFIGURED}}
EOF
}

rls_score() {
    if [[ "$RLS_INITIALIZED" != "true" ]]; then echo 0; return; fi
    local score=70
    [[ $RLS_MIDDLEWARES_GENERATED -gt 0 ]] && score=$((score + 20))
    [[ $RLS_TIERS_CONFIGURED -gt 0 ]] && score=$((score + 10))
    echo "$score"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "rate-limiting-system" \
        --version "248.0" \
        --description "Sliding Window/Token Bucket レート制限 + API ティア管理" \
        --init "rls_init" \
        --report "rls_report" \
        --score "rls_score" \
        --enable-var "ENABLE_RATE_LIMITING" \
        --cli-flags "--rate-limit:--no-rate-limit"
fi

# v2003.1: source時のexit codeを確実に0にする
true
