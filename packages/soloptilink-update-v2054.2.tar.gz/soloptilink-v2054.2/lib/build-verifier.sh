#!/usr/bin/env bash
# ============================================================
# SoloptiLink Chain v13.0 - Build Verifier Module
# ============================================================
# Runs actual build commands (install, build, lint) against the
# generated project and verifies that they succeed. When a build
# fails the module parses error output and produces a structured
# error report that the healer module can consume to auto-fix.
#
# v13.0 Features:
#   - Auto-detect stack (Node/Python/Rust/Go/Static)
#   - Run install, build, lint as separate verifiable steps
#   - Build-fix loop: parse errors → structured report → healer
#   - Timeout-aware execution (gtimeout / timeout fallback)
#   - Per-step exit code & stderr capture
#   - JSON-formatted error reports for downstream consumers
#
# Usage: source lib/build-verifier.sh
# ============================================================

# sourceされるライブラリなので set -euo pipefail は設定しない

# --- Load guard --------------------------------------------------------------
[[ -n "${_BV_LOADED:-}" ]] && return 0
_BV_LOADED=1

# --- Colour constants (BV_ prefix) ------------------------------------------
BV_GREEN='\033[0;32m'   BV_YELLOW='\033[0;33m'  BV_RED='\033[0;31m'
BV_CYAN='\033[0;36m'    BV_PURPLE='\033[0;35m'  BV_BOLD='\033[1m'
BV_DIM='\033[2m'        BV_NC='\033[0m'

# --- Global state (BV_ prefix) ----------------------------------------------
BV_PROJECT_DIR=""
BV_LOG_DIR=""
BV_LOG_FILE=""
BV_STACK=""                # detected stack: node | python | rust | go | static | unknown
BV_HAS_LOCKFILE=false      # whether a lockfile (package-lock / yarn.lock / pnpm-lock) exists
BV_TIMEOUT="${BV_TIMEOUT:-180}"   # per-command timeout in seconds

# Step results
BV_INSTALL_RC=""
BV_INSTALL_OUTPUT=""
BV_BUILD_RC=""
BV_BUILD_OUTPUT=""
BV_LINT_RC=""
BV_LINT_OUTPUT=""

# Error collection
BV_ERROR_COUNT=0
BV_WARNING_COUNT=0
BV_ERRORS_JSON="[]"        # JSON array of structured error objects

# ============================================================
# Helper: _bv_log(level, message)
# Prints a coloured log line and optionally appends to the log file.
# Levels: INFO, SUCCESS, WARN, ERROR, STEP, SECTION
# ============================================================
_bv_log() {
    local level="$1" message="$2" color="${BV_NC}"
    case "$level" in
        INFO|SUCCESS) color="${BV_GREEN}"  ;;
        WARN)         color="${BV_YELLOW}" ;;
        ERROR|FAIL)   color="${BV_RED}"    ;;
        STEP)         color="${BV_CYAN}"   ;;
        SECTION)      color="${BV_PURPLE}" ;;
    esac
    echo -e "  ${color}[BUILD-VERIFY:${level}]${BV_NC} ${message}"
    if [[ -n "$BV_LOG_FILE" ]]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${level}] ${message}" >> "$BV_LOG_FILE" 2>/dev/null || true
    fi
}

# ============================================================
# Helper: _bv_run_with_timeout(cmd, timeout_sec)
# Runs a command string under a timeout. Returns exit code.
# Stdout+stderr are captured into the global BV__LAST_OUTPUT.
# ============================================================
BV__LAST_OUTPUT=""
_bv_run_with_timeout() {
    local cmd="$1" timeout_sec="${2:-$BV_TIMEOUT}"
    local exit_code=0
    if command -v timeout &>/dev/null; then
        BV__LAST_OUTPUT=$(timeout "${timeout_sec}" bash -c "$cmd" 2>&1) || exit_code=$?
    elif command -v gtimeout &>/dev/null; then
        BV__LAST_OUTPUT=$(gtimeout "${timeout_sec}" bash -c "$cmd" 2>&1) || exit_code=$?
    else
        # No timeout command available; run directly
        BV__LAST_OUTPUT=$(bash -c "$cmd" 2>&1) || exit_code=$?
    fi
    # exit code 124 = timeout killed
    if [[ $exit_code -eq 124 ]]; then
        _bv_log "WARN" "コマンドタイムアウト (${timeout_sec}秒): ${cmd:0:80}"
    fi
    return $exit_code
}

# ============================================================
# Helper: _bv_append_error(step, file, line, message, raw_output)
# Appends a structured error entry to BV_ERRORS_JSON.
# ============================================================
_bv_append_error() {
    local step="$1" file="${2:-}" line="${3:-}" message="${4:-}" raw="${5:-}"
    (( BV_ERROR_COUNT++ ))
    # Escape JSON special characters in values
    local esc_msg esc_raw esc_file
    esc_msg=$(printf '%s' "$message" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\t/\\t/g' | tr '\n' ' ')
    esc_raw=$(printf '%s' "${raw:0:1000}" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\t/\\t/g' | tr '\n' ' ')
    esc_file=$(printf '%s' "$file" | sed 's/\\/\\\\/g; s/"/\\"/g')
    local entry
    entry=$(printf '{"step":"%s","file":"%s","line":"%s","message":"%s","raw":"%s","timestamp":"%s"}' \
        "$step" "$esc_file" "$line" "$esc_msg" "$esc_raw" "$(date '+%Y-%m-%dT%H:%M:%S')")
    # Append to JSON array
    if [[ "$BV_ERRORS_JSON" == "[]" ]]; then
        BV_ERRORS_JSON="[${entry}]"
    else
        BV_ERRORS_JSON="${BV_ERRORS_JSON%]},${entry}]"
    fi
}

# ============================================================
# Helper: _bv_parse_node_errors(output, step)
# Parses typical Node.js / TypeScript build/lint error patterns
# and appends structured entries.
# ============================================================
_bv_parse_node_errors() {
    local output="$1" step="$2"
    # Pattern: filepath(line,col): error TS... or filepath:line:col - error
    # Pre-compile regex patterns into variables for bash 5.3+ compatibility
    local re_ts='^([^(]+)[(]([0-9]+),[0-9]+[)]:[[:space:]]*error[[:space:]]+(.*)'
    local re_eslint='^([^:]+):([0-9]+):[0-9]+:[[:space:]]*(error|Error)[[:space:]]+(.*)'
    local re_module='^(Module not found|Error|SyntaxError|TypeError):(.+)'
    local re_npm='^npm[[:space:]]ERR![[:space:]](.+)'
    while IFS= read -r line; do
        local file="" lineno="" msg=""
        # TypeScript style: src/foo.ts(10,5): error TS2304: ...
        if [[ "$line" =~ $re_ts ]]; then
            file="${BASH_REMATCH[1]}"
            lineno="${BASH_REMATCH[2]}"
            msg="${BASH_REMATCH[3]}"
        # ESLint / generic style: /path/file.ts:10:5: error ...
        elif [[ "$line" =~ $re_eslint ]]; then
            file="${BASH_REMATCH[1]}"
            lineno="${BASH_REMATCH[2]}"
            msg="${BASH_REMATCH[4]}"
        # Next.js / Webpack: Module not found: Error: Can't resolve ...
        elif [[ "$line" =~ $re_module ]]; then
            msg="${BASH_REMATCH[1]}:${BASH_REMATCH[2]}"
        # npm ERR! lines
        elif [[ "$line" =~ $re_npm ]]; then
            msg="npm error: ${BASH_REMATCH[1]}"
        else
            continue
        fi
        _bv_append_error "$step" "$file" "$lineno" "$msg" "$line"
    done <<< "$output"
}

# ============================================================
# Helper: _bv_parse_python_errors(output, step)
# Parses typical Python build/lint error patterns.
# ============================================================
_bv_parse_python_errors() {
    local output="$1" step="$2"
    while IFS= read -r line; do
        local file="" lineno="" msg=""
        # SyntaxError: File "foo.py", line 10
        if [[ "$line" =~ File[[:space:]]\"([^\"]+)\",?[[:space:]]line[[:space:]]([0-9]+) ]]; then
            file="${BASH_REMATCH[1]}"
            lineno="${BASH_REMATCH[2]}"
            msg="$line"
        # flake8/pylint: foo.py:10:5: E302 ...
        elif [[ "$line" =~ ^([^:]+\.py):([0-9]+):[0-9]+:[[:space:]]*(E|W|F|C)([0-9]+[[:space:]].+) ]]; then
            file="${BASH_REMATCH[1]}"
            lineno="${BASH_REMATCH[2]}"
            msg="${BASH_REMATCH[3]}${BASH_REMATCH[4]}"
        # ModuleNotFoundError / ImportError
        elif [[ "$line" =~ (ModuleNotFoundError|ImportError):(.+) ]]; then
            msg="${BASH_REMATCH[1]}:${BASH_REMATCH[2]}"
        else
            continue
        fi
        _bv_append_error "$step" "$file" "$lineno" "$msg" "$line"
    done <<< "$output"
}

# ============================================================
# Helper: _bv_parse_generic_errors(output, step)
# Fallback parser for any stack; catches common error patterns.
# ============================================================
_bv_parse_generic_errors() {
    local output="$1" step="$2"
    while IFS= read -r line; do
        # Lines containing "error" (case-insensitive) that look like real errors
        if [[ "$line" =~ [Ee]rror[[:space:]]*:(.+) ]]; then
            _bv_append_error "$step" "" "" "${line:0:300}" "$line"
        elif [[ "$line" =~ ^FAILED|^FATAL|panic: ]]; then
            _bv_append_error "$step" "" "" "${line:0:300}" "$line"
        fi
    done <<< "$output"
}

# ============================================================
# bv_init(project_dir)
# Initialise the build verifier for a given project directory.
# Creates log directories and resets all state variables.
# ============================================================
bv_init() {
    local project_dir="${1:?bv_init: project_dir required}"
    BV_PROJECT_DIR="$(cd "$project_dir" 2>/dev/null && pwd)" || {
        _bv_log "ERROR" "ディレクトリが見つかりません: $project_dir"
        return 1
    }
    BV_LOG_DIR="${BV_PROJECT_DIR}/docs/chain-logs"
    BV_LOG_FILE="${BV_LOG_DIR}/build-verifier_$(date +%Y%m%d_%H%M%S).log"
    mkdir -p "$BV_LOG_DIR" 2>/dev/null || true

    # Reset state
    BV_STACK=""
    BV_HAS_LOCKFILE=false
    BV_INSTALL_RC="" ; BV_INSTALL_OUTPUT=""
    BV_BUILD_RC=""   ; BV_BUILD_OUTPUT=""
    BV_LINT_RC=""    ; BV_LINT_OUTPUT=""
    BV_ERROR_COUNT=0
    BV_WARNING_COUNT=0
    BV_ERRORS_JSON="[]"

    _bv_log "INFO" "Build Verifier 初期化: ${BV_PROJECT_DIR}"
    bv_detect_stack "$BV_PROJECT_DIR"
    return 0
}

# ============================================================
# bv_detect_stack(project_dir)
# Auto-detect the project's technology stack by examining marker
# files (package.json, requirements.txt, Cargo.toml, go.mod, etc.).
# Sets BV_STACK and BV_HAS_LOCKFILE.
# ============================================================
bv_detect_stack() {
    local dir="${1:-$BV_PROJECT_DIR}"
    BV_STACK="unknown"
    BV_HAS_LOCKFILE=false

    # Node.js / TypeScript
    if [[ -f "${dir}/package.json" ]]; then
        BV_STACK="node"
        # Check for lockfile
        if [[ -f "${dir}/package-lock.json" || -f "${dir}/yarn.lock" || -f "${dir}/pnpm-lock.yaml" ]]; then
            BV_HAS_LOCKFILE=true
        fi
        # Refine: TypeScript?
        if [[ -f "${dir}/tsconfig.json" ]]; then
            BV_STACK="typescript"
        fi
    # Python
    elif [[ -f "${dir}/requirements.txt" || -f "${dir}/pyproject.toml" || -f "${dir}/setup.py" || -f "${dir}/Pipfile" ]]; then
        BV_STACK="python"
        if [[ -f "${dir}/Pipfile.lock" || -f "${dir}/poetry.lock" ]]; then
            BV_HAS_LOCKFILE=true
        fi
    # Rust
    elif [[ -f "${dir}/Cargo.toml" ]]; then
        BV_STACK="rust"
        [[ -f "${dir}/Cargo.lock" ]] && BV_HAS_LOCKFILE=true
    # Go
    elif [[ -f "${dir}/go.mod" ]]; then
        BV_STACK="go"
        [[ -f "${dir}/go.sum" ]] && BV_HAS_LOCKFILE=true
    # Static (HTML/CSS/JS without package.json)
    elif ls "${dir}"/*.html &>/dev/null 2>&1; then
        BV_STACK="static"
    fi

    _bv_log "INFO" "検出スタック: ${BV_BOLD}${BV_STACK}${BV_NC}  lockfile=${BV_HAS_LOCKFILE}"
    return 0
}

# ============================================================
# bv_run_install(project_dir)
# Run dependency installation for the detected stack.
# Returns 0 on success, 1 on failure (errors are captured).
# ============================================================
bv_run_install() {
    local dir="${1:-$BV_PROJECT_DIR}"
    _bv_log "STEP" "依存関係インストール開始 (${BV_STACK})"

    local cmd=""
    case "$BV_STACK" in
        node|typescript)
            # Prefer the package manager matching the lockfile
            if [[ -f "${dir}/pnpm-lock.yaml" ]] && command -v pnpm &>/dev/null; then
                cmd="cd '${dir}' && pnpm install --frozen-lockfile 2>&1 || pnpm install 2>&1"
            elif [[ -f "${dir}/yarn.lock" ]] && command -v yarn &>/dev/null; then
                cmd="cd '${dir}' && yarn install --frozen-lockfile 2>&1 || yarn install 2>&1"
            else
                cmd="cd '${dir}' && npm ci 2>&1 || npm install 2>&1"
            fi
            ;;
        python)
            if [[ -f "${dir}/Pipfile" ]] && command -v pipenv &>/dev/null; then
                cmd="cd '${dir}' && pipenv install 2>&1"
            elif [[ -f "${dir}/pyproject.toml" ]] && command -v poetry &>/dev/null; then
                cmd="cd '${dir}' && poetry install 2>&1"
            elif [[ -f "${dir}/requirements.txt" ]]; then
                cmd="cd '${dir}' && pip install -r requirements.txt 2>&1"
            else
                _bv_log "WARN" "Python依存ファイルが見つかりません"
                BV_INSTALL_RC=0; BV_INSTALL_OUTPUT=""; return 0
            fi
            ;;
        rust)
            cmd="cd '${dir}' && cargo fetch 2>&1"
            ;;
        go)
            cmd="cd '${dir}' && go mod download 2>&1"
            ;;
        static)
            _bv_log "INFO" "静的プロジェクト: インストール不要"
            BV_INSTALL_RC=0; BV_INSTALL_OUTPUT=""; return 0
            ;;
        *)
            _bv_log "WARN" "不明なスタック: インストールスキップ"
            BV_INSTALL_RC=0; BV_INSTALL_OUTPUT=""; return 0
            ;;
    esac

    _bv_run_with_timeout "$cmd" "$BV_TIMEOUT"
    BV_INSTALL_RC=$?
    BV_INSTALL_OUTPUT="$BV__LAST_OUTPUT"

    if [[ $BV_INSTALL_RC -eq 0 ]]; then
        _bv_log "SUCCESS" "依存関係インストール完了"
    else
        _bv_log "ERROR" "依存関係インストール失敗 (exit=${BV_INSTALL_RC})"
        # Parse errors based on stack
        case "$BV_STACK" in
            node|typescript) _bv_parse_node_errors "$BV_INSTALL_OUTPUT" "install" ;;
            python)          _bv_parse_python_errors "$BV_INSTALL_OUTPUT" "install" ;;
            *)               _bv_parse_generic_errors "$BV_INSTALL_OUTPUT" "install" ;;
        esac
    fi
    return $BV_INSTALL_RC
}

# ============================================================
# bv_run_build(project_dir)
# Run the build command for the detected stack.
# For Node projects, checks package.json for a "build" script.
# Returns 0 on success, 1 on failure.
# ============================================================
bv_run_build() {
    local dir="${1:-$BV_PROJECT_DIR}"
    _bv_log "STEP" "ビルド実行開始 (${BV_STACK})"

    local cmd=""
    case "$BV_STACK" in
        node|typescript)
            # Check if a build script exists in package.json
            if [[ -f "${dir}/package.json" ]] && grep -q '"build"' "${dir}/package.json" 2>/dev/null; then
                if [[ -f "${dir}/pnpm-lock.yaml" ]] && command -v pnpm &>/dev/null; then
                    cmd="cd '${dir}' && pnpm run build 2>&1"
                elif [[ -f "${dir}/yarn.lock" ]] && command -v yarn &>/dev/null; then
                    cmd="cd '${dir}' && yarn build 2>&1"
                else
                    cmd="cd '${dir}' && npm run build 2>&1"
                fi
            else
                _bv_log "INFO" "ビルドスクリプトなし: TypeScript tsc チェック"
                if [[ -f "${dir}/tsconfig.json" ]]; then
                    cmd="cd '${dir}' && npx tsc --noEmit 2>&1"
                else
                    _bv_log "INFO" "ビルドステップ不要"
                    BV_BUILD_RC=0; BV_BUILD_OUTPUT=""; return 0
                fi
            fi
            ;;
        python)
            # Python: check for setup.py build or pyproject.toml build
            if [[ -f "${dir}/setup.py" ]]; then
                cmd="cd '${dir}' && python setup.py check 2>&1"
            elif [[ -f "${dir}/pyproject.toml" ]] && command -v poetry &>/dev/null; then
                cmd="cd '${dir}' && poetry build --no-interaction 2>&1"
            else
                # Syntax check all .py files
                cmd="cd '${dir}' && python -m py_compile \$(find . -name '*.py' -not -path '*/venv/*' -not -path '*/.venv/*' -not -path '*/__pycache__/*' | head -50) 2>&1"
            fi
            ;;
        rust)
            cmd="cd '${dir}' && cargo build 2>&1"
            ;;
        go)
            cmd="cd '${dir}' && go build ./... 2>&1"
            ;;
        static)
            _bv_log "INFO" "静的プロジェクト: ビルド不要"
            BV_BUILD_RC=0; BV_BUILD_OUTPUT=""; return 0
            ;;
        *)
            _bv_log "WARN" "不明なスタック: ビルドスキップ"
            BV_BUILD_RC=0; BV_BUILD_OUTPUT=""; return 0
            ;;
    esac

    _bv_run_with_timeout "$cmd" "$BV_TIMEOUT"
    BV_BUILD_RC=$?
    BV_BUILD_OUTPUT="$BV__LAST_OUTPUT"

    if [[ $BV_BUILD_RC -eq 0 ]]; then
        _bv_log "SUCCESS" "ビルド成功"
    else
        _bv_log "ERROR" "ビルド失敗 (exit=${BV_BUILD_RC})"
        case "$BV_STACK" in
            node|typescript) _bv_parse_node_errors "$BV_BUILD_OUTPUT" "build" ;;
            python)          _bv_parse_python_errors "$BV_BUILD_OUTPUT" "build" ;;
            *)               _bv_parse_generic_errors "$BV_BUILD_OUTPUT" "build" ;;
        esac
    fi
    return $BV_BUILD_RC
}

# ============================================================
# bv_run_lint(project_dir)
# Run linting for the detected stack.
# Returns 0 on success, 1 on failure (lint warnings are captured
# but do not cause a non-zero overall verification status).
# ============================================================
bv_run_lint() {
    local dir="${1:-$BV_PROJECT_DIR}"
    _bv_log "STEP" "Lint実行開始 (${BV_STACK})"

    local cmd=""
    case "$BV_STACK" in
        node|typescript)
            # Check if lint script exists in package.json
            if [[ -f "${dir}/package.json" ]] && grep -q '"lint"' "${dir}/package.json" 2>/dev/null; then
                if [[ -f "${dir}/pnpm-lock.yaml" ]] && command -v pnpm &>/dev/null; then
                    cmd="cd '${dir}' && pnpm run lint 2>&1"
                elif [[ -f "${dir}/yarn.lock" ]] && command -v yarn &>/dev/null; then
                    cmd="cd '${dir}' && yarn lint 2>&1"
                else
                    cmd="cd '${dir}' && npm run lint 2>&1"
                fi
            elif [[ -f "${dir}/node_modules/.bin/eslint" ]]; then
                cmd="cd '${dir}' && npx eslint . --ext .js,.jsx,.ts,.tsx --max-warnings 0 2>&1"
            else
                _bv_log "INFO" "Lintツール未検出: スキップ"
                BV_LINT_RC=0; BV_LINT_OUTPUT=""; return 0
            fi
            ;;
        python)
            if command -v ruff &>/dev/null; then
                cmd="cd '${dir}' && ruff check . 2>&1"
            elif command -v flake8 &>/dev/null; then
                cmd="cd '${dir}' && flake8 --max-line-length 120 . 2>&1"
            elif command -v pylint &>/dev/null; then
                cmd="cd '${dir}' && pylint --disable=all --enable=E \$(find . -name '*.py' -not -path '*/venv/*' -not -path '*/.venv/*' | head -30) 2>&1"
            else
                _bv_log "INFO" "Python lintツール未検出: スキップ"
                BV_LINT_RC=0; BV_LINT_OUTPUT=""; return 0
            fi
            ;;
        rust)
            cmd="cd '${dir}' && cargo clippy -- -D warnings 2>&1"
            ;;
        go)
            if command -v golangci-lint &>/dev/null; then
                cmd="cd '${dir}' && golangci-lint run ./... 2>&1"
            else
                cmd="cd '${dir}' && go vet ./... 2>&1"
            fi
            ;;
        static)
            # For static sites, check HTML validity if htmlhint is available
            if command -v htmlhint &>/dev/null; then
                cmd="cd '${dir}' && htmlhint '**/*.html' 2>&1"
            else
                _bv_log "INFO" "静的プロジェクト: Lintスキップ"
                BV_LINT_RC=0; BV_LINT_OUTPUT=""; return 0
            fi
            ;;
        *)
            _bv_log "WARN" "不明なスタック: Lintスキップ"
            BV_LINT_RC=0; BV_LINT_OUTPUT=""; return 0
            ;;
    esac

    _bv_run_with_timeout "$cmd" "$BV_TIMEOUT"
    BV_LINT_RC=$?
    BV_LINT_OUTPUT="$BV__LAST_OUTPUT"

    if [[ $BV_LINT_RC -eq 0 ]]; then
        _bv_log "SUCCESS" "Lint成功 (問題なし)"
    else
        _bv_log "WARN" "Lint警告/エラー検出 (exit=${BV_LINT_RC})"
        case "$BV_STACK" in
            node|typescript) _bv_parse_node_errors "$BV_LINT_OUTPUT" "lint" ;;
            python)          _bv_parse_python_errors "$BV_LINT_OUTPUT" "lint" ;;
            *)               _bv_parse_generic_errors "$BV_LINT_OUTPUT" "lint" ;;
        esac
    fi
    return $BV_LINT_RC
}

# ============================================================
# bv_verify_all(project_dir)
# Run the full verification pipeline: install → build → lint.
# Returns 0 only if install AND build succeed. Lint failures
# are recorded but do not block (return warning).
#
# Return codes:
#   0 = all passed
#   1 = install or build failed (critical)
#   2 = install+build passed, lint has warnings
# ============================================================
bv_verify_all() {
    local dir="${1:-$BV_PROJECT_DIR}"
    [[ -z "$BV_STACK" ]] && bv_init "$dir"

    _bv_log "SECTION" "========== Build Verification 開始 =========="
    _bv_log "INFO" "プロジェクト: ${dir}"
    _bv_log "INFO" "スタック: ${BV_STACK}  lockfile: ${BV_HAS_LOCKFILE}"

    local overall=0

    # Step 1: Install
    if ! bv_run_install "$dir"; then
        _bv_log "FAIL" "インストール失敗 - ビルド検証中断"
        overall=1
    fi

    # Step 2: Build (only if install succeeded)
    if [[ $overall -eq 0 ]]; then
        if ! bv_run_build "$dir"; then
            _bv_log "FAIL" "ビルド失敗"
            overall=1
        fi
    fi

    # Step 3: Lint (run even if build failed, for additional diagnostics)
    bv_run_lint "$dir"
    local lint_rc=$?

    # Determine final status
    if [[ $overall -ne 0 ]]; then
        _bv_log "FAIL" "Build Verification 失敗: エラー ${BV_ERROR_COUNT}件"
        _bv_log "INFO" "エラーレポートは bv_get_errors() で取得可能"
        return 1
    elif [[ $lint_rc -ne 0 ]]; then
        _bv_log "WARN" "ビルド成功、Lint警告あり: ${BV_ERROR_COUNT}件"
        return 2
    else
        _bv_log "SUCCESS" "Build Verification 完全成功"
        return 0
    fi
}

# ============================================================
# bv_get_errors()
# Returns the structured error report as a JSON string.
# Format: { "stack": "...", "error_count": N, "warning_count": N,
#           "install_rc": N, "build_rc": N, "lint_rc": N,
#           "errors": [ ... ] }
# ============================================================
bv_get_errors() {
    local report
    report=$(printf '{
  "stack": "%s",
  "project_dir": "%s",
  "error_count": %d,
  "warning_count": %d,
  "install_rc": "%s",
  "build_rc": "%s",
  "lint_rc": "%s",
  "install_output_tail": "%s",
  "build_output_tail": "%s",
  "lint_output_tail": "%s",
  "errors": %s,
  "generated_at": "%s"
}' \
    "$BV_STACK" \
    "$BV_PROJECT_DIR" \
    "$BV_ERROR_COUNT" \
    "$BV_WARNING_COUNT" \
    "${BV_INSTALL_RC:-N/A}" \
    "${BV_BUILD_RC:-N/A}" \
    "${BV_LINT_RC:-N/A}" \
    "$(printf '%s' "${BV_INSTALL_OUTPUT:(-200)}" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')" \
    "$(printf '%s' "${BV_BUILD_OUTPUT:(-200)}" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')" \
    "$(printf '%s' "${BV_LINT_OUTPUT:(-200)}" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')" \
    "$(type -t causal_healer_enrich_report &>/dev/null && causal_healer_enrich_report "$BV_ERRORS_JSON" || printf '%s' "$BV_ERRORS_JSON")" \
    "$(date '+%Y-%m-%dT%H:%M:%S')")
    echo "$report"

    # Also persist to log directory
    if [[ -n "$BV_LOG_DIR" ]]; then
        echo "$report" > "${BV_LOG_DIR}/build-errors_$(date +%Y%m%d_%H%M%S).json" 2>/dev/null || true
    fi
}

# ============================================================
# bv_summary()
# Print a human-readable summary of the last verification run.
# ============================================================
bv_summary() {
    echo ""
    echo -e "  ${BV_BOLD}╔══════════════════════════════════════════════╗${BV_NC}"
    echo -e "  ${BV_BOLD}║         Build Verification Summary           ║${BV_NC}"
    echo -e "  ${BV_BOLD}╠══════════════════════════════════════════════╣${BV_NC}"
    printf  "  ${BV_BOLD}║${BV_NC} %-20s : %-22s ${BV_BOLD}║${BV_NC}\n" "Stack" "$BV_STACK"
    printf  "  ${BV_BOLD}║${BV_NC} %-20s : %-22s ${BV_BOLD}║${BV_NC}\n" "Project" "$(basename "$BV_PROJECT_DIR")"

    local install_icon build_icon lint_icon
    if [[ "${BV_INSTALL_RC:-1}" -eq 0 ]]; then
        install_icon="${BV_GREEN}PASS${BV_NC}"
    else
        install_icon="${BV_RED}FAIL (rc=${BV_INSTALL_RC})${BV_NC}"
    fi
    if [[ "${BV_BUILD_RC:-1}" -eq 0 ]]; then
        build_icon="${BV_GREEN}PASS${BV_NC}"
    else
        build_icon="${BV_RED}FAIL (rc=${BV_BUILD_RC})${BV_NC}"
    fi
    if [[ "${BV_LINT_RC:-1}" -eq 0 ]]; then
        lint_icon="${BV_GREEN}PASS${BV_NC}"
    else
        lint_icon="${BV_YELLOW}WARN (rc=${BV_LINT_RC})${BV_NC}"
    fi

    echo -e "  ${BV_BOLD}║${BV_NC} %-20s : ${install_icon}                ${BV_BOLD}║${BV_NC}" "Install"
    echo -e "  ${BV_BOLD}║${BV_NC} %-20s : ${build_icon}                ${BV_BOLD}║${BV_NC}" "Build"
    echo -e "  ${BV_BOLD}║${BV_NC} %-20s : ${lint_icon}                ${BV_BOLD}║${BV_NC}" "Lint"
    printf  "  ${BV_BOLD}║${BV_NC} %-20s : %-22s ${BV_BOLD}║${BV_NC}\n" "Total errors" "$BV_ERROR_COUNT"
    echo -e "  ${BV_BOLD}╚══════════════════════════════════════════════╝${BV_NC}"
    echo ""
}
