#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v102.0 - E2E Runner (Playwright)
# 生成されたフロントエンドを実際にブラウザで操作して検証
#
# page.tsxを解析→Playwrightテストスクリプト自動生成→実行→結果収集
# ============================================================

[[ -n "${_E2E_LOADED:-}" ]] && return 0
_E2E_LOADED=1

E2E_VERSION="102.0"
E2E_INITIALIZED=false
E2E_TIMEOUT=30000  # Playwrightタイムアウト(ms)

# --- 統計 ---
E2E_TOTAL_TESTS=0
E2E_PASSED_TESTS=0
E2E_FAILED_TESTS=0
E2E_RESULTS=""

# ============================================================
# 初期化
# ============================================================
e2e_init() {
    E2E_TOTAL_TESTS=0
    E2E_PASSED_TESTS=0
    E2E_FAILED_TESTS=0
    E2E_RESULTS=""
    E2E_INITIALIZED=true
    return 0
}

# ============================================================
# メイン: E2Eテスト実行
# ============================================================
e2e_run() {
    local project_dir="$1"
    local base_url="${2:-http://localhost:3000}"

    [[ ! -d "$project_dir" ]] && return 1

    e2e_init
    echo -e "  🎭 [E2E] E2E Runner v${E2E_VERSION} 開始" >&2

    # Playwright利用可能チェック
    if ! command -v npx &>/dev/null; then
        echo -e "  ⚠️ [E2E] npxが利用不可 → スキップ" >&2
        return 0
    fi

    # ページルート検出
    local pages
    pages=$(_e2e_detect_pages "$project_dir")

    if [[ -z "$pages" ]]; then
        echo -e "  ⚠️ [E2E] ページ未検出 → スキップ" >&2
        return 0
    fi

    # テストスクリプト生成
    local test_dir="${project_dir}/.e2e-tests"
    mkdir -p "$test_dir"

    _e2e_generate_tests "$project_dir" "$pages" "$test_dir" "$base_url"

    # Playwright実行（インストール済みの場合のみ）
    if (cd "$project_dir" && npx playwright --version &>/dev/null 2>&1); then
        _e2e_run_playwright "$project_dir" "$test_dir"
    else
        # Playwrightなし → curl fallback
        _e2e_run_curl_fallback "$pages" "$base_url"
    fi

    # クリーンアップ
    rm -rf "$test_dir" 2>/dev/null

    echo -e "  📊 [E2E] 結果: ${E2E_PASSED_TESTS}/${E2E_TOTAL_TESTS} 通過" >&2

    E2E_RESULTS=$(_e2e_build_report)

    [[ ${E2E_FAILED_TESTS} -gt 0 ]] && return 1
    return 0
}

# ============================================================
# ページ検出（Next.js App Router）
# ============================================================
_e2e_detect_pages() {
    local project_dir="$1"

    find "$project_dir" -name "page.tsx" -o -name "page.jsx" 2>/dev/null | \
        grep -v node_modules | grep -v .next | \
        while IFS= read -r page_file; do
            local route
            route=$(echo "$page_file" | sed "s|${project_dir}/||;s|^app/||;s|^src/app/||;s|/page\.tsx$||;s|/page\.jsx$||")
            [[ "$route" == "page.tsx" || "$route" == "page.jsx" ]] && route=""
            # 動的ルート除外
            [[ "$route" == *"["* ]] && continue
            echo "/${route}"
        done | sort -u
}

# ============================================================
# Playwrightテストスクリプト生成
# ============================================================
_e2e_generate_tests() {
    local project_dir="$1"
    local pages="$2"
    local test_dir="$3"
    local base_url="$4"

    local test_file="${test_dir}/generated.spec.ts"

    cat > "$test_file" << PLAYWRIGHT_EOF
import { test, expect } from '@playwright/test';

const BASE_URL = '${base_url}';

PLAYWRIGHT_EOF

    echo "$pages" | while IFS= read -r page; do
        [[ -z "$page" ]] && continue
        local test_name
        test_name=$(echo "$page" | sed 's|/|_|g;s|^_||')
        [[ -z "$test_name" ]] && test_name="home"

        cat >> "$test_file" << PLAYWRIGHT_EOF
test('page ${page} loads', async ({ page }) => {
  const response = await page.goto(\`\${BASE_URL}${page}\`);
  expect(response?.status()).toBeLessThan(500);
  await expect(page).not.toHaveTitle('500');
});

PLAYWRIGHT_EOF
    done
}

# ============================================================
# Playwright実行
# ============================================================
_e2e_run_playwright() {
    local project_dir="$1"
    local test_dir="$2"

    local output
    output=$(cd "$project_dir" && timeout 120 npx playwright test "$test_dir" --reporter=json 2>&1 || true)

    # JSON結果をパース
    local passed failed
    passed=$(echo "$output" | grep -oE '"passed":\s*[0-9]+' | head -1 | grep -oE '[0-9]+' || echo "0")
    failed=$(echo "$output" | grep -oE '"failed":\s*[0-9]+' | head -1 | grep -oE '[0-9]+' || echo "0")

    E2E_PASSED_TESTS=$((E2E_PASSED_TESTS + passed))
    E2E_FAILED_TESTS=$((E2E_FAILED_TESTS + failed))
    E2E_TOTAL_TESTS=$((E2E_TOTAL_TESTS + passed + failed))
}

# ============================================================
# curl フォールバック（Playwrightなし時）
# ============================================================
_e2e_run_curl_fallback() {
    local pages="$1"
    local base_url="$2"

    echo "$pages" | while IFS= read -r page; do
        [[ -z "$page" ]] && continue
        local url="${base_url}${page}"
        local status
        status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 "$url" 2>/dev/null || echo "000")

        E2E_TOTAL_TESTS=$((E2E_TOTAL_TESTS + 1))

        if [[ "$status" == 2* ]] || [[ "$status" == "307" ]] || [[ "$status" == "308" ]]; then
            E2E_PASSED_TESTS=$((E2E_PASSED_TESTS + 1))
        elif [[ "$status" == "401" ]] || [[ "$status" == "403" ]]; then
            # 認証が必要なページはOK（動いている証拠）
            E2E_PASSED_TESTS=$((E2E_PASSED_TESTS + 1))
        else
            E2E_FAILED_TESTS=$((E2E_FAILED_TESTS + 1))
            E2E_RESULTS+="- PAGE_ERROR: ${page} → HTTP ${status}
"
        fi
    done
}

# ============================================================
# レポート
# ============================================================
_e2e_build_report() {
    if [[ ${E2E_FAILED_TESTS} -eq 0 ]]; then
        echo ""
        return
    fi
    echo "## E2Eテストエラー (${E2E_FAILED_TESTS}/${E2E_TOTAL_TESTS}件失敗)
${E2E_RESULTS}"
}

e2e_report() {
    echo "=== E2E Runner v${E2E_VERSION} ==="
    echo "  Tests: ${E2E_TOTAL_TESTS} (Pass:${E2E_PASSED_TESTS}, Fail:${E2E_FAILED_TESTS})"
}

e2e_score() {
    [[ $E2E_TOTAL_TESTS -eq 0 ]] && { echo "50"; return; }
    echo "$(( (E2E_PASSED_TESTS * 100) / E2E_TOTAL_TESTS ))"
}

# Module Registry
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "e2e-runner" \
        --version "$E2E_VERSION" \
        --description "E2Eテスト - Playwright/curlでページ遷移+UI操作を検証" \
        --init "e2e_init" \
        --report "e2e_report" \
        --score "e2e_score" \
        --enable-var "ENABLE_E2E" \
        --cli-flags "--e2e-test:--no-e2e-test"
fi

# v2003.1: source時のexit codeを確実に0にする
true
