#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - Cache Strategy Engine
# =============================================================================
# キャッシュ戦略の完全自動構築: Memory/Redis/Hybrid対応。
# HTTPキャッシュ(ETag/Cache-Control)、クエリキャッシュ(TTL+invalidation)、
# セッションストア(Redis-backed)を本番品質TypeScriptコードとして生成。
#
# Functions:
#   cst_init()                     - Initialize cache config
#   cst_generate_cache_layer()     - Cache abstraction (memory/Redis/hybrid)
#   cst_generate_cache_middleware() - HTTP cache headers, ETag, conditional req
#   cst_generate_query_cache()     - DB query result caching with invalidation
#   cst_generate_session_store()   - Session storage (Redis-backed)
#   cst_invalidation_strategy()    - TTL, event-based, manual invalidation
#   cst_generate_cache()           - Full cache scaffold
#   cst_inject_cache_patterns()    - Inject caching best practices
#   cst_report() / cst_score()    - Reporting
#
# All globals use the CST_ prefix.
# =============================================================================

[[ -n "${_CST_LOADED:-}" ]] && return 0; _CST_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g CST_VERSION="140.0"
CST_GENERATED=0
CST_ERRORS=0
CST_FILES_WRITTEN=0
CST_PHASE="cache_setup"
CST_LAYER_OK=false
CST_MIDDLEWARE_OK=false
CST_QUERY_OK=false
CST_SESSION_OK=false
CST_INVALIDATION_OK=false

# =============================================================================
# Init
# =============================================================================
cst_init() {
    CST_GENERATED=0
    CST_ERRORS=0
    CST_FILES_WRITTEN=0
    CST_LAYER_OK=false
    CST_MIDDLEWARE_OK=false
    CST_QUERY_OK=false
    CST_SESSION_OK=false
    CST_INVALIDATION_OK=false
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Cache Strategy v${CST_VERSION}"
    return 0
}

# =============================================================================
# Utility
# =============================================================================
_cst_write_file() {
    local filepath="$1"
    local content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        CST_FILES_WRITTEN=$((CST_FILES_WRITTEN + 1))
        return 0
    else
        CST_ERRORS=$((CST_ERRORS + 1))
        return 1
    fi
}

# =============================================================================
# Generate Cache Abstraction Layer (Memory / Redis / Hybrid)
# =============================================================================
cst_generate_cache_layer() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local strategy="${2:-hybrid}"

    _cst_write_file "${project_dir}/src/lib/cache.ts" "$(cat <<'TYPESCRIPT'
// ====================================================================
// Cache Service - Unified cache abstraction (Memory + Redis hybrid)
// ====================================================================

export interface CacheEntry<T = unknown> {
  data: T;
  expiresAt: number; // unix ms
  tags: string[];    // for tag-based invalidation
}

export interface CacheOptions {
  ttl?: number;       // seconds (default: 300 = 5 min)
  tags?: string[];    // invalidation tags
}

interface CacheAdapter {
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T, options?: CacheOptions): Promise<void>;
  delete(key: string): Promise<void>;
  deleteByTag(tag: string): Promise<number>;
  clear(): Promise<void>;
  has(key: string): Promise<boolean>;
}

// ── In-Memory Cache ─────────────────────────────────────────────────
class MemoryCache implements CacheAdapter {
  private store = new Map<string, CacheEntry>();
  private tagIndex = new Map<string, Set<string>>(); // tag -> keys

  async get<T>(key: string): Promise<T | null> {
    const entry = this.store.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expiresAt) {
      this.store.delete(key);
      return null;
    }
    return entry.data as T;
  }

  async set<T>(key: string, value: T, options?: CacheOptions): Promise<void> {
    const ttl = (options?.ttl ?? 300) * 1000;
    const tags = options?.tags ?? [];
    this.store.set(key, { data: value, expiresAt: Date.now() + ttl, tags });
    for (const tag of tags) {
      if (!this.tagIndex.has(tag)) this.tagIndex.set(tag, new Set());
      this.tagIndex.get(tag)!.add(key);
    }
  }

  async delete(key: string): Promise<void> {
    const entry = this.store.get(key);
    if (entry) {
      for (const tag of entry.tags) {
        this.tagIndex.get(tag)?.delete(key);
      }
    }
    this.store.delete(key);
  }

  async deleteByTag(tag: string): Promise<number> {
    const keys = this.tagIndex.get(tag);
    if (!keys) return 0;
    let count = 0;
    for (const key of keys) {
      this.store.delete(key);
      count++;
    }
    this.tagIndex.delete(tag);
    return count;
  }

  async clear(): Promise<void> {
    this.store.clear();
    this.tagIndex.clear();
  }

  async has(key: string): Promise<boolean> {
    const entry = this.store.get(key);
    if (!entry) return false;
    if (Date.now() > entry.expiresAt) {
      this.store.delete(key);
      return false;
    }
    return true;
  }
}

// ── Redis Cache (optional, graceful fallback to memory) ─────────────
class RedisCache implements CacheAdapter {
  private redis: any = null;
  private fallback = new MemoryCache();
  private connected = false;

  constructor() {
    this.initRedis();
  }

  private async initRedis() {
    try {
      if (process.env.REDIS_URL) {
        const { createClient } = await import('redis');
        this.redis = createClient({ url: process.env.REDIS_URL });
        this.redis.on('error', () => { this.connected = false; });
        await this.redis.connect();
        this.connected = true;
      }
    } catch {
      console.warn('[cache] Redis unavailable, using in-memory fallback');
      this.connected = false;
    }
  }

  async get<T>(key: string): Promise<T | null> {
    if (!this.connected) return this.fallback.get<T>(key);
    try {
      const raw = await this.redis.get(`cache:${key}`);
      if (!raw) return null;
      return JSON.parse(raw) as T;
    } catch {
      return this.fallback.get<T>(key);
    }
  }

  async set<T>(key: string, value: T, options?: CacheOptions): Promise<void> {
    const ttl = options?.ttl ?? 300;
    if (!this.connected) return this.fallback.set(key, value, options);
    try {
      await this.redis.set(`cache:${key}`, JSON.stringify(value), { EX: ttl });
      if (options?.tags) {
        for (const tag of options.tags) {
          await this.redis.sAdd(`tag:${tag}`, key);
        }
      }
    } catch {
      return this.fallback.set(key, value, options);
    }
  }

  async delete(key: string): Promise<void> {
    if (!this.connected) return this.fallback.delete(key);
    try { await this.redis.del(`cache:${key}`); } catch { this.fallback.delete(key); }
  }

  async deleteByTag(tag: string): Promise<number> {
    if (!this.connected) return this.fallback.deleteByTag(tag);
    try {
      const keys: string[] = await this.redis.sMembers(`tag:${tag}`);
      if (keys.length > 0) {
        await this.redis.del(keys.map((k: string) => `cache:${k}`));
      }
      await this.redis.del(`tag:${tag}`);
      return keys.length;
    } catch {
      return this.fallback.deleteByTag(tag);
    }
  }

  async clear(): Promise<void> {
    if (!this.connected) return this.fallback.clear();
    try { await this.redis.flushDb(); } catch { this.fallback.clear(); }
  }

  async has(key: string): Promise<boolean> {
    if (!this.connected) return this.fallback.has(key);
    try { return (await this.redis.exists(`cache:${key}`)) === 1; } catch { return this.fallback.has(key); }
  }
}

// ── Cache Singleton ─────────────────────────────────────────────────
const cacheInstance: CacheAdapter = process.env.REDIS_URL ? new RedisCache() : new MemoryCache();

export const cache = {
  get: <T>(key: string) => cacheInstance.get<T>(key),
  set: <T>(key: string, value: T, options?: CacheOptions) => cacheInstance.set(key, value, options),
  delete: (key: string) => cacheInstance.delete(key),
  invalidateTag: (tag: string) => cacheInstance.deleteByTag(tag),
  clear: () => cacheInstance.clear(),
  has: (key: string) => cacheInstance.has(key),

  /** Cache-aside pattern: get from cache or compute and store */
  async getOrSet<T>(key: string, fetcher: () => Promise<T>, options?: CacheOptions): Promise<T> {
    const cached = await cacheInstance.get<T>(key);
    if (cached !== null) return cached;
    const fresh = await fetcher();
    await cacheInstance.set(key, fresh, options);
    return fresh;
  },
};

export type { CacheAdapter };
TYPESCRIPT
)"

    _cst_write_file "${project_dir}/src/lib/cache-config.ts" "$(cat <<'TYPESCRIPT'
// ====================================================================
// Cache TTL Configuration per Resource Type
// ====================================================================

export const CACHE_TTL = {
  // Static / rarely changing data
  settings: 3600,          // 1 hour
  permissions: 1800,       // 30 min
  roles: 1800,             // 30 min

  // Semi-static data
  userProfile: 300,        // 5 min
  companyInfo: 600,        // 10 min

  // Dynamic but cacheable
  dashboardStats: 60,      // 1 min
  listResults: 120,        // 2 min
  searchResults: 60,       // 1 min

  // Volatile - very short cache
  notifications: 15,       // 15 sec
  activeUsers: 30,         // 30 sec
} as const;

export const CACHE_TAGS = {
  users: 'entity:users',
  projects: 'entity:projects',
  tasks: 'entity:tasks',
  settings: 'entity:settings',
  notifications: 'entity:notifications',
} as const;

/** Build a cache key with consistent format */
export function cacheKey(resource: string, ...parts: (string | number)[]): string {
  return [resource, ...parts].join(':');
}
TYPESCRIPT
)"
    CST_LAYER_OK=true
    CST_GENERATED=$((CST_GENERATED + 1))
}

# =============================================================================
# Generate HTTP Cache Middleware (ETag, Cache-Control, Conditional Requests)
# =============================================================================
cst_generate_cache_middleware() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _cst_write_file "${project_dir}/src/middleware/cache-middleware.ts" "$(cat <<'TYPESCRIPT'
import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';

/** HTTP caching middleware: ETag, Cache-Control, conditional requests (304) */
export function withHttpCache(
  handler: (req: NextRequest) => Promise<NextResponse>,
  options: { maxAge?: number; private?: boolean; staleWhileRevalidate?: number } = {}
) {
  const { maxAge = 0, staleWhileRevalidate = 60 } = options;
  const isPrivate = options.private ?? true;

  return async (req: NextRequest): Promise<NextResponse> => {
    // Only cache GET/HEAD requests
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      return handler(req);
    }

    const response = await handler(req);

    // Generate ETag from response body
    const body = await response.clone().text();
    const etag = `"${crypto.createHash('md5').update(body).digest('hex')}"`;

    // Check If-None-Match for conditional request (304 Not Modified)
    const ifNoneMatch = req.headers.get('if-none-match');
    if (ifNoneMatch === etag) {
      return new NextResponse(null, {
        status: 304,
        headers: { ETag: etag },
      });
    }

    // Set cache headers
    const cacheControl = [
      isPrivate ? 'private' : 'public',
      `max-age=${maxAge}`,
      staleWhileRevalidate > 0 ? `stale-while-revalidate=${staleWhileRevalidate}` : '',
    ].filter(Boolean).join(', ');

    response.headers.set('ETag', etag);
    response.headers.set('Cache-Control', cacheControl);
    response.headers.set('Vary', 'Accept, Authorization');

    return response;
  };
}

/** Bust cache headers for mutating responses */
export function noCacheHeaders(response: NextResponse): NextResponse {
  response.headers.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  response.headers.set('Pragma', 'no-cache');
  return response;
}
TYPESCRIPT
)"
    CST_MIDDLEWARE_OK=true
    CST_GENERATED=$((CST_GENERATED + 1))
}

# =============================================================================
# Generate Database Query Cache
# =============================================================================
cst_generate_query_cache() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _cst_write_file "${project_dir}/src/lib/query-cache.ts" "$(cat <<'TYPESCRIPT'
import { cache } from './cache';
import { cacheKey, CACHE_TTL, CACHE_TAGS } from './cache-config';

// ====================================================================
// Database Query Cache with Automatic Invalidation
// ====================================================================

type EntityType = keyof typeof CACHE_TAGS;

/**
 * Cached query wrapper: caches Prisma query results.
 * Automatically invalidates when entity is mutated.
 *
 * Usage:
 *   const users = await cachedQuery('users', 'list', { page: 1 },
 *     () => prisma.user.findMany({ take: 20 })
 *   );
 */
export async function cachedQuery<T>(
  entity: EntityType,
  operation: string,
  params: Record<string, unknown>,
  fetcher: () => Promise<T>,
  ttl?: number,
): Promise<T> {
  const key = cacheKey(entity, operation, JSON.stringify(params));
  const cacheTtl = ttl ?? (CACHE_TTL as Record<string, number>)[entity] ?? 120;
  return cache.getOrSet<T>(key, fetcher, {
    ttl: cacheTtl,
    tags: [CACHE_TAGS[entity]],
  });
}

/**
 * Invalidate all cached queries for an entity type.
 * Call this after any CREATE / UPDATE / DELETE operation.
 *
 * Usage:
 *   await prisma.user.update({ ... });
 *   await invalidateEntity('users');
 */
export async function invalidateEntity(entity: EntityType): Promise<void> {
  const tag = CACHE_TAGS[entity];
  if (tag) {
    const count = await cache.invalidateTag(tag);
    if (process.env.NODE_ENV === 'development') {
      console.log(`[query-cache] Invalidated ${count} entries for ${entity}`);
    }
  }
}

/**
 * Invalidate specific cache entry.
 */
export async function invalidateQuery(entity: EntityType, operation: string, params: Record<string, unknown>): Promise<void> {
  const key = cacheKey(entity, operation, JSON.stringify(params));
  await cache.delete(key);
}

/**
 * Prisma middleware for automatic cache invalidation on write operations.
 * Add to Prisma client: prisma.$use(cacheInvalidationMiddleware);
 */
export function cacheInvalidationMiddleware() {
  return async (params: any, next: (params: any) => Promise<any>) => {
    const result = await next(params);
    const writeOps = ['create', 'update', 'upsert', 'delete', 'createMany', 'updateMany', 'deleteMany'];
    if (writeOps.includes(params.action)) {
      const model = params.model?.toLowerCase() as EntityType | undefined;
      if (model && CACHE_TAGS[model]) {
        await invalidateEntity(model).catch(() => {});
      }
    }
    return result;
  };
}
TYPESCRIPT
)"
    CST_QUERY_OK=true
    CST_GENERATED=$((CST_GENERATED + 1))
}

# =============================================================================
# Generate Session Store (Redis-backed for production)
# =============================================================================
cst_generate_session_store() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _cst_write_file "${project_dir}/src/lib/session-store.ts" "$(cat <<'TYPESCRIPT'
import { cache } from './cache';
import crypto from 'crypto';

// ====================================================================
// Session Store - Redis-backed with in-memory fallback
// ====================================================================

export interface SessionData {
  userId: string;
  role: string;
  email: string;
  createdAt: number;
  lastAccessedAt: number;
  metadata?: Record<string, unknown>;
}

const SESSION_TTL = 24 * 60 * 60; // 24 hours
const SESSION_PREFIX = 'session';

/** Create a new session */
export async function createSession(data: Omit<SessionData, 'createdAt' | 'lastAccessedAt'>): Promise<string> {
  const sessionId = crypto.randomBytes(32).toString('hex');
  const session: SessionData = {
    ...data,
    createdAt: Date.now(),
    lastAccessedAt: Date.now(),
  };
  await cache.set(`${SESSION_PREFIX}:${sessionId}`, session, { ttl: SESSION_TTL });
  // Also maintain user->sessions index
  const userSessions = await cache.get<string[]>(`user-sessions:${data.userId}`) ?? [];
  userSessions.push(sessionId);
  await cache.set(`user-sessions:${data.userId}`, userSessions, { ttl: SESSION_TTL });
  return sessionId;
}

/** Get session by ID (extends TTL on access) */
export async function getSession(sessionId: string): Promise<SessionData | null> {
  const session = await cache.get<SessionData>(`${SESSION_PREFIX}:${sessionId}`);
  if (!session) return null;
  session.lastAccessedAt = Date.now();
  await cache.set(`${SESSION_PREFIX}:${sessionId}`, session, { ttl: SESSION_TTL });
  return session;
}

/** Destroy a specific session */
export async function destroySession(sessionId: string): Promise<void> {
  const session = await cache.get<SessionData>(`${SESSION_PREFIX}:${sessionId}`);
  if (session) {
    const userSessions = await cache.get<string[]>(`user-sessions:${session.userId}`) ?? [];
    await cache.set(
      `user-sessions:${session.userId}`,
      userSessions.filter(s => s !== sessionId),
      { ttl: SESSION_TTL }
    );
  }
  await cache.delete(`${SESSION_PREFIX}:${sessionId}`);
}

/** Destroy all sessions for a user (e.g., password change, force logout) */
export async function destroyUserSessions(userId: string): Promise<void> {
  const sessionIds = await cache.get<string[]>(`user-sessions:${userId}`) ?? [];
  for (const sid of sessionIds) {
    await cache.delete(`${SESSION_PREFIX}:${sid}`);
  }
  await cache.delete(`user-sessions:${userId}`);
}
TYPESCRIPT
)"
    CST_SESSION_OK=true
    CST_GENERATED=$((CST_GENERATED + 1))
}

# =============================================================================
# Generate Invalidation Strategy
# =============================================================================
cst_invalidation_strategy() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _cst_write_file "${project_dir}/src/lib/cache-invalidation.ts" "$(cat <<'TYPESCRIPT'
import { cache } from './cache';
import { CACHE_TAGS } from './cache-config';

// ====================================================================
// Cache Invalidation Strategies
// ====================================================================

type InvalidationStrategy = 'ttl' | 'event' | 'manual' | 'cascade';

interface InvalidationRule {
  entity: string;
  strategy: InvalidationStrategy;
  cascadeTo?: string[];  // Other entities to invalidate
}

const INVALIDATION_RULES: InvalidationRule[] = [
  { entity: 'users', strategy: 'event', cascadeTo: ['tasks', 'projects'] },
  { entity: 'projects', strategy: 'event', cascadeTo: ['tasks'] },
  { entity: 'tasks', strategy: 'event' },
  { entity: 'settings', strategy: 'manual' },
  { entity: 'notifications', strategy: 'ttl' },
];

/** Event-based invalidation: call after any write operation */
export async function onEntityChange(entity: string, action: 'create' | 'update' | 'delete', entityId?: string): Promise<void> {
  const rule = INVALIDATION_RULES.find(r => r.entity === entity);
  if (!rule) return;

  // Invalidate the entity's cache
  const tag = (CACHE_TAGS as Record<string, string>)[entity];
  if (tag) {
    await cache.invalidateTag(tag);
  }

  // Cascade invalidation to dependent entities
  if (rule.cascadeTo) {
    for (const dep of rule.cascadeTo) {
      const depTag = (CACHE_TAGS as Record<string, string>)[dep];
      if (depTag) {
        await cache.invalidateTag(depTag);
      }
    }
  }

  if (process.env.NODE_ENV === 'development') {
    console.log(`[cache-invalidation] ${entity}.${action}${entityId ? `#${entityId}` : ''} -> invalidated${rule.cascadeTo ? ` + cascade: ${rule.cascadeTo.join(', ')}` : ''}`);
  }
}

/** Manual bulk invalidation (admin action) */
export async function invalidateAll(): Promise<void> {
  await cache.clear();
  console.log('[cache-invalidation] Full cache cleared');
}

/** Warm cache for frequently accessed data */
export async function warmCache(fetchers: Array<{ key: string; fetcher: () => Promise<unknown>; ttl: number }>): Promise<void> {
  await Promise.allSettled(
    fetchers.map(async ({ key, fetcher, ttl }) => {
      const data = await fetcher();
      await cache.set(key, data, { ttl });
    })
  );
}
TYPESCRIPT
)"
    CST_INVALIDATION_OK=true
    CST_GENERATED=$((CST_GENERATED + 1))
}

# =============================================================================
# Inject Cache Patterns into Claude Prompt
# =============================================================================
cst_inject_cache_patterns() {
    local prompt="${1:-}"
    cat <<'INJECT'

## [CACHE-STRATEGY] Caching Best Practices (MANDATORY)

### Cache-Aside Pattern (REQUIRED for all DB queries):
```typescript
import { cachedQuery, invalidateEntity } from '@/lib/query-cache';
// READ: always use cachedQuery
const users = await cachedQuery('users', 'list', { page }, () => prisma.user.findMany());
// WRITE: always invalidate after mutation
await prisma.user.update({ ... });
await invalidateEntity('users');
```

### Rules:
- NEVER cache auth tokens or sensitive data in shared cache
- ALL list/read endpoints MUST use cachedQuery
- ALL write operations MUST call invalidateEntity
- Use tag-based invalidation for related entities
- Set appropriate TTLs per resource type (see cache-config.ts)
- HTTP responses: set ETag + Cache-Control headers
- Redis for production, in-memory for development (auto-detected)

INJECT
    echo "$prompt"
}

# =============================================================================
# Full Cache Scaffold
# =============================================================================
cst_generate_cache() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    echo "[cache-strategy] Generating complete cache system for ${project_dir}..."

    cst_generate_cache_layer "$project_dir" "hybrid"
    cst_generate_cache_middleware "$project_dir"
    cst_generate_query_cache "$project_dir"
    cst_generate_session_store "$project_dir"
    cst_invalidation_strategy "$project_dir"

    echo "[cache-strategy] Generated ${CST_FILES_WRITTEN} files, ${CST_GENERATED} components"
    return 0
}

# =============================================================================
# Report
# =============================================================================
cst_report() {
    echo -e "\n  ${BOLD:-}=== Cache Strategy v${CST_VERSION} ===${NC:-}"
    echo -e "  生成コンポーネント: ${CST_GENERATED}"
    echo -e "  ファイル書込数: ${CST_FILES_WRITTEN}"
    echo -e "  Cache Layer: $(${CST_LAYER_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  HTTP Middleware: $(${CST_MIDDLEWARE_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Query Cache: $(${CST_QUERY_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Session Store: $(${CST_SESSION_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Invalidation: $(${CST_INVALIDATION_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  エラー: ${CST_ERRORS}"
}

cst_report_json() {
    cat <<JSON
{
  "module": "cache-strategy",
  "version": "${CST_VERSION}",
  "generated": ${CST_GENERATED},
  "files_written": ${CST_FILES_WRITTEN},
  "errors": ${CST_ERRORS},
  "components": {
    "cache_layer": ${CST_LAYER_OK},
    "http_middleware": ${CST_MIDDLEWARE_OK},
    "query_cache": ${CST_QUERY_OK},
    "session_store": ${CST_SESSION_OK},
    "invalidation": ${CST_INVALIDATION_OK}
  }
}
JSON
}

cst_score() {
    local score=50
    ${CST_LAYER_OK} && score=$((score + 10))
    ${CST_MIDDLEWARE_OK} && score=$((score + 10))
    ${CST_QUERY_OK} && score=$((score + 10))
    ${CST_SESSION_OK} && score=$((score + 10))
    ${CST_INVALIDATION_OK} && score=$((score + 10))
    [[ ${CST_ERRORS} -eq 0 ]] || score=$((score - 10))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry self-registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "cache-strategy" --version "140.0" \
        --description "キャッシュ戦略自動設計×Redis/Memory/Hybrid (v140完全実装)" \
        --init "cst_init" --report "cst_report" --report-json "cst_report_json" --score "cst_score" \
        --enable-var "ENABLE_CACHE_STRATEGY" --cli-flags "--cache-strategy:--no-cache-strategy"
fi

# v2003.1: source時のexit codeを確実に0にする
true
