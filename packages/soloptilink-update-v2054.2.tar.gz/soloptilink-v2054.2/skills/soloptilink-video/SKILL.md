---
name: soloptilink-video
description: "SoloptiLinkAI v2054.2 - Cinema Director Mode - 「CM作って」「予告編風の動画」「プロモ動画を生成して」「Higgsfieldで動画」「ショート動画を作って」等、動画の実生成で起動。監督エンジン(絵コンテ→キーフレーム先行→ショット別生成→自動QC→編集仕上げ)で映画予告・大手CM級の動画を一言から一発生成する。台本や編集指示書だけの場合は soloptilink-creative。"
argument-hint: "「30秒の会社CMを予告編風に作って」「新商品のプロモ動画 9:16 で」「--budget 300」"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, Agent, WebSearch, WebFetch, TodoWrite, AskUserQuestion, ToolSearch"
---

# SoloptiLinkAI v2054.2 - Cinema Director Mode

## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

# 映画予告・大手CM級動画の一発生成スキル (Higgsfield 連携)

---

## 🚀 最優先指令

1. **一発完成**: 一言依頼から「完成 mp4 + サムネイル + 実測レポート」まで自律で到達する。途中の逐次承認は求めない(予算超過見込みのみ例外)。
2. **1本の動画=編集された複数カット**: 1回の生成で完成品を出そうとしない。必ず「絵コンテ→カット別生成→編集仕上げ」の多段で作る。映画予告・CMの品質は構造から生まれる。
3. **画像先行 (最大の品質レバー)**: 既定は text2image でキーフレーム静止画を確定→採用画のみ image2video。テキスト直行は激しいカメラワーク主体のショットのみ。
4. **カット単位の自動QC**: 生成した全クリップはフレーム抽出→目視評価し、不合格カットだけ撮り直す(ショットあたり最大2回)。全カット未評価のまま編集に進むことを禁止。
5. **実測のみ・捏造禁止**: 実行していない生成・検証を「できた」と書かない。消費クレジットは台帳の実測値のみ報告する。
6. **クレジット規律**: 既定予算 200cr/本 (`--budget` で変更可)。着手前に見積合計を確認し、予算超過が見込まれる場合のみ停止して選択肢を提示。台帳ガードの BLOCK を無視して生成を続けることを禁止。
7. **文字は生成AIに描かせない**: タイトル・ロゴ・キャッチコピーは必ずポスプロ(タイトルカード/オーバーレイ)で載せる(文字化け根絶)。
8. **権利物を勝手に使わない**: BGM はユーザー提供素材のみ既定。権利不明の音源を混ぜない。無指定時は「BGM無し版+差し替え手順」で納品する。
9. **言語・顧客可視ポリシー**: `~/.claude/CLAUDE.md` のグローバルポリシーに完全準拠。応答は全て日本語・地の文に機械言語を貼らない。進捗は「① 構想 → ② 絵コンテ → ③ 撮影 → ④ 検品 → ⑤ 編集仕上げ」のマイルストーンで伝える。

**エンジンの所在 (内部)**: `~/.soloptilink/lib/video-director/` — style-presets.json (プリセット10種) / cinema-vocab.json (映画的語彙+プロンプト規律) / model-matrix.json (モデル選定+実測コスト台帳) / story-grammar.json (予告編・CM文法) / director-engine.sh (雛形・検証・予算台帳) / qc-extract.sh (QCフレーム抽出) / assemble.sh (自動編集) / hf-runner/ (REST予備経路)。

---

## Step 0: 接続確認 (毎回最初に実行)

1. **MCP経路 (優先)**: ToolSearch で `higgsfield` を検索し、生成系ツール (`generate_video` / `generate_image` / `balance` / `models_explore` / `job_display` 等) が載っているか確認する。
   - 載っている → `balance` で残高を実測し、予算と照合して開始。
   - **初回または model-matrix.json に verified_models が無い場合** → `models_explore` を実行し、実在モデルIDと特性を `model-matrix.json` に追記する(自己学習・SoT転記)。
2. **REST予備経路**: MCPツールが無い場合、`bash -c 'cd ~/.soloptilink/lib/video-director/hf-runner && node runner.mjs doctor'` を実行。
   - `ok:true` → REST経路で続行 (`runner.mjs image/video/speak/motions/styles/download`)。
   - `ok:false` (鍵未設定) → 次の2択を日本語で案内して待つ: ①Higgsfieldコネクタを認証済みの新しいセッションで再実行 ②cloud.higgsfield.ai > API Keys で鍵を発行し環境変数 HF_CREDENTIALS を設定。**ここが唯一の停止許容点** (接続なしで生成の偽装は絶対禁止)。
3. どちらの経路でも、生成は非同期 (queued→in_progress→completed/failed/nsfw)。failed/nsfw はクレジット返還されるので台帳に記録しない。

---

## Step 1: ブリーフ推論 (Silent Inference・質問しない)

一言依頼から以下を内部確定し、**前提として1行ずつ提示**してから進む (誤りは後から指摘可能な形):

- **目的** (認知/販促/採用/ブランディング) / **ターゲット** / **コアメッセージ1文**
- **尺** (既定30秒) / **比率** (既定はプリセットの aspect_default)
- **プリセット**: `style-presets.json` の10種から選択 (映画予告/ナショナルCM/テックローンチ/ラグジュアリー/エモーショナル/シズル/コーポレート/採用/SNS縦型/ドキュメンタリー)
- **予算**: `--budget` 指定 or 既定200cr
- 会社URLがあれば WebFetch で事業内容を取得しメッセージに反映する

## Step 2: プロジェクト初期化

```bash
VD=~/.soloptilink/lib/video-director
bash "$VD/director-engine.sh" init "$PWD/<プロジェクト名>" --preset <id> --duration <秒> --budget <cr> --title "<題名>"
```

## Step 3: ストーリー設計と絵コンテ (品質の心臓部)

1. `story-grammar.json` から該当文法を選び、フェーズ配分どおりに8〜15カットを割り付ける。**冒頭ルール: 最初のショットは全カット中で最も強い画**。ラストは必ずブランド/CTA。
2. `shotlist.json` を書く。各ショットは必ず以下を満たす:
   - フィールド: `id / phase / duration_sec (1-15) / shot_size / camera_move / lighting / lens / prompt_en / negative_en / model / pipeline (image_first|text_direct)`
   - `prompt_en` は `cinema-vocab.json` の **prompt_recipe** に従い英語で書く: 被写体と動作+場所+shot_size+camera_move+lighting+lens+プリセットの style_keywords_en 全句+motion_quality 2句。1ショット=1アクション。
   - `negative_en` は negative_bank 全句+プリセットの negative_extra_en。
   - **スタイルロック**: 同一人物・商品が複数ショットに出る場合、その記述句を全ショットで一字一句同じにする。人物の顔ショットは表情を1語指定。
   - タイトル・ロゴのカットは生成せず、絵コンテ上は `phase: title/brand` として編集段(タイトルカード)に割り当てる。
3. `bash "$VD/director-engine.sh" validate <dir>` が **PASS するまで**絵コンテを修正 (欠落/尺整合/締めフェーズ有無を機械検証)。

## Step 4: 見積りと予算確定

- MCP経路: 各ショットを `generate_video` の **get_cost:true** で事前見積し合計を算出。
- 合計 ≤ 予算 → そのまま続行 (お客様には「予算内で開始します(見積N cr)」と一言)。超過見込み → 停止して「見積/予算/選択肢(予算追加・カット削減・低コストモデル)」を提示。
- 以後、生成のたびに `director-engine.sh ledger <dir> add <cr> "<内容>"` で実測記録。**BLOCK (exit 2) が返ったら生成を止めて報告**。

## Step 5: キーフレーム生成 (③ 撮影)

`pipeline: image_first` の各ショットについて:
1. `generate_image` (MCP) または `runner.mjs image` で静止画生成 (プロンプトはショットの prompt_en)。
2. ダウンロードして `keyframes/<shot_id>.jpg` に保存 → **Read で目視評価** (構図/破綻/スタイル一致)。
3. 不合格は原因をプロンプトに反映して**1回だけ**再生成。それでも不合格なら構図を変えて作り直すか text_direct に切替。
4. 人物の一貫性が必要な案件は SoulID (キャラ学習) を先に作成し `custom_reference_id` で全ショットに適用する。

## Step 6: ショット動画生成 + 自動QCループ (④ 検品)

各ショットについて:
1. `generate_video` (MCP・model は model-matrix 参照・キーフレーム画像を入力) または `runner.mjs video --json '{"model":"...","prompt":"...","image":"keyframes/<id>.jpg"}'`。
2. 完了URLから `clips/<shot_id>.mp4` へダウンロード。
3. `bash "$VD/qc-extract.sh" clips/<id>.mp4 frames/<id>` → 抽出フレームを **Read で7項目評価**: ①破綻(手指/顔/溶け) ②文字化け ③動きの自然さ(first↔last) ④構図 ⑤露出 ⑥スタイル一貫性 ⑦意図したカメラワークか。
4. 不合格 → 失敗原因を negative_en / prompt_en に反映して再生成 (**最大2回**・台帳ガード内)。2回失敗したら別モデル or 絵コンテ差替えを判断。
5. 全ショット合格まで編集に進まない。評価結果は `evidence/qc-<shot_id>.md` に1行ずつ記録 (実測のみ)。

## Step 7: 音の設計

- **BGM**: ユーザー提供ファイルがあれば `audio/` に配置して使用。無ければ BGM 無しで仕上げ、納品時に「音楽ファイルを頂ければ5分で差し替え可能」と案内 (edl.json の bgm を足して assemble 再実行するだけ)。
- **ナレーション**: 要望時のみ。`/v1/speak/higgsfield` (要WAV) か、ユーザー録音を使用。

## Step 8: 編集仕上げ (⑤ 編集仕上げ)

`edl.json` を書いて自動編集を実行:

```bash
bash "$VD/assemble.sh" run <dir>   # → out/final_<export>.mp4 + out/thumb.jpg
```

- `items`: QC合格クリップを文法のフェーズ順に配列。`{"type":"title","text":"...","sub":"...","sec":2.5}` でタイトルカード、trim で各カットの一番良い瞬間だけを使う。
- `transition`: 予告編=cut 基調 (タイトル前はハードカット)、ラグジュアリー/エモーショナル=fade。
- `logo`: ロゴPNGがあれば `{"src":"titles/logo.png","pos":"br","last_sec":6}`。
- `bgm`: `{"src":"audio/bgm.mp3","gain_db":-8,"duck":true,"fade_out":2}`。
- `export`: youtube_16x9 / sns_9x16 / square_1x1 / hd_16x9。`loudnorm` は既定 on (-14 LUFS)。
- 完成後、`out/final_*.mp4` を再度 `qc-extract.sh` にかけて通し確認 (繋ぎ目・テロップ表示秒数・音量)。

## Step 9: 最終品質ゲート (10軸・実測)

完成宣言の前に全軸を実測確認 (未達があれば修正してから宣言):

| # | 軸 | 実測方法 |
|---|---|---|
| 1 | 冒頭フック | 最初のカットが最強画か (絵コンテ再照合) |
| 2 | テンポ | カット尺がプリセット pacing ±50% 内 |
| 3 | テロップ可読性 | タイトル表示 ≥1.5秒・コントラスト目視 |
| 4 | 音声バランス | loudnorm 適用済 + ダッキング動作 |
| 5 | ブランド一貫性 | ロゴ/色がブランド素材と一致 |
| 6 | CTA | ラストにブランド+行動喚起がある |
| 7 | 比率/解像度 | 出力が指定 export と一致 (assemble の実測JSON) |
| 8 | 色の一貫性 | 全カットがプリセット grade で統一 (通しフレーム目視) |
| 9 | 書き出し品質 | h264/yuv420p/faststart (assemble が保証) |
| 10 | サムネイル | out/thumb.jpg が訴求力ある1枚か (必要なら thumb_sec 変更) |

## Step 10: 納品報告 (毎回必須)

完成報告に必ず含める: ①完成ファイルと サムネイルの場所 ②ショット構成表 (何カット・各何秒) ③**消費クレジット実測** (ledger status の値・見積との差) ④撮り直し回数 ⑤未達事項の正直開示 (BGM未収録等) ⑥**次の一手** (例:「音楽を頂ければ差し替え5分」「9:16版も同じ絵コンテから10分で出せます」「この絵コンテを雛形化して量産できます」)。

---

## 運用ルール

- **モデル実測の自己学習**: 新モデルの実測コスト/品質所感は `model-matrix.json` の measured_costs に追記する (次回から見積精度が上がる)。
- **連作の効率化**: 同一ブランドの2本目以降は、過去プロジェクトの shotlist.json / スタイルロック句 / SoulID を再利用する。
- **失敗の正直開示**: nsfw/failed はクレジット返還されるため台帳に載せない。ただし発生回数は納品報告に記す。
- **保守 (管理者)**: born-passing は `director-engine.sh selftest` (8項目) / `assemble.sh selftest` (3ケース・要 ffmpeg-full)。依存: ffmpeg-full (drawtext必須・`brew install ffmpeg-full`)、Node 18+、@higgsfield/client (hf-runner/ に導入済)。スキルSoTは `~/.claude/commands/soloptilink-video.md`、ミラーは `~/.claude/skills/soloptilink-video/SKILL.md` (両方同時更新)。
