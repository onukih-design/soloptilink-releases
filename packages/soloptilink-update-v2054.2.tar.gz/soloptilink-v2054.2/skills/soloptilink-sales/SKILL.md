---
name: soloptilink-sales
description: "SoloptiLinkAI v2054.2 - 「営業」「セールス」「クロージング」「提案書」「ピッチ」「営業資料」「営業動画」「商談」「反論処理」「パイプライン」「ロープレ」「バトルカード」等で起動。再現性高く売れる営業の仕組みを自動化する。"
argument-hint: "[作りたい営業成果物 (提案書/ピッチ/動画/メール/バトルカード/...)] [--industry construction|...] [--persona CEO|CFO|...] [--duration 10s|30s|3min|15min]"
allowed-tools: Bash, Read, Write, Edit, Glob, Grep, Task, Agent, WebSearch, WebFetch
---

# SoloptiLinkAI v2054.2 - Sales Engine - Centurion Sales Force


## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

## 機能概要

SoloptiLinkAI v2025.0 Sales Engine "Centurion Sales Force" - 営業組織が増えても再現性高く売れる仕組みを完全自動化。ICP/ペルソナ自動生成(20業種×12ロール)、BANT/SPIN/MEDDIC/Challenger Sale 戦略フレーム、8つのクロージング技法+105反論処理パターン(PRICE/TIMING/COMPETITOR/AUTHORITY/NEED/TRUST/RISK/IMPLEMENTATION/INTEGRATION/CHANGE_RESISTANCE)、提案書8セクション自動生成、ピッチ4段階(10秒/30秒/3分/15分)、営業動画8テンプレ(製品デモ/事例/反論処理/Webinar/Onboarding/SNSショート)、パイプライン健全性+3シナリオ売上予測+Win/Loss分析+営業マンランキング+Sales Velocity、競合バトルカード8社(Claude Code/Copilot/Cursor/SAP/kintone/freee等)+トラップ質問+セールスプレイ、メールシーケンス6種(Cold/Nurture/Follow/Reactivation/PostDemo/ClosingPush)、KPIベンチマーク+ロールプレイ7シナリオ+商談振り返りコーチング、戦略アカウント計画+Land-and-Expand戦略を統合。Sales Excellence Fortress (11軸170点 Diamond) 採点。「営業」「セールス」「クロージング」「提案書」「ピッチ」「営業資料」「営業動画」「商談」「クロージング」「反論処理」「KPI」「パイプライン」「売上予測」「営業マン」「ロープレ」「競合分析」「バトルカード」等で起動。営業組織が10名から100名・500名に増えても受注率・単価・サイクルを構造的に改善する基盤。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

## コンセプト

通常の `/soloptilink` がエンジンなら、`/soloptilink-sales` は**営業組織のオペレーティングシステム**。営業マン1名が達成していたパフォーマンスを、組織全体で標準化・再現する基盤。

「いま25社契約・目標6ヶ月500社」というスケールには、属人化した営業力ではなく、**100名の営業マンが入っても全員が同じ品質で売れる仕組み**が必須。本スキルはその仕組みを、12モジュール+11軸品質ゲートで提供する。

## 起動条件

以下のキーワードを含む依頼で自動起動:

| カテゴリ | 検出キーワード |
|---------|---------------|
| 戦略 | 営業戦略 / Sales Strategy / ICP / ペルソナ / リード / ターゲット / Segmentation |
| フレームワーク | BANT / SPIN / MEDDIC / Challenger / Sales Methodology |
| クロージング | クロージング / Closing / 反論処理 / Objection / 切り返し / Take-Away / Urgency |
| 資料 | 提案書 / Proposal / ピッチ / Pitch / プレゼン資料 / 稟議書 / RFI回答 |
| 動画 | 営業動画 / Sales Video / プロダクトデモ動画 / 事例動画 / Webinar / Reels / Shorts |
| パイプライン | パイプライン / Pipeline / 商談 / Deal / Win Rate / Sales Velocity / Forecast |
| 分析 | Win/Loss / 受注率 / 失注分析 / Sales Performance / 営業マンランキング / KPI |
| 競合 | 競合分析 / バトルカード / Battlecard / 競合プレイ / Trap Question |
| メール | メールシーケンス / Email Sequence / Outreach / Nurture / Cold Email |
| 研修 | ロールプレイ / Roleplay / 商談コーチング / Call Review / 営業研修 |
| アカウント | アカウントプラン / Account Plan / Land-and-Expand / Strategic Account |

## 12コアモジュール

すべて `~/.soloptilink/lib/sales/` に配置 (約3500行 TypeScript)

### 1. ICP / Persona Engine (`icp_engine.ts`)
- **20業種×12ロール**で ICP / ペルソナ自動生成
- 業種別の痛点・必須シグナル・Disqualifier をDNAとして内蔵
- リードスコアリング (FIT 50 + INTENT 30 + AUTHORITY 20 = 100点)
- Tier判定: Hot 75+ / Warm 55+ / Lukewarm 35+ / Cold

### 2. Sales Strategy (`sales_strategy.ts`)
- **BANT** (Budget/Authority/Need/Timeline) アセスメント+ Gap質問自動生成
- **SPIN** (Situation/Problem/Implication/Need-payoff) 業種別質問セット
- **MEDDIC** スコアリング+ Champion/Economic Buyer 評価
- **Challenger Sale** (Warmer/Reframe/Rational Drowning/Emotional Impact/New Way/Our Solution)
- 商談10ステージ確率マッピング+ Next-Best-Action 推奨

### 3. Closing Coach (`closing_coach.ts`)
- **8つのクロージング技法**: Assumptive / Now-or-Never / Summary / Sharp Angle / Question / Soft / Take-Away / Urgency
- 各技法に Setup/Trigger/Follow-up/If-Yes/If-No/If-Maybe/Caution の7要素
- **Buyer Signals 10種**から Closing Readiness Score (0-100) を算出
- Stageに応じた推奨技法を自動選定

### 4. Objection Library (closing_coach.tsに統合)
- **105反論処理パターン**: PRICE 15 / TIMING 15 / COMPETITOR 10 / AUTHORITY 10 / NEED 10 / TRUST 10 / RISK 10 / IMPLEMENTATION 3 / INTEGRATION 3 / CHANGE_RESISTANCE 5
- 各反論に **5ステップ応答**: Empathy → Question → Reframe → Proof → Next Step
- カテゴリ検索 + キーワード検索で即引き出し可能

### 5. Proposal Generator (`proposal_generator.ts`)
- **8セクション提案書**自動生成 (Markdown + Word変換可)
- 1. エグゼクティブサマリー / 2. 課題と放置コスト / 3. ソリューション / 4. ROIシミュレーション / 5. 導入スケジュール / 6. 価格・契約条件 / 7. 導入実績 / 8. 次の一歩
- 3年累計 ROI / 投資回収月数 / 段階導入計画を自動算出

### 6. Sales Pitch (`sales_pitch.ts`)
- **4段階ピッチ**: 10秒(エレベーター) / 30秒(展示会) / 3分(初回商談) / 15分(経営層プレゼン)
- 業種別 Hook 候補 (20業種×2フレーズ)
- Speaker Notes / Visual Cues / Recommended Use Cases 付き

### 7. Video Studio (`sales_video_studio.ts`)
- **8動画テンプレ**: 60秒/3分プロダクトデモ / 顧客事例2分 / 反論処理45秒 / Cold Outreach 30秒 / Webinar Intro 5分 / Onboarding Welcome 2分 / SNSショート 15秒
- シーン別ナレーション+ 画面+ オンスクリーンテキスト+ BGMムード+ トランジション
- サムネイル設計 / キャプション / 公開チャネル / 制作工数 まで

### 8. Pipeline Analytics (`pipeline_analytics.ts`)
- **Pipeline Health Score** (0-100) + Stale検出 (14日以上動きなし)
- **3シナリオ売上予測**: Best / Realistic / Worst Case + Committed / Weighted
- **Win/Loss Analysis**: 受注率 / 平均サイクル日数 / Top失注理由 / Top競合
- **Sales Rep Ranking**: 営業マン別 Revenue / 受注率 / Pipeline / 強み・改善エリア
- **Sales Velocity**: 改善レバー4種(Qualified数/単価/受注率/サイクル) + 影響金額試算

### 9. Competitive Battlecard (`competitive_battlecard.ts`)
- **8競合プロファイル**: Claude Code / Copilot / Cursor / 内製 / SAP / kintone / 大手SIer / freee
- **バトルカード**: When We Win / When We Lose / Positioning Pivots / Trap Questions / Proof Points / Pricing Landmines / Reference Customers / Sales Play Summary
- 競合別 Attack/Defense アングル+ Must Say/Must Not Say+ Killer Data

### 10. Email Sequence (`email_sequence.ts`)
- **6種シーケンス**:
  - Cold Outreach 7-touch (30日)
  - Nurture (90日 月次/四半期コンテンツ)
  - Post-Demo Follow-up (5タッチ19日)
  - Closing Push (3タッチ5日)
  - Reactivation (3タッチ15日)
- 各メールに件名+本文+CTA+Personalization Tokens+期待返信率+No-reply時アクション

### 11. Sales KPI + Roleplay (`sales_kpi.ts`)
- **KPIベンチマーキング**: 13指標 × top quartile / median / bottom quartile (SaaS日本市場値)
- 改善アクションを指標別に自動提案
- **ロールプレイ7シナリオ**: Cold Call初回 / Price反論 / Champion育成 / Final Negotiation / 競合プレゼン / SPIN Discovery / + 業界別カスタム
- **Call Review**: Talk Ratio / 質問数 / SPIN Coverage / Objections / Next Steps から Coaching Feedback 自動生成

### 12. Strategic Account Planning (`account_planning.ts`)
- **アカウントプラン**: Stakeholder Map / Whitespace / 1年目標 / 3年ビジョン / 四半期マイルストーン / Expansion Play / Retention Play / Competitive Defense / Governance(QBR頻度)
- **Land-and-Expand戦略**: 3フェーズ展開計画 (初期着地 → クロスセル → 全社展開)
- リテンションリスク自動検出+ 推奨アクション

## 実行手順

### Step 0: 認証確認
```bash
SOLOPTILINK_BIN=""; if [ -f ~/.soloptilink/soloptilink ]; then SOLOPTILINK_BIN="./soloptilink"; fi
AUTH_CHECK=$(cd ~/.soloptilink 2>/dev/null && ${SOLOPTILINK_BIN:-./soloptilink} --status 2>&1)
if echo "$AUTH_CHECK" | grep -q "承認済み"; then echo "AUTHORIZED"; else echo "UNAUTHORIZED"; fi
```

UNAUTHORIZED時は `/soloptilink` のメッセージに誘導し作業中止。

### Step 1: Sales Engine ステータス確認
```bash
bash ~/.soloptilink/lib/sales/sales-bridge.sh status
bash ~/.soloptilink/lib/sales/sales-bridge.sh health-check
```

### Step 2: 依頼カテゴリ判定 (Silent Inference)

ユーザ依頼から以下に分類:

| カテゴリ | 出力モジュール |
|---------|---------------|
| 戦略立案 | ICP + Strategy + Account Planning |
| 提案書作成 | Proposal Generator |
| プレゼン/ピッチ | Sales Pitch (4段階から最適選定) |
| 動画スクリプト | Video Studio |
| メール作成 | Email Sequence |
| 競合対応 | Competitive Battlecard |
| 商談分析 | Pipeline Analytics + KPI |
| 営業研修 | Roleplay + Coaching |
| クロージング | Closing Coach + Objection Library |
| KPI設計 | Sales KPI Benchmarking |

### Step 3: 業種・ペルソナ・コンテキスト確定

引数または推論で以下を確定:
- 業種 (`--industry`): 20業種から選択
- ペルソナロール (`--persona`): 12ロールから選択
- 製品ポジショニング: SoloptiLinkAI標準 or カスタム
- 規模: micro/small/medium/large/enterprise

### Step 4: 成果物生成

該当モジュールを TypeScript として import し、関数を呼び出す。生成物は:
- Markdown形式 (提案書/ピッチ/メール本文)
- JSON形式 (KPIベンチマーク/Pipeline分析)
- HTML / PDF への変換も可 (`anthropic-skills:docx`/`pptx` と連携)

### Step 5: Sales Excellence Fortress 採点

```bash
# 通常採点
bash ~/.soloptilink/lib/quality-fortresses/sales-excellence-fortress.sh run \
    "$PROJECT_DIR" "$PROJECT_DIR/.sales-excellence/result.json"

# REAL_VERIFY 込み(SE05/SE08/SE12/SE15 を実走検証)
REAL_VERIFY=1 bash ~/.soloptilink/lib/quality-fortresses/sales-excellence-fortress.sh run \
    "$PROJECT_DIR" "$PROJECT_DIR/.sales-excellence/result-real.json"

# Hendekafortress (11 Fortress 1870点)
bash ~/.soloptilink/lib/quality-fortresses/hendekafortress.sh run "$PROJECT_DIR"
```

採点軸 (17×10=170点):
| 軸 | 内容 |
|---|---|
| SE01 | ICP/Persona Engine 配置 |
| SE02 | 業種(20)×ロール(12) カバレッジ |
| SE03 | BANT+SPIN+MEDDIC+Challenger 統合 |
| SE04 | 10商談ステージ確率マッピング |
| SE05 | Closing 8技法 + Objection 80+ ★REAL |
| SE06 | Buyer Signal検出 + Readinessスコア |
| SE07 | Proposal 8セクション構造 |
| SE08 | Pitch 4段階 (10s/30s/3min/15min) ★REAL |
| SE09 | Video 8テンプレート |
| SE10 | Pipeline健全性 + Stale検出 |
| SE11 | 売上予測 3シナリオ |
| SE12 | Win/Loss + Sales Velocity ★REAL |
| SE13 | 競合バトルカード 8社 |
| SE14 | メールシーケンス 6種 + Personalization |
| SE15 | KPIベンチマーク + 改善アクション ★REAL |
| SE16 | Roleplay + Call Review コーチング |
| SE17 | Account Planning + Land-Expand |

認定: Diamond 162-170 / Platinum 142-161 / Gold 110-141 / Silver 80-109 / Bronze <80

### Step 6: BOOST/JAPAN-NATIVE との統合

- `/soloptilink-boost` の Step 0.62 (新設) で本スキルが自動呼び出される
- `/soloptilink-japan` の業種辞書と連携 (建設→construction.json等)
- `/soloptilink-tenant-dna` のSIer別雛形と連携可能 (NTTデータ式営業/富士通式営業)
- `/soloptilink-creative` のPPTX/動画生成と連携 (提案書→PowerPoint, 動画スクリプト→絵コンテ)

## 使用例

### 例1: 提案書生成
```
/soloptilink-sales 建設業の経営者向け提案書を作って 案件名: A社原価管理システム
```
→ ICP生成 → ペルソナ生成 → 提案書8セクション自動生成 → Word変換可

### 例2: クロージング支援
```
/soloptilink-sales お客さんから「価格が高い」と言われた、切り返しを教えて
```
→ Objection Library から PRICE カテゴリ抽出 → 5ステップ応答提示 → 関連事例

### 例3: 営業マン研修
```
/soloptilink-sales 新人営業マン向けロープレシナリオを作って、難易度別に
```
→ 7シナリオ生成 (Beginner/Intermediate/Advanced/Expert) + 評価軸 + Trainer Notes

### 例4: パイプライン健全性診断
```
/soloptilink-sales 今月のパイプラインの健全性を診断して。CSV データ: deals.csv
```
→ Pipeline Health Score + Stale検出 + 3シナリオForecast + Sales Rep Ranking

### 例5: 競合プレゼン準備
```
/soloptilink-sales Claude Codeと比較されている。バトルカードを出して
```
→ Claude Code バトルカード(Trap Questions / Proof Points / Pricing Landmines / Sales Play Summary)

### 例6: メールシーケンス
```
/soloptilink-sales 製造業CFO向けのCold Outreach 7-touchシーケンスを作って
```
→ 7メール+電話 + 件名 + 本文 + CTA + Personalization Tokens + No-reply時アクション

### 例7: 戦略アカウント計画
```
/soloptilink-sales B社向けの3年アカウントプランを作って 現契約ACV: 1200万円
```
→ Stakeholder Map + Whitespace + 四半期マイルストーン + Land-and-Expand 3フェーズ

## v2025.0 で出来るようになったこと

| Before | After |
|--------|-------|
| 営業マン個人のセンスに依存 | 12モジュール+105反論パターンの構造化資産で再現性確保 |
| 提案書を毎回ゼロから | 8セクションテンプレ+ROI自動算出で60分→10分 |
| 競合対応がアドホック | 8社のバトルカード+トラップ質問で即引き出し |
| 売上予測が経験則 | 3シナリオ予測+ Sales Velocity改善レバー定量化 |
| 営業研修が場当たり | ロープレ7シナリオ+ Coaching Feedback で継続改善 |
| 営業マン10名超えで品質低下 | Sales Excellence Fortress採点で組織レベル品質保証 |
| 値引きで失注回避 | 8技法+Take-Away+Pricing Landminesで価格防衛 |

## アンチパターン (避けるべき使い方)

- **顧客に対して直接スクリプトを読み上げない**: 各ピッチ/メールはテンプレ。実商談では相手の発言に応じて即興でブレンドする
- **反論処理ライブラリを丸読み**: ライブラリは型。共感の深さ・タイミング・トーンが決定要素
- **競合バトルカードで悪口を言う**: Must Not Say 必読
- **ロープレを練習なしで実商談**: 練習回数 × 受注率の相関は強い

## ストレージとプライバシー

- 全モジュールは `~/.soloptilink/lib/sales/` 配下に**ローカル保存のみ**
- 顧客固有情報(商談ログ・提案書ドラフト)は `~/.soloptilink/sales-data/{tenant_id}/` 配下に分離
- データ送出ゼロ。ARTE-Defender の SIEM Bridge と統合可能(オプション)

## バージョン履歴

- v2025.0 (2026-04-29): Sales Engine "Centurion Sales Force" 新設
  - 12モジュール 約3500行
  - Sales Excellence Fortress (11軸170点) 新設
  - Hendekafortress (11×170=1870点) 拡張
  - REAL_VERIFY 4軸追加 (累計37軸)
- 統合: BOOST Step 0.62 / JAPAN-NATIVE業種辞書 / Tenant DNA / Creative

## 関連スキル

- `/soloptilink-boost` v2024.0+ (BOOST Step 0.62 で自動連携)
- `/soloptilink-japan` (業種辞書連携)
- `/soloptilink-tenant-dna` (SIer別営業雛形)
- `/soloptilink-creative` (提案書→PPTX変換、動画台本→絵コンテ)
- `/soloptilink-rfp` (RFP→提案書フローと連動)
