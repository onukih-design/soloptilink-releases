#!/bin/bash
# ============================================================
# SoloptiLinkAI Auto-Update v2009.4
#
# Claude Code起動時にバックグラウンドで実行される。
# お客さんは何もしなくても常に最新版になる。
#
# 仕組み:
#   1. 24時間キャッシュで頻度制限
#   2. 排他ロック（複数Claude Codeウィンドウ対策）
#   3. APIに最新バージョンを問い合わせ
#   4. 更新があればパッケージをダウンロード
#   5. SHA256検証後、全ファイルを安全に更新
#   6. skills/agents/hooks も含めて完全更新
#   7. 更新後検証ステータスを記録
#
# 配置: ~/.soloptilink/auto-update.sh
# フック: ~/.claude/settings.json の UserPromptSubmit
# ============================================================

# ============================================================
# PFP-101 自己上書き安全化 (2026-06-10): 更新処理は auto-update.sh 自身も
# 置換する。bash は実行中ファイルが置換されると以降を誤読し
# 「command not found / 構文エラー」を吐く (実測: v2034.4→v2038.2 更新時)。
# → 起動直後に一時コピーへ退避し、そちらを再実行することで根絶する。
# ============================================================
if [ -z "${SOLOPTILINK_AUTOUPDATE_REEXEC:-}" ]; then
    _self_tmp=$(mktemp "${TMPDIR:-/tmp}/sl-autoupdate.XXXXXX" 2>/dev/null) || exit 0
    cat "$0" > "$_self_tmp" 2>/dev/null || { rm -f "$_self_tmp"; exit 0; }
    SOLOPTILINK_AUTOUPDATE_REEXEC=1 exec bash "$_self_tmp" "$@"
fi

SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
CLAUDE_DIR="$HOME/.claude"
CACHE_FILE="$SL_DIR/.last_auto_update_check"
API_BASE="${SOLOPTILINK_API_URL:-https://admin-dashboard-blue-alpha-78.vercel.app/api/v1}"
CHECK_INTERVAL=86400  # 24時間
LOG_FILE="$SL_DIR/.auto-update.log"
LOCK_DIR="$SL_DIR/.auto-update.lock"
STATUS_FILE="$SL_DIR/.auto-update-status.json"

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE" 2>/dev/null; }

# ============================================================
# 2026-07-15 貝沼建設事案 (スラッシュメニューから boost が消える) 恒久対策:
# スキル/コマンドのアトミック置換 helper
# - 従来の `cp src dst` は truncate→write の非アトミック更新で、書込中に
#   Claude Code がスキル走査すると SKILL.md が「空/途中」に見えてメニュー脱落した。
# - _sl_atomic_cp: 同ディレクトリの一時名に cp してから mv (rename は原子的)。
# - _sl_atomic_dir_replace: references 等のディレクトリを「新を横に展開→旧を退け→即 mv」
#   で置換する (従来の rm -rf → cp -R は cp の間ずっと欠落窓が開いていた)。
# ============================================================
_sl_atomic_cp() {
    local src="$1" dst="$2" tmp
    [ -f "$src" ] || return 1
    mkdir -p "$(dirname "$dst")" 2>/dev/null
    tmp="${dst}.slnew.$$"
    if cp "$src" "$tmp" 2>/dev/null && mv -f "$tmp" "$dst" 2>/dev/null; then
        return 0
    fi
    rm -f "$tmp" 2>/dev/null
    # rename 不能環境のみ従来コピーへフォールバック (無いよりまし)
    cp "$src" "$dst" 2>/dev/null
}
_sl_atomic_dir_replace() {
    local srcdir="$1" dstdir="$2" tmp old
    [ -d "$srcdir" ] || return 1
    mkdir -p "$(dirname "$dstdir")" 2>/dev/null
    tmp="${dstdir}.slnew.$$"
    old="${dstdir}.slold.$$"
    rm -rf "$tmp" 2>/dev/null
    cp -R "$srcdir" "$tmp" 2>/dev/null || { rm -rf "$tmp"; return 1; }
    if [ -d "$dstdir" ]; then
        mv "$dstdir" "$old" 2>/dev/null || { rm -rf "$dstdir" 2>/dev/null; }
    fi
    mv "$tmp" "$dstdir" 2>/dev/null || { rm -rf "$tmp"; [ -d "$old" ] && mv "$old" "$dstdir" 2>/dev/null; return 1; }
    rm -rf "$old" 2>/dev/null
    return 0
}

# ============================================================
# PFP-177 (2026-07-20 高山様事案): 管理者専用スキルの顧客端末残存を自己修復
# 2026-04-16〜07-20 の payload に soloptilink-release が混入し、旧バイナリは
# 実行毎にそれを ~/.claude/skills へ書き戻す。本フックはセッション開始毎に
# 走るため、ここでの除去が旧バイナリ端末の恒常的な救済層になる。
# 管理者端末 (.admin_mode あり) では SoT (~/.claude) を温存し配信ソース側のみ浄化。
# ============================================================
_sl_is_admin_only_skill() {
    case "$1" in soloptilink-release|soloptilink-deploy|soloptilink-doctor) return 0 ;; esac
    return 1
}
_sl_purge_admin_skills() {
    local _n _purged=0
    for _n in soloptilink-release soloptilink-deploy soloptilink-doctor; do
        for _t in "$SL_DIR/skills/$_n" "$SL_DIR/launcher/skills/$_n"; do
            [ -e "$_t" ] && rm -rf "$_t" 2>/dev/null && _purged=$((_purged + 1))
        done
        if [ ! -f "$SL_DIR/.admin_mode" ]; then
            [ -e "$CLAUDE_DIR/skills/$_n" ] && rm -rf "$CLAUDE_DIR/skills/$_n" 2>/dev/null && _purged=$((_purged + 1))
            [ -f "$CLAUDE_DIR/commands/$_n.md" ] && rm -f "$CLAUDE_DIR/commands/$_n.md" 2>/dev/null && _purged=$((_purged + 1))
        fi
    done
    [ "$_purged" -gt 0 ] && log "ADMIN_SKILL_PURGED count=$_purged (PFP-177)"
    return 0
}
_sl_purge_admin_skills 2>/dev/null || true

# ============================================================
# v2034.2 で堅牢化: 共通 curl helper
# - stderr を .error-log に集約 (黙殺禁止)
# - リトライ 3回 / 接続タイムアウト 10秒 / 全体タイムアウト引数化
# - --fail-with-body で HTTP エラー時もボディ取得
# - rc != 0 の時のみ error-log に記録 (成功時はノイズ無し)
# ============================================================
_sl_curl() {
    local method="$1" url="$2" outfile="${3:-}" timeout="${4:-15}"
    local error_log="$SL_DIR/.error-log"
    # PFP-101 (2026-06-10): -L 必須。GitHub Releases 等の 302 リダイレクト配信で
    # 追従しないと空ボディ (0バイト) を保存し DOWNLOAD_TOO_SMALL で全更新が失敗する
    local curl_args=(-s -L --max-redirs 5 --connect-timeout 20 --retry 3 --retry-delay 2 --fail-with-body)
    if [ -n "$outfile" ]; then
        # ファイルDL (大容量): 絶対期限を課さず「停滞」だけで中断する。
        # 2026-07-13 インサイドグロース事案: 絶対 --max-time (90/120s) が低速回線の
        # 大容量DL (11〜19MB) を構造的に失敗させていた。--speed-limit/--speed-time は
        # 「120秒間 実効1B/s未満 = 停滞」のみを異常とみなす (完走時間は無制限に近い保険値)。
        curl_args+=(--speed-limit 1 --speed-time 120 --max-time 7200 -o "$outfile")
    else
        # 小さな API 呼び出し: 従来どおり短い絶対期限
        curl_args+=(--max-time "$timeout")
    fi
    local stderr_capture
    stderr_capture=$(mktemp)
    local response rc
    if [ "$method" = "GET" ]; then
        response=$(curl "${curl_args[@]}" "$url" 2>"$stderr_capture")
        rc=$?
    else
        response=$(curl "${curl_args[@]}" -X "$method" "$url" 2>"$stderr_capture")
        rc=$?
    fi
    if [ $rc -ne 0 ]; then
        echo "$(date '+%Y-%m-%dT%H:%M:%S') [curl] FAIL rc=$rc url=$url $(cat "$stderr_capture" | tr '\n' ' ' | head -c 200)" >> "$error_log" 2>/dev/null
    fi
    rm -f "$stderr_capture"
    [ $rc -eq 0 ] && echo "$response"
    return $rc
}

# ========================================
# 排他ロック（複数ウィンドウ同時実行防止）
# ========================================
# mkdir はアトミック操作 → 安全なロック
if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    # ロックが存在 → 別インスタンスが実行中
    # ただし5分以上経過したロックはスタール（古い）とみなす
    if [ -d "$LOCK_DIR" ]; then
        LOCK_MTIME=$(stat -f %m "$LOCK_DIR" 2>/dev/null || stat -c %Y "$LOCK_DIR" 2>/dev/null || echo 0)
        NOW_TS=$(date +%s)
        LOCK_AGE=$((NOW_TS - LOCK_MTIME))
        if [ "$LOCK_AGE" -gt 300 ]; then
            rmdir "$LOCK_DIR" 2>/dev/null
            mkdir "$LOCK_DIR" 2>/dev/null || exit 0
        else
            exit 0
        fi
    else
        exit 0
    fi
fi
# ロック解除のtrap（親プロセス終了時）+ 自己コピー掃除 (PFP-101)
trap "rmdir '$LOCK_DIR' 2>/dev/null; rm -f '$0' 2>/dev/null" EXIT

# ========================================
# 強制更新フラグ（--force または SOLOPTILINK_FORCE_UPDATE=1）
# ========================================
FORCE_UPDATE=false
if [ "${1:-}" = "--force" ] || [ "${SOLOPTILINK_FORCE_UPDATE:-${SOLAI_FORCE_UPDATE:-0}}" = "1" ]; then
    FORCE_UPDATE=true
fi

# ========================================
# 頻度チェック（24時間以内ならスキップ、--force時は無視）
# ========================================
if [ "$FORCE_UPDATE" = false ] && [ -f "$CACHE_FILE" ]; then
    LAST_CHECK=$(cat "$CACHE_FILE" 2>/dev/null || echo "0")
    # 数値チェック
    case "$LAST_CHECK" in
        ''|*[!0-9]*) LAST_CHECK=0 ;;
    esac
    NOW=$(date +%s)
    ELAPSED=$((NOW - LAST_CHECK))
    if [ "$ELAPSED" -lt "$CHECK_INTERVAL" ]; then
        exit 0
    fi
fi

# ========================================
# 現在のバージョンを取得
# ========================================
CURRENT_VERSION=""
if [ -f "$SL_DIR/chain.sh" ]; then
    CURRENT_VERSION=$(grep 'readonly VERSION=' "$SL_DIR/chain.sh" 2>/dev/null | head -1 | grep -o '"[^"]*"' | tr -d '"')
elif [ -f "$SL_DIR/VERSION" ]; then
    CURRENT_VERSION=$(cat "$SL_DIR/VERSION" 2>/dev/null | tr -d '[:space:]')
fi
# chain.sh も VERSION も無い → 初回インストール扱い（バージョン0.0.0として更新チェック）
[ -z "$CURRENT_VERSION" ] && CURRENT_VERSION="0.0.0"

# ========================================
# Migration 自動適用 (idempotent / NOOP if applied)
# v2027.0+ 既存顧客遡及配線レーン
# ========================================
if [ -d "$SL_DIR/migration" ]; then
    for mig in "$SL_DIR/migration/"v*.sh; do
        [ -f "$mig" ] || continue
        mig_name=$(basename "$mig" .sh)
        # state ファイルを読み、既に適用済みの migration はスキップ
        if [ -f "$SL_DIR/.migration-state.json" ] && grep -q "\"${mig_name}\"" "$SL_DIR/.migration-state.json" 2>/dev/null; then
            continue
        fi
        bash "$mig" >> "$SL_DIR/.migration.log" 2>&1 || true
    done
fi

# ========================================
# PFP-064b (2026-07-06): スキル表記の毎回追従パス (every-run / idempotent / 軽量)
# ----------------------------------------
# 実欠陥: SoT (~/.claude/commands/<skill>.md) は導入時版のまま更新対象になっておらず、
# 更新直後の heal が新 SKILL.md を旧版へ巻き戻し「本体は最新・表記は導入時版」に固着した
# (実例: 本体 v2050.1 で picker 表記 v2038.0)。本パスは毎回の起動で
# 「本体側 skills (配布で更新済) の版 > SoT/picker の版」の時だけ追従コピーする。
# 版数が取れない・同版・SoT が新しい場合は無操作 (管理者の正典編集を壊さない)。
# ========================================
_sl_skill_ver_num() {
    local v
    v=$(head -15 "$1" 2>/dev/null | grep -oE 'v20[0-9][0-9]\.[0-9][0-9]*' | head -1)
    [ -z "$v" ] && return 0
    local major="${v#v}"; major="${major%%.*}"
    local minor="${v##*.}"
    echo $(( major * 1000 + minor ))
}
_sl_skill_freshness_pass() {
    local sdir sname body_md target bv cv
    for sdir in "$SL_DIR/skills/soloptilink"*/; do
        [ -d "$sdir" ] || continue
        sname=$(basename "$sdir")
        # PFP-177: 管理者専用スキルは SoT/picker へ絶対に伝播させない
        _sl_is_admin_only_skill "$sname" && continue
        body_md="$sdir/SKILL.md"
        [ -f "$body_md" ] || continue
        bv=$(_sl_skill_ver_num "$body_md")
        [ -n "$bv" ] || continue
        for target in "$CLAUDE_DIR/commands/${sname}.md" "$CLAUDE_DIR/skills/$sname/SKILL.md"; do
            [ -f "$target" ] || continue
            cv=$(_sl_skill_ver_num "$target")
            if [ -n "$cv" ] && [ "$bv" -gt "$cv" ] 2>/dev/null; then
                _sl_atomic_cp "$body_md" "$target" && log "SKILL_FRESHENED $target (→ body版)"
            fi
        done
    done
    return 0
}
_sl_skill_freshness_pass 2>/dev/null || true

# バージョン文字列をサニタイズ（URL安全化）
SAFE_VERSION=$(echo "$CURRENT_VERSION" | tr -cd '0-9.')
[ -z "$SAFE_VERSION" ] && exit 0

# ========================================
# APIで最新バージョンをチェック
# ========================================
OS=$(uname -s | tr '[:upper:]' '[:lower:]')
ARCH=$(uname -m)
case "$ARCH" in
    x86_64)        ARCH="amd64" ;;
    aarch64|arm64) ARCH="arm64" ;;
esac

# OS 正規化 (2026-06-16): Git Bash/MSYS/Cygwin の uname は mingw64_nt-... 等になる。
# updates/check の os パラメータ・/updates/download・ランチャー実体名は windows で扱う必要がある。
API_OS="$OS"
LAUNCHER_NAME="soloptilink"
case "$OS" in
    mingw*|msys*|cygwin*|windows*) API_OS="windows"; LAUNCHER_NAME="soloptilink.exe" ;;
esac

# ========================================
# python3 非依存 JSON フィールド抽出 (2026-07-13 インサイドグロース事案 恒久対策)
# ----------------------------------------
# 従来は「python3 がなければ exit 0 (静かに何もしない)」だったため、python3 を持たない
# 標準的な Windows + Git Bash 端末では本体更新が永遠に走らず、しかも exit 0 のため
# ランチャー側は成功と誤認していた (v2040 固着デッドロックの根因)。
# 配信 API の応答はフラット JSON かつキー既知なので、python3 不在時は sed 抽出に
# フォールバックする。python3 がある環境では従来通り python3 を優先 (厳密解析)。
# ========================================
HAS_PY3=0
command -v python3 >/dev/null 2>&1 && HAS_PY3=1

# フラット JSON から文字列フィールドを 1 つ取り出す: _sl_json_field "$json" key
_sl_json_field() {
    printf '%s' "$1" | sed -n 's/.*"'"$2"'"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1
}
# フラット JSON の boolean が true か: _sl_json_true "$json" key
_sl_json_true() {
    printf '%s' "$1" | grep -q '"'"$2"'"[[:space:]]*:[[:space:]]*true'
}
# ローカル JSON ファイルから文字列フィールド抽出: _sl_jfile_field file key
_sl_jfile_field() {
    [ -f "$1" ] || return 0
    sed -n 's/.*"'"$2"'"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$1" | head -1
}

# ========================================
# Windows (Git Bash) 非互換コマンドのフォールバック (2026-07-13 恒久対策)
# ----------------------------------------
# Git for Windows には rsync が存在せず、shasum (perl) も構成により欠落する。
# 従来は rsync 失敗 = ステージング失敗、shasum 欠落 = チェックサム空で不一致扱い、
# となり Windows 端末の本体更新を構造的に破壊していた。
# ========================================
# SHA-256 計算: shasum → sha256sum → openssl の順で試行
_sl_sha256() {
    if command -v shasum >/dev/null 2>&1; then
        shasum -a 256 "$1" 2>/dev/null | cut -d' ' -f1
    elif command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$1" 2>/dev/null | cut -d' ' -f1
    elif command -v openssl >/dev/null 2>&1; then
        openssl dgst -sha256 "$1" 2>/dev/null | awk '{print $NF}'
    fi
}
# ミラー同期 (rsync -a --delete 相当): _sl_mirror_dir src/ dst/
# rsync 不在時は「隣に新ツリーを構築 → アトミックに近い swap」で行う。
# (旧実装の「稼働中 dst を rm -rf してから cp」は、cp 途中失敗で dst 全損の
#  非アトミック窓が生じるため禁止 — 2026-07-13 敵対検証で確証)
_sl_mirror_dir() {
    local src="$1" dst="$2"
    if command -v rsync >/dev/null 2>&1; then
        rsync -a --delete "$src" "$dst"
        return $?
    fi
    local dst_norm="${dst%/}"
    local tmp_new="${dst_norm}.new.$$" tmp_old="${dst_norm}.old.$$"
    rm -rf "$tmp_new" "$tmp_old" 2>/dev/null
    mkdir -p "$tmp_new" || return 1
    if ! cp -R "${src%/}/." "$tmp_new/"; then
        rm -rf "$tmp_new" 2>/dev/null
        return 1   # コピー失敗 → 稼働中の dst は無傷のまま中止
    fi
    if [ -d "$dst_norm" ]; then
        mv "$dst_norm" "$tmp_old" || { rm -rf "$tmp_new"; return 1; }
    fi
    if mv "$tmp_new" "$dst_norm"; then
        rm -rf "$tmp_old" 2>/dev/null
        return 0
    fi
    # swap 失敗 → 旧ツリーを復元
    [ -d "$tmp_old" ] && mv "$tmp_old" "$dst_norm" 2>/dev/null
    rm -rf "$tmp_new" 2>/dev/null
    return 1
}
# オーバーレイ同期 (rsync -a 相当・既存保全): _sl_overlay_dir src/ dst/
_sl_overlay_dir() {
    local src="$1" dst="$2"
    if command -v rsync >/dev/null 2>&1; then
        rsync -a "$src" "$dst"
    else
        mkdir -p "$dst" || return 1
        cp -R "${src%/}/." "${dst%/}/"
    fi
}

# タイムスタンプ更新（失敗しても24時間待つ）
date +%s > "$CACHE_FILE"

# ========================================
# v2038.4: 軽量バージョン報告 (テレメトリ盲点の補完 / PFP-telemetry)
# ----------------------------------------
# ランチャー (./soloptilink <task>) を起動しない Desktop / 休眠端末は heartbeat を
# 送らず版数が届かない盲点があった。Claude Code セッションごとに必ず走る本スクリプト
# から直接 heartbeat を送り、版数を届ける。非ブロッキング (起動を遅延させない)・失敗黙殺。
# サーバ世代差の保険として current_version と app_version を両キー送信する。
# ========================================
_sl_report_version() {
    command -v curl >/dev/null 2>&1 || return 0
    local act="$SL_DIR/activation.json" lic="$SL_DIR/license.json"
    [ -f "$act" ] && [ -f "$lic" ] || return 0
    local hb_json
    if [ "$HAS_PY3" != "1" ]; then
        # python3 不在時フォールバック (sed 抽出 + printf 構築)。
        # 値は device_id / token / fingerprint / email = 引用符・バックスラッシュを含まない
        # 単純文字列のため、この構築で JSON として安全。
        # v2054 (skeptic 指摘 1a 対処): fingerprint を持たない超旧世代 (v2000系) 端末でも
        # 版数を管理画面の到達 KPI に計上できるよう fp は必須にしない。recover.sh と同じ流儀で
        # device_id + token が揃えば送信し、fp があれば含める (列挙防止はサーバ側 token 検証で維持)。
        local did tok fp em ver
        did=$(_sl_jfile_field "$lic" device_id); [ -n "$did" ] || did=$(_sl_jfile_field "$act" device_id)
        tok=$(_sl_jfile_field "$lic" token); [ -n "$tok" ] || tok=$(_sl_jfile_field "$act" token)
        fp=$(_sl_jfile_field "$act" fingerprint)
        [ -n "$did" ] && [ -n "$tok" ] || return 0
        ver=$(printf '%s' "$CURRENT_VERSION" | sed 's/^v//')
        em=$(_sl_jfile_field "$act" email)
        hb_json=$(printf '{"device_id":"%s","token":"%s","current_version":"%s","app_version":"%s"' "$did" "$tok" "$ver" "$ver")
        [ -n "$fp" ] && hb_json="${hb_json},\"fingerprint\":\"${fp}\""
        [ -n "$em" ] && hb_json="${hb_json},\"email\":\"${em}\""
        hb_json="${hb_json}}"
        curl -s -L --max-time 8 --connect-timeout 5 \
            -X POST -H "Content-Type: application/json" \
            -d "$hb_json" "${API_BASE}/devices/heartbeat" >/dev/null 2>&1 || true
        return 0
    fi
    hb_json=$(CUR_VER="$CURRENT_VERSION" ACT="$act" LIC="$lic" python3 -c "
import json, os
try:
    act = json.load(open(os.environ['ACT']))
    try:
        lic = json.load(open(os.environ['LIC']))
    except Exception:
        lic = {}
    did = lic.get('device_id') or act.get('device_id') or ''
    tok = lic.get('token') or act.get('token') or ''
    fp  = act.get('fingerprint') or ''
    # v2054 (skeptic 指摘 1a 対処): fingerprint を持たない超旧世代 (v2000系) 端末でも
    # 版数を管理画面の到達 KPI に計上できるよう fp は必須にしない (recover.sh と同流儀)。
    # device_id + token が揃えば送信し、fp があれば含める。列挙防止はサーバ側 token 検証で維持。
    if not (did and tok):
        raise SystemExit(0)
    ver = (os.environ.get('CUR_VER','') or '').lstrip('v')
    body = {'device_id': did, 'token': tok,
            'current_version': ver, 'app_version': ver}
    if fp:
        body['fingerprint'] = fp
    em = act.get('email')
    if em:
        body['email'] = em
    print(json.dumps(body))
except Exception:
    pass
" 2>/dev/null)
    [ -n "$hb_json" ] || return 0
    curl -s -L --max-time 8 --connect-timeout 5 \
        -X POST -H "Content-Type: application/json" \
        -d "$hb_json" "${API_BASE}/devices/heartbeat" >/dev/null 2>&1 || true
}
# 非ブロッキングで実行 (更新有無に依存せず毎回・親の exit を待たせない)
( _sl_report_version ) >/dev/null 2>&1 &

# APIに問い合わせ (v2034.2 堅牢化: _sl_curl で 15s/retry3/error-log 集約)
UPDATE_RESPONSE=$(_sl_curl GET "${API_BASE}/updates/check?version=${SAFE_VERSION}&os=${API_OS}&arch=${ARCH}" || echo "")

[ -z "$UPDATE_RESPONSE" ] && exit 0

# python3 が無くても続行する (2026-07-13 恒久対策)。
# 旧実装はここで exit 0 しており、python3 の無い Windows + Git Bash 端末では
# 「成功終了なのに何もしない」= ランチャーが成功と誤認する静かなデッドロックだった。
[ "$HAS_PY3" = "1" ] || log "PY3_ABSENT fallback-parser engaged"

# ========================================
# Goランチャーバイナリの SHA ベース更新 (2026-06-16 全顧客自動更新到達保証)
# ----------------------------------------
# 課題(version-coupling): バイナリの版は chain.sh から動的取得されるため、平文が
# 新版に上がるとバイナリも新版を名乗り、updates/check が available=false を返して
# バイナリが永遠に更新されない。これを断つため、版の available 判定とは独立に
# 「配信バイナリの sha256」と「ローカルバイナリの sha256」を比較し、異なれば
# /updates/download から取得して置換する (updates/check は available=false でも
# sha256 を返すため成立)。これによりフック稼働中の既存端末にも、自己回復を備えた
# 新ランチャーが平文更新の次サイクルで自動的に届く。
# 管理者端末 (.admin_mode) は dev ビルド保護のためスキップ。
# ========================================
# 版文字列を比較可能な整数へ (2040.0 -> 2040000000)。BSD/GNU 両対応。
_sl_vernum() {
    printf '%s' "${1#v}" | awk -F. '{printf "%d%06d%06d\n", ($1+0), ($2+0), ($3+0)}' 2>/dev/null
}
# 構造的未対応プラットフォーム判定 (2026-07-23 v2054.4):
# 配信APIは未対応 os/arch に HTTP 400 + 小さな JSON エラーボディを返す
# (--fail-with-body のためボディは outfile に残る)。これはバイナリ破損や回線障害では
# なく「配信側がこのプラットフォームに未対応」の合図。この場合に .binupdate-failed-sha を
# 武装させると、配信側が対応した後も同一 sha のまま最大7日更新が止まるため、武装させない。
_sl_is_platform_reject() {
    local f="$1" sz
    [ -f "$f" ] || return 1
    sz=$(wc -c < "$f" 2>/dev/null | tr -d ' ')
    [ "${sz:-0}" -gt 0 ] && [ "${sz:-0}" -lt 4096 ] || return 1
    head -c 1 "$f" 2>/dev/null | grep -q '{' || return 1
    grep -q 'error' "$f" 2>/dev/null
}
_sl_update_binary_if_sha_differs() {
    [ -f "$SL_DIR/.admin_mode" ] && return 0
    # ランチャー実体名は OS 依存 (Windows=soloptilink.exe)。実行中でない名前を対象にする。
    local launcher="$SL_DIR/$LAUNCHER_NAME"
    [ -f "$launcher" ] || return 0
    local served_sha served_ver
    if [ "$HAS_PY3" = "1" ]; then
        served_sha=$(UPDATE_RESPONSE="$UPDATE_RESPONSE" python3 -c "
import json,os
try:
    print((json.loads(os.environ['UPDATE_RESPONSE']).get('sha256') or '').strip())
except Exception:
    pass
" 2>/dev/null)
        served_ver=$(UPDATE_RESPONSE="$UPDATE_RESPONSE" python3 -c "
import json,os
try:
    print((json.loads(os.environ['UPDATE_RESPONSE']).get('version') or '').strip())
except Exception:
    pass
" 2>/dev/null)
    else
        served_sha=$(_sl_json_field "$UPDATE_RESPONSE" sha256)
        served_ver=$(_sl_json_field "$UPDATE_RESPONSE" version)
    fi
    [ -n "$served_sha" ] || return 0
    # 単調前進ガード(ダウングレード防止): ローカル版が配信版より新しければ置換しない。
    if [ -n "$served_ver" ]; then
        local lv sv
        lv=$(_sl_vernum "$CURRENT_VERSION"); sv=$(_sl_vernum "$served_ver")
        if [ -n "$lv" ] && [ -n "$sv" ] && [ "$lv" -gt "$sv" ] 2>/dev/null; then
            return 0
        fi
    fi
    local local_sha
    local_sha=$(_sl_sha256 "$launcher")
    [ -n "$local_sha" ] || return 0
    served_sha=$(printf '%s' "$served_sha" | tr 'A-Z' 'a-z')
    if [ "$served_sha" = "$(printf '%s' "$local_sha" | tr 'A-Z' 'a-z')" ]; then
        rm -f "$SL_DIR/.binupdate-failed-sha" 2>/dev/null   # 一致=最新→失敗マーカー解除
        return 0
    fi
    # 無限DL防止: この配信 sha で前回失敗(7日以内)ならスキップ
    local fail_marker="$SL_DIR/.binupdate-failed-sha"
    if [ -f "$fail_marker" ]; then
        local f_sha f_ts now
        f_sha=$(cut -d'|' -f1 "$fail_marker" 2>/dev/null | tr 'A-Z' 'a-z' | tr -d ' ')
        f_ts=$(cut -d'|' -f2 "$fail_marker" 2>/dev/null | tr -d ' ')
        now=$(date +%s)
        if [ "$f_sha" = "$served_sha" ] && [ -n "$f_ts" ] && [ $((now - f_ts)) -lt 604800 ] 2>/dev/null; then
            return 0
        fi
    fi
    local bin_url="${API_BASE}/updates/download?os=${API_OS}&arch=${ARCH}"
    local tmp_bin
    tmp_bin=$(mktemp "${TMPDIR:-/tmp}/sl-bin.XXXXXX") || return 0
    if ! _sl_curl GET "$bin_url" "$tmp_bin" 120 >/dev/null; then
        if _sl_is_platform_reject "$tmp_bin"; then
            log "BINARY_UPDATE_PLATFORM_UNSUPPORTED os=${API_OS} arch=${ARCH} (failマーカー非武装)"
            rm -f "$tmp_bin"; return 0
        fi
        printf '%s|%s' "$served_sha" "$(date +%s)" > "$fail_marker" 2>/dev/null
        rm -f "$tmp_bin"; return 0
    fi
    local got_sha got_size
    got_size=$(wc -c < "$tmp_bin" | tr -d ' ')
    if [ "${got_size:-0}" -lt 1048576 ]; then  # 1MB未満は不完全DL
        if _sl_is_platform_reject "$tmp_bin"; then
            log "BINARY_UPDATE_PLATFORM_UNSUPPORTED os=${API_OS} arch=${ARCH} (failマーカー非武装)"
            rm -f "$tmp_bin"; return 0
        fi
        printf '%s|%s' "$served_sha" "$(date +%s)" > "$fail_marker" 2>/dev/null
        rm -f "$tmp_bin"; return 0
    fi
    got_sha=$(_sl_sha256 "$tmp_bin" | tr 'A-Z' 'a-z')
    if [ "$got_sha" != "$served_sha" ]; then
        log "BINARY_SHA_MISMATCH served=$served_sha got=$got_sha"
        printf '%s|%s' "$served_sha" "$(date +%s)" > "$fail_marker" 2>/dev/null
        rm -f "$tmp_bin"; return 0
    fi
    rm -f "$fail_marker" 2>/dev/null
    # rename-backup 方式で置換 (実行中.exeのロック時も .backup から復元可能)
    chmod +x "$tmp_bin" 2>/dev/null || true
    local backup="${launcher}.backup"
    rm -f "$backup" 2>/dev/null
    if mv "$launcher" "$backup" 2>/dev/null; then
        if mv "$tmp_bin" "$launcher" 2>/dev/null; then
            chmod +x "$launcher" 2>/dev/null || true
            rm -f "$backup" 2>/dev/null
            log "BINARY_UPDATED_BY_SHA ($LAUNCHER_NAME) -> $served_sha"
        else
            mv "$backup" "$launcher" 2>/dev/null   # 復元
            rm -f "$tmp_bin"
        fi
    else
        # rename 不可(実行中ロック等) → 直接上書きを試行、不可なら次サイクルへ
        if cp "$tmp_bin" "$launcher" 2>/dev/null; then
            chmod +x "$launcher" 2>/dev/null || true
            log "BINARY_UPDATED_BY_SHA_CP ($LAUNCHER_NAME) -> $served_sha"
        fi
        rm -f "$tmp_bin"
    fi
}
# 版の available 判定より前に実行 (平文が最新でもバイナリだけ古いケースを救う)
# 2026-07-13 敵対検証で確証: フック経由 (非 force) の実行予算は 30 秒であり、
# 大容量バイナリDLを前景で行うと低速回線で毎回途中 kill され永遠に完遂しない。
# フック経由ではバックグラウンドで実行し、フック本体は即座に先へ進む。
if [ "$FORCE_UPDATE" = true ]; then
    _sl_update_binary_if_sha_differs
else
    ( _sl_update_binary_if_sha_differs ) >> "$LOG_FILE" 2>&1 &
fi

# レスポンス解析（環境変数経由で安全に渡す、改行区切りで出力）
# package_url を優先使用（skills/agents/hooks パッケージ用）
# package_url がない場合は download_url にフォールバック
if [ "$HAS_PY3" = "1" ]; then
PARSE_RESULT=$(UPDATE_RESPONSE="$UPDATE_RESPONSE" python3 -c "
import json, os, re, sys
try:
    d = json.loads(os.environ['UPDATE_RESPONSE'])
    if not d.get('available', False):
        sys.exit(0)
    ver = d.get('version', '')
    # package_url を優先、なければ download_url
    url = d.get('package_url', '') or d.get('download_url', '')
    sha = d.get('package_sha256', '') or d.get('sha256', '')
    # バージョン形式検証
    if not re.match(r'^[0-9]+\.[0-9]+(\.[0-9]+)?$', ver):
        sys.exit(0)
    # URL検証（httpsのみ許可）
    if not url.startswith('https://'):
        sys.exit(0)
    # 改行区切りで出力（URLにパイプが含まれても安全）
    print(ver)
    print(url)
    print(sha)
except (json.JSONDecodeError, KeyError, TypeError):
    pass
" 2>/dev/null)
else
    # python3 不在時フォールバック (sed 抽出 + シェル検証。検証内容は python3 経路と同一)
    PARSE_RESULT=""
    if _sl_json_true "$UPDATE_RESPONSE" available; then
        _fb_ver=$(_sl_json_field "$UPDATE_RESPONSE" version)
        _fb_url=$(_sl_json_field "$UPDATE_RESPONSE" package_url)
        [ -n "$_fb_url" ] || _fb_url=$(_sl_json_field "$UPDATE_RESPONSE" download_url)
        _fb_sha=$(_sl_json_field "$UPDATE_RESPONSE" package_sha256)
        [ -n "$_fb_sha" ] || _fb_sha=$(_sl_json_field "$UPDATE_RESPONSE" sha256)
        # バージョン形式検証 + https 検証 (python3 経路と同一基準)
        if printf '%s' "$_fb_ver" | grep -Eq '^[0-9]+\.[0-9]+(\.[0-9]+)?$'; then
            case "$_fb_url" in
                https://*) PARSE_RESULT=$(printf '%s\n%s\n%s' "$_fb_ver" "$_fb_url" "$_fb_sha") ;;
            esac
        fi
    fi
fi

# ========================================
# スキル乖離 自己修復 (2026-07-13 v2040発E2Eで実証した固着の根治)
# 旧世代 do_update はスキルSoTミラー (~/.soloptilink/skills) を更新しないため、
# 「本体は最新版・スキルは旧版に巻き戻り」の乖離が恒久化する。版一致で更新が
# 走らない時にも乖離を検知し、配信中パッケージからスキル群のみ再適用する。
# ========================================
_sl_skill_drift_detected() {
    local probe="$SL_DIR/skills/soloptilink-boost/SKILL.md"
    [ -f "$probe" ] || return 0          # ミラー不在 = 乖離扱い (修復対象)
    grep -q "v${CURRENT_VERSION}" "$probe" 2>/dev/null && return 1   # 追従済み
    return 0
}
heal_skill_drift() {
    _sl_skill_drift_detected || return 0
    log "SKILL_DRIFT_DETECTED chain=v${CURRENT_VERSION} mirror=$(grep -m1 -o 'v[0-9][0-9.]*' "$SL_DIR/skills/soloptilink-boost/SKILL.md" 2>/dev/null | head -1)"
    local latest_json latest_ver latest_url latest_sha
    latest_json=$(_sl_curl GET "${API_BASE}/releases/latest" "" 20) || return 0
    latest_ver=$(_sl_json_field "$latest_json" version)
    latest_url=$(_sl_json_field "$latest_json" package_url)
    latest_sha=$(_sl_json_field "$latest_json" package_sha256)
    case "$latest_url" in https://*) ;; *) return 0 ;; esac
    # 現行本体より古いパッケージでの修復は行わない (ダウングレード防止)
    [ "$(printf '%s\n%s' "$latest_ver" "$CURRENT_VERSION" | sort -V | tail -1)" = "$CURRENT_VERSION" ] && [ "$latest_ver" != "$CURRENT_VERSION" ] && return 0
    local hdir hpkg
    hdir=$(mktemp -d) || return 0
    hpkg="$hdir/pkg.tar.gz"
    if ! _sl_curl GET "$latest_url" "$hpkg" >/dev/null; then rm -rf "$hdir"; return 0; fi
    if [ -n "$latest_sha" ]; then
        local actual; actual=$(_sl_sha256 "$hpkg" | tr 'A-Z' 'a-z')
        [ "$actual" != "$(printf '%s' "$latest_sha" | tr 'A-Z' 'a-z')" ] && { log "SKILL_HEAL_SHA_MISMATCH"; rm -rf "$hdir"; return 0; }
    fi
    tar -xzf "$hpkg" -C "$hdir" 2>/dev/null || { rm -rf "$hdir"; return 0; }
    local root; root=$(ls -d "$hdir"/soloptilink-v*/ 2>/dev/null | head -1)
    [ -d "${root}skills" ] || { rm -rf "$hdir"; return 0; }
    local healed=0 sdir sname
    for sdir in "${root}skills/"*/; do
        [ -d "$sdir" ] || continue
        sname=$(basename "$sdir")
        # PFP-177: パッケージに万一混入していても管理者専用スキルは適用しない
        _sl_is_admin_only_skill "$sname" && continue
        [ -f "$sdir/SKILL.md" ] || continue
        mkdir -p "$SL_DIR/skills/$sname" "$CLAUDE_DIR/skills/$sname"
        # 2026-07-15: アトミック置換 (書込途中の SKILL.md をスキル走査に見せない)
        _sl_atomic_cp "$sdir/SKILL.md" "$SL_DIR/skills/$sname/SKILL.md" || true
        _sl_atomic_cp "$sdir/SKILL.md" "$CLAUDE_DIR/skills/$sname/SKILL.md" || true
        if [ -d "$sdir/references" ]; then
            _sl_atomic_dir_replace "$sdir/references" "$SL_DIR/skills/$sname/references" || true
            _sl_atomic_dir_replace "$sdir/references" "$CLAUDE_DIR/skills/$sname/references" || true
        fi
        case "$sname" in soloptilink*)
            mkdir -p "$CLAUDE_DIR/commands"
            _sl_atomic_cp "$sdir/SKILL.md" "$CLAUDE_DIR/commands/${sname}.md" || true ;;
        esac
        healed=$((healed + 1))
    done
    rm -rf "$hdir"
    log "SKILL_DRIFT_HEALED count=$healed package=v${latest_ver}"
}

if [ -z "$PARSE_RESULT" ]; then
    # 更新なし — スキル乖離だけ確認して自己修復する。
    # フック経由は実行予算 30 秒のため背面実行、--force は前景で完遂する。
    if [ "$FORCE_UPDATE" = true ]; then
        heal_skill_drift
    else
        ( heal_skill_drift ) >> "$LOG_FILE" 2>&1 &
    fi
    exit 0
fi

# パース結果を分解（改行区切り）
NEW_VERSION=$(echo "$PARSE_RESULT" | sed -n '1p')
DOWNLOAD_URL=$(echo "$PARSE_RESULT" | sed -n '2p')
EXPECTED_SHA256=$(echo "$PARSE_RESULT" | sed -n '3p')

[ -z "$NEW_VERSION" ] && exit 0
[ -z "$DOWNLOAD_URL" ] && exit 0

log "UPDATE_AVAILABLE v${CURRENT_VERSION} -> v${NEW_VERSION}"

# ========================================
# 更新処理関数
# ========================================
do_update() {
    TEMP_DIR=$(mktemp -d)
    # PFP-101: do_update 内の trap はグローバル EXIT trap を置換するため、
    # ロック解除 + 自己コピー掃除も合わせて引き継ぐ (trap 上書き事故の根絶)
    trap "rm -rf '$TEMP_DIR'; rmdir '$LOCK_DIR' 2>/dev/null; rm -f '$0' 2>/dev/null" EXIT
    PACKAGE_FILE="$TEMP_DIR/solai-update.tar.gz"

    write_status() {
        local status="$1" message="$2"
        cat > "$STATUS_FILE" << STATUSEOF
{"status":"${status}","version":"${NEW_VERSION}","from":"${CURRENT_VERSION}","message":"${message}","timestamp":"$(date -u '+%Y-%m-%dT%H:%M:%SZ')"}
STATUSEOF
        # [PFP-117] 更新失敗を管理ダッシュボードへ自動報告 (silent / 非ブロッキング)
        if [ "$status" = "failed" ] && [ -f "$SL_DIR/lib/cognitive/customer-error-reporter.sh" ]; then
            bash "$SL_DIR/lib/cognitive/customer-error-reporter.sh" "auto-update-failure" "v${CURRENT_VERSION:-unknown} -> v${NEW_VERSION:-unknown}: ${message:-}" 2>/dev/null || true
        fi
    }

    # v2034.2 堅牢化: append-only 履歴 (途中過程を全て保持 / status.json の上書き喪失問題を解消)
    _append_history() {
        local status="$1" version="$2" message="$3"
        local history="$SL_DIR/.auto-update-history.jsonl"
        echo "{\"ts\":\"$(date -u '+%Y-%m-%dT%H:%M:%SZ')\",\"status\":\"$status\",\"from\":\"$CURRENT_VERSION\",\"version\":\"$version\",\"message\":\"$message\"}" >> "$history" 2>/dev/null
    }

    write_status "downloading" "パッケージダウンロード中"
    _append_history "downloading" "${NEW_VERSION:-$CURRENT_VERSION}" "パッケージダウンロード中"

    # v2034.8 / PFP-057 + PFP-080: DOWNLOAD_TOO_SMALL リトライロジック (下限引き上げ)
    # transient 障害 (release 直後の asset upload race / CDN cold cache) を救う
    # 最大4回、5分間隔で再試行 (合計15分以内に復旧する transient 障害をカバー)
    DOWNLOAD_RETRY_MAX=4
    DOWNLOAD_RETRY_INTERVAL=300  # 5分
    # PFP-080 (v2034.8 2026-05-27): 100bytes → 10240bytes (10KB)
    # 正規の tar.gz は MB 単位なので 10KB 未満は確実に不完全ダウンロード。
    # 監査C指摘の「5KB未満の不完全ダウンロードが漏れる」可能性を構造的根絶。
    # 環境変数 SL_DOWNLOAD_MIN_SIZE で上書き可能 (将来 release asset metadata 動的読取に発展)。
    DOWNLOAD_MIN_SIZE="${SL_DOWNLOAD_MIN_SIZE:-10240}"
    DOWNLOAD_ATTEMPT=0
    DOWNLOAD_SUCCESS=0

    while [ "$DOWNLOAD_ATTEMPT" -lt "$DOWNLOAD_RETRY_MAX" ]; do
        DOWNLOAD_ATTEMPT=$((DOWNLOAD_ATTEMPT + 1))

        # v2034.2 堅牢化: 90秒 / retry3 / connect-timeout 10s / stderr→error-log
        if ! _sl_curl GET "$DOWNLOAD_URL" "$PACKAGE_FILE" 90 >/dev/null; then
            log "DOWNLOAD_FAILED attempt=${DOWNLOAD_ATTEMPT}/${DOWNLOAD_RETRY_MAX} $DOWNLOAD_URL"
            if [ "$DOWNLOAD_ATTEMPT" -lt "$DOWNLOAD_RETRY_MAX" ]; then
                log "DOWNLOAD_RETRY_WAIT ${DOWNLOAD_RETRY_INTERVAL}s (next attempt=$((DOWNLOAD_ATTEMPT + 1)))"
                sleep "$DOWNLOAD_RETRY_INTERVAL"
                continue
            fi
            write_status "failed" "ダウンロード失敗 (${DOWNLOAD_RETRY_MAX}回試行)"
            _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "ダウンロード失敗 (curl rc != 0, ${DOWNLOAD_RETRY_MAX}回試行)"
            return 1
        fi

        FILE_SIZE=$(wc -c < "$PACKAGE_FILE" | tr -d ' ')
        if [ "$FILE_SIZE" -lt "$DOWNLOAD_MIN_SIZE" ]; then
            log "DOWNLOAD_TOO_SMALL attempt=${DOWNLOAD_ATTEMPT}/${DOWNLOAD_RETRY_MAX} ${FILE_SIZE}bytes"
            if [ "$DOWNLOAD_ATTEMPT" -lt "$DOWNLOAD_RETRY_MAX" ]; then
                log "DOWNLOAD_RETRY_WAIT ${DOWNLOAD_RETRY_INTERVAL}s (transient障害可能性: CDN cold cache or asset upload race)"
                write_status "retrying" "ダウンロードサイズ異常 (${FILE_SIZE}bytes) - ${DOWNLOAD_RETRY_INTERVAL}秒後にリトライ (${DOWNLOAD_ATTEMPT}/${DOWNLOAD_RETRY_MAX})"
                sleep "$DOWNLOAD_RETRY_INTERVAL"
                continue
            fi
            log "DOWNLOAD_TOO_SMALL_FINAL ${FILE_SIZE}bytes after ${DOWNLOAD_RETRY_MAX} attempts"
            write_status "failed" "ダウンロードサイズ異常 (${FILE_SIZE}bytes, ${DOWNLOAD_RETRY_MAX}回試行)"
            _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "ダウンロードサイズ異常 (${FILE_SIZE}bytes, ${DOWNLOAD_RETRY_MAX}回試行)"
            return 1
        fi

        # サイズOK → 抜ける
        DOWNLOAD_SUCCESS=1
        if [ "$DOWNLOAD_ATTEMPT" -gt 1 ]; then
            log "DOWNLOAD_RETRY_SUCCESS attempt=${DOWNLOAD_ATTEMPT} size=${FILE_SIZE}bytes"
        fi
        break
    done

    if [ -n "$EXPECTED_SHA256" ]; then
        ACTUAL_SHA256=$(_sl_sha256 "$PACKAGE_FILE")
        # 大文字/小文字を正規化して比較 (登録側が大文字SHAでも恒久不一致にしない)
        ACTUAL_SHA256=$(printf '%s' "$ACTUAL_SHA256" | tr 'A-Z' 'a-z')
        EXPECTED_SHA256=$(printf '%s' "$EXPECTED_SHA256" | tr 'A-Z' 'a-z')
        if [ "$ACTUAL_SHA256" != "$EXPECTED_SHA256" ]; then
            log "CHECKSUM_MISMATCH expected=$EXPECTED_SHA256 actual=$ACTUAL_SHA256"
            write_status "failed" "チェックサム不一致"
            _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "チェックサム不一致 expected=$EXPECTED_SHA256 actual=$ACTUAL_SHA256"
            return 1
        fi
        log "CHECKSUM_VERIFIED $ACTUAL_SHA256"
    fi

    write_status "extracting" "パッケージ展開中"
    _append_history "extracting" "${NEW_VERSION:-$CURRENT_VERSION}" "パッケージ展開中"

    EXTRACT_DIR="$TEMP_DIR/extracted"
    mkdir -p "$EXTRACT_DIR"

    if file "$PACKAGE_FILE" 2>/dev/null | grep -q "gzip"; then
        tar xzf "$PACKAGE_FILE" -C "$EXTRACT_DIR" 2>/dev/null
    elif file "$PACKAGE_FILE" 2>/dev/null | grep -q "Zip"; then
        unzip -qo "$PACKAGE_FILE" -d "$EXTRACT_DIR" 2>/dev/null
    else
        case "$PACKAGE_FILE" in
            *.tar.gz|*.tgz) tar xzf "$PACKAGE_FILE" -C "$EXTRACT_DIR" 2>/dev/null ;;
            *.zip) unzip -qo "$PACKAGE_FILE" -d "$EXTRACT_DIR" 2>/dev/null ;;
            *) tar xzf "$PACKAGE_FILE" -C "$EXTRACT_DIR" 2>/dev/null || unzip -qo "$PACKAGE_FILE" -d "$EXTRACT_DIR" 2>/dev/null ;;
        esac
    fi

    if [ ! "$(ls -A "$EXTRACT_DIR" 2>/dev/null)" ]; then
        log "EXTRACT_FAILED"
        write_status "failed" "パッケージ展開失敗"
        _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "パッケージ展開失敗 (empty extract dir)"
        return 1
    fi

    SUBDIRS=$(find "$EXTRACT_DIR" -mindepth 1 -maxdepth 1 -type d 2>/dev/null)
    # grep -c は 0 件時に exit 1 を返すため `|| echo 0` だと "0\n0" になる (整数比較が壊れる)
    SUBDIR_COUNT=$(printf '%s' "$SUBDIRS" | grep -c '.')
    case "$SUBDIR_COUNT" in ''|*[!0-9]*) SUBDIR_COUNT=0 ;; esac
    if [ "$SUBDIR_COUNT" -eq 1 ] && [ ! -f "$EXTRACT_DIR/chain.sh" ]; then
        EXTRACT_DIR="$SUBDIRS"
    fi

    write_status "applying" "更新適用中"
    _append_history "applying" "${NEW_VERSION:-$CURRENT_VERSION}" "更新適用中"

    # バックアップ
    SAFE_CUR=$(echo "$CURRENT_VERSION" | tr -cd '0-9.')
    BACKUP_DIR="$SL_DIR/.backups/v${SAFE_CUR}_$(date +%Y%m%d%H%M%S)"
    mkdir -p "$BACKUP_DIR"
    cp "$SL_DIR/chain.sh" "$BACKUP_DIR/" 2>/dev/null || true
    cp "$SL_DIR/setup.sh" "$BACKUP_DIR/" 2>/dev/null || true
    if [ -d "$CLAUDE_DIR/skills" ]; then
        mkdir -p "$BACKUP_DIR/skills"
        for skill_dir in "$CLAUDE_DIR/skills/soloptilink"*/; do
            [ ! -d "$skill_dir" ] && continue
            skill_name=$(basename "$skill_dir")
            mkdir -p "$BACKUP_DIR/skills/$skill_name"
            cp "$skill_dir/SKILL.md" "$BACKUP_DIR/skills/$skill_name/" 2>/dev/null || true
        done
    fi

    log "BACKUP $BACKUP_DIR"

    # ステージング
    STAGE_DIR="$TEMP_DIR/staging"
    mkdir -p "$STAGE_DIR"
    UPDATE_COUNT=0
    STAGE_OK=true

    [ -f "$EXTRACT_DIR/chain.sh" ] && { cp "$EXTRACT_DIR/chain.sh" "$STAGE_DIR/chain.sh" || STAGE_OK=false; UPDATE_COUNT=$((UPDATE_COUNT + 1)); }
    [ -f "$EXTRACT_DIR/setup.sh" ] && { cp "$EXTRACT_DIR/setup.sh" "$STAGE_DIR/setup.sh" || STAGE_OK=false; UPDATE_COUNT=$((UPDATE_COUNT + 1)); }
    [ -f "$EXTRACT_DIR/VERSION" ] && { cp "$EXTRACT_DIR/VERSION" "$STAGE_DIR/VERSION" || STAGE_OK=false; UPDATE_COUNT=$((UPDATE_COUNT + 1)); }
    if [ -d "$EXTRACT_DIR/lib" ]; then
        mkdir -p "$STAGE_DIR/lib"
        _sl_mirror_dir "$EXTRACT_DIR/lib/" "$STAGE_DIR/lib/" || STAGE_OK=false
        UPDATE_COUNT=$((UPDATE_COUNT + 1))
    fi

    if [ "$STAGE_OK" = false ]; then
        log "STAGING_FAILED"
        write_status "failed" "ステージング失敗"
        _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "ステージング失敗 (cp / rsync エラー)"
        return 1
    fi

    # 本適用
    [ -f "$STAGE_DIR/chain.sh" ] && { cp "$STAGE_DIR/chain.sh" "$SL_DIR/chain.sh"; chmod +x "$SL_DIR/chain.sh"; }
    [ -f "$STAGE_DIR/setup.sh" ] && { cp "$STAGE_DIR/setup.sh" "$SL_DIR/setup.sh"; chmod +x "$SL_DIR/setup.sh"; }
    [ -f "$STAGE_DIR/VERSION" ] && cp "$STAGE_DIR/VERSION" "$SL_DIR/VERSION"
    if [ -d "$STAGE_DIR/lib" ]; then
        _sl_mirror_dir "$STAGE_DIR/lib/" "$SL_DIR/lib/"
        find "$SL_DIR/lib/" -name '*.sh' -exec chmod +x {} + 2>/dev/null
    fi
    # ========================================
    # v2041.0 / PFP-122 (2026-06-13): DBL業種辞書 domains/ + IBL連携辞書 integrations/ を同期。
    # 【重大欠陥の修正】従来 do_update は domains/integrations を一切同期せず、
    # 業種辞書・連携辞書の追加/更新が既存顧客の自動更新で永遠に届かなかった。
    # パッケージに含まれる場合のみ rsync (含まれない旧パッケージで顧客の既存辞書を
    # 消さないよう、ディレクトリ存在を条件にする = 後方互換)。
    # ========================================
    # 重要: --delete を使わず overlay 同期にする。boost(Step 0.8)は未登録業種の DBL を、
    # Connector Forge(Step 0.9)は未登録サービスの連携辞書を顧客の domains//integrations/ に
    # 作成するため、--delete だと更新のたびに顧客/FDE が作った辞書を消してしまう(データ消失)。
    # overlay なら公式辞書は新版で上書き更新しつつ、顧客作成辞書を保全できる。
    for kb in domains integrations; do
        if [ -d "$EXTRACT_DIR/$kb" ] && [ -n "$(ls -A "$EXTRACT_DIR/$kb" 2>/dev/null)" ]; then
            mkdir -p "$SL_DIR/$kb"
            if _sl_overlay_dir "$EXTRACT_DIR/$kb/" "$SL_DIR/$kb/" 2>/dev/null; then
                kb_n=$(find "$SL_DIR/$kb" -name '*.json' 2>/dev/null | wc -l | tr -d ' ')
                UPDATE_COUNT=$((UPDATE_COUNT + 1))
                log "KB_SYNCED $kb ($kb_n dictionaries, overlay)"
            fi
        fi
    done
    [ -f "$EXTRACT_DIR/version-manifest.json" ] && cp "$EXTRACT_DIR/version-manifest.json" "$SL_DIR/version-manifest.json"
    [ -f "$EXTRACT_DIR/auto-update.sh" ] && { cp "$EXTRACT_DIR/auto-update.sh" "$SL_DIR/auto-update.sh"; chmod +x "$SL_DIR/auto-update.sh"; }

    # PFP-064b (2026-07-06): scripts/ (skill-sot-guard 等の構造防御) と migration/ (遡及配線) を同期する。
    # 従来はどちらも導入時のまま更新されず、①旧 skill-sot-guard が更新直後の heal で新表記を
    # 旧 SoT へ巻き戻す ②新規 migration が既存顧客に一切届かない、の2欠陥があった。
    # tar に同梱済みの内容をそのまま反映する (--delete はしない: 顧客側の状態ファイルを保全)。
    for sync_dir in scripts migration; do
        if [ -d "$EXTRACT_DIR/$sync_dir" ] && [ -n "$(ls -A "$EXTRACT_DIR/$sync_dir" 2>/dev/null)" ]; then
            mkdir -p "$SL_DIR/$sync_dir"
            if _sl_overlay_dir "$EXTRACT_DIR/$sync_dir/" "$SL_DIR/$sync_dir/" 2>/dev/null; then
                UPDATE_COUNT=$((UPDATE_COUNT + 1))
                log "DIR_SYNCED $sync_dir"
            fi
        fi
    done

    # ========================================
    # Goランチャーバイナリの配布
    # パッケージ内の bin/ ディレクトリからOS/Arch一致バイナリを配置
    # ========================================
    BIN_DEPLOYED=false
    # 配置先はランチャー実体名 (Windows=soloptilink.exe / それ以外=soloptilink)。
    BIN_TARGET="$SL_DIR/$LAUNCHER_NAME"
    if [ -d "$EXTRACT_DIR/bin" ]; then
        # OS/Archに合ったバイナリを選択 (Windows は .exe サフィックス)
        BIN_NAME="soloptilink-${API_OS}-${ARCH}"
        [ "$API_OS" = "windows" ] && BIN_NAME="soloptilink-windows-${ARCH}.exe"
        if [ -f "$EXTRACT_DIR/bin/$BIN_NAME" ]; then
            cp "$EXTRACT_DIR/bin/$BIN_NAME" "$BIN_TARGET"
            chmod +x "$BIN_TARGET" 2>/dev/null || true
            BIN_DEPLOYED=true
            UPDATE_COUNT=$((UPDATE_COUNT + 1))
            log "BINARY_DEPLOYED $BIN_NAME -> $BIN_TARGET"
        fi
    fi
    # フォールバック: パッケージ直下の soloptilink バイナリ
    if [ "$BIN_DEPLOYED" = false ] && [ -f "$EXTRACT_DIR/soloptilink" ]; then
        cp "$EXTRACT_DIR/soloptilink" "$BIN_TARGET"
        chmod +x "$BIN_TARGET" 2>/dev/null || true
        UPDATE_COUNT=$((UPDATE_COUNT + 1))
        log "BINARY_DEPLOYED soloptilink -> $BIN_TARGET"
    fi

    # skills/agents/hooks → ~/.claude/
    if [ -d "$EXTRACT_DIR/skills" ]; then
        for skill_dir in "$EXTRACT_DIR/skills/"*/; do
            [ ! -d "$skill_dir" ] && continue
            skill_name=$(basename "$skill_dir")
            mkdir -p "$CLAUDE_DIR/skills/$skill_name"
            # 2026-07-15: アトミック置換 (書込途中の SKILL.md をスキル走査に見せない=メニュー脱落根絶)
            [ -f "$skill_dir/SKILL.md" ] && { _sl_atomic_cp "$skill_dir/SKILL.md" "$CLAUDE_DIR/skills/$skill_name/SKILL.md"; UPDATE_COUNT=$((UPDATE_COUNT + 1)); }
            if [ -d "$skill_dir/references" ]; then
                _sl_atomic_dir_replace "$skill_dir/references" "$CLAUDE_DIR/skills/$skill_name/references" || true
            fi
            # 本体同梱ミラー (~/.soloptilink/skills/<name>/) も必ず更新する (2026-07-13 v2040発E2Eで実証)。
            # Goランチャーの writeback heal はこのミラーを SoT として ~/.claude/skills を修復するため、
            # ここが旧版のままだと更新直後にスキルが旧版へ巻き戻される (Goネイティブ経路と同等化)。
            if [ -f "$skill_dir/SKILL.md" ]; then
                mkdir -p "$SL_DIR/skills/$skill_name"
                _sl_atomic_cp "$skill_dir/SKILL.md" "$SL_DIR/skills/$skill_name/SKILL.md" || true
                if [ -d "$skill_dir/references" ]; then
                    _sl_atomic_dir_replace "$skill_dir/references" "$SL_DIR/skills/$skill_name/references" || true
                fi
            fi
            # PFP-064b (2026-07-06): SoT (~/.claude/commands/<name>.md) も同時更新する。
            # 従来は SoT が導入時版のまま残り、直後の skill-sot-guard heal が新 SKILL.md を
            # 旧版へ巻き戻して「本体は最新・表記は旧版」に固着した (実例: 本体 v2050.1 で表記 v2038.0)。
            # soloptilink* のみ対象 = 顧客が自作した commands を上書きしない。
            case "$skill_name" in
                soloptilink*)
                    if [ -f "$skill_dir/SKILL.md" ]; then
                        mkdir -p "$CLAUDE_DIR/commands"
                        _sl_atomic_cp "$skill_dir/SKILL.md" "$CLAUDE_DIR/commands/${skill_name}.md"
                        UPDATE_COUNT=$((UPDATE_COUNT + 1))
                        log "SOT_REFRESHED commands/${skill_name}.md"
                    fi
                    ;;
            esac
        done
    fi
    if [ -d "$EXTRACT_DIR/agents" ]; then
        mkdir -p "$CLAUDE_DIR/agents"
        for agent_file in "$EXTRACT_DIR/agents/"*.md; do
            [ ! -f "$agent_file" ] && continue
            cp "$agent_file" "$CLAUDE_DIR/agents/"
            UPDATE_COUNT=$((UPDATE_COUNT + 1))
        done
    fi
    if [ -f "$EXTRACT_DIR/hooks/soloptilink-session-guard.sh" ]; then
        mkdir -p "$CLAUDE_DIR/hooks"
        cp "$EXTRACT_DIR/hooks/soloptilink-session-guard.sh" "$CLAUDE_DIR/hooks/"
        chmod +x "$CLAUDE_DIR/hooks/soloptilink-session-guard.sh"
        UPDATE_COUNT=$((UPDATE_COUNT + 1))
    fi

    # クリーンアップ
    if [ -d "$SL_DIR/.backups" ]; then
        ls -td "$SL_DIR/.backups/"*/ 2>/dev/null | tail -n +6 | while IFS= read -r old_dir; do
            rm -rf "$old_dir"
        done
    fi

    # ========================================
    # 適用後検証 (2026-07-13 恒久対策): 「成功」を宣言する前に、chain.sh の版が
    # 実際に目標版へ進んだことを実測する。従来は UPDATE_COUNT=0 (何も適用されず) でも
    # UPDATE_COMPLETE を書いており、ランチャー/顧客が偽成功を信じるデッドロックを生んだ。
    # ========================================
    APPLIED_VERSION=$(grep 'readonly VERSION=' "$SL_DIR/chain.sh" 2>/dev/null | head -1 | grep -o '"[^"]*"' | tr -d '"')
    if [ "$APPLIED_VERSION" != "$NEW_VERSION" ]; then
        log "APPLY_VERIFY_FAILED applied=${APPLIED_VERSION:-none} expected=$NEW_VERSION files=$UPDATE_COUNT"
        write_status "failed" "適用後検証失敗 (適用版=${APPLIED_VERSION:-不明} 期待版=${NEW_VERSION})"
        _append_history "failed" "$NEW_VERSION" "適用後検証失敗 applied=${APPLIED_VERSION:-none} files=$UPDATE_COUNT"
        return 1
    fi

    write_status "success" "v${CURRENT_VERSION} -> v${NEW_VERSION} (${UPDATE_COUNT} files)"
    _append_history "success" "${NEW_VERSION:-$CURRENT_VERSION}" "v${CURRENT_VERSION} -> v${NEW_VERSION} (${UPDATE_COUNT} files)"
    log "UPDATE_COMPLETE v${CURRENT_VERSION} -> v${NEW_VERSION} (${UPDATE_COUNT} files)"

    # PFP-064: do_update が Go embed writeback で ~/.claude/skills/ を古いバージョンに
    # 書き戻してしまった場合、即座に SoT (~/.claude/commands/<name>.md) から修復する。
    # 失敗しても無視 (do_update の成功 status を上書きしない)。
    if [ -x "${HOME}/.soloptilink/scripts/structural-defenses/skill-sot-guard.sh" ]; then
        bash "${HOME}/.soloptilink/scripts/structural-defenses/skill-sot-guard.sh" heal --silent 2>&1 >> "$LOG_FILE" || true
    fi

    # PFP-093: 顧客端末で Centuria ロスター (105体実起動エンジンの依存) を確実に生成する。
    # 配信される ~/.claude/agents/*.md (118体) から centuria-roster.json を再構築し、
    # 「105体が本物として動く」エンジンが顧客端末で初回から成立する状態を保証する。
    if [ -x "${HOME}/.soloptilink/lib/centuria-roster.sh" ]; then
        bash "${HOME}/.soloptilink/lib/centuria-roster.sh" build 2>&1 >> "$LOG_FILE" || true
    fi

    # v2052.3 fleet-wide: production_gate 自動 arm (既存 60 顧客 instance への遡及配布経路)。
    # 冪等 — 既に arm 済みなら skip。失敗しても更新完了ステータスを落とさない (fail-silent)。
    # ~/.soloptilink/.production_gate が armed 状態なら env override 攻撃を全排除する。
    if [ -x "${HOME}/.soloptilink/lib/migration/v2052.3-production-gate-arm.sh" ]; then
        SOLOPTILINK_MIGRATION_LOG="$LOG_FILE" \
            bash "${HOME}/.soloptilink/lib/migration/v2052.3-production-gate-arm.sh" >> "$LOG_FILE" 2>&1 || true
    fi

    # v2052.6 fleet-wide: semantic-detector daemon 常駐化 (PFP-165 cold-start 根治)。
    # 既存 60 顧客 instance に launchd/systemd 常駐設定を遡及配布し、hook 8 秒
    # timeout 内で socket 応答を保証する (fail-open 窓の構造的根絶)。
    # 冪等 — 既に load 済みなら unload → reload で最新テンプレートに更新。
    # 失敗しても更新完了ステータスを落とさない (fail-silent)。
    if [ -x "${HOME}/.soloptilink/lib/migration/v2052.6-semantic-daemon-install.sh" ]; then
        SOLOPTILINK_MIGRATION_LOG="$LOG_FILE" \
            bash "${HOME}/.soloptilink/lib/migration/v2052.6-semantic-daemon-install.sh" >> "$LOG_FILE" 2>&1 || true
    fi
}

# ========================================
# 実行モード分岐
# ========================================
if [ "$FORCE_UPDATE" = true ]; then
    # フォアグラウンド実行（Goランチャーの --update から呼ばれる）
    # 2026-07-13 敵対検証で確証: 旧実装は do_update 失敗 (適用後検証 failed 含む) でも
    # 無条件に「完了」を出力して exit 0 していた (偽成功)。結果を正直に返す。
    if do_update; then
        echo "[SoloptiLinkAI] v${CURRENT_VERSION} → v${NEW_VERSION} パッケージ更新完了"
    else
        echo "[SoloptiLinkAI] パッケージ更新に失敗しました (詳細: ~/.soloptilink/.auto-update-status.json)" >&2
        exit 1
    fi
else
    # バックグラウンド実行（フック経由）
    ( do_update ) >> "$LOG_FILE" 2>&1 &
    cat << EOF
<user-prompt-submit-hook>
[SoloptiLinkAI] v${NEW_VERSION} への自動更新をバックグラウンドで開始しました。
完了後、次のセッションから新バージョンが適用されます。
</user-prompt-submit-hook>
EOF
fi

exit 0
