---
name: soloptilink-video
description: "SoloptiLinkAI v2054.6 - Cinema Director Mode - 「CM作って」「予告編風の動画」「プロモ動画を生成して」「Higgsfieldで動画」「ショート動画を作って」等、動画の実生成で起動。監督エンジン(絵コンテ→キーフレーム先行→ショット別生成→自動QC→編集仕上げ)で映画予告・大手CM級の動画を一言から一発生成する。台本や編集指示書だけの場合は soloptilink-creative。"
argument-hint: "「30秒の会社CMを予告編風に作って」「新商品のプロモ動画 9:16 で」「--budget 300」"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, Agent, WebSearch, WebFetch, TodoWrite, AskUserQuestion, ToolSearch"
---

# SoloptiLinkAI v2054.6 - Cinema Director Mode

## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

# 映画予告・大手CM級動画の一発生成スキル (Higgsfield 連携)

---

## 🚀 最優先指令

1. **一発完成**: 一言依頼から「完成 mp4 + サムネイル + 実測レポート」まで自律で到達する。途中の逐次承認は求めない(予算超過見込みのみ例外)。
2. **1本の動画=編集された複数カット**: 1回の生成で完成品を出そうとしない。必ず「絵コンテ→カット別生成→編集仕上げ」の多段で作る。映画予告・CMの品質は構造から生まれる。
3. **画像先行 (最大の品質レバー)**: 既定は text2image でキーフレーム静止画を確定→採用画のみ image2video。テキスト直行は激しいカメラワーク主体のショットのみ。
4. **カット単位の自動QC**: 生成した全クリップはフレーム抽出→目視評価し、不合格カットだけ撮り直す(ショットあたり最大2回)。全カット未評価のまま編集に進むことを禁止。
5. **実測のみ・捏造禁止**: 実行していない生成・検証を「できた」と書かない。消費クレジットは台帳の実測値のみ報告する。
6. **クレジット規律**: 既定予算 200cr/本 (`--budget` で変更可)。着手前に見積合計を確認し、予算超過が見込まれる場合のみ停止して選択肢を提示。台帳ガードの BLOCK を無視して生成を続けることを禁止。
7. **文字は生成AIに描かせない**: タイトル・ロゴ・キャッチコピーは必ずポスプロ(タイトルカード/オーバーレイ)で載せる(文字化け根絶)。
8. **権利物を勝手に使わない**: BGM はユーザー提供素材のみ既定。権利不明の音源を混ぜない。無指定時は「BGM無し版+差し替え手順」で納品する。
9. **言語・顧客可視ポリシー**: `~/.claude/CLAUDE.md` のグローバルポリシーに完全準拠。応答は全て日本語・地の文に機械言語を貼らない。進捗は「① 構想 → ② 絵コンテ → ③ 撮影 → ④ 検品 → ⑤ 編集仕上げ」のマイルストーンで伝える。

**エンジンの所在 (内部)**: `~/.soloptilink/lib/video-director/` — style-presets.json (プリセット10種) / cinema-vocab.json (映画的語彙+プロンプト規律) / model-matrix.json (モデル選定+実測コスト台帳) / story-grammar.json (予告編・CM文法) / director-engine.sh (雛形・検証・予算台帳) / qc-extract.sh (QCフレーム抽出) / assemble.sh (自動編集) / hf-runner/ (REST予備経路)。

---

## Step 0: 接続確認 (毎回最初に実行)

1. **MCP経路 (優先)**: ToolSearch で `higgsfield` を検索し、生成系ツール (`generate_video` / `generate_image` / `balance` / `models_explore` / `job_display` 等) が載っているか確認する。
   - 載っている → `balance` で残高を実測し、予算と照合して開始。
   - **初回または model-matrix.json に verified_models が無い場合** → `models_explore` を実行し、実在モデルIDと特性を `model-matrix.json` に追記する(自己学習・SoT転記)。
2. **REST予備経路**: MCPツールが無い場合、`bash -c 'cd ~/.soloptilink/lib/video-director/hf-runner && node runner.mjs doctor'` を実行。
   - `ok:true` → REST経路で続行 (`runner.mjs image/video/speak/motions/styles/download`)。
   - `ok:false` (鍵未設定) → 次の2択を日本語で案内して待つ: ①Higgsfieldコネクタを認証済みの新しいセッションで再実行 ②cloud.higgsfield.ai > API Keys で鍵を発行し環境変数 HF_CREDENTIALS を設定。**ここが唯一の停止許容点** (接続なしで生成の偽装は絶対禁止)。
3. どちらの経路でも、生成は非同期 (queued→in_progress→completed/failed/nsfw)。failed/nsfw はクレジット返還されるので台帳に記録しない。

---

## Step 1: ブリーフ推論 (Silent Inference・質問しない)

一言依頼から以下を内部確定し、**前提として1行ずつ提示**してから進む (誤りは後から指摘可能な形):

- **目的** (認知/販促/採用/ブランディング) / **ターゲット** / **コアメッセージ1文**
- **尺** (既定30秒) / **比率** (既定はプリセットの aspect_default)
- **プリセット**: `style-presets.json` の10種から選択 (映画予告/ナショナルCM/テックローンチ/ラグジュアリー/エモーショナル/シズル/コーポレート/採用/SNS縦型/ドキュメンタリー)
- **予算**: `--budget` 指定 or 既定200cr
- 会社URLがあれば WebFetch で事業内容を取得しメッセージに反映する

## Step 2: プロジェクト初期化

```bash
VD=~/.soloptilink/lib/video-director
bash "$VD/director-engine.sh" init "$PWD/<プロジェクト名>" --preset <id> --duration <秒> --budget <cr> --title "<題名>"
```

## 一発到達ショートカット (v2054.3 新設・顧客体験の最短経路)

Step 2〜4 は個別に呼べるが、**「一言依頼」から「生成着手前の準備完了」までを 1 コマンドで通すショートカット**を用意している (顧客が使う既定経路):

```bash
bash "$VD/director-engine.sh" ready <dir> --brief "<一言依頼>" --subject "<主被写体 (英語)>" \
  [--preset <id>] [--duration <秒>] [--budget <cr>] [--title "<題名>"]
```

`ready` は内部で `init` → `scaffold-shotlist` → `validate` → `estimate` → `next` を通し実行し、`{phase:"ready_for_generation", shots, grammar, validate, estimate:{verdict,total_est_cr,budget_cr,action}, next:{step,hint}}` を 1 行 JSON で返す。**scaffold の被写体・締めロゴを微修正したいときだけ Step 3 の手作業に落ちる**。

顧客向けの現状レポート (何が終わっていて次に何を?) は:

```bash
bash "$VD/director-engine.sh" brief <dir>      # 顧客に見せて OK な日本語 1 画面レポート
bash "$VD/director-engine.sh" preflight        # 依存 (ffmpeg-full/Node/SDK/HF認証) の実測と対処法
```

## v2054.4 新設 — 品質・実況・法的安全・納品体裁の 5 機構 (Top5 improvement)

**【V01】ショット役割別プロンプト重み付け** — scaffold-shotlist が phase から opening/rising/climax/resolve/brand の役割を自動推論し、`presets/shot-role-weights.json` で定義された役割別の Composition emphasis / Lighting bias / pace_multiplier を prompt_en に注入。冒頭は「establishing wide shot + slow push in」、rising はカット尺を 0.85 倍に短縮し「dynamic movement + increased kinetic energy」、締めは「clean brand hero shot」で編集段のロゴ合成に最適化。**全カット同じ style_keywords が繰り返される平板さを構造的に根絶**。

**【OPS03】所要時間見積 (estimate --with-eta)** — `bash "$VD/director-engine.sh" estimate <dir> --with-eta [--parallelism N]` で費用に加えて **P50/P90 の所要時間** (「Seedance 2.0 × 8カット・並列3 → 6分・11分」等) を日本語で返す。model-latency.json の実測 P50/P90 × QC retry 15% + 編集 60 秒 を並列度で割った目安。`--parallelism` で Higgsfield プランに応じた並列数を上書き。

**【OPS05】リアルタイム進捗** — `bash "$VD/director-engine.sh" progress <dir>` で「現在フェーズ / N/M 完了 (X%) / 経過時間 / 残り目安 / 直近イベント / 注意事項」を日本語で表示。`--json` で機械読取。長時間バッチ (6-11 分) 中に顧客・owner が「今どこ?」を確認できる。progress.json はアトミック書込で並行安全。書込は `~/.soloptilink/lib/video-director/lib/progress-emitter.sh` の `emit_progress` を各長時間サブコマンドから呼ぶ設計。

**【F05】BGM ライセンスガード** — `bash "$VD/director-engine.sh" preflight-bgm <dir>` で **edl.json の bgm に license_type が未指定なら exit 2 (BLOCK)** し、推奨フリー音源 (Pixabay Music / MusicBed / Artlist) を日本語で案内。JASRAC 管理曲や外国著作権曲による Content ID ストライク・法的クレームを商用ラインに乗せる前に構造的に遮断する。**「動画は動いたが後で法的通告」の事故を防ぐ**。

**【UX05】納品パッケージ生成** — `bash "$VD/director-engine.sh" package <dir> [--version v1]` で `deliverables/<プロジェクト名>_<version>_<日付>/` 配下に **final.mp4 + サムネ + storyboard.md (絵コンテ) + assets/ (キーフレーム) + cost-report.md (消費内訳) + README.md** を一式まとめる。**「動画1本だけ渡す」から「企業納品品質のパッケージを渡す」へ**の転換。上長承認・広告代理店提出にそのまま出せる形。

## Step 3: ストーリー設計と絵コンテ (品質の心臓部)

**「一言 → 絵コンテ雛形」を機械生成できる (v2054.3 新設)**。以下の順で組み立てる:

1. **雛形を自動生成**: `bash "$VD/director-engine.sh" scaffold-shotlist <dir> --brief "<一言依頼>" --subject "<主被写体 (英)>"` — プリセットの structure_ref(grammar)・フェーズ配分・avg_shot_sec から shots を機械割付。各ショットの `prompt_en` は cinema-vocab の shot_size / camera_move / lighting / lens + プリセット style_keywords + motion_quality を自動連結して構築される(短すぎ検出を回避)。
2. **人による微修正 (品質の心臓部)**: 生成された shotlist.json を Read し、以下を必ず手で書き加える:
   - **被写体の具体化**: `--subject` の英語表現を各ショットで一字一句同じにする(スタイルロック)。人物の顔ショットは表情を1語(confident smile / focused eyes 等)。
   - **フェーズ最終のブランド指定**: 最終フェーズが brand の場合、当該ショットは `phase: "brand"` のまま `pipeline: "text_direct"` を維持(生成はロゴ無しの画・ロゴは edl.json 側のタイトルカードで載せる)。
   - **セカンダリ被写体**: 商品カットは商品名の英語スペルを固定・型番は書かない(文字化け温床)。
3. **機械検証**: `bash "$VD/director-engine.sh" validate <dir>` が **PASS するまで**修正。欠落/尺整合/締めフェーズ有無/prompt_en の情報密度を機械検証。

「shotlist.json をゼロから書く」は上級者向け(ユーザーが個別ショットを指定するケース)。既定は必ず scaffold-shotlist を通す(一言依頼からの一発到達を担保)。

## Step 4: 見積りと予算確定

**機械見積コマンドが載っている (v2054.3 新設)**。`bash "$VD/director-engine.sh" estimate <dir> [--model <id>]` で全ショットの見積合計と予算判定を返す:

- verdict = **OK** → 予算内。生成着手可能。お客様には「予算内で開始します(見積N cr)」と一言。
- verdict = **PARTIAL** → 未実測モデルが混在(unknown_models に列挙される)。接続後に **models_explore** を実行して `model-matrix.json` の verified_models を追記してから再見積 → OK 化。
- verdict = **OVER** → 予算超過見込み。停止して「見積/予算/選択肢(予算追加・カット削減・低コストモデル指定=`--model`)」を提示。

MCP経路が使える環境では、estimate の代わりに `generate_video` の **get_cost:true** で実 API 見積を取ってもよい(estimate は実測レートベースの近似・model-matrix.json 実測値が SoT)。

以後、生成のたびに `director-engine.sh ledger <dir> add <cr> "<内容>"` で実測記録。**BLOCK (exit 2) が返ったら生成を止めて報告**。

**「今どこ?・次に何を?」の機械判定 (v2054.3 新設)**: 途中で迷ったら `bash "$VD/director-engine.sh" next <dir>` を実行。プロジェクト状態から次の一手を日本語で返す (scaffold / キーフレーム / 動画生成 / QC / edl / assemble / 納品報告 のどこまで進んだか + 次の1手)。自律進行のガイド。

## Step 5: キーフレーム生成 (③ 撮影)

`pipeline: image_first` の各ショットについて:
1. `generate_image` (MCP) または `runner.mjs image` で静止画生成 (プロンプトはショットの prompt_en)。
2. ダウンロードして `keyframes/<shot_id>.jpg` に保存 → **Read で目視評価** (構図/破綻/スタイル一致)。
3. 不合格は原因をプロンプトに反映して**1回だけ**再生成。それでも不合格なら構図を変えて作り直すか text_direct に切替。
4. 人物の一貫性が必要な案件は SoulID (キャラ学習) を先に作成し `custom_reference_id` で全ショットに適用する。

## Step 6: ショット動画生成 + 自動QCループ (④ 検品)

各ショットについて:
1. `generate_video` (MCP・model は model-matrix 参照・キーフレーム画像を入力) または `runner.mjs video --json '{"model":"...","prompt":"...","image":"keyframes/<id>.jpg"}'`。
2. 完了URLから `clips/<shot_id>.mp4` へダウンロード。
3. `bash "$VD/qc-extract.sh" clips/<id>.mp4 frames/<id>` → 抽出フレームを **Read で7項目評価**: ①破綻(手指/顔/溶け) ②文字化け ③動きの自然さ(first↔last) ④構図 ⑤露出 ⑥スタイル一貫性 ⑦意図したカメラワークか。
4. 不合格 → 失敗原因を negative_en / prompt_en に反映して再生成 (**最大2回**・台帳ガード内)。2回失敗したら別モデル or 絵コンテ差替えを判断。
5. 全ショット合格まで編集に進まない。評価結果は `evidence/qc-<shot_id>.md` に1行ずつ記録 (実測のみ)。

## Step 7: 音の設計

- **BGM**: ユーザー提供ファイルがあれば `audio/` に配置して使用。無ければ BGM 無しで仕上げ、納品時に「音楽ファイルを頂ければ5分で差し替え可能」と案内 (edl.json の bgm を足して assemble 再実行するだけ)。
- **ナレーション**: 要望時のみ。`/v1/speak/higgsfield` (要WAV) か、ユーザー録音を使用。

## Step 8: 編集仕上げ (⑤ 編集仕上げ)

`edl.json` を書いて自動編集を実行:

```bash
bash "$VD/assemble.sh" run <dir>   # → out/final_<export>.mp4 + out/thumb.jpg
```

- `items`: QC合格クリップを文法のフェーズ順に配列。`{"type":"title","text":"...","sub":"...","sec":2.5}` でタイトルカード、trim で各カットの一番良い瞬間だけを使う。
- `transition`: 予告編=cut 基調 (タイトル前はハードカット)、ラグジュアリー/エモーショナル=fade。
- `logo`: ロゴPNGがあれば `{"src":"titles/logo.png","pos":"br","last_sec":6}`。
- `bgm`: `{"src":"audio/bgm.mp3","gain_db":-8,"duck":true,"fade_out":2}`。
- `export`: youtube_16x9 / sns_9x16 / square_1x1 / hd_16x9。`loudnorm` は既定 on (-14 LUFS)。
- 完成後、`out/final_*.mp4` を再度 `qc-extract.sh` にかけて通し確認 (繋ぎ目・テロップ表示秒数・音量)。

## Step 9: 最終品質ゲート (10軸・実測)

完成宣言の前に全軸を実測確認 (未達があれば修正してから宣言):

| # | 軸 | 実測方法 |
|---|---|---|
| 1 | 冒頭フック | 最初のカットが最強画か (絵コンテ再照合) |
| 2 | テンポ | カット尺がプリセット pacing ±50% 内 |
| 3 | テロップ可読性 | タイトル表示 ≥1.5秒・コントラスト目視 |
| 4 | 音声バランス | loudnorm 適用済 + ダッキング動作 |
| 5 | ブランド一貫性 | ロゴ/色がブランド素材と一致 |
| 6 | CTA | ラストにブランド+行動喚起がある |
| 7 | 比率/解像度 | 出力が指定 export と一致 (assemble の実測JSON) |
| 8 | 色の一貫性 | 全カットがプリセット grade で統一 (通しフレーム目視) |
| 9 | 書き出し品質 | h264/yuv420p/faststart (assemble が保証) |
| 10 | サムネイル | out/thumb.jpg が訴求力ある1枚か (必要なら thumb_sec 変更) |

## Step 10: 納品報告 (毎回必須)

完成報告に必ず含める: ①完成ファイルと サムネイルの場所 ②ショット構成表 (何カット・各何秒) ③**消費クレジット実測** (ledger status の値・見積との差) ④撮り直し回数 ⑤未達事項の正直開示 (BGM未収録等) ⑥**次の一手** (例:「音楽を頂ければ差し替え5分」「9:16版も同じ絵コンテから10分で出せます」「この絵コンテを雛形化して量産できます」)。

---

## 運用ルール

- **モデル実測の自己学習**: 新モデルの実測コスト/品質所感は `model-matrix.json` の measured_costs に追記する (次回から見積精度が上がる)。
- **連作の効率化**: 同一ブランドの2本目以降は、過去プロジェクトの shotlist.json / スタイルロック句 / SoulID を再利用する。
- **失敗の正直開示**: nsfw/failed はクレジット返還されるため台帳に載せない。ただし発生回数は納品報告に記す。
- **保守 (管理者)**: born-passing は `director-engine.sh selftest` (8項目) / `assemble.sh selftest` (3ケース・要 ffmpeg-full)。依存: ffmpeg-full (drawtext必須・`brew install ffmpeg-full`)、Node 18+、@higgsfield/client (REST予備経路利用時のみ hf-runner/ で npm install。配布物には非同梱・MCP経路なら不要)。スキルSoTは `~/.claude/commands/soloptilink-video.md`、ミラーは `~/.claude/skills/soloptilink-video/SKILL.md` (両方同時更新)。
