---
name: soloptilink-tenant-dna
description: "SoloptiLinkAI v2054.6 - 「テナント学習」「顧客プロファイル」「命名規則ロック」「SIer雛形」「過去判断」「Tenant DNA」「Memory Graph」等で起動。顧客企業×プロジェクト×判断の3次元永続学習層。データ送出ゼロ。"
argument-hint: "[--mode register|recall|recommend|export|import|sync] [--tenant <id>] [--project <id>] [--sier nttdata|fujitsu|nri|nomura|nec|hitachi|tis|sier-x|generic] [--source <project_dir>] [--auto-detect] [--locale ja|en]"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, Agent, AskUserQuestion, TodoWrite"
---

# SoloptiLinkAI v2054.6 - Tenant DNA / Memory Graph


## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

## 機能概要

SoloptiLinkAI v1.0 Tenant DNA / Memory Graph - 顧客企業×プロジェクト×判断 の3次元永続学習層。SIer→顧客→プロジェクト→判断 の4階層メモリで、命名規則・採用禁止ライブラリ・過去の決裁理由・SIer固有の雛形 (NTTデータ式/富士通式/NRI式/野村総研式) を蓄積。Claude Code は session 単位で記憶終わりだが、本スキルは永続保管+横断学習+次回プロジェクトへの自動注入で構造的ロックインを実現。「テナント学習」「顧客プロファイル」「命名規則ロック」「ライブラリブラックリスト」「SIer雛形」「過去判断」「Tenant DNA」「Memory Graph」「会社固有ルール」「過去の決裁」等で起動。対 Claude Code 差別化戦略 B-3 の核。データ送出ゼロ (~/.soloptilink/learning/tenants/ 配下に JSONL 永続化)。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

Claude Code が**構造的に到達できない**領域 — 「顧客企業ごとの暗黙知の永続学習」を実現する中核スキル。

## 対 Claude Code 差別化 — 「忘れない護城河」

| 領域 | Claude Code | SoloptiLinkAI Tenant DNA |
|------|------------|--------------------------|
| 記憶単位 | session 単位 | **SIer / 顧客 / プロジェクト / 判断 の4階層永続** |
| 命名規則 | 毎回ゼロから推論 | ✅ 顧客固有ルール (snake_case_ja / camelCase / 接頭辞) を学習し強制 |
| 採用禁止ライブラリ | 知らない | ✅ 「この客先はAmazon RDS禁止 / Vue禁止 / GraphQL禁止」を覚える |
| 過去の決裁理由 | 揮発 | ✅ "2024年12月に Next.js 14 → 15 へ上げない決定 (理由: Pages Router 維持)" |
| SIer 固有雛形 | 持たない | ✅ NTTデータ式SI標準雛形 / 富士通式 / NRI式 / 野村総研式 / NEC式 / 日立式 / TIS式 |
| 横断学習 | なし | ✅ 同一SIerの過去案件から成功パターンを次案件に注入 |
| データ送出 | クラウド経由 | ✅ ~/.soloptilink/learning/ 配下にローカル JSONL (Pマーク・閉域網対応) |
| アンロック | 不可 | ✅ `--export` で他端末・他社員へ DNA を引き継ぎ可能 |

## 4階層メモリモデル

```
SIer (NTTデータ / 富士通 / NRI 等)
└── Customer (株式会社サンプル建設)
    └── Project (工事原価管理システム v1)
        └── Decision (個別判断記録)
            ├── stack: 技術スタック決定
            ├── naming: 命名規則
            ├── library_ban: 採用禁止ライブラリ
            ├── design_pattern: 設計パターン採用/却下
            ├── deployment: デプロイ先決定
            ├── api_spec: API設計判断
            ├── db_schema: DB設計判断
            ├── ui_pattern: UI/UX決定
            ├── compliance: 法令対応決定
            └── handover: 引継ぎ事項
```

## Step 0: 端末認証 (BOOST と同一)

```bash
SOLOPTILINK_BIN=""; if [ -f ~/.soloptilink/soloptilink ]; then SOLOPTILINK_BIN="./soloptilink"; elif [ -f ~/.soloptilink/soloptilink.exe ]; then SOLOPTILINK_BIN="./soloptilink.exe"; fi
AUTH_CHECK=$(cd ~/.soloptilink 2>/dev/null && ${SOLOPTILINK_BIN:-./soloptilink} --status 2>&1); if echo "$AUTH_CHECK" | grep -q "承認済み"; then echo "AUTHORIZED"; else echo "UNAUTHORIZED"; fi
```

## ストレージレイアウト

```
~/.soloptilink/learning/tenants/
├── _index.json                       SIer / Customer / Project の階層インデックス
├── nttdata/                          SIer ID
│   ├── _profile.json                 SIer固有プロファイル (雛形・標準ライブラリ・禁則)
│   ├── customers/
│   │   ├── strukt-jp/
│   │   │   ├── _profile.json         顧客プロファイル
│   │   │   ├── naming.json           命名規則 (テーブル/変数/関数/接頭辞)
│   │   │   ├── library_blacklist.json 採用禁止ライブラリ
│   │   │   ├── decisions.jsonl       判断履歴 (append-only)
│   │   │   └── projects/
│   │   │       ├── kosei-2026/
│   │   │       │   ├── _project.json プロジェクトメタ
│   │   │       │   ├── decisions.jsonl
│   │   │       │   └── handover.md
│   │   │       └── shoki-2025/
│   │   └── kainuma-co/
│   └── _patterns.jsonl                SIer全体で頻出するパターン (蒸留結果)
├── fujitsu/
├── nri/
├── nomura/
├── nec/
├── hitachi/
├── tis/
└── _global_patterns.jsonl             全SIer横断のメタパターン
```

## モード一覧 (`--mode`)

### `register` — 新規 SIer / Customer / Project / Decision を登録
```
/soloptilink-tenant-dna --mode register --sier nttdata --tenant strukt-jp --project kosei-2026
```
プロジェクト初回起動時に自動呼び出し。`_profile.json` を作成し、以後の判断を `decisions.jsonl` に追記。

### `recall` — 関連メモリを取り出し、現セッションへ注入
```
/soloptilink-tenant-dna --mode recall --tenant strukt-jp
```
BOOST Step 0.4 推論サマリー直前に**自動呼出し**。命名規則・禁止ライブラリ・過去判断を Layer 5 として注入。

### `recommend` — 過去パターンから推奨技術スタック・設計を提案
```
/soloptilink-tenant-dna --mode recommend --sier nttdata --auto-detect
```
類似プロジェクトの成功パターンから次案件に向けた推奨を生成。

### `export` — DNA を ZIP / JSON エクスポート
```
/soloptilink-tenant-dna --mode export --tenant strukt-jp --output ~/Desktop/strukt-dna.zip
```
他端末・他社員へ引き継ぎ。複数端末同期にも使用。

### `import` — エクスポート済 DNA を取り込み
```
/soloptilink-tenant-dna --mode import --source ~/Desktop/strukt-dna.zip
```

### `sync` — 既存プロジェクトから DNA を逆抽出
```
/soloptilink-tenant-dna --mode sync --source <project_dir> --auto-detect
```
`package.json` / `prisma/schema.prisma` / `.eslintrc` / 既存ソースから命名規則・採用ライブラリを自動抽出して登録。

## SIer 内蔵雛形 (出荷時テンプレ)

| SIer | 命名規則 | 採用ライブラリ | 標準アーキテクチャ | デプロイ先傾向 |
|------|---------|---------------|------------------|---------------|
| **NTTデータ** | snake_case (DB) / camelCase (TS) / 接頭辞 `T_` `M_` | Spring Boot 主流 / 自社製OSS / SAStruts (レガシー) | 3層 + バッチ + EAI | オンプレ + プライベートクラウド |
| **富士通** | snake_case + 全大文字略称 / `tbl_` 接頭辞 | INTERSTAGE / Apworks / FUJITSU Cloud | フレームワーク強制 + ガイドライン重視 | FUJITSU Cloud / オンプレ |
| **NRI** | UpperCamelCase (Java) / TBL_ 接頭辞 | THE STAR / 自社系 | 金融標準 + STAR System | 自社データセンター |
| **野村総研** | NRI互換 + 詳細命名規約 | 同上 | 金融 / 証券系特化 | 自社DC |
| **NEC** | NEC共通フレームワーク準拠 | WebSAM / SystemDirector / Spring | 業務系 / 自治体系 | NEC Cloud IaaS |
| **日立** | 日立共通基盤準拠 | Cosminexus / JP1 / Hitachi Cloud | 業務系 / 公共系 | Hitachi Cloud |
| **TIS** | TIS共通開発標準 (TIDS) | Spring + Apache + JDDS | 金融系 / B2B | プライベートクラウド |
| **generic (中小SIer)** | 案件ごと | プロジェクト毎ベスト | 自由 | 案件ごと |

これらは出荷時テンプレで、各SIerの実プロジェクト経験で**上書き学習**される (組織内ノウハウとして蓄積)。

## BOOST 統合 (Step 0.4d Layer 5)

BOOST 起動時に Silent Inference Engine の **Layer 5: Tenant DNA Layer** として自動呼出し:

```
Layer 1: Prompt Parser
Layer 2: Domain Standard Template
Layer 3: Session Pattern Match
Layer 4: Workspace Context
Layer 5: Tenant DNA      ← v2019.2 新設 (このスキルが提供)
```

Layer 5 が拾うもの:
- 現プロジェクトディレクトリから推論される SIer / 顧客
- 過去の同一顧客の判断履歴
- 命名規則・ライブラリ禁則
- SIer標準雛形

推論サマリーへの追記:
```markdown
【Tenant DNA 自動適用】v2019.2
- SIer: NTTデータ (内蔵雛形 + 過去実績 23件)
- 顧客: 株式会社サンプル建設 (過去プロジェクト 3件)
- 命名規則: snake_case (DB) / camelCase (TS) / 接頭辞 `t_` `m_`
- 禁止ライブラリ: Vue, GraphQL, MongoDB (顧客方針 2024-11)
- 過去判断: Next.js 15 採用 / Prisma 採用 / Vercel デプロイ / Tailwind 採用
- 推奨パターン: 同SIer内 78% 案件で採用された「Auth.js v5 + Prisma + Postgres」
```

## 引数解釈

| 引数 | 動作 |
|------|------|
| `--mode register` | 新規エントリ作成 |
| `--mode recall` (デフォルト) | 関連DNA取り出し |
| `--mode recommend` | 推奨提案 |
| `--mode export` | DNA エクスポート |
| `--mode import` | DNA インポート |
| `--mode sync` | 既存プロジェクトから逆抽出 |
| `--tenant <id>` | 顧客ID (例: strukt-jp) |
| `--project <id>` | プロジェクトID |
| `--sier <id>` | SIer ID (nttdata/fujitsu/nri/nomura/nec/hitachi/tis/generic) |
| `--source <path>` | 既存プロジェクトディレクトリ or ZIPファイル |
| `--auto-detect` | package.json / .git/config 等から自動検出 |
| `--output <path>` | エクスポート先 |
| `--locale ja\|en` | 言語 (デフォルト ja) |

## 使用例

```bash
# 新規プロジェクトで Tenant DNA をスタート
/soloptilink-tenant-dna --mode register --sier nttdata --tenant strukt-jp --project kosei-2026

# BOOST 起動時に自動 recall (通常は意識不要)
/soloptilink-tenant-dna --mode recall --tenant strukt-jp

# 既存プロジェクトから命名規則・ライブラリ採用状況を逆抽出
/soloptilink-tenant-dna --mode sync --source ~/projects/strukt-kousei --auto-detect

# 部署移動時に DNA を引き継ぐ
/soloptilink-tenant-dna --mode export --tenant strukt-jp --output ~/Desktop/strukt-dna.zip
/soloptilink-tenant-dna --mode import --source ~/Desktop/strukt-dna.zip
```

## セキュリティ・データ保護

- **すべてローカル**: クラウドへ送信しない (`~/.soloptilink/learning/` 配下)
- **暗号化**: Mac Keychain / Linux libsecret に DNA 暗号鍵を保管 (`SoloptiLinkAI_DNA_KEY`)
- **個人情報フィルタ**: メールアドレス / 電話 / 住所は登録時に自動マスキング (`maskPII`)
- **顧客機密**: API key / DB 接続文字列は登録対象外 (`scanForSecrets` で警告)
- **エクスポート時**: 暗号化 ZIP + パスフレーズ必須

## 連携スキル

- `/soloptilink-boost`: Step 0.4d Layer 5 として呼出される側
- `/soloptilink-japan`: `pattern_library.ts` / `learning_analytics.ts` と双方向連携
- `/soloptilink-rfp`: 過去類似実績を提案書に自動引用
- `/soloptilink-handoff`: 引継書に Tenant DNA サマリーを自動添付

## 設計哲学

1. **Append-only**: 判断履歴は削除しない (改ざんされない監査ログ)
2. **オフライン優先**: ネットワーク不要、閉域網でも動作
3. **エクスポート可搬**: 端末・社員交代に強い
4. **段階的学習**: 出荷時テンプレ → 実案件で精度向上 → 横断蒸留
5. **プライバシー優先**: PII / 秘密情報は自動マスク
