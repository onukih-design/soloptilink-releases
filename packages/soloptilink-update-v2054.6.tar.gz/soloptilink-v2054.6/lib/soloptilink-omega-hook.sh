#!/usr/bin/env bash
# ============================================================================
# SoloptiLink AI Omega Hook (v2026.0 統合ブリッジ)
# ============================================================================
# SoloptiLink AI 本体 (chain.sh / BOOST / Generator-Verifier Loop) から
# v2026.0 ARTE-Omega を「能力」として呼び出すための統合層。
#
# 役割:
#   1. SoloptiLink がプロジェクトを生成/修正した直後に自動セキュリティ検査
#   2. 検出された脆弱性に対して 12 防御層を自動修正生成
#   3. Closed-Loop で再検証 (0件まで最大3iter)
#   4. 最終的に「Customer Confidence Score (CCS) のセキュリティ軸」へ反映
#
# 呼び出し方:
#   bash ~/.soloptilink/lib/soloptilink-omega-hook.sh check <project_dir> [--quick|--full|--closed-loop]
#   bash ~/.soloptilink/lib/soloptilink-omega-hook.sh score <project_dir>
#   bash ~/.soloptilink/lib/soloptilink-omega-hook.sh integrate-into-pipeline
# ============================================================================
set -uo pipefail

OMEGA_HOOK_VERSION="1.0.0"
ARTE_ROOT="${ARTE_ROOT:-$HOME/.soloptilink/lib/security/arte}"
V2025_ROOT="$ARTE_ROOT/v2025"
V2026_ROOT="$ARTE_ROOT/v2026"
QF_ROOT="${QF_ROOT:-$HOME/.soloptilink/lib/quality-fortresses}"
HOOK_LOG="${HOOK_LOG:-$HOME/.soloptilink/.omega-hook.log}"

usage() {
  cat <<EOF
SoloptiLink AI Omega Hook v${OMEGA_HOOK_VERSION}

SoloptiLink AI 本体に v2026 ARTE-Omega の攻撃側AI + 自動修復を「能力」として組み込むブリッジ。

Usage:
  soloptilink-omega-hook.sh check <project_dir> [--quick|--full|--closed-loop|--tier1]
      --quick       : 4 主要攻撃 (api/ml/k8s/identity) のみ
      --full        : 16 攻撃領域フルスキャン
      --closed-loop : 攻撃→修正→再検証 (3iter)
      --tier1       : v2026.1 Tier-1 Defenders 8モジュール起動 (国家機関相当)
      --sovereign   : v2027.0 Sovereign Audit 起動 (Tier-0 監査法人代替+Self-Healing)
      --antifragile : v2028.0 Antifragile 起動 (連合学習+RL+Adaptive Honeypot)
      --predictive  : v2029.0 Predictive 起動 (攻撃3-6ヶ月先回り予測)
      --confidential: v2030.0 Confidential Computing (TEE+FHE+ZKP+MPC)
      --tier-x      : v2028+v2029+v2030 全部実行 (技術天井)
      --vs-ai       : v2032.0 AI-vs-AI Defense (Mythos 等最新AI攻撃対応)

  soloptilink-omega-hook.sh score <project_dir>
      v2025 (Quantum + Legal) + v2026 (Mega-Attack + Auto-Heal) の
      Fortress 4本を採点し、SoloptiLink AI 総合セキュリティスコアを返す。

  soloptilink-omega-hook.sh integrate-into-pipeline
      chain.sh からこのフックが呼ばれるよう設定スニペットを出力

  soloptilink-omega-hook.sh status
      v2025 / v2026 モジュール存在状態を確認

Exit Codes:
  0  全モジュール健全 + Closed-Loop 収束
  1  脆弱性が残存 (Auto-Heal 適用後も)
  2  使用方法エラー
  90 Kill-Switch 発火
EOF
}

# ロギング
hook_log() {
  local LV="$1"; shift
  local TS; TS=$(date +%Y-%m-%dT%H:%M:%S%z)
  printf "[%s] [%s] %s\n" "$TS" "$LV" "$*" >> "$HOOK_LOG" 2>/dev/null || true
  case "$LV" in
    INFO)  printf "\033[36m[Omega]\033[0m %s\n" "$*" ;;
    WARN)  printf "\033[33m[Omega WARN]\033[0m %s\n" "$*" >&2 ;;
    ERROR) printf "\033[31m[Omega ERROR]\033[0m %s\n" "$*" >&2 ;;
    OK)    printf "\033[32m[Omega OK]\033[0m %s\n" "$*" ;;
  esac
}

# Kill-Switch 確認
check_kill() {
  if [ -f "$ARTE_ROOT/kill.flag" ]; then
    hook_log ERROR "Global ARTE Kill-Switch ENGAGED"
    return 90
  fi
  return 0
}

# モジュール存在チェック
status_cmd() {
  echo "═══════════════════════════════════════════════════════════════════"
  echo " SoloptiLink AI Omega Hook v${OMEGA_HOOK_VERSION} — Capability Status"
  echo "═══════════════════════════════════════════════════════════════════"
  local OK=0 FAIL=0
  check_file() {
    if [ -f "$2" ]; then echo "  ✓ $1"; OK=$((OK+1))
    else echo "  ✗ $1 (missing $2)"; FAIL=$((FAIL+1)); fi
  }
  echo " [v2025 ARTE-Quantum + Legal Attack Surface]"
  check_file "Quantum Orchestrator" "$V2025_ROOT/quantum-orchestrator.sh"
  check_file "Legal Attack Orchestrator" "$V2025_ROOT/legal-attack-orchestrator.sh"
  check_file "Unvigintifortress (21st)" "$QF_ROOT/unvigintifortress.sh"
  check_file "Duovigintifortress (22nd)" "$QF_ROOT/duovigintifortress.sh"
  echo ""
  echo " [v2026 ARTE-Omega Mega-Attack + Auto-Heal]"
  check_file "Mega-Attack Orchestrator" "$V2026_ROOT/mega-attack-orchestrator.sh"
  check_file "Closed-Loop Orchestrator" "$V2026_ROOT/closed-loop-orchestrator.sh"
  check_file "Auto-Heal Orchestrator" "$V2026_ROOT/auto-heal/auto-heal-orchestrator.sh"
  check_file "Tervigintifortress (23rd)" "$QF_ROOT/tervigintifortress.sh"
  check_file "Quattuorvigintifortress (24th)" "$QF_ROOT/quattuorvigintifortress.sh"
  echo ""
  echo " [Integration]"
  check_file "Omega Hook (this script)" "$HOME/.soloptilink/lib/soloptilink-omega-hook.sh"
  echo "─────────────────────────────────────────────────────────"
  echo "  OK: $OK / FAIL: $FAIL"
  echo "═══════════════════════════════════════════════════════════════════"
  [ $FAIL -eq 0 ]
}

# check コマンド: プロジェクトに対するセキュリティ検査
check_cmd() {
  local PROJECT="$1"; shift
  local MODE="quick"
  while [ $# -gt 0 ]; do
    case "$1" in
      --quick) MODE="quick"; shift ;;
      --full) MODE="full"; shift ;;
      --closed-loop) MODE="closed-loop"; shift ;;
      *) shift ;;
    esac
  done
  [ -d "$PROJECT" ] || { hook_log ERROR "Project not found: $PROJECT"; return 2; }
  check_kill || return 90

  hook_log INFO "SoloptiLink Omega Capability invoked: mode=$MODE on $PROJECT"

  local OUTDIR="$PROJECT/.soloptilink-omega"
  mkdir -p "$OUTDIR"

  case "$MODE" in
    quick)
      # 2026-07-24 大型ディレクトリガード: 生成物でない巨大作業フォルダ (開発ワークスペース等・実測14GB/2.5万ファイル) で
      # quick-scan の identity 段が巨大ファイル群に引っかかり Stop hook の制限時間内に完走できず
      # 「起動ログのみ・完了なし」で毎ターン時間を浪費する事象の根治。2条件 (ファイル数 or 200MB超ファイルの存在) の
      # いずれか該当でスキップを正直に記録して終了 (fail-open ではなく明示 skip・生成プロジェクトは数百ファイルで非該当)。
      # 判定は両方とも早期打切りで 0.5 秒以内 (du は 8 秒超のため不採用)。
      local MAX_FILES="${OMEGA_MAX_FILES:-20000}"
      local FILE_COUNT BIG_FILE
      FILE_COUNT=$(find "$PROJECT" \( -name node_modules -o -name .git -o -name .next -o -name .backups \) -prune -o -type f -print 2>/dev/null | head -n "$((MAX_FILES + 1))" | wc -l | tr -d ' ')
      BIG_FILE=$(find "$PROJECT" \( -name node_modules -o -name .git -o -name .next -o -name .backups \) -prune -o -type f -size +200M -print 2>/dev/null | head -1)
      if [ "$FILE_COUNT" -gt "$MAX_FILES" ] || [ -n "$BIG_FILE" ]; then
        hook_log WARN "Quick scan skip: 対象が大きすぎます (files=${FILE_COUNT}/上限${MAX_FILES} / 200MB超=${BIG_FILE:-なし})。生成プロジェクト単位で実行するか OMEGA_MAX_FILES で調整してください: $PROJECT"
        return 0
      fi
      hook_log INFO "Quick scan (4 critical attack surfaces: api/ml/k8s/identity)"
      hook_log INFO "  → mega-attack-orchestrator.sh quick-scan 起動"
      # v2034.2 (2026-05-18): tail -10 撤去で進捗ログ完全可視化
      # PFP-180 v2 (2026-07-23 決定性根治): stdbuf -oL | tee のパイプチェーンが api-attacker の
      # grep+while read サブシェルに部分読み/早期終了レースを引き起こし、実行毎に BOLA 検出件数が
      # 変動 (0-3件) していた。tee の代わりにログはリダイレクト書込に変更し stdbuf も撤去する
      # (進捗ログの可視化は v2034.2 で撤去済のため tail -10 制限なし=リダイレクトで問題なし)。
      bash "$V2026_ROOT/mega-attack-orchestrator.sh" quick-scan "$PROJECT" --output-dir "$OUTDIR/quick" > "$OUTDIR/quick.log" 2>&1
      hook_log INFO "Quick scan 完了 (詳細: $OUTDIR/quick.log)"
      ;;
    full)
      hook_log INFO "Full 16-domain attack surface scan"
      hook_log INFO "  → mega-attack-orchestrator.sh full-scan 起動"
      stdbuf -oL bash "$V2026_ROOT/mega-attack-orchestrator.sh" full-scan "$PROJECT" \
        --output-dir "$OUTDIR/full" 2>&1 | tee "$OUTDIR/full.log"
      hook_log INFO "Full scan 完了 / 次: v2025 Quantum scan"
      stdbuf -oL bash "$V2025_ROOT/quantum-orchestrator.sh" quick-scan "$PROJECT" 2>&1 | tee "$OUTDIR/quantum.log"
      hook_log INFO "Quantum scan 完了 (詳細: $OUTDIR/quantum.log)"
      ;;
    closed-loop)
      hook_log INFO "Closed-Loop Red-Blue Auto-Heal (full pipeline)"
      bash "$V2026_ROOT/closed-loop-orchestrator.sh" run "$PROJECT" \
        --industry "${SOLOPTILINK_INDUSTRY:-generic}" \
        --max-iter 3 \
        --output-dir "$OUTDIR/closed-loop" 2>&1 | tee "$OUTDIR/closed-loop.log" | tail -15
      ;;
    tier1)
      hook_log INFO "Tier-1 Defenders 起動 (国家機関相当 8モジュール)"
      local T1="$V2026_ROOT/tier1-defenders"
      mkdir -p "$OUTDIR/tier1"
      for M in anomaly-detector threat-intel-aggregator deepfake-detector ueba-analyzer \
               dlp-engine attestation-validator multi-guardrail-llm apt-hunter; do
        if [ -x "$T1/$M.sh" ]; then
          hook_log INFO "  Tier-1: $M"
          bash "$T1/$M.sh" --help >/dev/null 2>&1 && \
            echo "  ✓ $M ready" || echo "  ✗ $M issue"
        fi
      done 2>&1 | tee "$OUTDIR/tier1.log"
      bash "$V2026_ROOT/closed-loop-orchestrator.sh" run "$PROJECT" \
        --industry "${SOLOPTILINK_INDUSTRY:-generic}" --max-iter 3 \
        --output-dir "$OUTDIR/closed-loop" 2>&1 | tail -5
      ;;
    sovereign)
      hook_log INFO "Tier-0 Sovereign Audit 起動 (監査法人代替 5フレーム + Self-Healing)"
      local V27="$ARTE_ROOT/v2027"
      mkdir -p "$OUTDIR/sovereign"
      if [ -x "$V27/auditor-orchestrator.sh" ]; then
        bash "$V27/auditor-orchestrator.sh" run "$PROJECT" \
          --industry "${SOLOPTILINK_INDUSTRY:-generic}" --frame all \
          --output-dir "$OUTDIR/sovereign" 2>&1 | tail -20
      fi
      bash "$V2026_ROOT/closed-loop-orchestrator.sh" run "$PROJECT" \
        --industry "${SOLOPTILINK_INDUSTRY:-generic}" --max-iter 3 \
        --output-dir "$OUTDIR/closed-loop" 2>&1 | tail -5
      ;;
    antifragile)
      hook_log INFO "Tier-0+ Antifragile 起動 (連合学習+RL+Adaptive)"
      local V28="$ARTE_ROOT/v2028"
      [ -x "$V28/antifragile-orchestrator.sh" ] && \
        bash "$V28/antifragile-orchestrator.sh" run "$PROJECT" \
          --output-dir "$OUTDIR/antifragile" 2>&1 | tail -15
      ;;
    predictive)
      hook_log INFO "Tier-0+ Predictive 起動 (攻撃3-6ヶ月先回り予測)"
      local V29="$ARTE_ROOT/v2029"
      [ -x "$V29/prophetic-orchestrator.sh" ] && \
        bash "$V29/prophetic-orchestrator.sh" run "$PROJECT" \
          --horizon 6m --output-dir "$OUTDIR/predictive" 2>&1 | tail -15
      ;;
    confidential)
      hook_log INFO "Tier-0+ Confidential Computing 起動 (TEE+FHE+ZKP+MPC)"
      local V30="$ARTE_ROOT/v2030"
      [ -x "$V30/confidential-orchestrator.sh" ] && \
        bash "$V30/confidential-orchestrator.sh" run "$PROJECT" \
          --scheme all --output-dir "$OUTDIR/confidential" 2>&1 | tail -15
      ;;
    tier-x)
      hook_log INFO "Tier-X 起動 (Antifragile + Predictive + Confidential 全層)"
      for V in v2028:antifragile-orchestrator v2029:prophetic-orchestrator v2030:confidential-orchestrator; do
        local VER="${V%:*}" SCRIPT="${V#*:}"
        [ -x "$ARTE_ROOT/$VER/$SCRIPT.sh" ] && \
          bash "$ARTE_ROOT/$VER/$SCRIPT.sh" run "$PROJECT" \
            --output-dir "$OUTDIR/$VER" 2>&1 | tail -5
      done
      ;;
    vs-ai)
      hook_log INFO "AI-vs-AI Defense 起動 (Mythos 等最新AI攻撃対応)"
      local V32="$ARTE_ROOT/v2032"
      [ -x "$V32/vsai-orchestrator.sh" ] && \
        bash "$V32/vsai-orchestrator.sh" run "$PROJECT" \
          --mode "${SOLOPTILINK_VSAI_MODE:-normal}" \
          --output-dir "$OUTDIR/vs-ai" 2>&1 | tail -15
      ;;
  esac

  # 結果サマリを Customer Confidence Score (CCS) 互換 JSON で残す
  python3 - "$OUTDIR" "$PROJECT" "$MODE" <<'PY'
import json, os, sys, datetime, glob
outdir, project, mode = sys.argv[1:4]
total_findings = 0
critical = 0
high = 0
# skeptic FIND-180-04: findings.json 集計を「今回のモードのサブディレクトリ」に限定する。
# 従来は {outdir}/**/findings.json を再帰 glob していたため、同一 OUTDIR に quick と full の
# 過去結果が同居すると両方を二重合算し、quick 実行でも過去 full の critical で PERFECT にならない
# (逆に過去 full を消さず quick を回すと過大報告)。モードのサブディレクトリを優先し、無ければ
# 従来の再帰 glob にフォールバック (他モード=closed-loop 等が別階層へ書く後方互換)。
mode_files = sorted(set(
    glob.glob(f"{outdir}/{mode}/findings.json") +
    glob.glob(f"{outdir}/{mode}/**/findings.json", recursive=True)
))
scan_files = mode_files or sorted(set(glob.glob(f"{outdir}/**/findings.json", recursive=True)))
for f in scan_files:
    try:
        with open(f) as g: d = json.load(g)
        total_findings += d.get("totalFindings", 0)
        sev = d.get("severity", {})
        critical += sev.get("critical", 0)
        high += sev.get("high", 0)
    except: pass

# セキュリティスコア (0-100)
# critical 0件 = 100点 から減点
score = 100 - (critical * 10) - (high * 3)
score = max(0, min(100, score))
verdict = "PERFECT" if critical == 0 and high == 0 else \
          "GOOD" if score >= 80 else \
          "NEEDS_REMEDIATION" if score >= 50 else "CRITICAL"

summary = {
    "tool": "SoloptiLink AI Omega Hook",
    "version": "1.0.0",
    "project": project,
    "mode": mode,
    "evaluatedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "totalFindings": total_findings,
    "critical": critical,
    "high": high,
    "securityScore": score,
    "verdict": verdict,
    "ccsSecurityAxis": score,
    "recommendation": (
        "本体能力として ARTE-Omega が攻撃面0件確認済み — 配信可能" if verdict == "PERFECT"
        else "残存脆弱性に Auto-Heal を実行: bash ~/.soloptilink/lib/security/arte/v2026/auto-heal/auto-heal-orchestrator.sh heal <findings>"
    )
}
with open(f"{outdir}/omega-summary.json", 'w', encoding='utf-8') as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)
print(f"\n═══════════════════════════════════════════════════════════════════")
print(f" SoloptiLink AI Omega Capability — Summary")
print(f"═══════════════════════════════════════════════════════════════════")
print(f"  Total findings:   {total_findings}")
print(f"  Critical:         {critical}")
print(f"  High:             {high}")
print(f"  Security Score:   {score} / 100")
print(f"  Verdict:          {verdict}")
print(f"  CCS Security:     {score} / 100")
print(f"═══════════════════════════════════════════════════════════════════")
PY

  hook_log OK "Omega check complete: $OUTDIR/omega-summary.json"
  # exit code: 重要度に応じて
  local CRITICAL; CRITICAL=$(python3 -c "import json;print(json.load(open('$OUTDIR/omega-summary.json'))['critical'])" 2>/dev/null || echo 0)
  [ "$CRITICAL" = "0" ] && return 0 || return 1
}

# score コマンド: Fortress 4 本の統合スコア
score_cmd() {
  local PROJECT="$1"
  [ -d "$PROJECT" ] || { hook_log ERROR "Project not found"; return 2; }
  check_kill || return 90

  hook_log INFO "Computing SoloptiLink AI Integrated Security Fortress Score"

  local TMP; TMP=$(mktemp -d)
  trap "rm -rf $TMP 2>/dev/null" RETURN

  # Fortress 4 本を並列実行
  bash "$QF_ROOT/unvigintifortress.sh" "$PROJECT" "$TMP/21.json" >/dev/null 2>&1 &
  bash "$QF_ROOT/duovigintifortress.sh" "$PROJECT" "$TMP/22.json" >/dev/null 2>&1 &
  bash "$QF_ROOT/tervigintifortress.sh" "$PROJECT" "$TMP/23.json" >/dev/null 2>&1 &
  bash "$QF_ROOT/quattuorvigintifortress.sh" "$PROJECT" "$TMP/24.json" >/dev/null 2>&1 &
  wait

  python3 - "$TMP" "$PROJECT" <<'PY'
import json, os, sys, datetime
tmp, project = sys.argv[1:3]
def load(f):
    try:
        with open(f) as g: return json.load(g)
    except: return {"score":0, "rank":"N/A"}
f21 = load(f"{tmp}/21.json")
f22 = load(f"{tmp}/22.json")
f23 = load(f"{tmp}/23.json")
f24 = load(f"{tmp}/24.json")
totals = [f21["score"], f22["score"], f23["score"], f24["score"]]
total = sum(totals)
max_total = 170 * 4
rank = "Diamond★★★★★" if total >= int(max_total*0.95) else \
       "Platinum★★★★"  if total >= int(max_total*0.90) else \
       "Gold★★★"       if total >= int(max_total*0.82) else \
       "Silver"         if total >= int(max_total*0.70) else "Reject"
result = {
    "tool": "SoloptiLink AI Integrated Security Fortress",
    "version": "1.0.0",
    "project": project,
    "evaluatedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "fortresses": {
        "21st_Unvigintifortress_Quantum": f21["score"],
        "22nd_Duovigintifortress_LegalAttack": f22["score"],
        "23rd_Tervigintifortress_MegaAttack": f23["score"],
        "24th_Quattuorvigintifortress_AutoHeal": f24["score"]
    },
    "integratedScore": total,
    "maxScore": max_total,
    "percentage": round(total / max_total * 100, 1),
    "rank": rank
}
print(f"\n═══════════════════════════════════════════════════════════════════")
print(f" SoloptiLink AI Integrated Security Fortress")
print(f"═══════════════════════════════════════════════════════════════════")
print(f"  21st (Quantum):          {f21['score']:>3} / 170")
print(f"  22nd (Legal Attack):     {f22['score']:>3} / 170")
print(f"  23rd (Mega-Attack):      {f23['score']:>3} / 170")
print(f"  24th (Auto-Heal):        {f24['score']:>3} / 170")
print(f"─────────────────────────────────────────────────────────")
print(f"  INTEGRATED SCORE:        {total:>3} / {max_total}  ({result['percentage']}%)")
print(f"  RANK:                    {rank}")
print(f"═══════════════════════════════════════════════════════════════════")
print(json.dumps(result, ensure_ascii=False, indent=2))
PY
}

# パイプライン統合スニペット出力
integrate_cmd() {
  cat <<'EOF'
# ============================================================================
# SoloptiLink AI v2026 Omega 統合スニペット
# chain.sh の最後 (Phase 8 完了直前) に以下を追加することで
# 全ての SoloptiLink AI 生成成果物が自動的にセキュリティ検査される
# ============================================================================

# Phase 8.5: ARTE-Omega Security Closed-Loop (v2026 統合能力)
omega_phase_8_5() {
  local PROJECT="${PROJECT_DIR:-.}"
  echo ""
  echo "═══════════════════════════════════════════════════════════════════"
  echo " Phase 8.5: ARTE-Omega Security Closed-Loop"
  echo "═══════════════════════════════════════════════════════════════════"

  # クイックスキャン (本番品質ゲート)
  if bash ~/.soloptilink/lib/soloptilink-omega-hook.sh check "$PROJECT" --quick; then
    echo "  ✓ Quick security gate PASSED"
  else
    echo "  ⚠ Security issues detected — running Auto-Heal"
    # フルスキャン+Closed-Loop
    bash ~/.soloptilink/lib/soloptilink-omega-hook.sh check "$PROJECT" --closed-loop || true
  fi

  # 統合 Fortress スコア
  bash ~/.soloptilink/lib/soloptilink-omega-hook.sh score "$PROJECT"
}

# ----- chain.sh の最後で呼ぶ -----
# Phase 8 完了後:
omega_phase_8_5
EOF
}

# Main
CMD="${1:-}"
case "$CMD" in
  check) shift; check_cmd "$@" ;;
  score) shift; score_cmd "$@" ;;
  status) status_cmd ;;
  integrate-into-pipeline) integrate_cmd ;;
  ""|--help|-h) usage ;;
  *) hook_log ERROR "Unknown command: $CMD"; usage; exit 2 ;;
esac
exit 0
