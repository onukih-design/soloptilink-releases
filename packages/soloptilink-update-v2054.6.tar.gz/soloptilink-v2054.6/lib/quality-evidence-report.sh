#!/usr/bin/env bash
# ==============================================================================
# PFP-120 Quality Evidence Report — 品質証明書ジェネレータ (v2040)
# ------------------------------------------------------------------------------
# 目的:
#   完成した業務システムについて「どの品質ゲートを実走し、どう判定されたか」を
#   お客さま向けの単一 HTML 証明書 (品質証明書.html) として発行する。
#   記載内容はすべてプロジェクト内に実在する実測データのみから導出する (捏造禁止)。
#
#   さらに本証明書は「改ざん検証可能な保証書」である。発行時に証明書サイドカー
#   (certificate.json) を併せて書き出し、ゲート判定をハッシュ連鎖で封緘する。
#   第三者 (顧客/検収担当) は手元で verify サブコマンドを実行するだけで、保存
#   された判定が後から書き換えられていないか (改ざん検知) を自力で検証できる。
#
# 使い方 (CLI 契約):
#   bash quality-evidence-report.sh generate <project_dir>
#     → <project_dir>/品質証明書.html と <project_dir>/.soloptilink/certificate.json を生成
#   bash quality-evidence-report.sh verify <project_dir>
#     → certificate.json と現在の実測記録から fingerprint を再計算し真正性を判定
#        (一致=VERIFIED exit0 / 不一致=TAMPERED exit1)
#   bash quality-evidence-report.sh register <project_dir>
#     → certificate.json の発行記録 (PIIなし) をサーバへ best-effort 送信
#
# データソース (実在するものだけを採用・無いセクションは省略):
#   ① <project_dir>/.soloptilink/*-results.json   … 品質ゲート判定の実記録
#   ② <project_dir>/.soloptilink/agent-evidence/*.md … 実起動した専門ロールの証跡
#   ③ <project_dir>/(src/)app/**/page.{tsx,jsx,ts,js} … 実在する画面 (ページ)
#   ④ ①の実測ゲートを品質フレームワーク(標準29軸+新5軸=全34軸)上の軸として
#      レーダーチャート化 (実測された軸のみ描画)
#   ⑤ フッタ: 生成日時 + フィンガープリント + 検証URL + SoloptiLinkAI v2040 クレジット
#
# 改ざん検証の核 (ハッシュ連鎖 algo='sha256-chain-v1'):
#   h0 = sha256(version + '|' + issued_at)
#   hi = sha256(h(i-1) + '|' + gate_i.name + '=' + gate_i.verdict)   ※ゲート名昇順
#   最終 hi が fingerprint。どれか 1 ゲートの verdict が改ざんされると fingerprint が割れる。
#
# 出力: <project_dir>/品質証明書.html (単一ファイル・外部依存なし・A4印刷対応)
#       <project_dir>/.soloptilink/certificate.json (PIIなし証明書サイドカー)
# 終了コード:
#   generate : 0 = 生成成功 / 2 = 設定エラー (project_dir 不正 / python3 不在)
#   verify   : 0 = VERIFIED (未改ざん) / 1 = TAMPERED (改ざん検知) / 2 = 設定エラー
#   register : 0 = 常に成功 (best-effort・送信失敗は黙殺) / 2 = 設定エラー
# 依存: python3 (標準ライブラリのみ / Desktop 環境でも動作), curl (register のみ任意)
# 備考: 顧客可視の成果物のため PFP 番号は本文に出さず、顧客向け日本語名称で表記する。
#       certificate.json には PII (プロジェクト名/パス/コード等) を一切含めない。
# ==============================================================================
set -uo pipefail

CMD="${1:-help}"
PROJECT_DIR="${2:-}"

QER_VERSION="v2040"
# 検証 URL のベース (環境変数で上書き可)
SITE_URL="${SOLOPTILINK_SITE_URL:-https://admin-dashboard-blue-alpha-78.vercel.app}"

usage() {
    cat <<'USAGE'
PFP-120 Quality Evidence Report — 品質証明書ジェネレータ
使い方:
  quality-evidence-report.sh generate <project_dir>   品質証明書.html + certificate.json を生成
  quality-evidence-report.sh verify   <project_dir>   保存判定の真正性を再計算検証 (VERIFIED/TAMPERED)
  quality-evidence-report.sh register <project_dir>   発行記録(PIIなし)をサーバへ best-effort 送信
  quality-evidence-report.sh help                      このヘルプを表示
USAGE
}

case "$CMD" in
    help|-h|--help)
        usage
        exit 0
        ;;
    generate|verify|verify-internal|register)
        : # 続行
        ;;
    self-test)
        # self-test は project_dir 不要(純メモリで sha256-chain-v1 の発行/検証対称性・
        # メタ加算の fingerprint 不変性・改ざん感度を検査する)。ダミーを充て共通経路へ。
        PROJECT_DIR="${PROJECT_DIR:-.}"
        ;;
    *)
        echo "❌ 不明なコマンドです: $CMD" >&2
        usage >&2
        exit 2
        ;;
esac

if [[ -z "$PROJECT_DIR" ]]; then
    echo "❌ project_dir を指定してください" >&2
    usage >&2
    exit 2
fi

# プロジェクトディレクトリの正規化 (実在確認を兼ねる)
PROJECT_DIR="$(cd "$PROJECT_DIR" 2>/dev/null && pwd)" || {
    echo "❌ project_dir が見つかりません: ${2:-}" >&2
    exit 2
}

command -v python3 >/dev/null 2>&1 || {
    echo "❌ python3 が見つかりません (品質証明書の生成・検証に必要です)" >&2
    exit 2
}

# ------------------------------------------------------------------------------
# 共有 python ヘルパー本体。
# generate / verify / register の 3 サブコマンドはいずれもこの 1 本の python を
# 起動し、第 1 引数のモードで分岐する。実測データの収集・判定導出・ハッシュ連鎖の
# 算出ロジックを 1 箇所に集約することで、「発行時」と「検証時」で fingerprint の
# 計算式が必ず一致する (= 改ざん検知が成立する) ことを構造的に保証する。
#
# 引数の渡し方は既存方針を踏襲し、すべて argv 経由 (パス文字列のコード内展開禁止)。
#   argv[1] = MODE (generate|verify|register)
#   argv[2] = PROJECT_DIR
#   argv[3] = ENGINE_VERSION
#   argv[4] = SITE_URL
#   argv[5] = ISSUED_AT (ISO8601 / generate 時のみ意味を持つ。date -u で外から渡す)
#   argv[6] = CERT_ID   (ランダム / generate 時のみ意味を持つ。シェル側で採番)
# ------------------------------------------------------------------------------

# issued_at は python 内で生成せず、date -u で取得して argv 経由で渡す (要件)。
ISSUED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

# cert_id はランダム。openssl 優先・無ければ /dev/urandom にフォールバック。
gen_cert_id() {
    if command -v openssl >/dev/null 2>&1; then
        openssl rand -hex 16 2>/dev/null && return 0
    fi
    if [[ -r /dev/urandom ]]; then
        # 32 hex 文字 (16 バイト相当) を urandom から生成
        LC_ALL=C tr -dc 'a-f0-9' < /dev/urandom 2>/dev/null | head -c 32
        return 0
    fi
    # 最終フォールバック (時刻 + PID)。証明書 ID は機密ではないため十分。
    printf '%s%s' "$(date +%s)" "$$"
}
CERT_ID="$(gen_cert_id)"

python3 - "$CMD" "$PROJECT_DIR" "$QER_VERSION" "$SITE_URL" "$ISSUED_AT" "$CERT_ID" <<'PYEOF'
# -*- coding: utf-8 -*-
# PFP-120 品質証明書ジェネレータ / 検証器 本体 (実測データのみ・捏造禁止)
import sys, os, re, json, glob, html, math, datetime, hashlib

MODE = sys.argv[1]
ROOT = os.path.realpath(sys.argv[2])
ENGINE_VERSION = sys.argv[3] if len(sys.argv) > 3 else "v2040"
SITE_URL = (sys.argv[4] if len(sys.argv) > 4 else "").rstrip("/")
ISSUED_AT = sys.argv[5] if len(sys.argv) > 5 else ""
CERT_ID = sys.argv[6] if len(sys.argv) > 6 else ""
SLD = os.path.join(ROOT, ".soloptilink")
OUT = os.path.join(ROOT, "品質証明書.html")
CERT_PATH = os.path.join(SLD, "certificate.json")
esc = html.escape

# ==============================================================================
# ゲート表示名カタログ (results ファイル名 → 顧客向け日本語名 / 補足説明 / レーダー軸名)
# ※ PFP 番号は顧客可視出力に出さない
# ==============================================================================
GATE_INFO = {
    "layered-depth":           ("業務階層深度検証",       "業界知識・業務ロジックが多層で実装されているかを検証", "業務深度"),
    "deep-system":             ("業務貫通度検証",         "データ充足・画面間連携・業務フローの貫通を検証",       "業務貫通"),
    "crud-input-capability":   ("入力フォーム完備検証",   "業務データの作成・編集・書込経路の実在を検証",         "入力機能"),
    "data-completeness":       ("初期データ充足検証",     "初回起動時から業務データが揃っているかを検証",         "データ充足"),
    "one-shot-completeness":   ("一発完成度検証",         "手作業セットアップなしで動作する完成度を検証",         "一発完成"),
    "security-hardening":      ("セキュリティ強化検証",   "通信防護・不正ログイン対策・暗号化など多軸で検証",     "セキュリティ"),
    "pfp-082-watermark":       ("知的財産保護検証",       "生成ファイルへの権利保護表記の網羅を検証",             "知財保護"),
    "uat":                     ("受入テスト検証",         "利用者目線の受入シナリオに基づく完全性を検証",         "受入テスト"),
    "csv-io":                  ("CSV入出力検証",          "CSV取込・出力機能の実在と整合を検証",                  "CSV入出力"),
    "document-output":         ("帳票出力検証",           "請求書等の帳票・ドキュメント出力機能を検証",           "帳票出力"),
    "permission-matrix":       ("権限管理検証",           "役割ごとのアクセス権限の整合を検証",                   "権限管理"),
    "compliance-implementation": ("法令対応実装検証",     "該当業種の法令要件(個情法/マイナンバー/電帳法/インボイス等)の実装網羅を検証", "法令対応"),
    "backup-restore":          ("バックアップ復元検証",   "バックアップ取得・復元機能の実在を検証",               "バックアップ"),
    "performance-baseline":    ("性能ベースライン検証",   "応答性能が基準内に収まっているかを検証",               "性能"),
    "image-cms":               ("画像管理機能検証",       "画像の一括登録・最適化・配信機能を検証",               "画像管理"),
    "mega-portal":             ("大規模ポータル対応検証", "大量データ掲載時の性能・SEO 構造を検証",               "大規模対応"),
    "incremental-integration": ("統合整合性検証",         "機能追加時の既存機能との整合を検証",                   "統合整合"),
    "aupe":                    ("UI/UX品質検証",          "画面の使いやすさ・見た目の品質を検証",                 "UI/UX"),
    "e2e":                     ("一気通貫テスト",         "実操作シナリオの自動テスト結果",                       "E2E試験"),
    "ui-test":                 ("画面テスト",             "画面表示・操作の自動テスト結果",                       "画面試験"),
    "crawl":                   ("全ページ巡回検証",       "全画面を実際に巡回しエラー有無を検証",                 "巡回検証"),
    "phase":                   ("工程別検証",             "構築工程ごとの検証結果",                               "工程検証"),
    "dep-audit":               ("依存パッケージ監査",     "利用ライブラリの脆弱性を監査",                         "依存監査"),
}

# ルート区分 → 日本語画面名 (一般的な業務システム語彙)
SEG_JA = {
    "dashboard": "ダッシュボード", "home": "ホーム", "login": "ログイン", "logout": "ログアウト",
    "signin": "ログイン", "signup": "新規登録", "register": "新規登録",
    "forgot-password": "パスワード再設定", "reset-password": "パスワード再設定", "password": "パスワード",
    "customers": "顧客", "customer": "顧客", "clients": "取引先", "client": "取引先",
    "companies": "企業", "company": "企業", "partners": "取引先",
    "users": "ユーザー", "user": "ユーザー", "staff": "スタッフ", "members": "メンバー",
    "employees": "従業員", "employee": "従業員", "teams": "チーム",
    "products": "商品", "product": "商品", "items": "品目", "services": "サービス",
    "inventory": "在庫", "stock": "在庫", "warehouses": "倉庫",
    "orders": "受注", "order": "受注", "purchases": "発注", "purchase": "発注",
    "sales": "売上", "deals": "商談", "leads": "リード", "opportunities": "商談",
    "quotes": "見積", "quotations": "見積", "estimates": "見積",
    "invoices": "請求書", "invoice": "請求書", "billing": "請求", "payments": "入金", "expenses": "経費",
    "contracts": "契約", "contract": "契約", "projects": "案件", "project": "案件",
    "tasks": "タスク", "task": "タスク", "issues": "課題", "tickets": "チケット",
    "reports": "レポート", "report": "レポート", "analytics": "分析", "stats": "統計",
    "settings": "設定", "setting": "設定", "profile": "プロフィール", "account": "アカウント",
    "notifications": "通知", "messages": "メッセージ", "chat": "チャット",
    "calendar": "カレンダー", "schedule": "スケジュール", "schedules": "スケジュール",
    "admin": "管理", "search": "検索", "help": "ヘルプ", "about": "概要",
    "new": "新規作成", "create": "新規作成", "edit": "編集",
    "attendance": "勤怠", "payroll": "給与", "leave": "休暇", "shifts": "シフト",
    "approvals": "承認", "approval": "承認", "workflows": "ワークフロー",
    "audit": "監査", "audit-logs": "監査ログ", "logs": "ログ", "history": "履歴",
    "suppliers": "仕入先", "vendors": "仕入先", "shipments": "出荷", "deliveries": "納品",
    "categories": "カテゴリ", "tags": "タグ", "documents": "書類", "files": "ファイル",
    "uploads": "アップロード", "import": "取込", "export": "出力",
    "news": "お知らせ", "announcements": "お知らせ", "faq": "よくある質問", "contact": "お問い合わせ",
}

# v2054.6 (PFP-181): 「測れなかった/実行されなかった」を UNVERIFIED として独立させる。
#   従来はこれらが未知の語として None になり、該当ゲートが**証明書から消えていた**ため、
#   未確認の項目がお客様には「問題なし」に見えていた (顧客可視レイヤーでの fail-open)。
#   序列は既存の相対順序を保ったまま WARN と FAIL の間に入れる。
SEV = {"PASS": 1, "WARN": 2, "UNVERIFIED": 3, "FAIL": 4, "BLOCK": 5}
VERDICT_JA = {"PASS": "合格", "WARN": "注意", "FAIL": "不合格", "BLOCK": "不合格(重大)",
              "NA": "対象外", "UNVERIFIED": "未確認"}
VERDICT_CLS = {"PASS": "b-pass", "WARN": "b-warn", "FAIL": "b-fail", "BLOCK": "b-fail",
               "NA": "b-na", "UNVERIFIED": "b-warn"}
# UNVERIFIED は意図的に SCORE へ入れない = 測っていないものを点数化しない。
# (スコアの分母から外れるが、一覧には「未確認」として必ず表示される)
SCORE = {"PASS": 100, "WARN": 60, "FAIL": 25, "BLOCK": 10}
# certificate.json の verdict 列が許容する値
ALLOWED_VERDICTS = ("PASS", "WARN", "FAIL", "BLOCK", "NA", "UNVERIFIED")


def norm_verdict(v):
    """判定文字列を PASS/WARN/FAIL/BLOCK/NA に正規化。判定でない値は None。"""
    u = str(v).strip().upper().replace("-", "_")
    if u in ("PASS", "PASSED", "OK", "GO", "SUCCESS", "GREEN", "APPLIED"):
        return "PASS"
    if u in ("WARN", "WARNING", "YELLOW"):
        return "WARN"
    if u in ("FAIL", "FAILED", "NG", "RED", "ERROR"):
        return "FAIL"
    if u == "BLOCK":
        return "BLOCK"
    if u in ("NOT_APPLICABLE", "NA", "N/A", "SKIP", "SKIPPED", "NONE"):
        return "NA"
    # v2054.6 (PFP-181): 測れなかった / 実行されなかったものは「対象外」ではない。
    #   お客様には「未確認」として必ず見せる (消さない・合格に混ぜない)。
    if u in ("UNMEASURABLE", "UNMEASURED", "NOT_MEASURED", "UNRUN", "NOT_RUN", "NOTRUN"):
        return "UNVERIFIED"
    return None


def collect_statuses(node, out):
    """ネストした verdict/status キーの値を再帰収集する。"""
    if isinstance(node, dict):
        for k, v in node.items():
            if k in ("verdict", "status") and isinstance(v, str):
                nv = norm_verdict(v)
                if nv:
                    out.append(nv)
            else:
                collect_statuses(v, out)
    elif isinstance(node, list):
        for v in node:
            collect_statuses(v, out)


def layer_num(s):
    m = re.match(r"[Ll](\d+)", str(s).strip())
    return int(m.group(1)) if m else None


def derive_verdict(base, d):
    """ゲートごとの実記録から判定を導出する。導出不能なら None (= 表示しない)。"""
    # 階層深度ゲートは到達階層 vs 基準階層の比較が公式判定
    if base == "layered-depth":
        a, m = layer_num(d.get("achieved_layer")), layer_num(d.get("min_required"))
        if a is not None and m is not None:
            if a >= m:
                return "PASS"
            return "FAIL" if d.get("strict") is True else "WARN"
    # トップレベルの判定キーを優先
    for k in ("verdict", "status", "overall", "result"):
        v = d.get(k)
        if isinstance(v, str):
            nv = norm_verdict(v)
            if nv:
                return nv
    # 無ければネスト判定を集計し最も重い判定を採用
    found = []
    collect_statuses(d, found)
    real = [v for v in found if v in SEV]
    if real:
        return max(real, key=lambda v: SEV[v])
    if "NA" in found:
        return "NA"
    return None


def strip_pfp(s):
    """顧客可視文字列から PFP 番号表記を取り除く。"""
    return re.sub(r"\(?\s*PFP[-_ ]?\d+[a-z]?\s*\)?\s*", "", str(s)).strip(" -—:")


_MANIFEST_JA_CACHE = None


def _manifest_name_ja(base):
    """台帳 (gates-manifest.json) から日本語ゲート名を引く。

    v2054.6 (PFP-181): 台帳登録ゲートを証明書に載せるようにした結果、
    GATE_INFO に無いゲートが英字 ID のまま顧客可視の証明書に出ていた。
    証明書はお客様が読むものなので、台帳の日本語名を第一候補にする。
    """
    global _MANIFEST_JA_CACHE
    if _MANIFEST_JA_CACHE is None:
        _MANIFEST_JA_CACHE = {}
        try:
            mani = os.path.expanduser("~/.soloptilink/lib/first-boot-perfect/gates-manifest.json")
            with open(mani, encoding="utf-8") as fh:
                for g in json.load(fh).get("gates", []):
                    gid = g.get("id") or ""
                    nm = (g.get("name_ja") or "").strip()
                    if gid and nm:
                        # 台帳の name_ja は説明文を「—」以降に含むことがあるので見出し部だけ使う
                        head = re.split(r"\s*[—(]\s*", nm)[0].strip() or nm
                        _MANIFEST_JA_CACHE[gid] = head
        except Exception:
            _MANIFEST_JA_CACHE = {}
    # 結果ファイル名 (例 tax-accuracy-results.json → tax-accuracy) と
    # 台帳 id (tax-accuracy-gate) は綴りが揺れるため、代表的な揺れを吸収して引く
    for key in (base, base + "-gate", base + "-guarantee", base.replace("-gate", "")):
        v = _MANIFEST_JA_CACHE.get(key)
        if v:
            return v
    return None


def gate_display(base, d):
    """(日本語ゲート名, 補足説明, レーダー軸名) を返す。"""
    if base in GATE_INFO:
        return GATE_INFO[base]
    ja = _manifest_name_ja(base)
    if ja:
        ja = strip_pfp(ja)
        if ja:
            return (ja, "", ja[:7])
    g = d.get("gate")
    if isinstance(g, str) and g.strip():
        name = strip_pfp(g)
        if name:
            return (name, "", name[:7])
    pretty = re.sub(r"^pfp-\d+-?", "", base).replace("-", " ").strip() or base
    return (pretty, "", pretty[:7])


def fmt_pct(v):
    return ("%g%%" % v) if isinstance(v, (int, float)) else None


def jget(d, *keys):
    cur = d
    for k in keys:
        if isinstance(cur, dict) and k in cur:
            cur = cur[k]
        else:
            return None
    return cur


def build_summary(base, d):
    """ゲート固有の実測値から「要点」文字列を組み立てる (実在する値のみ)。"""
    parts = []
    if base == "crud-input-capability":
        v = jget(d, "create_form", "coverage_pct")
        if isinstance(v, (int, float)):
            parts.append("作成フォーム網羅 %s" % fmt_pct(v))
        v = jget(d, "write_path", "coverage_pct")
        if isinstance(v, (int, float)):
            parts.append("書込経路 %s" % fmt_pct(v))
        v = jget(d, "edit_form", "coverage_pct")
        if isinstance(v, (int, float)):
            parts.append("編集フォーム %s" % fmt_pct(v))
    elif base == "deep-system":
        al = d.get("achieved_layer")
        if al:
            parts.append("到達深度 %s" % al)
        bm = d.get("business_models")
        if isinstance(bm, int) and bm > 0:
            parts.append("業務モデル %d件" % bm)
        v = jget(d, "L4_data_richness", "coverage_pct")
        if isinstance(v, (int, float)):
            parts.append("データ充足 %s" % fmt_pct(v))
    elif base == "layered-depth":
        al, mr = d.get("achieved_layer"), d.get("min_required")
        if al and mr:
            parts.append("到達階層 %s (基準 %s)" % (al, mr))
        elif al:
            parts.append("到達階層 %s" % al)
        nm = jget(d, "dbl", "name")
        if nm and jget(d, "dbl", "registered") is True:
            parts.append("業種辞書: %s" % nm)
        if norm_verdict(jget(d, "industry_terminology_coverage", "status") or "") == "FAIL":
            parts.append("業界用語網羅は基準未達")
    elif base == "pfp-082-watermark":
        w, t = d.get("watermarked_files"), d.get("total_files")
        if isinstance(w, int) and isinstance(t, int) and t > 0:
            parts.append("保護表記済 %d/%dファイル" % (w, t))
        v = d.get("coverage_percent")
        if isinstance(v, (int, float)):
            parts.append("網羅 %s" % fmt_pct(v))
    elif base == "security-hardening":
        axes = d.get("axes")
        if isinstance(axes, dict) and axes:
            ok = sum(1 for v in axes.values() if norm_verdict(v) == "PASS")
            parts.append("検査軸 %d/%d 適合" % (ok, len(axes)))
        ap = d.get("applied")
        if isinstance(ap, int) and ap > 0:
            parts.append("自動強化 %d件" % ap)
    # 汎用フォールバック (どのゲートでも実在すれば拾う)
    if not parts:
        for key, label in (("coverage_percent", "網羅"), ("coverage_pct", "網羅")):
            v = d.get(key)
            if isinstance(v, (int, float)):
                parts.append("%s %s" % (label, fmt_pct(v)))
                break
        al = d.get("achieved_layer")
        if al:
            parts.append("到達 %s" % al)
        p, t = d.get("passed"), d.get("total")
        if isinstance(p, int) and isinstance(t, int) and t > 0:
            parts.append("%d/%d 合格" % (p, t))
        bm = d.get("business_models")
        if isinstance(bm, int) and bm > 0:
            parts.append("業務モデル %d件" % bm)
    return " ／ ".join(parts[:3])


# ==============================================================================
# 共通: 実測ゲート集合の収集 (.soloptilink/*-results.json)
# generate / verify が同一ロジックを使うことで fingerprint の一致を保証する。
# 返り値: (gates, unreadable)
#   gates[i] = {base, name, desc, axis, verdict, summary}
# ==============================================================================
def _manifest_result_paths():
    """v2054.6 (PFP-181): 台帳に登録された結果ファイルも収集対象に加える。

    従来は '*-results.json' という命名のものだけを見ていたため、台帳登録ゲートの
    大半 (runtime-login-smoke.json 等) が証明書に一切載っていなかった。
    載らないゲートは「未確認」も表示されず、お客様には問題なしに見えてしまう。
    台帳が読めない環境では従来どおり glob だけで動く (証明書生成は止めない)。
    """
    out = []
    try:
        mani = os.path.expanduser("~/.soloptilink/lib/first-boot-perfect/gates-manifest.json")
        with open(mani, encoding="utf-8") as fh:
            entries = json.load(fh).get("gates", [])
        proj = os.path.dirname(SLD)
        for g in entries:
            rf = g.get("results_file") or ""
            if not rf:
                continue
            p = os.path.join(proj, rf)
            if os.path.exists(p):
                out.append(p)
    except Exception:
        pass
    return out


def collect_gates():
    gates = []
    unreadable = 0
    _paths = sorted(set(glob.glob(os.path.join(SLD, "*-results.json")) + _manifest_result_paths()))
    for path in _paths:
        _fn = os.path.basename(path)
        if _fn.endswith("-results.json"):
            base = _fn[: -len("-results.json")]
        else:
            base = _fn[: -len(".json")] if _fn.endswith(".json") else _fn
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception:
            unreadable += 1
            continue
        if not isinstance(data, dict):
            unreadable += 1
            continue
        verdict = derive_verdict(base, data)
        if verdict is None:
            continue  # 判定が導出できない記録は表示しない (捏造禁止)
        name, desc, axis = gate_display(base, data)
        gates.append({
            "base": base,
            "name": strip_pfp(name),
            "desc": strip_pfp(desc) if desc else "",
            "axis": strip_pfp(axis),
            "verdict": verdict,
            "summary": build_summary(base, data),
        })
    return gates, unreadable


def count_roles():
    """実起動専門ロール数 (agent-evidence/*.md の非空ファイル実数)。"""
    roles = 0
    ev_dir = os.path.join(SLD, "agent-evidence")
    if os.path.isdir(ev_dir):
        for fn in os.listdir(ev_dir):
            if not fn.endswith(".md"):
                continue
            fp = os.path.join(ev_dir, fn)
            try:
                if os.path.isfile(fp) and os.path.getsize(fp) > 0:
                    roles += 1
            except OSError:
                continue
    return roles


def collect_pages():
    """画面一覧 (app/ 配下の page.tsx 等を走査し日本語ルート名を付与)。"""
    app_root = None
    for cand in (os.path.join(ROOT, "src", "app"), os.path.join(ROOT, "app")):
        if os.path.isdir(cand):
            app_root = cand
            break
    pages = []
    if not app_root:
        return pages
    seen = set()
    for dirpath, dirnames, filenames in os.walk(app_root):
        dirnames[:] = [x for x in dirnames if x not in ("node_modules", ".next", ".git")]
        if not any(fn in ("page.tsx", "page.jsx", "page.ts", "page.js") for fn in filenames):
            continue
        rel = os.path.relpath(dirpath, app_root)
        segs = [] if rel == "." else rel.split(os.sep)
        segs = [s for s in segs if not (s.startswith("(") and s.endswith(")")) and not s.startswith("@")]
        route = "/" + "/".join(segs)
        if route in seen:
            continue
        seen.add(route)

        def seg_label(s):
            if re.fullmatch(r"\[\.*[^\]]+\]", s):
                return "詳細"
            return SEG_JA.get(s.lower(), s)

        label = " › ".join(seg_label(s) for s in segs) if segs else "トップページ"
        pages.append((route, label))
    pages.sort(key=lambda t: t[0])
    return pages


def collect_models():
    """業務モデル数 (Prisma schema の model 宣言数)。PII を含まないため件数のみ。"""
    candidates = [
        os.path.join(ROOT, "prisma", "schema.prisma"),
        os.path.join(ROOT, "schema.prisma"),
    ]
    for sp in candidates:
        if os.path.isfile(sp):
            try:
                with open(sp, encoding="utf-8") as fh:
                    txt = fh.read()
                return len(re.findall(r"(?m)^\s*model\s+\w+\s*\{", txt))
            except Exception:
                return 0
    return 0


def detect_target_domain():
    """対象業種ドメインを実測記録のみから導出する (捏造しない)。
       優先: 階層深度ゲートの DBL 名 (registered のみ) → 各 results の target_domain キー。
       見つからなければ None (= certificate に target_domain を載せない)。"""
    # ① 階層深度ゲート: DBL が registered のときだけ業種名を採用 (推測しない)
    ld = os.path.join(SLD, "layered-depth-results.json")
    if os.path.isfile(ld):
        try:
            with open(ld, encoding="utf-8") as fh:
                d = json.load(fh)
            if isinstance(d, dict):
                nm = jget(d, "dbl", "name")
                if isinstance(nm, str) and nm.strip() and jget(d, "dbl", "registered") is True:
                    return nm.strip()[:64]
        except Exception:
            pass
    # ② 任意の results.json に target_domain が実在すれば採用 (unknown は採らない)
    for path in sorted(glob.glob(os.path.join(SLD, "*-results.json"))):
        try:
            with open(path, encoding="utf-8") as fh:
                d = json.load(fh)
        except Exception:
            continue
        if isinstance(d, dict):
            td = d.get("target_domain")
            if isinstance(td, str) and td.strip() and td.strip().lower() != "unknown":
                return td.strip()[:64]
    return None


def overall_status(gates):
    """実測ゲート判定から総合ステータスを導出する (実 verdict のみが根拠)。
       不合格(FAIL/BLOCK)在 → '要確認' / 注意(WARN)在 → '条件付き合格' /
       合格在(他は対象外) → '合格' / 判定が対象外のみ → None。"""
    if not gates:
        return None
    verds = [g.get("verdict") for g in gates]
    if any(v in ("FAIL", "BLOCK") for v in verds):
        return "要確認"
    if any(v == "WARN" for v in verds):
        return "条件付き合格"
    if any(v == "PASS" for v in verds):
        return "合格"
    return None


# ==============================================================================
# ★ ハッシュ連鎖 (改ざん検知の核) — algo='sha256-chain-v1'
#   h0 = sha256(version + '|' + issued_at)
#   hi = sha256(h(i-1) + '|' + gate_i.name + '=' + gate_i.verdict)   ※ゲート名昇順
#   最終 hi が fingerprint。
#   入力 (version, issued_at, ゲート名↔判定) が 1 文字でも変われば fingerprint が割れる。
# ==============================================================================
def _sha256(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def compute_chain(version, issued_at, gate_pairs):
    """gate_pairs = [(name, verdict), ...] (任意順) を受け取り、
       (hash_chain, fingerprint) を返す。ゲート名昇順で連鎖を構築する。"""
    # 同名ゲートが理論上ありうるため (name, verdict) の組で安定ソート
    ordered = sorted(gate_pairs, key=lambda p: (p[0], p[1]))
    chain = [_sha256("%s|%s" % (version, issued_at))]
    for name, verdict in ordered:
        chain.append(_sha256("%s|%s=%s" % (chain[-1], name, verdict)))
    fingerprint = chain[-1]
    return chain, fingerprint


def gate_pairs_from(gates):
    """gates リストから (name, verdict) の組を取り出す。verdict は許容集合のみ。"""
    pairs = []
    for g in gates:
        v = g["verdict"]
        if v not in ALLOWED_VERDICTS:
            v = "NA"
        pairs.append((g["name"], v))
    return pairs


def gate_pairs_from_cert(cert_gates):
    """certificate.json の gates ([{name, verdict}, ...]) から (name, verdict) の組を
       防御的に取り出す。発行時 gate_pairs_from と同一の正規化を行い、内部整合性検査で
       『証明書自身の判定一覧から連鎖を再計算』できるようにする (fingerprint 構成は不変)。"""
    pairs = []
    if not isinstance(cert_gates, list):
        return pairs
    for g in cert_gates:
        if not isinstance(g, dict):
            continue
        v = g.get("verdict")
        if v not in ALLOWED_VERDICTS:
            v = "NA"
        pairs.append((str(g.get("name")), v))
    return pairs


# ==============================================================================
# L10 v2043: トレーサビリティ(session_id + role列) / 外部タイムスタンプ(TSA)メタ
#   いずれも fingerprint 構成式 (compute_chain) に渡さない「メタ」。証明書に出所と
#   時刻証明を刻むが、改ざん検知の対称性 (発行/検証の fingerprint 一致) は不変。
# ==============================================================================
def collect_role_names():
    """agent-evidence/*.md の非空ファイル名(=実起動ロール識別子)を昇順で返す。
       count_roles と同じ母集団。role 列トレーサビリティの出所根拠。"""
    names = []
    ev_dir = os.path.join(SLD, "agent-evidence")
    if os.path.isdir(ev_dir):
        for fn in os.listdir(ev_dir):
            if not fn.endswith(".md"):
                continue
            fp = os.path.join(ev_dir, fn)
            try:
                if os.path.isfile(fp) and os.path.getsize(fp) > 0:
                    names.append(fn[:-3])  # 拡張子 .md を除去
            except OSError:
                continue
    return sorted(names)


def _sanitize_sid(sid):
    """session_id を安全文字種へ正規化(PII/注入防止)。@以降(メール)除去・[A-Za-z0-9._-]のみ・64字。
       pfp-082 透かし側のサニタイズと同方針(skeptic/falsifier 指摘の二重防御)。"""
    sid = (sid or "").split("@", 1)[0]
    sid = "".join(c for c in sid if (c.isalnum() or c in "._-"))
    return sid[:64]


def traceability_bound_digest(fingerprint, sid, roles_digest):
    """traceability を fingerprint へ束縛するダイジェスト(改ざん検知=tamper-evident)。
       bound = sha256(fingerprint | session_id | roles_digest)。
       ★ これにより「traceability を別 cert からコピー」「session_id を黙って書換」を検知できる
         (fingerprint に紐づくため)。ただし秘密鍵を持たないため完全な否認防止(non-repudiation)
         には至らない=完全強度は owner の TSA/HMAC 実鍵運用が前提(language を過大にしない)。
       ★ 主 fingerprint 構成式(gate+version+issued_at)は不変=L8-QER-FPCONST 保存・発行/検証対称。"""
    return _sha256("%s|%s|%s" % (fingerprint, sid, roles_digest))


def build_traceability(cert_id, role_count, fingerprint=""):
    """session_id + role列メタを組む。session_id は環境変数優先(無ければ cert_id 由来)。
       PII を含めない(ロール識別子は内部固定名・プロジェクト名/パスは入れない)。
       fingerprint が渡れば bound_digest(連鎖束縛)を付与する。"""
    sid = _sanitize_sid(os.environ.get("SOLOPTILINK_SESSION_ID", "").strip())
    if not sid:
        # セッションIDが渡らない実行では cert_id の先頭16桁を擬似セッション識別子に充てる
        sid = ("cert-" + str(cert_id))[:21]
    roles = collect_role_names()
    roles_digest = _sha256("|".join(roles)) if roles else ""
    t = {
        "session_id": sid,
        "role_count": role_count,
        "roles": roles,
        # role 列のダイジェスト(順序非依存・出所照合用。fingerprint とは無関係)
        "roles_digest": roles_digest,
    }
    if fingerprint:
        t["bound_digest"] = traceability_bound_digest(fingerprint, sid, roles_digest)
    return t


def build_external_ts(fingerprint):
    """TSA(Time-Stamping Authority)連携メタ。QUALITY_EVIDENCE_TSA=on のときのみ外部
       時刻証明を試み、タイムアウト/未到達なら status=unavailable(WARN相当)に縮退する。
       既定 off(閉域網・鍵未配備でも生成を止めない)。実鍵/実エンドポイント運用は owner。
       ★ fingerprint には一切影響しない(メタのみ)。"""
    mode = os.environ.get("QUALITY_EVIDENCE_TSA", "off").strip().lower()
    if mode not in ("on", "1", "true"):
        return {"status": "disabled", "algo": "tsa-rfc3161",
                "note": "TSA連携は既定OFF(QUALITY_EVIDENCE_TSA=on で有効化)"}
    tsa_url = os.environ.get("QUALITY_EVIDENCE_TSA_URL", "").strip()
    if not tsa_url:
        return {"status": "unavailable", "algo": "tsa-rfc3161",
                "note": "QUALITY_EVIDENCE_TSA=on だが TSA_URL 未設定=外部時刻証明を取得できず縮退(owner設定待ち)"}
    # best-effort: 短いタイムアウトで RFC3161 風の時刻取得を試みる。失敗は WARN 相当へ縮退。
    try:
        import urllib.request
        body = fingerprint.encode("utf-8")
        req = urllib.request.Request(tsa_url, data=body, method="POST",
                                     headers={"Content-Type": "application/timestamp-query",
                                              "User-Agent": "soloptilink-cert/v1"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            code = getattr(resp, "status", None) or resp.getcode()
            token = resp.read(4096)
        return {"status": "stamped", "algo": "tsa-rfc3161", "tsa_url": tsa_url,
                "http_status": int(code), "token_sha256": _sha256(token.decode("latin-1"))}
    except Exception as e:
        return {"status": "unavailable", "algo": "tsa-rfc3161", "tsa_url": tsa_url,
                "note": "外部TSA未到達(timeout/網閉塞)=WARN縮退・手元検証は継続可能", "reason": str(e)[:120]}


# ==============================================================================
# L10 v2043: self-test — sha256-chain-v1 の発行/検証「対称性」を純メモリで実証
#   検査3軸 (いずれも file/network/project 非依存=高速・冪等):
#     symmetry            : 発行側 gate_pairs_from と検証側 gate_pairs_from_cert が
#                           同一ゲート集合に対し同一 chain/fingerprint を返す。
#     metadata_invariance : traceability/external_ts を足しても fingerprint 不変
#                           (= 検証式の非対称化が起きない=メタ加算の安全性)。
#     tamper_sensitivity  : verdict を1つ書き換えると fingerprint が割れる(改ざん検知が効く)。
#   出力: JSON {self_test, symmetry, metadata_invariance, tamper_sensitivity}, exit 0/1。
# ==============================================================================
def run_self_test():
    version = "v2043-selftest"
    issued = "2026-06-20T00:00:00Z"
    # 合成ゲート集合(順不同で渡し、両経路が同一の昇順正規化で一致することを確認)
    gates = [
        {"name": "PFP-086 実DBログイン", "verdict": "PASS"},
        {"name": "PFP-100 CRUD入力",     "verdict": "PASS"},
        {"name": "PFP-082 透かし",        "verdict": "WARN"},
        {"name": "PFP-125 敵対的検証波",   "verdict": "PASS"},
    ]
    # 発行側経路
    pairs_gen = gate_pairs_from(gates)
    chain_gen, fp_gen = compute_chain(version, issued, pairs_gen)
    # 検証側経路(cert に保存される形 {name, verdict} から再計算)
    cert_gates = [{"name": g["name"], "verdict": g["verdict"]} for g in gates]
    pairs_ver = gate_pairs_from_cert(cert_gates)
    chain_ver, fp_ver = compute_chain(version, issued, pairs_ver)
    symmetry = (chain_gen == chain_ver) and (fp_gen == fp_ver)

    # メタ加算不変性: traceability/external_ts を「足した」cert からでも、fingerprint は
    #   gates+version+issued のみで再計算される=メタは fingerprint に混ざらない。
    cert_with_meta = {
        "version": version, "issued_at": issued, "gates": cert_gates,
        "traceability": {"session_id": "sess-xyz", "role_count": 3, "roles": ["a", "b"]},
        "external_ts": {"status": "stamped", "token_sha256": "deadbeef"},
        "fingerprint": fp_gen,
    }
    pairs_meta = gate_pairs_from_cert(cert_with_meta["gates"])
    _, fp_meta = compute_chain(cert_with_meta["version"], cert_with_meta["issued_at"], pairs_meta)
    metadata_invariance = (fp_meta == fp_gen)

    # 改ざん感度: verdict を1つ書換え→ fingerprint が変わる(検知が効く)
    tampered = [dict(g) for g in cert_gates]
    tampered[0]["verdict"] = "FAIL" if tampered[0]["verdict"] != "FAIL" else "PASS"
    _, fp_tam = compute_chain(version, issued, gate_pairs_from_cert(tampered))
    tamper_sensitivity = (fp_tam != fp_gen)

    # 出所束縛(bound_digest)の改ざん検知: session_id を書換えると bound_digest 再計算が割れる。
    sid_orig, rdg = "sess-real", _sha256("architect|implementer")
    bd_orig = traceability_bound_digest(fp_gen, sid_orig, rdg)
    bd_recompute_clean = traceability_bound_digest(fp_gen, sid_orig, rdg)
    bd_recompute_forged = traceability_bound_digest(fp_gen, "ATTACKER-FORGED", rdg)
    trace_binding = (bd_recompute_clean == bd_orig) and (bd_recompute_forged != bd_orig)

    ok = symmetry and metadata_invariance and tamper_sensitivity and trace_binding
    result = {
        "self_test": "PASS" if ok else "FAIL",
        "algo": "sha256-chain-v1",
        "symmetry": symmetry,
        "metadata_invariance": metadata_invariance,
        "tamper_sensitivity": tamper_sensitivity,
        "trace_binding": trace_binding,
        "fingerprint_sample": fp_gen[:16],
    }
    print(json.dumps(result, ensure_ascii=False))
    return 0 if ok else 1


# ==============================================================================
# レーダーチャート / バー (generate 専用)
# ==============================================================================
def radar_svg(items):
    """実測軸のみのレーダーチャートを純 SVG で描画する (外部依存なし)。"""
    n = len(items)
    cx, cy, R = 320, 235, 158
    W, H = 640, 470

    def pt(i, r):
        ang = math.radians(-90.0 + 360.0 * i / n)
        return (cx + r * math.cos(ang), cy + r * math.sin(ang))

    s = ['<svg viewBox="0 0 %d %d" xmlns="http://www.w3.org/2000/svg" role="img" '
         'aria-label="品質スコアレーダーチャート" style="max-width:640px;width:100%%;height:auto">' % (W, H)]
    for frac in (0.25, 0.5, 0.75, 1.0):
        ring = " ".join("%.1f,%.1f" % pt(i, R * frac) for i in range(n))
        s.append('<polygon points="%s" fill="none" stroke="#cbd5e1" stroke-width="1"/>' % ring)
    for i, (label, score, _full) in enumerate(items):
        x, y = pt(i, R)
        s.append('<line x1="%d" y1="%d" x2="%.1f" y2="%.1f" stroke="#dde3ec" stroke-width="1"/>' % (cx, cy, x, y))
        lx, ly = pt(i, R + 26)
        anchor = "middle"
        if lx < cx - 12:
            anchor = "end"
        elif lx > cx + 12:
            anchor = "start"
        s.append('<text x="%.1f" y="%.1f" text-anchor="%s" font-size="12" fill="#334155">%s</text>'
                 % (lx, ly + 4, anchor, esc(label)))
    poly = " ".join("%.1f,%.1f" % pt(i, R * items[i][1] / 100.0) for i in range(n))
    s.append('<polygon points="%s" fill="rgba(15,118,110,0.22)" stroke="#0f766e" stroke-width="2"/>' % poly)
    for i, (label, score, full) in enumerate(items):
        x, y = pt(i, R * score / 100.0)
        s.append('<circle cx="%.1f" cy="%.1f" r="3.5" fill="#0f766e"><title>%s: %d点</title></circle>'
                 % (x, y, esc(full), score))
    s.append('<text x="%d" y="%.1f" font-size="9" fill="#94a3b8" text-anchor="middle">100</text>' % (cx, cy - R - 4))
    s.append("</svg>")
    return "".join(s)


def bars_html(items):
    """軸が少なくレーダー描画に適さない場合の水平バー表示。"""
    rows = []
    for label, score, full in items:
        rows.append(
            '<div class="barrow"><span class="barlabel" title="%s">%s</span>'
            '<span class="bartrack"><span class="barfill" style="width:%d%%"></span></span>'
            '<span class="barval">%d点</span></div>' % (esc(full), esc(label), score, score)
        )
    return '<div class="bars">%s</div>' % "".join(rows)


# ==============================================================================
# MODE: generate — 品質証明書.html + certificate.json を生成
# ==============================================================================
def run_generate():
    gates, unreadable = collect_gates()
    roles = count_roles()
    pages = collect_pages()
    models = collect_models()

    # ---- ④ 品質スコア (実測ゲート → フレームワーク軸スコア) ----
    axes = [(g["axis"], SCORE[g["verdict"]], g["name"]) for g in gates if g["verdict"] in SCORE]
    overall = int(round(sum(a[1] for a in axes) / len(axes))) if axes else None

    # ---- ★ 証明書サイドカー certificate.json の組み立て (PII なし) ----
    # gates は HTML に使う results の verdict 集合と同じ。名前 + 判定のみ。
    cert_gates = [{"name": g["name"], "verdict": (g["verdict"] if g["verdict"] in ALLOWED_VERDICTS else "NA")}
                  for g in gates]
    pairs = gate_pairs_from(gates)
    hash_chain, fingerprint = compute_chain(ENGINE_VERSION, ISSUED_AT, pairs)
    verify_url = "%s/verify/%s" % (SITE_URL, fingerprint) if SITE_URL else "/verify/%s" % fingerprint

    # 公開検証ページ/サーバ登録 (register) が読む補助メタ。いずれも実測のみから導出する。
    # ※ fingerprint(改ざん検知)はゲート判定 + version + issued_at のみで算出するため、
    #    target_domain / quality_verdict を追加しても改ざん検証 (verify) には一切影響しない。
    # ※ quality_verdict は「品質の総合判定」(合格/条件付き合格/要確認)。証明書の
    #    ライフサイクル状態(valid/revoked)を表すサーバ側 status 列とは別概念なので、
    #    キー名を分けて混同を防ぐ (register は status 列へは流さない)。
    target_domain = detect_target_domain()
    quality_verdict = overall_status(gates)

    # ── L10 v2043: トレーサビリティ + 外部タイムスタンプ(TSA)メタ ──────────────
    # 目的(堀⑦ = IP防衛): 「どのセッションのどの専門ロール群が出力したか」を証明書に
    #   刻み、生成物の出所追跡を可能にする。external_ts は第三者(TSA)による時刻証明。
    # ★ 不変条件: これらは certificate の「メタ」であり、fingerprint(=改ざん検知)の
    #   構成式 compute_chain(version, issued_at, gate_pairs) には一切渡さない。よって
    #   traceability / external_ts を足しても発行/検証の fingerprint は完全一致する
    #   (= 検証式の非対称化を起こさない。self-test の metadata_invariance で実証)。
    traceability = build_traceability(CERT_ID, roles, fingerprint)
    external_ts = build_external_ts(fingerprint)

    certificate = {
        "schema": "soloptilink-cert/v1",
        "cert_id": CERT_ID,
        "version": ENGINE_VERSION,
        "issued_at": ISSUED_AT,
        "target_domain": target_domain,
        "quality_verdict": quality_verdict,
        "gates": cert_gates,
        "evidence": {
            "agent_count": roles,
            "pages": len(pages),
            "models": models,
        },
        "traceability": traceability,
        "external_ts": external_ts,
        "hash_chain": hash_chain,
        "fingerprint": fingerprint,
        "algo": "sha256-chain-v1",
        "verify_url": verify_url,
    }
    # .soloptilink ディレクトリが無ければ作る (generate 単体実行のケースを許容)
    try:
        os.makedirs(SLD, exist_ok=True)
    except OSError:
        pass
    with open(CERT_PATH, "w", encoding="utf-8") as fh:
        json.dump(certificate, fh, ensure_ascii=False, indent=2)

    # ---- HTML 用の日本語表示日時 (issued_at を表示用に整形) ----
    try:
        dt = datetime.datetime.strptime(ISSUED_AT, "%Y-%m-%dT%H:%M:%SZ")
        now_label = dt.strftime("%Y年%m月%d日 %H:%M (UTC)")
        date_label = dt.strftime("%Y年%m月%d日")
    except Exception:
        now_label = ISSUED_AT
        date_label = ISSUED_AT
    fp_short = fingerprint[:16]

    # ---- プロジェクト表示名 (HTML 表紙用。certificate.json には入れない) ----
    proj_name = os.path.basename(ROOT)
    pkg_path = os.path.join(ROOT, "package.json")
    if os.path.isfile(pkg_path):
        try:
            with open(pkg_path, encoding="utf-8") as fh:
                nm = json.load(fh).get("name")
            if isinstance(nm, str) and nm.strip():
                proj_name = nm.strip()
        except Exception:
            pass

    CSS = """
:root{--navy:#1b2a4a;--teal:#0f766e;--ink:#1f2937;--line:#d8dee9;--bg:#eef1f6}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);line-height:1.65;
  font-family:"Hiragino Sans","Hiragino Kaku Gothic ProN","Yu Gothic UI","Meiryo",sans-serif}
.sheet{max-width:880px;margin:24px auto;background:#fff;box-shadow:0 2px 14px rgba(27,42,74,.12)}
.cover{background:linear-gradient(135deg,#1b2a4a 0%,#27406e 100%);color:#fff;padding:38px 44px 32px}
.cover .en{letter-spacing:.22em;font-size:11px;color:#9fb3d9;text-transform:uppercase}
h1{margin:6px 0 2px;font-size:30px;letter-spacing:.14em;font-weight:700}
.proj{font-size:16px;color:#dbe5f5;margin-top:12px}
.issued{font-size:12px;color:#9fb3d9;margin-top:2px}
.body{padding:30px 44px 8px}
.cards{display:flex;gap:12px;flex-wrap:wrap;margin:0 0 8px}
.card{flex:1 1 150px;border:1px solid var(--line);border-top:3px solid var(--teal);
  border-radius:6px;padding:12px 14px;text-align:center;background:#fbfcfe}
.card .num{font-size:26px;font-weight:700;color:var(--navy)}
.card .lbl{font-size:11px;color:#64748b;margin-top:2px}
h2{font-size:16px;color:var(--navy);border-left:4px solid var(--teal);padding-left:10px;margin:32px 0 12px}
table{width:100%;border-collapse:collapse;font-size:12.5px}
th{background:#f1f4f9;color:#334155;text-align:left;padding:7px 10px;border-bottom:2px solid var(--navy);font-size:11.5px}
td{padding:7px 10px;border-bottom:1px solid var(--line);vertical-align:top}
.gname{font-weight:600;color:var(--navy)}
.gdesc{font-size:10.5px;color:#8a94a6;margin-top:1px}
.badge{display:inline-block;padding:1px 10px;border-radius:999px;font-size:11px;font-weight:700;white-space:nowrap}
.b-pass{background:#e2f3ef;color:#0f766e}.b-warn{background:#fdf1de;color:#b45309}
.b-fail{background:#fbe7e7;color:#b91c1c}.b-na{background:#eef0f3;color:#6b7280}
.note{font-size:11px;color:#8a94a6;margin-top:8px}
.rolebox{display:flex;align-items:center;gap:20px;border:1px solid var(--line);border-radius:6px;
  padding:16px 22px;background:#fbfcfe}
.rolenum{font-size:42px;font-weight:800;color:var(--teal);line-height:1}
.roletext{font-size:12.5px;color:#475569}
.chartwrap{text-align:center;padding:6px 0 0}
.scoreline{font-size:13px;color:#334155;margin-top:6px}
.scoreline b{font-size:20px;color:var(--teal)}
.bars{display:flex;flex-direction:column;gap:8px;max-width:560px;margin:8px auto 0}
.barrow{display:flex;align-items:center;gap:10px;font-size:12px}
.barlabel{flex:0 0 110px;text-align:right;color:#334155}
.bartrack{flex:1;background:#eef0f3;border-radius:999px;height:12px;overflow:hidden}
.barfill{display:block;height:100%;background:#0f766e;border-radius:999px}
.barval{flex:0 0 42px;color:#0f766e;font-weight:700}
.empty{border:1px dashed var(--line);border-radius:6px;padding:18px 20px;font-size:12.5px;color:#64748b;background:#fbfcfe}
.seal{display:flex;align-items:center;gap:18px;border:1px solid var(--line);border-radius:8px;
  padding:16px 20px;background:#fbfcfe;margin-top:10px}
.qr{flex:0 0 auto}
.sealtext{font-size:12px;color:#475569}
.sealtext .fp{font-family:"SFMono-Regular",Consolas,"Liberation Mono",Menlo,monospace;
  font-size:13px;color:var(--navy);font-weight:700;letter-spacing:.04em}
.sealtext .vurl{font-family:"SFMono-Regular",Consolas,"Liberation Mono",Menlo,monospace;
  font-size:11px;color:#0f766e;word-break:break-all}
footer{border-top:1px solid var(--line);margin-top:24px;padding:14px 44px 26px;font-size:11px;color:#8a94a6;
  display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px}
.brand{font-weight:700;color:var(--navy)}
@media print{
  body{background:#fff}
  .sheet{box-shadow:none;margin:0;max-width:none}
  @page{size:A4;margin:13mm}
  h2{page-break-after:avoid}
  tr,.cards,.rolebox,.chartwrap,.seal{page-break-inside:avoid}
}
"""

    H = []
    H.append("<!DOCTYPE html>")
    H.append('<html lang="ja"><head><meta charset="utf-8">')
    H.append('<meta name="viewport" content="width=device-width,initial-scale=1">')
    H.append("<title>品質証明書 — %s</title>" % esc(proj_name))
    H.append("<style>%s</style></head><body>" % CSS)
    H.append('<div class="sheet">')

    # --- 表紙ヘッダ ---
    H.append('<div class="cover">')
    H.append('<div class="en">Quality Evidence Report</div>')
    H.append("<h1>品質証明書</h1>")
    H.append('<div class="proj">対象システム: %s</div>' % esc(proj_name))
    # 対象業種・総合判定はいずれも実測記録由来 (target_domain=登録済DBL名 / quality_verdict=実ゲート判定)。
    if target_domain:
        H.append('<div class="proj">対象業種: %s</div>' % esc(target_domain))
    if quality_verdict:
        H.append('<div class="proj">総合判定: <b>%s</b></div>' % esc(quality_verdict))
    H.append('<div class="issued">発行日: %s</div>' % esc(date_label))
    H.append("</div>")

    H.append('<div class="body">')

    # --- サマリカード (実在するデータのみ) ---
    cards = []
    if gates:
        npass = sum(1 for g in gates if g["verdict"] == "PASS")
        cards.append((str(len(gates)), "実施済み品質ゲート (うち合格 %d)" % npass))
    if overall is not None:
        cards.append((str(overall), "総合品質スコア (実測軸平均 / 100点)"))
    if roles > 0:
        cards.append((str(roles), "実起動専門ロール数"))
    if pages:
        cards.append((str(len(pages)), "実装画面数"))
    if cards:
        H.append('<div class="cards">')
        for num, lbl in cards:
            H.append('<div class="card"><div class="num">%s</div><div class="lbl">%s</div></div>' % (esc(num), esc(lbl)))
        H.append("</div>")

    if not gates and roles == 0 and not pages:
        H.append('<div class="empty">本プロジェクトには品質検証の実測データが見つかりませんでした。'
                 "品質ゲートの実行後に本証明書を再生成してください。</div>")

    # --- ① 品質ゲート検証結果 ---
    if gates:
        H.append("<h2>1. 品質ゲート検証結果</h2>")
        H.append("<table><thead><tr><th style='width:38%'>検証項目</th><th style='width:14%'>判定</th><th>要点 (実測値)</th></tr></thead><tbody>")
        for g in gates:
            name_cell = '<div class="gname">%s</div>' % esc(g["name"])
            if g["desc"]:
                name_cell += '<div class="gdesc">%s</div>' % esc(g["desc"])
            badge = '<span class="badge %s">%s</span>' % (VERDICT_CLS[g["verdict"]], VERDICT_JA[g["verdict"]])
            H.append("<tr><td>%s</td><td>%s</td><td>%s</td></tr>" % (name_cell, badge, esc(g["summary"]) or ""))
        H.append("</tbody></table>")
        note = "上記はプロジェクト内に保存された品質ゲートの実測記録のみを集計したものです。"
        if unreadable:
            note += " 読み取れなかった記録 %d 件は表示から除外しています。" % unreadable
        H.append('<div class="note">%s</div>' % esc(note))

    # --- ② 実起動専門ロール ---
    if roles > 0:
        H.append("<h2>2. 専門ロールによる構築体制</h2>")
        H.append('<div class="rolebox"><div class="rolenum">%d</div>' % roles)
        H.append('<div class="roletext">本システムの構築にあたり、<b>%d 種の専門ロール</b>'
                 "(設計・実装・テスト・レビュー・セキュリティ等) が実際に起動し、"
                 "それぞれの成果証跡がプロジェクト内に保存されています。"
                 "この数値は証跡ファイルの実数から算出しています。</div></div>" % roles)

    # --- ③ 画面一覧 ---
    if pages:
        sec_no = 3 if roles > 0 else 2
        H.append("<h2>%d. 実装画面一覧 (全 %d 画面)</h2>" % (sec_no, len(pages)))
        H.append("<table><thead><tr><th style='width:46%'>画面 (URL パス)</th><th>画面名</th></tr></thead><tbody>")
        LIMIT = 150
        for route, label in pages[:LIMIT]:
            H.append("<tr><td><code>%s</code></td><td>%s</td></tr>" % (esc(route), esc(label)))
        H.append("</tbody></table>")
        if len(pages) > LIMIT:
            H.append('<div class="note">ほか %d 画面 (誌面の都合により省略)</div>' % (len(pages) - LIMIT))

    # --- ④ 品質スコア総覧 (レーダーチャート) ---
    if axes:
        sec_no = 1 + (1 if gates else 0) + (1 if roles > 0 else 0) + (1 if pages else 0)
        H.append("<h2>%d. 品質スコア総覧</h2>" % sec_no)
        H.append('<div class="chartwrap">')
        chart_items = [(a[0], a[1], a[2]) for a in axes]
        if len(chart_items) >= 3:
            H.append(radar_svg(chart_items))
        else:
            H.append(bars_html(chart_items))
        if overall is not None:
            H.append('<div class="scoreline">総合品質スコア <b>%d</b> / 100 点 (実測 %d 軸の平均)</div>'
                     % (overall, len(axes)))
        H.append("</div>")
        H.append('<div class="note">品質フレームワーク全34軸 (標準29軸+新5軸) のうち、'
                 "本プロジェクトで実際に測定された %d 軸のみを表示しています。"
                 "スコアは各ゲートの実判定 (合格=100 / 注意=60 / 不合格=25 / 重大=10) に基づきます。</div>" % len(axes))

    # --- ⑤ 真正性シール (フィンガープリント + 検証URL + QR) ---
    sec_no = 1 + (1 if gates else 0) + (1 if roles > 0 else 0) + (1 if pages else 0) + (1 if axes else 0)
    H.append("<h2>%d. 真正性 (改ざん検証)</h2>" % sec_no)
    H.append('<div class="seal">')
    H.append('<div class="qr">%s</div>' % qr_svg(verify_url))
    H.append('<div class="sealtext">')
    H.append('フィンガープリント: <span class="fp">%s</span><br>' % esc(fp_short))
    H.append('発行日時: %s<br>' % esc(now_label))
    H.append('検証URL: <span class="vurl">%s</span><br>' % esc(verify_url))
    H.append('<span style="display:inline-block;margin-top:6px;color:#475569">'
             'この証明書は SoloptiLink で発行・検証できます。'
             '記載された判定が後から書き換えられていないことを、上記URLまたはお手元で照合できます。</span>')
    H.append('</div></div>')

    H.append("</div>")  # .body

    # --- フッタ ---
    H.append("<footer>")
    H.append('<span>生成日時: %s ／ フィンガープリント %s</span>' % (esc(now_label), esc(fp_short)))
    H.append('<span>本証明書は <span class="brand">SoloptiLinkAI %s</span> が実測データのみから自動生成しました。</span>'
             % esc(ENGINE_VERSION))
    H.append("</footer>")
    H.append("</div></body></html>")

    with open(OUT, "w", encoding="utf-8") as fh:
        fh.write("\n".join(H))

    print("✅ 品質証明書を生成しました: %s" % OUT)
    print("   証明書サイドカー: %s" % CERT_PATH)
    print("   品質ゲート %d 項目 / 専門ロール %d / 画面 %d / スコア軸 %d" % (len(gates), roles, len(pages), len(axes)))
    print("   フィンガープリント: %s" % fingerprint)
    return 0


# ==============================================================================
# 簡易 QR 風コード (外部依存なし) — 検証URLを視認できる装飾コード。
# 真の QR 規格ではなく、URL を SHA で散らした「指紋ドット」+ URL テキスト併記。
# (外部 QR ライブラリ/CDN を一切使わない要件のため、決定論的ドット絵で代替する)
# ==============================================================================
def qr_svg(text):
    digest = hashlib.sha256(text.encode("utf-8")).digest()
    # 21x21 のドットマトリクスを digest から決定論的に生成
    n = 21
    cell = 5
    pad = 6
    size = n * cell + pad * 2
    bits = []
    # digest を繰り返してビット列を作る
    src = (digest * ((n * n) // len(digest) // 8 + 2))
    for b in src:
        for k in range(8):
            bits.append((b >> k) & 1)
    s = ['<svg viewBox="0 0 %d %d" xmlns="http://www.w3.org/2000/svg" role="img" '
         'aria-label="検証コード" width="110" height="110">' % (size, size)]
    s.append('<rect x="0" y="0" width="%d" height="%d" fill="#ffffff" stroke="#cbd5e1"/>' % (size, size))

    def finder(ox, oy):
        out = []
        out.append('<rect x="%d" y="%d" width="%d" height="%d" fill="#1b2a4a"/>'
                   % (pad + ox * cell, pad + oy * cell, 7 * cell, 7 * cell))
        out.append('<rect x="%d" y="%d" width="%d" height="%d" fill="#ffffff"/>'
                   % (pad + (ox + 1) * cell, pad + (oy + 1) * cell, 5 * cell, 5 * cell))
        out.append('<rect x="%d" y="%d" width="%d" height="%d" fill="#1b2a4a"/>'
                   % (pad + (ox + 2) * cell, pad + (oy + 2) * cell, 3 * cell, 3 * cell))
        return "".join(out)

    def in_finder(x, y):
        # 3 つの位置検出パターン領域 (左上/右上/左下) はデータドットを描かない
        return ((x < 8 and y < 8) or (x >= n - 8 and y < 8) or (x < 8 and y >= n - 8))

    idx = 0
    for y in range(n):
        for x in range(n):
            if in_finder(x, y):
                continue
            bit = bits[idx % len(bits)]
            idx += 1
            if bit:
                s.append('<rect x="%d" y="%d" width="%d" height="%d" fill="#0f766e"/>'
                         % (pad + x * cell, pad + y * cell, cell, cell))
    s.append(finder(0, 0))
    s.append(finder(n - 7, 0))
    s.append(finder(0, n - 7))
    s.append("</svg>")
    return "".join(s)


# ==============================================================================
# MODE: verify — certificate.json と現在の実測記録から fingerprint を再計算し照合
# 一致=VERIFIED (exit0) / 不一致=TAMPERED (exit1)
# ==============================================================================
def run_verify():
    if not os.path.isfile(CERT_PATH):
        print("❌ 証明書 (certificate.json) が見つかりません。先に generate を実行してください。")
        print("   想定パス: %s" % CERT_PATH)
        return 1
    try:
        with open(CERT_PATH, encoding="utf-8") as fh:
            cert = json.load(fh)
    except Exception as e:
        print("❌ 証明書の読み込みに失敗しました (破損の可能性): %s" % e)
        return 1
    if not isinstance(cert, dict) or cert.get("schema") != "soloptilink-cert/v1":
        print("❌ 証明書の形式が不正です (schema 不一致)。")
        return 1

    saved_fp = str(cert.get("fingerprint", ""))
    saved_version = str(cert.get("version", ""))
    saved_issued = str(cert.get("issued_at", ""))
    saved_algo = str(cert.get("algo", ""))
    saved_gates = cert.get("gates", [])
    saved_chain = cert.get("hash_chain", [])

    if saved_algo != "sha256-chain-v1":
        print("⚠ 未知のハッシュ方式です (algo=%s)。この検証器は sha256-chain-v1 のみ対応します。" % saved_algo)
        return 1

    # ★ 内部整合性検査 (v2042 堅牢化): 証明書「自身」が記録する判定一覧 (saved_gates) から
    #   連鎖を再計算し、保存された fingerprint / hash_chain と突合する。これにより、発行時の
    #   実測記録 (results.json) が手元に無くても、証明書を直接いじった素朴な改ざん
    #     (a) gates の verdict だけ書換え、fingerprint を再計算し忘れる
    #     (b) hash_chain の中間ノードを差し替える
    #   を検出できる (= 途中改ざん検出)。fingerprint の構成式 (gate+version+issued_at) と
    #   compute_chain は一切変更していないため、正規に発行された証明書は必ず一致する。
    internal_pairs = gate_pairs_from_cert(saved_gates)
    internal_chain, internal_fp = compute_chain(saved_version, saved_issued, internal_pairs)
    internal_ok = True
    internal_reason = ""
    if saved_fp and internal_fp != saved_fp:
        internal_ok = False
        internal_reason = ("証明書内の判定一覧から再計算した指紋が、保存された指紋と一致しません "
                           "(判定が書き換えられた後に指紋が再計算されていない可能性)")
    elif isinstance(saved_chain, list) and saved_chain:
        if [str(x) for x in saved_chain] != internal_chain:
            internal_ok = False
            internal_reason = ("ハッシュ連鎖 (hash_chain) の中間ノードが、証明書の判定一覧から "
                               "再計算した連鎖と一致しません (連鎖の途中差し替えの可能性)")

    # 現在の実測記録から、発行時と同じ条件 (同 version / 同 issued_at) で再計算する。
    gates, _unreadable = collect_gates()
    pairs = gate_pairs_from(gates)
    _chain, recomputed_fp = compute_chain(saved_version, saved_issued, pairs)
    results_ok = bool(saved_fp) and recomputed_fp == saved_fp

    print("──────────────────────────────────────────")
    print(" SoloptiLink 品質証明書 — 真正性検証")
    print("──────────────────────────────────────────")
    print(" 証明書ID      : %s" % cert.get("cert_id", "(なし)"))
    print(" 発行版        : %s" % saved_version)
    print(" 発行日時      : %s" % saved_issued)
    print(" 記録ゲート数  : %d 件 (証明書) / %d 件 (現在の実測)" % (len(saved_gates), len(gates)))
    print(" 保存指紋      : %s" % saved_fp)
    print(" 内部再計算指紋: %s" % internal_fp)
    print(" 実測再計算指紋: %s" % recomputed_fp)
    print(" 内部整合      : %s" % ("OK" if internal_ok else "NG"))
    print("──────────────────────────────────────────")

    if internal_ok and results_ok:
        print("✅ VERIFIED — 実測・未改ざん")
        print("   証明書に記録された品質ゲート判定は内部的に整合し、現在の実測記録とも完全に一致します。")
        print("   発行後に判定や連鎖が書き換えられた形跡はありません。")
        return 0

    # v2054.6 (PFP-181): 「改ざん」と「発行後に実測が変わった」を混同しない。
    #   証明書自身の内部整合が取れている (=書き換えられていない) のに指紋が合わない場合、
    #   それは改ざんではなく、再検査・機構更新・追加開発によって現在の実測が動いただけ。
    #   これを「改ざん」と表示すると、正当な証明書を持つお客様に不当な疑いをかけることになる。
    if internal_ok and not results_ok:
        print("⚠ STALE — 証明書は未改ざんですが、発行後に実測記録が変わっています")
        print("   証明書そのものの内部整合性は保たれており、書き換えられた形跡はありません。")
        print("   発行時と現在で品質ゲートの判定内容が異なります")
        print("   (再検査を行った / 検査機構が更新された / 追加開発を行った、のいずれか)。")
        print("   → 最新の状態で証明書を再発行してください。")
        return 1

    print("❌ TAMPERED — 改ざんを検知")
    if not internal_ok:
        # 証明書そのものの内部不整合 (現在の実測記録が無くても確定する改ざん検知)
        print("   証明書の内部整合性検査に失敗しました:")
        print("   ・%s" % internal_reason)
    if not results_ok:
        print("   証明書の指紋と、現在の実測記録から再計算した指紋が一致しません。")
        print("   いずれかの品質ゲート判定が発行後に変更された可能性があります。")
        # どのゲートが変わったかのヒント (PII を含まない判定名のみ)
        saved_map = {}
        for g in saved_gates:
            if isinstance(g, dict):
                saved_map[str(g.get("name"))] = str(g.get("verdict"))
        now_map = {g["name"]: g["verdict"] for g in gates}
        diffs = []
        for name in sorted(set(saved_map) | set(now_map)):
            a = saved_map.get(name)
            b = now_map.get(name)
            if a != b:
                diffs.append("   ・%s: 証明書=%s → 現在=%s" % (name, a or "(なし)", b or "(なし)"))
        if diffs:
            print("   相違のあった検証項目:")
            for line in diffs[:20]:
                print(line)
    return 1


# ==============================================================================
# MODE: register — certificate.json の発行記録 (PIIなし) をサーバへ best-effort POST
# 失敗は黙殺し常に exit0。urllib (stdlib) のみ使用。
# ==============================================================================
def run_register():
    if not os.path.isfile(CERT_PATH):
        print("ℹ 証明書 (certificate.json) が未生成のため、登録をスキップしました。")
        return 0
    try:
        with open(CERT_PATH, encoding="utf-8") as fh:
            cert = json.load(fh)
    except Exception:
        print("ℹ 証明書を読み込めなかったため、登録をスキップしました。")
        return 0
    if not isinstance(cert, dict):
        print("ℹ 証明書形式が不正のため、登録をスキップしました。")
        return 0

    gates = cert.get("gates", [])
    _glist = gates if isinstance(gates, list) else []
    # 2026-06-16 ds-3 是正: サーバ/UI が読むのは gates_total / gates_passed だが、旧版は gates_count のみ
    # 送っていたため UI「ゲート通過」が常に '-' 表示だった。verdict から PASS 数を算出して両キーを送る。
    # target_domain も server Body が期待するため cert から添付する(欠落時 null)。
    _gpassed = sum(
        1 for g in _glist
        if isinstance(g, dict) and str(g.get("verdict", "")).strip().upper() in ("PASS", "OK", "GREEN")
    )
    payload = {
        "cert_id": cert.get("cert_id"),
        "version": cert.get("version"),
        "issued_at": cert.get("issued_at"),
        "fingerprint": cert.get("fingerprint"),
        "algo": cert.get("algo"),
        "target_domain": cert.get("target_domain"),
        # 注: 品質の総合判定(quality_verdict)はサーバ status 列(valid/revoked のライフサイクル)
        #     とは別概念のため、status 列へは送らない(admin の「有効数」集計を壊さないため)。
        #     品質判定は gates_passed/gates_total と手元の品質証明書 HTML で確認できる。
        "gates_count": len(_glist),
        "gates_total": len(_glist),
        "gates_passed": _gpassed,
        "evidence": cert.get("evidence", {}),
    }
    if not SITE_URL:
        print("ℹ 送信先が未設定のため、登録をスキップしました (証明書は手元で検証可能です)。")
        return 0
    url = "%s/api/v1/certificates" % SITE_URL

    import urllib.request
    import urllib.error
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url, data=body, method="POST",
        headers={"Content-Type": "application/json", "User-Agent": "soloptilink-cert/v1"},
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            code = getattr(resp, "status", None) or resp.getcode()
            if 200 <= int(code) < 300:
                print("✅ 発行記録をサーバに登録しました (真正性照会が可能になりました)。")
            else:
                print("ℹ 発行記録の登録は完了しませんでした (応答 %s)。証明書は手元で検証可能です。" % code)
    except Exception:
        # best-effort: ネットワーク/サーバ未対応でも失敗を黙殺し成功終了する
        print("ℹ 発行記録の登録はスキップされました (送信不可)。証明書は手元で検証可能です。")
    return 0


# ==============================================================================
# MODE: verify-internal — 第三者独立検証(実測記録 results.json を持たない者向け)
#   通常の verify は「証明書内部の整合(internal_ok)」+「現在の実測記録との一致(results_ok)」の
#   両方を要求するため、原本プロジェクトを持たない第三者が verify すると results が空で TAMPERED に
#   なる。verify-internal は証明書「自身」が記録する判定一覧から連鎖を再計算し、保存 fingerprint /
#   hash_chain と突合する=実測記録なしでも改ざん(verdict書換/連鎖差替)を検知できる。
#   さらに traceability.bound_digest を再計算し、出所メタが fingerprint へ束縛されているかを点検する。
#   → sha256-chain-v1 の「第三者独立検証可能化」を CLI 単体で成立させる(goal2)。
#   一致=VERIFIED-INTERNAL(exit0) / 不一致=TAMPERED-INTERNAL(exit1)。
# ==============================================================================
def run_verify_internal():
    if not os.path.isfile(CERT_PATH):
        print("❌ 証明書 (certificate.json) が見つかりません。")
        return 1
    try:
        with open(CERT_PATH, encoding="utf-8") as fh:
            cert = json.load(fh)
    except Exception as e:
        print("❌ 証明書の読み込みに失敗しました: %s" % e)
        return 1
    if not isinstance(cert, dict) or cert.get("schema") != "soloptilink-cert/v1":
        print("❌ 証明書の形式が不正です (schema 不一致)。")
        return 1
    if str(cert.get("algo", "")) != "sha256-chain-v1":
        print("⚠ 未知のハッシュ方式です。この検証器は sha256-chain-v1 のみ対応します。")
        return 1
    saved_fp = str(cert.get("fingerprint", ""))
    saved_version = str(cert.get("version", ""))
    saved_issued = str(cert.get("issued_at", ""))
    saved_chain = cert.get("hash_chain", [])
    pairs = gate_pairs_from_cert(cert.get("gates", []))
    chain, fp = compute_chain(saved_version, saved_issued, pairs)
    ok = True
    reasons = []
    if saved_fp and fp != saved_fp:
        ok = False
        reasons.append("証明書内の判定一覧から再計算した指紋が保存指紋と不一致(判定の書換え)")
    if isinstance(saved_chain, list) and saved_chain and [str(x) for x in saved_chain] != chain:
        ok = False
        reasons.append("ハッシュ連鎖の中間ノードが再計算と不一致(連鎖の途中差替え)")
    # 出所メタの連鎖束縛(tamper-evident)。秘密鍵不要で「session_id 書換/別cert流用」を検知。
    trace_note = "traceability なし"
    t = cert.get("traceability")
    if isinstance(t, dict) and t.get("bound_digest"):
        expect = traceability_bound_digest(saved_fp, str(t.get("session_id", "")), str(t.get("roles_digest", "")))
        if expect == str(t.get("bound_digest")):
            trace_note = "traceability は fingerprint へ束縛 整合(session_id/role 改変なし)"
        else:
            trace_note = "⚠ traceability.bound_digest 不一致(session_id/role が改変された可能性)"
    if ok:
        print("✅ VERIFIED-INTERNAL — 証明書の内部連鎖整合を確認(実測記録なしで独立検証可能)。")
        print("   %s" % trace_note)
        return 0
    else:
        print("❌ TAMPERED-INTERNAL — 内部連鎖に改ざんの形跡:")
        for r in reasons:
            print("   - %s" % r)
        return 1


# ==============================================================================
# ディスパッチ
# ==============================================================================
if MODE == "generate":
    sys.exit(run_generate())
elif MODE == "verify":
    sys.exit(run_verify())
elif MODE == "verify-internal":
    sys.exit(run_verify_internal())
elif MODE == "register":
    sys.exit(run_register())
elif MODE == "self-test":
    sys.exit(run_self_test())
else:
    print("❌ 不明なモード: %s" % MODE, file=sys.stderr)
    sys.exit(2)
PYEOF
rc=$?

# generate のときのみ「生成失敗」を設定エラー扱いにする。
# verify は exit1 (TAMPERED) を正常な検知結果として返すため、ここで握りつぶさない。
if [[ "$CMD" == "generate" && $rc -ne 0 ]]; then
    echo "❌ 品質証明書の生成に失敗しました (exit=$rc)" >&2
    exit "$rc"
fi

# ============================================================================
# [L19] warranty 連携フック (opt-in・append-only・PFP-120 不可侵契約を一切変更しない)
# ----------------------------------------------------------------------------
# 不変条件(明文化): 改ざん耐性 保証書(Warranty)の保証範囲は、本ツールが certificate.json
#   に封緘した「実測ゲート判定(gates)」のみから導出する(results.json に無いゲートを保証
#   範囲に書かない=保証の水増し禁止)。warranty 層は certificate.json を read-only でしか
#   参照せず、fingerprint 連鎖式(sha256-chain-v1)・6サブコマンド契約は一切変更しない
#   (本フックは別ファイル lib/warranty/* を起動するだけ)。
# 既定 OFF: 環境変数 ENABLE_WARRANTY_ISSUER=1 のときのみ generate 成功後に保証書を発行する。
# best-effort: warranty 発行が失敗しても generate の rc(=$rc) には一切影響させない。
if [[ "$CMD" == "generate" && $rc -eq 0 && "${ENABLE_WARRANTY_ISSUER:-0}" == "1" ]]; then
    _w_runner="$HOME/.soloptilink/lib/warranty/run-warranty.sh"
    if [[ -x "$_w_runner" ]]; then
        "$_w_runner" issue "$PROJECT_DIR" \
            ${WARRANTY_DELIVERY_DATE:+--delivery="$WARRANTY_DELIVERY_DATE"} \
            ${WARRANTY_DOMAIN:+--domain="$WARRANTY_DOMAIN"} >/dev/null 2>&1 || true
    fi
fi

exit "$rc"
