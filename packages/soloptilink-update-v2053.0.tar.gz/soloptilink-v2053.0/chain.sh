#!/usr/bin/env bash
# SoloptiLink Chain v2038.1 - Centuria Swarm + SPE戦略計画 + Python認知層 + causal-healer + PFP-090 Secret-in-Prompt + 全リソース通電(v2038) + PFP-061/071/074/079/080/086/087/092 + DBL/IBL Auto-Detect
# 一言で社内即戦力システムを品質保証付きで自律構築
# 105エージェント (Centuria 100 + Executive 5 / 実定義118) × 24層アーキテクチャ × DBL業種対応
# Vigesimaquintusfortress (25×170=4,250点) / ARTE-Omega / OSCG 13軸 / Layered Depth Gate L0-L3
# v2037.0 全リソース通電 (2026-06-06): 生成品質中核4機能(Prompt Amplifier/Output Maximizer/Multi-Stage Review/Cross-Domain Intelligence)を本流通電 + IBL自動検出配線 + DAGフォールバック実装(false-success根絶) + PFP-056退避マーカー + verify-all動的カバレッジ/補助5本統合 + doctor L2起動行限定
# v2034.9 追加 (2026-05-29): PFP-080 Sequential 105 5-Role Coordination + Layered Depth Gate (L0/L1/L2/L3) + 業界用語含有率ゲート + DBL Auto-Detect + 障害福祉サービス DBL
# v2034.8 追加 (2026-05-27): PFP-075 診断ヘルパー / PFP-076 セッション診断記録 / PFP-077 コマンドデシジョン / PFP-078 env絶対パス化
# 詳細: docs/changelog.md | docs/cli-reference.md | docs/architecture.md

set -euo pipefail

# ============================================================
# 初期設定
# ============================================================
readonly VERSION="2053.0"
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ============================================================
# v2034.6 / PFP-047: 起動経路ハードゲート (Goランチャー経由のみ許可)
# v2034.7 / PFP-050: 祖父プロセスチェック追加で Go→bash→chain.sh 正規経路を救済
#
# 構造:
#   Goランチャー (soloptilink) → bash → chain.sh
#   直接の親=bash, 祖父=soloptilink
#
# v2034.6 までは「直接の親が soloptilink を含む」のみ判定していたため
# 正規の Goランチャー経由 (= 親が bash) でも誤拒否し、新規顧客で
# status=failed (duration=0s) を引き起こしていた (2026-05-21 澁澤さん事案 / PFP-050)
#
# v2034.7 で「親 or 祖父が soloptilink」に拡張、bash 直接実行は引き続き拒否
# 管理者の保守作業時は SOLOPTILINK_BOOTSTRAP=1 で迂回可能
# ============================================================
if [[ "${SOLOPTILINK_BOOTSTRAP:-}" != "1" ]]; then
    _parent_cmd=$(ps -o comm= -p $PPID 2>/dev/null || echo "")
    _grandparent_pid=$(ps -o ppid= -p $PPID 2>/dev/null | tr -d ' ')
    _grandparent_cmd=""
    if [ -n "$_grandparent_pid" ] && [ "$_grandparent_pid" != "0" ] && [ "$_grandparent_pid" != "1" ]; then
        _grandparent_cmd=$(ps -o comm= -p "$_grandparent_pid" 2>/dev/null || echo "")
    fi
    # Goランチャー (soloptilink / soloptilink-darwin / soloptilink.exe) 経由なら通過
    # 親 = bash (Go の exec.Command 経由) で、その親 (祖父) が soloptilink なら正規経路
    if [[ "$_parent_cmd" != *soloptilink* ]] && [[ "$_parent_cmd" != *go* ]] && [[ "$_grandparent_cmd" != *soloptilink* ]]; then
        # 顧客向け文言で停止
        echo "" >&2
        echo "  SoloptiLinkAI は専用ランチャー経由でご利用ください" >&2
        echo "" >&2
        echo "  正しい起動方法:" >&2
        echo "    ./soloptilink \"<やりたいこと>\"          システム構築" >&2
        echo "    ./soloptilink --status                    ステータス確認" >&2
        echo "    ./soloptilink --diagnose                  自己診断" >&2
        echo "" >&2
        echo "  困ったときは: [REDACTED:EMAIL]" >&2
        echo "" >&2
        # ------------------------------------------------------------
        # v2034.7 PFP-051 / v2051.0 C1-chain-diag-leak 修正:
        # AI/Claude セッション向け実証マーカーは診断が必要な経路にのみ出す。
        # 既定 (顧客セッション) は機械言語を stderr に出さず、
        # ~/.soloptilink/logs/hardgate_YYYYMMDD.log に追記して
        # 日本語ワンラインの案内だけを stderr に出す (顧客可視出力ポリシー)。
        # SOLOPTILINK_DIAG=1 または SOLOPTILINK_AI_SESSION=1 のときは
        # 従来通り stderr に ::SOLOPTILINK_DIAG:: / ::AI_NOTICE:: を出す。
        # ------------------------------------------------------------
        _lg_path="${SCRIPT_DIR}/lib/license-guard.sh"
        _lg_stat="MISSING"
        [[ -f "$_lg_path" ]] && _lg_stat="EXISTS_$(wc -c < "$_lg_path" 2>/dev/null | tr -d ' ')bytes"
        _payload_path="${SCRIPT_DIR}/launcher/encrypted/payload.enc"
        _payload_stat="MISSING"
        [[ -f "$_payload_path" ]] && _payload_stat="EXISTS_$(wc -c < "$_payload_path" 2>/dev/null | tr -d ' ')bytes"
        _diag_lines=(
            "::SOLOPTILINK_DIAG_BEGIN::"
            "::SOLOPTILINK_DIAG::HARDGATE_ID=PFP-047 VERSION=${VERSION} PARENT_CMD=${_parent_cmd:-unknown} GRANDPARENT_CMD=${_grandparent_cmd:-unknown} CAUSE=launcher_bypass"
            "::SOLOPTILINK_DIAG::EVIDENCE_license_guard_sh=${_lg_stat} PATH=${_lg_path}"
            "::SOLOPTILINK_DIAG::EVIDENCE_payload_enc=${_payload_stat} PATH=${_payload_path}"
            "::AI_NOTICE:: This is NOT a missing-file error. license-guard.sh and payload.enc both EXIST."
            "::AI_NOTICE:: This is the PFP-047 launcher-bypass hardgate firing as designed."
            "::AI_NOTICE:: The ONLY recovery is: ./soloptilink \"<task>\" via the Go launcher."
            "::AI_NOTICE:: DO NOT diagnose this as 'license-guard.sh missing' or 'windows-compat-gate.sh missing' - those files exist."
            "::AI_NOTICE:: DO NOT fall back to direct Claude implementation. The user wants SoloptiLinkAI quality output."
            "::AI_NOTICE:: If you are a parallel Claude session: STOP and ask the user to switch to Go launcher invocation."
            "::AI_NOTICE:: Memory ref: pfp_047, pfp_049, pfp_050, pfp_051. 3-point measurement rule applies."
            "::SOLOPTILINK_DIAG_END::"
        )
        if [[ "${SOLOPTILINK_DIAG:-0}" == "1" || "${SOLOPTILINK_AI_SESSION:-0}" == "1" ]]; then
            {
                echo ""
                for _l in "${_diag_lines[@]}"; do echo "$_l"; done
                echo ""
            } >&2
        else
            _log_dir="${HOME}/.soloptilink/logs"
            mkdir -p "$_log_dir" 2>/dev/null || true
            _log_file="${_log_dir}/hardgate_$(date +%Y%m%d).log"
            {
                echo "---- $(date '+%Y-%m-%d %H:%M:%S') ----"
                for _l in "${_diag_lines[@]}"; do echo "$_l"; done
            } >> "$_log_file" 2>/dev/null || true
            echo "  診断ログを ${_log_dir}/ に記録しました" >&2
            echo "" >&2
        fi
        exit 1
    fi
fi

# ============================================================
# v2034.5 / PFP-044: AppleDouble セルフクリーンアップ (起動時防御)
# 配信 tar.gz に macOS の ._* / .DS_Store が混入すると setup.sh の
# モジュール整合性検証が status=failed で落ち、BOOST が起動不能になる
# (mayu9 端末 2026-05-19 事案: server_key_half 復号は成功するが setup.sh が 11秒で fail)
# 起動時に予防的に削除し、boost skill が「LICENSE」ログを見て誤判定する経路を遮断する
# ============================================================
find "$SCRIPT_DIR" -name '._*' -delete 2>/dev/null || true
find "$SCRIPT_DIR" -name '.DS_Store' -delete 2>/dev/null || true

# ============================================================
# v2051 / エラー報告スプール自動再送 (best-effort, silent)
# customer-error-reporter.sh の .error-queue (送信失敗 payload) を
# 起動時に閉ループ再送する。注意: reporter は引数なしで自身が
# _cer_flush_queue をバックグラウンド起動して exit 0 する設計のため
# source 禁止 (script 内 exit で本流が落ちる)。必ず別プロセス+
# バックグラウンドで起動し、失敗しても本流を一切止めない。
# 顧客可視出力ゼロ (stdout/stderr 抑止、記録は .error-log のみ)。
# ============================================================
if [[ -f "${SCRIPT_DIR}/lib/cognitive/customer-error-reporter.sh" ]] \
   && [[ -d "${SOLOPTILINK_DIR:-$HOME/.soloptilink}/.error-queue" ]]; then
    ( bash "${SCRIPT_DIR}/lib/cognitive/customer-error-reporter.sh" </dev/null >/dev/null 2>&1 & ) >/dev/null 2>&1 || true
fi

# ============================================================
# Layer 0: 共通ユーティリティの先行読み込み (lib/common/)
# ============================================================
# colors.sh → logger.sh → error-handler.sh → json-utils.sh → timeout-utils.sh の順で読み込み
# これにより全モジュールが統一されたカラー・ログ・エラーハンドリング・JSON・タイムアウトAPIを使用
for _common_lib in colors.sh logger.sh error-handler.sh json-utils.sh timeout-utils.sh; do
    if [[ -f "${SCRIPT_DIR}/lib/common/${_common_lib}" ]]; then
        source "${SCRIPT_DIR}/lib/common/${_common_lib}" 2>/dev/null || true
    fi
done

# カラー変数の後方互換エイリアス
# lib/common/colors.sh のCLR_*定数から従来変数名へマッピング
GREEN="${CLR_GREEN:-\033[0;32m}"
YELLOW="${CLR_YELLOW:-\033[0;33m}"
RED="${CLR_RED:-\033[0;31m}"
BLUE="${CLR_BLUE:-\033[0;34m}"
PURPLE="${CLR_PURPLE:-\033[0;35m}"
CYAN="${CLR_CYAN:-\033[0;36m}"
BOLD="${CLR_BOLD:-\033[1m}"
NC="${CLR_NC:-\033[0m}"
# v2034.7-fix(SLB-006): DIM is used unprefixed in lib/phases-quality.sh (5x)
# but was never defined in this global alias block. Under chain.sh `set -u`
# the first ${DIM} reference aborts the run mid-phase. Define it here with
# the other global color aliases (\033[2m = dim, per all lib *_DIM consts).
DIM="${CLR_DIM:-\033[2m}"

# ============================================================
# Layer 0.5: Core モジュール先行読み込み (lib/core/)
# CLI解析・セッション管理・フェーズ実行・レポート・権限管理
# ============================================================
for _core_lib in cli-parser.sh session.sh phase-executor.sh report.sh permissions.sh layer-loader.sh config-validator.sh; do
    if [[ -f "${SCRIPT_DIR}/lib/core/${_core_lib}" ]]; then
        source "${SCRIPT_DIR}/lib/core/${_core_lib}" 2>/dev/null || true
    fi
done

# ============================================================
# v2034.9 / PFP-080: Claude Code Environment Detection
# Step 1.0 で参照する SOLOPTILINK_RUNTIME / SOLOPTILINK_AGENT_MODE を確定
#
# 背景:
#   Claude Code Desktop 内 Bash は macOS Keychain 制限で claude CLI 認証不可
#   (PFP-068)。chain.sh の agent-orchestrator.sh が claude -p で 105 エージェント
#   協調を実行するが、Desktop 内では「Not logged in」で全失敗するため、
#   Claude (LLM) 自身がシーケンシャルに 5 ロール (Architect→Implementer→
#   Tester→Reviewer→Refiner) を演じ分けるモードに切替える必要がある。
#
#   従来は SKILL.md の prose 記述のみで判定が LLM 任せだったが、PFP-080 で
#   chain.sh 側にも物理的な分岐情報を持たせ、Layered Depth Gate / 業界用語
#   含有率チェックの動作モードを下流フェーズに伝播させる。
# ============================================================
if [[ "${CLAUDECODE:-0}" == "1" ]] || [[ "${CLAUDE_CODE_ENTRYPOINT:-}" == "claude-desktop" ]]; then
    export SOLOPTILINK_RUNTIME="claude-code-desktop"
    export SOLOPTILINK_AGENT_MODE="sequential-105"
    export SOLOPTILINK_DEPTH_GATE_MODE="strict"
    echo -e "${CYAN:-}[PFP-080]${NC:-} Claude Code 環境検知 → シーケンシャル 105 協調モード${NC:-}" >&2
else
    export SOLOPTILINK_RUNTIME="terminal"
    export SOLOPTILINK_AGENT_MODE="parallel-105"
    export SOLOPTILINK_DEPTH_GATE_MODE="strict"
fi

# Layered Depth Gate / 業界用語含有率の閾値 (環境変数でオーバーライド可能)
STRICT_LAYERED_DEPTH="${STRICT_LAYERED_DEPTH:-true}"
LAYERED_DEPTH_MIN_LAYER="${LAYERED_DEPTH_MIN_LAYER:-L2}"   # L0/L1/L2/L3 のうち最低達成すべき層
INDUSTRY_TERM_MIN_REGISTERED="${INDUSTRY_TERM_MIN_REGISTERED:-100}"  # DBL登録済み業種の最低含有数
INDUSTRY_TERM_MIN_UNREGISTERED="${INDUSTRY_TERM_MIN_UNREGISTERED:-150}"  # DBL未登録業種の最低含有数

# Data Persistence Gate (PFP-089 / v2036.0) - 永続DB保証 (環境変数でオーバーライド可能)
ENABLE_DB_PERSISTENCE_GATE="${ENABLE_DB_PERSISTENCE_GATE:-true}"
STRICT_DB_PERSISTENCE="${STRICT_DB_PERSISTENCE:-true}"
# v2037.0 (PFP-090): Secret-in-Prompt Protection Gate — 生成物の平文機密残存を検査
ENABLE_SECRET_PROTECTION_GATE="${ENABLE_SECRET_PROTECTION_GATE:-true}"
STRICT_SECRET_PROTECTION="${STRICT_SECRET_PROTECTION:-true}"
DB_PERSISTENCE_TIER="${DB_PERSISTENCE_TIER:-}"   # free|paid|none|"" (未指定なら本番意図時に人へ確認=BLOCK)

# v2038.x (PFP-100): CRUD Input Capability Gate — 生成物が「入力できる」か (新規作成/編集フォーム実在) を保証
# create フォームが 1 つも無い完全閲覧専用 (TWOSTONE 事案) は BLOCK = 生成停止 (Strict 不問)。
# 部分的不足は既定 WARN (非Strict)。STRICT_CRUD_INPUT=true で FAIL も生成停止に昇格。
ENABLE_CRUD_INPUT_GATE="${ENABLE_CRUD_INPUT_GATE:-true}"
STRICT_CRUD_INPUT="${STRICT_CRUD_INPUT:-false}"
CIC_CREATE_MIN="${CIC_CREATE_MIN:-60}"   # 業務モデルの作成フォーム網羅率 基準 %
CIC_WRITE_MIN="${CIC_WRITE_MIN:-60}"     # 業務モデルの書込パス網羅率 基準 %

# デフォルト設定（環境変数でオーバーライド可能）
MAX_ROUNDS="${MAX_ROUNDS:-15}"
COST_LIMIT="${COST_LIMIT:-10.00}"
SESSION_TIMEOUT="${SESSION_TIMEOUT:-10800}"  # 3時間
MAX_HEAL_ITERATIONS="${MAX_HEAL_ITERATIONS:-50}"
PIPELINE_MODE="auto"
NO_RAG="${NO_RAG:-0}"
NO_LEARN="${NO_LEARN:-0}"

# URL駆動モード用
declare -a URLS=()
VALIDATE_DIR=""
AUTO_FIX="false"
RESUME_MODE="false"
SHOW_CHECKPOINTS="false"
TASK_DESC=""

# v9.0/v10.0 フラグ
ENABLE_PARALLEL="false"
ENABLE_DEPLOY="false"
ENABLE_BROWSER_TEST="false"

# v11.0 セキュリティフラグ
ENABLE_SECURITY="true"
SECURITY_SCAN_ONLY=""
SECURITY_AUTO_FIX="false"
SECURITY_SCORE=""

# v17.0 Enterprise Foundationフラグ
ENABLE_DATA_INTEGRITY="true"
ENABLE_AUDIT_LOG="true"
ENABLE_E2E="true"
DI_SCORE=""
AL_COVERAGE_SCORE=""

# v18.0 Intelligent Platformフラグ
ENABLE_DATA_IMPORT="${ENABLE_DATA_IMPORT:-auto}"
DATA_IMPORT_FILE="${DATA_IMPORT_FILE:-}"
ENABLE_SAAS="${ENABLE_SAAS:-auto}"
TENANT_STRATEGY="${TENANT_STRATEGY:-auto}"
AUTH_METHODS="${AUTH_METHODS:-jwt}"
ENABLE_BILLING="${ENABLE_BILLING:-false}"
ENABLE_AI="${ENABLE_AI:-auto}"
LLM_PROVIDERS="${LLM_PROVIDERS:-}"
ENABLE_RAG="${ENABLE_RAG:-false}"
VECTOR_DB="${VECTOR_DB:-pinecone}"
DIN_SCORE=""
SB_SCORE=""
AI_SCORE=""
DIN_TABLE_COUNT="${DIN_TABLE_COUNT:-0}"
DIN_COLUMN_COUNT="${DIN_COLUMN_COUNT:-0}"

# v20.0 Quality Fortressフラグ
ENABLE_QUALITY_GATE="${ENABLE_QUALITY_GATE:-true}"
ENABLE_SMOKE_TEST="${ENABLE_SMOKE_TEST:-true}"
QUALITY_THRESHOLD="${QUALITY_THRESHOLD:-80}"
QG_SCORE=""

# v25.0 Adaptive Intelligenceフラグ
ENABLE_DEP_RESOLVE="${ENABLE_DEP_RESOLVE:-true}"
ENABLE_PERF_PROFILE="${ENABLE_PERF_PROFILE:-true}"
ENABLE_API_CONTRACT="${ENABLE_API_CONTRACT:-true}"

# ============================================================
# v2042 (L1ハーネス / REQ-WIRE-V2042): Lane Wiring フラグ初期化(追記のみ)
# ------------------------------------------------------------
# L2〜L9 が本体を再編集せず lib/phases/phase_lane<N>_*.sh を置くだけで点灯できる
# ための ENABLE/STRICT フラグ。実体未配置時は汎用ディスパッチの compgen が空=何も
# 起きない(既定フロー完全不変=回帰ゼロ)。外側ゲートは既定 true(開く)、STRICT は
# 既定 false(WARNのみ・FAIL停止しない)。opt-in 既定OFF は各 phase 関数が自己ガードで管理。
ENABLE_LANE_PHASES="${ENABLE_LANE_PHASES:-true}"
ENABLE_LANE1="${ENABLE_LANE1:-true}";   STRICT_LANE1="${STRICT_LANE1:-false}"
ENABLE_LANE2="${ENABLE_LANE2:-true}";   STRICT_LANE2="${STRICT_LANE2:-false}"
ENABLE_LANE3="${ENABLE_LANE3:-true}";   STRICT_LANE3="${STRICT_LANE3:-false}"
ENABLE_LANE4="${ENABLE_LANE4:-true}";   STRICT_LANE4="${STRICT_LANE4:-false}"
ENABLE_LANE5="${ENABLE_LANE5:-true}";   STRICT_LANE5="${STRICT_LANE5:-false}"
ENABLE_LANE6="${ENABLE_LANE6:-true}";   STRICT_LANE6="${STRICT_LANE6:-false}"
ENABLE_LANE7="${ENABLE_LANE7:-true}";   STRICT_LANE7="${STRICT_LANE7:-false}"
ENABLE_LANE8="${ENABLE_LANE8:-true}";   STRICT_LANE8="${STRICT_LANE8:-false}"
ENABLE_LANE9="${ENABLE_LANE9:-true}";   STRICT_LANE9="${STRICT_LANE9:-false}"
ENABLE_LANE10="${ENABLE_LANE10:-true}"; STRICT_LANE10="${STRICT_LANE10:-false}"
# 機能別フラグ ENABLE_LANE<N>_<FEAT> は事前宣言しない(波3 skeptic/falsifier 指摘の恒久対策)。
# 理由: 事前宣言すると各レーンの機能フラグ既定(例 L2 は ENABLE_LANE2_PERF を「既定OFFの opt-in」として
#       自所有)と衝突する。ディスパッチは "${!_lane_feat_var:-true}" のインライン既定で動くため事前宣言は
#       不要であり、機能フラグの既定は各 phase 実体/ヘルパー側(${ENABLE_LANE<N>_<FEAT>:-...})が所有する。

DR_SCORE=""
PP_SCORE=""
ACV_SCORE=""

# ファイル出力追跡
REQUIREMENTS_FILE=""
SPEC_DIR=""
BLUEPRINT_FILE=""
TECH_STACK_FILE=""

# v13.0: コスト追跡
CLAUDE_CALL_COUNT=0
CLAUDE_ESTIMATED_COST="0.00"

# セッション管理 - session_init()で正式初期化される前の仮値
SESSION_ID="chain_$(date +%Y%m%d_%H%M%S)_$$"
SESSION_START=$(date +%s)
SESSION_LOG_DIR="${SCRIPT_DIR}/docs/chain-logs/${SESSION_ID}"
LOCK_FILE="/tmp/soloptilink_chain.lock"
WATCHDOG_PID=""

# v23.0: Error Guardian 初期化
if type -t err_init &>/dev/null; then
    err_init "$SESSION_ID" "$SESSION_LOG_DIR"
fi


# ============================================================
# フェーズ関数・ユーティリティ関数の読み込み
# ============================================================
source "${SCRIPT_DIR}/lib/phases.sh" 2>/dev/null || { echo "ERROR: lib/phases.sh not found"; exit 1; }
source "${SCRIPT_DIR}/lib/chain-utils.sh" 2>/dev/null || { echo "ERROR: lib/chain-utils.sh not found"; exit 1; }

# ============================================================
# ライブラリ読み込み（lib/core/layer-loader.sh に委譲）
# ============================================================
_load_libraries() {
    local lib_dir="${SCRIPT_DIR}/lib"

    if type -t load_all_layers &>/dev/null; then
        # v11.0: 3層アーキテクチャによるモジュール読み込み
        load_all_layers "$lib_dir"
    else
        # フォールバック: layer-loader未ロード時は直接読み込み
        echo -e "  ${BOLD}モジュール読み込み（フォールバック）:${NC}"
        # v2008.5: License Guard 最優先読み込み
        if [[ -f "${lib_dir}/license-guard.sh" ]]; then
            source "${lib_dir}/license-guard.sh" 2>/dev/null || true
            echo -e "    ${GREEN}✓${NC} license-guard.sh"
        fi
        for lib in dag-pipeline.sh realtime-learn.sh \
                   url-analyzer.sh validator.sh qa-engine.sh healer.sh causal-healer.sh checkpoint.sh \
                   prompt-expander.sh scaffolder.sh file-writer.sh file-writer-v2.sh file-writer-v3.sh \
                   parallel-exec.sh browser-test.sh auto-deploy.sh \
                   dep-audit.sh security-guard.sh \
                   context-engine.sh agent-orchestrator.sh agent-protocol.sh knowledge-graph.sh \
                   dev-server.sh build-verifier.sh env-manager.sh infra-provisioner.sh \
                   test-runner.sh ui-engine.sh visual-review.sh prompt-optimizer.sh \
                   observatory.sh trace-propagator.sh cost-engine.sh perf-baseline.sh coverage-gate.sh \
                   agent-runtime.sh plugin-loader.sh structured-output.sh session-state.sh log-rotation.sh \
                   planner-judge.sh model-router.sh memory-manager.sh context-budget.sh \
                   data-integrity.sh audit-logger.sh e2e-pipeline.sh agent-scaler.sh \
                   data-intelligence.sh saas-builder.sh ai-integration.sh \
                   workflow-engine.sh cost-dashboard.sh template-registry.sh \
                   real-data-connector.sh \
                   dependency-resolver.sh performance-profiler.sh api-contract-validator.sh \
                   deep-fix-engine.sh \
                   domain-knowledge.sh blueprint-generator.sh prompt-compiler.sh \
                   tech-stack-resolver.sh followup-context.sh code-scanner.sh \
                   incremental-analyzer.sh targeted-compiler.sh delta-applier.sh \
                   learning-hub.sh consultant-engine.sh \
                   swarm-coordinator.sh voting-engine.sh governance-engine.sh \
                   structured-output-v2.sh micro-task-engine.sh \
                   prompt-evolution.sh parallel-exec-v2.sh \
                   dashboard-connector.sh \
                   ios-deploy-pipeline.sh \
                   harness-bridge.sh \
                   quality-genome.sh plan-calibration.sh cognitive-rpc.sh strategic-planning-engine.sh \
                   ibl.sh connector-forge.sh integration-learning-loop.sh \
                   integration-planner.sh connectivity-probe.sh; do
            if [[ -f "${lib_dir}/${lib}" ]]; then
                source "${lib_dir}/${lib}" 2>/dev/null || echo -e "    ${YELLOW}⚠️ ${lib} ロード警告（続行）${NC}"
                echo -e "    ${GREEN}✓${NC} ${lib}"
            fi
        done
    fi
}

# ============================================================
# 引数パース（lib/core/cli-parser.sh に委譲）
# ============================================================
_parse_args() {
    if type -t parse_cli_args &>/dev/null; then
        # v11.0: cli-parser.shの関数で引数解析 → グローバル変数に反映
        parse_cli_args "$@"
        cli_apply_to_globals
    else
        # フォールバック: cli-parser.sh未ロード時の簡易パーサー
        while [[ $# -gt 0 ]]; do
            case "$1" in
                --url)       URLS+=("${2:?--urlにはURLが必要}"); shift 2 ;;
                --validate)  VALIDATE_DIR="${2:-.}"; [[ -n "${2:-}" && "${2:-}" != --* ]] && shift 2 || shift ;;
                --auto-fix)  AUTO_FIX="true"; shift ;;
                --resume)    RESUME_MODE="true"; shift ;;
                --checkpoints) SHOW_CHECKPOINTS="true"; shift ;;
                --pipeline)  [[ -n "${2:-}" && "${2:-}" != --* ]] && { PIPELINE_MODE="$2"; shift 2; } || { PIPELINE_MODE="auto"; shift; } ;;
                --parallel)  ENABLE_PARALLEL="true"; shift ;;
                --deploy)    ENABLE_DEPLOY="true"; shift ;;
                --browser-test) ENABLE_BROWSER_TEST="true"; shift ;;
                --security-scan) SECURITY_SCAN_ONLY="${2:-.}"; [[ -n "${2:-}" && "${2:-}" != --* ]] && shift 2 || shift ;;
                --security-fix)  SECURITY_SCAN_ONLY="${2:-.}"; [[ -n "${2:-}" && "${2:-}" != --* ]] && shift 2 || shift; SECURITY_AUTO_FIX="true" ;;
                --no-security) ENABLE_SECURITY="false"; shift ;;
                --no-data-integrity) ENABLE_DATA_INTEGRITY="false"; shift ;;
                --no-audit-log) ENABLE_AUDIT_LOG="false"; shift ;;
                --no-e2e) ENABLE_E2E="false"; shift ;;
                --e2e) ENABLE_E2E="true"; shift ;;
                # v18.0 Intelligent Platform
                --data-import)    ENABLE_DATA_IMPORT="true"; shift ;;
                --no-data-import) ENABLE_DATA_IMPORT="false"; shift ;;
                --data-file)      DATA_IMPORT_FILE="${2:?--data-fileにはパスが必要}"; ENABLE_DATA_IMPORT="true"; shift 2 ;;
                --saas)           ENABLE_SAAS="true"; shift ;;
                --no-saas)        ENABLE_SAAS="false"; shift ;;
                --tenant-strategy) TENANT_STRATEGY="${2:?--tenant-strategyに戦略指定が必要}"; shift 2 ;;
                --auth-methods)   AUTH_METHODS="${2:?--auth-methodsにメソッド指定が必要}"; shift 2 ;;
                --billing)        ENABLE_BILLING="true"; ENABLE_SAAS="true"; shift ;;
                --ai-integration) ENABLE_AI="true"; shift ;;
                --no-ai)          ENABLE_AI="false"; shift ;;
                --llm-providers)  LLM_PROVIDERS="${2:?--llm-providersにプロバイダ指定が必要}"; ENABLE_AI="true"; shift 2 ;;
                --rag)            ENABLE_RAG="true"; ENABLE_AI="true"; shift ;;
                --vector-db)      VECTOR_DB="${2:?--vector-dbにDB指定が必要}"; shift 2 ;;
                --context-budget) CONTEXT_BUDGET="${2:-200000}"; shift 2 ;;
                # v20.0 Quality Fortress
                --quality-gate)    ENABLE_QUALITY_GATE="true"; shift ;;
                --no-quality-gate) ENABLE_QUALITY_GATE="false"; shift ;;
                --quality-threshold) QUALITY_THRESHOLD="${2:-80}"; shift 2 ;;
                --smoke-test)      ENABLE_SMOKE_TEST="true"; shift ;;
                --no-smoke-test)   ENABLE_SMOKE_TEST="false"; shift ;;
                --help|-h)   type -t show_help &>/dev/null && show_help || echo "Usage: ./chain.sh \"タスク\""; exit 0 ;;
                -*)          echo -e "${RED}不明なオプション: $1${NC}"; exit 1 ;;
                *)           TASK_DESC="$1"; shift ;;
            esac
        done
    fi
}

# ============================================================
# Phase: quality_check
# ============================================================
phase_quality_check() {
    local healer_initialized=true
    _log "INFO" "Phase: quality_check - healer_initialized outside loop"
    if declare -f qg_run &>/dev/null; then
        qg_run "$PROJECT_DIR"
    fi
    if declare -f fh_heal &>/dev/null && [[ "$healer_initialized" == "true" ]]; then
        fh_heal "$PROJECT_DIR"
    fi
}

# ============================================================
# Phase: self_replication_gate (PFP-081 SRPG) — 2026-05-29 v2034.10
# ============================================================
# SoloptiLinkAI 自体のクローン / リバースエンジニアリング / 派生
# フレームワーク作成依頼を main_flow 冒頭で構造的に検知・拒否する。
# 検知時は exit 1 で生成停止 (Strict mode はデフォルト ON)。
# 顧客向け文言は内部用語禁止に準拠。
# ============================================================
phase_self_replication_gate() {
    local session_id="$1" task_desc="$2"
    local pfp081="$HOME/.soloptilink/scripts/structural-defenses/pfp-081-self-replication-prohibition.sh"

    if [[ ! -f "$pfp081" ]]; then
        echo -e "  ${YELLOW}⚠️ PFP-081 スクリプト未配置、self_replication_gate をスキップ${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🛡️  [PFP-081] Self-Replication Prohibition Gate${NC}"

    local srpg_out srpg_verdict srpg_message
    srpg_out=$(bash "$pfp081" "$task_desc" --json 2>/dev/null) || true
    srpg_verdict=$(echo "$srpg_out" | python3 -c "import sys,json
try:
    print(json.load(sys.stdin).get('verdict','ALLOW'))
except Exception:
    print('ALLOW')
" 2>/dev/null || echo "ALLOW")   # 配信前監査D3: python3一過性失敗でも set -e 中断させず ALLOW へ graceful fallback

    case "$srpg_verdict" in
        ALLOW)
            echo -e "  ${GREEN}✅ PFP-081: 自己複製パターン検知なし${NC}"
            return 0
            ;;
        BLOCK)
            srpg_message=$(echo "$srpg_out" | python3 -c "import sys,json
try:
    print(json.load(sys.stdin).get('customer_message',''))
except Exception:
    print('')
" 2>/dev/null || echo '')
            echo "" >&2
            echo -e "${RED}╔═══════════════════════════════════════════════════════════════╗${NC}" >&2
            echo -e "${RED}║  SoloptiLinkAI Self-Replication Prohibition Gate (PFP-081)    ║${NC}" >&2
            echo -e "${RED}╚═══════════════════════════════════════════════════════════════╝${NC}" >&2
            echo "" >&2
            echo "$srpg_message" >&2
            echo "" >&2
            echo -e "  ${CYAN}ご相談はサポート窓口まで: support@soloptilink.com${NC}" >&2
            echo "" >&2
            # 詳細ログ保存
            local audit_dir="$HOME/.soloptilink/.audit/self-replication-gate"
            mkdir -p "$audit_dir" 2>/dev/null
            echo "$srpg_out" > "$audit_dir/blocked-${session_id}-$(date +%Y%m%d-%H%M%S).json" 2>/dev/null || true
            # STRICT_SELF_REPLICATION_GATE (default: true)
            if [[ "${STRICT_SELF_REPLICATION_GATE:-true}" == "true" ]]; then
                exit 1
            else
                echo -e "  ${YELLOW}⚠️ Non-Strict mode: 続行${NC}" >&2
                return 0
            fi
            ;;
        *)
            echo -e "  ${YELLOW}⚠️ PFP-081: verdict 不明 (verdict=${srpg_verdict}) — 続行${NC}" >&2
            return 0
            ;;
    esac
}

# ============================================================
# Phase: first_login_gate (PFP-061 + PFP-071 統合) — 2026-05-25
# ============================================================
# 「BOOST生成システムが1回目ログインできない」事案を構造的に根絶。
# 内部で PFP-061 (port allocator) + PFP-071 (First-Login Gate) を順次実行。
# 失敗してもプロジェクト生成自体は中断しない (warn のみ)。
# ============================================================
phase_first_login_gate() {
    local session_id="$1" task_desc="$2"
    local target_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo ".")}"

    _log "INFO" "Phase: first_login_gate - target=$target_dir"

    local pfp061="$HOME/.soloptilink/scripts/structural-defenses/pfp-061-port-allocator.sh"
    local pfp071="$HOME/.soloptilink/scripts/structural-defenses/pfp-071-first-login-gate.sh"

    if [[ ! -f "$pfp061" ]] || [[ ! -f "$pfp071" ]]; then
        echo -e "  ${YELLOW}⚠️ PFP-061/071 スクリプト未配置、first_login_gate をスキップ${NC}" >&2
        return 0
    fi

    # Next.js プロジェクトでない場合はスキップ (PFP-071 が自動判定)
    echo -e "\n  ${CYAN}🔐 [PFP-061/071] First-Login Zero-Friction Gate${NC}"

    # PFP-061: port 整合自動修復 (1分以内に終わる軽量処理)
    local p61_out
    p61_out=$(bash "$pfp061" --apply --json "$target_dir" 2>&1) || true
    local p61_verdict=$(echo "$p61_out" | grep -oE '"verdict"\s*:\s*"[^"]+"' | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
    case "$p61_verdict" in
        applied)
            local changes=$(echo "$p61_out" | grep -oE '"target_port"\s*:\s*[0-9]+' | grep -oE '[0-9]+')
            echo -e "  ${GREEN}✅ PFP-061: port を ${changes} で整合${NC}"
            ;;
        already_consistent|consistent|needs_init)
            echo -e "  ${GREEN}✅ PFP-061: port 整合済み${NC}"
            ;;
        not_applicable)
            echo -e "  ${YELLOW}ℹ PFP-061: Next.js プロジェクトでないためスキップ${NC}"
            return 0
            ;;
        *)
            echo -e "  ${YELLOW}⚠️ PFP-061: verdict=${p61_verdict} (続行)${NC}"
            ;;
    esac

    # PFP-071: 統合ゲート (apply モードで自動修復)
    local p71_out
    p71_out=$(bash "$pfp071" --apply --json "$target_dir" 2>&1) || true
    local p71_verdict=$(echo "$p71_out" | grep -oE '"verdict"\s*:\s*"[^"]+"' | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
    local p71_pass=$(echo "$p71_out" | grep -oE '"passed"\s*:\s*[0-9]+' | grep -oE '[0-9]+')
    local p71_fail=$(echo "$p71_out" | grep -oE '"failed"\s*:\s*[0-9]+' | grep -oE '[0-9]+')
    local p71_heal=$(echo "$p71_out" | grep -oE '"healed"\s*:\s*[0-9]+' | grep -oE '[0-9]+')

    case "$p71_verdict" in
        PASS)
            echo -e "  ${GREEN}✅ PFP-071: First-Login Gate PASS (${p71_pass:-0}件 / 自動修復 ${p71_heal:-0}件)${NC}"
            ;;
        FAIL)
            if [[ "${STRICT_FIRST_LOGIN_GATE:-true}" == "true" ]]; then
                echo -e "  ${RED}❌ PFP-071: ${p71_fail:-?}件 残存 / 修復 ${p71_heal:-0}件 (Strict mode → 失敗)${NC}" >&2
                return 1
            else
                echo -e "  ${YELLOW}⚠️ PFP-071: ${p71_fail:-?}件 残存 / 修復 ${p71_heal:-0}件 (非Strict → 続行)${NC}"
            fi
            ;;
        not_applicable)
            echo -e "  ${YELLOW}ℹ PFP-071: 対象外 (Next.js+auth プロジェクトでない)${NC}"
            ;;
        *)
            if [[ "${STRICT_FIRST_LOGIN_GATE:-true}" == "true" ]]; then
                echo -e "  ${RED}❌ PFP-071: verdict=${p71_verdict:-unknown} (Strict mode → 失敗)${NC}" >&2
                return 1
            else
                echo -e "  ${YELLOW}⚠️ PFP-071: verdict=${p71_verdict:-unknown} (続行)${NC}"
            fi
            ;;
    esac

    # ============================================================
    # PFP-079: Login Redirect Race Gate (LRRG) — 2026-05-28
    # ============================================================
    # 「サーバー側認証は成功するが UI が dashboard に滞在できず /login に戻る」
    # 事案を構造的に根絶。HOKEN HEROES Platform (2026-05-28) で確定した
    # 3階建てrace (callbackUrlフルURL+router.refresh+SessionProvider polling)
    # を L1-L3 自動修復で防ぐ。PFP-071 の直後に実行。
    local pfp079="$HOME/.soloptilink/scripts/structural-defenses/pfp-079-login-redirect-race-gate.sh"
    if [[ -f "$pfp079" ]]; then
        local p79_out
        p79_out=$(bash "$pfp079" --apply --json "$target_dir" 2>&1) || true
        local p79_verdict=$(echo "$p79_out" | grep -oE '"verdict"\s*:\s*"[^"]+"' | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
        local p79_pass=$(echo "$p79_out" | grep -oE '"passed"\s*:\s*[0-9]+' | grep -oE '[0-9]+')
        local p79_fail=$(echo "$p79_out" | grep -oE '"failed"\s*:\s*[0-9]+' | grep -oE '[0-9]+')
        local p79_heal=$(echo "$p79_out" | grep -oE '"healed"\s*:\s*[0-9]+' | grep -oE '[0-9]+')

        case "$p79_verdict" in
            PASS)
                echo -e "  ${GREEN}✅ PFP-079: LRRG PASS (${p79_pass:-0}件 / 自動修復 ${p79_heal:-0}件)${NC}"
                ;;
            FAIL)
                if [[ "${STRICT_FIRST_LOGIN_GATE:-true}" == "true" ]]; then
                    echo -e "  ${RED}❌ PFP-079: ${p79_fail:-?}件 残存 / 修復 ${p79_heal:-0}件 (Strict mode → 失敗)${NC}" >&2
                    return 1
                else
                    echo -e "  ${YELLOW}⚠️ PFP-079: ${p79_fail:-?}件 残存 / 修復 ${p79_heal:-0}件 (非Strict → 続行)${NC}"
                fi
                ;;
            not_applicable)
                echo -e "  ${YELLOW}ℹ PFP-079: 対象外 (Next.js+next-auth プロジェクトでない)${NC}"
                ;;
            *)
                echo -e "  ${YELLOW}⚠️ PFP-079: verdict=${p79_verdict:-unknown} (続行)${NC}"
                ;;
        esac
    fi

    return 0
}

# ============================================================
# Phase: form_critical_path (PFP-074 FCPG/REHD/OSCG 三兄弟統合) — 2026-05-26
# ============================================================
# 「請求書/見積/契約/受注/予約フォームが一発で送信できない」事案を構造的に根絶。
# linkage-mic-platform (2026-05-09) + sales-cockpit-pro (2026-05-21)
# の請求書フォーム失敗を再発防止。
# 内部で REHD (RSC Event Handler Detector) + FCPG (Form Critical Path Guarantor 8軸)
# + OSCG (One-Shot Completeness Gate 13軸) を順次実行。
# 環境変数: ENABLE_FORM_CRITICAL_PATH (default true), STRICT_FORM_CRITICAL_PATH (default true)
# ============================================================
phase_form_critical_path() {
    local session_id="$1" task_desc="$2"
    local target_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo ".")}"

    _log "INFO" "Phase: form_critical_path - target=$target_dir"

    local fcpg="${SCRIPT_DIR}/lib/first-boot-perfect/form-critical-path-guarantor.sh"
    local rehd="${SCRIPT_DIR}/lib/first-boot-perfect/rsc-event-handler-detector.sh"
    local oscg="${SCRIPT_DIR}/lib/first-boot-perfect/one-shot-completeness-gate.sh"

    if [[ ! -f "$fcpg" ]] || [[ ! -f "$rehd" ]] || [[ ! -f "$oscg" ]]; then
        echo -e "  ${YELLOW}⚠️ FCPG/REHD/OSCG スクリプト未配置、phase_form_critical_path をスキップ${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}📋 [PFP-074] Form Critical Path Gate (REHD/FCPG/OSCG 三兄弟)${NC}"

    local fail_count=0
    local total_violations=0
    local tmp_log=$(mktemp)

    # REHD: RSC Event Handler Detector
    echo -e "  ${CYAN}  ▸ REHD (RSC Event Handler Detector)${NC}"
    if bash "$rehd" run "$target_dir" >"$tmp_log" 2>&1; then
        echo -e "  ${GREEN}  ✅ REHD PASS${NC}"
    else
        local rehd_ec=$?
        if [[ $rehd_ec -eq 2 ]]; then
            echo -e "  ${YELLOW}  ℹ REHD: 対象フォームなし (SKIP)${NC}"
        else
            local v=$(grep -cE 'violation|error|fail' "$tmp_log" 2>/dev/null || echo 0)
            echo -e "  ${RED}  ❌ REHD FAIL (violations≈${v})${NC}" >&2
            fail_count=$((fail_count+1))
            total_violations=$((total_violations+v))
        fi
    fi

    # FCPG: Form Critical Path Guarantor (8軸)
    echo -e "  ${CYAN}  ▸ FCPG (Form Critical Path Guarantor 8軸)${NC}"
    if bash "$fcpg" run "$target_dir" >"$tmp_log" 2>&1; then
        echo -e "  ${GREEN}  ✅ FCPG PASS (8軸)${NC}"
    else
        local fcpg_ec=$?
        if [[ $fcpg_ec -eq 2 ]]; then
            echo -e "  ${YELLOW}  ℹ FCPG: 対象フォームなし (SKIP)${NC}"
        else
            local v=$(grep -cE '\[Form保証 ✗\]|violation|fail' "$tmp_log" 2>/dev/null || echo 0)
            echo -e "  ${RED}  ❌ FCPG FAIL (violations≈${v})${NC}" >&2
            fail_count=$((fail_count+1))
            total_violations=$((total_violations+v))
        fi
    fi

    # OSCG: One-Shot Completeness Gate (13軸)
    echo -e "  ${CYAN}  ▸ OSCG (One-Shot Completeness Gate 13軸)${NC}"
    if bash "$oscg" run "$target_dir" >"$tmp_log" 2>&1; then
        echo -e "  ${GREEN}  ✅ OSCG PASS (13軸)${NC}"
    else
        local oscg_ec=$?
        if [[ $oscg_ec -eq 2 ]]; then
            echo -e "  ${YELLOW}  ℹ OSCG: 対象なし (SKIP)${NC}"
        else
            local v=$(grep -cE 'fail|violation' "$tmp_log" 2>/dev/null || echo 0)
            echo -e "  ${RED}  ❌ OSCG FAIL (violations≈${v})${NC}" >&2
            fail_count=$((fail_count+1))
            total_violations=$((total_violations+v))
        fi
    fi

    rm -f "$tmp_log"

    if [[ $fail_count -gt 0 ]]; then
        if [[ "${STRICT_FORM_CRITICAL_PATH:-true}" == "true" ]]; then
            echo -e "  ${RED}❌ Form Critical Path Gate FAIL: ${fail_count} module / ${total_violations} violations (Strict mode → 失敗)${NC}" >&2
            return 1
        else
            echo -e "  ${YELLOW}⚠️ Form Critical Path Gate ${fail_count} module 失敗 (非Strict → 続行)${NC}"
            return 0
        fi
    fi

    echo -e "  ${GREEN}✅ Form Critical Path Gate: 3 module 全 PASS${NC}"
    return 0
}

# ============================================================
# Phase: dbl_detect (PFP-080 DBL Auto-Detect / Step 0.8) — 2026-05-29
# ============================================================
# 事業推論結果から ~/.soloptilink/domains/*.json の keywords[] を突合し、
# スコア最高の DBL を自動推測する。
#
# 出力: $PROJECT_DIR/.soloptilink/dbl-detection.json
# export: SOLOPTILINK_DETECTED_DBL (後続 phase_layered_depth_gate が参照)
#
# 環境変数:
#   ENABLE_DBL_DETECT (default: true)
#   DBL_MIN_SCORE (default: 3 / これ未満は unregistered)
# ============================================================
phase_dbl_detect() {
    local session_id="$1" task_desc="${2:-}"
    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    local domains_dir="${HOME}/.soloptilink/domains"
    local min_score="${DBL_MIN_SCORE:-3}"

    if [[ ! -d "$domains_dir" ]]; then
        echo -e "  ${YELLOW}⚠️ domains/ ディレクトリ不在 → phase_dbl_detect をスキップ${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}📚 [Step 0.8] DBL Auto-Detect${NC}"

    # 候補テキスト = TASK_DESC + project README + package.json description + prisma schema model/enum
    local cand_text="$task_desc"
    if [[ -f "$proj_dir/README.md" ]]; then
        cand_text+=$'\n'"$(cat "$proj_dir/README.md" 2>/dev/null || true)"
    fi
    if [[ -f "$proj_dir/package.json" ]]; then
        cand_text+=$'\n'"$(jq -r '.description // ""' "$proj_dir/package.json" 2>/dev/null || true)"
    fi
    if [[ -f "$proj_dir/prisma/schema.prisma" ]]; then
        cand_text+=$'\n'"$(grep -E '^(model|enum) ' "$proj_dir/prisma/schema.prisma" 2>/dev/null || true)"
    fi

    local best_score=0
    local best_dbl=""
    for f in "$domains_dir"/*.json; do
        [[ "$(basename "$f")" == "_base.json" ]] && continue
        [[ ! -f "$f" ]] && continue
        local kws
        kws=$(jq -r '.keywords[]?' "$f" 2>/dev/null | head -30 || true)
        [[ -z "$kws" ]] && continue
        local score=0
        while IFS= read -r kw; do
            [[ -z "$kw" ]] && continue
            [[ ${#kw} -lt 2 ]] && continue
            if echo "$cand_text" | grep -iqF -- "$kw"; then
                score=$((score + 1))
            fi
        done <<< "$kws"
        if [[ $score -gt $best_score ]]; then
            best_score=$score
            best_dbl=$(basename "$f" .json)
        fi
    done

    local result_file="$proj_dir/.soloptilink/dbl-detection.json"
    mkdir -p "$(dirname "$result_file")" || return 1

    if [[ -n "$best_dbl" ]] && [[ $best_score -ge $min_score ]]; then
        local kw_count model_count
        kw_count=$(jq '.keywords | length' "$domains_dir/$best_dbl.json" 2>/dev/null || echo 0)
        model_count=$(jq '.models | length' "$domains_dir/$best_dbl.json" 2>/dev/null || echo 0)
        echo -e "  ${GREEN}✓${NC} DBL: $best_dbl (score=$best_score / registered)"
        echo -e "    keywords=$kw_count / models=$model_count"
        cat > "$result_file" <<EOF
{
  "version": "v2034.9",
  "phase": "PFP-080 DBL Auto-Detect",
  "dbl_name": "$best_dbl",
  "score": $best_score,
  "registered": true,
  "keyword_count": $kw_count,
  "model_count": $model_count
}
EOF
        export SOLOPTILINK_DETECTED_DBL="$best_dbl"
    else
        echo -e "  ${YELLOW}⚠${NC} DBL: unregistered (score=$best_score < $min_score)"
        echo -e "    推奨: DBL 雛形作成で L2/L3 到達精度向上"
        cat > "$result_file" <<EOF
{
  "version": "v2034.9",
  "phase": "PFP-080 DBL Auto-Detect",
  "dbl_name": "unregistered",
  "best_candidate": "$best_dbl",
  "score": $best_score,
  "registered": false
}
EOF
        export SOLOPTILINK_DETECTED_DBL=""
    fi
}

# ============================================================
# Phase: ibl_detect (REQ-WIRE-003 / v2037) — 外部連携 Auto-Detect
# ============================================================
# TASK_DESC から外部サービス連携 (Zoom/LINE/freee/Stripe 等) を IBL 辞書で
# 自動検出し、検出時は SOLOPTILINK_DETECTED_CONNECTOR を export + 連携ナレッジ
# (ibl_inject_prompt の日本語化済みブロック) を生成プロンプト用に保存する。
# 従来 ibl.sh は source のみで自動フロー未配線 (半孤児) だったのを正規配線する。
# 非Strictオプトイン: ENABLE_IBL_DETECT=true 既定 / 未登録サービスでも生成を止めない。
# ============================================================
phase_ibl_detect() {
    local session_id="$1" task_desc="${2:-}"
    [[ "${ENABLE_IBL_DETECT:-true}" != "true" ]] && return 0
    [[ -z "$task_desc" ]] && return 0
    type -t ibl_detect &>/dev/null || return 0   # ibl.sh 未ロード環境は透過

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    local min_score="${IBL_MIN_SCORE:-2}"

    echo -e "\n  ${CYAN}🔌 [Step 0.9] 外部連携 Auto-Detect (IBL)${NC}"
    type -t ibl_init &>/dev/null && ibl_init 2>/dev/null || true

    local detect_json conn score reg
    detect_json="$(ibl_detect "$task_desc" 2>/dev/null || echo '{}')"
    conn="$(printf '%s' "$detect_json" | python3 -c "import sys,json
try: print(json.load(sys.stdin).get('connector',''))
except: print('')" 2>/dev/null || echo "")"
    score="$(printf '%s' "$detect_json" | python3 -c "import sys,json
try: print(int(json.load(sys.stdin).get('score',0)))
except: print(0)" 2>/dev/null || echo 0)"
    reg="$(printf '%s' "$detect_json" | python3 -c "import sys,json
try: print(str(json.load(sys.stdin).get('registered',False)).lower())
except: print('false')" 2>/dev/null || echo false)"
    [[ "$score" =~ ^[0-9]+$ ]] || score=0

    local result_file="$proj_dir/.soloptilink/ibl-detection.json"
    mkdir -p "$(dirname "$result_file")" || return 1

    if [[ -n "$conn" ]] && (( score >= min_score )); then
        echo -e "  ${GREEN}✓${NC} 連携検出: $conn (score=$score / registered=$reg)"
        export SOLOPTILINK_DETECTED_CONNECTOR="$conn"
        local inject_file="$proj_dir/.soloptilink/ibl-knowledge-$conn.md"
        ibl_inject_prompt "$conn" > "$inject_file" 2>/dev/null || true
        [[ -s "$inject_file" ]] && echo -e "    連携ナレッジ注入: $(basename "$inject_file")"
        printf '{"version":"v2037.0","phase":"REQ-WIRE-003 IBL Auto-Detect","connector":"%s","score":%s,"registered":%s}\n' \
            "$conn" "$score" "$reg" > "$result_file"
    else
        echo -e "  ${YELLOW}⚠${NC} 外部連携: 未検出 (score=$score < $min_score) — 連携不要 or 長尾サービス"
        export SOLOPTILINK_DETECTED_CONNECTOR=""
        printf '{"version":"v2037.0","phase":"REQ-WIRE-003 IBL Auto-Detect","connector":"","score":%s,"registered":false}\n' \
            "$score" > "$result_file"
    fi
    return 0
}

# ============================================================
# Phase: quality_amplification (REQ-WIRE-002 / v2037) — 生成品質中核4機能 通電
# ============================================================
# 従来 description で「搭載」と謳いながら本流に通電していなかった4機能を、
# 非ブロッキングの専用フェーズで実起動し claim=reality を成立させる:
#   - Prompt Amplifier (pa_amplify_prompt)          : 増幅ガイダンス生成
#   - Cross-Domain Intelligence (cdi_inject_...)     : 業種横断パターン注入
#   - Multi-Stage Review (msr_run_pipeline)          : 生成物の多段レビュー
#   - Output Maximizer (om_score_output)             : 主要ファイルの品質スコアリング
# 全てサブシェル隔離 + || true で非ブロッキング。重い処理は ENABLE_QUALITY_AMPLIFICATION=false
# で無効化可。モジュールは遅延 source (フェーズ実行時のみ・常時オーバーヘッドなし)。
# ============================================================
phase_quality_amplification() {
    local session_id="$1" task_desc="${2:-}"
    [[ "${ENABLE_QUALITY_AMPLIFICATION:-true}" != "true" ]] && return 0
    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    [[ -d "$proj_dir" ]] || return 0
    local libdir="${SCRIPT_DIR:-$HOME/.soloptilink}/lib"
    local out_dir="$proj_dir/.soloptilink"
    mkdir -p "$out_dir" 2>/dev/null || true

    echo -e "\n  ${CYAN}🧠 [品質増幅] Prompt Amplifier / Cross-Domain / Multi-Stage Review / Output Maximizer${NC}"

    # 1) Prompt Amplifier + Cross-Domain Intelligence (プロンプトベース・プロジェクト規模非依存・高速)
    if [[ -f "$libdir/prompt-amplifier.sh" && -f "$libdir/cross-domain-intelligence.sh" ]]; then
        ( source "$libdir/prompt-amplifier.sh" 2>/dev/null
          source "$libdir/cross-domain-intelligence.sh" 2>/dev/null
          {
            type -t pa_amplify_prompt &>/dev/null && pa_amplify_prompt "implementation" "$task_desc" "${SOLOPTILINK_DETECTED_DBL:-general}" "$proj_dir" 2>/dev/null
            type -t cdi_inject_learned_patterns &>/dev/null && cdi_inject_learned_patterns "$task_desc" "${SOLOPTILINK_DETECTED_DBL:-general}" 2>/dev/null
          } > "$out_dir/amplified-guidance.md" 2>/dev/null ) || true
        [[ -s "$out_dir/amplified-guidance.md" ]] && echo -e "    ${GREEN}✓${NC} 増幅ガイダンス: amplified-guidance.md"
    fi

    # REQ-PERF-007/008 (v2038): サイズゲートを「全スキップ」から「サンプル検査+正直ログ」へ。
    # om は head -10 で完全に有界のため常に実行する。msr は内部 grep ループを head 制限するが
    # 初回 find は全件列挙するため病的サイズでは時間がかかりうる(検証 #3)。よって多段レビュー(msr)は
    # QA_HARD_SKIP_FILES(既定2000=大半の業務システムを内包しつつ巨大リポの時間超過を防ぐ)を上限とし、
    # 超過時のみ見送る(om は常に実行)。成否・生成物は不変(msr/om はサブシェル + ログリダイレクト + || true で隔離)。
    # find は -maxdepth で深いツリー(NFS/SMB)の応答遅延も抑制。閾値は QA_MAX_FILES / QA_HARD_SKIP_FILES で調整可。
    local _qa_files _qa_sampled="false" _qa_skip_msr="false"
    # capstone[medium] 修正: set -euo pipefail 下で head -6000 早期closeにより find が SIGPIPE→
    # pipefail で非0→set -e 中断、を防ぐため末尾に || true (count の stdout は保持される)。
    _qa_files=$(find "$proj_dir" -maxdepth 6 -type f \( -name '*.ts' -o -name '*.tsx' \) ! -path '*/node_modules/*' ! -path '*/.next/*' 2>/dev/null | head -6000 | wc -l | tr -d ' ' || true)
    if [[ "${_qa_files:-0}" =~ ^[0-9]+$ ]] && (( ${_qa_files:-0} > ${QA_MAX_FILES:-500} )); then
        _qa_sampled="true"
        echo -e "    ${YELLOW}⚠${NC} 大規模プロジェクト(ソース ${_qa_files}+ 件) → 主要ファイルを${YELLOW}サンプル検査${NC}します(全件ではありません)"
    fi
    if [[ "${_qa_files:-0}" =~ ^[0-9]+$ ]] && (( ${_qa_files:-0} > ${QA_HARD_SKIP_FILES:-2000} )); then
        _qa_skip_msr="true"
        echo -e "    ${YELLOW}⚠${NC} 超大規模(ソース ${_qa_files}+ 件) → 多段レビューは見送り、出力スコア(主要10件)のみ実行します"
    fi

    # 2) Multi-Stage Review (内部で head 自己制限済・node_modules除外。超大規模時のみ見送り)
    if [[ "$_qa_skip_msr" != "true" && -f "$libdir/multi-stage-review.sh" ]]; then
        ( source "$libdir/multi-stage-review.sh" 2>/dev/null
          type -t msr_run_pipeline &>/dev/null && msr_run_pipeline "$proj_dir" >"$out_dir/multi-stage-review.log" 2>&1 ) || true
        if [[ -s "$out_dir/multi-stage-review.log" ]]; then
            if [[ "$_qa_sampled" == "true" ]]; then
                echo -e "    ${GREEN}✓${NC} 多段レビュー(主要ファイルをサンプル検査): multi-stage-review.log"
            else
                echo -e "    ${GREEN}✓${NC} 多段レビュー: multi-stage-review.log"
            fi
        fi
    fi

    # 3) Output Maximizer (主要生成ファイル最大10件・maxdepth制限で深いツリーのハング防止)
    if [[ -f "$libdir/output-maximizer.sh" ]]; then
        ( source "$libdir/output-maximizer.sh" 2>/dev/null
          if type -t om_score_output &>/dev/null; then
            find "$proj_dir" -maxdepth 6 -type f \( -name '*.ts' -o -name '*.tsx' \) ! -path '*/node_modules/*' ! -path '*/.next/*' 2>/dev/null | head -10 | while read -r f; do
              om_score_output "$f" 2>/dev/null
            done
          fi ) >"$out_dir/output-scores.log" 2>&1 || true
        [[ -s "$out_dir/output-scores.log" ]] && echo -e "    ${GREEN}✓${NC} 出力スコア: output-scores.log"
    fi
    return 0
}

# ============================================================
# Phase: learning_intelligence (REQ-PERF-004 / v2038) — 過去学習の注入(活用)
# ============================================================
# learning-hub に蓄積した過去セッションの知見を lh_build_intelligence_context で取り出し、
# 管理者の内部学習領域 ~/.soloptilink/learning/intelligence/last-session-context.md に
# surface する(収集→活用 閉ループの「活用」側。顧客プロジェクト配下には置かない=横断統計の漏洩防止)。
# 完全非ブロッキング(サブシェル隔離 + || true)・型ガード付き。ENABLE_LEARNING_LOOP=false で無効化可。
# 顧客影響なし: 生成パイプラインの成否を一切変えず、参照用コンテキストを足すだけ。
# ============================================================
phase_learning_intelligence() {
    local session_id="$1" task_desc="${2:-}"
    [[ "${ENABLE_LEARNING_LOOP:-true}" != "true" ]] && return 0
    type -t lh_init &>/dev/null || return 0
    type -t lh_build_intelligence_context &>/dev/null || return 0
    local domain="${SOLOPTILINK_DETECTED_DBL:-${DOMAIN_TYPE:-general}}"
    # 検証 #5 修正(プライバシー): 横断集計(他案件の成功率/コスト/ドメイン等)を含む learning-context は
    # 顧客プロジェクト配下に置かず、管理者の内部学習領域にのみ surface する
    # (顧客 git への混入・他案件情報の漏洩を構造的に防止)。生成プロンプトへの消費配線は次段階。
    local out_dir="${HOME}/.soloptilink/learning/intelligence"
    mkdir -p "$out_dir" 2>/dev/null || true
    local ctx_file="$out_dir/last-session-context.md"
    (
        lh_init "$session_id" "$domain" 2>/dev/null || exit 0
        lh_build_intelligence_context "implementation" "$domain" 4000 > "$ctx_file" 2>/dev/null || exit 0
    ) || true
    if [[ -s "$ctx_file" ]]; then
        echo -e "  ${GREEN}🧠 過去学習をセッション知見として蓄積しました${NC}"
    fi
    return 0
}

# ============================================================
# Phase: learning_record (REQ-PERF-003 / v2038) — 今回セッションの学習記録(収集)
# ============================================================
# 今回の実行結果(時間/コスト/品質/exit)を learning-hub のストアに記録し、次回以降の
# phase_learning_intelligence で活用できるようにする(閉ループの「収集」側)。
# 完全非ブロッキング・型ガード付き。顧客影響なし(記録のみ)。
# ============================================================
phase_learning_record() {
    local session_id="$1" task_desc="${2:-}" exit_code="${3:-0}"
    [[ "${ENABLE_LEARNING_LOOP:-true}" != "true" ]] && return 0
    type -t lh_record_session_summary &>/dev/null || return 0
    local domain="${SOLOPTILINK_DETECTED_DBL:-${DOMAIN_TYPE:-general}}"
    # 検証 #2/#8 + capstone[high] 修正: 実際にインクリメントされる SoT 変数で記録する。
    #   期間=SESSION_START 差分 / 呼出数=COST_CALLS_TOTAL / 完了フェーズ=_COMPLETED_PHASE_COUNT
    #   (_phase_done で ++ される本物の SoT。旧 OBS_PHASES_COMPLETED は宣言のみで常に0だった)。
    #   コスト=COST_USD_TOTAL / 品質=QG_SCORE。
    #   既知の限界(capstone[medium]): Claude Code Desktop では cost_record が claude -p 経路に依存するため
    #   COST_* は 0 記録になりうる。DAG のみ経路では _COMPLETED_PHASE_COUNT も 0 になりうる(学習の補助項目=害なし)。
    local _sess_dur=0
    [[ -n "${SESSION_START:-}" ]] && _sess_dur=$(( $(date +%s) - SESSION_START ))
    (
        type -t lh_init &>/dev/null && lh_init "$session_id" "$domain" 2>/dev/null
        lh_record_session_summary \
            "$task_desc" \
            "${_sess_dur:-0}" \
            "${COST_CALLS_TOTAL:-0}" \
            "${COST_USD_TOTAL:-0.00}" \
            "${QG_SCORE:-0}" \
            "$exit_code" \
            "${_COMPLETED_PHASE_COUNT:-0}" 2>/dev/null
    ) || true
    return 0
}

# ============================================================
# Phase: layered_depth_gate (PFP-080 最下層到達度評価) — 2026-05-29
# ============================================================
# 「BOOST 一発目の出力が L0 (汎用 HRTech 骨組み) で止まり L2 業界マスタ・L3
# 業界ロジックに到達しない」事案 (2026-05-29 sabikan-link-platform 監査) を
# 構造的に根絶する。
#
# 背景:
#   PFP-068 で Claude Code Desktop 内では chain.sh の agent-orchestrator.sh
#   経由 105 エージェント協調 (claude -p) が Keychain 認証不可で動作不能。
#   Step 2 BOOST LAYER 直接実装に分岐するが、単体 Claude (LLM) の生成は
#   汎用骨組みで終わりがち。本 phase で生成物の L0/L1/L2/L3 を計測し、
#   LAYERED_DEPTH_MIN_LAYER (default: L2) 未達なら Strict mode で生成停止。
#
# 環境変数:
#   ENABLE_LAYERED_DEPTH_GATE (default: true)
#   STRICT_LAYERED_DEPTH (default: true)
#   LAYERED_DEPTH_MIN_LAYER (default: L2)
#   INDUSTRY_TERM_MIN_REGISTERED (default: 100)
#   INDUSTRY_TERM_MIN_UNREGISTERED (default: 150)
# ============================================================
phase_secret_protection_gate() {
    # PFP-090 SIPG: 顧客がプロンプト/CLIに入れた APIキー/接続文字列/秘密鍵が
    # 生成物に平文で残ったまま完成・デプロイされる事故を構造的に根絶する。
    # SoT=secret-patterns.json で leak-scan し、BLOCK 時は生成停止。
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/secret-protection-guarantee.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Secret Protection Gate スクリプト未配置 → phase_secret_protection_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🔐 [PFP-090] Secret Protection Gate - 顧客APIキーの平文残存を検査 (暗号化保護)${NC}"

    bash "$script" "$proj_dir"
    return $?
}

phase_db_persistence_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/data-persistence-guarantee.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Data Persistence Gate スクリプト未配置 → phase_db_persistence_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🗄️ [PFP-089] Data Persistence Gate - 永続DB保証 (データ消失の構造的防止)${NC}"

    # 【2026-07-15 owner方針】保存先は「無料の永続DB」を既定適用 (質問しない)。
    # DB_PERSISTENCE_TIER 未指定はゲート側が free を既定適用して PASS する。
    # 有料は顧客の明示要求か無料枠超過見込み時のみ (概算費用を提示して合意の上で
    # DB_PERSISTENCE_TIER=paid を指定)。未接続 (none) の本番公開は従来どおり BLOCK。
    DB_PERSISTENCE_TIER="${DB_PERSISTENCE_TIER:-}" \
    DEPLOY_INTENT="${DEPLOY_INTENT:-auto}" \
    bash "$script" "$proj_dir" --tier "${DB_PERSISTENCE_TIER:-}" --apply
    return $?
}

phase_layered_depth_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/layered-depth-gate.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Layered Depth Gate スクリプト未配置 → phase_layered_depth_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}📐 [PFP-080] Layered Depth Gate - L0/L1/L2/L3 到達度評価${NC}"

    # phase_dbl_detect の結果を受け取って --dbl 引数として連動
    local dbl_args=()
    if [[ -n "${SOLOPTILINK_DETECTED_DBL:-}" ]]; then
        dbl_args=(--dbl "${SOLOPTILINK_DETECTED_DBL}")
        echo -e "  ${DIM}DBL指定: ${SOLOPTILINK_DETECTED_DBL}${NC}"
    fi

    STRICT_LAYERED_DEPTH="${STRICT_LAYERED_DEPTH:-true}" \
    LAYERED_DEPTH_MIN_LAYER="${LAYERED_DEPTH_MIN_LAYER:-L2}" \
    INDUSTRY_TERM_MIN_REGISTERED="${INDUSTRY_TERM_MIN_REGISTERED:-100}" \
    INDUSTRY_TERM_MIN_UNREGISTERED="${INDUSTRY_TERM_MIN_UNREGISTERED:-150}" \
    bash "$script" run "$proj_dir" "${dbl_args[@]}"
    local _ldg_exit=$?

    # Auto-Refiner: FAIL なら補強指示を JSON 出力 (上位 LLM/chain.sh が読み取り再生成)
    if [[ $_ldg_exit -ne 0 ]] && [[ "${ENABLE_AUTO_REFINER:-true}" == "true" ]]; then
        _ldg_generate_refiner_prompt "$proj_dir"
    fi

    return $_ldg_exit
}

# ============================================================
# PFP-094: Incremental Integration Gate (追加開発統合検証)
# 追加開発で足した model/api/page が既存システム (集計/他機能/ナビ/API
# クライアント) へ結線されたかを検証する。孤児テーブル/死蔵API/孤児ページ/
# ダッシュボード未反映を検出。follow-up (feature_add/modification) のときは
# git 差分で「今回追加した分」だけに絞る。
# ============================================================
phase_incremental_integration_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/incremental-integration-gate.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Incremental Integration Gate スクリプト未配置 → phase_incremental_integration_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    # follow-up (feature_add/modification) なら git 差分で「今回追加分」に絞る
    local scope="full"
    if [[ "${FUC_IS_FOLLOWUP:-false}" == "true" ]]; then
        case "${FUC_REQUEST_TYPE:-}" in
            feature_add|modification) scope="changed";;
        esac
    fi

    echo -e "\n  ${CYAN}🔗 [PFP-094] Incremental Integration Gate - 追加機能の結線検証 (scope=${scope})${NC}"

    STRICT_INCREMENTAL_INTEGRATION="${STRICT_INCREMENTAL_INTEGRATION:-false}" \
    bash "$script" run "$proj_dir" --scope "$scope"
    return $?
}

# ============================================================
# PFP-096 Data Completeness Gate (DCG) — データ完全性6軸の meta ゲート
# マスタ網羅/関連整合/業務ロジック実装率/画面↔DB結線(孤児テーブル・孤児ページ)/
# 集計反映/入力臨界経路 を束ねて検査する。孤児テーブル検出の本配線(これまで未配線=孤児ゲート)。
# 既定 WARN (非Strict)。STRICT_DATA_COMPLETENESS=true で BLOCK。
# (2026-06-06 小貫さん指摘「監査ログが入らない=孤児テーブル」の構造的検出)
# ============================================================
phase_data_completeness_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/data-completeness-gate.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Data Completeness Gate スクリプト未配置 → phase_data_completeness_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🧩 [PFP-096] Data Completeness Gate - データ完全性6軸 (孤児テーブル/孤児ページ/集計反映)${NC}"

    # DBL が検出済みならマスタ網羅性の精度向上のため渡す (空配列展開を避けるため分岐)
    if [[ -n "${SOLOPTILINK_DETECTED_DBL:-}" ]]; then
        STRICT="${STRICT_DATA_COMPLETENESS:-false}" bash "$script" run "$proj_dir" --dbl "${SOLOPTILINK_DETECTED_DBL}"
    else
        STRICT="${STRICT_DATA_COMPLETENESS:-false}" bash "$script" run "$proj_dir"
    fi
    return $?
}

# ============================================================
# PFP-098 Deep System Gate (L4/L5/L6) — v2040
# 「UIは綺麗だが中身が薄い」(一覧の企業名がクリックできない/データが空/モジュール
# 非連携) を出荷前に検出する。Layered Depth (L0-L3) の上に L4 データ充足 / L5 画面
# 連携(ドリルダウン) / L6 業務貫通 を測る。既定 WARN (非Strict)。
# ============================================================
phase_deep_system_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/deep-system-gate.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Deep System Gate スクリプト未配置 → phase_deep_system_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🏗️  [PFP-098] Deep System Gate - 深さ L4/L5/L6 (データ充足/ドリルダウン/業務貫通)${NC}"

    if [[ -n "${SOLOPTILINK_DETECTED_DBL:-}" ]]; then
        STRICT="${STRICT_DEEP_SYSTEM:-false}" DEEP_SYSTEM_MIN_LAYER="${DEEP_SYSTEM_MIN_LAYER:-L5}" bash "$script" run "$proj_dir" --dbl "${SOLOPTILINK_DETECTED_DBL}"
    else
        STRICT="${STRICT_DEEP_SYSTEM:-false}" DEEP_SYSTEM_MIN_LAYER="${DEEP_SYSTEM_MIN_LAYER:-L5}" bash "$script" run "$proj_dir"
    fi
    return $?
}

# ============================================================
# PFP-100 CRUD Input Capability Gate — v2038.x (2026-06-08)
# 「入力できる」を構造的に保証する。全業務エンティティが DB へ永続化される
# 新規作成/編集フォームを持つかを検証。create フォームが 1 つも無い完全閲覧専用
# システム (TWOSTONE&Sons 事案) は BLOCK = 生成停止 (Strict 不問)。
# ============================================================
phase_crud_input_capability_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/crud-input-capability-gate.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ CRUD Input Capability Gate スクリプト未配置 → phase_crud_input_capability_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}⌨️  [PFP-100] CRUD Input Capability Gate - 入力フォーム(新規作成/編集)の実在保証${NC}"
    STRICT_CRUD_INPUT="${STRICT_CRUD_INPUT:-false}" \
        CIC_CREATE_MIN="${CIC_CREATE_MIN:-60}" CIC_WRITE_MIN="${CIC_WRITE_MIN:-60}" \
        bash "$script" run "$proj_dir"
    return $?
}

# ============================================================
# PFP-106 Security Hardening Gate — v2038.x (2026-06-11)
# 生成物の実戦的セキュリティ標準装備を保証する。S1 セキュリティヘッダ /
# S2 レート制限 / S3 ログイン試行ロックアウト / S4 npm audit を検証し、
# 不足分は apply で安全に自動是正 (ファイル追加・ヘッダ注入のみ・破壊的変更なし)。
# S5 IDOR / S6 zod max / S7 機微カラム暗号化 は WARN で refiner へ。既定 非Strict。
# ============================================================
phase_security_hardening_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/security-hardening-gate.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Security Hardening Gate スクリプト未配置 → phase_security_hardening_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🛡️  [PFP-106] Security Hardening Gate - セキュリティヘッダ/レート制限/ロックアウト標準装備${NC}"
    STRICT_SECURITY_HARDENING="${STRICT_SECURITY_HARDENING:-false}" \
        bash "$script" apply "$proj_dir"
    return $?
}

# ============================================================
# PFP-107 Permission Matrix Gate - ロール×操作の権限マトリクス強制検証 — v2040 (2026-06-12)
# ============================================================
phase_permission_matrix_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/permission-matrix-gate.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Permission Matrix Gate - ロール×操作の権限マトリクス強制検証 スクリプト未配置 → phase_permission_matrix_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🔐 [PFP-107] Permission Matrix Gate - ロール×操作の権限マトリクス強制検証${NC}"
    STRICT_PERMISSION_MATRIX="${STRICT_PERMISSION_MATRIX:-false}" \
        bash "$script" apply "$proj_dir"
    return $?
}

# ============================================================
# PFP-108 Document Output Gate - 帳票・印刷・PDF出力保証 — v2040 (2026-06-12)
# ============================================================
phase_document_output_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/document-output-gate.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Document Output Gate - 帳票・印刷・PDF出力保証 スクリプト未配置 → phase_document_output_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🖨️ [PFP-108] Document Output Gate - 帳票・印刷・PDF出力保証${NC}"
    STRICT_DOCUMENT_OUTPUT="${STRICT_DOCUMENT_OUTPUT:-false}" \
        bash "$script" apply "$proj_dir"
    return $?
}

# ============================================================
# PFP-109 CSV I/O Gate - CSV入出力(BOM/プレビュー)保証 — v2040 (2026-06-12)
# ============================================================
phase_csv_io_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/csv-io-gate.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ CSV I/O Gate - CSV入出力(BOM/プレビュー)保証 スクリプト未配置 → phase_csv_io_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}📑 [PFP-109] CSV I/O Gate - CSV入出力(BOM/プレビュー)保証${NC}"
    STRICT_CSV_IO="${STRICT_CSV_IO:-false}" \
        bash "$script" apply "$proj_dir"
    return $?
}

# ============================================================
# PFP-110 Performance Baseline Gate - N+1/ページネーション/バンドル — v2040 (2026-06-12)
# ============================================================
phase_performance_baseline_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/performance-baseline-gate.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Performance Baseline Gate - N+1/ページネーション/バンドル スクリプト未配置 → phase_performance_baseline_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}⚡ [PFP-110] Performance Baseline Gate - N+1/ページネーション/バンドル${NC}"
    STRICT_PERFORMANCE_BASELINE="${STRICT_PERFORMANCE_BASELINE:-false}" \
        bash "$script" run "$proj_dir"
    return $?
}

# ============================================================
# PFP-111 Backup/Restore Gate - バックアップ標準装備 — v2040 (2026-06-12)
# ============================================================
phase_backup_restore_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/backup-restore-gate.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Backup/Restore Gate - バックアップ標準装備 スクリプト未配置 → phase_backup_restore_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}💾 [PFP-111] Backup/Restore Gate - バックアップ標準装備${NC}"
    STRICT_BACKUP_RESTORE="${STRICT_BACKUP_RESTORE:-false}" \
        bash "$script" apply "$proj_dir"
    return $?
}

# ============================================================
# PFP-115 Enterprise Integration Gate - 仕訳連動/在庫引当/承認WF — v2040 (2026-06-12)
# ============================================================
phase_enterprise_integration_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/enterprise-integration-gate.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Enterprise Integration Gate - 仕訳連動/在庫引当/承認WF スクリプト未配置 → phase_enterprise_integration_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi
    # 基幹システム級ビルドでなければ即スキップ (ゲート側も not_applicable を返すが二重防御)
    [[ -f "$proj_dir/.soloptilink/enterprise-blueprint.json" ]] || return 0

    echo -e "\n  ${CYAN}🏢 [PFP-115] Enterprise Integration Gate - 仕訳連動/在庫引当/承認WF${NC}"
    STRICT_ENTERPRISE_INTEGRATION="${STRICT_ENTERPRISE_INTEGRATION:-false}" \
        bash "$script" apply "$proj_dir"
    return $?
}

# ============================================================
# PFP-126 Runtime CRUD Smoke Gate - 実走CRUD検証(DB書込をトランザクション内で実証) — v2041 (2026-06-16)
# ============================================================
phase_runtime_crud_smoke_gate() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/runtime-crud-smoke.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Runtime CRUD Smoke Gate - 実走CRUD検証 スクリプト未配置 → phase_runtime_crud_smoke_gate をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🧪 [PFP-126] Runtime CRUD Smoke Gate - 実走CRUD検証(create→read→update→delete+rollback)${NC}"
    STRICT_RUNTIME_CRUD="${STRICT_RUNTIME_CRUD:-false}" \
        bash "$script" run "$proj_dir"
    return $?
}

# ============================================================
# Helper: Auto-Refiner プロンプト生成 (PFP-080 v2034.9)
# Layered Depth Gate FAIL 時に呼ばれ、層別不足項目を JSON で出力する。
# 実際の再生成は呼び出し元 (Claude LLM in Desktop / chain.sh claude -p in
# terminal) がこの JSON を読んで指示する。
# 出力ファイル: $proj_dir/.soloptilink/refiner-prompts.json
# ============================================================
_ldg_generate_refiner_prompt() {
    local proj_dir="$1"
    local result_file="$proj_dir/.soloptilink/layered-depth-results.json"
    local prompt_file="$proj_dir/.soloptilink/refiner-prompts.json"

    [[ ! -f "$result_file" ]] && return 1
    # 配信前監査D2: jq 不在環境では set -e 中断を避け Refiner プロンプト生成を graceful skip
    command -v jq >/dev/null 2>&1 || { echo -e "  ${YELLOW}⚠${NC} jq 不在のため Auto-Refiner プロンプト生成をスキップ" >&2; return 0; }

    local l1 l2 l3 coverage achieved dbl_name dbl_registered
    l1=$(jq -r '.layers.L1.status // "FAIL"' "$result_file" 2>/dev/null)
    l2=$(jq -r '.layers.L2.status // "FAIL"' "$result_file" 2>/dev/null)
    l3=$(jq -r '.layers.L3.status // "FAIL"' "$result_file" 2>/dev/null)
    coverage=$(jq -r '.industry_terminology_coverage.status // "FAIL"' "$result_file" 2>/dev/null)
    achieved=$(jq -r '.achieved_layer // "none"' "$result_file" 2>/dev/null)
    dbl_name=$(jq -r '.dbl.name // ""' "$result_file" 2>/dev/null)
    dbl_registered=$(jq -r '.dbl.registered // false' "$result_file" 2>/dev/null)

    # 層別補強指示を選定
    local instructions=()
    if [[ "$l1" != "PASS" ]]; then
        instructions+=("L1: DBL '$dbl_name' の pages[] を全件展開して業界専用画面を追加 (例: /seikyuu /jisshi-shidou /reward /monitoring など)")
    fi
    if [[ "$l2" != "PASS" ]]; then
        instructions+=("L2: DBL '$dbl_name' の models[] のうち業界マスタを schema.prisma に追加し、seed.ts に seed_data から全件投入。例: KasanMaster (加算マスタ20種) / RewardScheduleMaster (報酬単価マスタ) / QualificationMaster (資格マスタ)")
    fi
    if [[ "$l3" != "PASS" ]]; then
        instructions+=("L3: DBL '$dbl_name' の business_logic[] を src/lib/services/ に実コード化。名前だけのファイル禁止。例: calculateMonthlyReward (基本×日数×加算×地域区分の実計算) / checkKasanEligibility (加算20種要件チェック) / monitoringReminderCron (6ヶ月ルール)")
    fi
    if [[ "$coverage" != "PASS" ]]; then
        instructions+=("業界用語含有率不足: DBL keywords[] を grep して 100語+ (DBL未登録なら 150語+) になるよう各ページの description / コメント / placeholder / SEO 文言で補強")
    fi

    # JSON 配列に変換
    local instructions_json
    instructions_json='[]'
    [[ ${#instructions[@]} -gt 0 ]] && instructions_json=$(printf '%s\n' "${instructions[@]}" | jq -R . 2>/dev/null | jq -s . 2>/dev/null || echo '[]')

    # 最終 JSON 出力
    jq -n \
        --arg version "v2034.9" \
        --arg gate "PFP-080 Auto-Refiner" \
        --arg ts "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" \
        --arg dbl "$dbl_name" \
        --argjson reg "$dbl_registered" \
        --arg achieved "$achieved" \
        --arg l1 "$l1" --arg l2 "$l2" --arg l3 "$l3" --arg cov "$coverage" \
        --argjson instructions "$instructions_json" \
        --arg max "${MAX_REFINER_ITERATIONS:-3}" \
        '{
          version: $version,
          gate: $gate,
          triggered_at: $ts,
          dbl_name: $dbl,
          dbl_registered: $reg,
          achieved_layer: $achieved,
          failed_checks: {L1: $l1, L2: $l2, L3: $l3, coverage: $cov},
          refiner_instructions: $instructions,
          max_iterations: ($max | tonumber),
          next_action: "上位 Claude (LLM) または chain.sh main_flow がこの prompts を読んで再生成を指示。Claude Code Desktop 環境では Step 2.A シーケンシャル 105 協調モードで Refiner ロールが本JSON を入力として補強実装する"
        }' > "$prompt_file" 2>/dev/null

    echo -e "\n  ${YELLOW}🔧 [PFP-080 Auto-Refiner] 補強指示を生成: $prompt_file${NC}" >&2
    for ins in "${instructions[@]}"; do
        echo -e "  ${DIM}  • $ins${NC}" >&2
    done
}

# ============================================================
# Phase: customer_error_reporter (PFP-033 顧客側送信コード配備) — 2026-05-27
# ============================================================
# 「受信API は完成しているのに顧客端末からエラーが届かず偽陽性 HEALTHY」事案
# (2026-05-15 Failure Intelligence + Customer Error Tracking 数ヶ月無送信) を
# 構造的に根絶する。生成済プロジェクトに以下を配置:
#   - <project>/lib/customer-error-reporter.ts
#   - <project>/app/global-error.tsx
#   - <project>/.env.example に NEXT_PUBLIC_CUSTOMER_ERROR_REPORTING_URL
# 環境変数: ENABLE_CUSTOMER_ERROR_REPORTER (default true)
# ============================================================
phase_customer_error_reporter() {
    local session_id="$1" task_desc="$2"
    local target_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo ".")}"

    _log "INFO" "Phase: customer_error_reporter - target=$target_dir"

    local injector="$HOME/.soloptilink/scripts/structural-defenses/pfp-033-error-reporter-injector.sh"
    if [[ ! -x "$injector" ]]; then
        echo -e "  ${YELLOW}⚠️ PFP-033 injector 未配置、phase_customer_error_reporter をスキップ${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}📡 [PFP-033] Customer Error Reporter Injection${NC}"

    local tmp_log
    tmp_log=$(mktemp)
    local ec=0
    bash "$injector" --apply --json "$target_dir" >"$tmp_log" 2>&1 || ec=$?

    if [[ $ec -eq 2 ]]; then
        echo -e "  ${YELLOW}  ℹ Customer Error Reporter: Next.js プロジェクトではない (SKIP)${NC}"
        rm -f "$tmp_log"
        return 0
    fi

    if [[ $ec -ne 0 ]]; then
        echo -e "  ${RED}  ❌ Customer Error Reporter Injection FAIL (ec=$ec)${NC}" >&2
        cat "$tmp_log" >&2 || true
        rm -f "$tmp_log"
        return 1
    fi

    local verdict
    verdict=$(grep -oE '"verdict"\s*:\s*"[^"]+"' "$tmp_log" | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
    case "$verdict" in
        applied)
            echo -e "  ${GREEN}  ✅ Customer Error Reporter: 配備完了${NC}"
            ;;
        skip)
            echo -e "  ${YELLOW}  ℹ Customer Error Reporter: SKIP${NC}"
            ;;
        *)
            echo -e "  ${YELLOW}  ⚠️ Customer Error Reporter: verdict=${verdict:-unknown}${NC}"
            ;;
    esac

    rm -f "$tmp_log"
    return 0
}

# ============================================================
# Phase: mega_portal_check (PFP-083 大規模ポータル品質保証) — 2026-05-29
# ============================================================
# 不動産ポータル/求人ポータル/中古車ポータル等の「数百万件規模 × 高速配信」
# プラットフォームを HOMES/SUUMO/athome と同等の品質で構築するための
# 13軸検証 (next/image / ISR / sharp / 動的sitemap / 構造化データ / Edge Runtime 等)。
# DBL が mega-portal カテゴリ (例: real-estate-portal) の時、または
# --portal-scale large 指定時、または ENABLE_MEGA_PORTAL_GATE=true の時に起動。
# 環境変数: ENABLE_MEGA_PORTAL_GATE / STRICT_MEGA_PORTAL / MEGA_PORTAL_MIN_PASS
# ============================================================
phase_mega_portal_check() {
    local session_id="$1" task_desc="$2"
    local target_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo ".")}"

    _log "INFO" "Phase: mega_portal_check - target=$target_dir"

    local script="${SCRIPT_DIR}/lib/first-boot-perfect/mega-portal-gate.sh"
    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ mega-portal-gate.sh 未配置、phase_mega_portal_check をスキップ${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🏙  [PFP-083] Mega Portal Gate (13軸検証)${NC}"

    local tmp_log
    tmp_log=$(mktemp)
    local ec=0
    local mode="run"
    [[ "${MEGA_PORTAL_AUTO_HEAL:-true}" == "true" ]] && mode="apply"
    bash "$script" "$mode" "$target_dir" >"$tmp_log" 2>&1 || ec=$?
    cat "$tmp_log" >&2
    rm -f "$tmp_log"

    if [[ $ec -ne 0 ]]; then
        echo -e "  ${RED}❌ Mega Portal Gate FAIL (詳細: ${target_dir}/.soloptilink/mega-portal-results.json)${NC}" >&2
        return 1
    fi
    return 0
}

# ============================================================
# Phase: image_cms_check (PFP-084 画像CMS品質保証) — 2026-05-29
# ============================================================
# 管理ユーザー (不動産Agent/ECショップ管理者) が大量画像を
# 「ドラッグ&ドロップ並列アップロード + 自動圧縮 + WebP/AVIF変換 + EXIF削除
#  + サムネ4サイズ生成 + CDN URL返却」までを一発で済ませる体験を保証する。
# 10軸検証 (S3互換 / sharp / react-dropzone / 並列 / 進捗 / WebP+AVIF / サムネ /
#         EXIF削除 / バリデーション / CDN URL)。
# 環境変数: ENABLE_IMAGE_CMS_GATE / STRICT_IMAGE_CMS / IMAGE_CMS_STORAGE
# ============================================================
phase_image_cms_check() {
    local session_id="$1" task_desc="$2"
    local target_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo ".")}"

    _log "INFO" "Phase: image_cms_check - target=$target_dir"

    local script="${SCRIPT_DIR}/lib/first-boot-perfect/image-cms-gate.sh"
    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ image-cms-gate.sh 未配置、phase_image_cms_check をスキップ${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🖼  [PFP-084] Image CMS Gate (10軸検証)${NC}"

    local tmp_log
    tmp_log=$(mktemp)
    local ec=0
    local mode="run"
    [[ "${IMAGE_CMS_AUTO_HEAL:-true}" == "true" ]] && mode="apply"
    bash "$script" "$mode" "$target_dir" >"$tmp_log" 2>&1 || ec=$?
    cat "$tmp_log" >&2
    rm -f "$tmp_log"

    if [[ $ec -ne 0 ]]; then
        echo -e "  ${RED}❌ Image CMS Gate FAIL (詳細: ${target_dir}/.soloptilink/image-cms-results.json)${NC}" >&2
        return 1
    fi
    return 0
}

# ============================================================
# Helper: mega-portal カテゴリ判定 (DBL 検出結果から)
# ============================================================
_is_mega_portal_context() {
    # 明示的指定が最優先
    [[ "${MEGA_PORTAL_FORCE:-false}" == "true" ]] && return 0
    [[ "${PORTAL_SCALE:-}" == "large" ]] && return 0
    [[ "${ENABLE_MEGA_PORTAL_GATE:-}" == "true" ]] && return 0

    # DBL Auto-Detect 結果から判定
    local dbl="${SOLOPTILINK_DETECTED_DBL:-}"
    case "$dbl" in
        real-estate-portal|*-portal|job-portal|car-portal|travel-portal|news-portal)
            return 0
            ;;
    esac

    # DBL JSON の category=mega-portal フィールドで判定
    if [[ -n "$dbl" ]] && [[ -f "$HOME/.soloptilink/domains/${dbl}.json" ]]; then
        local cat
        cat=$(jq -r '.category // ""' "$HOME/.soloptilink/domains/${dbl}.json" 2>/dev/null)
        [[ "$cat" == "mega-portal" ]] && return 0
    fi

    return 1
}

# ============================================================
# Phase: output_watermark (PFP-082 OWG / v2034.10) — 2026-05-29
# ============================================================
# 生成プロジェクト配下の主要ファイル (*.tsx / *.ts / *.prisma / *.sql / *.md /
# *.py) の先頭に Trade-Secret Watermark を自動注入する。
# - 対象外: package.json / .env* / node_modules / prisma/client / migration
# - validator.sh --apply モードで注入 + 注入率 95%+ を検証
# - 環境変数: ENABLE_OUTPUT_WATERMARK / STRICT_OUTPUT_WATERMARK / OWG_THRESHOLD
# ============================================================
phase_output_watermark() {
    local session_id="$1" task_desc="$2"
    local target_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo ".")}"

    _log "INFO" "Phase: output_watermark - target=$target_dir"

    local script="$HOME/.soloptilink/scripts/structural-defenses/pfp-082-watermark-validator.sh"
    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ pfp-082-watermark-validator.sh 未配置、phase_output_watermark をスキップ${NC}" >&2
        return 0
    fi

    if [[ ! -d "$target_dir" ]] || { [[ "$target_dir" == "." ]] && [[ -z "${PROJECT_DIR:-}" ]]; }; then
        echo -e "  ${YELLOW}⚠️ PROJECT_DIR 未確定 → Watermark 注入をスキップ${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}©  [PFP-082] Output Watermark Gate (Trade-Secret 通告注入)${NC}"

    local tmp_log
    tmp_log=$(mktemp)
    local ec=0
    local threshold="${OWG_THRESHOLD:-95}"
    bash "$script" "$target_dir" --apply --threshold "$threshold" >"$tmp_log" 2>&1 || ec=$?
    cat "$tmp_log" >&2
    rm -f "$tmp_log"

    if [[ $ec -ne 0 ]]; then
        echo -e "  ${RED}❌ Output Watermark Gate FAIL (注入率 ${threshold}% 未達)${NC}" >&2
        return 1
    fi
    return 0
}

# ============================================================
# Phase: auto_update (PFP-095 AUPE / 本体機能拡張) — 2026-06-06
# ============================================================
# 生成プロジェクトに「出荷後の自動アップデートパッチ機構 (AUPE)」の軽量クライアント
# (脆弱性 NVD/OSV・依存 npm audit・法令 e-Gov・OS/API 変化の追従土台) を標準装備する。
# 非破壊 (既存 package.json を壊さない)。ビルド時は重い初回スキャンを延期し装備のみ
# (AUPE_INITIAL_SCAN=false)。実スキャンは生成物の定期バッチ / 管理側 aupe-batch が担う。
# 環境変数: ENABLE_AUTO_UPDATE_PHASE (default: false=オプトイン) / STRICT_AUTO_UPDATE (default: false)
# 既定 OFF: 既存顧客ビルドの挙動を変えないため。配信判断で有効化する。
# ============================================================
phase_auto_update() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/auto-update-phase.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Auto-Update Phase スクリプト未配置 → phase_auto_update をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🔄 [PFP-095] Auto-Update Patch Engine - 出荷後自動追従クライアント装備${NC}"

    STRICT_AUTO_UPDATE="${STRICT_AUTO_UPDATE:-false}" \
    AUPE_INITIAL_SCAN="${AUPE_INITIAL_SCAN:-false}" \
    bash "$script" run "$proj_dir"
    return $?
}

# ============================================================
# Phase: uat_loop (PFP-096 KUT / 本体機能拡張) — 2026-06-06
# ============================================================
# 「画面とボタンは並んだが裏側のデータ (マスタ/関連/業務ロジック/集計/結線) が
# 揃っていない」生成物を出荷前に軽量検証する (Data Completeness Gate)。サーバ不要。
# 重い UAT 生成/Playwright 実行は既定 OFF (ENABLE_UAT_FEEDBACK=false)。
# 環境変数: ENABLE_UAT_LOOP (default: false=オプトイン) / STRICT_UAT_LOOP (default: false)
#           MAX_UAT_ITERATIONS (default: 3)
# 既定 OFF: 既存顧客ビルドの挙動を変えないため。配信判断で有効化する。
# ============================================================
phase_uat_loop() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/uat-loop.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ UAT Loop スクリプト未配置 → phase_uat_loop をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🧪 [PFP-096] KUT UAT Loop - データ完全性検証${NC}"

    STRICT_UAT_LOOP="${STRICT_UAT_LOOP:-false}" \
    MAX_UAT_ITERATIONS="${MAX_UAT_ITERATIONS:-3}" \
    ENABLE_UAT_FEEDBACK="${ENABLE_UAT_FEEDBACK:-false}" \
    bash "$script" run "$proj_dir"
    return $?
}

# ============================================================
# Phase: build_dev_hygiene (PFP-092 / 本体機能拡張) — 2026-06-06
# ============================================================
# 生成プロジェクトの DB provider/URL 整合 (schema=postgresql vs DATABASE_URL=file: の
# 不一致で全DBクエリが Validation Error → health 503・ログイン不可になる事故) を静的に
# 検査し file:→sqlite を安全是正する。ビルド帯ではサーバ未起動のため、HTTP スモークを
# 伴う check/serve-prod ではなく、サーバ不要の apply (静的整合 + 安全是正のみ) を実行する。
# デモ受け渡し時の本番サーバ HTTP スモーク (ログアウト 500 検出) は SKILL.md 手順
# (serve-prod/check) で別途実施し、その verdict も同 build-dev-hygiene.json に記録される。
# その結果は完成ゲート hook (boost-completion-gate-hook.sh) が読み、FAIL/BLOCK なら完成宣言をブロックする。
# 環境変数: ENABLE_BUILD_DEV_HYGIENE (default: false=オプトイン) / STRICT_BUILD_DEV_HYGIENE (default: false)
# 既定 OFF: apply は schema.prisma を書き換えるため既存顧客ビルドの挙動を変えない。配信判断で有効化する。
# (2026-06-06 本体監査: 373行実装済だが chain.sh/hook/verify-all の3点とも未配線の孤児を配線)
# ============================================================
phase_build_dev_hygiene() {
    local session_id="$1" task_desc="${2:-}"
    local script="${SCRIPT_DIR}/lib/first-boot-perfect/build-dev-hygiene-gate.sh"

    if [[ ! -x "$script" ]]; then
        echo -e "  ${YELLOW}⚠️ Build/Dev Hygiene Gate スクリプト未配置 → phase_build_dev_hygiene をスキップ${NC}" >&2
        return 0
    fi

    local proj_dir="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
    if [[ ! -d "$proj_dir" ]] || [[ ! -f "$proj_dir/package.json" ]]; then
        echo -e "  ${YELLOW}⚠️ プロジェクトディレクトリ未確定でスキップ: $proj_dir${NC}" >&2
        return 0
    fi

    echo -e "\n  ${CYAN}🧹 [PFP-092] Build/Dev Hygiene - DB provider/URL 整合検査・安全是正${NC}"

    # ビルド帯はサーバ未起動のため apply のみ (静的整合 + file:→sqlite 安全是正)。
    # HTTP スモークを伴う check/serve-prod はデモ受け渡し時に SKILL.md 手順で別途実施する。
    bash "$script" apply "$proj_dir"
    return $?
}

# ============================================================
# メイン実行フロー
# ============================================================
main() {
    # フェーズ完了カウンター（ランチャーが読み取る）
    export _COMPLETED_PHASE_COUNT=0

    # ============ プリフライトチェック（lib/core/session.sh に委譲）============
    if type -t session_preflight &>/dev/null; then
        session_preflight || exit 1
    else
        # フォールバック: 基本チェック
        if [[ ${BASH_VERSINFO[0]} -lt 4 ]]; then
            echo -e "${RED}エラー: Bash 4.0以上が必要です（現在: ${BASH_VERSION}）${NC}"
            exit 2
        fi
        if ! command -v claude &>/dev/null; then
            echo -e "${RED}エラー: claude CLI がインストールされていません${NC}"
            exit 2
        fi
        if ! command -v timeout &>/dev/null; then
            if command -v gtimeout &>/dev/null; then
                timeout() { gtimeout "$@"; }
            else
                timeout() { shift; "$@"; }
            fi
        fi
    fi

    # バナー表示（lib/core/cli-parser.sh に委譲）
    if type -t show_banner &>/dev/null; then
        show_banner
    else
        echo -e "${BOLD}SoloptiLink Chain v${VERSION}${NC}"
    fi

    # 初回セットアップチェック
    local _sentinel="${SCRIPT_DIR}/.soloptilink_initialized"
    if [[ ! -f "$_sentinel" ]]; then
        echo ""
        echo -e "${BOLD}${CYAN}╔═══════════════════════════════════════════════╗${NC}"
        echo -e "${BOLD}${CYAN}║  初回セットアップを検出しました                  ║${NC}"
        echo -e "${BOLD}${CYAN}╚═══════════════════════════════════════════════╝${NC}"
        echo ""
        if [[ -f "${SCRIPT_DIR}/setup.sh" ]]; then
            echo -e "  ${YELLOW}setup.sh を実行してモジュールの整合性を確認します...${NC}"
            echo ""
            bash "${SCRIPT_DIR}/setup.sh" || true
        fi
        # センチネルファイル作成（setup.shが作成しなかった場合のフォールバック）
        if [[ ! -f "$_sentinel" ]]; then
            date '+%Y-%m-%d %H:%M:%S' > "$_sentinel" 2>/dev/null || true
        fi
        echo ""
    fi

    echo -e "${BOLD}ライブラリ読み込み中...${NC}"
    _load_libraries
    echo ""

    # 引数パース
    _parse_args "$@"

    # ============================================================
    # v2008.6: ライセンス認証（license-guard.sh 配線）
    # サーバー承認済み端末のみ実行許可。バイパス不可。
    # 環境変数によるスキップは廃止済み（セキュリティ強化）
    # ============================================================
    # セキュリティ: SOLOPTILINK_SKIP_LICENSE を明示的に無効化（バイパス防止）
    unset SOLOPTILINK_SKIP_LICENSE 2>/dev/null || true
    if type -t lg_check_license &>/dev/null; then
        echo -e "${BOLD}端末認証中...${NC}"
        if ! lg_check_license; then
            echo -e "${RED}╔═══════════════════════════════════════════════════════╗${NC}" >&2
            echo -e "${RED}║  ライセンス認証に失敗しました                         ║${NC}" >&2
            echo -e "${RED}║  SoloptiLinkAIを使用するには:                         ║${NC}" >&2
            echo -e "${RED}║  1. 有効なライセンスキーの登録                         ║${NC}" >&2
            echo -e "${RED}║  2. 管理者による端末承認                               ║${NC}" >&2
            echo -e "${RED}║  が必要です。                                          ║${NC}" >&2
            echo -e "${RED}╚═══════════════════════════════════════════════════════╝${NC}" >&2
            echo "" >&2
            echo -e "  ${CYAN}アクティベーション: ./soloptilink --activate${NC}" >&2
            echo -e "  ${CYAN}ステータス確認:     ./soloptilink --status${NC}" >&2
            echo -e "  ${CYAN}自己診断:           ./soloptilink --diagnose${NC}" >&2
            echo -e "  ${CYAN}サポート窓口:       support@soloptilink.com${NC}" >&2
            exit 1
        fi
        echo ""
    else
        # 認証モジュールが正しくロードされていない場合 (顧客向け文言・PFP-047対策)
        echo -e "${RED}╔═══════════════════════════════════════════════════════╗${NC}" >&2
        echo -e "${RED}║  SoloptiLinkAI の初期化に問題が発生しました           ║${NC}" >&2
        echo -e "${RED}║  以下のコマンドで自動修復をお試しください             ║${NC}" >&2
        echo -e "${RED}╚═══════════════════════════════════════════════════════╝${NC}" >&2
        echo "" >&2
        echo -e "  ${CYAN}自己診断:        ./soloptilink --diagnose${NC}" >&2
        echo -e "  ${CYAN}最新版に更新:    ./soloptilink --update${NC}" >&2
        echo -e "  ${CYAN}サポート窓口:    support@soloptilink.com${NC}" >&2
        exit 1
    fi

    # v24.0: Config Validator - 設定値の整合性検証
    if type -t cv_validate_all &>/dev/null; then
        cv_validate_all
        if [[ $CV_ERROR_COUNT -gt 0 ]]; then
            cv_report
            exit 1
        elif [[ $CV_WARN_COUNT -gt 0 ]]; then
            cv_report
        fi
    fi

    # ============================================================
    # v2034.10: PFP-081 Self-Replication Prohibition Gate
    # main_flow 冒頭で TASK_DESC を走査し、SoloptiLinkAI 自体の
    # クローン/リバースエンジニアリング/派生フレームワーク作成
    # 依頼を構造的に検知・拒否する。Strict mode (default: true)
    # で検知時は exit 1 で生成停止。
    # ============================================================
    # ============ v2040 (PFP-117): 進捗エンジン開始 (5マイルストーン) ============
    if [[ -f "${SCRIPT_DIR}/lib/progress-engine.sh" ]]; then
        source "${SCRIPT_DIR}/lib/progress-engine.sh" 2>/dev/null || true
        type -t progress_start &>/dev/null && progress_start "${PROJECT_DIR:-$(pwd)}" 5 2>/dev/null || true
    fi

    if [[ -n "${TASK_DESC:-}" ]] && type -t phase_self_replication_gate &>/dev/null; then
        phase_self_replication_gate "${SESSION_ID:-startup}" "$TASK_DESC"
    fi

    # ============================================================
    # REQ-WIRE-004 (v2037): PFP-056 退避ガード マーカー writer
    # chain.sh が「正規 builder」として駆動中であることを記録する。
    #  - SOLOPTILINK_CHAIN_DRIVING=1: ガードが chain.sh 自身の claude -p 書込みを
    #    退避と誤判定しないための自己免除フラグ (hook へ env 継承)。
    #  - .boost_session_active.json: terminal モードでのみ生成。Desktop (CLAUDECODE=1)
    #    は chain.sh が動かず Step 2 直接実装が正規 [[pfp-068]] のため生成しない
    #    (=Desktop の正規生成をガードで誤ブロックしない)。
    # ============================================================
    export SOLOPTILINK_CHAIN_DRIVING=1
    if [[ "${CLAUDECODE:-0}" != "1" ]] && [[ -n "${TASK_DESC:-}" ]]; then
        printf '{"boost_active":true,"session_start":"%s","session_id":"%s","version":"%s","driver":"chain.sh"}\n' \
            "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "${SESSION_ID:-startup}" "$VERSION" \
            > "${HOME}/.soloptilink/.boost_session_active.json" 2>/dev/null || true
    fi

    # ============================================================
    # v2037.0: PFP-090 Secret-in-Prompt Protection (shield-bootstrap 配線 / G1・AKP17)
    # 顧客が CLI 引数/プロンプト (TASK_DESC) に入れた API キーを、claude へ渡る前に
    # OS Keychain へ退避し handle 置換する (LR3: ps aux 漏洩の構造的解消)。
    # local-prompt-shield 未配線/node・jq 不在環境では透過 (顧客の自由を尊重)。
    # ============================================================
    if [[ -f "${SCRIPT_DIR}/lib/shield-bootstrap.sh" ]]; then
        source "${SCRIPT_DIR}/lib/shield-bootstrap.sh" 2>/dev/null || true
        if type -t sb_scrub_cli_args &>/dev/null && [[ -n "${TASK_DESC:-}" ]]; then
            sb_scrub_cli_args "$TASK_DESC" || true
            if [[ "${SHIELD_REDACTION_COUNT:-0}" =~ ^[0-9]+$ ]] && (( SHIELD_REDACTION_COUNT > 0 )); then
                TASK_DESC="${SHIELD_SCRUBBED_ARGS[0]:-$TASK_DESC}"
            fi
        fi
        type -t sb_first_run_check &>/dev/null && sb_first_run_check || true
    fi

    # ============ 特殊モードの処理 ============

    # バリデーションのみモード
    if [[ -n "${VALIDATE_DIR}" ]]; then
        _validate_mode "$VALIDATE_DIR" "$AUTO_FIX"
        exit $?
    fi

    # v11.0: セキュリティスキャンのみモード
    if [[ -n "${SECURITY_SCAN_ONLY}" ]]; then
        echo -e "\n${BOLD}${CYAN}╔═══════════════════════════════════════════╗${NC}"
        echo -e "${BOLD}${CYAN}║     セキュリティスキャン専用モード (v11.0)   ║${NC}"
        echo -e "${BOLD}${CYAN}╚═══════════════════════════════════════════╝${NC}\n"

        local scan_dir="${SECURITY_SCAN_ONLY}"
        mkdir -p "${SESSION_LOG_DIR}" 2>/dev/null || true

        if [[ "${SECURITY_AUTO_FIX}" == "true" ]]; then
            echo -e "  ${PURPLE}セキュリティ自動修正モード有効${NC}"
            _security_gate "$scan_dir"
        else
            # スキャンのみ（修正なし）
            local sg_report=""
            local dep_report=""
            if type -t sg_run_all &>/dev/null; then
                echo -e "  ${BOLD}[1/2] OWASPセキュリティスキャン...${NC}"
                sg_report=$(sg_run_all "$scan_dir" 2>/dev/null || echo "")
                echo -e "  ${GREEN}✅ OWASPスキャン完了${NC}"
                [[ -n "$sg_report" ]] && echo "$sg_report"
            else
                echo -e "  ${YELLOW}⚠️ security-guard.sh 未ロード${NC}"
            fi
            if type -t dep_audit_run_all &>/dev/null; then
                echo -e "  ${BOLD}[2/2] 依存関係セキュリティ監査...${NC}"
                dep_report=$(dep_audit_run_all "$scan_dir" 2>/dev/null || echo "")
                echo -e "  ${GREEN}✅ 依存関係監査完了${NC}"
                [[ -n "$dep_report" ]] && echo "$dep_report"
            else
                echo -e "  ${YELLOW}⚠️ dep-audit.sh 未ロード${NC}"
            fi

            # レポート保存
            local report_file="${SESSION_LOG_DIR}/security_scan_report.md"
            cat > "$report_file" <<EOF
# セキュリティスキャンレポート (v${VERSION})
- 日時: $(date '+%Y-%m-%d %H:%M:%S')
- 対象: ${scan_dir}

## OWASPスキャン
${sg_report:-（未実行）}

## 依存関係監査
${dep_report:-（未実行）}
EOF
            echo -e "\n  📄 レポート: ${report_file}"
        fi
        exit 0
    fi

    # チェックポイント再開モード
    if [[ "${RESUME_MODE}" == "true" ]]; then
        _resume_from_checkpoint
        exit $?
    fi

    # チェックポイント一覧モード
    if [[ "${SHOW_CHECKPOINTS}" == "true" ]]; then
        if type -t checkpoint_list &>/dev/null; then
            checkpoint_list ""
        else
            echo -e "${RED}チェックポイントモジュールが未ロードです${NC}"
        fi
        exit 0
    fi

    # v55.0: iOS セットアップガイドモード（早期終了）
    if [[ "${IOS_DEPLOY_TARGET:-}" == "setup-guide" ]]; then
        echo -e "\n${BOLD}${PURPLE}╔═══════════════════════════════════════════╗${NC}"
        echo -e "${BOLD}${PURPLE}║  iOS App Store / TestFlight セットアップ   ║${NC}"
        echo -e "${BOLD}${PURPLE}╚═══════════════════════════════════════════╝${NC}\n"
        if type -t idp_init &>/dev/null; then
            idp_init "${TASK_DESC:-.}"
            idp_check_prerequisites 2>/dev/null || true
            idp_setup_prerequisites_guide
        else
            echo -e "${YELLOW}ios-deploy-pipeline.sh が読み込まれていません${NC}"
            echo -e "lib/ios-deploy-pipeline.sh が存在するか確認してください"
        fi
        exit 0
    fi

    # タスク説明チェック
    if [[ -z "$TASK_DESC" ]]; then
        echo -e "${RED}タスク説明を指定してください${NC}"
        echo "Usage: ./chain.sh \"タスク説明\" [--pipeline quick|standard|deep|hotfix]"
        exit 1
    fi

    # ============ セッションセットアップ（lib/core/session.sh に委譲）============

    if type -t session_init &>/dev/null; then
        session_init "$SCRIPT_DIR"
    else
        mkdir -p "${SESSION_LOG_DIR}" docs/knowledge docs/chain-logs 2>/dev/null || true
    fi

    # ============ v2028.2: Learning Fetcher (中央DB→端末ローカルキャッシュ) ============
    # 中央 admin-dashboard から「他の顧客が実際に踏んだエラーパターン」を fetch して
    # ローカルキャッシュ更新。staleness 24h で自動再取得。失敗はサイレント。
    # 取得結果は prompt-compiler が Predictive Foresight として Claude プロンプトに注入。
    if [[ -f "${HOME}/.soloptilink/lib/learning-pipeline/learning-fetcher.sh" ]]; then
        # shellcheck source=/dev/null
        source "${HOME}/.soloptilink/lib/learning-pipeline/learning-fetcher.sh" 2>/dev/null || true
        lf_init 2>/dev/null || true
        if type -t lf_should_refetch &>/dev/null && lf_should_refetch; then
            (lf_fetch >/dev/null 2>&1 &) || true  # バックグラウンドで取得 (起動遅延ゼロ)
        fi
    fi

    # ロック取得（lib/core/session.sh に委譲）
    if type -t session_acquire_lock &>/dev/null; then
        session_acquire_lock || exit 1
    else
        if [[ -f "$LOCK_FILE" ]]; then
            local lock_pid
            lock_pid=$(cat "$LOCK_FILE" 2>/dev/null || echo "")
            if [[ -n "$lock_pid" ]] && kill -0 "$lock_pid" 2>/dev/null; then
                echo -e "${RED}別のチェーンが実行中です (PID: ${lock_pid})${NC}"
                exit 1
            fi
        fi
        echo $$ > "$LOCK_FILE"
    fi
    trap '_cleanup' EXIT INT TERM

    # v11.0: permissions.sh 初期化
    if type -t perm_init &>/dev/null; then
        perm_init "."
    fi

    # v12.0: コンテキストエンジン初期化
    if type -t ctx_init &>/dev/null; then
        ctx_init "$SESSION_ID" "$SESSION_LOG_DIR"
    fi

    # ============ モジュール初期化 (lib/chain-utils.sh _init_all_modules) ============
    _init_all_modules

    type -t progress_milestone &>/dev/null && progress_milestone "${PROJECT_DIR:-$(pwd)}" 1 "ご要望を分析しています" 2>/dev/null || true

    # ============ v28.0: Consultant Engine（コンサル対話） ============

    # URL駆動モードでなければ、まずコンサルタント対話を実行
    if [[ ${#URLS[@]} -eq 0 && "${CE_SKIP_CONSULTATION:-0}" != "1" ]]; then
        phase_consultation "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ コンサルテーションに問題（続行）${NC}"
    fi

    # ============ v2034.9 NEW (PFP-080): DBL Auto-Detect (Step 0.8) ============
    # 事業推論結果から ~/.soloptilink/domains/*.json と突合し、業種 DBL を自動推測。
    # SOLOPTILINK_DETECTED_DBL 環境変数として後続 phase_layered_depth_gate に伝播。
    # 未登録業種なら推奨メッセージのみ出力 (BLOCKING しない)。
    if [[ "${ENABLE_DBL_DETECT:-true}" == "true" ]]; then
        phase_dbl_detect "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ DBL Auto-Detect に問題（続行）${NC}"
        # REQ-WIRE-003: IBL 外部連携 Auto-Detect (DBL検出直後・非ブロッキング・オプトイン)
        phase_ibl_detect "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ IBL Auto-Detect に問題（続行）${NC}"
    fi

    # ============ v2048 NEW (可変開発層数): Scale Planner (規模層 SL 自動判定) ============
    # タスクから「業務サブシステム(規模層 SL)の数=横の規模」を分析し、SOLOPTILINK_TARGET_LAYERS /
    # SOLOPTILINK_LAYER_PLAN を export する(DBL 検出直後=DBL の models 数を加味できる位置)。
    # 後続 phase_smart_generation が SG_LAYER_PLAN として生成プロンプトへ注入する。
    # 検証段数(validator 5層)・到達度(L0-L3)とは別軸。非ブロッキング・追記のみ・phase関数を増やさず
    # インライン source(doctor 到達数 不変)。kill-switch: SOLOPTILINK_SCALE_PLANNER=off で完全 no-op。
    if [[ "${SOLOPTILINK_SCALE_PLANNER:-on}" != "off" ]] && [[ -f "${SCRIPT_DIR}/lib/scale-planner.sh" ]]; then
        # shellcheck disable=SC1091
        source "${SCRIPT_DIR}/lib/scale-planner.sh" 2>/dev/null \
            && sp_plan "$TASK_DESC" "${SOLOPTILINK_DETECTED_DBL:-general}" "$(pwd)" 2>/dev/null || true
        if [[ -n "${SOLOPTILINK_TARGET_LAYERS:-}" ]]; then
            echo -e "  ${GREEN}🧩 規模分析: ${SOLOPTILINK_TARGET_LAYERS}層構成 (${SOLOPTILINK_SCALE_MODE:-one-shot})${NC}"
            # ≥11層(staged-mandatory)は群分割の段階生成で実行(phase_smart_generation が ssg_execute へ分岐)。
            # 6-10層(staged-recommended)は既定一発・ENABLE_SCALE_STAGED=on で段階化可。乖離時は推定で続行。
            if [[ "${SOLOPTILINK_SCALE_MODE:-}" == "staged-mandatory" ]]; then
                echo -e "  ${YELLOW}🧩 大規模のため群に分けた段階生成で進めます(規模の絞り込みご希望時はお知らせください)${NC}"
            elif grep -q '"divergence": *"' "$(pwd)/.soloptilink/scale-plan.json" 2>/dev/null; then
                echo -e "  ${YELLOW}🧩 ご依頼の規模感に幅があるため推定で進めます(規模のご希望があればお知らせください)${NC}"
            fi
        fi
    fi

    # ============ v2032.0 (配線復旧 REQ-COMPLETION-GUARANTEE-001): Cognitive Frustration Detector (CFD) ============
    # ユーザー発言から「困っている / 一発でできない領域」を検出し、当該領域の検証を最優先化する。
    # 非ブロッキング (検出・レポート生成のみ)。doctor L2 配線検証で参照確認。無効化: ENABLE_COGNITIVE_FRUSTRATION=false
    if [[ "${ENABLE_COGNITIVE_FRUSTRATION:-true}" == "true" ]] && [[ -f "${SCRIPT_DIR}/lib/first-boot-perfect/cognitive-frustration-detector.sh" ]]; then
        bash "${SCRIPT_DIR}/lib/first-boot-perfect/cognitive-frustration-detector.sh" run "$TASK_DESC" "$(pwd)" 2>/dev/null || true
    fi

    # ============ v38.0: Phase Optimizer プロジェクト分析 ============
    if type -t po_analyze_project &>/dev/null; then
        po_analyze_project "$TASK_DESC" 2>/dev/null || true
        if [[ -n "${PO_PROJECT_TYPE:-}" ]]; then
            echo -e "  ${GREEN}🎯 v38.0 Phase Optimizer: ${PO_PROJECT_TYPE} (${PO_COMPLEXITY}) → ${PO_PHASES_SKIPPED:-0}フェーズスキップ可能${NC}"
        fi
    fi

    # ============ v53.0: Living System 推薦設定＋能動的適用 ============
    if type -t ls_recommend_config &>/dev/null; then
        local _ls_config
        _ls_config=$(ls_recommend_config "$TASK_DESC" 2>/dev/null || echo "")
        if [[ -n "$_ls_config" ]]; then
            echo -e "  ${GREEN}🧠 v40.0 Living System: 推薦設定 → ${_ls_config}${NC}"
        fi
        # v53.0: 推薦を実際の変数に適用
        if type -t ls_apply_recommendations &>/dev/null; then
            ls_apply_recommendations "$TASK_DESC" 2>/dev/null || true
        fi
    fi

    # ============ v44.0: Cross-Session Intelligence 分析 ============
    if type -t cs_analyze_patterns &>/dev/null; then
        cs_analyze_patterns 2>/dev/null || true
        local _cs_advisory
        _cs_advisory=$(cs_generate_advisory "${DOMAIN_TYPE:-general}" 2>/dev/null || echo "")
        if [[ -n "$_cs_advisory" && "$_cs_advisory" != "normal_operation" ]]; then
            echo -e "  ${GREEN}📚 v44.0 Cross-Session: ${_cs_advisory}${NC}"
        fi

        # v52.0: Phase B-9: Cross-Session Error Learning - 前回エラーパターン警告
        if type -t cs_get_common_errors &>/dev/null; then
            local _cs_errors
            _cs_errors=$(cs_get_common_errors 2>/dev/null || echo "none")
            if [[ "$_cs_errors" != "none" && -n "$_cs_errors" ]]; then
                echo -e "  ${YELLOW}⚠️ 過去セッションの頻出エラー: ${_cs_errors}${NC}"
                # Error Chain履歴も確認
                local _ec_history_file="${HOME}/.soloptilink/knowledge/error_chain_history.jsonl"
                if [[ -f "$_ec_history_file" ]]; then
                    local _ec_top_errors
                    _ec_top_errors=$(sort "$_ec_history_file" 2>/dev/null | uniq -c | sort -rn | head -3 | awk '{$1=$1};1' 2>/dev/null || echo "")
                    if [[ -n "$_ec_top_errors" ]]; then
                        echo -e "  ${YELLOW}  エラーチェーン Top3: ${NC}"
                        while IFS= read -r _ec_line; do
                            [[ -z "$_ec_line" ]] && continue
                            echo -e "    ${DIM}${_ec_line}${NC}"
                        done <<< "$_ec_top_errors"
                    fi
                fi
                # エラー傾向をFollow-upコンテキストに注入
                export CROSS_SESSION_ERROR_PATTERNS="${_cs_errors}"
            fi
        fi
    fi

    # ============ v43.0: Health Monitor 初回チェック ============
    if type -t hm_get_health_score &>/dev/null; then
        local _hm_score
        _hm_score=$(hm_get_health_score 2>/dev/null || echo "100")
        if [[ "${_hm_score:-100}" -lt 70 ]]; then
            echo -e "  ${YELLOW:-}⚠️ v43.0 Health Monitor: スコア ${_hm_score}/100 - $(hm_suggest_action 2>/dev/null)${NC}"
        fi
    fi

    # ============ v9.0: スマートプロンプト展開 ============

    # URL駆動モードでなければ、プロンプト展開を実行
    if [[ ${#URLS[@]} -eq 0 ]]; then
        phase_prompt_expand "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ プロンプト展開に問題（続行）${NC}"
    fi

    # ============ v28.0: Follow-up Intelligence 検出 ============

    phase_followup_detect "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Follow-up検出に問題（続行）${NC}"

    if [[ "${FUC_IS_FOLLOWUP:-false}" == "true" ]]; then
        # ============ v28.0: Follow-up パス（2回目以降の指示） ============
        echo -e "\n${BOLD}${CYAN}[v28.0] Follow-up Intelligence パス (${FUC_REQUEST_TYPE})${NC}"

        phase_code_scan "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ コードスキャンに問題（続行）${NC}"
        phase_incremental_analysis "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ 差分分析に問題（続行）${NC}"
        phase_targeted_compile "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ ターゲットコンパイルに問題（続行）${NC}"

        # URL駆動モード（Follow-up時も対応）
        if [[ ${#URLS[@]} -gt 0 ]]; then
            _url_driven_development "${URLS[0]}" "${URLS[1]:-}" "$TASK_DESC"
        fi
    else
        # ============ 通常パス（新規ビルド - v27.0フロー） ============

        # ============ v18.0: データインポート ============
        phase_data_import "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ データインポートに問題（続行）${NC}"

        # ============ URL駆動モード ============
        if [[ ${#URLS[@]} -gt 0 ]]; then
            _url_driven_development "${URLS[0]}" "${URLS[1]:-}" "$TASK_DESC"
        fi

        # ============ v27.0: ドメイン知識注入 ============
        phase_domain_knowledge "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ ドメイン知識注入に問題（続行）${NC}"

        # ============ v2038: 過去学習の注入 (REQ-PERF-004 / 収集→活用 閉ループ・非ブロッキング) ============
        phase_learning_intelligence "$SESSION_ID" "$TASK_DESC" || true

        # ============ v9.0: スキャフォルド ============
        phase_scaffold "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ スキャフォルドに問題（続行）${NC}"

        type -t progress_milestone &>/dev/null && progress_milestone "${PROJECT_DIR:-$(pwd)}" 2 "システムを設計しています" 2>/dev/null || true

        # ============ v2035.0: 戦略計画(熟考) - SPE ============
        phase_strategic_planning "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ 戦略計画に問題（続行）${NC}"

        # ============ v27.0: ブループリント生成 ============
        phase_blueprint "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ ブループリント生成に問題（続行）${NC}"

        # ============ v27.0: プロンプトコンパイル ============
        phase_prompt_compile "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ プロンプトコンパイルに問題（続行）${NC}"
    fi

    # ============ v10.0: ファイルライター初期化 ============

    if type -t fw_init &>/dev/null; then
        fw_init "." 2>/dev/null || true
    fi

    type -t progress_milestone &>/dev/null && progress_milestone "${PROJECT_DIR:-$(pwd)}" 3 "機能を実装しています" 2>/dev/null || true

    # ============ DAGパイプライン構築・実行 ============

    local dag_exit=0

    if type -t dag_analyze_task &>/dev/null; then
        local complexity="standard"
        case "$PIPELINE_MODE" in
            quick)   complexity="quick" ;;
            deep)    complexity="deep" ;;
            hotfix)  complexity="hotfix" ;;
            auto)    complexity=$(_auto_detect_complexity "$TASK_DESC") ;;
            *)       complexity="$PIPELINE_MODE" ;;
        esac

        echo -e "${BOLD}パイプラインモード: ${CYAN}${complexity}${NC}"
        echo ""

        # v16.0: Planner-Judgeが有効ならタスク計画を事前生成
        if [[ "${ENABLE_PLANNER_JUDGE:-true}" == "true" ]] && type -t pj_plan &>/dev/null; then
            echo -e "  ${CYAN}⚖️  [Planner] タスク全体計画を生成中...${NC}"
            local _pj_master_plan
            _pj_master_plan=$(pj_plan "master" "$TASK_DESC" "" 2>/dev/null || echo "")
            if [[ -n "$_pj_master_plan" ]]; then
                echo -e "  ${GREEN}⚖️  [Planner] マスタープラン生成完了${NC}"
                # 計画をメモリに保存
                if type -t mm_store_short &>/dev/null; then
                    mm_store_short "master_plan" "$_pj_master_plan" 2>/dev/null || true
                fi
            fi
        fi

        # プリセットまたは動的構築
        case "$complexity" in
            quick)  dag_preset_quick ;;
            hotfix) dag_preset_hotfix ;;
            *)      dag_analyze_task "$TASK_DESC" "$complexity" ;;
        esac

        # DAGグラフ表示
        if type -t dag_print_graph &>/dev/null; then
            dag_print_graph
        fi

        # DAG実行（並列モード対応 / v2041: parallel-exec-v2 本配線を第一経路化）
        if [[ "$ENABLE_PARALLEL" == "true" ]] && [[ "${SOLOPTILINK_PE2:-on}" != "off" ]] \
           && type -t pe2_run_dag_waves &>/dev/null && declare -p DAG_NODES &>/dev/null; then
            local _pe2_max="${SOLOPTILINK_MAX_PARALLEL:-16}"
            echo -e "${BOLD}⚡ 並列実行モード v2 (parallel-exec-v2 / 最大${_pe2_max}並列)${NC}"
            pe2_init "$SESSION_ID" "$_pe2_max"
            echo -e "  ${DIM}有効並列度: ${PE2_MAX_PARALLEL} (CPU=${PE2_EFFECTIVE_CPU} / 上限=${PE2_MAX_CEILING}$([ "${PE2_DEGRADED:-false}" = "true" ] && echo " / 高負荷縮退"))${NC}"
            pe2_run_dag_waves "$SESSION_ID" "$TASK_DESC"
            dag_exit=$?
            pe2_report 2>/dev/null || true
            # フォールバック: v2が対象ノードを1つも起動できなかった場合のみ逐次実行へ
            if [[ "${PE2_JOBS_LAUNCHED:-0}" -eq 0 ]]; then
                echo -e "${YELLOW}⚠️ 並列v2の実行対象なし → 通常DAG実行にフォールバック${NC}"
                dag_execute "$SESSION_ID" "$TASK_DESC"
                dag_exit=$?
            fi
        elif [[ "$ENABLE_PARALLEL" == "true" ]] && type -t parallel_execute &>/dev/null; then
            echo -e "${BOLD}⚡ 並列実行モード (v10.0)${NC}"
            # DAGから並列実行可能なノードを抽出してJSONを構築
            local parallel_nodes="[]"
            if type -t dag_get_runnable_nodes &>/dev/null; then
                parallel_nodes=$(dag_get_runnable_nodes 2>/dev/null || echo "[]")
            else
                # DAGノードから直接並列実行ノードを構築
                local _px_nodes="["
                local _px_first=true
                for nid in "${!DAG_NODES[@]}"; do
                    local _func="${DAG_NODES["$nid"]}"
                    if declare -F "$_func" &>/dev/null; then
                        [[ "$_px_first" == true ]] && _px_first=false || _px_nodes+=","
                        _px_nodes+="{\"id\":\"${nid}\",\"phase_func\":\"${_func}\"}"
                    fi
                done
                _px_nodes+="]"
                parallel_nodes="$_px_nodes"
            fi
            if [[ "$parallel_nodes" != "[]" && "$parallel_nodes" != "[" ]]; then
                parallel_init "$SESSION_ID"
                parallel_execute "$parallel_nodes" "$SESSION_ID" "$TASK_DESC"
                dag_exit=$?
                parallel_report 2>/dev/null || true
            else
                echo -e "${YELLOW}⚠️ 並列実行対象ノードなし（DAG_NODES未構築の可能性） → 通常DAG実行${NC}"
                dag_execute "$SESSION_ID" "$TASK_DESC"
                dag_exit=$?
            fi
        else
            dag_execute "$SESSION_ID" "$TASK_DESC"
            dag_exit=$?
        fi
    else
        # DAGモジュールなし → シンプル実行
        _simple_execution "$TASK_DESC"
        dag_exit=$?
    fi

    type -t progress_milestone &>/dev/null && progress_milestone "${PROJECT_DIR:-$(pwd)}" 4 "動作を検証しています" 2>/dev/null || true

    # ============ v16.0: DAG完了後のJudge総合評価 ============

    if [[ "${ENABLE_PLANNER_JUDGE:-true}" == "true" ]] && type -t pj_judge &>/dev/null; then
        echo -e "\n${BOLD}${CYAN}[v16.0] Planner-Judge 総合評価${NC}"
        local _pj_master_plan=""
        if type -t mm_recall_short &>/dev/null; then
            _pj_master_plan=$(mm_recall_short "master_plan" 2>/dev/null || echo "")
        fi
        if [[ -n "$_pj_master_plan" ]]; then
            local _pj_final_judge
            _pj_final_judge=$(pj_judge "final" "$_pj_master_plan" 2>/dev/null || echo "")
            if [[ -n "$_pj_final_judge" ]]; then
                local _pj_final_confidence
                _pj_final_confidence=$(echo "$_pj_final_judge" | python3 -c "
import sys, json
try:
    d = json.loads(sys.stdin.read())
    print(d.get('confidence', 0.0))
except:
    print(0.0)
" 2>/dev/null || echo "0.0")
                echo -e "  ${GREEN}⚖️  総合品質スコア: ${BOLD}${_pj_final_confidence}${NC}"
            fi
        fi
    fi

    type -t progress_milestone &>/dev/null && progress_milestone "${PROJECT_DIR:-$(pwd)}" 5 "仕上げをしています" 2>/dev/null || true
    type -t progress_done &>/dev/null && progress_done "${PROJECT_DIR:-$(pwd)}" 2>/dev/null || true

    # ============ v16.0: セッション終了時メモリ永続化 ============

    if type -t mm_store_long &>/dev/null; then
        echo -e "\n  ${CYAN}🧠 [Memory] 長期記憶に保存中...${NC}"
        mm_store_long "session_${SESSION_ID}" "{\"task\":\"${TASK_DESC}\",\"exit_code\":${dag_exit},\"timestamp\":\"$(date -u '+%Y-%m-%dT%H:%M:%SZ')\"}" 2>/dev/null || true
    fi
    if type -t mm_decay &>/dev/null; then
        mm_decay 2>/dev/null || true
    fi

    # ============ v28.0→v52.0: Project Genome 保存（成功/失敗問わず常に保存） ============

    if type -t fuc_save_genome &>/dev/null && type -t cs_scan_project &>/dev/null; then
        echo -e "\n  ${CYAN}🧬 [Genome] プロジェクトDNA保存中...${NC}"
        local _genome_project_dir
        _genome_project_dir="$(_detect_project_dir 2>/dev/null || echo ".")"
        local _genome_json
        _genome_json=$(cs_scan_project "$_genome_project_dir" 2>/dev/null || echo "")
        if [[ -n "$_genome_json" ]]; then
            fuc_save_genome "$_genome_project_dir" "$_genome_json" 2>/dev/null || true
            if [[ "$dag_exit" -eq 0 ]]; then
                echo -e "  ${GREEN}🧬 [Genome] DNA保存完了 → 次回のFollow-up指示で活用${NC}"
            else
                echo -e "  ${YELLOW}🧬 [Genome] DNA保存完了（エラー状態含む → 次回修正時に活用）${NC}"
            fi
        fi
    fi

    # ============ v18.0: SaaS アーキテクチャ ============
    # NOTE: _simple_execution() 内で既に実行される場合があるため、
    # DAGパイプライン経由時のみここで実行する（二重実行防止 v18.0.1）
    if [[ "$dag_exit" -eq 0 ]] && type -t dag_analyze_task &>/dev/null; then
        phase_saas_architecture "$SESSION_ID" "$TASK_DESC"
        phase_ai_integration "$SESSION_ID" "$TASK_DESC"
    fi

    # ============ v30.0: 群知能タスク分配 ============

    if [[ "${ENABLE_SWARM:-true}" == "true" ]] && type -t pe_execute_swarm_allocate &>/dev/null; then
        pe_execute_swarm_allocate "$(_detect_project_dir 2>/dev/null || echo ".")"
    fi

    # ============ v53.0: エージェント投票（DAGパイプライン経由時 - 実効化） ============

    if [[ "${ENABLE_SWARM:-true}" == "true" ]] && type -t pe_execute_swarm_vote &>/dev/null; then
        pe_execute_swarm_vote "$(_detect_project_dir 2>/dev/null || echo ".")" "architecture_decision"
        # v53.0: 投票結果をガバナンスチェックに反映
        if type -t vt_get_result &>/dev/null; then
            local _arch_vote_result
            _arch_vote_result=$(vt_get_result 2>/dev/null || echo "")
            if [[ -n "$_arch_vote_result" ]]; then
                echo -e "  ${GREEN}🗳️ [v53.0 Swarm] アーキテクチャ投票結果: ${_arch_vote_result}${NC}"
            fi
        fi
    fi

    # ============ v11.0: セキュリティ監査 ============

    if [[ "${ENABLE_SECURITY}" == "true" ]]; then
        phase_security_audit "$SESSION_ID" "$TASK_DESC"
    fi

    # ============ v17.0: データ整合性チェック ============

    if [[ "${ENABLE_DATA_INTEGRITY:-true}" == "true" ]]; then
        phase_data_integrity_scan "$SESSION_ID" "$TASK_DESC"
    fi

    # ============ v17.0: 監査ログ検証 ============

    if [[ "${ENABLE_AUDIT_LOG:-true}" == "true" ]]; then
        phase_audit_log_validation "$SESSION_ID" "$TASK_DESC"
    fi

    # ============ v17.0: E2Eパイプラインテスト ============

    if [[ "${ENABLE_E2E:-true}" == "true" ]]; then
        phase_e2e_test "$SESSION_ID" "$TASK_DESC"
    fi

    # ============ v2038.x NEW (PFP-097): One-Shot Setup Injector ============
    # 「手動 db:setup なしで受け取った状態のまま一発デモ可能」を構造的に保証する auto-heal。
    # Next.js+Prisma+SQLite に scripts/setup-if-needed.mjs + predev/prestart を冪等注入する。
    # (2026-06-06 小貫さん指摘「更新しないとデータが出ないのは面倒」の構造的根絶)
    if [[ "${ENABLE_ONESHOT_SETUP_INJECTOR:-true}" == "true" ]]; then
        _oss_inj="${SCRIPT_DIR}/lib/first-boot-perfect/oneshot-setup-injector.sh"
        _oss_proj="${PROJECT_DIR:-$(_detect_project_dir 2>/dev/null || echo "$PWD")}"
        if [[ -x "$_oss_inj" && -d "$_oss_proj" && -f "$_oss_proj/package.json" ]]; then
            bash "$_oss_inj" apply "$_oss_proj" >/dev/null 2>&1 && \
              echo -e "  ${GREEN}✓ [PFP-097] 一発自動セットアップを確認/注入${NC}" || true
        fi
    fi

    # ============ v2037.0 NEW (PFP-090): Secret-in-Prompt Protection Gate ============
    # 顧客がプロンプト/CLIに入れた APIキー/接続文字列/秘密鍵が、生成物に平文で
    # 残ったまま完成・デプロイされる事故を構造的に根絶 (SoT=secret-patterns.json で leak-scan)。
    # 機密はログイン/デプロイより前に確定させるべきなので db_persistence の直前に置く。
    # STRICT_SECRET_PROTECTION=true (default) で BLOCK 時 exit 1 (生成停止)
    if [[ "${ENABLE_SECRET_PROTECTION_GATE:-true}" == "true" ]]; then
        if [[ "${STRICT_SECRET_PROTECTION:-true}" == "true" ]]; then
            phase_secret_protection_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Secret Protection Gate BLOCK (Strict mode → 生成停止)。平文の機密を削除し暗号化env/vaultへ移してください${NC}" >&2; exit 1; }
        else
            phase_secret_protection_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Secret Protection Gate に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ v2036.0 NEW (PFP-089): Data Persistence Gate ============
    # SQLite のまま本番(サーバーレス)へ出してデータが消える事故を構造的に根絶。
    # 本番デプロイ意図のある SQLite プロジェクトで、無料/有料/未接続の選択
    # (DB_PERSISTENCE_TIER) が人により確定していなければ BLOCK。
    # 永続DBはログインユーザの前提なので first_login の直前に置く。
    # STRICT_DB_PERSISTENCE=true (default) で BLOCK 時 exit 1 (生成停止)
    if [[ "${ENABLE_DB_PERSISTENCE_GATE:-true}" == "true" ]]; then
        if [[ "${STRICT_DB_PERSISTENCE:-true}" == "true" ]]; then
            phase_db_persistence_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Data Persistence Gate BLOCK (Strict mode → 生成停止)。無料/有料DBを人に確認し DB_PERSISTENCE_TIER を指定してください${NC}" >&2; exit 1; }
        else
            phase_db_persistence_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Data Persistence Gate に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ v2034.8: First-Login Zero-Friction Gate (PFP-061+071) - Strict化 ============
    # BOOST生成システムの「1回目ログイン失敗」事案を構造的に根絶
    # smoke_test の直前に走らせ、port整合 + email正規化 + seed表示 + db:setup を保証
    # STRICT_FIRST_LOGIN_GATE=true (default) で FAIL 時 exit 1 (生成自体を停止)
    if [[ "${ENABLE_FIRST_LOGIN_GATE:-true}" == "true" ]]; then
        if [[ "${STRICT_FIRST_LOGIN_GATE:-true}" == "true" ]]; then
            phase_first_login_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ First-Login Gate FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_first_login_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ First-Login Gate に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ v2034.9 NEW (PFP-074): Form Critical Path Gate (FCPG+REHD+OSCG) ============
    # 「請求書/見積/契約/受注/予約フォームが一発で送信できない」事案を構造的に根絶
    # linkage-mic-platform (2026-05-09) + sales-cockpit-pro (2026-05-21) 事案の再発防止
    # STRICT_FORM_CRITICAL_PATH=true (default) で FAIL 時 exit 1 (生成自体を停止)
    if [[ "${ENABLE_FORM_CRITICAL_PATH:-true}" == "true" ]]; then
        if [[ "${STRICT_FORM_CRITICAL_PATH:-true}" == "true" ]]; then
            phase_form_critical_path "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Form Critical Path Gate FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_form_critical_path "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Form Critical Path Gate に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ v2034.10 NEW (PFP-033): Customer Error Reporter Injection ============
    # 顧客端末で発生したエラーを admin-dashboard へ silent ack 送信する
    # customer-error-reporter.ts + global-error.tsx + .env.example を配置
    # 2026-05-15 Failure Intelligence/Customer Error Tracking 偽陽性 HEALTHY 事案の再発防止
    if [[ "${ENABLE_CUSTOMER_ERROR_REPORTER:-true}" == "true" ]]; then
        phase_customer_error_reporter "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Customer Error Reporter 配備に問題（続行）${NC}"
    fi

    # ============ v2034.9 NEW (PFP-080): Layered Depth Gate ============
    # 生成物が L0/L1/L2/L3 のどこまで到達したか構造的に検証
    # Claude Code Desktop 環境 (PFP-068) では agent-orchestrator.sh の 105 エージェント
    # 協調が claude -p Keychain 制限で動作不能 → Step 2 BOOST LAYER 直接実装に分岐
    # するため、生成物が汎用 HRTech 骨組み (L0) で止まる事案が多発。本 gate で
    # LAYERED_DEPTH_MIN_LAYER (default: L2) 未達なら Strict mode で生成停止
    # (2026-05-29 sabikan-link-platform 監査結果)
    if [[ "${ENABLE_LAYERED_DEPTH_GATE:-true}" == "true" ]]; then
        if [[ "${STRICT_LAYERED_DEPTH:-true}" == "true" ]]; then
            phase_layered_depth_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Layered Depth Gate FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_layered_depth_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Layered Depth Gate に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ v2037.x NEW (PFP-094): Incremental Integration Gate ============
    # 追加開発で足した model/api/page が既存システム (集計/他機能/ナビ/APIクライアント)
    # へ結線されたかを検証。孤児テーブル/死蔵API/孤児ページ/ダッシュボード未反映を検出。
    # follow-up (feature_add/modification) では git 差分で「今回追加分」に絞る。
    # 既定は WARN (非Strict) — v1 ヒューリスティックのため誤検知で生成を止めない。
    # (2026-06-05 小貫さん指示: 追加開発時の裏側連携の欠落を構造的に検出する)
    if [[ "${ENABLE_INCREMENTAL_INTEGRATION_GATE:-true}" == "true" ]]; then
        if [[ "${STRICT_INCREMENTAL_INTEGRATION:-false}" == "true" ]]; then
            phase_incremental_integration_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Incremental Integration Gate FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_incremental_integration_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Incremental Integration Gate に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ v2038.x NEW (PFP-096): Data Completeness Gate ============
    # IIG/Layered/FCPG を束ねて「データ完全性」6軸 (マスタ網羅/関連整合/業務ロジック/
    # 画面↔DB結線(孤児テーブル・孤児ページ)/集計反映/入力臨界経路) を一括判定。
    # これまで chain.sh から呼ばれていなかった孤児ゲートを本配線。既定 WARN (非Strict)。
    # (2026-06-06 小貫さん「監査ログが入らない=孤児テーブル」の構造的検出)
    if [[ "${ENABLE_DATA_COMPLETENESS_GATE:-true}" == "true" ]] && type -t phase_data_completeness_gate &>/dev/null; then
        if [[ "${STRICT_DATA_COMPLETENESS:-false}" == "true" ]]; then
            phase_data_completeness_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Data Completeness Gate FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_data_completeness_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Data Completeness Gate に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ PFP-098 Deep System Gate (L4/L5/L6) — v2040 ============
    # 「UIは綺麗だが中身が薄い」(一覧の企業名クリック不可/データ空/モジュール非連携) を
    # 出荷前に検出。Layered Depth (L0-L3) の上に L4 データ充足/L5 ドリルダウン/L6 業務貫通
    # を測る。既定 WARN (非Strict)。STRICT_DEEP_SYSTEM=true で生成停止に昇格。
    # (2026-06-07 小貫さん「薄っぺらいシステム・3層止まり」の構造的根絶)
    if [[ "${ENABLE_DEEP_SYSTEM_GATE:-true}" == "true" ]] && type -t phase_deep_system_gate &>/dev/null; then
        if [[ "${STRICT_DEEP_SYSTEM:-false}" == "true" ]]; then
            phase_deep_system_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Deep System Gate FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_deep_system_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Deep System Gate に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ PFP-100 CRUD Input Capability Gate (入力できるか) — v2038.x ============
    # 「顧客管理や請求書の入力項目が無い=閲覧専用システム」を出荷前に検出 (TWOSTONE 事案)。
    # 全業務エンティティが DB へ永続化される新規作成/編集フォームを持つかを検証する。
    # create フォームが 1 つも無い完全閲覧専用 = BLOCK は Strict 不問で生成停止。
    # 部分不足は既定 WARN。STRICT_CRUD_INPUT=true で FAIL も生成停止。
    # (2026-06-08 小貫さん「入力できない使えないシステムを出すな」の構造的根絶)
    if [[ "${ENABLE_CRUD_INPUT_GATE:-true}" == "true" ]] && type -t phase_crud_input_capability_gate &>/dev/null; then
        phase_crud_input_capability_gate "$SESSION_ID" "$TASK_DESC"
        _cic_rc=$?
        _cic_json="${PROJECT_DIR:-$PWD}/.soloptilink/crud-input-capability-results.json"
        _cic_verdict="$(sed -n 's/.*"verdict"[[:space:]]*:[[:space:]]*"\([A-Za-z_]*\)".*/\1/p' "$_cic_json" 2>/dev/null | tail -1)"
        if [[ "$_cic_verdict" == "BLOCK" ]]; then
            echo -e "  ${RED}❌ CRUD Input Capability Gate BLOCK — 入力フォームが1つもありません(完全閲覧専用)。全業務モデルに新規作成/編集フォームを実装してください${NC}" >&2
            exit 1
        elif [[ "$_cic_rc" -ne 0 ]] && [[ "${STRICT_CRUD_INPUT:-false}" == "true" ]]; then
            echo -e "  ${RED}❌ CRUD Input Capability Gate FAIL (Strict mode → 生成停止)${NC}" >&2
            exit 1
        elif [[ "$_cic_rc" -ne 0 ]]; then
            echo -e "  ${YELLOW}⚠️ CRUD Input Capability Gate に問題（非Strict → 続行）。一部業務モデルに入力画面が不足${NC}" >&2
        fi
    fi

    # ============ PFP-106 Security Hardening Gate (生成物セキュリティ標準装備) — v2038.x ============
    # 「綺麗で深く入力できるが守りが無い」を出荷前に塞ぐ (2026-06-11 セキュリティ総点検)。
    # セキュリティヘッダ/レート制限/ログインロックアウト/npm audit を検証し、不足は apply で
    # 安全に自動是正 (ファイル追加のみ)。IDOR/入力長/機微カラム暗号化は WARN で refiner へ。
    # 既定 WARN (非Strict)。STRICT_SECURITY_HARDENING=true で生成停止に昇格。
    if [[ "${ENABLE_SECURITY_HARDENING_GATE:-true}" == "true" ]] && type -t phase_security_hardening_gate &>/dev/null; then
        if [[ "${STRICT_SECURITY_HARDENING:-false}" == "true" ]]; then
            phase_security_hardening_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Security Hardening Gate FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_security_hardening_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Security Hardening Gate に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ PFP-107 Permission Matrix Gate (権限マトリクス強制) — v2040 ============
    if [[ "${ENABLE_PERMISSION_MATRIX_GATE:-true}" == "true" ]] && type -t phase_permission_matrix_gate &>/dev/null; then
        if [[ "${STRICT_PERMISSION_MATRIX:-false}" == "true" ]]; then
            phase_permission_matrix_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Permission Matrix Gate (権限マトリクス強制) FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_permission_matrix_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Permission Matrix Gate (権限マトリクス強制) に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ PFP-108 Document Output Gate (帳票印刷PDF) — v2040 ============
    if [[ "${ENABLE_DOCUMENT_OUTPUT_GATE:-true}" == "true" ]] && type -t phase_document_output_gate &>/dev/null; then
        if [[ "${STRICT_DOCUMENT_OUTPUT:-false}" == "true" ]]; then
            phase_document_output_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Document Output Gate (帳票印刷PDF) FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_document_output_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Document Output Gate (帳票印刷PDF) に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ PFP-109 CSV I/O Gate (CSV入出力) — v2040 ============
    if [[ "${ENABLE_CSV_IO_GATE:-true}" == "true" ]] && type -t phase_csv_io_gate &>/dev/null; then
        if [[ "${STRICT_CSV_IO:-false}" == "true" ]]; then
            phase_csv_io_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ CSV I/O Gate (CSV入出力) FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_csv_io_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ CSV I/O Gate (CSV入出力) に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ PFP-110 Performance Baseline Gate (性能基礎) — v2040 ============
    if [[ "${ENABLE_PERFORMANCE_BASELINE_GATE:-true}" == "true" ]] && type -t phase_performance_baseline_gate &>/dev/null; then
        if [[ "${STRICT_PERFORMANCE_BASELINE:-false}" == "true" ]]; then
            phase_performance_baseline_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Performance Baseline Gate (性能基礎) FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_performance_baseline_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Performance Baseline Gate (性能基礎) に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ PFP-111 Backup/Restore Gate (バックアップ) — v2040 ============
    if [[ "${ENABLE_BACKUP_RESTORE_GATE:-true}" == "true" ]] && type -t phase_backup_restore_gate &>/dev/null; then
        if [[ "${STRICT_BACKUP_RESTORE:-false}" == "true" ]]; then
            phase_backup_restore_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Backup/Restore Gate (バックアップ) FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_backup_restore_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Backup/Restore Gate (バックアップ) に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ PFP-115 Enterprise Integration Gate (基幹3点) — v2040 ============
    if [[ "${ENABLE_ENTERPRISE_GATE:-true}" == "true" ]] && type -t phase_enterprise_integration_gate &>/dev/null; then
        if [[ "${STRICT_ENTERPRISE_INTEGRATION:-false}" == "true" ]]; then
            phase_enterprise_integration_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Enterprise Integration Gate (基幹3点) FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_enterprise_integration_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Enterprise Integration Gate (基幹3点) に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ PFP-126 Runtime CRUD Smoke Gate (実走CRUD検証) — v2041 ============
    if [[ "${ENABLE_RUNTIME_CRUD_SMOKE_GATE:-true}" == "true" ]] && type -t phase_runtime_crud_smoke_gate &>/dev/null; then
        if [[ "${STRICT_RUNTIME_CRUD:-false}" == "true" ]]; then
            phase_runtime_crud_smoke_gate "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Runtime CRUD Smoke Gate (実走CRUD検証) FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_runtime_crud_smoke_gate "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Runtime CRUD Smoke Gate (実走CRUD検証) に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ PFP-120 Quality Evidence Report (品質証明書) — v2040 ============
    # 全品質ゲートの実測記録 (.soloptilink/*-results.json) が出揃った時点で、
    # お客さま向けの品質証明書.html を発行する。実測データのみから生成 (捏造ゼロ)。
    if [[ "${ENABLE_QUALITY_EVIDENCE_REPORT:-true}" == "true" ]] && [[ -f "${SCRIPT_DIR}/lib/quality-evidence-report.sh" ]]; then
        bash "${SCRIPT_DIR}/lib/quality-evidence-report.sh" generate "${PROJECT_DIR:-$PWD}" \
            || echo -e "  ${YELLOW}⚠️ 品質証明書の生成に失敗（非ブロッキング → 続行）${NC}" >&2
    fi

    # ============ 本体機能拡張 NEW (PFP-095): Auto-Update Patch Engine 装備 ============
    # 生成プロジェクトに出荷後の自動アップデートパッチ機構 (AUPE) クライアントを標準装備する。
    # 既定 OFF (オプトイン)。既存顧客ビルドの挙動を変えず、配信判断で ENABLE_AUTO_UPDATE_PHASE=true 有効化。
    if [[ "${ENABLE_AUTO_UPDATE_PHASE:-false}" == "true" ]]; then
        if [[ "${STRICT_AUTO_UPDATE:-false}" == "true" ]]; then
            phase_auto_update "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Auto-Update Phase FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_auto_update "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Auto-Update Phase に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ 本体機能拡張 NEW (PFP-096): KUT UAT Loop (データ完全性) ============
    # 「画面はできたが裏側のデータが揃っていない」生成物を出荷前に軽量検証する (KUT)。
    # 既定 OFF (オプトイン)。配信判断で ENABLE_UAT_LOOP=true 有効化。重いUAT実行は別途 ENABLE_UAT_FEEDBACK。
    if [[ "${ENABLE_UAT_LOOP:-false}" == "true" ]]; then
        if [[ "${STRICT_UAT_LOOP:-false}" == "true" ]]; then
            phase_uat_loop "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ UAT Loop BLOCK (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_uat_loop "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ UAT Loop に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ 本体機能拡張 NEW (PFP-092): Build/Dev Hygiene Gate ============
    # 生成プロジェクトの DB provider/URL 整合を検査・安全是正する (apply のみ / サーバ不要)。
    # schema=postgresql vs DATABASE_URL=file: の不一致で全DBクエリ失敗 → health 503・ログイン
    # 不可になる事故を出荷前に塞ぐ。HTTP スモーク (ログアウト 500 検出) はデモ受け渡し時に
    # serve-prod/check で別途実施 (SKILL.md)。既定 OFF (オプトイン): apply は schema.prisma を
    # 書き換えるため既存顧客ビルドの挙動を変えない。配信判断で ENABLE_BUILD_DEV_HYGIENE=true 有効化。
    if [[ "${ENABLE_BUILD_DEV_HYGIENE:-false}" == "true" ]]; then
        if [[ "${STRICT_BUILD_DEV_HYGIENE:-false}" == "true" ]]; then
            phase_build_dev_hygiene "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Build/Dev Hygiene Gate FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_build_dev_hygiene "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Build/Dev Hygiene Gate に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ v2034.10: Mega Portal Edition (PFP-083 + PFP-084) ============
    # 大規模ポータルカテゴリの DBL が検出されたとき、または明示指定時のみ起動。
    # 汎用業務システム生成では起動しない (オーバヘッドを避ける)。
    if _is_mega_portal_context; then
        echo -e "\n  ${CYAN}🌆 Mega Portal Edition 起動 (DBL=${SOLOPTILINK_DETECTED_DBL:-?} / scale=${PORTAL_SCALE:-large})${NC}"

        if [[ "${ENABLE_MEGA_PORTAL_GATE:-true}" == "true" ]]; then
            if [[ "${STRICT_MEGA_PORTAL:-true}" == "true" ]]; then
                phase_mega_portal_check "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Mega Portal Gate FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
            else
                phase_mega_portal_check "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Mega Portal Gate に問題（非Strict → 続行）${NC}"
            fi
        fi

        if [[ "${ENABLE_IMAGE_CMS_GATE:-true}" == "true" ]]; then
            if [[ "${STRICT_IMAGE_CMS:-true}" == "true" ]]; then
                phase_image_cms_check "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Image CMS Gate FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
            else
                phase_image_cms_check "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Image CMS Gate に問題（非Strict → 続行）${NC}"
            fi
        fi
    fi

    # ============ REQ-WIRE-002: 生成品質中核4機能 通電 (非ブロッキング) ============
    phase_quality_amplification "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ 品質増幅に問題（続行）${NC}"

    # ============ v20.0: スモークテスト ============

    phase_smoke_test "$SESSION_ID" "$TASK_DESC"

    # ============ v2034.10: Output Watermark Gate (PFP-082) ============
    # 生成プロジェクトの主要ファイル先頭に Trade-Secret Watermark を自動注入。
    # default: ENABLE=true / STRICT=false (注入失敗時も続行)。
    if [[ "${ENABLE_OUTPUT_WATERMARK:-true}" == "true" ]]; then
        if [[ "${STRICT_OUTPUT_WATERMARK:-false}" == "true" ]]; then
            phase_output_watermark "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Output Watermark Gate FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
        else
            phase_output_watermark "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Output Watermark Gate に問題（非Strict → 続行）${NC}"
        fi
    fi

    # ============ v53.0: Adaptive Intelligence 三兄弟 実接続 ============

    local _ai_project_dir
    _ai_project_dir="$(_detect_project_dir 2>/dev/null || echo ".")"

    # ============ v2030.0 (配線復旧 REQ-COMPLETION-GUARANTEE-001): First-Boot-Perfect Bridge ============
    # 生成完了直前に 7 ゲート (port / sce-guard / paid-api / env-completeness / onboarding注入 /
    # japanese-lock / one-shot-completeness) を統合実行し、追加指示なしで起動できる状態を保証する。
    # 非ブロッキング。無効化: ENABLE_FIRST_BOOT_PERFECT=false
    if [[ "${ENABLE_FIRST_BOOT_PERFECT:-true}" == "true" ]] && [[ -f "${SCRIPT_DIR}/lib/first-boot-perfect/v2030-bridge.sh" ]]; then
        bash "${SCRIPT_DIR}/lib/first-boot-perfect/v2030-bridge.sh" run "$_ai_project_dir" 2>/dev/null || true
    fi

    # ============ 配線復旧 REQ-COMPLETION-GUARANTEE-001: 総合品質チェック (qg_run + fh_heal) ============
    # 旧 phase_quality_check が main_flow から呼ばれていなかった孤児状態を解消。非ブロッキング。
    if [[ "${ENABLE_QUALITY_CHECK_PHASE:-true}" == "true" ]] && type -t phase_quality_check &>/dev/null; then
        PROJECT_DIR="${PROJECT_DIR:-$_ai_project_dir}" phase_quality_check "$SESSION_ID" "$TASK_DESC" 2>/dev/null || true
    fi

    # ============ 配線復旧 REQ-COMPLETION-GUARANTEE-001: 監査ログ AuditLog 自動注入 (FR-AUDIT) ============
    # 生成プロジェクトの prisma/schema.prisma に AuditLog モデルが無ければ注入する (冪等)。
    # 旧 al_inject_prisma_schema が呼び出し0件の孤児だった状態を解消。非ブロッキング。
    if [[ "${ENABLE_AUDIT_LOG_INJECT:-true}" == "true" ]] && [[ -f "$HOME/.soloptilink/lib/audit-logger.sh" ]]; then
        type -t al_inject_prisma_schema &>/dev/null || source "$HOME/.soloptilink/lib/audit-logger.sh" 2>/dev/null
        type -t al_inject_prisma_schema &>/dev/null && al_inject_prisma_schema "$_ai_project_dir" 2>/dev/null || true
    fi

    # Phase 5.3: Dependency Resolver - 依存関係自動分析・最適化
    if [[ "${ENABLE_DEP_RESOLVE:-true}" == "true" ]] && type -t dr_full_analysis &>/dev/null; then
        echo -e "\n  ${CYAN}📦 [v53.0] Phase 5.3: Dependency Resolver - 依存関係分析${NC}"
        if type -t pe_set_phase &>/dev/null; then
            pe_set_phase "dependency_resolve"
        fi
        dr_full_analysis "$_ai_project_dir" 2>/dev/null || true
        local _dr_score="${DR_SCORE:-0}"
        echo -e "  ${BOLD}依存関係健全性スコア: ${_dr_score}/100${NC}"
        if [[ "${_dr_score}" -lt 60 ]]; then
            echo -e "  ${YELLOW}⚠️ 依存関係に問題あり - 自動修正を試行${NC}"
            dr_fix_vulnerabilities "$_ai_project_dir" 2>/dev/null || true
            dr_optimize "$_ai_project_dir" 2>/dev/null || true
        fi
        if type -t dr_report &>/dev/null; then
            dr_report 2>/dev/null || true
        fi
    fi

    # Phase 5.4: Performance Profiler - パフォーマンス分析
    if [[ "${ENABLE_PERF_PROFILE:-true}" == "true" ]] && type -t pp_full_profile &>/dev/null; then
        echo -e "\n  ${CYAN}⚡ [v53.0] Phase 5.4: Performance Profiler - パフォーマンス分析${NC}"
        if type -t pe_set_phase &>/dev/null; then
            pe_set_phase "performance_profile"
        fi
        pp_full_profile "$_ai_project_dir" 2>/dev/null || true
        local _pp_score="${PP_SCORE:-0}"
        echo -e "  ${BOLD}パフォーマンススコア: ${_pp_score}/100${NC}"
        if [[ "${_pp_score}" -lt 60 ]]; then
            echo -e "  ${YELLOW}⚠️ パフォーマンス問題検出 - 最適化レコメンデーションを確認してください${NC}"
        fi
        if type -t pp_report &>/dev/null; then
            pp_report 2>/dev/null || true
        fi
    fi

    # Phase 5.5: API Contract Validator - API契約検証
    if [[ "${ENABLE_API_CONTRACT:-true}" == "true" ]] && type -t acv_full_validation &>/dev/null; then
        echo -e "\n  ${CYAN}📋 [v53.0] Phase 5.5: API Contract Validator - API契約検証${NC}"
        if type -t pe_set_phase &>/dev/null; then
            pe_set_phase "api_contract_validate"
        fi
        acv_full_validation "$_ai_project_dir" 2>/dev/null || true
        local _acv_score="${ACV_SCORE:-0}"
        echo -e "  ${BOLD}API品質スコア: ${_acv_score}/100${NC}"
        if [[ "${_acv_score}" -lt 60 ]]; then
            echo -e "  ${YELLOW}⚠️ API契約に問題検出 - エンドポイント整合性を確認してください${NC}"
        fi
        if type -t acv_report &>/dev/null; then
            acv_report 2>/dev/null || true
        fi
    fi

    # ============ v53.0: ガバナンス検証（閾値ベースゲート制御） ============
    # v35.0: _simple_execution内で既に実行済みの場合はスキップ（重複実行防止）
    if [[ "${ENABLE_GOVERNANCE:-true}" == "true" && "${_GOVERNANCE_EXECUTED:-false}" != "true" ]]; then
        local _gov_dir
        _gov_dir="$(_detect_project_dir 2>/dev/null || echo ".")"
        if type -t ge_enforce_governance &>/dev/null; then
            ge_enforce_governance "$_gov_dir" "${GOVERNANCE_PASS_THRESHOLD:-80}" "${GOVERNANCE_WARN_THRESHOLD:-60}" || true
        elif type -t pe_execute_governance_check &>/dev/null; then
            pe_execute_governance_check "$_gov_dir"
        fi
    fi

    # ============ v2042 (L1ハーネス / REQ-WIRE-V2042): Lane Phase 汎用ディスパッチ ============
    # lib/phases/phase_lane<N>_*.sh が定義する全 phase_lane<N>_* 関数を、レーン別/機能別
    # マスタトグルでガードして実行する。実体未配置なら compgen が空=no-op(既定フロー不変)。
    # DAG実行分岐(ENABLE_PARALLEL=行199)の外・dag_exit を変更しない=main の戻り値(return $dag_exit)を汚さない。
    # STRICT_LANE<N>=true のレーンのみ FAIL で生成停止、既定 false=WARN 続行。
    # 数字入り命名(phase_lane2_perf 等)ゆえ doctor 孤児監査 regex(phase_[a-z_]+)に非該当=孤児FALSE化しない。
    if [[ "${ENABLE_LANE_PHASES:-true}" == "true" ]]; then
        local _lane_fns _lfn _lane_n _lane_en_var _lane_strict_var _lane_feat_var
        _lane_fns="$(compgen -A function 'phase_lane' 2>/dev/null | sort)"
        for _lfn in $_lane_fns; do
            _lane_n="$(printf '%s' "$_lfn" | sed -E 's/^phase_lane([0-9]+)_.*/\1/')"
            [[ "$_lane_n" =~ ^[0-9]+$ ]] || continue        # 規約外命名(数字なし)はスキップ
            _lane_en_var="ENABLE_LANE${_lane_n}"
            _lane_strict_var="STRICT_LANE${_lane_n}"
            _lane_feat_var="ENABLE_$(printf '%s' "${_lfn#phase_}" | tr '[:lower:]' '[:upper:]')"  # phase_lane2_perf→ENABLE_LANE2_PERF
            [[ "${!_lane_en_var:-true}" == "true" ]] || continue       # レーン別ゲート
            [[ "${!_lane_feat_var:-true}" == "true" ]] || continue     # 機能別ゲート(既定true)
            if [[ "${!_lane_strict_var:-false}" == "true" ]]; then
                "$_lfn" "$SESSION_ID" "$TASK_DESC" || { echo -e "  ${RED}❌ Lane${_lane_n} phase ${_lfn} FAIL (Strict mode → 生成停止)${NC}" >&2; exit 1; }
            else
                "$_lfn" "$SESSION_ID" "$TASK_DESC" || echo -e "  ${YELLOW}⚠️ Lane${_lane_n} phase ${_lfn} に問題（非Strict → 続行）${NC}"
            fi
        done
        unset _lane_fns _lfn _lane_n _lane_en_var _lane_strict_var _lane_feat_var
    fi

    # ============ v10.0: ブラウザテスト ============

    if [[ "$ENABLE_BROWSER_TEST" == "true" ]]; then
        phase_browser_test "$SESSION_ID" "$TASK_DESC"
    fi

    # ============ v14.0: カバレッジゲート ============

    if [[ "$ENABLE_DEPLOY" == "true" ]] && [[ -n "${COVERAGE_THRESHOLD:-}" ]]; then
        if type -t covgate_check &>/dev/null; then
            echo -e "\n${BOLD}${CYAN}[v14.0] カバレッジゲート チェック${NC}"
            covgate_check 2>/dev/null || true
            if type -t covgate_should_block_deploy &>/dev/null && covgate_should_block_deploy 2>/dev/null; then
                echo -e "${RED}  ❌ カバレッジゲート失敗 - デプロイブロック${NC}"
                covgate_report 2>/dev/null || true
                ENABLE_DEPLOY="false"
            else
                echo -e "${GREEN}  ✅ カバレッジゲート通過${NC}"
            fi
        fi
    fi

    # ============ v55.0: iOS Deploy Pipeline ============

    if [[ -n "${IOS_DEPLOY_TARGET:-}" && "${IOS_DEPLOY_TARGET}" != "" ]] && type -t idp_run_full_pipeline &>/dev/null; then
        echo -e "\n  ${BOLD}${PURPLE}📱 [v55.0] iOS Deploy Pipeline - ${IOS_DEPLOY_TARGET}${NC}"

        if [[ "${IOS_DEPLOY_TARGET}" == "setup-guide" ]]; then
            # セットアップガイドのみ表示
            idp_init "${PROJECT_DIR:-./output}"
            idp_check_prerequisites 2>/dev/null || true
            idp_setup_prerequisites_guide
        else
            # iOS Deploy Pipeline のグローバル変数を設定
            IDP_BUNDLE_ID="${IOS_BUNDLE_ID:-}"
            IDP_TEAM_ID="${IOS_TEAM_ID:-}"
            IDP_APPLE_ID="${IOS_APPLE_ID:-}"
            IDP_APP_SPECIFIC_PW="${IOS_APP_SPECIFIC_PW:-}"
            IDP_SCHEME="${IOS_SCHEME:-}"
            IDP_USE_FASTLANE="${IOS_USE_FASTLANE:-auto}"
            IDP_DEPLOY_TARGET="${IOS_DEPLOY_TARGET}"

            # App Store 審査バリデーション
            if type -t idp_validate_for_submission &>/dev/null; then
                idp_init "${PROJECT_DIR:-./output}"
                idp_validate_for_submission "${PROJECT_DIR:-./output}" 2>/dev/null || true
            fi

            # Xcode プロジェクト生成 & コード署名 & アーカイブ & アップロード
            idp_run_full_pipeline "${PROJECT_DIR:-./output}" || {
                echo -e "  ${YELLOW}⚠️ iOS Deploy Pipeline でエラーが発生しました${NC}"
                echo -e "  ${DIM}セットアップガイド: ./chain.sh --ios-setup-guide${NC}"
            }
        fi
    fi

    # ============ v10.0: 自動デプロイ ============
    # PFP-087 (v2034.11): deploy_auto 内で Deploy-Time Login Guarantee が
    # 自動稼働する。preflight で SQLite-on-serverless / NEXTAUTH_URL・SECRET 未設定
    # / 本番DB未シードを検出し致命なら deploy 中止、deploy 後は本番 URL で実ログインを
    # probe して「デプロイ=ログインできる状態」を構造的に保証する。
    # (gate: lib/first-boot-perfect/deploy-login-guarantee.sh / 一時回避:
    #  SOLOPTILINK_DEPLOY_LOGIN_GATE=warn)

    if [[ "$ENABLE_DEPLOY" == "true" ]]; then
        phase_auto_deploy "$SESSION_ID" "$TASK_DESC"
    fi

    # ============ v14.0: ファイルライターv3レポート ============

    if type -t fw3_report &>/dev/null && [[ "${FW3_FILES_WRITTEN:-0}" -gt 0 ]]; then
        fw3_report 2>/dev/null || true
    elif type -t fw2_report &>/dev/null && [[ "${FW2_FILES_WRITTEN:-0}" -gt 0 ]]; then
        fw2_report 2>/dev/null || true
    elif type -t fw_report &>/dev/null && [[ "${FW_FILES_WRITTEN:-0}" -gt 0 ]]; then
        fw_report 2>/dev/null || true
    fi

    # v12.0: コンテキストエンジン サマリー
    if type -t ctx_summary &>/dev/null; then
        echo -e "\n  ${BOLD}${CYAN}[Context Engine サマリー]${NC}"
        ctx_summary 2>/dev/null || true
    fi

    # ============ v14.0: Observatory Dashboard ============

    if [[ "${ENABLE_OBSERVATORY:-true}" == "true" ]] && type -t obs_collect_all &>/dev/null; then
        obs_collect_all 2>/dev/null || true
        obs_dashboard 2>/dev/null || true
        obs_export_json 2>/dev/null || true
    fi
    if [[ "${ENABLE_TRACE:-false}" == "true" ]] && type -t trace_export_json &>/dev/null; then
        trace_export_json 2>/dev/null || true
        trace_waterfall 2>/dev/null || true
    fi
    if type -t cost_breakdown_report &>/dev/null && [[ "${COST_CALLS_TOTAL:-0}" -gt 0 ]]; then
        cost_breakdown_report 2>/dev/null || true
        cost_export_json 2>/dev/null || true
    fi
    # Cost Dashboard (ガード付き配線): フラグ ON 時のみ呼び出し、かつ cd_render_dashboard 内の
    # 空データガードが実コストデータ無しの場合は無描画する二層防御。既定 (フラグ OFF) では不変。
    if [[ "${ENABLE_COST_DASHBOARD:-false}" == "true" ]] && type -t cd_render_dashboard &>/dev/null; then
        cd_render_dashboard "${PROJECT_DIR:-$PWD}" 2>/dev/null || true
    fi
    if type -t perf_baseline_report &>/dev/null && [[ -n "${BT_PERF_LCP:-}" ]]; then
        perf_baseline_report 2>/dev/null || true
    fi

    # ============ v35.0: Cost Gate 精度レポート + 学習データ永続化 ============

    if [[ "${CG_ENABLED:-false}" == "true" ]] && type -t cg_report &>/dev/null; then
        cg_report 2>/dev/null || true
    fi
    if [[ "${CG_ENABLED:-false}" == "true" ]] && type -t cg_save_learning &>/dev/null; then
        _warn_on_fail "CostGate" "save_learning" cg_save_learning || true
    fi

    # ============ セッション学習データ永続化 (lib/chain-utils.sh _save_session_data) ============
    _save_session_data

    # ============ v2038: 今回セッションの学習記録 (REQ-PERF-003 / 収集→活用 閉ループ・非ブロッキング) ============
    phase_learning_record "$SESSION_ID" "$TASK_DESC" "$dag_exit" || true

    # ============ v54.0: Dashboard Connector セッション完了通知 ============
    if type -t dc_session_complete &>/dev/null && dc_is_connected 2>/dev/null; then
        local _dc_status="COMPLETED"
        [[ "$dag_exit" -ne 0 ]] && _dc_status="FAILED"
        dc_session_complete \
            "$_dc_status" \
            "${QG_SCORE:-0}" \
            "${COST_USD_TOTAL:-0.00}" \
            "${EC_TOTAL_ERRORS:-0}" 2>/dev/null || true
    fi
    # Dashboard Connector レポート（接続時のみ）
    if type -t dc_report &>/dev/null && dc_is_connected 2>/dev/null; then
        dc_report 2>/dev/null || true
    fi

    # ============ v56.0: Harness Bridge ヘルスレポート ============
    if type -t hb_health_report &>/dev/null; then
        local _hb_report
        _hb_report=$(hb_health_report 2>/dev/null || echo "")
        if [[ -n "$_hb_report" ]]; then
            local _hb_score
            _hb_score=$(echo "$_hb_report" | python3 -c "import sys,json; print(json.loads(sys.stdin.read()).get('test_score',0))" 2>/dev/null || echo "0")
            if [[ "${_hb_score:-0}" -gt 0 ]]; then
                echo -e "  ${GREEN}🔗 [v56.0 Harness Bridge] テストスコア: ${_hb_score}%${NC}"
            fi
        fi
    fi

    # ============ v55.0: テレメトリファイル出力 (ランチャー→サーバー送信用) ============
    if [[ -n "${SOLOPTILINK_TELEMETRY_FILE:-}" ]]; then
        _write_telemetry_file "$dag_exit" || true
    fi

    # ============ v2028.0: Telemetry Wiring Layer (TWL) ============
    # 送信側パイプライン: chain実行エラーを admin-dashboard へ POST し、
    # 生成プロジェクトに Error Tracker SDK を自動配線する。
    # 失敗してもセッション完了を阻害しない (|| true)。
    if [[ -f "${HOME}/.soloptilink/lib/telemetry-wiring-layer/twl-orchestrator.sh" ]]; then
        # shellcheck source=/dev/null
        source "${HOME}/.soloptilink/lib/telemetry-wiring-layer/twl-orchestrator.sh"
        twl_run "$dag_exit" || true
    fi

    # ============ Phase 8.5: ARTE-Omega 自動セキュリティ検査 (v2025-v2030 統合) ============
    # 顧客が「セキュリティ」と言わなくても、SoloptiLink AI で作った成果物に対し
    # 16攻撃領域+12防御層+Tier-1+Tier-0+Tier-X を**勝手に**稼働させる。
    # 失敗してもセッション完了を阻害しない (|| true)。
    if [[ -x "${HOME}/.soloptilink/lib/soloptilink-omega-hook.sh" ]] && [[ "${SOLOPTILINK_OMEGA_SKIP:-0}" != "1" ]]; then
        local _omega_mode="quick"
        case "${SOLOPTILINK_BOOST_LEVEL:-1}" in
            3) _omega_mode="closed-loop" ;;
            2) _omega_mode="quick" ;;
        esac
        # キーワード自動格上げ
        if echo "${TASK_DESC:-}" | grep -qE "完璧|最強|金融|医療|公共|重要インフラ|脆弱性ゼロ|ハッキング対策"; then
            _omega_mode="closed-loop"
        fi
        local _omega_target="${PROJECT_DIR:-${SOLOPTILINK_RUNTIME_DIR:-.}}"
        echo ""
        echo "═══════════════════════════════════════════════════════════════════"
        echo "  Phase 8.5: ARTE-Omega 自動セキュリティ検査 (mode=$_omega_mode)"
        echo "═══════════════════════════════════════════════════════════════════"
        bash "${HOME}/.soloptilink/lib/soloptilink-omega-hook.sh" check "$_omega_target" --"$_omega_mode" 2>&1 | tail -10 || true
        if [[ -f "$_omega_target/.soloptilink-omega/omega-summary.json" ]]; then
            local _omega_score
            _omega_score=$(python3 -c "import json;print(json.load(open('$_omega_target/.soloptilink-omega/omega-summary.json')).get('securityScore',0))" 2>/dev/null)
            echo "  🛡️ Security Score (CCS axis): ${_omega_score:-N/A}/100"
        fi
        echo "═══════════════════════════════════════════════════════════════════"
    fi

    # ============ 実行後処理 ============

    _post_execution
    _final_report "$TASK_DESC" "$dag_exit"

    # ============ ランチャー向けステータスファイル出力 ============
    # ランチャーがセッション終了時にphases_completedを読み取る
    local _status_file="${SOLOPTILINK_RUNTIME_DIR:-.}/.soloptilink-status.json"
    local _phases_done="${_COMPLETED_PHASE_COUNT:-0}"
    printf '{"phases_completed":%d,"exit_code":%d,"quality_score":%s}\n' \
        "$_phases_done" "$dag_exit" "${QG_SCORE:-0}" > "$_status_file" 2>/dev/null || true

    # ============================================================
    # REQ-WIRE-004 (v2037): PFP-056 完了マーカー更新 + active マーカー掃除
    # chain.sh がセッション開始後に成功完了したことを記録 (ガードの「chain成功」判定源)。
    # これにより guard line 68 が "chain成功 → 通過" を判定でき、退避ガードが正しく機能する。
    # ============================================================
    printf '{"timestamp":"%s","session_id":"%s","version":"%s","exit_code":%d,"phases_completed":%d,"quality_score":%s}\n' \
        "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "${SESSION_ID:-startup}" "$VERSION" "$dag_exit" "$_phases_done" "${QG_SCORE:-0}" \
        > "${HOME}/.soloptilink/.last_boost_session.json" 2>/dev/null || true
    rm -f "${HOME}/.soloptilink/.boost_session_active.json" 2>/dev/null || true

    # PFP-118: 学習閉ループの実データ化 — セッション記録 + 生成アプリ friction 取込 (best-effort / 本流を止めない)
    [[ -f "${SCRIPT_DIR}/lib/learning-session-recorder.sh" ]] && \
        bash "${SCRIPT_DIR}/lib/learning-session-recorder.sh" record "${PROJECT_DIR:-$PWD}" >/dev/null 2>&1 || true
    if type -t ill_save_learning &>/dev/null; then
        ill_save_learning "${PROJECT_DIR:-$PWD}" 2>/dev/null || true
    fi

    return $dag_exit
}

# ============================================================
# エントリーポイント
# ============================================================
main "$@"
