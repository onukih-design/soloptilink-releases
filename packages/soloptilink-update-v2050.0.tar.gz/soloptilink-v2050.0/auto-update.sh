#!/bin/bash
# ============================================================
# SoloptiLinkAI Auto-Update v2009.4
#
# Claude Code起動時にバックグラウンドで実行される。
# お客さんは何もしなくても常に最新版になる。
#
# 仕組み:
#   1. 24時間キャッシュで頻度制限
#   2. 排他ロック（複数Claude Codeウィンドウ対策）
#   3. APIに最新バージョンを問い合わせ
#   4. 更新があればパッケージをダウンロード
#   5. SHA256検証後、全ファイルを安全に更新
#   6. skills/agents/hooks も含めて完全更新
#   7. 更新後検証ステータスを記録
#
# 配置: ~/.soloptilink/auto-update.sh
# フック: ~/.claude/settings.json の UserPromptSubmit
# ============================================================

# ============================================================
# PFP-101 自己上書き安全化 (2026-06-10): 更新処理は auto-update.sh 自身も
# 置換する。bash は実行中ファイルが置換されると以降を誤読し
# 「command not found / 構文エラー」を吐く (実測: v2034.4→v2038.2 更新時)。
# → 起動直後に一時コピーへ退避し、そちらを再実行することで根絶する。
# ============================================================
if [ -z "${SOLOPTILINK_AUTOUPDATE_REEXEC:-}" ]; then
    _self_tmp=$(mktemp "${TMPDIR:-/tmp}/sl-autoupdate.XXXXXX" 2>/dev/null) || exit 0
    cat "$0" > "$_self_tmp" 2>/dev/null || { rm -f "$_self_tmp"; exit 0; }
    SOLOPTILINK_AUTOUPDATE_REEXEC=1 exec bash "$_self_tmp" "$@"
fi

SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
CLAUDE_DIR="$HOME/.claude"
CACHE_FILE="$SL_DIR/.last_auto_update_check"
API_BASE="${SOLOPTILINK_API_URL:-https://admin-dashboard-blue-alpha-78.vercel.app/api/v1}"
CHECK_INTERVAL=86400  # 24時間
LOG_FILE="$SL_DIR/.auto-update.log"
LOCK_DIR="$SL_DIR/.auto-update.lock"
STATUS_FILE="$SL_DIR/.auto-update-status.json"

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE" 2>/dev/null; }

# ============================================================
# v2034.2 で堅牢化: 共通 curl helper
# - stderr を .error-log に集約 (黙殺禁止)
# - リトライ 3回 / 接続タイムアウト 10秒 / 全体タイムアウト引数化
# - --fail-with-body で HTTP エラー時もボディ取得
# - rc != 0 の時のみ error-log に記録 (成功時はノイズ無し)
# ============================================================
_sl_curl() {
    local method="$1" url="$2" outfile="${3:-}" timeout="${4:-15}"
    local error_log="$SL_DIR/.error-log"
    # PFP-101 (2026-06-10): -L 必須。GitHub Releases 等の 302 リダイレクト配信で
    # 追従しないと空ボディ (0バイト) を保存し DOWNLOAD_TOO_SMALL で全更新が失敗する
    local curl_args=(-s -L --max-redirs 5 --max-time "$timeout" --connect-timeout 10 --retry 3 --retry-delay 2 --fail-with-body)
    [ -n "$outfile" ] && curl_args+=(-o "$outfile")
    local stderr_capture
    stderr_capture=$(mktemp)
    local response rc
    if [ "$method" = "GET" ]; then
        response=$(curl "${curl_args[@]}" "$url" 2>"$stderr_capture")
        rc=$?
    else
        response=$(curl "${curl_args[@]}" -X "$method" "$url" 2>"$stderr_capture")
        rc=$?
    fi
    if [ $rc -ne 0 ]; then
        echo "$(date '+%Y-%m-%dT%H:%M:%S') [curl] FAIL rc=$rc url=$url $(cat "$stderr_capture" | tr '\n' ' ' | head -c 200)" >> "$error_log" 2>/dev/null
    fi
    rm -f "$stderr_capture"
    [ $rc -eq 0 ] && echo "$response"
    return $rc
}

# ========================================
# 排他ロック（複数ウィンドウ同時実行防止）
# ========================================
# mkdir はアトミック操作 → 安全なロック
if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    # ロックが存在 → 別インスタンスが実行中
    # ただし5分以上経過したロックはスタール（古い）とみなす
    if [ -d "$LOCK_DIR" ]; then
        LOCK_MTIME=$(stat -f %m "$LOCK_DIR" 2>/dev/null || stat -c %Y "$LOCK_DIR" 2>/dev/null || echo 0)
        NOW_TS=$(date +%s)
        LOCK_AGE=$((NOW_TS - LOCK_MTIME))
        if [ "$LOCK_AGE" -gt 300 ]; then
            rmdir "$LOCK_DIR" 2>/dev/null
            mkdir "$LOCK_DIR" 2>/dev/null || exit 0
        else
            exit 0
        fi
    else
        exit 0
    fi
fi
# ロック解除のtrap（親プロセス終了時）+ 自己コピー掃除 (PFP-101)
trap "rmdir '$LOCK_DIR' 2>/dev/null; rm -f '$0' 2>/dev/null" EXIT

# ========================================
# 強制更新フラグ（--force または SOLOPTILINK_FORCE_UPDATE=1）
# ========================================
FORCE_UPDATE=false
if [ "${1:-}" = "--force" ] || [ "${SOLOPTILINK_FORCE_UPDATE:-${SOLAI_FORCE_UPDATE:-0}}" = "1" ]; then
    FORCE_UPDATE=true
fi

# ========================================
# 頻度チェック（24時間以内ならスキップ、--force時は無視）
# ========================================
if [ "$FORCE_UPDATE" = false ] && [ -f "$CACHE_FILE" ]; then
    LAST_CHECK=$(cat "$CACHE_FILE" 2>/dev/null || echo "0")
    # 数値チェック
    case "$LAST_CHECK" in
        ''|*[!0-9]*) LAST_CHECK=0 ;;
    esac
    NOW=$(date +%s)
    ELAPSED=$((NOW - LAST_CHECK))
    if [ "$ELAPSED" -lt "$CHECK_INTERVAL" ]; then
        exit 0
    fi
fi

# ========================================
# 現在のバージョンを取得
# ========================================
CURRENT_VERSION=""
if [ -f "$SL_DIR/chain.sh" ]; then
    CURRENT_VERSION=$(grep 'readonly VERSION=' "$SL_DIR/chain.sh" 2>/dev/null | head -1 | grep -o '"[^"]*"' | tr -d '"')
elif [ -f "$SL_DIR/VERSION" ]; then
    CURRENT_VERSION=$(cat "$SL_DIR/VERSION" 2>/dev/null | tr -d '[:space:]')
fi
# chain.sh も VERSION も無い → 初回インストール扱い（バージョン0.0.0として更新チェック）
[ -z "$CURRENT_VERSION" ] && CURRENT_VERSION="0.0.0"

# ========================================
# Migration 自動適用 (idempotent / NOOP if applied)
# v2027.0+ 既存顧客遡及配線レーン
# ========================================
if [ -d "$SL_DIR/migration" ]; then
    for mig in "$SL_DIR/migration/"v*.sh; do
        [ -f "$mig" ] || continue
        mig_name=$(basename "$mig" .sh)
        # state ファイルを読み、既に適用済みの migration はスキップ
        if [ -f "$SL_DIR/.migration-state.json" ] && grep -q "\"${mig_name}\"" "$SL_DIR/.migration-state.json" 2>/dev/null; then
            continue
        fi
        bash "$mig" >> "$SL_DIR/.migration.log" 2>&1 || true
    done
fi

# バージョン文字列をサニタイズ（URL安全化）
SAFE_VERSION=$(echo "$CURRENT_VERSION" | tr -cd '0-9.')
[ -z "$SAFE_VERSION" ] && exit 0

# ========================================
# APIで最新バージョンをチェック
# ========================================
OS=$(uname -s | tr '[:upper:]' '[:lower:]')
ARCH=$(uname -m)
case "$ARCH" in
    x86_64)        ARCH="amd64" ;;
    aarch64|arm64) ARCH="arm64" ;;
esac

# OS 正規化 (2026-06-16): Git Bash/MSYS/Cygwin の uname は mingw64_nt-... 等になる。
# updates/check の os パラメータ・/updates/download・ランチャー実体名は windows で扱う必要がある。
API_OS="$OS"
LAUNCHER_NAME="soloptilink"
case "$OS" in
    mingw*|msys*|cygwin*|windows*) API_OS="windows"; LAUNCHER_NAME="soloptilink.exe" ;;
esac

# タイムスタンプ更新（失敗しても24時間待つ）
date +%s > "$CACHE_FILE"

# ========================================
# v2038.4: 軽量バージョン報告 (テレメトリ盲点の補完 / PFP-telemetry)
# ----------------------------------------
# ランチャー (./soloptilink <task>) を起動しない Desktop / 休眠端末は heartbeat を
# 送らず版数が届かない盲点があった。Claude Code セッションごとに必ず走る本スクリプト
# から直接 heartbeat を送り、版数を届ける。非ブロッキング (起動を遅延させない)・失敗黙殺。
# サーバ世代差の保険として current_version と app_version を両キー送信する。
# ========================================
_sl_report_version() {
    command -v python3 >/dev/null 2>&1 || return 0
    command -v curl >/dev/null 2>&1 || return 0
    local act="$SL_DIR/activation.json" lic="$SL_DIR/license.json"
    [ -f "$act" ] && [ -f "$lic" ] || return 0
    local hb_json
    hb_json=$(CUR_VER="$CURRENT_VERSION" ACT="$act" LIC="$lic" python3 -c "
import json, os
try:
    act = json.load(open(os.environ['ACT']))
    lic = json.load(open(os.environ['LIC']))
    did = lic.get('device_id') or act.get('device_id') or ''
    tok = lic.get('token') or ''
    fp  = act.get('fingerprint') or ''
    if not (did and tok and fp):
        raise SystemExit(0)
    ver = (os.environ.get('CUR_VER','') or '').lstrip('v')
    body = {'device_id': did, 'fingerprint': fp, 'token': tok,
            'current_version': ver, 'app_version': ver}
    em = act.get('email')
    if em:
        body['email'] = em
    print(json.dumps(body))
except Exception:
    pass
" 2>/dev/null)
    [ -n "$hb_json" ] || return 0
    curl -s -L --max-time 8 --connect-timeout 5 \
        -X POST -H "Content-Type: application/json" \
        -d "$hb_json" "${API_BASE}/devices/heartbeat" >/dev/null 2>&1 || true
}
# 非ブロッキングで実行 (更新有無に依存せず毎回・親の exit を待たせない)
( _sl_report_version ) >/dev/null 2>&1 &

# APIに問い合わせ (v2034.2 堅牢化: _sl_curl で 15s/retry3/error-log 集約)
UPDATE_RESPONSE=$(_sl_curl GET "${API_BASE}/updates/check?version=${SAFE_VERSION}&os=${API_OS}&arch=${ARCH}" || echo "")

[ -z "$UPDATE_RESPONSE" ] && exit 0

# python3がなければ終了
command -v python3 >/dev/null 2>&1 || exit 0

# ========================================
# Goランチャーバイナリの SHA ベース更新 (2026-06-16 全顧客自動更新到達保証)
# ----------------------------------------
# 課題(version-coupling): バイナリの版は chain.sh から動的取得されるため、平文が
# 新版に上がるとバイナリも新版を名乗り、updates/check が available=false を返して
# バイナリが永遠に更新されない。これを断つため、版の available 判定とは独立に
# 「配信バイナリの sha256」と「ローカルバイナリの sha256」を比較し、異なれば
# /updates/download から取得して置換する (updates/check は available=false でも
# sha256 を返すため成立)。これによりフック稼働中の既存端末にも、自己回復を備えた
# 新ランチャーが平文更新の次サイクルで自動的に届く。
# 管理者端末 (.admin_mode) は dev ビルド保護のためスキップ。
# ========================================
# 版文字列を比較可能な整数へ (2040.0 -> 2040000000)。BSD/GNU 両対応。
_sl_vernum() {
    printf '%s' "${1#v}" | awk -F. '{printf "%d%06d%06d\n", ($1+0), ($2+0), ($3+0)}' 2>/dev/null
}
_sl_update_binary_if_sha_differs() {
    [ -f "$SL_DIR/.admin_mode" ] && return 0
    # ランチャー実体名は OS 依存 (Windows=soloptilink.exe)。実行中でない名前を対象にする。
    local launcher="$SL_DIR/$LAUNCHER_NAME"
    [ -f "$launcher" ] || return 0
    local served_sha served_ver
    served_sha=$(UPDATE_RESPONSE="$UPDATE_RESPONSE" python3 -c "
import json,os
try:
    print((json.loads(os.environ['UPDATE_RESPONSE']).get('sha256') or '').strip())
except Exception:
    pass
" 2>/dev/null)
    served_ver=$(UPDATE_RESPONSE="$UPDATE_RESPONSE" python3 -c "
import json,os
try:
    print((json.loads(os.environ['UPDATE_RESPONSE']).get('version') or '').strip())
except Exception:
    pass
" 2>/dev/null)
    [ -n "$served_sha" ] || return 0
    # 単調前進ガード(ダウングレード防止): ローカル版が配信版より新しければ置換しない。
    if [ -n "$served_ver" ]; then
        local lv sv
        lv=$(_sl_vernum "$CURRENT_VERSION"); sv=$(_sl_vernum "$served_ver")
        if [ -n "$lv" ] && [ -n "$sv" ] && [ "$lv" -gt "$sv" ] 2>/dev/null; then
            return 0
        fi
    fi
    local local_sha
    local_sha=$(shasum -a 256 "$launcher" 2>/dev/null | cut -d' ' -f1)
    [ -n "$local_sha" ] || return 0
    served_sha=$(printf '%s' "$served_sha" | tr 'A-Z' 'a-z')
    if [ "$served_sha" = "$(printf '%s' "$local_sha" | tr 'A-Z' 'a-z')" ]; then
        rm -f "$SL_DIR/.binupdate-failed-sha" 2>/dev/null   # 一致=最新→失敗マーカー解除
        return 0
    fi
    # 無限DL防止: この配信 sha で前回失敗(7日以内)ならスキップ
    local fail_marker="$SL_DIR/.binupdate-failed-sha"
    if [ -f "$fail_marker" ]; then
        local f_sha f_ts now
        f_sha=$(cut -d'|' -f1 "$fail_marker" 2>/dev/null | tr 'A-Z' 'a-z' | tr -d ' ')
        f_ts=$(cut -d'|' -f2 "$fail_marker" 2>/dev/null | tr -d ' ')
        now=$(date +%s)
        if [ "$f_sha" = "$served_sha" ] && [ -n "$f_ts" ] && [ $((now - f_ts)) -lt 604800 ] 2>/dev/null; then
            return 0
        fi
    fi
    local bin_url="${API_BASE}/updates/download?os=${API_OS}&arch=${ARCH}"
    local tmp_bin
    tmp_bin=$(mktemp "${TMPDIR:-/tmp}/sl-bin.XXXXXX") || return 0
    if ! _sl_curl GET "$bin_url" "$tmp_bin" 120 >/dev/null; then
        printf '%s|%s' "$served_sha" "$(date +%s)" > "$fail_marker" 2>/dev/null
        rm -f "$tmp_bin"; return 0
    fi
    local got_sha got_size
    got_size=$(wc -c < "$tmp_bin" | tr -d ' ')
    if [ "${got_size:-0}" -lt 1048576 ]; then  # 1MB未満は不完全DL
        printf '%s|%s' "$served_sha" "$(date +%s)" > "$fail_marker" 2>/dev/null
        rm -f "$tmp_bin"; return 0
    fi
    got_sha=$(shasum -a 256 "$tmp_bin" 2>/dev/null | cut -d' ' -f1 | tr 'A-Z' 'a-z')
    if [ "$got_sha" != "$served_sha" ]; then
        log "BINARY_SHA_MISMATCH served=$served_sha got=$got_sha"
        printf '%s|%s' "$served_sha" "$(date +%s)" > "$fail_marker" 2>/dev/null
        rm -f "$tmp_bin"; return 0
    fi
    rm -f "$fail_marker" 2>/dev/null
    # rename-backup 方式で置換 (実行中.exeのロック時も .backup から復元可能)
    chmod +x "$tmp_bin" 2>/dev/null || true
    local backup="${launcher}.backup"
    rm -f "$backup" 2>/dev/null
    if mv "$launcher" "$backup" 2>/dev/null; then
        if mv "$tmp_bin" "$launcher" 2>/dev/null; then
            chmod +x "$launcher" 2>/dev/null || true
            rm -f "$backup" 2>/dev/null
            log "BINARY_UPDATED_BY_SHA ($LAUNCHER_NAME) -> $served_sha"
        else
            mv "$backup" "$launcher" 2>/dev/null   # 復元
            rm -f "$tmp_bin"
        fi
    else
        # rename 不可(実行中ロック等) → 直接上書きを試行、不可なら次サイクルへ
        if cp "$tmp_bin" "$launcher" 2>/dev/null; then
            chmod +x "$launcher" 2>/dev/null || true
            log "BINARY_UPDATED_BY_SHA_CP ($LAUNCHER_NAME) -> $served_sha"
        fi
        rm -f "$tmp_bin"
    fi
}
# 版の available 判定より前に実行 (平文が最新でもバイナリだけ古いケースを救う)
_sl_update_binary_if_sha_differs

# レスポンス解析（環境変数経由で安全に渡す、改行区切りで出力）
# package_url を優先使用（skills/agents/hooks パッケージ用）
# package_url がない場合は download_url にフォールバック
PARSE_RESULT=$(UPDATE_RESPONSE="$UPDATE_RESPONSE" python3 -c "
import json, os, re, sys
try:
    d = json.loads(os.environ['UPDATE_RESPONSE'])
    if not d.get('available', False):
        sys.exit(0)
    ver = d.get('version', '')
    # package_url を優先、なければ download_url
    url = d.get('package_url', '') or d.get('download_url', '')
    sha = d.get('package_sha256', '') or d.get('sha256', '')
    # バージョン形式検証
    if not re.match(r'^[0-9]+\.[0-9]+(\.[0-9]+)?$', ver):
        sys.exit(0)
    # URL検証（httpsのみ許可）
    if not url.startswith('https://'):
        sys.exit(0)
    # 改行区切りで出力（URLにパイプが含まれても安全）
    print(ver)
    print(url)
    print(sha)
except (json.JSONDecodeError, KeyError, TypeError):
    pass
" 2>/dev/null)

[ -z "$PARSE_RESULT" ] && exit 0

# パース結果を分解（改行区切り）
NEW_VERSION=$(echo "$PARSE_RESULT" | sed -n '1p')
DOWNLOAD_URL=$(echo "$PARSE_RESULT" | sed -n '2p')
EXPECTED_SHA256=$(echo "$PARSE_RESULT" | sed -n '3p')

[ -z "$NEW_VERSION" ] && exit 0
[ -z "$DOWNLOAD_URL" ] && exit 0

log "UPDATE_AVAILABLE v${CURRENT_VERSION} -> v${NEW_VERSION}"

# ========================================
# 更新処理関数
# ========================================
do_update() {
    TEMP_DIR=$(mktemp -d)
    # PFP-101: do_update 内の trap はグローバル EXIT trap を置換するため、
    # ロック解除 + 自己コピー掃除も合わせて引き継ぐ (trap 上書き事故の根絶)
    trap "rm -rf '$TEMP_DIR'; rmdir '$LOCK_DIR' 2>/dev/null; rm -f '$0' 2>/dev/null" EXIT
    PACKAGE_FILE="$TEMP_DIR/solai-update.tar.gz"

    write_status() {
        local status="$1" message="$2"
        cat > "$STATUS_FILE" << STATUSEOF
{"status":"${status}","version":"${NEW_VERSION}","from":"${CURRENT_VERSION}","message":"${message}","timestamp":"$(date -u '+%Y-%m-%dT%H:%M:%SZ')"}
STATUSEOF
        # [PFP-117] 更新失敗を管理ダッシュボードへ自動報告 (silent / 非ブロッキング)
        if [ "$status" = "failed" ] && [ -f "$SL_DIR/lib/cognitive/customer-error-reporter.sh" ]; then
            bash "$SL_DIR/lib/cognitive/customer-error-reporter.sh" "auto-update-failure" "v${CURRENT_VERSION:-unknown} -> v${NEW_VERSION:-unknown}: ${message:-}" 2>/dev/null || true
        fi
    }

    # v2034.2 堅牢化: append-only 履歴 (途中過程を全て保持 / status.json の上書き喪失問題を解消)
    _append_history() {
        local status="$1" version="$2" message="$3"
        local history="$SL_DIR/.auto-update-history.jsonl"
        echo "{\"ts\":\"$(date -u '+%Y-%m-%dT%H:%M:%SZ')\",\"status\":\"$status\",\"from\":\"$CURRENT_VERSION\",\"version\":\"$version\",\"message\":\"$message\"}" >> "$history" 2>/dev/null
    }

    write_status "downloading" "パッケージダウンロード中"
    _append_history "downloading" "${NEW_VERSION:-$CURRENT_VERSION}" "パッケージダウンロード中"

    # v2034.8 / PFP-057 + PFP-080: DOWNLOAD_TOO_SMALL リトライロジック (下限引き上げ)
    # transient 障害 (release 直後の asset upload race / CDN cold cache) を救う
    # 最大4回、5分間隔で再試行 (合計15分以内に復旧する transient 障害をカバー)
    DOWNLOAD_RETRY_MAX=4
    DOWNLOAD_RETRY_INTERVAL=300  # 5分
    # PFP-080 (v2034.8 2026-05-27): 100bytes → 10240bytes (10KB)
    # 正規の tar.gz は MB 単位なので 10KB 未満は確実に不完全ダウンロード。
    # 監査C指摘の「5KB未満の不完全ダウンロードが漏れる」可能性を構造的根絶。
    # 環境変数 SL_DOWNLOAD_MIN_SIZE で上書き可能 (将来 release asset metadata 動的読取に発展)。
    DOWNLOAD_MIN_SIZE="${SL_DOWNLOAD_MIN_SIZE:-10240}"
    DOWNLOAD_ATTEMPT=0
    DOWNLOAD_SUCCESS=0

    while [ "$DOWNLOAD_ATTEMPT" -lt "$DOWNLOAD_RETRY_MAX" ]; do
        DOWNLOAD_ATTEMPT=$((DOWNLOAD_ATTEMPT + 1))

        # v2034.2 堅牢化: 90秒 / retry3 / connect-timeout 10s / stderr→error-log
        if ! _sl_curl GET "$DOWNLOAD_URL" "$PACKAGE_FILE" 90 >/dev/null; then
            log "DOWNLOAD_FAILED attempt=${DOWNLOAD_ATTEMPT}/${DOWNLOAD_RETRY_MAX} $DOWNLOAD_URL"
            if [ "$DOWNLOAD_ATTEMPT" -lt "$DOWNLOAD_RETRY_MAX" ]; then
                log "DOWNLOAD_RETRY_WAIT ${DOWNLOAD_RETRY_INTERVAL}s (next attempt=$((DOWNLOAD_ATTEMPT + 1)))"
                sleep "$DOWNLOAD_RETRY_INTERVAL"
                continue
            fi
            write_status "failed" "ダウンロード失敗 (${DOWNLOAD_RETRY_MAX}回試行)"
            _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "ダウンロード失敗 (curl rc != 0, ${DOWNLOAD_RETRY_MAX}回試行)"
            return 1
        fi

        FILE_SIZE=$(wc -c < "$PACKAGE_FILE" | tr -d ' ')
        if [ "$FILE_SIZE" -lt "$DOWNLOAD_MIN_SIZE" ]; then
            log "DOWNLOAD_TOO_SMALL attempt=${DOWNLOAD_ATTEMPT}/${DOWNLOAD_RETRY_MAX} ${FILE_SIZE}bytes"
            if [ "$DOWNLOAD_ATTEMPT" -lt "$DOWNLOAD_RETRY_MAX" ]; then
                log "DOWNLOAD_RETRY_WAIT ${DOWNLOAD_RETRY_INTERVAL}s (transient障害可能性: CDN cold cache or asset upload race)"
                write_status "retrying" "ダウンロードサイズ異常 (${FILE_SIZE}bytes) - ${DOWNLOAD_RETRY_INTERVAL}秒後にリトライ (${DOWNLOAD_ATTEMPT}/${DOWNLOAD_RETRY_MAX})"
                sleep "$DOWNLOAD_RETRY_INTERVAL"
                continue
            fi
            log "DOWNLOAD_TOO_SMALL_FINAL ${FILE_SIZE}bytes after ${DOWNLOAD_RETRY_MAX} attempts"
            write_status "failed" "ダウンロードサイズ異常 (${FILE_SIZE}bytes, ${DOWNLOAD_RETRY_MAX}回試行)"
            _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "ダウンロードサイズ異常 (${FILE_SIZE}bytes, ${DOWNLOAD_RETRY_MAX}回試行)"
            return 1
        fi

        # サイズOK → 抜ける
        DOWNLOAD_SUCCESS=1
        if [ "$DOWNLOAD_ATTEMPT" -gt 1 ]; then
            log "DOWNLOAD_RETRY_SUCCESS attempt=${DOWNLOAD_ATTEMPT} size=${FILE_SIZE}bytes"
        fi
        break
    done

    if [ -n "$EXPECTED_SHA256" ]; then
        ACTUAL_SHA256=$(shasum -a 256 "$PACKAGE_FILE" 2>/dev/null | cut -d' ' -f1)
        if [ "$ACTUAL_SHA256" != "$EXPECTED_SHA256" ]; then
            log "CHECKSUM_MISMATCH expected=$EXPECTED_SHA256 actual=$ACTUAL_SHA256"
            write_status "failed" "チェックサム不一致"
            _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "チェックサム不一致 expected=$EXPECTED_SHA256 actual=$ACTUAL_SHA256"
            return 1
        fi
        log "CHECKSUM_VERIFIED $ACTUAL_SHA256"
    fi

    write_status "extracting" "パッケージ展開中"
    _append_history "extracting" "${NEW_VERSION:-$CURRENT_VERSION}" "パッケージ展開中"

    EXTRACT_DIR="$TEMP_DIR/extracted"
    mkdir -p "$EXTRACT_DIR"

    if file "$PACKAGE_FILE" 2>/dev/null | grep -q "gzip"; then
        tar xzf "$PACKAGE_FILE" -C "$EXTRACT_DIR" 2>/dev/null
    elif file "$PACKAGE_FILE" 2>/dev/null | grep -q "Zip"; then
        unzip -qo "$PACKAGE_FILE" -d "$EXTRACT_DIR" 2>/dev/null
    else
        case "$PACKAGE_FILE" in
            *.tar.gz|*.tgz) tar xzf "$PACKAGE_FILE" -C "$EXTRACT_DIR" 2>/dev/null ;;
            *.zip) unzip -qo "$PACKAGE_FILE" -d "$EXTRACT_DIR" 2>/dev/null ;;
            *) tar xzf "$PACKAGE_FILE" -C "$EXTRACT_DIR" 2>/dev/null || unzip -qo "$PACKAGE_FILE" -d "$EXTRACT_DIR" 2>/dev/null ;;
        esac
    fi

    if [ ! "$(ls -A "$EXTRACT_DIR" 2>/dev/null)" ]; then
        log "EXTRACT_FAILED"
        write_status "failed" "パッケージ展開失敗"
        _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "パッケージ展開失敗 (empty extract dir)"
        return 1
    fi

    SUBDIRS=$(find "$EXTRACT_DIR" -mindepth 1 -maxdepth 1 -type d 2>/dev/null)
    SUBDIR_COUNT=$(echo "$SUBDIRS" | grep -c '.' 2>/dev/null || echo 0)
    if [ "$SUBDIR_COUNT" -eq 1 ] && [ ! -f "$EXTRACT_DIR/chain.sh" ]; then
        EXTRACT_DIR="$SUBDIRS"
    fi

    write_status "applying" "更新適用中"
    _append_history "applying" "${NEW_VERSION:-$CURRENT_VERSION}" "更新適用中"

    # バックアップ
    SAFE_CUR=$(echo "$CURRENT_VERSION" | tr -cd '0-9.')
    BACKUP_DIR="$SL_DIR/.backups/v${SAFE_CUR}_$(date +%Y%m%d%H%M%S)"
    mkdir -p "$BACKUP_DIR"
    cp "$SL_DIR/chain.sh" "$BACKUP_DIR/" 2>/dev/null || true
    cp "$SL_DIR/setup.sh" "$BACKUP_DIR/" 2>/dev/null || true
    if [ -d "$CLAUDE_DIR/skills" ]; then
        mkdir -p "$BACKUP_DIR/skills"
        for skill_dir in "$CLAUDE_DIR/skills/soloptilink"*/; do
            [ ! -d "$skill_dir" ] && continue
            skill_name=$(basename "$skill_dir")
            mkdir -p "$BACKUP_DIR/skills/$skill_name"
            cp "$skill_dir/SKILL.md" "$BACKUP_DIR/skills/$skill_name/" 2>/dev/null || true
        done
    fi

    log "BACKUP $BACKUP_DIR"

    # ステージング
    STAGE_DIR="$TEMP_DIR/staging"
    mkdir -p "$STAGE_DIR"
    UPDATE_COUNT=0
    STAGE_OK=true

    [ -f "$EXTRACT_DIR/chain.sh" ] && { cp "$EXTRACT_DIR/chain.sh" "$STAGE_DIR/chain.sh" || STAGE_OK=false; UPDATE_COUNT=$((UPDATE_COUNT + 1)); }
    [ -f "$EXTRACT_DIR/setup.sh" ] && { cp "$EXTRACT_DIR/setup.sh" "$STAGE_DIR/setup.sh" || STAGE_OK=false; UPDATE_COUNT=$((UPDATE_COUNT + 1)); }
    [ -f "$EXTRACT_DIR/VERSION" ] && { cp "$EXTRACT_DIR/VERSION" "$STAGE_DIR/VERSION" || STAGE_OK=false; UPDATE_COUNT=$((UPDATE_COUNT + 1)); }
    if [ -d "$EXTRACT_DIR/lib" ]; then
        mkdir -p "$STAGE_DIR/lib"
        rsync -a --delete "$EXTRACT_DIR/lib/" "$STAGE_DIR/lib/" || STAGE_OK=false
        UPDATE_COUNT=$((UPDATE_COUNT + 1))
    fi

    if [ "$STAGE_OK" = false ]; then
        log "STAGING_FAILED"
        write_status "failed" "ステージング失敗"
        _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "ステージング失敗 (cp / rsync エラー)"
        return 1
    fi

    # 本適用
    [ -f "$STAGE_DIR/chain.sh" ] && { cp "$STAGE_DIR/chain.sh" "$SL_DIR/chain.sh"; chmod +x "$SL_DIR/chain.sh"; }
    [ -f "$STAGE_DIR/setup.sh" ] && { cp "$STAGE_DIR/setup.sh" "$SL_DIR/setup.sh"; chmod +x "$SL_DIR/setup.sh"; }
    [ -f "$STAGE_DIR/VERSION" ] && cp "$STAGE_DIR/VERSION" "$SL_DIR/VERSION"
    if [ -d "$STAGE_DIR/lib" ]; then
        rsync -a --delete "$STAGE_DIR/lib/" "$SL_DIR/lib/"
        find "$SL_DIR/lib/" -name '*.sh' -exec chmod +x {} + 2>/dev/null
    fi
    # ========================================
    # v2041.0 / PFP-122 (2026-06-13): DBL業種辞書 domains/ + IBL連携辞書 integrations/ を同期。
    # 【重大欠陥の修正】従来 do_update は domains/integrations を一切同期せず、
    # 業種辞書・連携辞書の追加/更新が既存顧客の自動更新で永遠に届かなかった。
    # パッケージに含まれる場合のみ rsync (含まれない旧パッケージで顧客の既存辞書を
    # 消さないよう、ディレクトリ存在を条件にする = 後方互換)。
    # ========================================
    # 重要: --delete を使わず overlay 同期にする。boost(Step 0.8)は未登録業種の DBL を、
    # Connector Forge(Step 0.9)は未登録サービスの連携辞書を顧客の domains//integrations/ に
    # 作成するため、--delete だと更新のたびに顧客/FDE が作った辞書を消してしまう(データ消失)。
    # overlay なら公式辞書は新版で上書き更新しつつ、顧客作成辞書を保全できる。
    for kb in domains integrations; do
        if [ -d "$EXTRACT_DIR/$kb" ] && [ -n "$(ls -A "$EXTRACT_DIR/$kb" 2>/dev/null)" ]; then
            mkdir -p "$SL_DIR/$kb"
            if rsync -a "$EXTRACT_DIR/$kb/" "$SL_DIR/$kb/" 2>/dev/null; then
                kb_n=$(find "$SL_DIR/$kb" -name '*.json' 2>/dev/null | wc -l | tr -d ' ')
                UPDATE_COUNT=$((UPDATE_COUNT + 1))
                log "KB_SYNCED $kb ($kb_n dictionaries, overlay)"
            fi
        fi
    done
    [ -f "$EXTRACT_DIR/version-manifest.json" ] && cp "$EXTRACT_DIR/version-manifest.json" "$SL_DIR/version-manifest.json"
    [ -f "$EXTRACT_DIR/auto-update.sh" ] && { cp "$EXTRACT_DIR/auto-update.sh" "$SL_DIR/auto-update.sh"; chmod +x "$SL_DIR/auto-update.sh"; }

    # ========================================
    # Goランチャーバイナリの配布
    # パッケージ内の bin/ ディレクトリからOS/Arch一致バイナリを配置
    # ========================================
    BIN_DEPLOYED=false
    # 配置先はランチャー実体名 (Windows=soloptilink.exe / それ以外=soloptilink)。
    BIN_TARGET="$SL_DIR/$LAUNCHER_NAME"
    if [ -d "$EXTRACT_DIR/bin" ]; then
        # OS/Archに合ったバイナリを選択 (Windows は .exe サフィックス)
        BIN_NAME="soloptilink-${API_OS}-${ARCH}"
        [ "$API_OS" = "windows" ] && BIN_NAME="soloptilink-windows-${ARCH}.exe"
        if [ -f "$EXTRACT_DIR/bin/$BIN_NAME" ]; then
            cp "$EXTRACT_DIR/bin/$BIN_NAME" "$BIN_TARGET"
            chmod +x "$BIN_TARGET" 2>/dev/null || true
            BIN_DEPLOYED=true
            UPDATE_COUNT=$((UPDATE_COUNT + 1))
            log "BINARY_DEPLOYED $BIN_NAME -> $BIN_TARGET"
        fi
    fi
    # フォールバック: パッケージ直下の soloptilink バイナリ
    if [ "$BIN_DEPLOYED" = false ] && [ -f "$EXTRACT_DIR/soloptilink" ]; then
        cp "$EXTRACT_DIR/soloptilink" "$BIN_TARGET"
        chmod +x "$BIN_TARGET" 2>/dev/null || true
        UPDATE_COUNT=$((UPDATE_COUNT + 1))
        log "BINARY_DEPLOYED soloptilink -> $BIN_TARGET"
    fi

    # skills/agents/hooks → ~/.claude/
    if [ -d "$EXTRACT_DIR/skills" ]; then
        for skill_dir in "$EXTRACT_DIR/skills/"*/; do
            [ ! -d "$skill_dir" ] && continue
            skill_name=$(basename "$skill_dir")
            mkdir -p "$CLAUDE_DIR/skills/$skill_name"
            [ -f "$skill_dir/SKILL.md" ] && { cp "$skill_dir/SKILL.md" "$CLAUDE_DIR/skills/$skill_name/SKILL.md"; UPDATE_COUNT=$((UPDATE_COUNT + 1)); }
        done
    fi
    if [ -d "$EXTRACT_DIR/agents" ]; then
        mkdir -p "$CLAUDE_DIR/agents"
        for agent_file in "$EXTRACT_DIR/agents/"*.md; do
            [ ! -f "$agent_file" ] && continue
            cp "$agent_file" "$CLAUDE_DIR/agents/"
            UPDATE_COUNT=$((UPDATE_COUNT + 1))
        done
    fi
    if [ -f "$EXTRACT_DIR/hooks/soloptilink-session-guard.sh" ]; then
        mkdir -p "$CLAUDE_DIR/hooks"
        cp "$EXTRACT_DIR/hooks/soloptilink-session-guard.sh" "$CLAUDE_DIR/hooks/"
        chmod +x "$CLAUDE_DIR/hooks/soloptilink-session-guard.sh"
        UPDATE_COUNT=$((UPDATE_COUNT + 1))
    fi

    # クリーンアップ
    if [ -d "$SL_DIR/.backups" ]; then
        ls -td "$SL_DIR/.backups/"*/ 2>/dev/null | tail -n +6 | while IFS= read -r old_dir; do
            rm -rf "$old_dir"
        done
    fi

    write_status "success" "v${CURRENT_VERSION} -> v${NEW_VERSION} (${UPDATE_COUNT} files)"
    _append_history "success" "${NEW_VERSION:-$CURRENT_VERSION}" "v${CURRENT_VERSION} -> v${NEW_VERSION} (${UPDATE_COUNT} files)"
    log "UPDATE_COMPLETE v${CURRENT_VERSION} -> v${NEW_VERSION} (${UPDATE_COUNT} files)"

    # PFP-064: do_update が Go embed writeback で ~/.claude/skills/ を古いバージョンに
    # 書き戻してしまった場合、即座に SoT (~/.claude/commands/<name>.md) から修復する。
    # 失敗しても無視 (do_update の成功 status を上書きしない)。
    if [ -x "${HOME}/.soloptilink/scripts/structural-defenses/skill-sot-guard.sh" ]; then
        bash "${HOME}/.soloptilink/scripts/structural-defenses/skill-sot-guard.sh" heal --silent 2>&1 >> "$LOG_FILE" || true
    fi

    # PFP-093: 顧客端末で Centuria ロスター (105体実起動エンジンの依存) を確実に生成する。
    # 配信される ~/.claude/agents/*.md (118体) から centuria-roster.json を再構築し、
    # 「105体が本物として動く」エンジンが顧客端末で初回から成立する状態を保証する。
    if [ -x "${HOME}/.soloptilink/lib/centuria-roster.sh" ]; then
        bash "${HOME}/.soloptilink/lib/centuria-roster.sh" build 2>&1 >> "$LOG_FILE" || true
    fi
}

# ========================================
# 実行モード分岐
# ========================================
if [ "$FORCE_UPDATE" = true ]; then
    # フォアグラウンド実行（Goランチャーの --update から呼ばれる）
    do_update
    echo "[SoloptiLinkAI] v${CURRENT_VERSION} → v${NEW_VERSION} パッケージ更新完了"
else
    # バックグラウンド実行（フック経由）
    ( do_update ) >> "$LOG_FILE" 2>&1 &
    cat << EOF
<user-prompt-submit-hook>
[SoloptiLinkAI] v${NEW_VERSION} への自動更新をバックグラウンドで開始しました。
完了後、次のセッションから新バージョンが適用されます。
</user-prompt-submit-hook>
EOF
fi

exit 0
