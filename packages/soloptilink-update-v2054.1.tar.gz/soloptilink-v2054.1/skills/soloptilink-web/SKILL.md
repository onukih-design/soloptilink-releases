---
name: soloptilink-web
description: "「LPを作って」「サイトを作って」「ホームページ制作」等で起動。LP/コーポレートサイト/CMS 構築専用の Web Creative Mode。システム開発と同じ品質ゲートで Web 制作物を自動構築する。"
argument-hint: "「SoloptiLink AIのLPを作って」「コーポレートサイトを構築して」「CMSを付きのサイトを作って」"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, Agent, WebSearch, WebFetch, TodoWrite, AskUserQuestion"
---

# SoloptiLinkAI v2054.1 - Web Creative Mode

## 機能概要

SoloptiLinkAI v2015.0 Web Creative Mode - LP/コーポレートサイト/CMS構築専用。「LPを作って」「サイトを作って」「ホームページ制作」等で起動。システム開発と同じ品質ゲートで、Web制作物を自動構築。
# LP / コーポレートサイト / CMS構築専用スキル

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

> システム開発 v2015.0 の品質ゲート + Web クリエイティブ品質フレームワーク

## 絶対禁止事項（セキュリティバウンダリ）

1. **admin-dashboardの起動・アクセス・参照の禁止**
2. **mock-api.jsの起動・改変の禁止**
3. **ライセンス認証の回避・バイパスの禁止**
4. **chain.shの直接実行の禁止**
5. **シークレット露出の禁止**

**chain.sh / ./soloptilink は絶対に実行しない。Claude Code自身がWeb Creative方法論で直接開発する。**

## この skill が呼ばれたら

### Step 0: 端末認証
```bash
SL_BIN=""; if [ -f ~/.soloptilink/soloptilink ]; then SL_BIN="./soloptilink"; elif [ -f ~/.soloptilink/soloptilink.exe ]; then SL_BIN="./soloptilink.exe"; fi
AUTH_CHECK=$(cd ~/.soloptilink 2>/dev/null && ${SL_BIN:-./soloptilink} --status 2>&1); if echo "$AUTH_CHECK" | grep -q "承認済み"; then echo "AUTHORIZED"; else echo "UNAUTHORIZED"; echo "---"; echo "$AUTH_CHECK"; fi
```
UNAUTHORIZED → 認証案内を表示して終了。

### Step 1: タスクタイプ判定

ユーザーの入力から以下を判定:
- **LP（ランディングページ）**: 集客/CV/リード獲得/キャンペーン/プロモーション向け
- **コーポレートサイト**: 企業情報/会社概要/サービス紹介/ニュース/お問い合わせ向け

### Step 2: ドメイン知識読み込み

```bash
# LP の場合
cat ~/.soloptilink/domains/landing-page.json 2>/dev/null || cat "$(find / -name 'landing-page.json' -path '*/domains/*' 2>/dev/null | head -1)"

# コーポレートサイトの場合
cat ~/.soloptilink/domains/corporate-site.json 2>/dev/null || cat "$(find / -name 'corporate-site.json' -path '*/domains/*' 2>/dev/null | head -1)"
```

### Step 3: Research → Strategy → Execution (Web Creative品質)

**Phase A: リサーチ**
1. 競合サイト調査（WebSearch 3-5サイト）
2. ターゲットユーザー定義
3. 参考デザインの品質基準抽出

**Phase B: 設計**
4. セクション構成設計（ドメインJSONの section_templates に基づく）
5. ワイヤーフレーム設計（セクション順序・CTA配置）
6. CMS スキーマ設計（更新可能な要素の特定）
7. デザインシステム定義（カラー・タイポグラフィ・スペーシング）

**Phase C: 実装（段階的）**
8. プロジェクトスキャフォールド（Next.js + Tailwind + Prisma）
9. コンポーネント実装（セクション単位で）:
   - 9a: レイアウト（Header/Footer/Navigation）
   - 9b: Hero セクション
   - 9c: Problem/Solution セクション
   - 9d: Features セクション
   - 9e: Social Proof / Testimonials
   - 9f: Pricing セクション
   - 9g: FAQ セクション（構造化データ付き）
   - 9h: CTA セクション
   - 9i: Contact Form（React Hook Form + Zod）
   - 9j: SEO設定（Metadata API + JSON-LD）
10. CMS管理画面実装（認証 + CRUD）
11. アニメーション実装（Framer Motion）
12. レスポンシブ対応（モバイルファースト）

### Step 4: Web Creative 品質ゲート（10軸）

| # | 検証軸 | チェック内容 |
|---|--------|------------|
| 1 | ブランド一貫性 | カラー/フォント/トーンの統一 |
| 2 | CV最適化 | CTA配置/フォーム導線/ファーストビュー |
| 3 | レスポンシブ | モバイル/タブレット/PC表示確認 |
| 4 | パフォーマンス | LCP/FID/CLS + 画像最適化 |
| 5 | SEO準拠 | meta/OGP/JSON-LD/sitemap |
| 6 | アクセシビリティ | WCAG AA準拠/色コントラスト/ARIA |
| 7 | アニメーション品質 | 60fps/prefers-reduced-motion対応 |
| 8 | CMS運用性 | 非エンジニアが更新可能か |
| 9 | コンテンツ品質 | コピーライティング/情報設計 |
| 10 | モバイルファースト | モバイル表示が最優先設計か |

### Step 5: ビルド検証
```bash
cd [project-dir] && npm run build
```
ビルドエラーがあれば修正して再ビルド。

### Step 6: デプロイ
Vercel統一。

### 実行後に必ず伝える
> SoloptiLinkAI **Web Creative** v2015.0 セッションがアクティブです。
> LP/サイト品質フレームワーク + 10軸品質ゲートが常時稼働します。

## LP開発時の必須ワークフロー

### 1. エグゼクティブサマリー
経営者向けに、何を作るか・なぜ作るかを端的にまとめる

### 2. 正規化された要件一覧
Must / Should / Nice to have / Assumptions / Risks に分類

### 3. 理想のセクション構成案
ドメインJSONの section_templates から最適な構成を選択

### 4. 推奨アーキテクチャ
Next.js App Router + Tailwind CSS + Framer Motion + Prisma + Vercel

### 5. 現状監査（既存コードがある場合）
要件との一致度を厳密に監査

### 6. 修正ロードマップ
優先順位順に修正ステップを提示

### 7. 最終判定
要件充足率 / デザイン完成度 / 実装品質 / CMS運用適性 / 商用公開 readiness

## Anti-Slop ルール（Web Creative版）

以下のパターンは禁止:
- 紫デフォルトのグラデーション背景
- 汎用ストック写真のみの構成
- テンプレート感の強い画一的レイアウト
- アニメーション過多（重さ > 演出効果）
- CTAのない装飾的セクション
- モバイルで読めない小さいテキスト
- コントラスト不足の薄いテキスト

## デプロイ
常にVercelを使用。
