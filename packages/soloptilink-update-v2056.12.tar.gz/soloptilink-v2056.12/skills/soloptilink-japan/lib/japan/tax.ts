/**
 * 消費税・源泉徴収計算ユーティリティ
 */

export type TaxRate = 'standard' | 'reduced' | 'exempt' | 'nontaxable';

/** 消費税額の1円未満の端数処理 (切捨て / 切上げ / 四捨五入) */
export type TaxRounding = 'floor' | 'ceil' | 'round';

/**
 * 消費税率 (国税+地方消費税の合計) を百分率の整数で持つ値表。税率はここ1か所だけに置く。
 * 標準税率10% / 軽減税率8% (消費税法第29条・地方税法第72条の83、平成28年改正法附則第34条)。
 */
export const CONSUMPTION_TAX_RATE_PERCENT: Readonly<Record<TaxRate, number>> = {
  standard: 10,
  reduced: 8,
  exempt: 0,
  nontaxable: 0,
};

/**
 * 整数の割り算 num/den (num≧0, den>0) を指定の方法で円に丸める。
 * ★浮動小数の割り算は使わない。旧実装の Math.floor(amount / 1.1) は、ちょうど割り切れる額
 *   (税込33円・110円・135円など) で 1.1 の二進誤差により1円少なく出ていた。
 */
function divideRounded(num: number, den: number, rounding: TaxRounding): number {
  // 1億円 × 10 程度までは Number の整数で誤差なく扱える (2^53 未満)。
  // 円未満を含む金額 (旧来の呼び出し) が来た場合は、商を 1e-9 円の桁で整えてから丸める。
  if (!Number.isInteger(num)) {
    const x = Math.round((num / den) * 1e9) / 1e9;
    const fq = Math.floor(x);
    if (rounding === 'ceil') return x > fq ? fq + 1 : fq;
    if (rounding === 'round') return x - fq >= 0.5 ? fq + 1 : fq;
    return fq;
  }
  const q = Math.floor(num / den);
  const rem = num - q * den;
  if (rounding === 'ceil') return rem > 0 ? q + 1 : q;
  if (rounding === 'round') return rem * 2 >= den ? q + 1 : q;
  return q;
}

/**
 * 消費税額の計算 (税抜→税込 / 税込→税抜)
 *
 * 【出典 — 一次情報】国税庁「適格請求書等保存方式に関するQ&A」問57
 *   (消費税法施行令第70条の10・消費税法基本通達1-8-15)
 *   https://www.nta.go.jp/taxes/shiraberu/zeimokubetsu/shohi/keigenzeiritsu/pdf/qa/57.pdf
 *   - 税込方式の設例: 60,000円×10/110≒5,454円、40,000円×8/108≒2,962円 (いずれも切捨て)
 *   - 端数処理 (切上げ・切捨て・四捨五入) の方法は任意。ただし一の適格請求書につき税率ごとに1回。
 *
 * ★2026-09-30 是正 (REQ-JPO-FIX-015): 税込→税抜を整数演算 (税額 = 税込×r/(100+r)) に改め、
 *   丸め方を選べるようにした。旧実装は浮動小数の割り算で税込33円→税額4円 (正しくは3円) を返していた。
 * ★既定の丸め方は国税庁の設例と同じ【切捨て】。旧実装は実質「税額の切上げ」固定だったため、
 *   税込方式で端数が出る額は旧実装より税額が1円小さくなる (どちらも適法)。
 *   お客様の請求書で切上げ・四捨五入を使っている場合は rounding で指定すること (オーナー判断事項・要確認)。
 *
 * @param rounding 1円未満の端数処理。既定 'floor' (切捨て)。税抜方式にも同じく効く。
 */
export function calcTax(
  amount: number,
  rate: TaxRate,
  mode: 'exclusive' | 'inclusive' = 'exclusive',
  rounding: TaxRounding = 'floor',
): { base: number; tax: number; total: number } {
  const pct = CONSUMPTION_TAX_RATE_PERCENT[rate] ?? 0;
  if (mode === 'exclusive') {
    const tax = pct === 0 ? 0 : Math.sign(amount) * divideRounded(Math.abs(amount) * pct, 100, rounding);
    return { base: amount, tax, total: amount + tax };
  } else {
    const tax = pct === 0 ? 0 : Math.sign(amount) * divideRounded(Math.abs(amount) * pct, 100 + pct, rounding);
    return { base: amount - tax, tax, total: amount };
  }
}

/** 報酬・料金等の源泉徴収の区分 (所得税法 第204条第1項) */
export type RewardWithholdingType = 'creative' | 'judicial' | 'hostess';

const REWARD_WITHHOLDING_TYPES: readonly RewardWithholdingType[] = ['creative', 'judicial', 'hostess'];

/**
 * 【報酬・料金等】の源泉徴収税額の計算 (所得税法 第204条第1項)。
 *
 * ★これは「報酬・料金・契約金及び賞金」に対する源泉徴収であり、
 *   【給与】の源泉徴収ではない。給与の源泉徴収は月額表 (国税庁告示別表第一) を引く
 *   `hr_payroll.calcWithholdingTax()` を使うこと。両者は同じ支給額でも税額が全く違う
 *   (例: 300,000円 → 報酬 30,630円 / 給与 (甲欄・扶養0人) 7,930円)。
 *   取り違えると静かに約4倍の誤額が出るため、本関数は用途が名前に出る
 *   `calcRewardWithholdingTax` を正式名とする。
 *
 * - デザイン・原稿料・講演料等: 100万円以下 → 10.21% / 100万円超 → (額-100万)×20.42%+102,100円
 * - 司法書士等: 1万円控除後 × 10.21%
 * - ホステス等: 控除後 × 10.21%
 *
 * @param amount 支払金額 (税抜)
 * @param type   報酬・料金の区分
 * @throws 区分が不正な場合。★旧実装はどの区分にも当たらないと黙って源泉徴収0円を返していたため、
 *         給与の月額表と取り違えて `calcWithholdingTax(300000, 2)` のように呼ぶと
 *         「源泉徴収0円」の支払調書が正常に出力されていた。0円で通さず例外で顕在化させる。
 */
export function calcRewardWithholdingTax(
  amount: number,
  type: RewardWithholdingType
): { withholding: number; netPayment: number } {
  if (!REWARD_WITHHOLDING_TYPES.includes(type)) {
    throw new Error(
      `報酬・料金の区分が不正です (受け取った値: ${JSON.stringify(type)})。` +
      `'creative' | 'judicial' | 'hostess' のいずれかを指定してください。` +
      `給与の源泉徴収を求めたい場合は、本関数ではなく給与所得の源泉徴収税額表 (月額表) を引く ` +
      `hr_payroll.calcWithholdingTax(課税対象額, 扶養親族等の数) を使ってください。`
    );
  }
  let withholding = 0;
  if (type === 'creative') {
    if (amount <= 1_000_000) withholding = Math.floor(amount * 0.1021);
    else withholding = Math.floor((amount - 1_000_000) * 0.2042 + 102_100);
  } else if (type === 'judicial') {
    withholding = Math.floor(Math.max(0, amount - 10_000) * 0.1021);
  } else if (type === 'hostess') {
    const deduction = 5_000; // 日額控除
    withholding = Math.floor(Math.max(0, amount - deduction) * 0.1021);
  }
  return { withholding, netPayment: amount - withholding };
}

/**
 * @deprecated 旧名。`hr_payroll.ts` の【給与】用 `calcWithholdingTax()` と同名で紛らわしいため、
 *   報酬・料金であることが名前に出る {@link calcRewardWithholdingTax} へ移行すること。
 *   後方互換のために残しているだけで、中身は同一。新規のコードで使わないこと。
 */
export const calcWithholdingTax = calcRewardWithholdingTax;

/*
 * 【削除済み】calcSalaryWithholding(monthlySalary, dependents)
 *
 *   給与の源泉徴収を「社会保険料を一律15%と仮定」した近似式で求めていた旧世代の実装。
 *   国税庁の月額表を引く hr_payroll.calcWithholdingTax() と同一入力で最大 13,290円/月 食い違い
 *   (低額帯は過少・高額帯は過大)、そのまま納付すると不足税額が生じていた。
 *   ~/.soloptilink 配下を全数調査したところ生きた呼び出し元が 0 件だったため、
 *   近似式が二度と使われないよう本体ごと削除した (2026-08-14)。
 *
 *   給与の源泉徴収は必ず実表を引くこと:
 *     import { calcWithholdingTax } from './hr_payroll';   // 令和8年分 月額表 (甲欄/乙欄)
 *     import { calcBonusWithholdingTax } from './gensen_bonus_rate_r8'; // 賞与の算出率の表
 */

/**
 * インボイス方式の税率別集計 (一の適格請求書につき、税率ごとに1回だけ端数処理する)
 *
 * @param opts.mode      明細の金額が税抜 ('exclusive'・既定) か税込 ('inclusive') か
 * @param opts.rounding  1円未満の端数処理 (既定 'floor' 切捨て。国税庁 問57 の設例と同じ)
 *   subtotal は明細金額の合計 (税込方式なら税込の合計)。明細行ごとには丸めない。
 */
export function summarizeByRate(
  items: Array<{ amount: number; rate: TaxRate }>,
  opts: { mode?: 'exclusive' | 'inclusive'; rounding?: TaxRounding } = {},
): Record<TaxRate, { subtotal: number; tax: number }> {
  const summary: Record<TaxRate, { subtotal: number; tax: number }> = {
    standard: { subtotal: 0, tax: 0 },
    reduced: { subtotal: 0, tax: 0 },
    exempt: { subtotal: 0, tax: 0 },
    nontaxable: { subtotal: 0, tax: 0 },
  };
  for (const it of items) {
    summary[it.rate].subtotal += it.amount;
  }
  const mode = opts.mode ?? 'exclusive';
  const rounding = opts.rounding ?? 'floor';
  summary.standard.tax = calcTax(summary.standard.subtotal, 'standard', mode, rounding).tax;
  summary.reduced.tax = calcTax(summary.reduced.subtotal, 'reduced', mode, rounding).tax;
  return summary;
}
