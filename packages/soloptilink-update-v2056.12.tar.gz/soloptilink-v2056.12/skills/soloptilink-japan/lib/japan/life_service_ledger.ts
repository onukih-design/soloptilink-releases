/**
 * lib/japan/life_service_ledger.ts — 生活サービスの規制値の版つき台帳（銭湯の統制額・互助会の前受金保全・警備員の教育時間）
 *
 * 2026-10-04 新設（日本最適化 T32・REQ-141／REQ-142）。
 *   値はこの台帳だけに置き、bath_spa.ts・security.ts はここを読む（同じ値の写しを持たない）。
 *   各行は 出典URL・確認日（checkedAt）・状態（status）を持つ。一次資料で確かめていない値は作らず「未確認」を返す。
 *
 * 出典（いずれも 2026-10-03 に取得）:
 *  - 東京都生活文化局「公衆浴場入浴料金の統制額について」（更新 2026-07-21）／同「東京の公衆浴場の現況」の統制額の推移
 *  - 警視庁「警備員に対する教育時間」（更新 2019-12-04。警備業法第21条第2項・同施行規則第38条第1項）
 *  - e-Gov 割賦販売法（昭和36年法律第159号・2025-06-01版）第17条第1項・第18条の3・第35条の3の62
 */

// ============================================================================
// 0. 共通
// ============================================================================

export type LedgerStatus = '確認済' | '二次' | '未確認';

export interface LifeLedgerRow {
  kind: 'sentoh' | 'mutual_aid' | 'security_training';
  key: string;
  validFrom: string;
  validTo: string | null;
  status: LedgerStatus;
  sourceUrl: string;
  checkedAt: string;
  note?: string;
}

/** 日付を YYYY-MM-DD にそろえる（Date はローカル日付で読む） */
export function toYmd(d: Date | string): string {
  if (typeof d === 'string') return d.slice(0, 10);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function addDaysYmd(ymd: string, days: number): string {
  const [y, m, d] = ymd.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1, d) + days * 86400000);
  return `${t.getUTCFullYear()}-${String(t.getUTCMonth() + 1).padStart(2, '0')}-${String(t.getUTCDate()).padStart(2, '0')}`;
}

function daysBetween(fromYmd: string, toYmdStr: string): number {
  const [y1, m1, d1] = fromYmd.split('-').map(Number);
  const [y2, m2, d2] = toYmdStr.split('-').map(Number);
  return Math.round((Date.UTC(y2, m2 - 1, d2) - Date.UTC(y1, m1 - 1, d1)) / 86400000);
}

// ============================================================================
// 1. 銭湯（一般公衆浴場）の入浴料金の統制額（物価統制令に基づき都道府県知事が指定）
// ============================================================================

export const PREFECTURES_47: ReadonlyArray<string> = Object.freeze([
  '北海道', '青森県', '岩手県', '宮城県', '秋田県', '山形県', '福島県',
  '茨城県', '栃木県', '群馬県', '埼玉県', '千葉県', '東京都', '神奈川県',
  '新潟県', '富山県', '石川県', '福井県', '山梨県', '長野県', '岐阜県',
  '静岡県', '愛知県', '三重県', '滋賀県', '京都府', '大阪府', '兵庫県',
  '奈良県', '和歌山県', '鳥取県', '島根県', '岡山県', '広島県', '山口県',
  '徳島県', '香川県', '愛媛県', '高知県', '福岡県', '佐賀県', '長崎県',
  '熊本県', '大分県', '宮崎県', '鹿児島県', '沖縄県',
]);

const TOKYO_SENTOH_URL = 'https://www.shouhiseikatu.metro.tokyo.lg.jp/chousa/yokujyo/touseigaku.html';
const TOKYO_SENTOH_HISTORY_URL = 'https://www.shouhiseikatu.metro.tokyo.lg.jp/chousa/yokujyo/genjo.html';

export interface SentohTariffRow {
  prefecture: string;
  validFrom: string;
  validTo: string | null;
  adultJpy: number; // 大人（12歳以上）
  childJpy: number; // 中人（6歳以上12歳未満）
  infantJpy: number; // 小人（6歳未満）
  status: LedgerStatus;
  sourceUrl: string;
  checkedAt: string;
}

/**
 * 都道府県別の統制額の履歴。ここに行の無い都道府県・期間は「未確認」（額を返さない）。
 *   東京都は都の公表する「統制額の推移」から転記（令和4年7月15日以降）。
 */
export const SENTOH_TARIFF_LEDGER: ReadonlyArray<SentohTariffRow> = Object.freeze([
  { prefecture: '東京都', validFrom: '2026-08-01', validTo: null, adultJpy: 600, childJpy: 200, infantJpy: 100, status: '確認済', sourceUrl: TOKYO_SENTOH_URL, checkedAt: '2026-10-03' },
  { prefecture: '東京都', validFrom: '2024-08-01', validTo: '2026-07-31', adultJpy: 550, childJpy: 200, infantJpy: 100, status: '確認済', sourceUrl: TOKYO_SENTOH_HISTORY_URL, checkedAt: '2026-10-03' },
  { prefecture: '東京都', validFrom: '2023-07-01', validTo: '2024-07-31', adultJpy: 520, childJpy: 200, infantJpy: 100, status: '確認済', sourceUrl: TOKYO_SENTOH_HISTORY_URL, checkedAt: '2026-10-03' },
  { prefecture: '東京都', validFrom: '2022-07-15', validTo: '2023-06-30', adultJpy: 500, childJpy: 200, infantJpy: 100, status: '確認済', sourceUrl: TOKYO_SENTOH_HISTORY_URL, checkedAt: '2026-10-03' },
]);

export type SentohTariffResult =
  | { status: 'confirmed'; prefecture: string; adultJpy: number; childJpy: number; infantJpy: number; validFrom: string; sourceUrl: string; checkedAt: string }
  | { status: 'unconfirmed'; prefecture: string; adultJpy: null; childJpy: null; infantJpy: null; display: '未確認'; reason: string };

/** 基準日の統制額。一次資料で確かめていない都道府県・期間は額を返さない */
export function getSentohTariff(prefecture: string, onDate: Date | string = new Date()): SentohTariffResult {
  const ymd = toYmd(onDate);
  const row = SENTOH_TARIFF_LEDGER.find((r) => r.prefecture === prefecture && r.validFrom <= ymd && (r.validTo === null || ymd <= r.validTo));
  if (!row) {
    return {
      status: 'unconfirmed', prefecture, adultJpy: null, childJpy: null, infantJpy: null, display: '未確認',
      reason: `${prefecture} の ${ymd} 時点の統制額は一次資料で確認できていません（都道府県の告示を確認してください）`,
    };
  }
  return { status: 'confirmed', prefecture, adultJpy: row.adultJpy, childJpy: row.childJpy, infantJpy: row.infantJpy, validFrom: row.validFrom, sourceUrl: row.sourceUrl, checkedAt: row.checkedAt };
}

/** 入浴料金の上限（統制額）による合計。未確認なら額を返さない */
export function calcSentohFee(prefecture: string, onDate: Date | string, persons: { adult: number; child: number; infant: number }):
  | { status: 'confirmed'; totalJpy: number; breakdown: { adult: number; child: number; infant: number } }
  | { status: 'unconfirmed'; totalJpy: null; reason: string } {
  const t = getSentohTariff(prefecture, onDate);
  if (t.status !== 'confirmed') return { status: 'unconfirmed', totalJpy: null, reason: t.reason };
  const breakdown = { adult: t.adultJpy * persons.adult, child: t.childJpy * persons.child, infant: t.infantJpy * persons.infant };
  return { status: 'confirmed', totalJpy: breakdown.adult + breakdown.child + breakdown.infant, breakdown };
}

/** 47都道府県の表（空欄は推測で埋めず「未確認」と表示） */
export function listSentohTariffTable(onDate: Date | string = new Date()): Array<{ prefecture: string; adultJpy: number | null; childJpy: number | null; infantJpy: number | null; display: string; status: 'confirmed' | 'unconfirmed' }> {
  return PREFECTURES_47.map((p) => {
    const t = getSentohTariff(p, onDate);
    if (t.status === 'confirmed') return { prefecture: p, adultJpy: t.adultJpy, childJpy: t.childJpy, infantJpy: t.infantJpy, display: `大人${t.adultJpy}円・中人${t.childJpy}円・小人${t.infantJpy}円`, status: 'confirmed' as const };
    return { prefecture: p, adultJpy: null, childJpy: null, infantJpy: null, display: '未確認', status: 'unconfirmed' as const };
  });
}

// ============================================================================
// 2. 冠婚葬祭互助会（前払式特定取引）の前受金保全（割賦販売法18条の3を35条の3の62で準用）
// ============================================================================

const KAPPU_URL = 'https://laws.e-gov.go.jp/law/336AC0000000159';

export const MUTUAL_AID_PRESERVATION_LEDGER = Object.freeze({
  kind: 'mutual_aid' as const,
  ratio: { numerator: 1, denominator: 2 }, // 前受金の合計額の2分の1（18条の3第1項・第2項）
  statutoryKijunbi: ['03-31', '09-30'] as const, // 基準日（18条の3第1項）
  eigyoHoshokin: { mainOfficeJpy: 100_000, perOtherOfficeJpy: 50_000 }, // 17条1項（主たる営業所10万円・その他の営業所又は代理店ごとに5万円）
  newContractBanDaysAfterKijunbi: 50, // 基準日の翌日から起算して50日を経過した日以後は新規契約不可（届出が無い場合）
  validFrom: '2025-06-01',
  validTo: null as string | null,
  status: '確認済' as LedgerStatus,
  sourceUrl: KAPPU_URL,
  checkedAt: '2026-10-03',
  bookDifferenceRule: { rule: '法定帳簿と会計帳簿に差異があれば多い方の残高で計算する', status: '二次' as LedgerStatus, note: '経済産業省の検査基本方針（令和7年度）の要約による。原文は要一次確認' },
});

export interface MutualAidPreservationInput {
  legalBookBalanceJpy: number; // 法定帳簿上の前受金残高
  accountingBookBalanceJpy?: number; // 会計帳簿上の前受金残高
  otherOfficeCount: number; // 主たる営業所以外の営業所・代理店の数
  securedAmountJpy?: number; // 前受金保全措置（前受業務保証金の供託・供託委託契約）で弁済に充てられる額
}

/**
 * 保全額の検算。
 *   基準額 = 前受金合計×1/2 − 営業保証金（18条の3第2項）。1/2 が営業保証金を「こえるとき」に措置が要る。
 *   ★2分の1で円未満が出る場合は安全側（切り上げ）で出す。端数の扱いは要確認（実務家・所管への確認待ち）。
 */
export function calcMutualAidPreservation(input: MutualAidPreservationInput) {
  const L = MUTUAL_AID_PRESERVATION_LEDGER;
  const warnings: string[] = [];
  const legal = input.legalBookBalanceJpy;
  const acct = input.accountingBookBalanceJpy ?? legal;
  if (acct !== legal) warnings.push(`法定帳簿（${legal.toLocaleString()}円）と会計帳簿（${acct.toLocaleString()}円）に差異があります。多い方で計算しました（${L.bookDifferenceRule.note}）`);
  const baseBalanceJpy = Math.max(legal, acct);
  const halfAmountJpy = Math.ceil((baseBalanceJpy * L.ratio.numerator) / L.ratio.denominator);
  if ((baseBalanceJpy * L.ratio.numerator) % L.ratio.denominator !== 0) warnings.push('2分の1で円未満の端数が出たため切り上げました（端数の扱いは要確認）');
  const eigyoHoshokinJpy = L.eigyoHoshokin.mainOfficeJpy + L.eigyoHoshokin.perOtherOfficeJpy * Math.max(0, input.otherOfficeCount);
  const measureRequired = halfAmountJpy > eigyoHoshokinJpy;
  const kijungakuJpy = measureRequired ? halfAmountJpy - eigyoHoshokinJpy : 0;
  const shortfallJpy = input.securedAmountJpy == null ? null : Math.max(0, kijungakuJpy - input.securedAmountJpy);
  if (shortfallJpy && shortfallJpy > 0) warnings.push(`保全額が ${shortfallJpy.toLocaleString()}円 不足しています`);
  return { baseBalanceJpy, halfAmountJpy, eigyoHoshokinJpy, measureRequired, kijungakuJpy, shortfallJpy, warnings, sourceUrl: L.sourceUrl };
}

/** 届出が無い場合に新規契約を締結できなくなる日（基準日の翌日から起算して50日を経過した日） */
export function mutualAidNewContractBanDate(kijunbi: Date | string): string {
  const ymd = toYmd(kijunbi);
  // 起算日＝基準日の翌日。起算日を1日目として50日目が満了 → その翌日が「50日を経過した日」
  return addDaysYmd(ymd, 1 + MUTUAL_AID_PRESERVATION_LEDGER.newContractBanDaysAfterKijunbi);
}

/** 互助会の前受金保全の月次検算（法定の基準日は3月末・9月末。その他の月は自主点検） */
export function checkMutualAidMonthly(input: {
  permitNumber?: string | null;
  activeContractCount: number;
  otherOfficeCount: number;
  months: Array<{ month: string; legalBookBalanceJpy: number; accountingBookBalanceJpy?: number; securedAmountJpy?: number }>;
}) {
  const warnings: string[] = [];
  if ((!input.permitNumber || !String(input.permitNumber).trim()) && input.activeContractCount > 0) {
    warnings.push(`経済産業大臣の許可番号が未登録のまま契約が ${input.activeContractCount}件 あります（割賦販売法35条の3の61: 無許可営業のおそれ）。許可番号を登録してください`);
  }
  const rows = input.months.map((m) => {
    const r = calcMutualAidPreservation({ legalBookBalanceJpy: m.legalBookBalanceJpy, accountingBookBalanceJpy: m.accountingBookBalanceJpy, otherOfficeCount: input.otherOfficeCount, securedAmountJpy: m.securedAmountJpy });
    const mm = m.month.slice(5, 7);
    const isStatutoryKijunbi = MUTUAL_AID_PRESERVATION_LEDGER.statutoryKijunbi.some((k) => k.startsWith(mm));
    for (const w of r.warnings) warnings.push(`${m.month}: ${w}`);
    return { month: m.month, isStatutoryKijunbi, ...r };
  });
  return { rows, warnings };
}

// ============================================================================
// 3. 警備員の教育時間（警備業法21条2項・同施行規則38条1項。警視庁の表を転記）
// ============================================================================

const KEISHICHO_URL = 'https://www.keishicho.metro.tokyo.lg.jp/tetsuzuki/keibi/k_keibi/education_time.html';

export type TrainingHours = { basic?: number | 'exempt'; specific?: number | 'exempt'; combined?: number };

export type SecurityGuardCategory =
  | 'general' // 上記対象以外の一般警備員
  | 'experienced' // 当該警備業務経験者（最近3年間に当該警備業務に通算1年以上）
  | 'former_police' // 元警察官（警察官であった期間が通算1年以上）
  | 'kentei1' // 当該警備業務1級検定の合格証明書の交付を受けた者
  | 'kentei2' // 当該警備業務2級検定の合格証明書の交付を受けた者
  | 'shidou_sekininsha' // 当該指導教育責任者資格者証の交付を受けている者
  | 'kikai_kanrisha'; // 機械警備業務管理者資格者証の交付を受けている者

export const SECURITY_TRAINING_LEDGER: ReadonlyArray<{ category: SecurityGuardCategory; assignment: string; newcomer: TrainingHours; current: TrainingHours }> = Object.freeze([
  { category: 'general', assignment: 'same', newcomer: { combined: 20 }, current: { combined: 10 } },
  { category: 'experienced', assignment: 'same', newcomer: { combined: 7 }, current: { combined: 10 } },
  { category: 'experienced', assignment: 'other', newcomer: { combined: 13 }, current: { combined: 10 } },
  { category: 'former_police', assignment: 'same', newcomer: { combined: 13 }, current: { combined: 10 } },
  { category: 'kentei1', assignment: 'same', newcomer: { basic: 'exempt', specific: 'exempt' }, current: { basic: 'exempt', specific: 'exempt' } },
  { category: 'kentei1', assignment: 'other', newcomer: { basic: 'exempt', specific: 10 }, current: { basic: 'exempt', specific: 6 } },
  { category: 'kentei1', assignment: 'other_experienced', newcomer: { basic: 'exempt', specific: 3 }, current: { basic: 'exempt', specific: 6 } },
  { category: 'kentei2', assignment: 'same', newcomer: { basic: 'exempt', specific: 'exempt' }, current: { basic: 'exempt', specific: 6 } },
  { category: 'kentei2', assignment: 'other', newcomer: { basic: 'exempt', specific: 10 }, current: { basic: 'exempt', specific: 6 } },
  { category: 'kentei2', assignment: 'other_experienced', newcomer: { basic: 'exempt', specific: 3 }, current: { basic: 'exempt', specific: 6 } },
  { category: 'shidou_sekininsha', assignment: 'same', newcomer: { basic: 'exempt', specific: 'exempt' }, current: { basic: 'exempt', specific: 'exempt' } },
  { category: 'shidou_sekininsha', assignment: 'other', newcomer: { basic: 'exempt', specific: 10 }, current: { basic: 'exempt', specific: 6 } },
  { category: 'shidou_sekininsha', assignment: 'other_experienced', newcomer: { basic: 'exempt', specific: 3 }, current: { basic: 'exempt', specific: 6 } },
  { category: 'kikai_kanrisha', assignment: 'kikai_experienced', newcomer: { basic: 3, specific: 'exempt' }, current: { combined: 10 } },
  { category: 'kikai_kanrisha', assignment: 'kikai_other', newcomer: { basic: 10, specific: 'exempt' }, current: { combined: 10 } },
  { category: 'kikai_kanrisha', assignment: 'non_kikai', newcomer: { combined: 20 }, current: { combined: 10 } },
  { category: 'kikai_kanrisha', assignment: 'non_kikai_experienced', newcomer: { combined: 7 }, current: { combined: 10 } },
]);

export const SECURITY_TRAINING_LEDGER_META = Object.freeze({
  kind: 'security_training' as const,
  validFrom: '2019-12-04', // 警視庁の表の更新日（施行日そのものではない）
  validTo: null as string | null,
  status: '確認済' as LedgerStatus,
  sourceUrl: KEISHICHO_URL,
  checkedAt: '2026-10-03',
  note: '現任教育は年度ごと。新任教育の業務別教育の一部は実地教育で行える（時間の上限は警視庁の表の注記による）',
});

/** 区分・就く業務に応じた教育時間。表に無い組み合わせは推測せず「未確認」 */
export function getSecurityTrainingRequirement(category: string, assignment: string):
  | { status: 'confirmed'; newcomer: TrainingHours; current: TrainingHours; sourceUrl: string }
  | { status: 'unconfirmed'; reason: string } {
  const row = SECURITY_TRAINING_LEDGER.find((r) => r.category === category && r.assignment === assignment);
  if (!row) return { status: 'unconfirmed', reason: `区分 ${category}／${assignment} は警視庁の表で確認できていません` };
  return { status: 'confirmed', newcomer: row.newcomer, current: row.current, sourceUrl: KEISHICHO_URL };
}

type HoursInput = number | { basic?: number; specific?: number; combined?: number };

function meets(req: TrainingHours, got: HoursInput): { ok: boolean; remaining: number } {
  const g = typeof got === 'number' ? { combined: got } : got;
  const basic = g.basic ?? 0;
  const specific = g.specific ?? 0;
  const total = g.combined ?? basic + specific;
  if (req.combined != null) {
    const remaining = Math.max(0, req.combined - total);
    return { ok: remaining === 0, remaining };
  }
  let remaining = 0;
  if (typeof req.basic === 'number') remaining += Math.max(0, req.basic - (g.basic ?? (g.combined != null && req.specific === 'exempt' ? g.combined : 0)));
  if (typeof req.specific === 'number') remaining += Math.max(0, req.specific - (g.specific ?? (g.combined != null && req.basic === 'exempt' ? g.combined : 0)));
  return { ok: remaining === 0, remaining };
}

/** 新任教育・現任教育（年度）の充足判定 */
export function evaluateSecurityTraining(input: { category: string; assignment: string; newcomerHours: HoursInput; currentHoursThisFiscalYear: HoursInput }) {
  const req = getSecurityTrainingRequirement(input.category, input.assignment);
  if (req.status !== 'confirmed') return { status: 'unconfirmed' as const, newcomerCompleted: null, currentCompleted: null, reason: req.reason };
  const n = meets(req.newcomer, input.newcomerHours);
  const c = meets(req.current, input.currentHoursThisFiscalYear);
  return { status: 'confirmed' as const, newcomerCompleted: n.ok, newcomerRemainingHours: n.remaining, currentCompleted: c.ok, currentRemainingHours: c.remaining, requirement: req, sourceUrl: KEISHICHO_URL };
}

// ============================================================================
// 4. 台帳の一覧と鮮度検査
// ============================================================================

export function listLifeLedgerRows(): LifeLedgerRow[] {
  const rows: LifeLedgerRow[] = SENTOH_TARIFF_LEDGER.map((r) => ({ kind: 'sentoh' as const, key: `${r.prefecture}@${r.validFrom}`, validFrom: r.validFrom, validTo: r.validTo, status: r.status, sourceUrl: r.sourceUrl, checkedAt: r.checkedAt }));
  const M = MUTUAL_AID_PRESERVATION_LEDGER;
  rows.push({ kind: 'mutual_aid', key: '前受金保全 2分の1・基準日3/31・9/30', validFrom: M.validFrom, validTo: M.validTo, status: M.status, sourceUrl: M.sourceUrl, checkedAt: M.checkedAt });
  const S = SECURITY_TRAINING_LEDGER_META;
  rows.push({ kind: 'security_training', key: '警備員の教育時間（警視庁の表 17区分）', validFrom: S.validFrom, validTo: S.validTo, status: S.status, sourceUrl: S.sourceUrl, checkedAt: S.checkedAt, note: S.note });
  return rows;
}

/**
 * 鮮度検査。確認日から maxAgeDays（既定365日）を超えた行、適用期間の終わった最新行を「古い」として返す。
 *   統制額は改定の発表が年1回程度あるため、確認日が1年を超えたら確認し直す運用を既定にしている（社内の運用基準。法定ではない）。
 */
export function checkLifeLedgerFreshness(asOf: Date | string = new Date(), opt: { maxAgeDays?: number } = {}) {
  const maxAgeDays = opt.maxAgeDays ?? 365;
  const today = toYmd(asOf);
  const stale: Array<LifeLedgerRow & { reason: string }> = [];
  for (const r of listLifeLedgerRows()) {
    if (r.validTo !== null && r.validTo < today) continue; // 過去の版は鮮度の対象外
    const age = daysBetween(r.checkedAt, today);
    if (age > maxAgeDays) stale.push({ ...r, reason: `確認日 ${r.checkedAt} から ${age}日 経過（${maxAgeDays}日を超過）。出典を開き直してください` });
  }
  const unconfirmedPrefectures = PREFECTURES_47.filter((p) => getSentohTariff(p, today).status !== 'confirmed');
  return { asOf: today, ok: stale.length === 0, stale, unconfirmedPrefectures };
}
