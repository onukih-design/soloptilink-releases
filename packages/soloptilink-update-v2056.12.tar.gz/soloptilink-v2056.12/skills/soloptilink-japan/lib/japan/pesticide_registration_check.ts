/**
 * lib/japan/pesticide_registration_check.ts — 農薬の使用基準を登録情報 (FAMIC) で保存前に検算する (REQ-160 / JPO-IND-137)
 *
 * 2026-10-03 (JPO-T33) 新設。農薬の使用記録を保存する前に、FAMIC の農薬登録情報 (登録番号・作物名・使用時期・本剤の使用回数・
 * 希釈倍数・有効成分ごとの総使用回数) と突き合わせ、使用基準 (農薬を使用する者が遵守すべき基準を定める省令 第2条) に照らして
 * 「違反」「適合」「確認できていない」を返す。登録データは ~/.soloptilink/scripts/japan/famic_pesticide_to_json.py で作る。
 *
 * 方針:
 *   - 登録の文字列を解釈できないとき・入力が足りないときは「適合」と言わず unverified を返す (黙って通さない)。
 *   - 作物群 (「野菜類」「かんきつ(みかんを除く)」等) で登録された農薬に一覧に無い作物名が来たときは、違反と断定せず unverified。
 *   - 画面にはデータの日付 (登録反映日・失効反映) を必ず出す。古いデータは「更新してください」と出す。
 *   - 最終確認は農薬のラベルと最新の登録情報で行う旨を必ず添える。
 */
import { PESTICIDE_DATA_RULES } from './primary_industry_ledger';

export interface FamicRegistrationRow {
  registrationNumber: number;
  pesticideName?: string;
  crop: string;
  target?: string;
  /** 希釈倍数使用量 (例: 「1000～2000倍」「3kg/10a」) */
  dilutionOrAmount: string;
  /** 使用時期 (例: 「収穫7日前まで」「収穫前日まで」) */
  timing: string;
  /** 本剤の使用回数 (例: 「3回以内」) */
  timesOfThisProduct: string;
  method?: string;
  /** 有効成分①〜⑤を含む農薬の総使用回数 */
  ingredientTotalTimes?: string[];
}

export interface FamicDataset {
  source: string;
  sourceUrl?: string;
  /** 登録反映日 (YYYY-MM-DD) — 配布ページの「○年○月○日登録反映分」 */
  registeredAsOf: string;
  /** 失効の反映 (例: 「令和8年9月失効」) */
  expiryReflected?: string;
  convertedAt?: string;
  registeredNumbers: number[];
  rows: FamicRegistrationRow[];
}

export interface PesticideUseInput {
  registrationNumber: number;
  crop: string;
  /** 適用病害虫雑草名 (分かれば。登録の行を絞り込む) */
  target?: string;
  /** 散布日 (YYYY-MM-DD) */
  applicationDate: string;
  /** 収穫 (予定) 日 (YYYY-MM-DD)。無いと使用時期を確認できない */
  harvestDate?: string;
  /** この作物への本剤の使用回数 (今回を含む) */
  useCountOfThisProduct: number;
  /** 希釈倍数 (倍)。希釈で登録されている農薬で無いと確認できない */
  dilutionFold?: number;
  /** 有効成分①〜⑤を含む農薬の総使用回数 (今回を含む・他の農薬の分も合算)。任意 */
  ingredientUseCounts?: number[];
}

export type PesticideViolationCode =
  | 'unregistered'
  | 'crop_not_applicable'
  | 'over_count'
  | 'phi_short'
  | 'over_concentration'
  | 'over_ingredient_total';

export interface PesticideCheckResult {
  status: 'compliant' | 'violation' | 'unverified';
  violations: { code: PesticideViolationCode; message: string }[];
  unverified: string[];
  notes: string[];
  matchedRows: number;
  dataNotice: string;
}

// ---------------- 登録の文字列の読み取り ----------------
const nfkc = (s: string) => String(s ?? '').normalize('NFKC').trim();

/** 使用時期 → 収穫前の日数 (「収穫前日まで」=1、「収穫7日前まで」=7)。読めなければ null */
export function parsePreHarvestDays(timing: string): number | null {
  const t = nfkc(timing);
  if (t === '収穫前日まで') return 1;
  const m = /^収穫(\d+)日前まで$/.exec(t);
  return m ? Number(m[1]) : null;
}

/** 本剤の使用回数 → 上限回数 (「3回以内」「1回」)。読めなければ null */
export function parseUseLimit(times: string): number | null {
  const t = nfkc(times);
  const m = /^(\d+)回(以内)?$/.exec(t);
  return m ? Number(m[1]) : null;
}

/** 希釈倍数 → 最低倍数 (「1000～2000倍」→1000・「2000倍」→2000)。希釈でない (kg/10a 等) は null */
export function parseMinDilutionFold(s: string): number | null {
  const t = nfkc(s).replace(/〜|~/g, '～');
  const m = /^(\d+)(?:～(\d+))?倍$/.exec(t);
  return m ? Number(m[1]) : null;
}

const isGroupCrop = (c: string) => /類|[（(]/.test(c);

function daysBetween(fromIso: string, toIso: string): number | null {
  const a = Date.parse(`${fromIso}T00:00:00Z`);
  const b = Date.parse(`${toIso}T00:00:00Z`);
  if (Number.isNaN(a) || Number.isNaN(b)) return null;
  return Math.round((b - a) / 86400000);
}

/** 画面に出すデータの日付の表示文 */
export function formatPesticideDataNotice(ds: Pick<FamicDataset, 'source' | 'registeredAsOf' | 'expiryReflected'>, today?: string): string {
  if (!ds || !ds.registeredAsOf) {
    return '農薬登録情報の日付が分かりません。日付の無いデータでは検算しません。FAMIC の最新の登録情報を取り込んでください。';
  }
  const src = /FAMIC/.test(ds.source || '') ? ds.source : `FAMIC ${ds.source || '農薬登録情報'}`;
  let s = `農薬登録情報: ${src} (${ds.registeredAsOf} 登録反映分${ds.expiryReflected ? `・${ds.expiryReflected}反映` : ''})。最終確認は農薬のラベルと最新の登録情報で行ってください。`;
  const t = today ?? new Date().toISOString().slice(0, 10);
  const age = daysBetween(ds.registeredAsOf, t);
  if (age !== null && age > PESTICIDE_DATA_RULES.staleAfterDays) {
    s += ` データが${age}日前のものです。新しい登録・失効が反映されていない可能性があるため、最新の登録情報に更新してください。`;
  }
  return s;
}

type Verdict = 'ok' | 'ng' | 'unknown';

/** 1件の使用記録を登録情報で検算する */
export function checkPesticideUseAgainstRegistration(
  input: PesticideUseInput,
  ds: FamicDataset,
  opts: { today?: string } = {},
): PesticideCheckResult {
  const dataNotice = formatPesticideDataNotice(ds, opts.today);
  const out: PesticideCheckResult = { status: 'unverified', violations: [], unverified: [], notes: [], matchedRows: 0, dataNotice };
  if (!ds || !ds.registeredAsOf) {
    out.unverified.push('農薬登録情報の日付が分からないため検算していません。');
    return out;
  }
  const reg = new Set(ds.registeredNumbers || []);
  if (!reg.has(Number(input.registrationNumber))) {
    out.status = 'violation';
    out.violations.push({ code: 'unregistered', message: `登録番号 ${input.registrationNumber} は ${ds.registeredAsOf} 時点の農薬登録情報にありません (無登録又は失効)。登録の無い農薬は使用できません。ラベルの登録番号を確かめてください。` });
    return out;
  }
  const rows = (ds.rows || []).filter((r) => r.registrationNumber === Number(input.registrationNumber));
  if (!rows.length) {
    out.unverified.push('登録番号はありますが、適用の行が取り込まれていません。データを取り込み直してください。');
    return out;
  }
  const crop = nfkc(input.crop);
  let cropRows = rows.filter((r) => nfkc(r.crop) === crop);
  if (!cropRows.length) {
    if (rows.some((r) => isGroupCrop(nfkc(r.crop)))) {
      out.unverified.push(`「${input.crop}」は登録の作物名に一致しません。作物群 (例: 野菜類) での登録に含まれるかは、ラベルと登録情報で確認してください。`);
      return out;
    }
    out.status = 'violation';
    const list = [...new Set(rows.map((r) => r.crop))].slice(0, 8).join('・');
    out.violations.push({ code: 'crop_not_applicable', message: `この農薬 (登録番号 ${input.registrationNumber}) は「${input.crop}」に登録がありません (適用作物: ${list} など)。適用の無い作物には使用できません。別の登録農薬を選んでください。` });
    return out;
  }
  if (input.target) {
    const byTarget = cropRows.filter((r) => nfkc(r.target || '') === nfkc(input.target as string));
    if (byTarget.length) cropRows = byTarget;
    else out.notes.push(`適用病害虫「${input.target}」は登録の行に一致しないため、作物の全ての行で判定しました。`);
  }
  out.matchedRows = cropRows.length;

  const days = input.harvestDate ? daysBetween(input.applicationDate, input.harvestDate) : null;
  const perRow = cropRows.map((r) => {
    const codes: { code: PesticideViolationCode; message: string }[] = [];
    const unknown: string[] = [];
    const lim = parseUseLimit(r.timesOfThisProduct);
    if (lim === null) unknown.push(`本剤の使用回数「${r.timesOfThisProduct}」を読み取れません`);
    else if (input.useCountOfThisProduct > lim) codes.push({ code: 'over_count', message: `本剤の使用回数が登録の上限 (${r.timesOfThisProduct}) を超えています (今回で${input.useCountOfThisProduct}回目)。` });
    const phi = parsePreHarvestDays(r.timing);
    if (phi === null) unknown.push(`使用時期「${r.timing}」を自動で確認できません`);
    else if (days === null) unknown.push('収穫 (予定) 日が無いため使用時期を確認できません');
    else if (days < phi) codes.push({ code: 'phi_short', message: `使用時期は「${r.timing}」ですが、散布から収穫まで${days}日しかありません (あと${phi - days}日空ける必要があります)。` });
    const minFold = parseMinDilutionFold(r.dilutionOrAmount);
    if (minFold === null) unknown.push(`使用量「${r.dilutionOrAmount}」は倍数でないため自動で確認できません`);
    else if (input.dilutionFold === undefined || input.dilutionFold === null) unknown.push('希釈倍数が入力されていません');
    else if (input.dilutionFold < minFold) codes.push({ code: 'over_concentration', message: `希釈倍数 ${input.dilutionFold}倍は登録 (${r.dilutionOrAmount}) の最低倍数を下回っています (濃すぎます)。` });
    if (Array.isArray(input.ingredientUseCounts) && Array.isArray(r.ingredientTotalTimes)) {
      r.ingredientTotalTimes.forEach((t, k) => {
        const n = input.ingredientUseCounts?.[k];
        if (!t || n === undefined) return;
        const l = parseUseLimit(String(t).replace(/[（(].*$/, ''));
        if (l === null) unknown.push(`有効成分${k + 1}の総使用回数「${t}」を読み取れません`);
        else if (n > l) codes.push({ code: 'over_ingredient_total', message: `有効成分${k + 1}を含む農薬の総使用回数が登録の上限 (${t}) を超えています (${n}回)。` });
      });
    }
    const v: Verdict = codes.length ? 'ng' : unknown.length ? 'unknown' : 'ok';
    return { r, v, codes, unknown };
  });

  if (perRow.some((x) => x.v === 'ok')) {
    out.status = 'compliant';
    if (!Array.isArray(input.ingredientUseCounts)) out.notes.push('有効成分ごとの総使用回数は、他の農薬の使用履歴と合わせて確認してください (未入力のため確認していません)。');
    return out;
  }
  if (perRow.every((x) => x.v === 'ng')) {
    out.status = 'violation';
    // 全ての行で違反になっている理由を優先して示す
    const counts = new Map<PesticideViolationCode, { code: PesticideViolationCode; message: string }>();
    const all = perRow.map((x) => new Set(x.codes.map((c) => c.code)));
    for (const x of perRow) for (const c of x.codes) if (all.every((s) => s.has(c.code)) && !counts.has(c.code)) counts.set(c.code, c);
    if (!counts.size) for (const x of perRow) for (const c of x.codes) if (!counts.has(c.code)) counts.set(c.code, c);
    out.violations = [...counts.values()];
    out.notes.push('ラベルの使用方法を確かめ、使用時期・回数・倍数を守れる別の登録農薬を検討してください。');
    return out;
  }
  out.status = 'unverified';
  out.unverified = [...new Set(perRow.flatMap((x) => x.unknown))];
  return out;
}
