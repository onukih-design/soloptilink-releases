/**
 * SoloptiLinkAI — 保育（施設型給付・地域型保育給付の公定価格、令和8年度の加算・減算、こども誰でも通園制度、
 *                 保育ICT推進加算、保護者への請求・無償化、職員配置とみなし保育士）
 *
 * 2026-10-03 T45 新設（REQ-132・REQ-135・REQ-136・REQ-137 / JPO-IND-109・112・113・114）
 *
 * 値の置き場（この部品には法令・告示・通知の数値を書かない）:
 *   - legal-values/hoiku.legal.json            令和7・8年度の加算・減算・誰でも通園・無償化の値（各値に出典の id と適用開始日）
 *   - legal-values/hoiku-koteikakaku.legal.json 公定価格の基本分単価・処遇改善等加算の単価（自治体の単価表から読み取った原子）
 *   - laws_extended.ts JidoFukushi.staffRatioBasis 保育所の配置の比率（施行日で分岐。値の正本）
 * 収載していない年度・地域・施設は「未対応（unsupported）」を返し、近い年度の値で代用しない。
 * 一次資料で確かめられない点は「確認できていない（unconfirmed）」を返し、決めつけない。
 * 端数処理の国の規定は確認できていないため、すべて設定値（rounding）にし、既定は安全側
 *   （減算は切上げ＝請求を多く出さない／加算・給付は切捨て）に置いた。要確認（士業・自治体の確認）。
 *
 * 出典（本文を読んだ日 2026-10-03。URL は値表の primary_sources にもある）:
 *   - こども家庭庁「令和８年度 公定価格・基準等の見直し事項 ～各改定事項概要資料～」令和８年４月
 *   - 横浜市「令和８年度 公定価格単価表（抜粋）」令和８年５月 別表第２ 保育所 16/100地域
 *   - こども家庭庁成育局長通知 こ成保第250号（令和８年４月１日）・令和８年こども家庭庁告示第８号
 *   - こども家庭庁「こども誰でも通園制度について ～基礎資料集～」改定 2026/4/1
 *   - こども家庭庁「幼児教育・保育の無償化概要」
 */

import HOIKU_DOC from "./legal-values/hoiku.legal.json" with { type: "json" };
import KOTEI_DOC from "./legal-values/hoiku-koteikakaku.legal.json" with { type: "json" };
import { JidoFukushi } from "./laws_extended";

// ----------------------------------------------------------------------
// 0) 値表の読み口（loader.mjs と同じ決まり: 出典が無ければ拒否・未収載の年度は代用しない）
// ----------------------------------------------------------------------

type AnyRec = Record<string, any>;
export type Rounding = "floor" | "ceil" | "round";
export const ROUNDING_NOTE_JA =
  "端数処理の国の規定は確認できていないため設定値です（既定は安全側: 減算は切上げ・加算と給付は切捨て）。要確認（自治体・士業の確認）";

function checkDoc(doc: AnyRec, name: string): void {
  if (!Array.isArray(doc.primary_sources) || doc.primary_sources.length === 0) throw new Error(`${name} に出典（primary_sources）が無い`);
  for (const s of doc.primary_sources) if (!s.title_ja || !s.url) throw new Error(`${name} の出典に title_ja / url が欠けている`);
}
checkDoc(HOIKU_DOC as AnyRec, "hoiku.legal.json");
checkDoc(KOTEI_DOC as AnyRec, "hoiku-koteikakaku.legal.json");

/** 年度キー（FY2026 など）の値。無ければ null（呼び出し元は「未対応」を返す） */
function fyValues(fy: string): AnyRec | null {
  const y = (HOIKU_DOC as AnyRec).fiscal_years?.[fy];
  return y ? (y as AnyRec) : null;
}
function sourceUrl(id: string | undefined): string | null {
  const s = ((HOIKU_DOC as AnyRec).primary_sources as AnyRec[]).find((x) => x.id === id);
  return s ? String(s.url) : null;
}
const unsupported = (reason_ja: string, extra: AnyRec = {}) => ({ status: "unsupported" as const, amount: null, reason_ja, ...extra });

export function roundYen(x: number, mode: Rounding): number {
  // 浮動小数の誤差（4285.7142… や 25488.000000004）を 1e-9 で吸収してから丸める
  const e = 1e-9;
  if (mode === "ceil") return Math.ceil(x - e);
  if (mode === "round") return Math.round(x);
  return Math.floor(x + e);
}

// ----------------------------------------------------------------------
// 日付の小道具（暦日の文字列 YYYY-MM-DD / 月 YYYY-MM で扱い、時刻帯に依存しない）
// ----------------------------------------------------------------------
function ymd(s: string): [number, number, number] {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(s || ""));
  if (!m) throw new TypeError(`日付は YYYY-MM-DD で渡す（受領: ${s}）`);
  return [Number(m[1]), Number(m[2]), Number(m[3])];
}
function fmt(t: number): string {
  const d = new Date(t);
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}`;
}
function addDays(s: string, n: number): string {
  const [y, m, d] = ymd(s);
  return fmt(Date.UTC(y, m - 1, d + n));
}
/** 民法143条: 月・年で定めた期間は応当日の前日に満了。応当日が無ければその月の末日 */
function periodEnd(start: string, months: number): string {
  const [y, m, d] = ymd(start);
  const ty = y + Math.floor((m - 1 + months) / 12);
  const tm = ((m - 1 + months) % 12 + 12) % 12; // 0始まり
  const last = new Date(Date.UTC(ty, tm + 1, 0)).getUTCDate();
  if (d > last) return fmt(Date.UTC(ty, tm, last));
  return fmt(Date.UTC(ty, tm, d - 1));
}
/** 実施日 d から「実施されていない状況が1年継続した日」＝ d の1年後の前日（S1 p.8 施設B: R7.5.15→R8.5.14） */
function oneYearContinued(d: string): string {
  return periodEnd(d, 12);
}
const monthOf = (s: string) => String(s).slice(0, 7);
function addMonths(ym: string, n: number): string {
  const [y, m] = ym.split("-").map(Number);
  const t = (y * 12 + (m - 1)) + n;
  return `${Math.floor(t / 12)}-${String((t % 12) + 1).padStart(2, "0")}`;
}
/** 月 YYYY-MM が属する年度キー（4月始まり） */
export function fiscalYearOfMonth(ym: string): string {
  const [y, m] = ym.split("-").map(Number);
  return `FY${m >= 4 ? y : y - 1}`;
}
const monthLastDay = (ym: string) => { const [y, m] = ym.split("-").map(Number); return fmt(Date.UTC(y, m, 0)); };

export type FacilityType =
  | "hoikusho" | "kindergarten" | "kodomoen"
  | "katei" | "shokibo_a" | "shokibo_b" | "shokibo_c" | "jigyosho_nai" | "kyotaku_houmon" | "mansan_shokibo";
const SHISETSU_TYPES = ["hoikusho", "kindergarten", "kodomoen"];
const groupOf = (ft: string) => (SHISETSU_TYPES.includes(ft) ? "shisetsu" : "chiiki");

/** 値の出典URLと適用開始日 */
export function hoikuValueSource(key: string, fy: string) {
  const v = fyValues(fy);
  if (!v) return unsupported(`${fy} の保育の値を収載していません（旧い年度の値で代用しません）`);
  const e = v[key];
  if (!e) return { status: "not_established" as const, url: null, effective_from: null, reason_ja: `${fy} には ${key} の制度がありません` };
  return { status: "ok" as const, source_id: e.source, url: sourceUrl(e.source), effective_from: e.effective_from ?? null, secondary_url: sourceUrl(e.source_secondary) };
}

// ----------------------------------------------------------------------
// 1) 令和8年度の加算・減算（REQ-132）
// ----------------------------------------------------------------------

/** 安全計画の策定等をしていない場合の減算の判定に使う項目 */
const ANZEN_ITEMS_BY_TYPE: Record<string, string[]> = {
  kindergarten: ["all"], kodomoen: ["all"],
};
const ANZEN_ITEM_LABEL: Record<string, string> = {
  all: "計画に定める取組", training: "訓練・研修（第6条の3第2項）", notice: "保護者等への周知（第3項）", review: "安全計画の見直し（第4項）",
};

export interface AnzenKeikakuInput {
  facilityType: FacilityType | string;
  /** 減算を判定する月（YYYY-MM） */
  month: string;
  /** 安全計画を策定した日。null/未指定は未策定 */
  formulatedOn?: string | null;
  /** 実施の記録（項目ごとの実施日）。保育所・地域型は training / notice / review、幼稚園・認定こども園は all */
  implementations?: Record<string, string[]>;
}

/**
 * 安全計画の策定等をしていない場合の減算（1,350円/月・令和8年7月〜）。S1 p.8・横浜市単価表「－1,350」。
 *   未策定: 策定された日の属する月まで。
 *   不実施: 計画に定める内容が実施されていない状況が1年継続した日の翌月から、解消した日の属する月まで（項目ごと）。
 *   記録が無い項目は「確認できていない」（策定から1年以内は不実施が1年続くことがないので減算なし）。
 */
export function anzenKeikakuGensan(input: AnzenKeikakuInput) {
  const v26 = fyValues("FY2026")!.anzen_keikaku_gensan;
  const startMonth: string = v26.start_month;
  const M = String(input.month);
  const fy = fiscalYearOfMonth(M);
  const fv = fyValues(fy);
  const amountEntry = fv ? fv.anzen_keikaku_gensan : null;
  const base = { source_url: sourceUrl(v26.source), effective_from: v26.effective_from };
  const withAmount = (applies: boolean, reasons_ja: string[]) => ({
    status: "ok" as const, applies,
    amount_per_child_month: applies ? (amountEntry ? amountEntry.amount_per_child_month : null) : 0,
    amount_status: applies && !amountEntry ? `${fy} の減算額を収載していません（未対応）` : "ok",
    reasons_ja, ...base,
  });
  if (M < startMonth) return { ...withAmount(false, [`${startMonth} 分から適用（それより前は減算なし）`]), status: "not_yet_effective" as const };

  const monthEnd = monthLastDay(M);
  const F = input.formulatedOn || null;
  if (!F || F > monthEnd || monthOf(F) === M) {
    return withAmount(true, [F ? `安全計画の策定は ${F}。策定された日の属する月まで減算` : "安全計画が未策定"]);
  }
  const items = ANZEN_ITEMS_BY_TYPE[String(input.facilityType)] || v26.items_hoikusho;
  const impl = input.implementations || {};
  const lapsed: string[] = [];
  const unknown: string[] = [];
  for (const it of items) {
    const list = (impl[it] || []).filter((d) => !!d).map((d) => String(d).slice(0, 10)).sort();
    if (list.length === 0) {
      if (M <= monthOf(oneYearContinued(F))) continue; // 策定から1年以内
      unknown.push(ANZEN_ITEM_LABEL[it] || it);
      continue;
    }
    const seq = F < list[0] ? [F, ...list] : list;
    let hit = false;
    for (let i = 0; i < seq.length; i++) {
      const lapseDay = oneYearContinued(seq[i]);
      const next = seq[i + 1];
      if (next && next <= lapseDay) continue;
      const from = addMonths(monthOf(lapseDay), 1);
      const to = next ? monthOf(next) : "9999-12";
      if (M >= from && M <= to) { hit = true; break; }
    }
    if (hit) lapsed.push(ANZEN_ITEM_LABEL[it] || it);
  }
  if (lapsed.length) return withAmount(true, [`実施されていない状況が1年継続: ${lapsed.join("・")}`]);
  if (unknown.length) {
    return { status: "unconfirmed" as const, applies: null, amount_per_child_month: null, reasons_ja: [`実施の記録が無く判定できません（確認できていない）: ${unknown.join("・")}`], ...base };
  }
  return withAmount(false, ["策定済みで、計画に定める取組の不実施が1年継続していない"]);
}

/** 経営情報等の報告期限（毎事業年度終了後5か月以内）。事業年度の末日から求める */
export function keieiJohoDeadline(fyEnd: string): string {
  const k = fyValues("FY2026")!.keiei_joho_gensan;
  // 末日の翌日から起算して5か月＝応当日の前日（3/31 → 8/31）
  return periodEnd(addDays(fyEnd, 1), k.report_deadline_months_after_fy_end);
}

export interface KeieiJohoInput {
  deadline: string; // 報告期限（YYYY-MM-DD）
  reportedOn?: string | null;
  month: string; // 減算を判定する月
  asOf?: string; // 未報告のときの判定日
  baseUnitPrice: number; // 基本分単価（⑥）
  rounding?: Rounding; // 既定 ceil（減算は切上げ・安全側・要確認）
}

/**
 * 経営情報等の報告を行っていない場合の減算（基本分単価×5/100・令和8年7月〜）。S1 p.14・子ども・子育て支援法第58条第2項。
 * 報告期限から3か月以上経過して未報告（または期限経過後3か月以上たってから報告）のとき、期限の属する日の翌月から
 * 報告等がなされる日の属する月まで。災害等で市町村が認める期間は対象外（入力 excludedByMunicipality で扱う）。
 */
export function keieiJohoGensan(input: KeieiJohoInput & { excludedByMunicipality?: boolean }) {
  const k26 = fyValues("FY2026")!.keiei_joho_gensan;
  const M = String(input.month);
  const fy = fiscalYearOfMonth(M);
  const fv = fyValues(fy);
  const entry = fv ? fv.keiei_joho_gensan : null;
  const rounding: Rounding = input.rounding || "ceil";
  const base = { source_url: sourceUrl(k26.source), effective_from: k26.effective_from, rounding, rounding_note_ja: ROUNDING_NOTE_JA };
  const no = (reason: string, status = "ok") => ({ status, applies: false, amount: 0, reasons_ja: [reason], ...base });
  if (M < k26.start_month) return no(`${k26.start_month} 分から適用（それより前は減算なし）`, "not_yet_effective");
  if (input.excludedByMunicipality) return no("災害その他やむを得ない事情により市町村が認める期間（減算しない）");
  const elapsedDay = addDays(periodEnd(addDays(input.deadline, 1), k26.grace_months), 1); // 3か月を経過した日
  const firstMonth = addMonths(monthOf(input.deadline), 1);
  let applies = false;
  let reason = "";
  if (input.reportedOn) {
    if (input.reportedOn < elapsedDay) { applies = false; reason = `報告日 ${input.reportedOn} は期限から3か月を経過する前（${elapsedDay} より前）`; }
    else { applies = M >= firstMonth && M <= monthOf(input.reportedOn); reason = `期限 ${input.deadline} の翌月（${firstMonth}）から報告月（${monthOf(input.reportedOn)}）まで`; }
  } else {
    const asOf = input.asOf || monthLastDay(M);
    if (asOf < elapsedDay) { applies = false; reason = `判定日 ${asOf} は期限から3か月を経過する前`; }
    else { applies = M >= firstMonth; reason = `未報告。期限 ${input.deadline} の翌月（${firstMonth}）から報告されるまで`; }
  }
  if (!applies) return no(reason || "減算の期間外");
  if (!entry) return { status: "ok", applies: true, amount: null, amount_status: `${fy} の率を収載していません（未対応）`, reasons_ja: [reason], ...base };
  const amount = roundYen((Number(input.baseUnitPrice) * entry.rate_numerator) / entry.rate_denominator, rounding);
  return { status: "ok", applies: true, amount, reasons_ja: [reason], ...base };
}

/**
 * 年齢別配置基準を下回る場合の減算が生じる月（幼稚園・認定こども園）。S1 p.15。
 * 令和8年度の見直し: 月の15日以降の退職等で基準を満たさなくなる場合は翌々月から。14日以前は翌月から。
 */
export function haichiGensanStartMonth(input: { facilityType: string; retirementDate: string }) {
  const fy26 = fyValues("FY2026")!.haichi_gensan_timing;
  if (!fy26.applies_to.includes(String(input.facilityType))) {
    return { applicable: false, start_month: null, reason_ja: "この減算は幼稚園・認定こども園の年齢別配置基準の減算です（保育所等は対象外）" };
  }
  const d = String(input.retirementDate).slice(0, 10);
  const rule = d >= fy26.effective_from ? fy26 : fyValues("FY2025")!.haichi_gensan_timing;
  const day = Number(d.slice(8, 10));
  const lag = rule.late_threshold_day && day >= rule.late_threshold_day ? rule.lag_months_late : rule.lag_months_early;
  return {
    applicable: true, start_month: addMonths(monthOf(d), lag),
    reason_ja: rule.late_threshold_day ? `退職等の日が${day}日（${rule.late_threshold_day}日以降は翌々月・それより前は翌月）` : "見直し前の運用（翌月から）。令和8年4月1日より前の退職等の扱いは要確認",
    source_url: sourceUrl(rule.source), effective_from: rule.effective_from,
  };
}

/** 学級編制調整加配加算（認定こども園・教育標準時間認定）。幼稚園は基本分単価に算入 */
export function gakkyuHenseiChoseiKahai(input: { fy: string; facilityType: string; capacity1go: number }) {
  const v = fyValues(input.fy);
  if (!v || !v.gakkyu_hensei_chosei_kahai) return { ...unsupported(`${input.fy} の値を収載していません`), eligible: null };
  if (input.facilityType === "kindergarten") return { status: "included_in_base" as const, eligible: null, reason_ja: "幼稚園は加算でなく基本分単価に算入" };
  if (input.facilityType !== "kodomoen") return { status: "not_applicable" as const, eligible: false, reason_ja: "認定こども園（教育標準時間認定）の加算" };
  const min = v.gakkyu_hensei_chosei_kahai.min_children;
  return { status: "ok" as const, eligible: Number(input.capacity1go) >= min, min_children: min, source_url: sourceUrl(v.gakkyu_hensei_chosei_kahai.source) };
}

/** 施設機能強化推進費加算（年額の限度額・3月初日の利用子ども数で割って加算） */
export function shisetsuKinoKyokaKasan(input: { fy: string; facilityType: string }) {
  const v = fyValues(input.fy);
  if (!v || !v.shisetsu_kino_kyoka_kasan) return unsupported(`${input.fy} の値を収載していません`);
  const e = v.shisetsu_kino_kyoka_kasan;
  if (!e.eligible_types.includes(input.facilityType)) return { status: "not_applicable" as const, amount: null, reason_ja: `${input.fy} は対象外の施設・事業` };
  return { status: "ok" as const, amount: e.amount_by_group[groupOf(input.facilityType)], source_url: sourceUrl(e.source) };
}

/** 満3歳以上限定小規模保育事業の基本分単価（1〜2歳児単価×65/100・60/100）。単価の金額は自治体の単価表から渡す */
export function mansanShokiboUnit(input: { fy: string; age: "3" | "4-5"; unit12: number; rounding?: Rounding }) {
  const v = fyValues(input.fy);
  if (!v) return unsupported(`${input.fy} の値を収載していません`);
  const e = v.mansan_shokibo;
  if (!e) return { status: "not_established" as const, amount: null, reason_ja: `${input.fy} は満3歳以上限定小規模保育事業の創設前（令和8年4月1日施行）` };
  const r = e.ratio_by_age[input.age];
  if (!r) return unsupported("年齢区分は 3 または 4-5");
  const rounding: Rounding = input.rounding || "floor";
  return { status: "ok" as const, amount: roundYen((Number(input.unit12) * r.numerator) / r.denominator, rounding), rounding, rounding_note_ja: ROUNDING_NOTE_JA, source_url: sourceUrl(e.source) };
}

/** 保育ICT推進加算の年額（施設型30万円・地域型18万円） */
export function hoikuIctKasanAmount(input: { fy: string; facilityType: string }) {
  const v = fyValues(input.fy);
  if (!v) return unsupported(`${input.fy} の値を収載していません`);
  if (!v.hoiku_ict_kasan) return { status: "not_established" as const, amount: null, reason_ja: `${input.fy} には保育ICT推進加算がありません` };
  return { status: "ok" as const, amount: v.hoiku_ict_kasan.amount_by_group[groupOf(input.facilityType)], source_url: sourceUrl(v.hoiku_ict_kasan.source) };
}

/** 年額の加算を3月初日の利用子ども数で割った1人当たりの額（既定は切捨て） */
export function perChildAnnualKasan(input: { annualAmount: number; marchFirstChildren: number; rounding?: Rounding }) {
  const n = Number(input.marchFirstChildren);
  if (!(n > 0)) return { status: "error" as const, amount: null, reason_ja: "3月初日の利用子ども数が要ります" };
  const rounding: Rounding = input.rounding || "floor";
  return { status: "ok" as const, amount: roundYen(Number(input.annualAmount) / n, rounding), rounding, rounding_note_ja: ROUNDING_NOTE_JA };
}

// ----------------------------------------------------------------------
// 2) 公定価格（基本分単価＋加算−減算）と職員配置（REQ-135）
// ----------------------------------------------------------------------

export type KoteiAge = "4+" | "3" | "1-2" | "0";
export interface KoteiInput {
  fy: string;
  region: string; // 地域区分（例 "16/100"）
  facilityType: string; // 収載は "hoikusho"
  capacity: number; // 利用定員
  ageClass: KoteiAge;
  certification: "standard" | "short"; // 保育標準時間認定 / 保育短時間認定
  ageAdjusted?: boolean; // （注１）年度の初日の前日における満年齢に応じて調整する月額
}

function koteiRow(input: KoteiInput): { row: AnyRec; table: AnyRec } | { error: string } {
  const y = (KOTEI_DOC as AnyRec).fiscal_years?.[input.fy];
  if (!y) return { error: `${input.fy} の公定価格の単価表を収載していません（旧い年度の単価で代用しません）` };
  const table = y.regions?.[input.region]?.[input.facilityType];
  if (!table) return { error: `地域区分 ${input.region}・${input.facilityType} の単価表を収載していません` };
  const cap = Number(input.capacity);
  const row = (table.rows as AnyRec[]).find((r) => r.age === input.ageClass && cap >= r.cap_min && (r.cap_max === null || cap <= r.cap_max));
  if (!row) return { error: `定員 ${input.capacity} 人・年齢区分 ${input.ageClass} に当たる行がありません（近い区分で代用しません）` };
  return { row, table };
}
function koteiSource() {
  const s = ((KOTEI_DOC as AnyRec).primary_sources as AnyRec[])[0];
  return { source_url: String(s.url), source_pdf_sha256: s.sha256 || null };
}

/** 基本分単価（原子から引く。金額をここに書かない） */
export function koteikakakuBaseUnit(input: KoteiInput) {
  const r = koteiRow(input);
  if ("error" in r) return unsupported(r.error);
  const key = `base_${input.certification}${input.ageAdjusted ? "_age_adjusted" : ""}`;
  const amount = r.row[key];
  if (typeof amount !== "number") return unsupported(`単価表に ${key} がありません`);
  return { status: "ok" as const, amount, ...koteiSource(), page: r.table.page, cap_range: [r.row.cap_min, r.row.cap_max] };
}

/** 処遇改善等加算（区分1及び区分2）＝単価×（加算率(a)＋加算率(b)＋(c)） */
export function shoguKaizenAmount(input: KoteiInput & { rateA: number; rateB: number; rounding?: Rounding }) {
  const r = koteiRow(input);
  if ("error" in r) return unsupported(r.error);
  const sfx = `${input.certification}${input.ageAdjusted ? "_age_adjusted" : ""}`;
  const unit = r.row[`shogu_unit_${sfx}`];
  const c = r.row[`shogu_c_${sfx}`];
  if (typeof unit !== "number" || typeof c !== "number") return unsupported("単価表に処遇改善等加算の単価がありません");
  const tenths = Math.round((Number(input.rateA) + Number(input.rateB) + c) * 10);
  const rounding: Rounding = input.rounding || "floor";
  return { status: "ok" as const, amount: roundYen((unit * tenths) / 10, rounding), unit, c, rounding, rounding_note_ja: ROUNDING_NOTE_JA, ...koteiSource() };
}

/**
 * 1人当たりの月額（基本分単価＋処遇改善等加算−安全計画の減算−経営情報の減算）。
 * 減算は令和8年度は7月から加減調整（横浜市単価表 注３）。ほかの加算は対象外（未対応・別途）。
 */
export function koteikakakuMonthly(input: KoteiInput & {
  month: string; rateA: number; rateB: number;
  deductions?: { anzenKeikaku?: boolean; keieiJoho?: boolean };
  rounding?: { addition?: Rounding; deduction?: Rounding };
}) {
  if (fiscalYearOfMonth(input.month) !== input.fy) return { status: "error" as const, amount: null, reason_ja: `${input.month} は ${input.fy} の月ではありません` };
  const b = koteikakakuBaseUnit(input);
  if (b.status !== "ok") return b;
  const s = shoguKaizenAmount({ ...input, rounding: input.rounding?.addition });
  if (s.status !== "ok") return s;
  const v = fyValues(input.fy);
  const lines: { label_ja: string; amount: number }[] = [
    { label_ja: "基本分単価", amount: b.amount as number },
    { label_ja: "処遇改善等加算（区分1及び区分2）", amount: s.amount as number },
  ];
  const ded: Rounding = input.rounding?.deduction || "ceil";
  const notes: string[] = [];
  if (input.deductions?.anzenKeikaku) {
    const e = v?.anzen_keikaku_gensan;
    if (!e) notes.push(`${input.fy} に安全計画の減算はありません`);
    else if (input.month < e.start_month) notes.push(`安全計画の減算は ${e.start_month} から`);
    else lines.push({ label_ja: "安全計画の策定等をしていない場合（減算）", amount: -e.amount_per_child_month });
  }
  if (input.deductions?.keieiJoho) {
    const e = v?.keiei_joho_gensan;
    if (!e) notes.push(`${input.fy} に経営情報の減算はありません`);
    else if (input.month < e.start_month) notes.push(`経営情報の減算は ${e.start_month} から`);
    else lines.push({ label_ja: "経営情報等の報告を行っていない場合（減算・基本分単価×5/100）", amount: -roundYen(((b.amount as number) * e.rate_numerator) / e.rate_denominator, ded) });
  }
  const amount = lines.reduce((a, l) => a + l.amount, 0);
  return { status: "ok" as const, amount, lines, notes_ja: notes, rounding_note_ja: ROUNDING_NOTE_JA, ...koteiSource() };
}

const AGE_MONTHS: Record<string, number> = { "0": 6, "1-2": 18, "3": 42, "4+": 54 };
/**
 * 必要保育士数（省令第33条第2項。比率は laws_extended.ts の JidoFukushi.staffRatioBasis を呼ぶ）。
 * mode: standard（基準）/ transitional（経過措置: 3歳20:1は令和10年3月31日まで・4歳以上30:1は当分の間）
 * rounding: per_class_ceil（区分ごとに切上げ・既定・安全側）/ sum_then_ceil（合計してから切上げ）。要確認
 */
export function requiredNurseryStaff(input: {
  counts: Record<string, number>; asOf: string; mode: "standard" | "transitional"; rounding?: "per_class_ceil" | "sum_then_ceil";
}) {
  const c = input.counts || {};
  const n = (k: string) => Number(c[k] || 0);
  const classes: Record<string, number> = { "0": n("0"), "1-2": n("1") + n("2") + n("1-2"), "3": n("3"), "4+": n("4") + n("5") + n("4+") };
  const byClass: AnyRec[] = [];
  const notes: string[] = [];
  let num = 0; // 300分の1単位（3・6・15・20・25・30の最小公倍数）
  let perClass = 0;
  for (const [k, cnt] of Object.entries(classes)) {
    if (!cnt) continue;
    const basis = JidoFukushi.staffRatioBasis(AGE_MONTHS[k], { asOf: input.asOf, transitional: input.mode === "transitional" });
    if (input.mode === "transitional" && !basis.transitionalApplied && (k === "3" || k === "4+")) notes.push(`${k}歳: 経過措置の期間外（終期 ${basis.transitionalLastDay ?? "なし"}）のため基準で計算`);
    num += cnt * (300 / basis.ratio);
    perClass += Math.ceil(cnt / basis.ratio);
    byClass.push({ ageClass: k, children: cnt, ratio: basis.ratio, applied_rule: basis.appliedRule });
  }
  const minimum = (HOIKU_DOC as AnyRec).staff_ratio.minimum_per_facility;
  const raw = input.rounding === "sum_then_ceil" ? Math.ceil(num / 300) : perClass;
  const total = Object.values(classes).reduce((a, b) => a + b, 0);
  const required = total > 0 ? Math.max(minimum, raw) : 0;
  return { required, by_class: byClass, rounding: input.rounding || "per_class_ceil", notes_ja: notes, rounding_note_ja: "端数処理の国の規定は確認できていないため設定値（既定は区分ごとに切上げ・安全側）。要確認" };
}

/**
 * みなし保育士の特例（S1 p.12）。看護師等1人・専門職1人（令和8年度〜）。併用は保育所と認定こども園だけで、それぞれ別の保育士の支援が要る。
 * 幼稚園教諭等・8時間超の特例は必要数の2/3以上を保育士とすること（保育士の数は実際の保育士だけで数える・安全側）。
 * 朝夕の少人数時の特例（2人目に代わる者）は扱わない（未対応）。
 */
export function checkDeemedNurseryStaff(input: {
  fy: string; facilityType: string; required: number;
  staff: { nurseryTeachers?: number; nurses?: number; specialists?: number; kindergartenTeachers?: number; over8hDeemed?: number };
  supporters?: { nurse?: string; specialist?: string };
}) {
  const v = fyValues(input.fy);
  if (!v || !v.minashi) return { ...unsupported(`${input.fy} の値を収載していません`), satisfied: null, counted: null };
  const mn = v.minashi;
  const s = input.staff || {};
  const reasons: string[] = [];
  const nt = Number(s.nurseryTeachers || 0);
  let nurse = Math.min(Number(s.nurses || 0), mn.nurse_max);
  let spec = Math.min(Number(s.specialists || 0), mn.specialist_max);
  if (Number(s.specialists || 0) > 0 && mn.specialist_max === 0) reasons.push(`${input.fy} は専門職のみなし特例がありません`);
  if (nurse && spec) {
    if (!mn.nurse_specialist_combined_types.includes(input.facilityType)) {
      spec = 0; reasons.push("看護師等と専門職の併用は保育所・認定こども園だけ（ほかは1人だけ数える・安全側）");
    } else if (!input.supporters?.nurse || !input.supporters?.specialist || input.supporters.nurse === input.supporters.specialist) {
      spec = 0; reasons.push("併用するときは、それぞれ別の保育士の支援が要る");
    }
  }
  const kyoyu = Number(s.kindergartenTeachers || 0) + Number(s.over8hDeemed || 0);
  let kyoyuCounted = kyoyu;
  if (kyoyu > 0) {
    const r = mn.kyoyu_min_hoikushi_ratio;
    if (!r || nt * r.denominator < Number(input.required) * r.numerator) {
      kyoyuCounted = 0; reasons.push("幼稚園教諭等・8時間超のみなしは必要数の2/3以上を保育士とすることが要る");
    }
  }
  const counted = nt + nurse + spec + kyoyuCounted;
  return { status: "ok" as const, satisfied: counted >= Number(input.required), counted, required: Number(input.required), reasons_ja: reasons, source_url: sourceUrl(mn.source) };
}

// ----------------------------------------------------------------------
// 3) こども誰でも通園制度と保育ICT推進加算（REQ-136）
// ----------------------------------------------------------------------

export function daredemoBenefit(input: { fy: string; ageAtFyStart: number; minutes: number; additions?: string[] }) {
  const v = fyValues(input.fy);
  if (!v || !v.daredemo) return { status: "unsupported" as const, public_amount: null, standard_fee: null, reason_ja: `${input.fy} の誰でも通園の単価を収載していません（旧い年度の単価で代用しません）` };
  const d = v.daredemo;
  const unit = d.unit_per_hour_by_age[String(input.ageAtFyStart)];
  if (typeof unit !== "number") return { status: "not_covered" as const, public_amount: null, standard_fee: null, reason_ja: "対象は年度当初0〜2歳（満3歳未満）" };
  const adds = input.additions || [];
  if (adds.length > 1) return { status: "needs_choice" as const, public_amount: null, standard_fee: null, reason_ja: "障害児加算・医療的ケア児加算・要支援家庭こども加算は併せて加算できません（いずれか1つ）" };
  let add = 0;
  if (adds.length === 1) {
    if (!d.additions_per_hour) return { status: "unconfirmed" as const, public_amount: null, standard_fee: null, reason_ja: `${input.fy} の加算の単価は収載していません（確認できていない）` };
    const a = d.additions_per_hour[adds[0]];
    if (typeof a !== "number") return { status: "error" as const, public_amount: null, standard_fee: null, reason_ja: `加算の種類が不明: ${adds[0]}` };
    add = a;
  }
  const minutes = Number(input.minutes);
  const minMin = d.min_minutes_per_use ?? 60;
  const inc = d.increment_minutes ?? 30;
  if (!(minutes >= minMin)) return { status: "below_minimum" as const, public_amount: null, standard_fee: null, reason_ja: "1回の利用は1時間以上" };
  const halfUnits = 2 + Math.floor((minutes - 60) / inc) * (inc / 30); // 30分単位の数（1時間＝2）
  const notes = (minutes - 60) % inc ? ["30分に満たない部分は給付の時間に数えていません（要確認）"] : [];
  const public_amount = roundYen(((unit + add) * halfUnits) / 2, "floor");
  const standard_fee = roundYen((d.standard_fee_per_hour * halfUnits) / 2, "floor");
  return { status: "ok" as const, public_amount, standard_fee, hours: halfUnits / 2, kind_ja: d.kind, notes_ja: notes, source_url: sourceUrl(d.source) };
}

export function validateDaredemoCap(input: { fy: string; capHours: number }) {
  const y = Number(String(input.fy).slice(2));
  const cap = Number(input.capHours);
  const v26 = fyValues("FY2026")!.daredemo;
  if (y >= 2026 && y <= 2027) {
    return { valid: cap >= v26.cap_hours_municipal_min && cap <= v26.cap_hours_national, reason_ja: "令和8・9年度は条例で3時間〜10時間（10時間が国の基準）" };
  }
  if (y >= 2028) return { valid: cap === v26.cap_hours_national, reason_ja: "経過措置は令和9年度まで。令和10年度からは月10時間" };
  return { valid: cap === v26.cap_hours_national, reason_ja: "令和7年度以前は月10時間（試行）" };
}

/** 月の上限時間を超える予約は受け付けない */
export function daredemoReserve(input: { fy: string; capHours: number; usedMinutes: number; requestedMinutes: number }) {
  const cap = validateDaredemoCap({ fy: input.fy, capHours: input.capHours });
  if (!cap.valid) return { accepted: false, reason_ja: `上限時間の設定が範囲外: ${cap.reason_ja}` };
  const after = Number(input.usedMinutes) + Number(input.requestedMinutes);
  const capMin = Number(input.capHours) * 60;
  if (Number(input.requestedMinutes) < 60) return { accepted: false, reason_ja: "1回の利用は1時間以上" };
  if (after > capMin) return { accepted: false, remaining_minutes: Math.max(0, capMin - Number(input.usedMinutes)), reason_ja: `月の上限 ${input.capHours} 時間を超えます（予約後 ${after / 60} 時間）` };
  return { accepted: true, remaining_minutes: capMin - after };
}

/** キャンセル: 当日午前0時以降は給付の対象にでき利用可能時間から減算。事業者の都合は対象外・減算しない */
export function daredemoCancel(input: { cancelledAt: string; useStartAt: string; byProvider?: boolean }) {
  if (input.byProvider) return { billable: false, counts_against_cap: false, reason_ja: "事業者の都合のキャンセルは給付の対象外・利用可能時間も減らさない" };
  const useDay = String(input.useStartAt).slice(0, 10);
  const cancelDay = String(input.cancelledAt).slice(0, 10);
  const sameOrAfter = cancelDay >= useDay;
  return sameOrAfter
    ? { billable: true, counts_against_cap: true, reason_ja: "利用当日の午前0時以降のキャンセル（相談援助の記録を残すこと）" }
    : { billable: false, counts_against_cap: false, reason_ja: "前日までのキャンセル" };
}

export const HOIKU_ICT_FUNCTIONS = [
  { id: "attendance", label_ja: "園児の登園及び降園の管理", match: /登降園|登園|降園|打刻|attendance/i },
  { id: "guardian_contact", label_ja: "保護者との連絡", match: /連絡帳|保護者連絡|おたより|お知らせ配信|contact-book|notices?/i },
  { id: "plan_record", label_ja: "保育に関する計画・記録", match: /指導計画|月案|週案|保育日誌|保育記録|plans?|journals?/i },
  { id: "cashless", label_ja: "キャッシュレス決済", match: /キャッシュレス|cashless|オンライン決済|クレジットカード決済/i },
] as const;

/** 画面一覧に4機能の画面があるか（生成物の巡回・ひな形の画面一覧の両方に使う） */
export function checkIctFunctionsInPages(pages: { path?: string; title?: string; description?: string }[]) {
  const found: Record<string, string[]> = {};
  for (const f of HOIKU_ICT_FUNCTIONS) {
    found[f.id] = (pages || []).filter((p) => f.match.test(`${p.path || ""} ${p.title || ""} ${p.description || ""}`)).map((p) => String(p.path || p.title));
  }
  const missing = HOIKU_ICT_FUNCTIONS.filter((f) => found[f.id].length === 0).map((f) => f.id);
  return { found, missing };
}

export type PlatformStatus = "unconfirmed" | "account_issued" | "verified_connected";
/** 国の基盤との連携状況の表示。確認の証跡（確認日・方法）が無いものを「連携済」と表示しない */
export function platformStatusLabel(status: string, evidence?: { verifiedAt?: string; method?: string }): string {
  if (status === "verified_connected" && evidence?.verifiedAt && evidence?.method) return `連携済（確認日 ${evidence.verifiedAt}・${evidence.method}）`;
  if (status === "account_issued") return "アカウント発行済み（未連携・手入力/CSV）";
  return "未確認（手入力/CSV）";
}

/** 保育ICT推進加算の算定可否（S1 p.16） */
export function evaluateIctKasan(input: {
  fy: string; facilityType: string; hasIctLead: boolean; functions: string[];
  platforms: { shisetsu_kanri?: string; hokatsu?: string };
  kokodeSearchUpdatedOn?: string | null; ictSubsidyThisYear?: boolean;
}) {
  const v = fyValues(input.fy);
  if (!v) return { status: "unconfirmed" as const, eligible: null, amount: null, reasons_ja: [`${input.fy} の要件（基盤の「活用」の中身）は令和8年度中に示す予定で、まだ収載していません（確認できていない）`] };
  const e = v.hoiku_ict_kasan;
  if (!e) return { status: "not_established" as const, eligible: false, amount: null, reasons_ja: [`${input.fy} には保育ICT推進加算がありません`] };
  const reasons: string[] = [];
  if (!input.hasIctLead) reasons.push("ICT活用の責任者を置いていない");
  const miss = (e.functions as string[]).filter((f) => !(input.functions || []).includes(f));
  if (miss.length) reasons.push(`4機能のうち欠け: ${miss.join("・")}`);
  const okPf = (s?: string) => (e.platform_account_suffices_this_year ? s === "account_issued" || s === "verified_connected" : s === "verified_connected");
  if (!okPf(input.platforms?.shisetsu_kanri)) reasons.push("保育業務施設管理プラットフォームのアカウント発行（活用）が確認できない");
  if (!okPf(input.platforms?.hokatsu)) reasons.push("保活情報連携基盤のアカウント発行（活用）が確認できない");
  if (!input.kokodeSearchUpdatedOn || input.kokodeSearchUpdatedOn > e.kokode_search_update_deadline) reasons.push(`ここdeサーチの運営状況の最新化が ${e.kokode_search_update_deadline} までに無い`);
  if (input.ictSubsidyThisYear) reasons.push("保育所等におけるICT化推進等事業の補助を受けた年度は算定できない");
  const eligible = reasons.length === 0;
  return { status: "ok" as const, eligible, amount: eligible ? e.amount_by_group[groupOf(input.facilityType)] : null, reasons_ja: reasons, source_url: sourceUrl(e.source) };
}

// ----------------------------------------------------------------------
// 4) 保護者への請求・無償化・振替データ・帳票の照合（REQ-137）
// ----------------------------------------------------------------------

/** 施設等利用給付（無償化）の上限で、給付と自己負担を分ける */
export function shisetsuToRiyoKyufu(input: {
  fy: string; facility: "ninkagai" | "mikoko_kindergarten" | "azukari_hoiku" | string;
  ageAtFyStart: number; fee: number; hoikuNeedCertified?: boolean; residentTaxExempt?: boolean;
}) {
  const v = fyValues(input.fy);
  if (!v || !v.mushouka) return { status: "unsupported" as const, benefit: null, self_pay: null, reason_ja: `${input.fy} の無償化の上限を収載していません` };
  const mu = v.mushouka;
  const fee = Number(input.fee);
  const split = (cap: number | null, reason: string) => {
    if (cap === null) return { status: "ok" as const, benefit: 0, self_pay: fee, cap: null, reason_ja: reason, source_url: sourceUrl(mu.source) };
    const benefit = Math.min(fee, cap);
    return { status: "ok" as const, benefit, self_pay: fee - benefit, cap, reason_ja: reason, source_url: sourceUrl(mu.source) };
  };
  if (input.facility === "azukari_hoiku") return { status: "unconfirmed" as const, benefit: null, self_pay: null, reason_ja: "幼稚園の預かり保育は日額との比較の規定を一次資料で確かめていません（確認できていない）" };
  if (input.facility === "mikoko_kindergarten") return split(mu.mikoko_kindergarten_cap, "新制度未移行の幼稚園（月額上限）");
  if (input.facility === "ninkagai") {
    if (!input.hoikuNeedCertified) return split(null, "保育の必要性の認定が無いため給付の対象外");
    if (input.ageAtFyStart >= 3) return split(mu.ninkagai_cap_3to5, "3〜5歳（月額上限）");
    if (input.residentTaxExempt === true) return split(mu.ninkagai_cap_0to2_nontaxable, "0〜2歳・住民税非課税世帯（月額上限）");
    if (input.residentTaxExempt === false) return split(null, "0〜2歳・住民税課税世帯は国の制度の対象外（自治体独自の上乗せは別）");
    return { status: "unconfirmed" as const, benefit: null, self_pay: null, reason_ja: "0〜2歳は住民税の課税状況が要る（確認できていない）" };
  }
  return { status: "unsupported" as const, benefit: null, self_pay: null, reason_ja: `施設の種類 ${input.facility} は未対応` };
}

/** 副食費の免除（年収360万円未満相当世帯・全ての世帯の第3子以降）。情報が無ければ決めつけない */
export function fukushokuhiExempt(input: { incomeUnder360Equivalent?: boolean; thirdOrLaterChild?: boolean }) {
  if (input?.incomeUnder360Equivalent === true) return { exempt: true, reason_ja: "年収360万円未満相当世帯" };
  if (input?.thirdOrLaterChild === true) return { exempt: true, reason_ja: "第3子以降（数え方は施設の種類と自治体で異なるため自治体の判定を入力）" };
  if (input?.incomeUnder360Equivalent === false && input?.thirdOrLaterChild === false) return { exempt: false, reason_ja: "免除の対象外" };
  return { exempt: null, reason_ja: "所得の区分と第何子かが分からない（確認できていない）" };
}

export interface InvoiceItem { childId: string; kind: "hoikuryo" | "fukushokuhi" | "encho" | "jippi" | "other"; label: string; amount: number; purpose?: string }
export interface InvoiceLine { kind: string; label_ja: string; amount: number; purpose_ja?: string; informational?: boolean }

/** 保護者への請求書（1人の児童・1か月）。実費は使途を明示。上限超過分の自己負担は別行。他の児童の明細は受け付けない */
export function buildGuardianInvoice(input: {
  childId: string; childName: string; guardianName?: string; month: string; items: InvoiceItem[];
  fukushokuhi?: { incomeUnder360Equivalent?: boolean; thirdOrLaterChild?: boolean };
  shisetsuToRiyo?: { fy: string; facility: string; ageAtFyStart: number; hoikuNeedCertified?: boolean; residentTaxExempt?: boolean; receiptMode: "proxy" | "reimbursement" };
}) {
  const err = (reason_ja: string) => ({ status: "error" as const, reason_ja });
  const lines: InvoiceLine[] = [];
  for (const it of input.items || []) {
    if (it.childId !== input.childId) return err("他の児童の明細が混ざっています（請求書を作りません）");
    if (!Number.isInteger(it.amount) || it.amount < 0) return err(`金額が不正: ${it.label}`);
    if (it.kind === "jippi" && !String(it.purpose || "").trim()) return err(`実費「${it.label}」の使途が書かれていません（使途の明示が要ります）`);
    lines.push({ kind: it.kind, label_ja: it.label, amount: it.amount, ...(it.purpose ? { purpose_ja: it.purpose } : {}) });
  }
  const notes: string[] = [];
  const fk = lines.filter((l) => l.kind === "fukushokuhi").reduce((a, l) => a + l.amount, 0);
  if (fk > 0 && input.fukushokuhi) {
    const ex = fukushokuhiExempt(input.fukushokuhi);
    if (ex.exempt === true) lines.push({ kind: "fukushokuhi_exemption", label_ja: `副食費の免除（${ex.reason_ja}）`, amount: -fk });
    else if (ex.exempt === null) notes.push("副食費の免除の判定に要る情報が無い（確認できていない）");
  }
  if (input.shisetsuToRiyo) {
    const fee = lines.filter((l) => l.kind === "hoikuryo").reduce((a, l) => a + l.amount, 0);
    const k = shisetsuToRiyoKyufu({ ...input.shisetsuToRiyo, fee });
    if (k.status !== "ok") return err(`施設等利用給付を計算できません: ${k.reason_ja}`);
    const proxy = input.shisetsuToRiyo.receiptMode === "proxy";
    lines.push({ kind: "shisetsu_to_riyo_kyufu", label_ja: proxy ? "施設等利用給付（法定代理受領）" : "施設等利用給付の見込み（償還払い・後日市町村から）", amount: proxy ? -(k.benefit as number) : -(k.benefit as number), informational: !proxy });
    lines.push({ kind: "over_cap_self_pay", label_ja: `上限（${k.cap ?? 0}円）を超える分の自己負担`, amount: k.self_pay as number, informational: true });
  }
  const total = lines.filter((l) => !l.informational).reduce((a, l) => a + l.amount, 0);
  return { status: "ok" as const, childId: input.childId, childName: input.childName, guardianName: input.guardianName ?? null, month: input.month, lines, total, notes_ja: notes };
}

/**
 * 口座振替のための振替データ（請求書から作る。1請求1件・0円は載せない）。合計は請求書の合計の和と一致させる。
 * 全国銀行協会の預金口座振替の様式（固定長）での書き出しは、様式の一次資料を取り込んでいないため未対応（要一次確認）。
 */
export function buildDebitTransfer(invoices: AnyRec[], opts: { month: string }) {
  const seen = new Set<string>();
  const records: AnyRec[] = [];
  for (const inv of invoices || []) {
    if (!inv || inv.status !== "ok") return { status: "error" as const, reason_ja: "作れていない請求書が混ざっています" };
    if (inv.month !== opts.month) return { status: "error" as const, reason_ja: `月の違う請求書（${inv.month}）が混ざっています` };
    const key = `${inv.childId}|${inv.month}`;
    if (seen.has(key)) return { status: "error" as const, reason_ja: `同じ児童・同じ月の請求が2重です（${inv.childId}）` };
    seen.add(key);
    if (inv.total > 0) records.push({ childId: inv.childId, guardianName: inv.guardianName, amount: inv.total });
  }
  const total = records.reduce((a, r) => a + r.amount, 0);
  const invoiceSum = (invoices || []).reduce((a, r) => a + (r.total || 0), 0);
  if (total !== invoiceSum) return { status: "error" as const, reason_ja: "振替データの合計が請求書の合計と一致しません" };
  return { status: "ok" as const, month: opts.month, count: records.length, total, records, format_note_ja: "全国銀行協会の預金口座振替の固定長様式での書き出しは要一次確認（未対応）。ここでは件数と合計を照合できる明細だけを作ります" };
}

/** 指導監査・実地検査の帳票の必須項目を、自治体の項目表と照合する。項目表が無ければ合格にしない */
export function checkAuditFormItems(form: { formName: string; items: string[] }, municipalityTable: { form: string; required: string[] } | null) {
  if (!municipalityTable || !Array.isArray(municipalityTable.required)) return { status: "unconfirmed" as const, missing: null, reason_ja: "自治体の項目表が渡されていません（確認できていない）" };
  const have = new Set((form.items || []).map((s) => String(s).trim()));
  const missing = municipalityTable.required.filter((r) => !have.has(r));
  return { status: missing.length ? "incomplete" as const : "ok" as const, missing };
}
