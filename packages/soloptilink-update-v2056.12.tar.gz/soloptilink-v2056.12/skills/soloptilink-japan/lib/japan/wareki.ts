/**
 * 和暦変換ユーティリティ
 * 令和/平成/昭和/大正/明治 ⇔ 西暦の相互変換と書式化
 *
 * ★2026-09-30 是正 (REQ-JPO-FIX-008・REQ-JPO-FIX-015):
 *   - 旧実装は端末の現地時刻 (getFullYear/getMonth/getDate) で日付を読み、協定世界時のサーバーでは
 *     日本時間 2019-05-01 0:00 を「平成31年4月30日」と返していた。いまは日本時間の暦日で決める。
 *   - 旧 toSeireki は「令和元年4月1日」「平成32年」「令和6年2月30日」をそのまま西暦に直していた。いまは例外にする。
 *     改元後の旧元号 (平成31年5月1日〜12月31日・昭和64年1月8日〜) は改元の年の中だけ受理し、
 *     toSeirekiChecked の warnings で注意を返す (受理か拒否かの最終判断は士業の確認待ち・要確認)。
 *   元号の表と変換の規則は正本 calendar/jp_calendar.ts (元号を改める政令2本を e-Gov で確認) にだけある。
 */

import {
  JP_ERAS,
  getJpEras,
  addJpEra,
  setJpEraTable,
  resetJpEraTable,
  replaceEraLigatures,
  formatWarekiJst,
  toWarekiJst,
  warekiToSeireki,
  parseWareki as parseWarekiText,
  toJstYmd,
  ymdToCalendarDate,
  JpCalendarError,
  type SeirekiResult,
} from './calendar/jp_calendar';

export type { SeirekiResult };

// 元号表の差し替え (REQ-JPO-CAL-005)・合字の直し (REQ-JPO-CAL-004) は正本の関数をそのまま出す
export { getJpEras as getEras, addJpEra as addEra, setJpEraTable as setEraTable, resetJpEraTable as resetEraTable, replaceEraLigatures };

export interface WarekiDate {
  era: string;
  eraShort: string;
  year: number;
  month: number;
  day: number;
}

/** 既定の元号の表 (正本の参照)。元号を足した後の表は getEras() で読む */
export const ERAS = JP_ERAS;

/**
 * 西暦 → 和暦 (日本時間の暦日で決める。'YYYY-MM-DD' の文字列はその暦日)
 */
export function toWareki(date: Date | string): WarekiDate {
  return toWarekiJst(date);
}

/**
 * 和暦 → 西暦 (検査つき・例外を投げない版)。ymd は 'YYYY-MM-DD'。
 */
export function toSeirekiChecked(wareki: Omit<WarekiDate, 'eraShort'>): SeirekiResult {
  return warekiToSeireki(wareki.era, wareki.year, wareki.month, wareki.day);
}

/**
 * 和暦 → 西暦の暦日 'YYYY-MM-DD'。実在しない和暦は例外。
 */
export function toSeirekiYmd(wareki: Omit<WarekiDate, 'eraShort'>): string {
  const r = toSeirekiChecked(wareki);
  if (!r.ok || !r.ymd) throw new JpCalendarError(r.error ?? '和暦を西暦に直せません');
  return r.ymd;
}

/**
 * 和暦 → 西暦。返す Date は「その暦日の協定世界時 0 時 (日本時間 9 時)」。日本時間でも協定世界時でも同じ暦日に読める。
 * 実在しない和暦 (令和元年4月1日・平成32年・2月30日など) は例外。
 */
export function toSeireki(wareki: Omit<WarekiDate, 'eraShort'>): Date {
  return ymdToCalendarDate(toSeirekiYmd(wareki));
}

/**
 * 和暦の文字列を読む (「令和6年1月1日」「令和６年１月１日」「R6.1.1」「H31.4.30」)。例外を投げない。
 */
export function parseWareki(text: string): SeirekiResult {
  return parseWarekiText(text);
}

/**
 * 和暦フォーマット (令和6年4月21日 / R6.4.21 / R06-04-21 / R06.04.21)
 * ※'iso' の区切り (JIS X 0301 はピリオド区切りとされる) は規格票の本文を確認するまで従来のまま (要一次確認)。
 * ※帳票・CSV の2桁ピリオド区切り (R08.09.29) は 'dotted' (2026-10-03 追加・REQ-JPO-CAL-004)。元号の合字は出さない。
 */
export function formatWareki(
  date: Date | string,
  format: 'long' | 'short' | 'iso' | 'ja_full' | 'dotted' = 'ja_full'
): string {
  const w = toWareki(date);
  const y = w.year === 1 ? '元' : String(w.year);
  switch (format) {
    case 'long':
    case 'short':
    case 'dotted':
      return formatWarekiJst(date, format);
    case 'iso':
      return `${w.eraShort}${String(w.year).padStart(2, '0')}-${String(w.month).padStart(2, '0')}-${String(w.day).padStart(2, '0')}`;
    case 'ja_full':
    default:
      return `${w.era}${y}年${w.month}月${w.day}日 (${toJstYmd(date).slice(0, 4)}年)`;
  }
}

/**
 * 和暦・西暦の併記 (帳票用)
 */
export function formatBoth(date: Date | string): string {
  const w = toWareki(date);
  const y = w.year === 1 ? '元' : String(w.year);
  const [sy, sm, sd] = toJstYmd(date).split('-').map(Number);
  return `${sy}年${sm}月${sd}日 (${w.era}${y}年)`;
}
