/**
 * 手形の最終振出・電子交換所の交換廃止への移行と、でんさい (電子記録債権) の満期の検査 — 値と判定の置き場
 *
 * ★2026-10-03 新設 (REQ-JPO-MNY-012・T08)。手形・でんさいの日付の値は【この値表 PROMISSORY_NOTE_VALUES だけ】に置く。
 *
 * 【出典 — 一次情報 (2026-10-03 に本文を開いて確認)】
 *   - 全国銀行協会「電子交換所の交換廃止時期の決定および手形・小切手交換廃止時期の明確化について」(2026-06-18)
 *       https://www.zenginkyo.or.jp/news/2026/n061802/
 *       電子交換所における手形・小切手の交換廃止時期を「2027年3月31日」と明確化。
 *       「2027年4月1日から手形・小切手が使用できなくなるものではありません。ただし、2027年4月1日からは電子交換所を
 *        介さない決済となることから、各金融機関において郵送等による相対決済を行う必要があるため、金融機関の判断により、
 *        手形・小切手の取扱い可否等が変更となる可能性があります。」
 *       → 画面では「使えなくなる」と断定しない。
 *   - 手形法 (e-Gov 307AC0000000020) 第38条1項: 支払をなすべき日又はこれに次ぐ二取引日内に呈示。
 *       第72条: 満期が法定の休日なら次の取引日。第77条1項3号・9号で約束手形へ準用。
 *   - 取適法 (e-Gov 331AC0000000120) 第5条1項2号: 手形の交付は支払遅延に含む。
 *   - 公取委 取適法Q&A Q80: 満期日が支払期日より後の電子記録債権は、割引料を委託側が負担しても通常は違反。
 *       支払期日に満額の現金を受け取れることが確保されていれば問題としない。
 *
 * 【要一次確認として残したもの】
 *   - 多くの金融機関の最終振出期限 2026-09-30 は要件 (REQ-JPO-MNY-012) の値。最終振出期限は金融機関ごとに異なるため
 *     bankLastIssueDate で取引銀行の期限に差し替えられる。各金融機関の案内での確認が要る。
 *   - 2027-04-01 以降の振出データを作らないのは当社システムの方針 (要件の値)。法律上手形が無効になるわけではない。
 *   - 取引日 (手形法の「取引日」) は銀行の休業日 (土日・祝日・12/31〜1/3) で近似する (手形法第87条・政令の休日)。
 */
import { toYmd, dayNumber, type Ymd } from './toriteki';
import { isJpBusinessDay, addJpBusinessDays, onOrAfterJpBusinessDay } from './calendar/jp_calendar';

// ===========================================================================
// 値表 (日付はここだけに置く)
// ===========================================================================
export const PROMISSORY_NOTE_VALUES = {
  /** 電子交換所での手形・小切手の交換廃止時期 (全銀協 2026-06-18) */
  exchange_abolition_date: '2027-03-31',
  /** 電子交換所を介さない決済となる最初の日 (全銀協 2026-06-18) */
  first_day_without_exchange: '2027-04-01',
  /** 多くの金融機関の最終振出期限 (要件の値・取引銀行ごとに設定。要一次確認) */
  default_last_issue_date: '2026-09-30',
  /** 当社システムの方針: この日以降の振出データは作らない (要件の値) */
  refuse_issue_from: '2027-04-01',
  /** 手形法第38条1項: 支払をなすべき日に次ぐ取引日の数 */
  presentment_following_business_days: 2,
  sources: [
    '全国銀行協会 2026-06-18「電子交換所の交換廃止時期の決定および手形・小切手交換廃止時期の明確化について」',
    '手形法 第38条1項・第72条・第77条1項3号・9号',
    '取適法 第5条1項2号・公取委 取適法Q&A Q80',
  ],
} as const;

const BANK = { closedDays: 'bank' as const };
const lt = (a: Ymd, b: Ymd) => a < b;

/** 交換廃止についての画面の案内 (断定しない言い方の正本) */
export const PROMISSORY_NOTE_NOTICE_JA =
  `電子交換所での手形・小切手の交換は ${PROMISSORY_NOTE_VALUES.exchange_abolition_date} (2027年3月31日) で廃止されます (全国銀行協会 2026-06-18)。` +
  `${PROMISSORY_NOTE_VALUES.first_day_without_exchange} 以降も手形がただちに使えなくなるものではありませんが、電子交換所を介さない個別の決済となり、` +
  '取扱いは金融機関の判断で変わる可能性があります。振込またはでんさいへの切替えをおすすめします。';

// ===========================================================================
// 振出の検査
// ===========================================================================
export type NoteIssueVerdict = 'ok' | 'warning' | 'refused';
export function checkPromissoryNoteIssue(input: {
  issueDate: Date | string;
  maturityDate?: Date | string;
  /** 取引銀行の最終振出期限 (既定 2026-09-30・要一次確認) */
  bankLastIssueDate?: Date | string;
  /** 取適法の対象取引か (手形の交付そのものが支払遅延に当たる) */
  toritekiApplies?: boolean;
}): { verdict: NoteIssueVerdict; canCreate: boolean; reasons: string[]; notices: string[] } {
  const V = PROMISSORY_NOTE_VALUES;
  const issue = toYmd(input.issueDate);
  const lastIssue = input.bankLastIssueDate ? toYmd(input.bankLastIssueDate) : V.default_last_issue_date;
  const reasons: string[] = [];
  const notices = [PROMISSORY_NOTE_NOTICE_JA];
  if (input.toritekiApplies) {
    reasons.push('取適法の対象取引では、代金の支払に手形を交付すること自体が支払遅延に当たります (取適法 第5条1項2号)。振込で支払期日までに満額を支払ってください。');
    return { verdict: 'refused', canCreate: false, reasons, notices };
  }
  if (!lt(issue, V.refuse_issue_from)) {
    reasons.push(`振出日 ${issue} は ${V.refuse_issue_from} 以降のため、手形の振出データは作成しません (電子交換所の交換廃止 ${V.exchange_abolition_date} の後)。振込またはでんさいで支払ってください。`);
    return { verdict: 'refused', canCreate: false, reasons, notices };
  }
  let verdict: NoteIssueVerdict = 'ok';
  if (lt(lastIssue, issue)) {
    verdict = 'warning';
    reasons.push(`振出日 ${issue} は取引銀行の最終振出期限 (${lastIssue}${input.bankLastIssueDate ? '' : '・多くの金融機関の期限。取引銀行の案内で確認してください'}) より後です。支払を受けられない可能性があるため、振込またはでんさいへの切替えを検討してください。`);
  }
  if (input.maturityDate) {
    const c = classifyNoteMaturity(input.maturityDate);
    if (c.category !== 'before_abolition') {
      verdict = 'warning';
      reasons.push(c.reason_ja);
    }
  }
  return { verdict, canCreate: true, reasons, notices };
}

// ===========================================================================
// 満期の分類
// ===========================================================================
export type NoteMaturityCategory = 'before_abolition' | 'presentment_crosses_abolition' | 'after_abolition';
/**
 * 満期日を交換廃止日と比べて分類する。
 *  - after_abolition: 満期が 2027-04-01 以降 (電子交換所を介さない決済になる)
 *  - presentment_crosses_abolition: 満期は 3/31 以前だが、呈示期間 (支払をなすべき日と次の2取引日) が 4/1 以降にかかる
 *  - before_abolition: 呈示期間の終わりまで 3/31 以前
 */
export function classifyNoteMaturity(maturityDate: Date | string): {
  category: NoteMaturityCategory; maturity: Ymd; presentmentLastDay: Ymd; reason_ja: string;
} {
  const V = PROMISSORY_NOTE_VALUES;
  const maturity = toYmd(maturityDate);
  const payDay = onOrAfterJpBusinessDay(maturity, BANK); // 第72条
  const presentmentLastDay = addJpBusinessDays(payDay, V.presentment_following_business_days, BANK); // 第38条1項
  if (!lt(maturity, V.first_day_without_exchange)) {
    return { category: 'after_abolition', maturity, presentmentLastDay,
      reason_ja: `満期 ${maturity} は交換廃止 (${V.exchange_abolition_date}) の後です。電子交換所を介さない決済になり、取扱いは金融機関の判断で変わる可能性があります。振込またはでんさいへの切替えを検討してください。` };
  }
  if (!lt(presentmentLastDay, V.first_day_without_exchange)) {
    return { category: 'presentment_crosses_abolition', maturity, presentmentLastDay,
      reason_ja: `満期 ${maturity} の呈示期間 (${presentmentLastDay} まで・手形法第38条) が交換廃止 (${V.exchange_abolition_date}) の後にかかります。満期日に呈示できるよう取引銀行と確認するか、振込への切替えを検討してください。` };
  }
  return { category: 'before_abolition', maturity, presentmentLastDay, reason_ja: '' };
}

export interface NoteRecord {
  id: string;
  maturityDate: Date | string;
  amountYen: number;
  issueDate?: Date | string;
  counterparty?: string;
  /** outstanding=未決済 (既定) / settled=決済済み / migrated=振込・でんさいへ切替済み */
  status?: 'outstanding' | 'settled' | 'migrated';
}
/** 期日が交換廃止日以降の手形 (呈示期間が廃止後にかかるものを含む) を全件一覧にする */
export function listNotesMaturingAfterAbolition(notes: NoteRecord[]): {
  items: Array<NoteRecord & { maturityDate: Ymd; category: NoteMaturityCategory; reason_ja: string }>; count: number; totalYen: number;
} {
  const items: Array<NoteRecord & { maturityDate: Ymd; category: NoteMaturityCategory; reason_ja: string }> = [];
  for (const n of notes) {
    if (n.status === 'settled' || n.status === 'migrated') continue;
    const c = classifyNoteMaturity(n.maturityDate);
    if (c.category !== 'before_abolition') items.push({ ...n, maturityDate: c.maturity, category: c.category, reason_ja: c.reason_ja });
  }
  items.sort((a, b) => (a.maturityDate < b.maturityDate ? -1 : a.maturityDate > b.maturityDate ? 1 : 0));
  return { items, count: items.length, totalYen: items.reduce((s, x) => s + (Number(x.amountYen) || 0), 0) };
}

/** 2027年3月末までに期日が来ない手形残高 (移行の残り)。count=0 で移行完了 */
export function noteMigrationStatus(notes: NoteRecord[]): {
  cutoff: Ymd; outstandingAfterCutoff: NoteRecord[]; count: number; totalYen: number; ready: boolean; message_ja: string;
} {
  const cutoff = PROMISSORY_NOTE_VALUES.exchange_abolition_date;
  const out = notes.filter((n) => (n.status ?? 'outstanding') === 'outstanding' && toYmd(n.maturityDate) > cutoff);
  const totalYen = out.reduce((s, x) => s + (Number(x.amountYen) || 0), 0);
  return {
    cutoff, outstandingAfterCutoff: out, count: out.length, totalYen, ready: out.length === 0,
    message_ja: out.length === 0
      ? `${cutoff} までに期日が来ない手形の残高はありません。`
      : `${cutoff} までに期日が来ない手形が ${out.length} 件 (合計 ${totalYen.toLocaleString('ja-JP')} 円) 残っています。振込またはでんさいへの切替えを取引先と協議してください。`,
  };
}

// ===========================================================================
// でんさい (電子記録債権) の満期と支払期日 (Q80)
// ===========================================================================
export function checkDensaiMaturity(input: {
  maturityDate: Date | string;
  paymentDueDate: Date | string;
  toritekiApplies?: boolean;
  /** 支払期日に割引なしで満額の現金を受け取れることが確保されているか (Q80 後段) */
  cashableAtFullAmountByDueDate?: boolean;
}): { verdict: 'ok' | 'warning' | 'violation'; exceedsDueDate: boolean; daysOver: number; reasons: string[] } {
  const m = toYmd(input.maturityDate);
  const due = toYmd(input.paymentDueDate);
  if (m <= due) return { verdict: 'ok', exceedsDueDate: false, daysOver: 0, reasons: [] };
  const daysOver = dayNumber(due, m) - 1;
  if (input.toritekiApplies && input.cashableAtFullAmountByDueDate !== true) {
    return { verdict: 'violation', exceedsDueDate: true, daysOver, reasons: [
      `でんさいの満期 ${m} が支払期日 ${due} より ${daysOver} 日後です。取適法の対象取引では、割引料を委託側が負担しても通常は支払遅延に当たります (取適法 第5条1項2号・公取委Q&A Q80)。満期を支払期日以内にしてください。`,
    ] };
  }
  return { verdict: 'warning', exceedsDueDate: true, daysOver, reasons: [
    input.toritekiApplies
      ? `でんさいの満期 ${m} が支払期日 ${due} より ${daysOver} 日後です。支払期日に満額の現金を受け取れる確保があるとの入力のため違反とはしませんが、その確保の内容を記録してください (公取委Q&A Q80)。`
      : `でんさいの満期 ${m} が支払期日 ${due} より ${daysOver} 日後です。取引先との約定を確認してください。`,
  ] };
}

/** 手形を振込・でんさいへ置き換える案 (振込日・でんさいの満期とも支払期日を超えない) */
export function proposeNoteReplacement(note: NoteRecord, opts: { paymentDueDate?: Date | string } = {}): {
  transferDate: Ymd; densaiMaturityDate: Ymd; reason_ja: string;
} {
  const maturity = toYmd(note.maturityDate);
  const due = opts.paymentDueDate ? toYmd(opts.paymentDueDate) : maturity;
  const target = due < maturity ? due : maturity;
  // 休業日なら前の営業日 (支払期日を超えない側)
  const transferDate = isJpBusinessDay(target, BANK) ? target : addJpBusinessDays(target, -1, BANK);
  return {
    transferDate,
    densaiMaturityDate: transferDate,
    reason_ja: `手形 ${note.id} (満期 ${maturity}) は、振込なら ${transferDate} までに、でんさいなら満期 ${transferDate} 以内で発生記録をすると、支払期日 ${due} を超えません。`,
  };
}
