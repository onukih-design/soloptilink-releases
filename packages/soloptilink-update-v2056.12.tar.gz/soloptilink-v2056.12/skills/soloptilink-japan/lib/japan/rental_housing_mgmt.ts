/**
 * rental_housing_mgmt.ts — 賃貸住宅管理業法 (賃貸住宅の管理業務等の適正化に関する法律) の点検部品
 *
 *   - 登録の要否 (管理戸数 200 戸以上) と 5 年ごとの更新 (満了の N か月前の警告・更新申請期間)
 *   - 営業所・事務所ごとの業務管理者の充足 (欠けた営業所では新規の管理受託契約を締結させない)
 *   - 令和7年度 全国立入検査で是正指導があった条項 11 類型の欠落検出
 *     (13・14・16・17・18・19・20・28・30・31・32 条)
 *
 * 【出典 — 一次情報 (e-Gov 法令API v2 で 2026-10-03 取得)】
 *   賃貸住宅の管理業務等の適正化に関する法律 (502AC0000000060・2025-06-01 施行版)
 *     3条1項・2項・3項 (登録・5年ごとの更新・処分待ちの間の効力) / 12条1項〜3項 (業務管理者) /
 *     13条・14条・16条〜20条・28条・30条〜32条
 *   同法施行規則 (502M60000800083・2024-05-27 施行版)
 *     3条 (登録が要る規模=賃貸住宅の戸数 200 戸) / 4条 (更新申請は満了日の 90 日前から 30 日前まで) /
 *     31条 (13条書面の説明事項 11 号) / 35条 (14条書面の記載事項) / 36条 (分別管理) / 37条 (証明書) /
 *     38条 (帳簿の記載事項 6 号・閉鎖後 5 年保存) / 39条 (標識) / 40条 (定期報告: 1 年を超えない期間ごと) /
 *     42条 (誇大広告をしてはならない事項) / 45条 (30条書面の説明事項 14 号) / 47条 (31条書面の記載事項) / 48条 (書類の閲覧)
 *   国土交通省「賃貸住宅管理業者等への全国立入検査結果 (令和7年度)【詳細版】」2026-06-05
 *     https://www.mlit.go.jp/report/press/content/002004977.pdf (条項別の是正指導件数。調査報告 G09 からの引用。本作業では未取得)
 *
 * ★登録の有効期間の満了日は「登録日の 5 年後の応当日の前日」として計算する (3条2項。要確認: 登録通知書の記載)。
 *   登録通知書に満了日が書かれているときは expiresOn を渡せばそれを優先する。
 * ★誇大広告 (28条) の判定は、広告に「家賃保証」等をうたいながら家賃の変更 (減額) の条件を表示していないものを機械で拾う。
 *   表示の適否の最終判断は人 (宅地建物取引士・弁護士) が行う (要確認)。
 */

// ===== 登録 =====

/** 登録が要る規模 (施行規則3条: 賃貸住宅の戸数 200 戸)。これ未満は登録義務なし (法3条1項ただし書) */
export const RENTAL_MGMT_REGISTRATION_THRESHOLD_UNITS = 200;
/** 登録の有効期間 (年)。法3条2項 */
export const RENTAL_MGMT_REGISTRATION_VALID_YEARS = 5;
/** 更新申請の期間: 満了日の 90 日前から 30 日前まで (施行規則4条) */
export const RENTAL_MGMT_RENEWAL_WINDOW_DAYS = { from: 90, to: 30 } as const;

/** 管理戸数から登録の要否を返す (200 戸以上で登録が要る) */
export function rentalMgmtRegistrationRequired(managedUnits: number): boolean {
  return managedUnits >= RENTAL_MGMT_REGISTRATION_THRESHOLD_UNITS;
}

const ymdToUtc = (s: string) => { const [y, m, d] = String(s).slice(0, 10).split('-').map(Number); return Date.UTC(y, m - 1, d); };
const utcToYmd = (t: number) => new Date(t).toISOString().slice(0, 10);
const addDaysYmd = (s: string, n: number) => utcToYmd(ymdToUtc(s) + n * 86400000);
/** n か月後の応当日 (応当日が無い月は末日) */
function addMonthsYmd(s: string, n: number): string {
  const [y, m, d] = String(s).slice(0, 10).split('-').map(Number);
  const total = (y * 12 + (m - 1)) + n;
  const ty = Math.floor(total / 12);
  const tm = total % 12;
  const last = new Date(Date.UTC(ty, tm + 1, 0)).getUTCDate();
  return utcToYmd(Date.UTC(ty, tm, Math.min(d, last)));
}

export interface RentalMgmtRegistration {
  /** 登録年月日 (YYYY-MM-DD) */
  registeredOn: string;
  /** 登録通知書に記載の有効期間の満了日。あればこれを優先する */
  expiresOn?: string;
  /** 更新の申請をした日 */
  renewalAppliedOn?: string;
  /** 更新申請に対する処分がまだ無いか */
  renewalPending?: boolean;
}

/**
 * 登録の有効期間の状態を返す。
 * @param warnMonths 満了日の何か月前から警告するか (設定値。必須)
 */
export function rentalMgmtRegistrationStatus(reg: RentalMgmtRegistration, asOf: string, warnMonths: number): {
  expiresOn: string;
  warnFrom: string;
  renewalWindow: { from: string; to: string };
  state: 'valid' | 'warning' | 'renewal_window' | 'renewal_window_closed' | 'expired' | 'extended_pending_decision';
  message: string;
} {
  if (!(typeof warnMonths === 'number' && warnMonths >= 0 && Number.isFinite(warnMonths))) {
    throw new Error('警告を出す月数 (warnMonths) を設定してください');
  }
  const expiresOn = reg.expiresOn ? String(reg.expiresOn).slice(0, 10) : addDaysYmd(addMonthsYmd(reg.registeredOn, RENTAL_MGMT_REGISTRATION_VALID_YEARS * 12), -1);
  const warnFrom = addMonthsYmd(expiresOn, -warnMonths);
  const renewalWindow = { from: addDaysYmd(expiresOn, -RENTAL_MGMT_RENEWAL_WINDOW_DAYS.from), to: addDaysYmd(expiresOn, -RENTAL_MGMT_RENEWAL_WINDOW_DAYS.to) };
  const d = String(asOf).slice(0, 10);
  const applied = reg.renewalAppliedOn ? String(reg.renewalAppliedOn).slice(0, 10) : null;
  if (d > expiresOn) {
    if (applied && applied <= expiresOn && reg.renewalPending) {
      return { expiresOn, warnFrom, renewalWindow, state: 'extended_pending_decision', message: `有効期間は ${expiresOn} に満了しましたが、満了日までに更新を申請しており処分待ちのため、処分があるまで従前の登録が有効です (法3条3項)` };
    }
    return { expiresOn, warnFrom, renewalWindow, state: 'expired', message: `登録の有効期間が ${expiresOn} に満了し、登録は効力を失っています (法3条2項)。管理業務を続けるには新規の登録が要ります` };
  }
  if (applied) return { expiresOn, warnFrom, renewalWindow, state: 'valid', message: `更新を ${applied} に申請済みです (満了日 ${expiresOn})` };
  if (d > renewalWindow.to) return { expiresOn, warnFrom, renewalWindow, state: 'renewal_window_closed', message: `更新申請の期間 (${renewalWindow.from}〜${renewalWindow.to}) を過ぎています。満了日 ${expiresOn} までに地方整備局へ相談してください (施行規則4条)` };
  if (d >= renewalWindow.from) return { expiresOn, warnFrom, renewalWindow, state: 'renewal_window', message: `更新申請の期間中です (${renewalWindow.from}〜${renewalWindow.to}・満了日 ${expiresOn})` };
  if (d >= warnFrom) return { expiresOn, warnFrom, renewalWindow, state: 'warning', message: `登録の有効期間の満了日 ${expiresOn} まで ${warnMonths} か月を切りました。更新申請は ${renewalWindow.from} から ${renewalWindow.to} までです` };
  return { expiresOn, warnFrom, renewalWindow, state: 'valid', message: `登録は有効です (満了日 ${expiresOn})` };
}

// ===== 業務管理者 (12条) =====

export interface BusinessManager {
  name: string;
  /** 6条1項1号〜7号 (欠格事由) のいずれかに該当するか */
  disqualified?: boolean;
  /** 他の営業所・事務所の業務管理者を兼ねているか (12条3項で不可) */
  alsoAssignedToOtherOffice?: boolean;
  /** 解任・退職などで既にいない */
  resigned?: boolean;
}

/**
 * その営業所・事務所で新規の管理受託契約を締結してよいかを返す。
 *   業務管理者の全員が欠格事由に該当し、又は全員が欠けたときは、新たに選任するまで管理受託契約を締結してはならない (12条2項)。
 *   他の営業所の業務管理者を兼ねる者は数えない (12条3項)。
 */
export function canConcludeManagementContract(office: { id: string; businessManagers: BusinessManager[] }): { allowed: boolean; validManagers: number; reason: string } {
  const valid = (office.businessManagers ?? []).filter((m) => m && m.name && !m.disqualified && !m.resigned && !m.alsoAssignedToOtherOffice);
  if (valid.length === 0) {
    return { allowed: false, validManagers: 0, reason: `営業所 ${office.id} に有効な業務管理者が1人もいないため、新規の管理受託契約は締結できません。業務管理者を選任してください (賃貸住宅管理業法12条1項・2項)` };
  }
  return { allowed: true, validManagers: valid.length, reason: `業務管理者 ${valid.length} 名を選任済みです` };
}

// ===== 法定記載事項・備付け義務の欠落 (立入検査の指摘 11 類型) =====

/** 13条書面 (管理受託契約の締結前の説明) の説明事項 — 施行規則31条1号〜11号 */
export const MGMT_PRE_CONTRACT_ITEMS_13 = [
  { code: 'registration', label: '商号・名称又は氏名並びに登録年月日及び登録番号', basis: '施行規則31条1号' },
  { code: 'property', label: '管理業務の対象となる賃貸住宅', basis: '施行規則31条2号' },
  { code: 'services', label: '管理業務の内容及び実施方法', basis: '施行規則31条3号' },
  { code: 'fee', label: '報酬の額並びにその支払の時期及び方法', basis: '施行規則31条4号' },
  { code: 'extra_costs', label: '報酬に含まれていない管理業務の費用で通常必要とするもの', basis: '施行規則31条5号' },
  { code: 'subcontract', label: '管理業務の一部の再委託に関する事項', basis: '施行規則31条6号' },
  { code: 'liability', label: '責任及び免責に関する事項', basis: '施行規則31条7号' },
  { code: 'periodic_report', label: '委託者への報告 (法20条) に関する事項', basis: '施行規則31条8号' },
  { code: 'term', label: '契約期間に関する事項', basis: '施行規則31条9号' },
  { code: 'tenant_notice', label: '入居者に対する管理業務の内容・実施方法の周知に関する事項', basis: '施行規則31条10号' },
  { code: 'renewal_termination', label: '管理受託契約の更新及び解除に関する事項', basis: '施行規則31条11号' },
] as const;

/** 14条書面 (管理受託契約の締結時の書面) の記載事項 — 法14条1項1号〜5号・施行規則35条。conditional=「定めがあるときは」 */
export const MGMT_CONTRACT_ITEMS_14 = [
  { code: 'property', label: '管理業務の対象となる賃貸住宅', basis: '法14条1項1号', conditional: false },
  { code: 'method', label: '管理業務の実施方法', basis: '法14条1項2号', conditional: false },
  { code: 'term', label: '契約期間に関する事項', basis: '法14条1項3号', conditional: false },
  { code: 'fee', label: '報酬の額並びにその支払の時期及び方法', basis: '法14条1項4号・施行規則35条1項', conditional: false },
  { code: 'renewal_termination', label: '契約の更新又は解除に関する定めの内容', basis: '法14条1項5号', conditional: true },
  { code: 'registration', label: '商号・名称又は氏名並びに登録年月日及び登録番号', basis: '施行規則35条2項1号', conditional: false },
  { code: 'services', label: '管理業務の内容', basis: '施行規則35条2項2号', conditional: false },
  { code: 'subcontract', label: '管理業務の一部の再委託に関する定めの内容', basis: '施行規則35条2項3号', conditional: true },
  { code: 'liability', label: '責任及び免責に関する定めの内容', basis: '施行規則35条2項4号', conditional: true },
  { code: 'periodic_report', label: '委託者への報告 (法20条) に関する事項', basis: '施行規則35条2項5号', conditional: false },
  { code: 'tenant_notice', label: '入居者に対する周知に関する事項', basis: '施行規則35条2項6号', conditional: false },
] as const;

/** 帳簿 (18条) の記載事項 — 施行規則38条1項 */
export const MGMT_LEDGER_ITEMS_18 = [
  { code: 'client_name', label: '委託者の商号・名称又は氏名', basis: '施行規則38条1項1号' },
  { code: 'contract_date', label: '管理受託契約を締結した年月日', basis: '施行規則38条1項2号' },
  { code: 'property', label: '契約の対象となる賃貸住宅', basis: '施行規則38条1項3号' },
  { code: 'services', label: '受託した管理業務の内容', basis: '施行規則38条1項4号' },
  { code: 'fee', label: '報酬の額', basis: '施行規則38条1項5号' },
  { code: 'special_terms', label: '特約その他参考となる事項', basis: '施行規則38条1項6号' },
] as const;
/** 帳簿の保存年数 (閉鎖後 5 年。施行規則38条3項) */
export const MGMT_LEDGER_RETENTION_YEARS = 5;

/** 定期報告 (20条) の記載事項 — 施行規則40条1項 */
export const MGMT_REPORT_ITEMS_20 = [
  { code: 'period', label: '報告の対象となる期間', basis: '施行規則40条1項1号' },
  { code: 'status', label: '管理業務の実施状況', basis: '施行規則40条1項2号' },
  { code: 'complaints', label: '入居者からの苦情の発生状況及び対応状況', basis: '施行規則40条1項3号' },
] as const;

/** 30条書面 (特定賃貸借契約の締結前の説明) の説明事項 — 施行規則45条1号〜14号 */
export const SUBLEASE_PRE_CONTRACT_ITEMS_30 = [
  { code: 'operator', label: '特定転貸事業者の商号・名称又は氏名及び住所', basis: '施行規則45条1号' },
  { code: 'property', label: '対象となる賃貸住宅', basis: '施行規則45条2号' },
  { code: 'rent_terms', label: '家賃の額・支払期日・支払方法等の賃貸の条件並びにその変更に関する事項', basis: '施行規則45条3号' },
  { code: 'maintenance_method', label: '維持保全の実施方法', basis: '施行規則45条4号' },
  { code: 'maintenance_cost', label: '維持保全に要する費用の分担に関する事項', basis: '施行規則45条5号' },
  { code: 'maintenance_report', label: '相手方に対する維持保全の実施状況の報告に関する事項', basis: '施行規則45条6号' },
  { code: 'damages', label: '損害賠償額の予定又は違約金に関する事項', basis: '施行規則45条7号' },
  { code: 'liability', label: '責任及び免責に関する事項', basis: '施行規則45条8号' },
  { code: 'term', label: '契約期間に関する事項', basis: '施行規則45条9号' },
  { code: 'sublet_terms', label: '転借人の資格その他の転貸の条件に関する事項', basis: '施行規則45条10号' },
  { code: 'sublessee_notice', label: '転借人に対する維持保全の実施方法の周知に関する事項', basis: '施行規則45条11号' },
  { code: 'renewal_termination', label: '更新及び解除に関する事項', basis: '施行規則45条12号' },
  { code: 'succession', label: '契約終了時の権利義務の承継に関する事項', basis: '施行規則45条13号' },
  { code: 'law_summary', label: '借地借家法その他の法令に関する事項の概要', basis: '施行規則45条14号' },
] as const;

/** 31条書面 (特定賃貸借契約の締結時の書面) の記載事項 — 法31条1項1号〜6号・施行規則47条 */
export const SUBLEASE_CONTRACT_ITEMS_31 = [
  { code: 'property', label: '対象となる賃貸住宅', basis: '法31条1項1号', conditional: false },
  { code: 'rent_terms', label: '相手方に支払う家賃その他賃貸の条件に関する事項', basis: '法31条1項2号', conditional: false },
  { code: 'maintenance_method', label: '維持保全の実施方法', basis: '法31条1項3号', conditional: false },
  { code: 'term', label: '契約期間に関する事項', basis: '法31条1項4号', conditional: false },
  { code: 'sublet_terms', label: '転借人の資格その他の転貸の条件に関する事項', basis: '法31条1項5号', conditional: false },
  { code: 'renewal_termination', label: '契約の更新又は解除に関する定めの内容', basis: '法31条1項6号', conditional: true },
  { code: 'operator', label: '特定転貸事業者の商号・名称又は氏名及び住所', basis: '施行規則47条1号', conditional: false },
  { code: 'maintenance_cost', label: '維持保全に要する費用の分担に関する事項', basis: '施行規則47条2号', conditional: false },
  { code: 'maintenance_report', label: '維持保全の実施状況の報告に関する事項', basis: '施行規則47条3号', conditional: false },
  { code: 'damages', label: '損害賠償額の予定又は違約金に関する定めの内容', basis: '施行規則47条4号', conditional: true },
  { code: 'liability', label: '責任及び免責に関する定めの内容', basis: '施行規則47条5号', conditional: true },
  { code: 'sublessee_notice', label: '転借人に対する維持保全の実施方法の周知に関する事項', basis: '施行規則47条6号', conditional: false },
  { code: 'succession', label: '契約終了時の権利義務の承継に関する事項', basis: '施行規則47条7号', conditional: false },
] as const;

/** 立入検査で是正指導があった条項 (令和7年度 全国立入検査) */
export const RENTAL_MGMT_INSPECTION_ARTICLES = [13, 14, 16, 17, 18, 19, 20, 28, 30, 31, 32] as const;
export type RentalMgmtArticle = typeof RENTAL_MGMT_INSPECTION_ARTICLES[number];

/** 項目ごとの記載有無。conditional の項目は、定めがある (has_<code> が true) ときだけ必須 */
export type ItemPresence = Record<string, boolean>;

export interface RentalMgmtRecord {
  /** 判定の基準日 */
  asOf: string;
  /** 13条: 管理受託契約の締結前の書面 */
  preContract13?: { items: ItemPresence; deliveredBeforeContract: boolean; clientIsProfessional?: boolean }[];
  /** 14条: 締結時の書面。provisions は「定めがある」項目 (renewal_termination / subcontract / liability) */
  contractDoc14?: { items: ItemPresence; provisions?: Record<string, boolean>; delivered: boolean }[];
  /** 16条: 分別管理 */
  segregation16?: { separateAccount: boolean; identifiablePerContract: boolean };
  /** 17条: 従業者の証明書 */
  employees17?: { name: string; carriesCertificate: boolean }[];
  /** 18条: 営業所ごとの帳簿 */
  ledgers18?: { officeId: string; kept: boolean; entries: { items: ItemPresence }[]; retentionYearsAfterClose?: number }[];
  /** 19条: 営業所ごとの標識 */
  signs19?: { officeId: string; posted: boolean }[];
  /** 20条: 委託者への定期報告 */
  reports20?: { contractId: string; contractedOn: string; endedOn?: string; reports: { deliveredOn: string; items: ItemPresence }[] }[];
  /** 28条: 特定賃貸借の勧誘の広告 */
  ads28?: { id: string; mentionsRentGuarantee: boolean; statesRentRevisionConditions: boolean; statesTerminationConditions?: boolean }[];
  /** 30条: 特定賃貸借契約の締結前の書面 (変更契約も含む) */
  preContract30?: { items: ItemPresence; deliveredBeforeContract: boolean; isChangeContract?: boolean; counterpartyIsProfessional?: boolean }[];
  /** 31条: 特定賃貸借契約の締結時の書面 */
  contractDoc31?: { items: ItemPresence; provisions?: Record<string, boolean>; delivered: boolean }[];
  /** 32条: 業務状況調書等の備置き */
  disclosure32?: { businessStatusDocsKept: boolean; officesWithoutDocs?: string[] };
}

export interface RentalMgmtFinding { article: RentalMgmtArticle; code: string; message: string; basis: string }

function missingItems(list: readonly { code: string; label: string; basis: string; conditional?: boolean }[], items: ItemPresence, provisions?: Record<string, boolean>) {
  return list.filter((it) => {
    if (it.conditional && !(provisions && provisions[it.code])) return false;
    return items[it.code] !== true;
  });
}

/**
 * 賃貸住宅管理業法の法定記載事項・備付け義務の欠落を検出する。
 *   渡されなかった区分は点検しない (点検しなかった区分は notChecked に返す。合格扱いにしない)。
 */
export function detectRentalMgmtDeficiencies(r: RentalMgmtRecord): { findings: RentalMgmtFinding[]; notChecked: RentalMgmtArticle[] } {
  const f: RentalMgmtFinding[] = [];
  const notChecked: RentalMgmtArticle[] = [];
  const asOf = String(r.asOf).slice(0, 10);

  if (!r.preContract13) notChecked.push(13);
  else r.preContract13.forEach((d, i) => {
    if (d.clientIsProfessional) return; // 賃貸住宅管理業者その他の専門家は除く (13条1項括弧書・施行規則30条)
    if (!d.deliveredBeforeContract) f.push({ article: 13, code: 'PRE13_NOT_BEFORE_CONTRACT', message: `管理受託契約 ${i + 1}: 締結までに書面を交付して説明していません`, basis: '法13条1項' });
    for (const it of missingItems(MGMT_PRE_CONTRACT_ITEMS_13, d.items)) f.push({ article: 13, code: `PRE13_MISSING_${it.code}`, message: `管理受託契約 ${i + 1} の締結前の書面に「${it.label}」がありません`, basis: it.basis });
  });

  if (!r.contractDoc14) notChecked.push(14);
  else r.contractDoc14.forEach((d, i) => {
    if (!d.delivered) f.push({ article: 14, code: 'DOC14_NOT_DELIVERED', message: `管理受託契約 ${i + 1}: 締結時の書面を交付していません`, basis: '法14条1項' });
    for (const it of missingItems(MGMT_CONTRACT_ITEMS_14, d.items, d.provisions)) f.push({ article: 14, code: `DOC14_MISSING_${it.code}`, message: `管理受託契約 ${i + 1} の締結時の書面に「${it.label}」がありません`, basis: it.basis });
  });

  if (!r.segregation16) notChecked.push(16);
  else {
    if (!r.segregation16.separateAccount) f.push({ article: 16, code: 'SEG16_NO_SEPARATE_ACCOUNT', message: '家賃・敷金等を管理する口座が自己の固有財産の口座と区分されていません', basis: '法16条・施行規則36条' });
    if (!r.segregation16.identifiablePerContract) f.push({ article: 16, code: 'SEG16_NOT_IDENTIFIABLE', message: '受領した金銭がどの管理受託契約に係るものか帳簿等で直ちに判別できません', basis: '法16条・施行規則36条' });
  }

  if (!r.employees17) notChecked.push(17);
  else for (const e of r.employees17) if (!e.carriesCertificate) f.push({ article: 17, code: 'CERT17_NOT_CARRIED', message: `従業者 ${e.name} に従業者証明書を携帯させていません`, basis: '法17条1項・施行規則37条' });

  if (!r.ledgers18) notChecked.push(18);
  else for (const l of r.ledgers18) {
    if (!l.kept) { f.push({ article: 18, code: 'LEDGER18_NOT_KEPT', message: `営業所 ${l.officeId} に帳簿が備え付けられていません`, basis: '法18条' }); continue; }
    l.entries.forEach((e, i) => { for (const it of missingItems(MGMT_LEDGER_ITEMS_18, e.items)) f.push({ article: 18, code: `LEDGER18_MISSING_${it.code}`, message: `営業所 ${l.officeId} の帳簿 ${i + 1} 件目に「${it.label}」がありません`, basis: it.basis }); });
    if (typeof l.retentionYearsAfterClose === 'number' && l.retentionYearsAfterClose < MGMT_LEDGER_RETENTION_YEARS) f.push({ article: 18, code: 'LEDGER18_RETENTION_SHORT', message: `営業所 ${l.officeId} の帳簿の保存期間が閉鎖後 ${l.retentionYearsAfterClose} 年で、5 年に足りません`, basis: '施行規則38条3項' });
  }

  if (!r.signs19) notChecked.push(19);
  else for (const s of r.signs19) if (!s.posted) f.push({ article: 19, code: 'SIGN19_NOT_POSTED', message: `営業所 ${s.officeId} に標識が掲示されていません`, basis: '法19条・施行規則39条' });

  if (!r.reports20) notChecked.push(20);
  else for (const c of r.reports20) {
    const end = c.endedOn && String(c.endedOn).slice(0, 10) < asOf ? String(c.endedOn).slice(0, 10) : asOf;
    const reps = c.reports.map((x) => ({ ...x, deliveredOn: String(x.deliveredOn).slice(0, 10) })).filter((x) => x.deliveredOn <= asOf).sort((a, b) => (a.deliveredOn < b.deliveredOn ? -1 : 1));
    // 締結日から1年を超えない期間ごと (施行規則40条1項): 前回 (又は締結日) の1年後の応当日の前日までに次の報告
    let anchor = String(c.contractedOn).slice(0, 10);
    for (const x of reps) {
      const limit = addDaysYmd(addMonthsYmd(anchor, 12), -1);
      if (x.deliveredOn > limit) { f.push({ article: 20, code: 'REPORT20_INTERVAL', message: `契約 ${c.contractId}: ${anchor} の後、${limit} までに管理業務報告書を交付していません (交付は ${x.deliveredOn})`, basis: '法20条・施行規則40条1項' }); break; }
      anchor = x.deliveredOn;
    }
    const limitNow = addDaysYmd(addMonthsYmd(anchor, 12), -1);
    if (end > limitNow && !f.some((x) => x.code === 'REPORT20_INTERVAL' && x.message.startsWith(`契約 ${c.contractId}:`))) {
      f.push({ article: 20, code: 'REPORT20_INTERVAL', message: `契約 ${c.contractId}: ${anchor} の後、${limitNow} までに管理業務報告書を交付していません`, basis: '法20条・施行規則40条1項' });
    }
    if (c.endedOn && String(c.endedOn).slice(0, 10) < asOf && !reps.some((x) => x.deliveredOn >= String(c.endedOn).slice(0, 10))) {
      f.push({ article: 20, code: 'REPORT20_NO_FINAL', message: `契約 ${c.contractId}: 契約期間の満了 (${String(c.endedOn).slice(0, 10)}) 後の報告がありません (満了後遅滞なく)`, basis: '施行規則40条1項' });
    }
    reps.forEach((x) => { for (const it of missingItems(MGMT_REPORT_ITEMS_20, x.items)) f.push({ article: 20, code: `REPORT20_MISSING_${it.code}`, message: `契約 ${c.contractId} の ${x.deliveredOn} の管理業務報告書に「${it.label}」がありません`, basis: it.basis }); });
  }

  if (!r.ads28) notChecked.push(28);
  else for (const a of r.ads28) if (a.mentionsRentGuarantee && !a.statesRentRevisionConditions) f.push({ article: 28, code: 'AD28_RENT_GUARANTEE_WITHOUT_REVISION', message: `広告 ${a.id}: 家賃の保証・一括借上げをうたいながら、家賃の変更 (減額) に関する事項を表示していません (誇大広告等のおそれ・要確認)`, basis: '法28条・施行規則42条1号' });

  if (!r.preContract30) notChecked.push(30);
  else r.preContract30.forEach((d, i) => {
    if (d.counterpartyIsProfessional) return;
    if (!d.deliveredBeforeContract) f.push({ article: 30, code: d.isChangeContract ? 'PRE30_CHANGE_NOT_EXPLAINED' : 'PRE30_NOT_BEFORE_CONTRACT', message: `特定賃貸借契約 ${i + 1}${d.isChangeContract ? ' (変更契約)' : ''}: 締結までに書面を交付して説明していません`, basis: '法30条1項' });
    for (const it of missingItems(SUBLEASE_PRE_CONTRACT_ITEMS_30, d.items)) f.push({ article: 30, code: `PRE30_MISSING_${it.code}`, message: `特定賃貸借契約 ${i + 1} の締結前の書面に「${it.label}」がありません`, basis: it.basis });
  });

  if (!r.contractDoc31) notChecked.push(31);
  else r.contractDoc31.forEach((d, i) => {
    if (!d.delivered) f.push({ article: 31, code: 'DOC31_NOT_DELIVERED', message: `特定賃貸借契約 ${i + 1}: 締結時の書面を交付していません`, basis: '法31条1項' });
    for (const it of missingItems(SUBLEASE_CONTRACT_ITEMS_31, d.items, d.provisions)) f.push({ article: 31, code: `DOC31_MISSING_${it.code}`, message: `特定賃貸借契約 ${i + 1} の締結時の書面に「${it.label}」がありません`, basis: it.basis });
  });

  if (!r.disclosure32) notChecked.push(32);
  else {
    if (!r.disclosure32.businessStatusDocsKept) f.push({ article: 32, code: 'DISC32_NOT_KEPT', message: '業務状況調書・貸借対照表・損益計算書 (又はこれに代わる書面) を営業所に備え置いていません', basis: '法32条・施行規則48条' });
    for (const o of r.disclosure32.officesWithoutDocs ?? []) f.push({ article: 32, code: 'DISC32_OFFICE_MISSING', message: `営業所 ${o} に業務状況調書等が備え置かれていません`, basis: '法32条・施行規則48条' });
  }

  return { findings: f, notChecked };
}
