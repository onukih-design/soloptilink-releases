/**
 * SoloptiLinkAI Phase 45 — カスタマーハラスメント対応
 *
 * 法令・条例の値は下の値表 KASUHARA_LEGAL_VALUES に1か所で持ち、関数はそこを読む（2026-09-30 是正 I2）。
 * - 労働施策総合推進法 第33条（職場における顧客等の言動に起因する問題に関する雇用管理上の措置等）
 *     令和7年法律第63号・公布 2025-06-11・施行 2026-10-01。規模を問わず全事業主に措置義務。
 *     指針: 令和8年厚生労働省告示第51号（講ずべき措置 10 項目）
 * - 東京都カスタマー・ハラスメント防止条例（令和6年10月11日条例第140号・R7.4.1 施行・罰則なし・事業者は第9条/第14条の努力義務）
 * - 北海道・群馬県の条例（R7.4.1 施行）／愛知県（令和7年条例第34号・R7.10.1 施行）／埼玉県（令和7年条例第54号・R8.7.1 施行）
 * - 三重県条例: 未成立（2026-09-14 県議会へ条例案提出・10-16 採決予定）。施行日・罰則は断定しない
 * - 桑名市条例（令和6年条例第43号・R6.12.25 公布・R7.4.1 施行・第9条第2項で氏名等の公表）
 * - 厚労省「カスタマーハラスメント対策企業マニュアル」（令和3年度作成・令和8年度改訂版 2026-09）
 * - 個人情報保護法 第21条（録音録画の利用目的の通知・公表。第4項の例外に当たるかは個別判断）
 * - 労契法 第5条 (安全配慮義務)
 *
 * カスハラ判断3要素（労働施策総合推進法第33条第1項）:
 *  1. 顧客等の言動であって
 *  2. その雇用する労働者が従事する業務の性質その他の事情に照らして社会通念上許容される範囲を超えたものにより
 *  3. 労働者の就業環境が害されるもの
 *
 * SoT:
 *  - https://laws.e-gov.go.jp/law/341AC0000000132 （asof=2026-10-01 revision 341AC0000000132_20261001_507AC0000000063）
 *  - https://www.mhlw.go.jp/content/11900000/001662576.pdf （厚労省リーフレット: 講ずべき措置①〜⑩）
 *  - https://www.mhlw.go.jp/content/11900000/000915233.pdf （企業マニュアル 令和8年度改訂版・告示第51号）
 *  - https://www.reiki.metro.tokyo.lg.jp/reiki/reiki_honbun/g101RG00005328.html
 */

/**
 * 値表（法令・条例の値の唯一の置き場）。照合日と確度つき。
 * 未確定の値は status: "pending" で持ち、施行日・罰則を断定しない。
 */
export const KASUHARA_LEGAL_VALUES = {
  checked_on: "2026-09-30",
  national: {
    law: "労働施策総合推進法",
    article: "第33条",
    article_detail: "第33条第1項（措置義務）・第2項（相談等を理由とする不利益取扱いの禁止）・第3項（他の事業主からの協力要請への協力の努力義務）・第4項（指針）",
    amending_law: "令和7年法律第63号",
    promulgated: "2025-06-11",
    effective: "2026-10-01",
    guideline: "事業主が職場における顧客等の言動に起因する問題に関して雇用管理上講ずべき措置等についての指針（令和8年厚生労働省告示第51号）",
    guideline_short: "指針（令和8年厚生労働省告示第51号）",
    definition_elements: [
      "顧客等（顧客、取引の相手方、施設の利用者その他の当該事業主の行う事業に関係を有する者）の言動であること",
      "その雇用する労働者が従事する業務の性質その他の事情に照らして社会通念上許容される範囲を超えたものであること",
      "労働者の就業環境が害されること",
    ],
    source: "https://laws.e-gov.go.jp/law/341AC0000000132",
    confidence: "確定（e-Gov 条文）",
    enforcement_ordinance_note: "施行期日を定める政令の番号は要一次確認",
  },
  /** 指針の講ずべき措置 10 項目（厚労省リーフレット ①〜⑩） */
  guideline_measures: [
    { key: "policy_clarified", label: "①カスハラに毅然と対応し労働者を保護する方針の明確化と周知・啓発" },
    { key: "response_content_notified", label: "②カスハラの内容とあらかじめ定めた対処の内容の労働者への周知" },
    { key: "consult_desk", label: "③相談窓口をあらかじめ定め労働者に周知" },
    { key: "desk_staff_capable", label: "④相談窓口の担当者が適切に対応できるようにする" },
    { key: "fact_check", label: "⑤事実関係の迅速かつ正確な確認" },
    { key: "victim_care", label: "⑥被害者に対する配慮のための措置" },
    { key: "recurrence_prevention", label: "⑦再発防止に向けた措置" },
    { key: "egregious_case_policy", label: "⑧特に悪質なカスハラへの対処方針と体制の整備（抑止のための措置）" },
    { key: "privacy_protection", label: "⑨相談者等のプライバシー保護の措置と周知" },
    { key: "no_disadvantage_notice", label: "⑩相談等を理由に不利益な取扱いをされない旨の定めと周知・啓発" },
  ],
  /** 条例（照合日 2026-09-30）。status: enacted＝成立・公布済み / pending＝未成立 */
  ordinances: {
    東京都: { name: "東京都カスタマー・ハラスメント防止条例", status: "enacted", number: "令和6年条例第140号", promulgated: "2024-10-11", effective: "2025-04-01", punitive: false,
      articles: "事業者の責務 第9条・事業者による措置等 第14条（いずれも努力義務・罰則なし）",
      source: "https://www.reiki.metro.tokyo.lg.jp/reiki/reiki_honbun/g101RG00005328.html", confidence: "確定（例規集）" },
    北海道: { name: "北海道カスタマーハラスメント防止条例", status: "enacted", number: null, promulgated: null, effective: "2025-04-01", punitive: false,
      articles: null, source: null, confidence: "施行日は調査報告 F2 で確認。条例番号・公布日は要一次確認" },
    群馬県: { name: "群馬県カスタマーハラスメント防止条例", status: "enacted", number: null, promulgated: null, effective: "2025-04-01", punitive: false,
      articles: null, source: null, confidence: "施行日は調査報告 F2 で確認。条例番号・公布日は要一次確認" },
    愛知県: { name: "愛知県カスタマーハラスメント防止条例", status: "enacted", number: "令和7年条例第34号", promulgated: "2025-07-11", effective: "2025-10-01", punitive: false,
      articles: null, source: "https://no-customerharassment.pref.aichi.jp/assets/pdf/aichi-chp.pdf", confidence: "確定（県の条例本文PDF）" },
    埼玉県: { name: "埼玉県カスタマーハラスメント防止条例", status: "enacted", number: "令和7年条例第54号", promulgated: "2025-12-23", effective: "2026-07-01", punitive: false,
      articles: null, source: "https://www.pref.saitama.lg.jp/documents/284078/01casuharajyorei.pdf", confidence: "確定（県の条例本文PDF）" },
    三重県: { name: "三重県カスタマーハラスメント防止条例（案）", status: "pending", number: null, promulgated: null, effective: null, punitive: null,
      articles: null, source: "https://www.pref.mie.lg.jp/KOYOU/HP/m0139400262.htm",
      confidence: "未成立。2026-09-14 県議会へ提出・10-16 採決予定（報道）。案では知事の禁止命令違反に罰則、可決なら 2027-04-01 施行予定とされる。採決結果を県議会の一次資料で確認してから値を入れる（要一次確認）" },
    桑名市: { name: "桑名市カスタマーハラスメント防止条例", status: "enacted", number: "令和6年条例第43号", promulgated: "2024-12-25", effective: "2025-04-01", punitive: false,
      articles: "第9条第2項（警告後も改善が不十分な行為者の氏名等の公表）", source: "https://www1.g-reiki.net/kuwana/reiki_honbun/r069RG00001827.html", confidence: "確定（例規集）" },
  } as Record<string, { name: string; status: "enacted" | "pending"; number: string | null; promulgated: string | null; effective: string | null; punitive: boolean | null; articles: string | null; source: string | null; confidence: string }>,
  ppi: {
    article: "個人情報保護法 第21条",
    note: "録音・録画は利用目的を通知・公表する（第21条第1項）。第4項第4号（取得の状況からみて利用目的が明らか）に当たるかは個別判断のため、告知文では例外への該当を断言しない（法務の確認が要る）",
  },
} as const;

export const KASUHARA_VERSION = "R7.4.1-tokyo,R8.10.1-national";
export const KASUHARA_NATIONAL_EFFECTIVE = KASUHARA_LEGAL_VALUES.national.effective; // 労働施策総合推進法 第33条
export const KASUHARA_TOKYO_EFFECTIVE = KASUHARA_LEGAL_VALUES.ordinances["東京都"].effective as string; // 東京都条例

/** 基準日を YYYY-MM-DD にそろえる（Date はローカル日付でなく ISO の日付部分を使う） */
function toYmd(asOf?: string | Date): string {
  if (asOf == null) return new Date().toISOString().slice(0, 10);
  if (asOf instanceof Date) return asOf.toISOString().slice(0, 10);
  return String(asOf).slice(0, 10);
}

export const KASUHARA_TYPES = {
  TIME_RESTRAINT: "時間拘束型",
  REPEAT: "リピート型",
  ABUSIVE_LANGUAGE: "暴言型",
  UNREASONABLE_DEMAND: "不当要求型",
  PHYSICAL_VIOLENCE: "暴力身体接触型",
  THREAT_INTIMIDATION: "威嚇脅迫型",
  SEXUAL_DISCRIMINATORY: "性的差別言動型",
  PRIVACY_INVASION: "SNS録画拡散型",
} as const;
export type KasuharaType = keyof typeof KASUHARA_TYPES;

export const ESCALATION_LEVELS = {
  L1_PRIMARY: "現場一次対応",
  L2_SUPERVISOR: "上長介入",
  L3_DEDICATED: "カスハラ相談窓口/法務",
  L4_POLICE: "警察通報",
  L5_CARE: "被害従業員ケア",
} as const;
export type EscalationLevel = keyof typeof ESCALATION_LEVELS;

export const SEVERITY = ["low", "mid", "high", "critical"] as const;
export type Severity = (typeof SEVERITY)[number];

/**
 * 業種別の比率。★出典未確認（要一次確認）: 厚労省「職場のハラスメントに関する実態調査」のどの表かを
 * 確かめられていない。判定には使っておらず、画面・帳票に「統計値」として出さないこと。
 * 出典が見つからなければ外すかはオーナー判断（2026-09-30 I2）。
 */
export const INDUSTRY_RISK_WEIGHTS_SOURCE = { status: "unverified", note: "出典未確認（要一次確認）" } as const;
export const INDUSTRY_RISK_WEIGHTS = {
  medical_welfare: { rate_pct: 29.9, weight: "high" },
  public_admin: { rate_pct: 29.4, weight: "high" },
  transport_postal: { rate_pct: 26.5, weight: "mid" },
  hospitality_food: { rate_pct: 31.2, weight: "high" },
  retail_wholesale: { rate_pct: 35.0, weight: "high" },
  longterm_care: { rate_pct: 34.5, weight: "critical" },
} as const;
export type IndustryCode = keyof typeof INDUSTRY_RISK_WEIGHTS;

export interface KasuharaIncident {
  occurredAt: Date;
  customerType: "consumer" | "b2b" | "public_user";
  utterances: string[];
  durationMinutes?: number;
  recordedMedia?: "audio" | "video" | "none";
  staffId: string;
  industry: IndustryCode;
  physicalContact?: boolean;
  weaponPresented?: boolean;
  refusedToLeave?: boolean;
  snsThreat?: boolean;
  monetaryDemand?: boolean;
}

export interface ThreeFactorScore {
  customerLanguage: boolean;
  exceedsSocialNorm: boolean;
  harmsWorkEnv: boolean;
  isKasuhara: boolean;
}

export interface KasuharaClassification {
  types: KasuharaType[];
  threeFactor: ThreeFactorScore;
  severity: Severity;
  escalation: EscalationLevel;
  needsImmediatePolice: boolean;
  reasons: string[];
}

const ABUSE_KEYWORDS = ["殺す", "死ね", "馬鹿", "クズ", "ふざけるな", "土下座", "晒す", "二度と"];
const SEXUAL_KEYWORDS = ["セクハラ", "胸", "下半身", "セックス", "デート"];
const DISCRIM_KEYWORDS = ["外人", "黒人", "差別", "国に帰れ", "オカマ"];
const THREAT_KEYWORDS = ["殺す", "晒す", "潰す", "燃やす", "復讐", "訴える"];

function detectKeywords(utterances: string[], keywords: string[]): boolean {
  const text = utterances.join(" ");
  return keywords.some((k) => text.includes(k));
}

/** カスハラ3要素検証 */
export function validateThreeFactors(i: KasuharaIncident): ThreeFactorScore {
  const customerLanguage = i.utterances.length > 0 || !!i.physicalContact;
  const exceedsSocialNorm =
    detectKeywords(i.utterances, ABUSE_KEYWORDS) ||
    detectKeywords(i.utterances, SEXUAL_KEYWORDS) ||
    detectKeywords(i.utterances, DISCRIM_KEYWORDS) ||
    detectKeywords(i.utterances, THREAT_KEYWORDS) ||
    !!i.physicalContact ||
    !!i.weaponPresented ||
    !!i.refusedToLeave ||
    !!i.snsThreat ||
    (i.durationMinutes ?? 0) > 30;
  const harmsWorkEnv = exceedsSocialNorm;
  return {
    customerLanguage,
    exceedsSocialNorm,
    harmsWorkEnv,
    isKasuhara: customerLanguage && exceedsSocialNorm && harmsWorkEnv,
  };
}

/** 8類型の自動分類 */
export function classifyKasuhara(i: KasuharaIncident): KasuharaClassification {
  const types: KasuharaType[] = [];
  const reasons: string[] = [];

  if ((i.durationMinutes ?? 0) > 30) {
    types.push("TIME_RESTRAINT");
    reasons.push(`時間拘束 ${i.durationMinutes}分 > 30分閾値`);
  }
  if (detectKeywords(i.utterances, ABUSE_KEYWORDS)) {
    types.push("ABUSIVE_LANGUAGE");
    reasons.push("暴言キーワード検出");
  }
  if (i.physicalContact) {
    types.push("PHYSICAL_VIOLENCE");
    reasons.push("身体的接触あり");
  }
  if (i.weaponPresented || detectKeywords(i.utterances, THREAT_KEYWORDS)) {
    types.push("THREAT_INTIMIDATION");
    reasons.push("脅迫/威嚇言動");
  }
  if (detectKeywords(i.utterances, SEXUAL_KEYWORDS) || detectKeywords(i.utterances, DISCRIM_KEYWORDS)) {
    types.push("SEXUAL_DISCRIMINATORY");
    reasons.push("性的/差別言動");
  }
  if (i.snsThreat) {
    types.push("PRIVACY_INVASION");
    reasons.push("SNS拡散威嚇");
  }
  if (i.monetaryDemand) {
    types.push("UNREASONABLE_DEMAND");
    reasons.push("金銭/不当要求");
  }
  if (i.refusedToLeave) {
    types.push("REPEAT");
    reasons.push("退去拒否/居座り");
  }

  const threeFactor = validateThreeFactors(i);
  const needsImmediatePolice =
    !!i.physicalContact || !!i.weaponPresented || !!i.refusedToLeave || (i.snsThreat && detectKeywords(i.utterances, THREAT_KEYWORDS)) || !!i.monetaryDemand;

  let severity: Severity = "low";
  let escalation: EscalationLevel = "L1_PRIMARY";

  if (needsImmediatePolice) {
    severity = "critical";
    escalation = "L4_POLICE";
  } else if (types.length >= 3 || (i.durationMinutes ?? 0) > 60) {
    severity = "high";
    escalation = "L3_DEDICATED";
  } else if (threeFactor.isKasuhara) {
    severity = "mid";
    escalation = "L2_SUPERVISOR";
  }

  return { types, threeFactor, severity, escalation, needsImmediatePolice, reasons };
}

export interface EscalationPlan {
  level: EscalationLevel;
  responder: string;
  actions: string[];
  legalBasis: string[];
  policeCall: boolean;
}

const PLANS: Record<EscalationLevel, Omit<EscalationPlan, "policeCall">> = {
  L1_PRIMARY: {
    level: "L1_PRIMARY",
    responder: "現場担当",
    actions: ["傾聴", "事実確認", "5分以内のメモ"],
    legalBasis: ["通常CS範囲"],
  },
  L2_SUPERVISOR: {
    level: "L2_SUPERVISOR",
    responder: "店長/課長",
    actions: ["担当交代", "録音開始通知", "記録作成"],
    legalBasis: [
      `${KASUHARA_LEGAL_VALUES.national.law} ${KASUHARA_LEGAL_VALUES.national.article}第1項 (事業主の雇用管理上の措置義務・${KASUHARA_LEGAL_VALUES.national.effective} 施行)`,
      "東京都カスタマー・ハラスメント防止条例 第9条・第14条 (事業者の努力義務・東京都内の事業に限る)",
    ],
  },
  L3_DEDICATED: {
    level: "L3_DEDICATED",
    responder: "カスハラ相談窓口/法務",
    // 出禁・記録の系列店共有・人事評価への利用はお客様（事業者）の判断事項。法的な交渉の代行はしない（弁護士法72条）
    actions: ["対応打ち切り通告書交付", "出禁措置検討（事業者の判断事項）", "弁護士相談"],
    legalBasis: [
      `${KASUHARA_LEGAL_VALUES.national.law} ${KASUHARA_LEGAL_VALUES.national.article}第1項・${KASUHARA_LEGAL_VALUES.national.guideline_short} ⑧特に悪質な事案への対処`,
      "民法709条 (不法行為)",
    ],
  },
  L4_POLICE: {
    level: "L4_POLICE",
    responder: "法務+警備",
    actions: ["110番通報", "現認証拠保全", "店内退避誘導"],
    legalBasis: ["刑法208条 (暴行)", "刑法222条 (脅迫)", "刑法130条 (不退去)", "刑法249条 (恐喝)", "刑法261条 (器物損壊)"],
  },
  L5_CARE: {
    level: "L5_CARE",
    responder: "産業医/EAP",
    actions: ["心身ケア面談", "休職判定", "労災申請支援"],
    legalBasis: ["労働契約法 第5条 (安全配慮義務)", "労働者災害補償保険法"],
  },
};

export function buildEscalationPlan(c: KasuharaClassification): EscalationPlan {
  const base = PLANS[c.escalation];
  return { ...base, policeCall: c.needsImmediatePolice };
}

/**
 * 録音・録画のお知らせ文（ひな形）。
 * 利用目的の公表（個人情報保護法第21条第1項）として書く。第4項の「通知・公表を要しない場合」に
 * 当たるかは個別判断のため、掲示文では例外への該当を断言しない。★掲示前に法務の確認が要る（要確認）。
 */
export const RECORDING_NOTICE_REVIEW_STATUS = { status: "要確認", note: KASUHARA_LEGAL_VALUES.ppi.note } as const;
export function generateRecordingConsentNotice(): string {
  return [
    "【録音・録画に関するお知らせ】",
    "従業員及び他のお客様の安全確保並びにサービス品質向上のため、",
    "店舗内・お問合せ窓口における会話を録音・録画する場合がございます。",
    "録音・録画した記録の利用目的は、(a) 事実確認と証拠の保全 (b) 従業員の教育研修 (c) 法令に基づく警察等関係機関への提供 です。",
    "この利用目的の範囲を超えて利用することはいたしません。",
  ].join("\n");
}

/** 指針（告示第51号）の講ずべき措置 10 項目の整備状況。キーは KASUHARA_LEGAL_VALUES.guideline_measures と同じ */
export interface EmployerAction {
  policy_clarified: boolean;
  response_content_notified: boolean;
  consult_desk: boolean;
  desk_staff_capable: boolean;
  fact_check: boolean;
  victim_care: boolean;
  recurrence_prevention: boolean;
  egregious_case_policy: boolean;
  privacy_protection: boolean;
  no_disadvantage_notice: boolean;
}

export interface ComplianceReport {
  ok: boolean;
  /** 基準日に第33条の措置義務が施行済みか */
  inForce: boolean;
  asOf: string;
  missing: string[];
  rule: string;
  hint: string;
}

/**
 * 労働施策総合推進法第33条の措置義務（指針 10 項目）＋労契法第5条の点検。
 * asOf（基準日）で施行前・施行済みの表示を切り替える。省略時は今日。
 * ★施行後の文面（行政の助言・指導の対象）の言い回しと、就業規則の改定・手続きを社会保険労務士へ回す線引きは要確認。
 */
export function checkSafetyDutyCompliance(actions: Partial<EmployerAction>, asOf?: string | Date): ComplianceReport {
  const nat = KASUHARA_LEGAL_VALUES.national;
  const day = toYmd(asOf);
  const inForce = day >= nat.effective;
  const missing: string[] = [];
  for (const m of KASUHARA_LEGAL_VALUES.guideline_measures) {
    if (!(actions as Record<string, boolean | undefined>)[m.key]) missing.push(m.label);
  }
  const rule = `${nat.law} ${nat.article}第1項（${nat.amending_law}・${nat.effective} 施行）・${nat.guideline_short} + 労契法第5条 (安全配慮義務)`;
  let hint: string;
  if (missing.length === 0) {
    hint = inForce ? "指針の10項目の措置が整っています。" : `指針の10項目の措置が整っています（${nat.effective}から義務）。`;
  } else if (inForce) {
    hint = `${nat.article}の措置義務は施行済みです（${nat.effective}）。未整備の措置があります（行政の助言・指導・勧告の対象になり得ます）: ${missing.join(" / ")}`;
  } else {
    hint = `${nat.effective}から${nat.article}の措置が義務になります。それまでに整えてください: ${missing.join(" / ")}`;
  }
  return { ok: missing.length === 0, inForce, asOf: day, missing, rule, hint };
}

export interface OrdinanceInfo {
  name: string | null;
  /** enacted＝成立・公布済み / pending＝未成立（審議中） / unverified＝この部品の台帳に無い（条例が無いことの確認ではない） */
  status: "enacted" | "pending" | "unverified";
  number: string | null;
  promulgated: string | null;
  effective: string | null;
  /** 刑事罰の有無。未成立・未確認は null（断定しない） */
  punitive: boolean | null;
  articles: string | null;
  /** 基準日に施行中か。未確認は null */
  inForce: boolean | null;
  asOf: string;
  source: string | null;
  confidence: string;
}

/**
 * 該当条例の取得（都道府県名または市の名前。例: "東京都", "桑名市"）。基準日で施行前後を返す。
 * 台帳に無い地域は null ではなく status: "unverified" を返す（「条例なし」と断定しない）。
 */
export function getApplicableOrdinance(prefecture: string, asOf?: string | Date): OrdinanceInfo {
  const day = toYmd(asOf);
  const o = KASUHARA_LEGAL_VALUES.ordinances[prefecture];
  if (!o) {
    return { name: null, status: "unverified", number: null, promulgated: null, effective: null, punitive: null, articles: null,
      inForce: null, asOf: day, source: null, confidence: "この部品の台帳（照合日 " + KASUHARA_LEGAL_VALUES.checked_on + "）に無い。条例が無いことの確認ではない（要確認）" };
  }
  const inForce = o.status === "enacted" && o.effective != null ? day >= o.effective : false;
  return { ...o, inForce, asOf: day };
}

/** カスハラ応対記録の必須欄（事実確認＝指針⑤の記録） */
export const INCIDENT_REQUIRED_FIELDS = ["occurredAt", "staffId", "recordedBy", "facts"] as const;

/** 応対記録を保存してよいか。必須欄が欠けていれば保存できない */
export function validateIncidentRecord(rec: Record<string, unknown>): { ok: boolean; missing: string[] } {
  const missing = INCIDENT_REQUIRED_FIELDS.filter((k) => {
    const v = rec?.[k];
    return v == null || (typeof v === "string" && v.trim() === "");
  }) as string[];
  return { ok: missing.length === 0, missing };
}

/**
 * 宿泊拒否の記録（旅館業法第5条）を保存してよいか。
 * 第1項の号（1〜4）と、第2項の「客観的な事実に基づいて判断」の根拠となる事実が空なら保存できない。
 */
export function validateLodgingRefusal(rec: { ground?: number; objectiveFacts?: string; decidedBy?: string }): { ok: boolean; missing: string[]; rule: string } {
  const missing: string[] = [];
  if (![1, 2, 3, 4].includes(Number(rec?.ground))) missing.push("ground");
  if (!rec?.objectiveFacts || String(rec.objectiveFacts).trim() === "") missing.push("objectiveFacts");
  if (!rec?.decidedBy || String(rec.decidedBy).trim() === "") missing.push("decidedBy");
  return { ok: missing.length === 0, missing, rule: "旅館業法 第5条第1項各号・第2項（客観的な事実に基づく判断と理由の説明）" };
}

/**
 * 応対記録の閲覧権限（指針⑨プライバシー保護）。既定は拒否。
 * 見られるのは相談窓口・法務・人事の担当者と、記録の対象の従業員本人。
 * ★誰に見せるか（人事評価・系列店との共有に使うか）はお客様（事業者）がお決めになる事項（要確認）。
 */
export const INCIDENT_VIEWER_ROLES = ["kasuhara_desk", "legal", "hr_manager"] as const;
export function canViewIncidentRecord(viewer: { role?: string; staffId?: string } | null | undefined, rec: { staffId?: string }): boolean {
  if (!viewer) return false;
  if (viewer.role && (INCIDENT_VIEWER_ROLES as readonly string[]).includes(viewer.role)) return true;
  if (viewer.role && viewer.staffId && rec?.staffId && viewer.staffId === rec.staffId) return true;
  return false;
}

export function selfCheck(): { ok: boolean; checks: Array<{ name: string; pass: boolean }> } {
  const tokyoIncident: KasuharaIncident = {
    occurredAt: new Date("2026-05-01"),
    customerType: "consumer",
    utterances: ["殺すぞ", "土下座しろ"],
    durationMinutes: 45,
    recordedMedia: "audio",
    staffId: "S001",
    industry: "retail_wholesale",
    refusedToLeave: true,
  };
  const cls = classifyKasuhara(tokyoIncident);
  const checks = [
    { name: "8類型定数", pass: Object.keys(KASUHARA_TYPES).length === 8 },
    { name: "5段階エスカレーション", pass: Object.keys(ESCALATION_LEVELS).length === 5 },
    { name: "東京都施行日", pass: KASUHARA_TOKYO_EFFECTIVE === "2025-04-01" },
    { name: "国施行日 (改正労施法)", pass: KASUHARA_NATIONAL_EFFECTIVE === "2026-10-01" },
    { name: "暴言+居座り → critical L4", pass: cls.severity === "critical" && cls.escalation === "L4_POLICE" },
    { name: "3要素全充足", pass: cls.threeFactor.isKasuhara === true },
    { name: "対応プラン警察通報", pass: buildEscalationPlan(cls).policeCall === true },
    // 旧: includes("第21条第4項第3号") で合格にしていた（誤った号を合格条件に固定していた）→ 2026-09-30 是正
    { name: "録音告知文は利用目的を示し、例外該当を断言しない", pass: generateRecordingConsentNotice().includes("利用目的") && !generateRecordingConsentNotice().includes("第21条第4項第3号") && !generateRecordingConsentNotice().includes("通知を要しない") },
    { name: "措置義務の根拠は第33条", pass: checkSafetyDutyCompliance({}, "2026-10-01").rule.includes("第33条") },
    { name: "9/30 は施行前・10/1 は施行済み", pass: checkSafetyDutyCompliance({}, "2026-09-30").inForce === false && checkSafetyDutyCompliance({}, "2026-10-01").inForce === true },
    { name: "指針10項目", pass: KASUHARA_LEGAL_VALUES.guideline_measures.length === 10 },
    { name: "三重県は未成立扱い", pass: getApplicableOrdinance("三重県", "2027-04-02").inForce === false },
  ];
  return { ok: checks.every((c) => c.pass), checks };
}
