/**
 * Phase 15 - 公共調達 / 自治体 / 政府情報システム DNA
 *
 *   Claude Code には存在しない、日本の公共調達 (一般競争入札 / 指名競争 / 随意契約)、
 *   電子入札コアシステム、政府情報システム標準ガイドライン、デジタル庁ガイドライン、
 *   ガバメントクラウド、自治体クラウド、補助金交付規則、官公庁会計、e-Gov、
 *   地方自治法 234条以下の支出原因行為、契約事務規則、検査調書 を一括収録する。
 *
 *   想定読み込み先:
 *     - lib/japan/public_sector.ts
 *     - src/lib/japan/public_sector.ts (jp_inject 後)
 */

// 補助金の値の正本（補助金台帳）。値はここから読む（REQ-JPO-REG-009）
import SUBSIDY_LEDGER from './subsidy-ledger.json';

// ───────────────────────────────────────────────
// 型定義
// ───────────────────────────────────────────────

/** 公共調達方式 (会計法・地方自治法ベース) */
export type ProcurementMethod =
  | 'open_competitive' //  一般競争入札 (原則)
  | 'designated_competitive' //  指名競争入札 (限定列挙の場合のみ)
  | 'discretionary_contract' //  随意契約 (少額・特殊性・緊急時)
  | 'overall_evaluation' //  総合評価落札方式
  | 'proposal_method' //  プロポーザル方式 (技術提案・建設コンサルタント等)
  | 'negotiated_contract' //  企画競争 (デジタル庁等で増加)
  | 'price_competitive_design_build' //  設計施工一括 (DB)
  | 'ecuf' //  ECI (Early Contractor Involvement)
  | 'ppp_pfi'; //  PPP/PFI 事業

/** 発注機関区分 */
export type GovernmentBody =
  | 'cabinet_office' //  内閣府
  | 'digital_agency' //  デジタル庁
  | 'reconstruction' //  復興庁
  | 'ministry' //  各省庁
  | 'agency' //  外局・特別の機関
  | 'prefecture' //  都道府県
  | 'designated_city' //  政令指定都市
  | 'core_city' //  中核市
  | 'special_ward' //  特別区
  | 'municipality' //  一般市町村
  | 'partial_affairs' //  一部事務組合
  | 'incorporated_admin'; //  独立行政法人

export interface ProcurementCase {
  caseId: string;
  title: string;
  body: GovernmentBody;
  method: ProcurementMethod;
  budgetYen: number;
  /** 入札公告 */
  publicNoticeDate: string; //  YYYY-MM-DD
  /** 入札書受付期限 */
  bidDueDate: string;
  /** 開札日 */
  openingDate: string;
  /** 履行期限 */
  performanceDeadline: string;
  /** 入札参加資格等級 (A/B/C/D) */
  qualificationGrade?: 'A' | 'B' | 'C' | 'D';
  /** WTO 政府調達協定対象案件か */
  wtoCovered: boolean;
  /** 価格点 + 技術点の配点 (総合評価方式時) */
  evaluation?: { priceWeight: number; technicalWeight: number };
}

export interface BidEntry {
  bidderId: string;
  bidderName: string;
  bidPriceYen: number; //  入札価格 (税抜)
  technicalScore?: number; //  技術評価点
  /** 失格理由 (空なら有効) */
  disqualified?: string[];
}

export interface BidEvaluationResult {
  caseId: string;
  evaluatedAt: string;
  awardedTo: string | null;
  awardPriceYen: number | null;
  ranked: Array<{ bidderId: string; bidderName: string; totalScore: number; bidPriceYen: number }>;
  notes: string[];
}

// ───────────────────────────────────────────────
// 政府情報システム標準ガイドライン (デジタル庁)
// ───────────────────────────────────────────────

/** 政府情報システムの整備及び管理に関する標準ガイドライン群 */
export const DIGITAL_AGENCY_STANDARDS = [
  {
    id: 'standard-guideline-2024',
    name: '政府情報システムの整備及び管理に関する標準ガイドライン',
    version: '令和6年度版',
    keyPrinciples: [
      'クラウド・バイ・デフォルト',
      'API ファースト',
      'データ標準化 (政府相互運用性フレームワーク GIF)',
      'アジャイル開発の推奨',
      'マイクロサービスアーキテクチャ',
      'ベンダーロックイン回避',
      '相互運用性の確保',
      'マイナンバー連携基盤の活用',
    ],
    requiredArtifacts: ['プロジェクト計画書', 'アーキテクチャ設計書', '運用要件定義書', 'セキュリティ実施手順書', '調達仕様書', 'PIA (プライバシー影響評価)'],
  },
  {
    id: 'gov-cloud-2024',
    name: 'ガバメントクラウド利用基準',
    version: '令和6年度',
    providers: ['AWS', 'Google Cloud', 'Microsoft Azure', 'Oracle Cloud', 'さくらインターネット (国産)'],
    keyControls: ['データレジデンシー (国内リージョン必須)', '暗号鍵の国内保管', 'クラウド認定 ISMAP 必須', '監査ログの不可逆保管 7年'],
    targetMigration: '全1,741市区町村の20基幹業務 → 2025年度末',
  },
  {
    id: 'gif-2024',
    name: '政府相互運用性フレームワーク (GIF)',
    version: '令和6年度',
    coreVocabularies: ['人 (氏名/カナ/英字/性別/生年月日)', '住所 (都道府県/市区町村/町字/番地/方書)', '法人 (法人番号13桁 + 商号 + 本店所在地)', '日付 (和暦/西暦両対応)', '電話番号 (E.164/国内表記両対応)'],
    purpose: '行政間データ連携の語彙を統一し相互運用性を確保',
  },
] as const;

/** 自治体クラウド (基幹業務システム標準化) */
export const STANDARDIZED_LGWAN_SYSTEMS = [
  '住民基本台帳',
  '戸籍住民票',
  '印鑑登録',
  '個人住民税',
  '法人住民税',
  '固定資産税',
  '軽自動車税',
  '国民健康保険',
  '後期高齢者医療',
  '介護保険',
  '国民年金',
  '児童手当',
  '児童扶養手当',
  '生活保護',
  '健康管理',
  '就学',
  '選挙人名簿管理',
  '障害者福祉',
  '子ども・子育て支援',
  '保育',
] as const;

// ───────────────────────────────────────────────
// 公共調達コアロジック
// ───────────────────────────────────────────────

/**
 * 入札方式を予定価格・特殊性から推奨する。
 *
 * 会計法第29条の3 / 地方自治法施行令167条の2 を踏まえた簡易判定:
 *   - 予定価格 ≧ 250万円 (物品)・1,000万円 (工事) → 一般競争入札 (原則)
 *   - 予定価格 < 上記 → 随意契約可能 (少額随契)
 *   - WTO 対象金額以上 → 一般競争入札必須
 *   - 特殊性が高い (専門性 / 緊急性) → 随意契約 or プロポーザル
 */
export function recommendProcurementMethod(input: {
  budgetYen: number;
  category: 'goods' | 'service' | 'construction' | 'consulting' | 'it_system';
  body: GovernmentBody;
  specialty: 'general' | 'specialized' | 'urgent' | 'creative';
  wtoCovered?: boolean;
}): { method: ProcurementMethod; reason: string; lawReference: string } {
  const { budgetYen, category, specialty, wtoCovered } = input;

  if (wtoCovered) {
    return {
      method: 'open_competitive',
      reason: 'WTO政府調達協定対象案件のため、一般競争入札が必須',
      lawReference: '政府調達に関する協定 (WTO/GPA) + 予算決算及び会計令 99条',
    };
  }

  if (specialty === 'creative') {
    return {
      method: 'proposal_method',
      reason: '創意工夫の余地が大きい案件 (Webサイト制作・デジタル戦略策定等) はプロポーザル方式が適切',
      lawReference: '会計法 29条の3第4項 + プロポーザル方式実施準則',
    };
  }
  if (specialty === 'urgent') {
    return {
      method: 'discretionary_contract',
      reason: '緊急の必要により競争に付し得ない場合は随意契約可',
      lawReference: '会計法29条の3第4項 + 予決令102条の4第3号',
    };
  }
  if (specialty === 'specialized') {
    return {
      method: 'discretionary_contract',
      reason: '契約の性質又は目的が競争を許さない場合は随意契約可',
      lawReference: '会計法29条の3第4項 + 予決令102条の4第3号',
    };
  }

  const minOpenCompetitive = category === 'construction' ? 10_000_000 : 2_500_000;
  if (budgetYen < minOpenCompetitive) {
    return {
      method: 'discretionary_contract',
      reason: `予定価格が少額 (${budgetYen.toLocaleString()}円) のため随意契約可`,
      lawReference: '予算決算及び会計令 99条 (少額随契)',
    };
  }

  if (category === 'it_system' && budgetYen >= 100_000_000) {
    return {
      method: 'overall_evaluation',
      reason: '大規模IT案件は価格と技術力を総合的に評価する総合評価落札方式が推奨',
      lawReference: '政府情報システムの整備及び管理に関する標準ガイドライン + 会計法29条の6',
    };
  }

  return {
    method: 'open_competitive',
    reason: '原則として一般競争入札',
    lawReference: '会計法29条の3第1項 + 地方自治法234条第2項',
  };
}

/**
 * 入札を評価し、落札者を決定する。
 *  - 総合評価方式: (技術点×technicalWeight + 価格点×priceWeight) で順位付け
 *  - 価格競争方式: 最低価格を提示した者を落札者とする
 *  - 失格者は除外し、有効入札者のみ評価
 *  - 同点の場合はくじ引きが原則だが、ここでは bidderId昇順で機械的に決定 (再現性確保)
 */
export function evaluateBids(input: {
  pcase: ProcurementCase;
  bids: BidEntry[];
  estimatedPriceYen: number;
}): BidEvaluationResult {
  const { pcase, bids, estimatedPriceYen } = input;
  const validBids = bids.filter((b) => !b.disqualified || b.disqualified.length === 0);
  const notes: string[] = [];

  if (validBids.length === 0) {
    return {
      caseId: pcase.caseId,
      evaluatedAt: new Date().toISOString(),
      awardedTo: null,
      awardPriceYen: null,
      ranked: [],
      notes: ['有効入札者なし。再公告 or 入札不調処理が必要'],
    };
  }

  const overTender = validBids.filter((b) => b.bidPriceYen > estimatedPriceYen);
  if (overTender.length > 0) {
    notes.push(`予定価格超過: ${overTender.length}件`);
  }

  const validInRange = validBids.filter((b) => b.bidPriceYen <= estimatedPriceYen);
  if (validInRange.length === 0) {
    return {
      caseId: pcase.caseId,
      evaluatedAt: new Date().toISOString(),
      awardedTo: null,
      awardPriceYen: null,
      ranked: validBids.map((b) => ({ bidderId: b.bidderId, bidderName: b.bidderName, totalScore: 0, bidPriceYen: b.bidPriceYen })),
      notes: [...notes, '全ての入札が予定価格を超過。再公告必要'],
    };
  }

  let ranked: Array<{ bidderId: string; bidderName: string; totalScore: number; bidPriceYen: number }>;
  if (pcase.method === 'overall_evaluation' && pcase.evaluation) {
    const minPrice = Math.min(...validInRange.map((b) => b.bidPriceYen));
    ranked = validInRange
      .map((b) => {
        const priceScore = (minPrice / b.bidPriceYen) * 100;
        const technical = b.technicalScore ?? 0;
        const totalScore = priceScore * (pcase.evaluation!.priceWeight / 100) + technical * (pcase.evaluation!.technicalWeight / 100);
        return { bidderId: b.bidderId, bidderName: b.bidderName, totalScore: Math.round(totalScore * 100) / 100, bidPriceYen: b.bidPriceYen };
      })
      .sort((a, b) => b.totalScore - a.totalScore || a.bidderId.localeCompare(b.bidderId));
  } else {
    ranked = validInRange
      .map((b) => ({ bidderId: b.bidderId, bidderName: b.bidderName, totalScore: 100 - (b.bidPriceYen / estimatedPriceYen) * 100, bidPriceYen: b.bidPriceYen }))
      .sort((a, b) => a.bidPriceYen - b.bidPriceYen || a.bidderId.localeCompare(b.bidderId));
  }

  const winner = ranked[0];
  const lowballThreshold = estimatedPriceYen * 0.6;
  if (winner.bidPriceYen < lowballThreshold) {
    notes.push(`低入札価格調査が必要 (予定価格の60%未満: ${winner.bidPriceYen.toLocaleString()}円)`);
  }

  return {
    caseId: pcase.caseId,
    evaluatedAt: new Date().toISOString(),
    awardedTo: winner.bidderId,
    awardPriceYen: winner.bidPriceYen,
    ranked,
    notes,
  };
}

// ───────────────────────────────────────────────
// 補助金交付規則
// ───────────────────────────────────────────────
//
// 補助金の名称・公募回・締切・上限の規定は補助金台帳 ./subsidy-ledger.json が正本（REQ-JPO-REG-009）。
// ここには値を書き写さない。台帳の上限規定（補助率・上限・下限・従業員規模・プロセス数・特例）を読んで計算する。
// 台帳で確かめていない制度・枠（令和6年度ベースのまま等）は、旧い値で計算せず「確認できていない」を返す。
// 旧い名称は台帳の former_names（旧名の欄）と、このカタログの formerNames にだけ置く。

export interface SubsidyProgram {
  programId: string;
  name: string;
  competentMinistry: string;
  category: 'business_dev' | 'sustainability' | 'wage_increase' | 'r_and_d' | 'digital_transformation' | 'employment' | 'disaster_recovery';
  /** 表示用の既定の補助率（台帳の default）。計算は calcSubsidyAmount が台帳を読んで行う */
  subsidyRate: number; //  例: 0.5 (1/2)
  /** 表示用の上限額（台帳の上限の最大値）。枠・区分ごとの上限は台帳 */
  maxAmountYen: number;
  applicantTypes: string[];
  documentChecklist: string[];
  /** 旧名（改称前の名称）。旧名はこの欄にだけ置く（REQ-JPO-FIX-017 / REQ-JPO-REG-009） */
  formerNames?: string[];
  /** 受付の状態・後継・出典（REQ-JPO-FIX-017 / 2026-10-01） */
  lifecycle?: SubsidyLifecycle;
  /** 補助金台帳の参照先（program_id・既定の枠） */
  ledgerRef?: { programId: string; frameId?: string };
}

/**
 * 補助金の受付の状態。
 *   active        : 受付中または継続中。台帳の上限規定で計算する（入力が足りなければ計算しない）
 *   renamed       : 改称済み（現行の制度は台帳の program を参照）
 *   ended         : 新規受付を終了。計算しない
 *   needs_check   : 現行の公募要領で確かめていない。旧い値では計算しない（確認できていない）
 */
export interface SubsidyLifecycle {
  status: 'active' | 'renamed' | 'ended' | 'needs_check';
  /** 改称を一次資料で確かめた日 */
  renamedConfirmedOn?: string;
  /** 新規受付を終えた日 */
  acceptanceEndedOn?: string;
  /** 後継の制度 */
  successorJa?: string;
  noteJa?: string;
  sourceUrl?: string;
  verifiedAt?: string;
}

type LedgerRate = { num: number; den: number };
type LedgerLimit = { when?: { fact: string; min?: number; max?: number; eq?: unknown }; cap_yen: number; min_subsidy_yen?: number; special_caps?: Record<string, number> };
type LedgerFrame = { frame_id: string; name_ja: string; limits_unknown?: boolean; limit_note_ja?: string; rates?: { default?: LedgerRate; small_business?: LedgerRate; special?: Record<string, LedgerRate> }; limits?: LedgerLimit[] };
type LedgerProgram = { program_id: string; name_ja: string | null; former_names?: string[]; status: string; acceptance_ended_on?: string | null; successor_ja?: string; check_note_ja?: string; ended_note_ja?: string; renamed_confirmed_on?: string; checked_on: string; sources: { url: string }[]; frames?: LedgerFrame[] };
const LEDGER_PROGRAMS = (SUBSIDY_LEDGER as unknown as { programs: LedgerProgram[] }).programs;

function ledgerProgram(id: string): LedgerProgram {
  const p = LEDGER_PROGRAMS.find((x) => x.program_id === id);
  if (!p) throw new Error(`補助金台帳に制度がありません: ${id}`);
  return p;
}
function ledgerFrame(p: LedgerProgram, frameId: string): LedgerFrame | undefined {
  return (p.frames || []).find((f) => f.frame_id === frameId);
}
const rateOf = (f: LedgerFrame | undefined): number => (f?.rates?.default ? f.rates.default.num / f.rates.default.den : 0);
const maxCapOf = (f: LedgerFrame | undefined): number => Math.max(0, ...((f?.limits || []).map((l) => Math.max(l.cap_yen, ...Object.values(l.special_caps || {})))));

/** 台帳から表示用のカタログ項目を作る（値は台帳のもの） */
function fromLedger(base: Omit<SubsidyProgram, 'name' | 'subsidyRate' | 'maxAmountYen' | 'formerNames' | 'lifecycle' | 'ledgerRef'>, programId: string, frameId: string | undefined, legacy: { subsidyRate: number; maxAmountYen: number }): SubsidyProgram {
  const p = ledgerProgram(programId);
  const f = frameId ? ledgerFrame(p, frameId) : undefined;
  const known = !!f && !f.limits_unknown && (f.limits || []).length > 0 && p.status === 'active';
  const status: SubsidyLifecycle['status'] = p.status === 'ended' ? 'ended' : p.status === 'active' ? (p.former_names?.length ? 'renamed' : 'active') : 'needs_check';
  return {
    ...base,
    programId: base.programId,
    name: p.name_ja ? (f && frameId !== 'tsujo' && frameId !== 'ippan' && frameId !== 'promotion' ? `${p.name_ja}（${f.name_ja}）` : p.name_ja) : '新規受付を終了した制度（旧名の欄を参照）',
    // 表示用の率・上限。台帳で確かめられた枠は台帳の値、確かめていない枠は旧い値を表示用にだけ残す（計算には使わない）
    subsidyRate: known ? rateOf(f) : legacy.subsidyRate,
    maxAmountYen: known ? maxCapOf(f) : legacy.maxAmountYen,
    formerNames: p.former_names && p.former_names.length ? [...p.former_names] : undefined,
    lifecycle: {
      status,
      renamedConfirmedOn: p.renamed_confirmed_on,
      acceptanceEndedOn: p.acceptance_ended_on ?? undefined,
      successorJa: p.successor_ja,
      noteJa: p.status === 'ended' ? p.ended_note_ja : p.status === 'active' ? (known ? undefined : (frameId ? f?.limit_note_ja : '枠ごとに補助率・上限が分かれるため、計算には枠（frameId）の指定が要る')) : p.check_note_ja,
      sourceUrl: p.sources[0]?.url,
      verifiedAt: p.checked_on,
    },
    ledgerRef: { programId, frameId },
  };
}

/** 主要補助金カタログ（値は補助金台帳 ./subsidy-ledger.json から読む。2026-10-03） */
export const SUBSIDY_PROGRAMS: readonly SubsidyProgram[] = [
  fromLedger({ programId: 'subs-ma-pmi-expert', competentMinistry: '中小企業庁', category: 'business_dev', applicantTypes: ['中小企業', '小規模事業者'], documentChecklist: ['M&Aの契約に関する書類', 'PMIの専門家の見積書', 'GビズIDプライム'] }, 'shoukei-ma', 'pmi-expert', { subsidyRate: 0.5, maxAmountYen: 1_500_000 }),
  fromLedger({ programId: 'subs-shoryokuka-ippan', competentMinistry: '中小企業庁', category: 'business_dev', applicantTypes: ['中小企業', '小規模事業者'], documentChecklist: ['事業計画書（申請者自身が作成）', '見積書・仕様書', '決算書', 'GビズIDプライム'] }, 'shoryokuka-ippan', 'ippan', { subsidyRate: 0.5, maxAmountYen: 100_000_000 }),
  fromLedger({ programId: 'subs-monozukuri', competentMinistry: '中小企業庁', category: 'business_dev', applicantTypes: ['中小企業', '小規模事業者'], documentChecklist: ['事業計画書', '見積書(2社以上)', '決算書(直近2期)', '労働者名簿', '加点項目証憑', 'GビズIDプライム'] }, 'monozukuri-legacy', 'main', { subsidyRate: 0.5, maxAmountYen: 12_500_000 }),
  fromLedger({ programId: 'subs-it-introduction', competentMinistry: '中小企業庁', category: 'digital_transformation', applicantTypes: ['中小企業', '小規模事業者'], documentChecklist: ['IT導入支援事業者との共同申請', '登録されたITツールの選択', '決算書', 'SECURITY ACTION 自己宣言', 'GビズIDプライム'] }, 'digital-ai-2026', 'tsujo', { subsidyRate: 0.5, maxAmountYen: 4_500_000 }),
  fromLedger({ programId: 'subs-jizokuka', competentMinistry: '中小企業庁', category: 'business_dev', applicantTypes: ['小規模事業者'], documentChecklist: ['経営計画書', '補助事業計画書', '商工会議所/商工会の支援証明'] }, 'jizokuka', 'ippan', { subsidyRate: 0.667, maxAmountYen: 2_000_000 }),
  fromLedger({ programId: 'subs-reconstruction', competentMinistry: '中小企業庁', category: 'business_dev', applicantTypes: ['中小企業', '中堅企業'], documentChecklist: ['事業計画書(15ページ以内)', '認定経営革新等支援機関の確認書', '決算書(直近3期)', 'ローカルベンチマーク'] }, 'jigyo-saikouchiku', 'main', { subsidyRate: 0.667, maxAmountYen: 70_000_000 }),
  fromLedger({ programId: 'subs-shoene', competentMinistry: '経済産業省 (資源エネルギー庁)', category: 'sustainability', applicantTypes: ['全事業者'], documentChecklist: ['事業計画書', 'エネルギー削減効果計算書', '見積書', 'CO2削減量計算根拠'] }, 'shoene', 'main', { subsidyRate: 0.5, maxAmountYen: 1_500_000_000 }),
  fromLedger({ programId: 'subs-business-succession', competentMinistry: '中小企業庁', category: 'business_dev', applicantTypes: ['中小企業', '小規模事業者', '個人事業主'], documentChecklist: ['事業計画書', '事業承継計画書', '株主名簿', '決算書(直近2期)', 'GビズIDプライム'] }, 'shoukei-ma', undefined, { subsidyRate: 0.667, maxAmountYen: 8_000_000 }),
];

/**
 * 補助金額・対象経費を計算する（補助金台帳の上限規定を読む）。
 *   frameId を省くとカタログ項目の既定の枠。従業員数（省力化）・プロセス数（デジタル化・AI）など、
 *   上限の区分を決める入力が無いときは計算しない（確認できていない）。
 */
export function calcSubsidyAmount(input: { programId: string; eligibleExpenseYen: number; frameId?: string; employees?: number; processCount?: number; smallBusiness?: boolean; specials?: string[]; combinedApplication?: boolean }): { subsidyYen: number; selfBurdenYen: number; rate: number; cappedByMax: boolean } {
  const program = SUBSIDY_PROGRAMS.find((p) => p.programId === input.programId);
  if (!program) throw new Error(`補助金プログラムが見つかりません: ${input.programId}`);
  const lc = program.lifecycle;
  if (lc && lc.status === 'ended') {
    throw new Error(`${program.name}: 新規受付を終了しています（${lc.acceptanceEndedOn ?? '日付不明'}）。後継: ${lc.successorJa ?? '要確認'}`);
  }
  if (!program.ledgerRef) throw new Error(`${program.name}: 補助金台帳の参照先が無いため計算しません（確認できていない）`);
  const p = ledgerProgram(program.ledgerRef.programId);
  if (p.status !== 'active') throw new Error(`${program.name}: 現行の公募要領で補助率・上限を確かめていないため旧い値では計算しません（確認できていない）。${p.check_note_ja ?? ''}`);
  const frameId = input.frameId ?? program.ledgerRef.frameId;
  if (!frameId) {
    const names = (p.frames || []).map((x) => `${x.frame_id}=${x.name_ja}`).join(' / ');
    throw new Error(`${program.name}: 枠ごとに補助率・上限が分かれるため、枠（frameId: ${names}）を指定してください（確認できていない項目: 枠）`);
  }
  const f = ledgerFrame(p, frameId);
  if (!f || f.limits_unknown || !(f.limits || []).length) {
    throw new Error(`${program.name}: 枠「${f?.name_ja ?? frameId}」の補助率・上限を台帳で確かめていないため計算しません（確認できていない）。${f?.limit_note_ja ?? ''}`);
  }
  const facts: Record<string, unknown> = { employees: input.employees, process_count: input.processCount, combined_application: input.combinedApplication };
  const missing: string[] = [];
  let lim: LedgerLimit | undefined;
  for (const l of f.limits || []) {
    const w = l.when;
    if (!w) { lim = l; break; }
    const v = facts[w.fact];
    if (v === undefined || v === null) { missing.push(w.fact === 'employees' ? '従業員数' : w.fact === 'process_count' ? 'プロセス数' : w.fact); continue; }
    if ('eq' in w ? v === w.eq : ((w.min === undefined || (v as number) >= w.min) && (w.max === undefined || (v as number) <= w.max))) { lim = l; break; }
  }
  if (!lim) throw new Error(`${program.name}: 上限の区分を決める入力（${[...new Set(missing)].join('・') || '該当区分なし'}）が足りないため計算しません（確認できていない項目: ${[...new Set(missing)].join('・')}）`);
  let rate = f.rates?.default;
  if (input.smallBusiness && f.rates?.small_business) rate = f.rates.small_business;
  for (const s of input.specials || []) if (f.rates?.special?.[s]) rate = f.rates.special[s];
  if (!rate) throw new Error(`${program.name}: 補助率が台帳に無いため計算しません（確認できていない）`);
  let cap = lim.cap_yen;
  for (const s of input.specials || []) if (lim.special_caps?.[s]) cap = lim.special_caps[s];
  const naive = Math.floor((input.eligibleExpenseYen * rate.num) / rate.den);
  const cappedByMax = naive > cap;
  const subsidyYen = cappedByMax ? cap : naive;
  if (lim.min_subsidy_yen && subsidyYen < lim.min_subsidy_yen) throw new Error(`${program.name}: 補助額が下限（${lim.min_subsidy_yen}円）未満のため対象外です`);
  return {
    subsidyYen,
    selfBurdenYen: input.eligibleExpenseYen - subsidyYen,
    rate: rate.num / rate.den,
    cappedByMax,
  };
}

// ───────────────────────────────────────────────
// 検査調書 / 完了検査
// ───────────────────────────────────────────────

export interface InspectionRecord {
  inspectionId: string;
  contractId: string;
  inspectedAt: string;
  inspector: string;
  /** 仕様書との照合結果 */
  conformsToSpec: boolean;
  /** 欠陥事項リスト */
  defects: Array<{ severity: 'critical' | 'major' | 'minor'; description: string; correctionDeadline?: string }>;
  /** 検査結果 */
  result: 'accepted' | 'conditionally_accepted' | 'rejected';
  /** 是正完了確認 (条件付き合格時) */
  remedyConfirmedAt?: string;
}

export function buildInspectionRecord(input: { contractId: string; inspector: string; defects: InspectionRecord['defects'] }): InspectionRecord {
  const hasCritical = input.defects.some((d) => d.severity === 'critical');
  const hasMajor = input.defects.some((d) => d.severity === 'major');
  const result: InspectionRecord['result'] = hasCritical ? 'rejected' : hasMajor || input.defects.length > 0 ? 'conditionally_accepted' : 'accepted';
  return {
    inspectionId: `INSP-${Date.now()}`,
    contractId: input.contractId,
    inspectedAt: new Date().toISOString(),
    inspector: input.inspector,
    conformsToSpec: result === 'accepted',
    defects: input.defects,
    result,
  };
}

// ───────────────────────────────────────────────
// 標準仕様書 (テンプレート) 雛形生成
// ───────────────────────────────────────────────

export function generateProcurementSpecSkeleton(input: { title: string; body: GovernmentBody; budgetYen: number; method: ProcurementMethod }): string {
  return `# ${input.title} 調達仕様書

1. 件名 / Project Name
   ${input.title}

2. 発注機関 / Government Body
   ${input.body}

3. 履行期限 / Performance Deadline
   契約締結日から ___ 日以内

4. 業務内容 / Scope of Work
   - 要件定義
   - 設計
   - 構築
   - テスト
   - 移行
   - 運用引継ぎ

5. 履行場所 / Place of Performance
   発注機関が指定する場所

6. 提出物 / Deliverables
   - プロジェクト計画書
   - 要件定義書
   - 基本設計書 / 詳細設計書
   - テスト計画書 / テスト結果報告書
   - 操作マニュアル / 運用マニュアル
   - 移行計画書

7. 入札参加資格 / Eligibility
   - 全省庁統一資格 (役務の提供等) ${input.budgetYen >= 100_000_000 ? 'A 等級以上' : 'B 等級以上'}
   - 過去5年間に同種・類似案件の実績を有すること

8. 評価方法 / Evaluation Method
   ${input.method === 'overall_evaluation' ? '総合評価落札方式 (価格点 + 技術点)' : input.method === 'open_competitive' ? '価格競争 (最低価格落札方式)' : input.method}

9. 知的財産権 / Intellectual Property
   本業務で発生した著作権 (著作権法第27条及び第28条の権利を含む) は発注者に帰属する

10. 機密保持 / Confidentiality
    NDA を締結し、業務遂行上知り得た情報は第三者に開示しない

11. 個人情報保護 / Privacy
    個人情報の保護に関する法律 (個情法) を遵守し、PIA (プライバシー影響評価) を実施する

12. セキュリティ要件 / Security
    - 政府機関等の情報セキュリティ対策のための統一基準群 準拠
    - ISMAP 認定クラウドサービスの利用 (該当時)
    - 暗号化通信 (TLS 1.2 以上)
    - 監査ログ7年保管

13. 検査・支払 / Inspection & Payment
    検査調書受領後、請求書受理から30日以内に支払
`;
}
