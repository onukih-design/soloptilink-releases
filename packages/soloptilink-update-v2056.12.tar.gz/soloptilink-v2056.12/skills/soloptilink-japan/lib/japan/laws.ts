/**
 * SoloptiLinkAI JAPAN-NATIVE Mode - 法令DNA Library
 * 8法令を網羅し、アプリケーションに直接注入できる判定・計算ユーティリティ群。
 *
 * 対応法令:
 *   1. インボイス制度 (消費税法 適格請求書等保存方式)
 *   2. 電子帳簿保存法 (電帳法)
 *   3. 個人情報保護法 (個情法)
 *   4. マイナンバー法 (番号法)
 *   5. 労働基準法 (労基法)
 *   6. 製造委託等に係る中小受託事業者に対する代金の支払の遅延等の防止に関する法律 (取適法・旧 下請法)
 *   7. 建設業法
 *   8. 金融商品取引法 (金商法)
 *
 * 使い方:
 *   import { Invoice, DenchoHo, PersonalInfo, MyNumber, LaborStd, Subcontract, Construction, FIEA } from './laws';
 *
 *   if (!Invoice.validateRegistrationNumber(supplier.invoiceNo)) throw new Error('登録番号不正');
 *   const tax = Invoice.calcTaxBreakdown(items); // { reduced8: 2400, standard10: 5000 }
 *   const violation = LaborStd.check36Agreement(monthlyOvertime);
 */

// 業種キーの正規化と「基本3法だけに落ちたか」の開示は、拡張法令側にしか分岐が無いキー
// (bridal / beauty / real_estate 等) も見なければ正しく判定できない。分岐キーの一覧を
// こちら側へ書き写すと片方だけが古くなるため、分岐そのものを呼んで確かめる。
// ★依存は laws.ts → laws_extended.ts の一方向のみ (laws_extended.ts は import を持たない)。
import { recommendExtendedLaws } from './laws_extended';
import { CONSTRUCTION_ORDINANCE_LEDGER } from './construction-law';
// 取適法の値・日数の数え方・適用判定は toriteki.ts が唯一の置き場 (toriteki.ts は import を持たない)。
import {
  checkToritekiPaymentDate,
  judgeToritekiApplicability,
  TORITEKI_ART4_REQUIRED,
  TORITEKI_ART4_CONDITIONAL,
  TORITEKI_PROHIBITIONS,
  type ToritekiTransactionType,
} from './toriteki';

// =============================================================================
// Invoice: インボイス制度 (適格請求書等保存方式)
// =============================================================================
export const Invoice = {
  /**
   * 適格請求書発行事業者の登録番号検証
   * フォーマット: "T" + 13桁の数字 (法人番号と同じ桁数)
   */
  validateRegistrationNumber(no: string): boolean {
    if (!no) return false;
    return /^T\d{13}$/.test(no.trim());
  },

  /**
   * 税率別集計 (10% / 軽減8% / 非課税)
   */
  calcTaxBreakdown(items: Array<{ price: number; qty: number; rate: 'standard' | 'reduced' | 'exempt' }>): {
    subtotal: { standard: number; reduced: number; exempt: number };
    tax: { standard: number; reduced: number };
    total: number;
  } {
    const subtotal = { standard: 0, reduced: 0, exempt: 0 };
    for (const it of items) {
      const amount = it.price * it.qty;
      if (it.rate === 'standard') subtotal.standard += amount;
      else if (it.rate === 'reduced') subtotal.reduced += amount;
      else subtotal.exempt += amount;
    }
    const tax = {
      standard: Math.floor(subtotal.standard * 0.10),
      reduced: Math.floor(subtotal.reduced * 0.08),
    };
    const total = subtotal.standard + subtotal.reduced + subtotal.exempt + tax.standard + tax.reduced;
    return { subtotal, tax, total };
  },

  /**
   * 適格簡易請求書の発行可否判定 (小売/飲食/写真/旅行/タクシー/駐車場)
   */
  canIssueSimplified(industry: string): boolean {
    // ★2026-08-11 (全結線計画 BLK-2): 業種辞書の名前で呼ばれても正しく判定できるよう
    //   キーを正規化する。従来は 'retail-pos' が false になり、小売業なのに
    //   適格簡易請求書を発行できないと判定していた (消費税法第57条の4第2項が
    //   小売業に認めた特例を、システムが自ら捨てていた)。
    return ['retail', 'food_service', 'photo', 'travel', 'taxi', 'parking']
      .includes(normalizeIndustryKey(industry));
  },

  /**
   * 必須記載事項のチェック (適格請求書)
   */
  requiredFields(): string[] {
    return [
      '発行者の氏名または名称',
      '登録番号 (T + 13桁)',
      '取引年月日',
      '取引内容 (軽減税率対象である旨)',
      '税率ごとに区分した合計額',
      '税率ごとに区分した消費税額',
      '受領者の氏名または名称',
    ];
  },
};

// =============================================================================
// DenchoHo: 電子帳簿保存法
// =============================================================================
export const DenchoHo = {
  /**
   * 電子取引データの3要件検索キー生成 (取引年月日/取引金額/取引先)
   */
  buildSearchKeys(transaction: { date: string; amount: number; partner: string }): string[] {
    return [
      `date:${transaction.date}`,
      `amount:${transaction.amount}`,
      `partner:${transaction.partner}`,
    ];
  },

  /**
   * タイムスタンプ付与要件 (JIIMA認定タイムスタンプが必要)
   * スキャナ保存: おおむね7営業日以内
   * 電子取引: 法令遵守のため取引後速やかに
   */
  timestampDeadline(kind: 'scanner' | 'e_transaction'): number {
    return kind === 'scanner' ? 7 : 2; // 営業日
  },

  /**
   * 改ざん防止のためのハッシュ計算 (SHA-256 を推奨)
   */
  async computeFileHash(file: Uint8Array): Promise<string> {
    if (typeof crypto !== 'undefined' && crypto.subtle) {
      const buf = await crypto.subtle.digest('SHA-256', new Uint8Array(file));
      return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
    }
    throw new Error('Crypto API 利用不可。server-side で node:crypto を利用してください。');
  },

  /**
   * スキャナ保存要件 (解像度/階調)
   */
  scannerRequirements(): { dpi: number; colorDepth: number; fileFormat: string[] } {
    return { dpi: 200, colorDepth: 24, fileFormat: ['pdf', 'jpeg', 'png', 'tiff'] };
  },
};

// =============================================================================
// PersonalInfo: 個人情報保護法
// =============================================================================
export const PersonalInfo = {
  /**
   * 要配慮個人情報の分類 (医療/犯罪歴/人種/信条/社会的身分等)
   */
  isSensitive(field: string): boolean {
    const sensitive = [
      '病歴', '診療履歴', '服薬', '障害', '精神状態',
      '犯罪歴', '犯罪被害',
      '人種', '信条', '社会的身分', '国籍',
      '遺伝情報', '生体情報',
    ];
    return sensitive.some(s => field.includes(s));
  },

  /**
   * 利用目的通知文の雛形生成
   */
  generatePurposeNotice(params: { purposes: string[]; company: string; contact: string }): string {
    return [
      `${params.company} 個人情報の利用目的のお知らせ`,
      '',
      '当社では、以下の目的でお客さまの個人情報を取扱います:',
      ...params.purposes.map(p => `・${p}`),
      '',
      '上記目的の範囲を超えて利用することはございません。',
      '個人情報保護に関するお問い合わせ:',
      params.contact,
    ].join('\n');
  },

  /**
   * 第三者提供時の記録項目 (名簿屋規制対応)
   */
  thirdPartyRecordFields(): string[] {
    return ['提供年月日', '提供先の名称', '本人氏名', '提供した項目', '本人同意の有無'];
  },

  /**
   * 保有個人データの開示請求対応チェック (30日以内)
   */
  disclosureDeadlineDays(): number {
    return 30;
  },
};

// =============================================================================
// MyNumber: マイナンバー法
// =============================================================================
export const MyNumber = {
  /**
   * マイナンバーの形式検証 (12桁の数字 + チェックディジット)
   */
  validate(no: string): boolean {
    if (!/^\d{12}$/.test(no)) return false;
    const digits = no.split('').map(Number);
    const check = digits[11];
    const body = digits.slice(0, 11);
    // チェックディジット計算 (国税庁公表仕様)
    const weights = [6, 5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
    let sum = 0;
    for (let i = 0; i < 11; i++) sum += body[i] * weights[i];
    const rem = sum % 11;
    const cd = rem <= 1 ? 0 : 11 - rem;
    return cd === check;
  },

  /**
   * 表示用マスク (下4桁以外を * に)
   */
  mask(no: string): string {
    if (!no || no.length < 4) return '************';
    return '*'.repeat(no.length - 4) + no.slice(-4);
  },

  /**
   * 取扱可能業務の判定 (税・社保・災害対策の3分野のみ)
   */
  canHandle(purpose: 'tax' | 'social_security' | 'disaster' | string): boolean {
    return ['tax', 'social_security', 'disaster'].includes(purpose);
  },

  /**
   * 廃棄記録のフィールド
   */
  disposalRecordFields(): string[] {
    return ['廃棄年月日', '廃棄方法', '対象件数', '廃棄責任者', '立会者'];
  },
};

// =============================================================================
// LaborStd: 労働基準法
// =============================================================================
export const LaborStd = {
  /**
   * 36協定違反検知 (月45時間/年360時間の原則、特別条項で月100h/年720h上限)
   */
  check36Agreement(monthly: number[], yearly: number, hasSpecial: boolean): Array<{ month: number; hours: number; rule: string }> {
    const violations: Array<{ month: number; hours: number; rule: string }> = [];
    const monthLimit = hasSpecial ? 100 : 45;
    const yearLimit = hasSpecial ? 720 : 360;
    monthly.forEach((h, i) => {
      if (h > monthLimit) violations.push({ month: i + 1, hours: h, rule: `月${monthLimit}時間超過` });
    });
    if (yearly > yearLimit) violations.push({ month: 0, hours: yearly, rule: `年${yearLimit}時間超過` });
    // 特別条項ありでも、複数月平均80時間は違反
    if (hasSpecial) {
      for (let i = 2; i < monthly.length; i++) {
        const avg3 = (monthly[i - 2] + monthly[i - 1] + monthly[i]) / 3;
        if (avg3 > 80) violations.push({ month: i + 1, hours: Math.round(avg3), rule: '3ヶ月平均80時間超過' });
      }
    }
    return violations;
  },

  /**
   * 割増賃金率の算出 (時間外25%, 深夜25%, 法定休日35%, 月60h超50%)
   */
  overtimeRate(params: { overtimeHoursInMonth: number; isNight: boolean; isLegalHoliday: boolean }): number {
    let rate = 0;
    if (params.isLegalHoliday) rate = 0.35;
    else if (params.overtimeHoursInMonth > 60) rate = 0.50;
    else rate = 0.25;
    if (params.isNight) rate += 0.25;
    return rate;
  },

  /**
   * 有給休暇5日取得義務チェック (年10日付与される労働者対象)
   */
  check5DaysPaidLeave(annualPaidDays: number, takenDays: number): boolean {
    if (annualPaidDays < 10) return true; // 対象外
    return takenDays >= 5;
  },
};

// =============================================================================
// Subcontract: 取適法 (製造委託等に係る中小受託事業者に対する代金の支払の遅延等の防止に関する法律・旧 下請法)
//   ★2026-01-01 施行の改正で題名・用語・条番号が変わった (委託事業者・中小受託事業者・製造委託等代金)。
//   ★2026-09-30 是正 (REQ-JPO-FIX-003・REQ-JPO-FIX-015): 旧法のままだった適用判定 (資本金だけ)・
//     支払期日の数え方 (受領日を算入していない)・明示事項・遵守事項を改正後へ直した。
//     値と判定は toriteki.ts に一本化し、ここは互換のための薄い口とする (名前 Subcontract は互換のため残す)。
// =============================================================================
export const Subcontract = {
  /**
   * 第4条の明示事項 (令和7年公正取引委員会規則第8号 第1条)。
   *   電磁的方法による明示に中小受託事業者の承諾は要らない (改正で承諾要件を廃止)。
   */
  requiredArt4Items(): string[] {
    return [
      ...TORITEKI_ART4_REQUIRED.map((i) => i.label),
      ...TORITEKI_ART4_CONDITIONAL.map((i) => i.label),
    ];
  },

  /**
   * @deprecated 旧名 (旧法の「3条の書面」)。改正後は第4条の明示。{@link Subcontract.requiredArt4Items} を使うこと。
   *   中身は requiredArt4Items と同一 (互換のために残す)。
   */
  required3jouFields(): string[] {
    return Subcontract.requiredArt4Items();
  },

  /**
   * 支払期日の検査 (第3条: 受領日から起算して60日以内・受領日を算入)。
   *   days は受領日を1日目として支払日が何日目か (6/1受領→7/30払いは60)。
   *   月単位の締切制度・休業日の順延は toriteki.checkToritekiPaymentDate を使う。
   */
  checkPaymentDeadline(receivedDate: Date, paymentDate: Date): { ok: boolean; days: number } {
    const r = checkToritekiPaymentDate({ receivedAt: receivedDate, paymentDate });
    return { ok: r.ok, days: r.dayNumber };
  },

  /**
   * 取適法の適用範囲判定 (第2条8項・9項: 資本金基準と従業員基準)。
   *   kind: 'manufacturing' (製造・修理・特定運送と政令の情報成果物・役務の区分) / 'service' (それ以外の情報成果物・役務)
   *   opts.parentEmployees / childEmployees: 常時使用する従業員の数。
   *   ★資本金で該当せず従業員数が無いときは断定できないため false を返す (判定の記録は toriteki.judgeToritekiApplicability を使う)。
   */
  applies(
    parentCapital: number,
    childCapital: number,
    kind: 'manufacturing' | 'service',
    opts: { parentEmployees?: number; childEmployees?: number; type?: ToritekiTransactionType; consignedAt?: string } = {},
  ): boolean {
    const r = judgeToritekiApplicability({
      type: opts.type ?? (kind === 'manufacturing' ? 'manufacturing' : 'service'),
      consignor: { capitalYen: parentCapital, employees: opts.parentEmployees ?? null },
      contractor: { capitalYen: childCapital, employees: opts.childEmployees ?? null },
      consignedAt: opts.consignedAt,
    });
    return r.applies === true;
  },

  /**
   * 委託事業者の遵守事項11類型 (第5条1項1〜7号・2項1〜4号)。
   *   旧法の「割引困難な手形の交付」は廃止され、手形の交付そのものが支払遅延 (第5条1項2号) になった。
   *   「協議に応じない一方的な代金決定」(第5条2項4号) が加わった。
   */
  prohibitedActs(): string[] {
    return TORITEKI_PROHIBITIONS.map((p) => p.name);
  },
};

/** 改正後の略称での別名 (中身は Subcontract と同一) */
export const Toriteki = Subcontract;

// =============================================================================
// Construction: 建設業法
// =============================================================================
/**
 * 建設業法の金額要件 (値表。建設業法施行令2条・27条ほか)。ここが唯一の置き場で、Construction の各判定はこれを読む。
 *   出典: 国土交通省 報道発表「建設業の各種金額要件や技術検定の受検手数料を見直します」(令和6年12月6日)
 *         https://www.mlit.go.jp/report/press/tochi_fudousan_kensetsugyo13_hh_000001_00267.html (2025-02-01 施行分)
 *         同「建設業法施行令の一部を改正する政令」(令和4年11月) (2023-01-01 施行分)
 *   specificSubcontractYen: 特定建設業の許可・監理技術者・施工体制台帳を要する【下請代金の総額】の下限 (以上)
 *   *_BuildingWork: 建築工事業 (建築一式工事) の場合
 *   exclusiveContractYen: 専任の主任技術者・監理技術者を要する【請負代金】の下限 (以上。施行令27条の重要な工事)
 */
// ★2026-10-04 (T26): 金額の値そのものは construction-law.ts の版つき値表 CONSTRUCTION_ORDINANCE_LEDGER に1か所で持ち、
//   ここはそれを読んで組み立てる (e-Gov の施行令の条文と機械で突き合わせるのは向こうの値表)。
export const CONSTRUCTION_AMOUNT_THRESHOLDS: ReadonlyArray<{
  from: string; // この日から適用 (YYYY-MM-DD)
  specificSubcontractYen: number;
  specificSubcontractYenBuildingWork: number;
  exclusiveContractYen: number;
  exclusiveContractYenBuildingWork: number;
  source: string;
}> = (() => {
  const spec = CONSTRUCTION_ORDINANCE_LEDGER.find((r) => r.key === 'specific_license_subcontract')!;
  const excl = CONSTRUCTION_ORDINANCE_LEDGER.find((r) => r.key === 'exclusive_engineer_contract')!;
  return spec.versions.map((v) => {
    const from = v.from ?? '0000-01-01';
    const e = excl.versions.find((x) => (x.from ?? '0000-01-01') === from);
    if (!e) throw new Error(`施行令2条と27条の版の始期が揃っていない: ${from}`);
    return { from, specificSubcontractYen: v.value, specificSubcontractYenBuildingWork: v.valueBuildingWork!, exclusiveContractYen: e.value, exclusiveContractYenBuildingWork: e.valueBuildingWork!, source: `${v.source} / ${e.source}` };
  });
})();

/** 基準日 (YYYY-MM-DD。省くと今日) に有効な金額要件を返す */
export function constructionAmountThresholdsAt(asOf?: string) {
  const d = (asOf || new Date().toISOString()).slice(0, 10);
  return CONSTRUCTION_AMOUNT_THRESHOLDS.find((t) => d >= t.from) ?? CONSTRUCTION_AMOUNT_THRESHOLDS[CONSTRUCTION_AMOUNT_THRESHOLDS.length - 1];
}

/** 都道府県の名前 (知事許可の許可番号の照合用) */
const PREFECTURE_NAMES = [
  '北海道', '青森県', '岩手県', '宮城県', '秋田県', '山形県', '福島県', '茨城県', '栃木県', '群馬県', '埼玉県', '千葉県',
  '東京都', '神奈川県', '新潟県', '富山県', '石川県', '福井県', '山梨県', '長野県', '岐阜県', '静岡県', '愛知県', '三重県',
  '滋賀県', '京都府', '大阪府', '兵庫県', '奈良県', '和歌山県', '鳥取県', '島根県', '岡山県', '広島県', '山口県', '徳島県',
  '香川県', '愛媛県', '高知県', '福岡県', '佐賀県', '長崎県', '熊本県', '大分県', '宮崎県', '鹿児島県', '沖縄県',
];

export const Construction = {
  /**
   * 建設業許可番号のフォーマット検証
   * 例: "国土交通大臣 特-30 第00001号" / "東京都知事 般-02 第000001号"
   *   知事許可は47都道府県の名前で照合する (旧版の [都道府県]{2,3} は「東京都知事」等を全て弾いていた)。
   */
  validateLicenseNumber(no: string): boolean {
    const m = /^(国土交通大臣|(.+)知事)\s+(特|般)-\d{2}\s+第\d{5,6}号$/.exec(String(no).trim());
    if (!m) return false;
    if (m[1] === '国土交通大臣') return true;
    return PREFECTURE_NAMES.includes(m[2]);
  },

  /**
   * 特定建設業の許可が要るか (建設業法3条1項2号・施行令2条)。
   *   発注者から直接請け負った工事で、下請に出す代金の総額が 5,000万円 (建築工事業 8,000万円) 以上 (2025-02-01〜)。
   */
  isSpecificLicenseRequired(subcontractTotalYen: number, isBuildingWork: boolean, asOf?: string): boolean {
    const t = constructionAmountThresholdsAt(asOf);
    return subcontractTotalYen >= (isBuildingWork ? t.specificSubcontractYenBuildingWork : t.specificSubcontractYen);
  },

  /**
   * 主任技術者/監理技術者の配置要件 (建設業法26条1項・2項・施行令2条)
   *   元請 (発注者から直接請け負った者) が下請に出す代金の【総額】が 5,000万円 (建築一式 8,000万円) 以上なら監理技術者。
   *   ★第1引数は下請代金の総額。元請の請負金額で判定してはならない (旧版の誤り)。
   */
  requiredEngineer(subcontractTotalYen: number, isArchitecture: boolean, isPrime: boolean, asOf?: string): 'chief' | 'supervisor' {
    const t = constructionAmountThresholdsAt(asOf);
    const threshold = isArchitecture ? t.specificSubcontractYenBuildingWork : t.specificSubcontractYen;
    if (isPrime && subcontractTotalYen >= threshold) return 'supervisor'; // 監理技術者
    return 'chief'; // 主任技術者
  },

  /**
   * 主任技術者・監理技術者の専任が要るか (建設業法26条3項・施行令27条)。
   *   公共性のある施設・多数の者が利用する施設 (共同住宅・事務所なども含む。個人住宅は除く) の重要な工事で、
   *   請負代金が 4,500万円 (建築一式 9,000万円) 以上 (2025-02-01〜)。公共工事に限らない。
   *   ★施行令27条の施設に当たるかは呼び出し側で isImportantFacility として渡す (不明なら true 側で扱うこと)。
   *   ★ICT 活用等の条件で専任を要しない特例 (26条3項ただし書) はここでは判定しない (要件の確認が要る)。
   */
  requiresExclusiveEngineer(p: { contractAmountYen: number; isBuildingWork: boolean; isImportantFacility: boolean; isPublic?: boolean; asOf?: string }): boolean {
    if (!p.isImportantFacility) return false;
    const t = constructionAmountThresholdsAt(p.asOf);
    return p.contractAmountYen >= (p.isBuildingWork ? t.exclusiveContractYenBuildingWork : t.exclusiveContractYen);
  },

  /**
   * 一括下請負の禁止 (建設業法22条)
   *   公共工事 (入札契約適正化法の対象) は全面禁止。民間工事は発注者の書面による承諾があれば可だが、
   *   共同住宅を新築する建設工事 (施行令6条の3) は承諾があっても禁止。
   *   共同住宅の新築か不明なときは「可」と言わない (opts.isNewApartmentConstruction を渡すこと)。
   *   出典: 国土交通省 北陸地方整備局「建設業者のための建設業法」令和7年2月改訂版 (22条3項・施行令6条の3)
   */
  checkLumpSubcontracting(isPublic: boolean, hasConsent: boolean, opts: { isNewApartmentConstruction?: boolean } = {}): { ok: boolean; reason?: string; needsConfirmation?: boolean } {
    if (isPublic) return { ok: false, reason: '公共工事は一括下請負全面禁止' };
    if (opts.isNewApartmentConstruction === true) return { ok: false, reason: '共同住宅を新築する建設工事は、民間工事でも発注者の承諾があっても一括下請負禁止 (建設業法22条3項・施行令6条の3)' };
    if (!hasConsent) return { ok: false, reason: '民間工事でも書面承諾が必要' };
    if (opts.isNewApartmentConstruction === undefined) {
      return { ok: false, needsConfirmation: true, reason: '共同住宅を新築する工事かどうかが分からないため判定できません (共同住宅の新築は承諾があっても禁止)' };
    }
    return { ok: true };
  },

  /**
   * 建退共証紙の計算 (掛金日額310円 × 就労日数)
   */
  calcTaishokusho(workDays: number): number {
    return workDays * 310;
  },

  /**
   * 29業種の一覧
   */
  specialties(): string[] {
    return [
      '土木', '建築', '大工', '左官', 'とび・土工・コンクリート',
      '石', '屋根', '電気', '管', 'タイル・れんが・ブロック',
      '鋼構造物', '鉄筋', '舗装', 'しゅんせつ', '板金',
      'ガラス', '塗装', '防水', '内装仕上', '機械器具設置',
      '熱絶縁', '電気通信', '造園', 'さく井', '建具',
      '水道施設', '消防施設', '清掃施設', '解体',
    ];
  },
};

// =============================================================================
// FIEA: 金融商品取引法 (Financial Instruments and Exchange Act)
// =============================================================================
export const FIEA = {
  /**
   * 広告規制: 誇大表示禁止項目
   */
  prohibitedAdTerms(): string[] {
    return ['絶対', '必ず儲かる', '元本保証', '損失なし', '確実に'];
  },

  /**
   * 適合性の原則チェック (顧客属性と商品の適合)
   */
  checkSuitability(customer: { age: number; experience: number; income: number; assets: number }, product: { riskLevel: 1 | 2 | 3 | 4 | 5 }): { ok: boolean; reason?: string } {
    if (product.riskLevel >= 4 && customer.experience < 3) {
      return { ok: false, reason: '投資経験不足 (3年未満)' };
    }
    if (product.riskLevel === 5 && customer.age >= 75) {
      return { ok: false, reason: '75歳以上への高リスク商品勧誘制限' };
    }
    if (customer.assets < product.riskLevel * 1_000_000) {
      return { ok: false, reason: '必要金融資産不足' };
    }
    return { ok: true };
  },

  /**
   * 契約締結前交付書面の必須記載事項
   */
  preContractDocRequiredFields(): string[] {
    return [
      '手数料・報酬・費用',
      '元本欠損のおそれ',
      '金利変動・相場変動リスク',
      'クーリングオフの有無',
      '取扱業者の商号・登録番号',
      '指定紛争解決機関',
    ];
  },
};

// =============================================================================
// 統合判定: 業種から必要法令を推定
// =============================================================================
// =============================================================================
// 業種キーの正規化 (2026-08-11 / 全結線計画 BLK-2)
// =============================================================================
/**
 * 業種辞書の slug を、法令判定が分岐に使うキーへ寄せる。
 *
 * 【なぜ要るか — 実測で確かめた欠陥】
 *   法令判定の分岐キーはカテゴリ単位 (construction / manufacturing / healthcare /
 *   professional / retail / food_service / finance) だが、業種辞書の名前は具体名の
 *   kebab-case (retail-pos / food-service / printing …) である。両者が一致しないため、
 *   業種辞書の名前でそのまま呼ぶと **既定の基本3法しか返らない**。しかも
 *   「該当法令なし」として画面に出るだけで、欠落したこと自体が表示されない。
 *     実測: applicableLawsFor('retail-pos') → 基本3法 / 'retail' → 景品表示法・特定商取引法を含む
 *           canIssueSimplified('retail-pos') → false (小売業なのに適格簡易請求書が発行できない判定)
 *
 * 【機械的に寄せてはいけない — 実測で確かめた反例】
 *   業種辞書の category 宣言を機械的に使うと誤る。
 *     ・veterinary-clinic の category は healthcare だが、動物病院に医療法・介護保険法は
 *       当たらない (獣医師法・獣医療法は本ライブラリに実装が無い)。
 *     ・retail-pos / food-service は category を宣言していない。
 *   よって本表は **根拠のあるものだけ** を1件ずつ載せる。載っていない業種は
 *   従来どおり既定 (基本3法) に落ちる = 挙動は変わらない。
 *
 * 【この表に足すときの条件】
 *   ① 業種辞書が自らその category を宣言している、または
 *   ② 返る法令が、その業種辞書の regulations に書かれた法令名・数値と一致することを
 *      実装を読んで確認した
 *   どちらも満たさないものを推測で足さない。足すと、その業種に無関係な法令が
 *   「該当法令」として顧客の画面に出る。
 */
const INDUSTRY_KEY_ALIASES: Record<string, string> = {
  // ---------------------------------------------------------------------------
  // (a) コア法 (laws.ts recommendLaws) の分岐へ寄せるもの
  // ---------------------------------------------------------------------------
  // 小売POS: 景品表示法 (景品額の上限)・特定商取引法第11条の8項目・製造物責任法第5条の
  //   3年/10年・薬機法第36条の8/9の販売区分が、業種辞書の regulations の記載値と
  //   一致することを確認済 (2026-08-11)
  'retail-pos': 'retail',
  // 飲食: 食品衛生法の営業許可業種と食中毒24時間届出・食品表示法のアレルゲン義務9品目/
  //   推奨20品目/栄養5項目が実装に実在し、業種辞書の要求と一致することを確認済
  'food-service': 'food_service',
  // 印刷: 業種辞書が category=manufacturing を宣言。かつ取適法 (旧 下請法) の条文・数値
  //   (第2条の資本金・従業員基準・第3条の60日・第4条の明示・第5条の遵守事項) が
  //   実装 API と対応することを確認済 (2026-09-30 に改正後の条番号へ是正)
  printing: 'manufacturing',
  // 産業廃棄物処理: 廃棄物処理法 (S45法律137) の産廃20種・特別管理の性状判定・
  //   12条の3のマニフェスト・14条の許可5年更新が実装に実在することを確認済
  'industrial-waste': 'industrial_waste',
  // 士業事務所 (2026-08-15 / 13業種結線): 辞書 regulations の 税理士法・弁護士法・公認会計士法・
  //   社会保険労務士法・行政書士法 は、実装分岐 'professional' が返す『士業法』の総称に対応する。
  //   keywords に 士業事務所・マイナンバー・就業規則 が実在し、返る マイナンバー法・労働基準法 と
  //   対応する (士業は特定個人情報の取扱者・雇用主として両法の名宛人)。
  //   ★辞書 regulations の 犯罪収益移転防止法 は本ライブラリに実装が無く返らない。
  //     網羅ではないことを判定台帳 industry-lane-judgment.json に開示している (owner 再判断用)。
  'professional-firm': 'professional',
  // 法律事務所 (2026-10-18 / L159-LAWS-ALIAS の是正): 判定台帳では laws-knowledge を結線済み
  //   (レーンは当たる) なのに本表にも分岐キーにも無く、『該当法令』が基本3法へ落ちていた。
  //   'professional' (士業法の総称) へは寄せない。辞書 regulations に固有の法律名が並んでおり、
  //   総称で返すと筆頭の弁護士法が画面に出ないため、専用の分岐 'law_firm' を置いた。
  //   返す4法はいずれも辞書 domains/law-firm.json の regulations に実在する (条件①)。
  //   題名は e-Gov 法令API v2 で 2026-10-18 に確かめた (いずれも廃止なし):
  //     弁護士法 (昭和二十四年法律第二百五号・施行 2025-10-01 の版) / 民事訴訟法 (平成八年法律第百九号・
  //     2026-06-24) / 総合法律支援法 (平成十六年法律第七十四号・2026-05-21) /
  //     犯罪による収益の移転防止に関する法律 (平成十九年法律第二十二号・2026-08-12。
  //     「犯罪収益移転防止法」は e-Gov の略称欄の表記)。
  //   ★犯収法: 弁護士は特定事業者 (2条2項45号) で、取引時確認等に相当する措置は日弁連の会則で
  //     定める (同法12条)。aml_cft.ts の lawyer と同じ扱い。
  //   ★辞書の 弁護士職務基本規程 は日弁連の会規 (法律ではない) のため法令名には入れない。
  //   ★マイナンバー法は辞書 regulations に無いため入れない (professional 分岐との違い)。
  'law-firm': 'law_firm',

  // ---------------------------------------------------------------------------
  // (b) 拡張法令 (laws_extended.ts recommendExtendedLaws) の分岐へ寄せるもの
  //     ★2026-08-14 追加。
  //
  //     【直した欠陥 — 直す前の実測】
  //       拡張法令の分岐は 15 件あるのに、114 業種を全通しで呼んで実際に発火したのは
  //       6 件だけだった (construction / manufacturing / food_service / healthcare /
  //       retail / bridal)。残る 9 件 (beauty / real_estate / hotel / childcare /
  //       education / advertising / logistics / transport / it) は、その分岐名に
  //       当たる業種名が本表に無いため **一度も発火しない死んだ分岐** だった。
  //       業種辞書には美容室も不動産も宿泊も保育も実在するのに、その業種で
  //       いちばん外せない業法 (薬機法・宅建業法・旅館業法・児童福祉法) が
  //       生成物の「該当法令」から丸ごと落ちていた。
  //
  //     【足す条件は (a) と同じ。推測で足さない】
  //       返る法令が業種辞書の regulations の記載と一致するか、返る実体の実装が
  //       その業種を名指ししていることを 1 件ずつ確認した。確認できない業種は
  //       足していない (足すと無関係な法令が顧客の画面に「該当法令」として出る)。
  //       ★本表に足しても KNOWN_INDUSTRY_KEYS には入らないため、コア法
  //         (recommendLaws) と適格簡易請求書 (canIssueSimplified) の判定は
  //         いずれも従来どおり (基本3法 / false) で変わらない。変わるのは
  //         拡張法令が返るようになる点と、その結果 fallsBackToBaseLaws が
  //         「基本3法だけ」ではなくなる点だけである。
  //
  // 美容室: 辞書の regulations に「医薬品医療機器等法 (薬機法)」「不当景品類及び
  //   不当表示防止法 (景品表示法)」を明記。分岐が返す2法と逐語で一致する。
  //   ★beauty-clinic (美容クリニック) は足さない。辞書の regulations は医療法
  //     (医療広告ガイドライン)・医師法であり、景品表示法の記載が無い。医療機関の
  //     広告規制は医療法側であって、機械的に寄せると誤った規制を提示する。
  'beauty-salon': 'beauty',
  // 不動産: 辞書の regulations 筆頭が「宅地建物取引業法」。分岐が返す法令と一致する。
  //   ★real-estate-portal / property-management も同法を掲げており同様に寄せられるが、
  //     本回は死んだ分岐の解消に必要な 1 件ずつに留めた (未追加であって不適格ではない)。
  'real-estate': 'real_estate',
  // 宿泊 (ホテル・旅館): 辞書の regulations に「旅館業法」「食品衛生法」を明記し、
  //   分岐が返す2法と一致する。「住宅宿泊事業法 (民泊新法)」も掲げており、
  //   実装側の RyokanGyo.isMinpaku (年間営業日数 180 日) と対応する。
  'hotel-ryokan': 'hotel',
  // 保育所: 辞書の regulations 筆頭が「児童福祉法」。分岐が返す法令と一致する。
  'nursery-school': 'childcare',
  // 学童保育 (放課後児童健全育成事業): 辞書の regulations 筆頭が
  //   「児童福祉法(放課後児童健全育成事業)」、category も education-welfare。
  //   ★childcare と education は同一の分岐 (どちらも児童福祉法だけを返す) であり、
  //     どちらの札に寄せても返る法令は変わらない。両業種とも辞書に児童福祉法がある。
  //   ★学校 (school)・学習塾 (cram-school)・語学学校 (language-school) は足さない。
  //     いずれも辞書の regulations に児童福祉法が無く (学校教育法・特定商取引法)、
  //     寄せると学校に児童福祉法を「該当法令」として提示することになる。
  'after-school-care': 'education',
  // SNSマーケティング代理店: 景品表示法は辞書の regulations に「景品表示法 (ステマ規制)
  //   第5条第3号・令和5年告示第19号」として明記されており一致する。
  //   ★薬機法は辞書の regulations に記載が無い。寄せる根拠は、薬機法第66条 (誇大広告等)
  //     が「何人も」を名宛人とし広告を作成・依頼する事業者を直接規制すること、および
  //     分岐が返す実体 Yakkiho.forbiddenMedicalClaims() が広告表現の禁止例そのもので
  //     あることによる。★辞書側に記載が無い点は隠さずここに残す (owner 再判断用)。
  'sns-marketing-agency': 'advertising',
  // 物流 (運送): 辞書の regulations は貨物自動車運送事業法・改善基準告示等であり、
  //   労働安全衛生法の記載は無い。寄せる根拠は、分岐が返す実体
  //   AnzenEisei.safetyManagerRequiredIndustries() が「運輸業」を安全管理者選任業種
  //   として明記していること (安衛法施行令第2条)。産業医・ストレスチェックの
  //   50人以上要件は業種を問わず全事業場に及ぶため、誤った義務の提示にはならない。
  'logistics-trucking': 'logistics',
  // 運送 (トラック運送): 上と同じ根拠。
  //   ★moving-company / taxi-operator は category=transport を自ら宣言しており
  //     同様に寄せられるが、本回は 1 件ずつに留めた (未追加であって不適格ではない)。
  'trucking-transport': 'transport',
  // IT (プロジェクト管理・SES): 辞書の regulations に「労働者派遣事業の適正な運営の
  //   確保等に関する法律(労働者派遣法)」を明記し、その key_articles の
  //   「派遣期間制限 … 原則3年 (事業所単位・個人単位)」が実装の
  //   HakenHou.individualMaxYears() / workplaceMaxYears() = 3 と数値まで一致する。
  'project-management': 'it',

  // ---------------------------------------------------------------------------
  // (c) 2026-09-16 追加 (NX-26 既存業種の結線)
  //     足す条件は (a)(b) と同じで、さらに機械で落とせる条件を 3 つ課した。
  //     3 条件すべてを満たしたものだけを足している (調査器の実測に基づく)。
  //       ① その分岐が返す法令が、業種辞書の regulations に【全件】そのまま在る
  //       ② その分岐が弁別的である (返すのが業種を問わない法令だけ、ではない)
  //       ③ その業種の【筆頭法令】(regulations の先頭) が返る法令で覆われている
  //          … BLK-2「いちばん外せない法令が黙って欠落する」を機械で落とすための条件
  //     ★②が無いと、労働安全衛生法しか返さない logistics / transport 分岐へ
  //       「労安衛法が辞書にある」だけの業種が 20 件近く当たってしまう (恒真の突合になる)。
  //
  // 児童発達支援: 辞書の regulations 筆頭が「児童福祉法」。分岐が返す法令と一致する。
  //   ★辞書 2 番目の「障害者総合支援法」は本ライブラリに実装が無く返らない。
  //     網羅ではないことを判定台帳 industry-lane-judgment.json に開示している。
  'child-development-support': 'childcare',
  // EC (通信販売): 辞書の regulations 筆頭が「特定商取引に関する法律 (特定商取引法)」で、
  //   景品表示法・製造物責任法 (PL法) も辞書に実在する。retail 分岐が返す3法と一致する。
  //   ★retail はコア法の分岐キーでもあるため、Invoice.canIssueSimplified が false→true に変わる
  //     (通信販売は小売業であり適格簡易請求書の交付対象。retail-pos と同じ扱いになる)。
  'ecommerce': 'retail',
  // 製造実行システム (工場): 辞書の regulations に 労働安全衛生法・製造物責任法(PL法)・
  //   中小受託取引適正化法(旧 下請代金支払遅延等防止法)・労働基準法 が実在し、
  //   manufacturing 分岐が返すコア法 (下請法・PL法・労働基準法) と拡張法令
  //   (PL法・労働安全衛生法) の【全件】が辞書の記載で裏づけられる。
  'manufacturing-mes': 'manufacturing',

  // ---------------------------------------------------------------------------
  // (d) 2026-09-16 追加 (NX-26 第2波)。(c) の 3 条件をそのまま使い、①だけを
  //     次の一点で緩めた。緩めた事実と理由をここに残す (黙って緩めない)。
  //
  //     【緩和の内容】労働基準法・労働安全衛生法は、辞書の regulations に
  //       書かれていなくても「欠け」と数えない。
  //     【なぜ許されるか】この2法は事業の種類を問わず【労働者を使用する事業者すべて】に
  //       適用される (労基法9条・116条2項 / 労安衛法2条3号・5条以下)。したがって
  //       この2法が「該当法令」に出ることは、その業種にとって誤った法令の提示にならない。
  //       辞書に無いのは「適用されない」ではなく「業種固有ではないので書いていない」だけである。
  //     【緩めなかったもの】業種を選ぶ法令 (PL法・旅館業法・貸金業法・資金決済法 等) は
  //       従来どおり【辞書に在ること】を要求する。実測 (2026-09-16):
  //         ・bakery / catering / convenience-store は hotel 分岐で 旅館業法 が欠け → 足さない
  //         ・booking / cram-school / fitness / lms は retail 分岐で PL法 が欠け → 足さない
  //           (役務提供であり「製造物」が無い。PL法を該当法令に出すのは誤り)
  //         ・growth-capital-advisory / internal-control-audit は finance 分岐で
  //           貸金業法・資金決済法 が欠け → 足さない
  //         ・food-manufacturing は food_service 分岐で PL法 が欠け → 足さない
  //           (食品が製造物に当たるかの判断は当方では決めず、owner 判断として台帳へ残した)
  //
  // 産業機械製造 (個別受注生産・半導体製造装置): 辞書 regulations の筆頭が
  //   「製造物責任法(PL法)」で、下請代金支払遅延等防止法・労働安全衛生法も実在する。
  //   manufacturing 分岐が返す 下請法・PL法・労働安全衛生法 が辞書の記載で裏づけられ、
  //   残る 労働基準法 のみが上記の緩和に当たる。
  'industrial-machinery': 'manufacturing',
  // 機械等修理業・設備保守: 辞書 regulations に 労働安全衛生法 (筆頭)・
  //   下請代金支払遅延等防止法 (保守作業の外注)・製造物責任法(PL法) (交換部品・改造) が実在する。
  //   ★筆頭が労働安全衛生法であり、③の「筆頭が覆われる」は満たすものの、
  //     筆頭そのものが業種を問わない法令である。弁別性は 下請法・PL法 側で担保されている。
  'machinery-maintenance-service': 'manufacturing',
  // 紙器製造 (原価計算): 辞書 regulations の筆頭が「下請代金支払遅延等防止法」で、
  //   PL法・労働安全衛生法も実在する。manufacturing 分岐と正面から一致する。
  //   ★前回は「筆頭の表記照合で見送り」として owner 判断へ回っていたが、
  //     2026-09-16 に別名の正規化を通して測り直したところ 3 条件を満たした。
  'paper-carton-manufacturing-cost': 'manufacturing',
  // 卸売業・商社: 辞書 regulations の筆頭が「中小受託取引適正化法 (旧 下請代金支払遅延等防止法)」
  //   で、製造物責任法(PL法) も実在する (卸売業者は輸入者・表示製造業者としてPL法の名宛人になりうる)。
  //   残る 労働基準法・労働安全衛生法 の2件のみが上記の緩和に当たる。
  'wholesale-trading': 'manufacturing',
  // 自動車部品製造 (2026-10-18 / 判定台帳 L159 で判定し結線): 辞書 regulations の筆頭が
  //   中小受託取引適正化法 (旧 下請代金支払遅延等防止法) で、製造物責任法・労働安全衛生法も実在する。
  //   manufacturing 分岐が返す 取適法・PL法・労働安全衛生法 が辞書の記載で裏づけられ、
  //   残る 労働基準法 のみが上記 (d) の緩和に当たる。★辞書の 道路運送車両法・化審法/化管法 は
  //   本ライブラリに受け皿の分岐が無く返らない (網羅ではないことを判定台帳に開示)。
  'auto-parts-manufacturing': 'manufacturing',
  // 汎用機械器具製造 (2026-10-18 / 同上): 辞書 regulations の筆頭が 労働安全衛生法 (ボイラー及び
  //   圧力容器安全規則) で、製造物責任法(PL法)・中小受託取引適正化法 も実在する。
  //   ★筆頭が業種を問わない法令である点は machinery-maintenance-service と同じで、弁別性は
  //     取適法・PL法 側で担保されている。辞書の 高圧ガス保安法・産業標準化法・電気用品安全法 は返らない。
  'general-purpose-machinery': 'manufacturing',
};

/** 法令判定が実際に分岐するキー。★この集合と下の switch を必ず一致させること。 */
const KNOWN_INDUSTRY_KEYS = new Set([
  'construction', 'manufacturing', 'healthcare', 'professional',
  'retail', 'food_service', 'finance', 'industrial_waste', 'law_firm',
]);

export function normalizeIndustryKey(industry: string): string {
  if (!industry) return industry;
  const raw = industry.trim();
  // ★2026-08-13 是正: 別名表の参照を小文字化していなかったため、'Retail-POS' は
  //   別名に当たらず既定 (基本3法) へ落ち、一方 'FOOD-SERVICE' は下の snake 化経路で
  //   正しく当たっていた。同じ大文字混在なのに寄せ先が別名か分岐キー本体かで結果が
  //   変わる不一致になっており、簡易課税セレクタ (slug を小文字化する) との間でも
  //   同じ業種名の判定が食い違っていた。
  const alias = INDUSTRY_KEY_ALIASES[raw.toLowerCase()];
  if (alias) return alias;
  // 表記ゆれだけの不一致 (kebab-case ↔ snake_case) は寄せる。
  //   ★寄せた先が実在する分岐キーのときだけ採用する。実在しないキーへ寄せると、
  //     既定へ落ちるのと同じでありながら「寄せた」ように見えて紛らわしい。
  const snake = raw.toLowerCase().replace(/-/g, '_');
  if (KNOWN_INDUSTRY_KEYS.has(snake)) return snake;
  // ★2026-08-14 是正 (2026-08-13 の是正の残り半分):
  //   上の集合はコア法 (recommendLaws) の分岐キーだけを持つため、拡張法令にしか
  //   分岐が無いキー (bridal 等) はここを素通りし、生の表記のまま返っていた。
  //   その結果 'bridal' は旅館業法・食品衛生法を返すのに 'Bridal' は 0 件という、
  //   2026-08-13 に直したのと同型の「大文字小文字で結果が変わる」不一致が残っていた。
  //   ★キーの一覧をここに書き写さない。分岐そのものを呼んで実在を確かめる
  //     (一覧を二重に持つと、片方だけが古くなって同じ死に方をする)。
  if (recommendExtendedLaws(snake).length > 0) return snake;
  return raw;
}

/**
 * 正規化しても既定 (基本3法) に落ちる業種かどうか。画面での開示に使う。
 *
 * ★2026-08-14 是正: 従来はコア法の分岐キー集合だけを見ていたため、拡張法令が
 *   実際に返っている業種まで「未登録 (基本3法だけ)」と申告していた
 *   (実測: bridal は旅館業法・食品衛生法の2法が返るのに true)。
 *   コア法と拡張法令の両方が空振りしたときだけが「基本3法だけ」である。
 *
 * ★この値が false でも「その業種の法令を網羅している」意味ではない。
 *   意味するのは「基本3法に加えて業種固有の法令が最低1件は返っている」ことだけで、
 *   本ライブラリに実装が無い業法 (例: 美容師法・獣医師法) は返らないままである。
 */
export function fallsBackToBaseLaws(industry: string): boolean {
  const key = normalizeIndustryKey(industry);
  return !KNOWN_INDUSTRY_KEYS.has(key) && recommendExtendedLaws(key).length === 0;
}

export function recommendLaws(industry: string): string[] {
  const base = ['インボイス制度', '電子帳簿保存法', '個人情報保護法'];
  switch (normalizeIndustryKey(industry)) {
    case 'construction':
      // 建設業界コア3法 (建築士法/建築基準法/建設業法) + 拡張8法 (取適法 (旧 下請法)/建築物省エネ法/都市計画法/耐震改修促進法/バリアフリー法/建設リサイクル法/住宅品質確保促進法/消防法) + 労基法.
      // 消防法は H3 で追加 (第17条 消防用設備等 + 第8条 防火管理者. 設備図・防火区画設計の前提法令).
      // 建築物省エネ法は 2025年4月改正で全新築 (原則 10 ㎡超) 適合義務化.
      // 各法令の条文番号・規模閾値・工程フェーズとの対応は construction-knowledge レーンに集約.
      return [
        ...base,
        '建築士法',
        '建築基準法',
        '建設業法',
        // 建設工事の再委託には取適法は適用されない (第2条4項)。設計・図面作成・資材製造の委託などに適用され得る。
        '取適法 (旧 下請法)',
        '労働基準法',
        '建築物省エネ法',
        '都市計画法',
        '耐震改修促進法',
        'バリアフリー法',
        '建設リサイクル法',
        '住宅品質確保促進法',
        '消防法',
      ];
    case 'manufacturing':
      return [...base, '取適法 (旧 下請法)', 'PL法', '労働基準法'];
    case 'healthcare':
      return [...base, 'マイナンバー法', '医療法', '介護保険法'];
    case 'professional':
      return [...base, 'マイナンバー法', '士業法', '労働基準法'];
    // ★2026-10-18 追加 (法律事務所)。根拠は上の別名表 'law-firm' の注記を参照。
    case 'law_firm':
      return [...base, '弁護士法', '民事訴訟法', '総合法律支援法', '犯罪収益移転防止法'];
    case 'retail':
      return [...base, '景品表示法', '特定商取引法'];
    case 'food_service':
      return [...base, '食品衛生法', '景品表示法'];
    case 'finance':
      return [...base, '金融商品取引法', '貸金業法', '資金決済法'];
    // ★2026-08-11 追加 (全結線計画 第3群)。lib/japan/waste.ts が廃棄物処理法
    //   (S45法律137) の産廃20種・特別管理の性状判定・12条の3のマニフェスト90日/180日・
    //   14条の許可5年更新を実装しており、業種辞書 industrial-waste の regulations と
    //   直接対応することを確認したうえで追加した。
    //   ★確認していない法令 (建設リサイクル法・フロン排出抑制法) はここに書かない。
    //     解体工事や第一種特定製品を扱うかは事業者ごとに異なり、一律に「該当法令」として
    //     出すと誤った義務を提示することになる。
    case 'industrial_waste':
      return [...base, '廃棄物処理法'];
    default:
      return base;
  }
}
