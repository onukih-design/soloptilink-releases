/**
 * lib/japan/farm_tax.ts — 農業の消費税・インボイス (出荷経路別) と青色申告 (農業所得用) の仕訳・部門別収支 (REQ-161 / JPO-IND-138)
 *
 * 2026-10-03 (JPO-T33) 新設。
 *   - 出荷経路ごとに、出荷者 (農家) の適格請求書の交付義務・免除の根拠・媒介者交付の可否を判定する
 *     (消費税法施行令70条の9第2項2号イ・ロ = 卸売市場特例・農協特例 / 70条の12 = 媒介者交付特例)
 *   - 免税事業者等からの仕入れの控除割合 (経過措置)・2割特例・3割特例・簡易課税のみなし仕入率は
 *     lib/japan/tax-calendar.json (正本) を読む。ここに値を書き写さない
 *   - 簡易課税の納付税額の参考計算 (令和9年4月1日からの飲食料品の税率引下げを含む期間は値が無いため計算しない)
 *   - 青色申告決算書 (農業所得用) の科目で仕訳を作り、部門別の収支を集計する
 * 税務申告書の作成・税務相談は税理士の業務 (税理士法第52条)。出力には必ずその線引きの文言を付ける。
 */
import taxCalendar from './tax-calendar.json';
import { PROFESSIONAL_BOUNDARY } from './primary_industry_ledger';

type Period = { effective_from: string; effective_to: string | null; deduction_ratio?: number; label?: string; wareki?: string };
const CT = (taxCalendar as any).consumption_tax as {
  invoice_transitional_measures: { periods: Period[] };
  two_percent_special: { effective_from: string; effective_to: string };
  three_percent_special?: { taxpayer_kinds: string[]; tax_years: number[]; base_period_sales_ceiling: number; deemed_deduction_ratio: number };
  simplified_deemed_rate: { categories: Record<string, { rate: number; name_ja: string }> };
};

export const FARM_TAX_BOUNDARY_NOTICE = PROFESSIONAL_BOUNDARY.zeirishi;

/** 飲食料品の税率引下げ期間 (国税庁 タックスアンサー No.6509 の注記。引下げ後の税率・簡易課税の特例の値は値表に無い) */
const FOOD_RATE_CUT = { from: '2027-04-01', to: '2029-03-31', source: '国税庁 タックスアンサー No.6509 (令和8年4月1日現在法令等) の注記' };

// ============================================================================
// 1. 出荷経路別のインボイス
// ============================================================================
export type FarmShippingRoute =
  | 'ja_consignment' // 農協・漁協・森林組合への販売委託
  | 'wholesale_market_consignment' // 卸売市場への販売委託
  | 'direct_sales_shop_consignment' // 直売所・道の駅への委託販売
  | 'direct_to_business' // 業者への直接販売
  | 'direct_to_consumer'; // 消費者への直接販売

export interface FarmInvoiceRouteInput {
  route: FarmShippingRoute;
  /** 出荷者 (農家) が適格請求書発行事業者か */
  producerRegistered: boolean;
  /** 農協への委託: 販売条件を付さない (無条件委託) か */
  unconditional?: boolean;
  /** 農協への委託: 共同計算 (財務省令で定める方法の精算) か */
  pooledSettlement?: boolean;
  /** 卸売市場: 中央卸売市場・地方卸売市場の認定等を受けた市場か */
  marketCertified?: boolean;
  /** 卸売市場: 卸売市場法2条1項の生鮮食料品等 (野菜・果実・魚類・肉類・花き等) か */
  isMarketPerishableGoods?: boolean;
  /** 農協・市場・直売所 (媒介者等) が適格請求書発行事業者か */
  intermediaryRegistered?: boolean;
}

export interface FarmInvoiceRouteResult {
  /** 出荷者自身に適格請求書の交付義務があるか (未登録の出荷者は交付できないため false) */
  producerMustIssue: boolean;
  /** 免除の特例が適用されるか */
  exemption: 'ja_special' | 'market_special' | 'none';
  /** 媒介者等が出荷者に代わって交付できるか (70条の12) */
  intermediaryCanIssue: boolean;
  issuer: string;
  buyerNote: string;
  basis: string[];
  unverified: string[];
  taxBoundaryNotice: string;
}

export function judgeFarmInvoiceRoute(i: FarmInvoiceRouteInput): FarmInvoiceRouteResult {
  const res: FarmInvoiceRouteResult = {
    producerMustIssue: false,
    exemption: 'none',
    intermediaryCanIssue: false,
    issuer: '',
    buyerNote: '',
    basis: [],
    unverified: [],
    taxBoundaryNotice: FARM_TAX_BOUNDARY_NOTICE,
  };
  const mediator = (who: string) => {
    res.intermediaryCanIssue = !!(i.producerRegistered && i.intermediaryRegistered);
    if (res.intermediaryCanIssue) {
      res.basis.push('消費税法施行令70条の12 (媒介者交付特例: 出荷者と媒介者等がともに適格請求書発行事業者)');
      res.issuer = `出荷者に交付義務があります。${who}が出荷者から登録の通知を受けていれば、${who}が代わって交付できます (媒介者交付特例)。`;
    }
  };
  if (i.route === 'ja_consignment' && i.unconditional && i.pooledSettlement) {
    res.exemption = 'ja_special';
    res.basis.push('消費税法施行令70条の9第2項第2号ロ (農協特例: 無条件委託・共同計算による農林水産物の譲渡)');
    res.issuer = '出荷者は適格請求書の交付を要しません (農協特例)。';
    res.buyerNote = '買手には組合 (農協・漁協・森林組合) が書類を交付する扱いです。買手の仕入税額控除の要件の細部は国税庁の資料で確認してください。';
    if (!i.producerRegistered) res.unverified.push('免税事業者の組合員の農産物が共同計算に含まれる場合の買手側の扱いは、一次資料で確認できていません (要一次確認・税理士に確認)。');
    return res;
  }
  if (i.route === 'wholesale_market_consignment' && i.marketCertified && i.isMarketPerishableGoods) {
    res.exemption = 'market_special';
    res.basis.push('消費税法施行令70条の9第2項第2号イ (卸売市場特例: 認定卸売市場で卸売業者が委託を受けて行う生鮮食料品等の卸売)');
    res.issuer = '出荷者は適格請求書の交付を要しません (卸売市場特例)。';
    res.buyerNote = '買手には卸売業者が書類を交付する扱いです。買手の仕入税額控除の要件の細部は国税庁の資料で確認してください。';
    if (!i.producerRegistered) res.unverified.push('免税事業者の出荷者の場合の買手側の扱いは、一次資料で確認できていません (要一次確認・税理士に確認)。');
    return res;
  }
  // 特例なし
  if (i.route === 'ja_consignment') res.basis.push('消費税法施行令70条の9第2項第2号ロ に当たらない (条件付き委託又は共同計算でない)');
  if (i.route === 'wholesale_market_consignment') res.basis.push('消費税法施行令70条の9第2項第2号イ に当たらない (認定を受けた卸売市場でない又は生鮮食料品等でない)');
  res.producerMustIssue = !!i.producerRegistered;
  if (i.producerRegistered) {
    res.basis.push('消費税法57条の4第1項 (適格請求書発行事業者の交付義務)');
    res.issuer = '出荷者 (農家) が買手の求めに応じて適格請求書を交付します。';
    if (i.route === 'ja_consignment') mediator('農協');
    if (i.route === 'wholesale_market_consignment') mediator('卸売業者');
    if (i.route === 'direct_sales_shop_consignment') mediator('直売所');
    res.buyerNote = i.route === 'direct_to_consumer'
      ? '消費者への販売でも、課税事業者の買手から求められたときは適格請求書の交付が要ります (適格簡易請求書で足りるかは事業の内容で異なるため要確認)。'
      : '買手は適格請求書の保存で仕入税額控除ができます。';
    if (i.route === 'direct_to_consumer') res.unverified.push('消費者向けの直接販売で適格簡易請求書 (レシート型) を使えるかは一次資料で確認できていません (要一次確認)。');
  } else {
    res.issuer = '出荷者は適格請求書発行事業者ではないため、適格請求書を交付できません。';
    res.buyerNote = '買手 (課税事業者) は、課税仕入れの日に応じた経過措置の割合だけ控除できます (buyerCreditRatioForUnregisteredPurchase で確認)。';
    res.basis.push('平成28年改正法附則52条・53条 (免税事業者等からの仕入れの経過措置)');
  }
  return res;
}

// ============================================================================
// 2. 免税事業者等からの仕入れの控除割合 (課税仕入れの日で引く)
// ============================================================================
export function buyerCreditRatioForUnregisteredPurchase(purchaseDate: string): { status: 'ok' | 'before_invoice_system' | 'invalid'; ratio: number | null; label: string; explanation: string } {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(purchaseDate)) return { status: 'invalid', ratio: null, label: '', explanation: '課税仕入れの日を YYYY-MM-DD で入力してください。' };
  const ps = CT.invoice_transitional_measures.periods;
  const p = ps.find((x) => purchaseDate >= x.effective_from && (x.effective_to === null || purchaseDate <= x.effective_to));
  if (!p) {
    return { status: 'before_invoice_system', ratio: null, label: 'インボイス制度の開始前', explanation: `${purchaseDate} はインボイス制度 (2023-10-01 開始) の前の仕入れで、経過措置の割合は使いません。` };
  }
  const pct = Math.round((p.deduction_ratio ?? 0) * 100);
  const range = `${p.effective_from}〜${p.effective_to ?? ''}`;
  const explanation = pct > 0
    ? `${purchaseDate} の仕入れは経過措置「${p.label}」の期間 (${range}) です。免税事業者等からの課税仕入れは、仕入税額相当額の${pct}%を控除できます (区分記載請求書等と同様の記載のある請求書と帳簿の保存が要件)。`
    : `${purchaseDate} の仕入れは経過措置の終了後 (${p.effective_from}〜) で、免税事業者等からの課税仕入れは控除できません (0%)。`;
  return { status: 'ok', ratio: p.deduction_ratio ?? 0, label: p.label ?? '', explanation };
}

// ============================================================================
// 3. 簡易課税の事業区分と納付税額の参考計算
// ============================================================================
export function farmSimplifiedCategory(item: { isFood: boolean }): { category: 2 | 3; deemedRate: number; nameJa: string } {
  const cat = item.isFood ? 2 : 3;
  const c = CT.simplified_deemed_rate.categories[String(cat)];
  return { category: cat, deemedRate: c.rate, nameJa: c.name_ja };
}

export interface FarmSimplifiedTaxInput {
  periodStart: string;
  periodEnd: string;
  sales: { amountExclTax: number; rate: 0.08 | 0.1; isFood: boolean }[];
}
export interface FarmSimplifiedTaxResult {
  status: 'ok' | 'unsupported' | 'invalid';
  nationalTax?: number;
  localTax?: number;
  totalTax?: number;
  message: string;
  notes: string[];
  taxBoundaryNotice: string;
}

/**
 * 簡易課税 (原則計算) の参考計算。課税標準額は税率ごとに千円未満切捨て・国税は 6.24% (軽減) / 7.8% (標準)・
 * 控除 = 事業区分ごとの売上の国税 × みなし仕入率・差引税額は百円未満切捨て・地方消費税 = 差引 × 22/78 (百円未満切捨て)。
 * 【端数処理・特例計算 (75%ルール等) の最終判断は要税理士確認】
 */
export function calcFarmSimplifiedTax(i: FarmSimplifiedTaxInput): FarmSimplifiedTaxResult {
  const notes = ['端数処理と、2種類以上の事業を営む場合の特例計算 (75%ルール) は考慮していません。最終の税額は税理士・申告書の様式で確認してください (要税理士確認)。'];
  if (!i || !i.periodStart || !i.periodEnd || i.periodStart > i.periodEnd) return { status: 'invalid', message: '課税期間の開始日と終了日を入力してください。', notes, taxBoundaryNotice: FARM_TAX_BOUNDARY_NOTICE };
  const overlapsCut = i.periodStart <= FOOD_RATE_CUT.to && i.periodEnd >= FOOD_RATE_CUT.from;
  if (overlapsCut && i.sales.some((s) => s.isFood)) {
    return {
      status: 'unsupported',
      message: `課税期間が飲食料品の税率引下げ期間 (${FOOD_RATE_CUT.from}〜${FOOD_RATE_CUT.to}) を含み、飲食料品の売上があります。引下げ後の税率と簡易課税の計算方法の特例の値が値表に無いため計算しません (${FOOD_RATE_CUT.source})。`,
      notes,
      taxBoundaryNotice: FARM_TAX_BOUNDARY_NOTICE,
    };
  }
  const NAT: Record<string, number> = { '0.08': 624, '0.1': 780 }; // 国税分 (1/10000)
  let national = 0;
  for (const rate of ['0.08', '0.1']) {
    const base = i.sales.filter((s) => String(s.rate) === rate).reduce((a, s) => a + s.amountExclTax, 0);
    const kazei = Math.floor(base / 1000) * 1000;
    national += Math.floor((kazei * NAT[rate]) / 10000);
  }
  let deduction = 0;
  for (const s of i.sales) {
    const nat = Math.floor((s.amountExclTax * NAT[String(s.rate)]) / 10000);
    deduction += Math.floor(nat * farmSimplifiedCategory({ isFood: s.isFood }).deemedRate);
  }
  const diff = Math.floor(Math.max(0, national - deduction) / 100) * 100;
  const local = Math.floor((diff * 22) / 78 / 100) * 100;
  return { status: 'ok', nationalTax: diff, localTax: local, totalTax: diff + local, message: '簡易課税の参考計算です。', notes, taxBoundaryNotice: FARM_TAX_BOUNDARY_NOTICE };
}

// ============================================================================
// 4. 2割特例・3割特例
// ============================================================================
export function judgeFarmSpecialTaxRelief(i: { kind: 'individual' | 'corporation'; periodStart: string; periodEnd: string; basePeriodSales: number }): { twoPercent: boolean; threePercent: boolean; message: string; taxBoundaryNotice: string } {
  const tp = CT.two_percent_special;
  const two = i.periodStart <= tp.effective_to && i.periodEnd >= tp.effective_from;
  const th = CT.three_percent_special;
  const year = Number(i.periodStart.slice(0, 4));
  const three = !two && !!th && th.taxpayer_kinds.includes(i.kind) && th.tax_years.includes(year) && i.periodStart.slice(5) === '01-01' && i.basePeriodSales <= th.base_period_sales_ceiling;
  const msg = two
    ? '2割特例の対象期間です (免税事業者からインボイス登録により課税事業者になった場合に限る)。'
    : three
      ? '3割特例 (個人の令和9年分・令和10年分) の対象です (免税事業者からインボイス登録により課税事業者になった場合に限る)。'
      : '2割特例・3割特例の対象ではありません。';
  return { twoPercent: two, threePercent: three, message: msg, taxBoundaryNotice: FARM_TAX_BOUNDARY_NOTICE };
}

// ============================================================================
// 5. 青色申告 (農業所得用) の仕訳と部門別収支
// ============================================================================
/** 青色申告決算書 (農業所得用) の損益の科目 (国税庁の様式) */
export const FARM_BLUE_RETURN_ACCOUNTS = {
  revenue: ['販売金額', '家事消費・事業消費金額', '雑収入'] as const,
  expense: ['租税公課', '種苗費', '素畜費', '肥料費', '飼料費', '農具費', '農薬・衛生費', '諸材料費', '修繕費', '動力光熱費', '作業用衣料費', '農業共済掛金', '減価償却費', '荷造運賃手数料', '雇人費', '利子割引料', '地代・賃借料', '土地改良費', '雑費'] as const,
};
export type FarmExpenseAccount = (typeof FARM_BLUE_RETURN_ACCOUNTS.expense)[number];
type BsAccount = '普通預金' | '現金' | '売掛金' | '未払金' | '事業主貸' | '事業主借' | '減価償却累計額';

export type FarmTransaction =
  | { kind: 'ja_settlement'; date: string; department: string; gross: number; deductions: { account: FarmExpenseAccount; amount: number }[] }
  | { kind: 'direct_sale'; date: string; department: string; amount: number; receivedBy?: '現金' | '普通預金' | '売掛金' }
  | { kind: 'home_consumption'; date: string; department: string; amount: number }
  | { kind: 'subsidy'; date: string; department: string; amount: number }
  | { kind: 'expense'; date: string; department: string; account: FarmExpenseAccount; amount: number; paidBy: 'cash' | 'bank' | 'payable' | 'owner' }
  | { kind: 'depreciation'; date: string; department: string; amount: number };

export interface FarmJournalEntry {
  date: string;
  department: string;
  description: string;
  lines: { account: string; debit: number; credit: number }[];
  errors?: string[];
}

const PAY: Record<string, BsAccount> = { cash: '現金', bank: '普通預金', payable: '未払金', owner: '事業主借' };
const isInt = (n: unknown) => typeof n === 'number' && Number.isInteger(n) && n >= 0;

export function buildFarmJournal(t: FarmTransaction): FarmJournalEntry {
  const e: FarmJournalEntry = { date: t.date, department: t.department, description: '', lines: [] };
  const err = (m: string) => ({ ...e, lines: [], errors: [m] });
  switch (t.kind) {
    case 'ja_settlement': {
      const ded = t.deductions.reduce((s, d) => s + d.amount, 0);
      if (!isInt(t.gross) || t.deductions.some((d) => !isInt(d.amount))) return err('金額は0以上の整数 (円) で入力してください。');
      if (ded > t.gross) return err(`差し引かれた額 (${ded}円) が販売金額 (${t.gross}円) を超えています。精算書を確かめてください。`);
      e.description = '農協の販売精算 (販売金額は総額で計上し、手数料・運賃・資材代は経費へ)';
      if (t.gross - ded > 0) e.lines.push({ account: '普通預金', debit: t.gross - ded, credit: 0 });
      for (const d of t.deductions) if (d.amount > 0) e.lines.push({ account: d.account, debit: d.amount, credit: 0 });
      e.lines.push({ account: '販売金額', debit: 0, credit: t.gross });
      return e;
    }
    case 'direct_sale':
      if (!isInt(t.amount) || t.amount <= 0) return err('金額は1円以上の整数で入力してください。');
      e.description = '直接販売';
      e.lines.push({ account: t.receivedBy ?? '現金', debit: t.amount, credit: 0 }, { account: '販売金額', debit: 0, credit: t.amount });
      return e;
    case 'home_consumption':
      if (!isInt(t.amount) || t.amount <= 0) return err('金額は1円以上の整数で入力してください。');
      e.description = '家事消費 (収穫した時の生産者販売価額で計上)';
      e.lines.push({ account: '事業主貸', debit: t.amount, credit: 0 }, { account: '家事消費・事業消費金額', debit: 0, credit: t.amount });
      return e;
    case 'subsidy':
      if (!isInt(t.amount) || t.amount <= 0) return err('金額は1円以上の整数で入力してください。');
      e.description = '交付金等 (雑収入。収入保険の対象収入では販売金額に含めるものがある)';
      e.lines.push({ account: '普通預金', debit: t.amount, credit: 0 }, { account: '雑収入', debit: 0, credit: t.amount });
      return e;
    case 'expense':
      if (!isInt(t.amount) || t.amount <= 0) return err('金額は1円以上の整数で入力してください。');
      if (!(FARM_BLUE_RETURN_ACCOUNTS.expense as readonly string[]).includes(t.account)) return err(`「${t.account}」は青色申告決算書 (農業所得用) の科目にありません。`);
      e.description = `経費 (${t.account})`;
      e.lines.push({ account: t.account, debit: t.amount, credit: 0 }, { account: PAY[t.paidBy] ?? '現金', debit: 0, credit: t.amount });
      return e;
    case 'depreciation':
      if (!isInt(t.amount) || t.amount <= 0) return err('金額は1円以上の整数で入力してください。');
      e.description = '減価償却費';
      e.lines.push({ account: '減価償却費', debit: t.amount, credit: 0 }, { account: '減価償却累計額', debit: 0, credit: t.amount });
      return e;
  }
  return err('取引の種類が分かりません。');
}

export interface FarmDepartmentPL {
  departments: { name: string; revenue: number; expense: number; profit: number }[];
  total: { revenue: number; expense: number; profit: number };
  consistent: boolean;
  taxBoundaryNotice: string;
}

/** 部門別の収支 (部門に属さない共通の費用は「共通」部門として出す。部門の和＝全体) */
export function departmentProfitAndLoss(entries: FarmJournalEntry[]): FarmDepartmentPL {
  const REV = new Set<string>(FARM_BLUE_RETURN_ACCOUNTS.revenue);
  const EXP = new Set<string>(FARM_BLUE_RETURN_ACCOUNTS.expense);
  const map = new Map<string, { revenue: number; expense: number }>();
  let tr = 0;
  let te = 0;
  for (const e of entries) {
    if (e.errors && e.errors.length) continue;
    const d = e.department || '共通';
    const cur = map.get(d) ?? { revenue: 0, expense: 0 };
    for (const l of e.lines) {
      if (REV.has(l.account)) { cur.revenue += l.credit - l.debit; tr += l.credit - l.debit; }
      if (EXP.has(l.account)) { cur.expense += l.debit - l.credit; te += l.debit - l.credit; }
    }
    map.set(d, cur);
  }
  const departments = [...map.entries()].map(([name, v]) => ({ name, revenue: v.revenue, expense: v.expense, profit: v.revenue - v.expense }));
  const sr = departments.reduce((s, x) => s + x.revenue, 0);
  const se = departments.reduce((s, x) => s + x.expense, 0);
  return { departments, total: { revenue: tr, expense: te, profit: tr - te }, consistent: sr === tr && se === te, taxBoundaryNotice: FARM_TAX_BOUNDARY_NOTICE };
}
