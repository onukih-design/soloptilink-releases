/**
 * lib/japan/hoiku_safety_alerts.ts — 保育の安全アラート (午睡のチェック・送迎バスの置き去り防止・閉所超過の未降園)
 *
 * 2026-10-04 新設 (要件 REQ-133 / JPO-IND-110・REQ-436 / JPO-NFR-037)。
 * 生成するアプリの見守り画面・通知の巡回は、この部品の評価関数を一定間隔 (例: 15秒ごと) で呼び、返った発報を出す。
 * 評価関数は「いまの時刻」を引数で受け取る純粋な関数にしてあり、時計を進める試験で発報の時刻を測れる。
 *
 * 【出典 — 一次情報】
 *  ・こども家庭庁 成育局 事務連絡「教育・保育施設等における睡眠中の安全確保の徹底について」(令和6年2月8日)
 *    別紙 = 「教育・保育施設等における事故防止及び事故発生時の対応のためのガイドライン【事故防止のための取組み】
 *    ～施設・事業者向け～」(平成28年3月) の抜粋:「子どもの数、職員の数に合わせ、定期的に子どもの呼吸・体位、
 *    睡眠状態を点検すること」 https://www.cfa.go.jp/policies/child-safety/effort/guideline/
 *    ★国のガイドラインは点検の間隔 (分) を定めていない。
 *  ・横浜市こども青少年局 こ保運第37号 (令和5年4月17日)「必ずブレスチェックを行い一人ひとり記録する
 *    【０歳児は５分に１回、１歳児は10分に１回】」
 *  ・こども家庭庁 事務連絡に添付された自治体の事故防止マニュアル (基礎編)「0歳児は５分毎・１歳児以上は１０分毎」
 *    → 既定は 0歳 5分・1〜2歳 10分 (要件 JPO-IND-110 の受入条件どおり)。
 *    → 3歳以上は一次資料に間隔が無いため既定値を置かない。園が設定した値で動かし、未設定なら「設定が必要」を発報する
 *      (受入基準書 JPO-IND-110 の確認待ち RU22)。
 *  ・児童福祉施設の設備及び運営に関する基準 第6条の3 (令和4年改正): 自動車を運行するときは乗車・降車の際に点呼等で
 *    所在を確認する / 通園を目的とした自動車にはブザー等の見落とし防止装置を備え、降車の際の確認を行う。
 *    → 到着 (予定と実到着の早い方) から園の設定した分までに「乗った全員の降車」と「車内の確認」がそろわなければ発報する。
 *      設定分の法定値は無いので、未設定・不正な値は 0分 (到着の時刻) として扱う (いちばん早い側)。
 *  ・閉所時刻 (延長保育の申込みがあればその終わり) を過ぎて降園の記録が無い子は、園の設定した分までに発報する (既定 0分)。
 *
 * ★危険側の誤り (発報が遅れる・出ない) を作らないための決めごと:
 *   - 園の設定で 0〜2歳の間隔を既定より長くすることはできない (短くすることはできる)。
 *   - 年齢は「実年齢」と「クラスの年齢」の厳しい方 (若い方) で決める。実年齢は誕生日の当日に1つ上がるものとして数え、
 *     法律上の加齢 (誕生日の前日) より遅らせる (= 0歳の扱いを1日長くする)。
 *   - 生年月日・時刻が読めない子は、その時点で発報する。
 */

export type HoikuAlertType =
  | 'nap_check_due'
  | 'nap_check_overdue'
  | 'nap_interval_unconfigured'
  | 'nap_data_invalid'
  | 'bus_left_behind_risk'
  | 'bus_data_invalid'
  | 'closing_overstay'
  | 'closing_data_invalid';

export interface HoikuAlert {
  type: HoikuAlertType;
  child_id?: string;
  run_id?: string;
  /** 期限 (ISO 8601) */
  due_at: string | null;
  /** 発報した時刻 (評価した時刻) */
  fired_at: string;
  message_ja: string;
}

/** 午睡の点検の間隔の既定 (分)。3歳以上は既定を置かない (null)。 */
export const NAP_CHECK_INTERVAL_DEFAULTS = {
  age0_minutes: 5,
  age1to2_minutes: 10,
  age3plus_minutes: null,
} as const;

export interface NapCheckConfig {
  /** 0歳の間隔 (分)。既定の5分より短くだけできる */
  age0_interval_minutes?: number;
  /** 1〜2歳の間隔 (分)。既定の10分より短くだけできる */
  age1to2_interval_minutes?: number;
  /** 3歳以上の間隔 (分)。園が決めて設定する (既定なし) */
  age3plus_interval_minutes?: number | null;
  /** 期限の何秒前に「まもなく」を出すか (既定 60秒) */
  reminder_lead_seconds?: number;
}

const MIN_MS = 60 * 1000;
const JST_OFFSET_MS = 9 * 60 * MIN_MS;

function parseTime(s: unknown): number | null {
  if (typeof s !== 'string' || s.trim() === '') return null;
  const ms = Date.parse(s);
  return Number.isFinite(ms) ? ms : null;
}
function isoOf(ms: number): string {
  return new Date(ms).toISOString();
}
function parseBirth(s: unknown): { y: number; m: number; d: number } | null {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const [y, m, d] = s.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) return null;
  return { y, m, d };
}
function positiveMinutes(v: unknown): number | null {
  return typeof v === 'number' && Number.isFinite(v) && v > 0 ? v : null;
}
function nonNegativeMinutes(v: unknown): number {
  return typeof v === 'number' && Number.isFinite(v) && v > 0 ? v : 0;
}

/** 実年齢 (日本時間の日付で、誕生日の当日に1つ上がる) */
export function ageInYearsJst(birth_date: string, at: string | number): number | null {
  const b = parseBirth(birth_date);
  const t = typeof at === 'number' ? at : parseTime(at);
  if (!b || t === null) return null;
  const j = new Date(t + JST_OFFSET_MS);
  const y = j.getUTCFullYear();
  const m = j.getUTCMonth() + 1;
  const d = j.getUTCDate();
  let age = y - b.y;
  if (m < b.m || (m === b.m && d < b.d)) age -= 1;
  return age >= 0 ? age : null;
}

/** 子どもの点検の間隔 (分)。未設定の3歳以上は null。 */
export function napCheckIntervalMinutes(
  child: { birth_date: string; class_age?: number | null },
  at: string | number,
  cfg: NapCheckConfig = {},
): { interval_minutes: number | null; age_used: number | null; configured: boolean; basis_ja: string } {
  const D = NAP_CHECK_INTERVAL_DEFAULTS;
  const actual = ageInYearsJst(child && child.birth_date, at);
  const cls = typeof child?.class_age === 'number' && Number.isInteger(child.class_age) && child.class_age >= 0 ? child.class_age : null;
  if (actual === null && cls === null) {
    return { interval_minutes: null, age_used: null, configured: false, basis_ja: '生年月日・クラスの年齢が読めないため間隔を決められません。' };
  }
  // 厳しい方 (若い方) の年齢で決める。生年月日が読めないときはクラスの年齢だけに頼らず、判定できないものとして扱う。
  if (actual === null) {
    return { interval_minutes: null, age_used: null, configured: false, basis_ja: '生年月日が読めないため間隔を決められません。' };
  }
  const age = cls === null ? actual : Math.min(actual, cls);
  if (age <= 0) {
    const set = positiveMinutes(cfg.age0_interval_minutes);
    return { interval_minutes: set !== null ? Math.min(set, D.age0_minutes) : D.age0_minutes, age_used: age, configured: true, basis_ja: '0歳は5分に1回 (自治体の通知・マニュアル)。園の設定で短くだけできる。' };
  }
  if (age <= 2) {
    const set = positiveMinutes(cfg.age1to2_interval_minutes);
    return { interval_minutes: set !== null ? Math.min(set, D.age1to2_minutes) : D.age1to2_minutes, age_used: age, configured: true, basis_ja: '1〜2歳は10分に1回 (自治体の通知・マニュアル)。園の設定で短くだけできる。' };
  }
  const set3 = positiveMinutes(cfg.age3plus_interval_minutes);
  return set3 !== null
    ? { interval_minutes: set3, age_used: age, configured: true, basis_ja: '3歳以上は園の設定値 (国・自治体の一次資料に間隔の定めが見当たらないため既定値を置かない)。' }
    : { interval_minutes: null, age_used: age, configured: false, basis_ja: '3歳以上の点検間隔が設定されていません。園で決めて設定してください。' };
}

export interface SleepingChild {
  child_id: string;
  birth_date: string;
  class_age?: number | null;
  sleep_started_at: string;
  last_checked_at?: string | null;
  /** 起きた時刻。あれば発報の対象から外す */
  sleep_ended_at?: string | null;
}

/** 午睡中の子どもの発報を返す。now の時点で「まもなく」「期限切れ」「設定が必要」「記録が読めない」を出す。 */
export function evaluateNapAlerts(children: SleepingChild[], now: string, cfg: NapCheckConfig = {}): HoikuAlert[] {
  const out: HoikuAlert[] = [];
  const t = parseTime(now);
  if (t === null) return out;
  const leadSec = typeof cfg.reminder_lead_seconds === 'number' && Number.isFinite(cfg.reminder_lead_seconds) && cfg.reminder_lead_seconds >= 0
    ? cfg.reminder_lead_seconds : 60;
  for (const c of Array.isArray(children) ? children : []) {
    if (!c) continue;
    const ended = parseTime(c.sleep_ended_at);
    if (ended !== null && ended <= t) continue;
    const start = parseTime(c.sleep_started_at);
    if (start === null) {
      out.push({ type: 'nap_data_invalid', child_id: c.child_id, due_at: null, fired_at: isoOf(t), message_ja: '午睡の開始時刻が読めません。すぐに子どもの様子を確認してください。' });
      continue;
    }
    if (start > t) continue;
    const iv = napCheckIntervalMinutes(c, t, cfg);
    if (iv.interval_minutes === null) {
      out.push({
        type: iv.age_used === null ? 'nap_data_invalid' : 'nap_interval_unconfigured',
        child_id: c.child_id, due_at: null, fired_at: isoOf(t),
        message_ja: `${iv.basis_ja} 設定されるまでは、こまめに呼吸・体位を確認してください。`,
      });
      continue;
    }
    const lastRaw = c.last_checked_at;
    const last = lastRaw === null || lastRaw === undefined ? start : parseTime(lastRaw);
    if (last === null) {
      out.push({ type: 'nap_data_invalid', child_id: c.child_id, due_at: null, fired_at: isoOf(t), message_ja: '最後の点検の時刻が読めません。すぐに子どもの様子を確認してください。' });
      continue;
    }
    const due = Math.max(last, start) + iv.interval_minutes * MIN_MS;
    if (t > due) {
      out.push({ type: 'nap_check_overdue', child_id: c.child_id, due_at: isoOf(due), fired_at: isoOf(t), message_ja: `午睡の点検の期限 (${iv.interval_minutes}分ごと) を過ぎています。すぐに呼吸・体位を確認して記録してください。` });
    } else if (t >= due - leadSec * 1000) {
      out.push({ type: 'nap_check_due', child_id: c.child_id, due_at: isoOf(due), fired_at: isoOf(t), message_ja: `まもなく午睡の点検の時刻です (${iv.interval_minutes}分ごと)。` });
    }
  }
  return out;
}

export interface BusRunState {
  run_id: string;
  expected_arrival_at: string;
  actual_arrival_at?: string | null;
  boarded_child_ids: string[];
  alighted_child_ids: string[];
  /** 車内の確認 (ブザー等の見落とし防止装置を用いた確認) を終えた時刻 */
  vehicle_check_completed_at?: string | null;
}

/** 「全員降車」を確定できるか。乗った子が降車の記録に無い・名簿が空のときは確定させない。 */
export function confirmBusAllAlighted(run: BusRunState): { ok: boolean; missing_child_ids: string[]; reason_ja: string } {
  const boarded = Array.isArray(run?.boarded_child_ids) ? run.boarded_child_ids : [];
  const alighted = new Set(Array.isArray(run?.alighted_child_ids) ? run.alighted_child_ids : []);
  if (boarded.length === 0) return { ok: false, missing_child_ids: [], reason_ja: '乗車の記録がありません。乗車の点呼を記録してから確定してください。' };
  const missing = boarded.filter((id) => !alighted.has(id));
  if (missing.length) return { ok: false, missing_child_ids: missing, reason_ja: `降車の記録が無い子がいます (${missing.length}人)。車内を確認してください。` };
  return { ok: true, missing_child_ids: [], reason_ja: '乗った全員の降車を記録しました。' };
}

/** 送迎バスの置き去りの恐れの発報 */
export function evaluateBusLeftBehindAlerts(runs: BusRunState[], now: string, cfg: { grace_minutes?: number } = {}): HoikuAlert[] {
  const out: HoikuAlert[] = [];
  const t = parseTime(now);
  if (t === null) return out;
  const grace = nonNegativeMinutes(cfg.grace_minutes);
  for (const r of Array.isArray(runs) ? runs : []) {
    if (!r) continue;
    const exp = parseTime(r.expected_arrival_at);
    const act = parseTime(r.actual_arrival_at);
    if (exp === null && act === null) {
      out.push({ type: 'bus_data_invalid', run_id: r.run_id, due_at: null, fired_at: isoOf(t), message_ja: '到着予定の時刻が読めません。車内を確認してください。' });
      continue;
    }
    const arrival = Math.min(exp ?? Infinity, act ?? Infinity);
    const due = arrival + grace * MIN_MS;
    const allOff = confirmBusAllAlighted(r).ok;
    const checked = parseTime(r.vehicle_check_completed_at) !== null;
    if (allOff && checked) continue;
    if (t >= due) {
      out.push({
        type: 'bus_left_behind_risk', run_id: r.run_id, due_at: isoOf(due), fired_at: isoOf(t),
        message_ja: !allOff ? '降車の記録が無い子がいます。すぐに車内を確認してください。' : '車内の確認 (ブザー等) の記録がありません。すぐに車内を確認してください。',
      });
    }
  }
  return out;
}

export interface AttendanceState {
  child_id: string;
  checked_in_at?: string | null;
  checked_out_at?: string | null;
  /** 延長保育の申込みの終わりの時刻 */
  extended_care_until?: string | null;
}

/** 閉所時刻 (延長保育の終わり) を過ぎても降園の記録が無い子の発報 */
export function evaluateClosingOverstayAlerts(attendances: AttendanceState[], closing_at: string, now: string, cfg: { grace_minutes?: number } = {}): HoikuAlert[] {
  const out: HoikuAlert[] = [];
  const t = parseTime(now);
  const close = parseTime(closing_at);
  if (t === null) return out;
  const grace = nonNegativeMinutes(cfg.grace_minutes);
  for (const a of Array.isArray(attendances) ? attendances : []) {
    if (!a) continue;
    if (parseTime(a.checked_in_at) === null) continue; // 登園していない
    if (parseTime(a.checked_out_at) !== null) continue; // 降園済み
    if (close === null) {
      out.push({ type: 'closing_data_invalid', child_id: a.child_id, due_at: null, fired_at: isoOf(t), message_ja: '閉所時刻が読めません。在園の子どもを確認してください。' });
      continue;
    }
    const ext = parseTime(a.extended_care_until);
    const due = Math.max(close, ext ?? close) + grace * MIN_MS;
    if (t >= due) {
      out.push({ type: 'closing_overstay', child_id: a.child_id, due_at: isoOf(due), fired_at: isoOf(t), message_ja: '閉所時刻を過ぎても降園の記録がありません。在園の確認と保護者への連絡をしてください。' });
    }
  }
  return out;
}
