/**
 * 敬語変換ユーティリティ
 * 丁寧語・尊敬語・謙譲語の変換、ビジネス文書の定型文生成
 *
 * 2026-09-30 REQ-JPO-FIX-006: escalate() が部分一致の一括置換で原文を壊していた
 *   （「ありがとうございます」→「ありがとうございますございます」、「確認するため」→「確認いたすため」、
 *    「私が言う」→「私がおっしゃる」（自分の行為に尊敬語）、「思う人」→「存じます人」）。
 *   出典: 文化審議会答申「敬語の指針」（平成19年2月2日）第2章 第1 — 尊敬語は相手側・第三者の行為、
 *   謙譲語Ⅰ・Ⅱは自分側の行為に使う。主語が分からない文を尊敬語・謙譲語に変えると意味が変わるため、
 *   自動変換は【文末だけを丁寧語（です・ます）にする】範囲に限り、判断できない文は変えずに返す（壊すくらいなら変換しない）。
 *   宛名の敬称は atena.ts の唯一の処理を呼ぶ。
 */
import { formatAtena } from './atena';

export type KeigoLevel = 'plain' | 'polite' | 'respectful' | 'humble';

const VERB_MAP: Array<{ plain: string; polite: string; respectful: string; humble: string }> = [
  { plain: '言う', polite: '言います', respectful: 'おっしゃる', humble: '申し上げる' },
  { plain: '見る', polite: '見ます', respectful: 'ご覧になる', humble: '拝見する' },
  { plain: '行く', polite: '行きます', respectful: 'いらっしゃる', humble: '伺う' },
  { plain: '来る', polite: '来ます', respectful: 'いらっしゃる', humble: '参る' },
  { plain: 'いる', polite: 'います', respectful: 'いらっしゃる', humble: 'おる' },
  { plain: 'する', polite: 'します', respectful: 'なさる', humble: 'いたす' },
  { plain: '食べる', polite: '食べます', respectful: '召し上がる', humble: 'いただく' },
  { plain: '知る', polite: '知っています', respectful: 'ご存じ', humble: '存じ上げる' },
  { plain: 'くれる', polite: 'くれます', respectful: 'くださる', humble: '' },
  { plain: 'もらう', polite: 'もらいます', respectful: '', humble: 'いただく' },
  // 尊敬語の一般形「お(ご)……になる」（敬語の指針 第2章 第2の1）
  { plain: '会う', polite: '会います', respectful: 'お会いになる', humble: 'お目にかかる' },
  { plain: '聞く', polite: '聞きます', respectful: 'お聞きになる', humble: '伺う' },
];

/**
 * 基本動詞の敬語変換
 * ★その段階の形が辞書に無いときは空文字を返す（要確認）。以前は丁寧語へ黙って落としていた（会う→「会います」）。
 */
export function convertVerb(verb: string, level: KeigoLevel): string {
  const entry = VERB_MAP.find(e => e.plain === verb || e.polite === verb);
  if (!entry) return verb;
  if (level === 'plain') return entry.plain;
  return entry[level] || '';
}

/**
 * ビジネス定型文の生成
 */
export const BusinessPhrases = {
  greeting(time: 'morning' | 'day' | 'evening' | 'formal'): string {
    return {
      morning: 'おはようございます。',
      day: 'お世話になっております。',
      evening: '夜分失礼いたします。',
      formal: '拝啓 時下ますますご清栄のこととお慶び申し上げます。',
    }[time];
  },

  opening(context: 'reply' | 'initiate' | 'apology' | 'thanks'): string {
    return {
      reply: 'ご連絡いただき誠にありがとうございます。',
      initiate: '突然のご連絡失礼いたします。',
      apology: 'このたびはご迷惑をおかけし、誠に申し訳ございません。',
      thanks: '平素より格別のお引き立てを賜り、厚く御礼申し上げます。',
    }[context];
  },

  closing(level: 'standard' | 'formal' | 'urgent'): string {
    return {
      standard: '何卒よろしくお願い申し上げます。',
      formal: '今後とも倍旧のお引き立てのほど、よろしくお願い申し上げます。敬具',
      urgent: 'お忙しいところ恐縮ですが、何卒よろしくお願い申し上げます。',
    }[level];
  },

  invoiceNote(): string {
    return 'いつも格別のお引き立てを賜り、厚く御礼申し上げます。\n下記の通りご請求申し上げますので、お支払いくださいますようお願い申し上げます。';
  },

  estimateNote(): string {
    return '下記の通りお見積り申し上げます。\nご検討のほど、よろしくお願い申し上げます。';
  },
};

/**
 * 相手への呼称変換（本体は atena.ts）
 * - 組織宛ては「御中」。ただし「株式会社ABC 山田」のように個人名があれば「様」（敬語の指針【21】）
 * - 既に付いた敬称・「各位」は重ねない。返信用の「行」は外す
 */
export function companyHonorific(name: string, relationship: 'customer' | 'partner' | 'vendor' | 'self'): string {
  if (relationship === 'self') return `当社 (${name})`;
  return formatAtena(name, { kind: 'organization' });
}

export function personHonorific(name: string, title?: string): string {
  return title ? `${name} ${title}` : formatAtena(name, { kind: 'person' });
}

/**
 * 文を句点ごとに分け、各文の本体（句点の前）に fn を掛ける
 */
export function mapSentenceBodies(text: string, fn: (body: string) => string): string {
  const src = String(text ?? '');
  const out: string[] = [];
  const re = /([^。！？!?\n]*)([。！？!?\n]|$)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(src)) !== null) {
    if (m[0] === '') { re.lastIndex++; if (re.lastIndex > src.length) break; continue; }
    out.push(fn(m[1]) + m[2]);
  }
  return out.join('');
}

const KANJI_OR_KATAKANA = /[\u4E00-\u9FFF\u3005\u30A0-\u30FF]/;
// 「〜だ」の直前がこれらなら名詞・形容動詞の語幹とみて「です」にできる（「読んだ」「まだ」「泳いだ」は変えない）
const DA_OK_PREV = /[\u4E00-\u9FFF\u3005\u30A0-\u30FFのうめとず]/;
// 文末の動詞で、丁寧語にしてよいもの（直前の字の条件つき）
const POLITE_VERBS: Array<{ plain: string; polite: string; prev?: RegExp }> = [
  { plain: '思う', polite: '思います' },
  { plain: '言う', polite: '言います' },
  { plain: '行く', polite: '行きます' },
  { plain: '来る', polite: '来ます' },
  { plain: '見る', polite: '見ます' },
  { plain: '送る', polite: '送ります' },
  { plain: 'いる', polite: 'います', prev: /[がにてでも]/ },
  { plain: 'ある', polite: 'あります', prev: /[がにてでもは]/ },
];

/**
 * 1文の文末だけを丁寧語にする。判断できなければ変えずに返す。
 * 主語を問わない丁寧語（です・ます）だけを使い、尊敬語・謙譲語には変えない。
 */
export function politeSentenceEnd(body: string): string {
  const b = body;
  if (/ありがとう$/.test(b)) return b + 'ございます';
  if (/(分か|わか)った$/.test(b)) return b.replace(/った$/, 'りました');
  const da = b.match(/(.)(だ|だよ|だね)$/);
  if (da && DA_OK_PREV.test(da[1])) return b.slice(0, b.length - da[2].length) + ({ 'だ': 'です', 'だよ': 'ですよ', 'だね': 'ですね' } as Record<string, string>)[da[2]];
  const suru = b.match(/(.)する$/);
  if (suru && KANJI_OR_KATAKANA.test(suru[1])) return b.slice(0, -2) + 'します';
  for (const v of POLITE_VERBS) {
    if (!b.endsWith(v.plain)) continue;
    const prev = b.charAt(b.length - v.plain.length - 1);
    if (v.prev && !v.prev.test(prev)) continue;
    return b.slice(0, b.length - v.plain.length) + v.polite;
  }
  return b;
}

/**
 * メッセージを敬語レベルに変換（原文を壊さない範囲だけ）
 * - 'plain' は変えない。'polite'・'respectful'・'humble' は、文末だけを丁寧語（です・ます）にする。
 * - 尊敬語・謙譲語は主語（誰の行為か）が分からないと誤用になるため、この関数では変換しない
 *   （自分の行為・相手の行為が確定している動詞は convertVerb、文単位は dialect_parser.adjustHonorific の subject 指定を使う）。
 */
export function escalate(text: string, level: KeigoLevel = 'polite'): string {
  if (level === 'plain') return text;
  return mapSentenceBodies(text, politeSentenceEnd);
}
