/**
 * lib/japan/env_energy_compliance.ts — 環境・エネルギーの期限・台帳 (束 T42)
 *
 * カバレッジ:
 *   - 温対法・省エネ法・フロン法の 7月末日の報告期限のカレンダー連携 (REQ-043)
 *   - 温対法の報告に使う CO2 算定 (一次資料から転記した係数だけを使う。電気・都市ガスは事業者別の係数が要る) (REQ-043)
 *   - 排出量取引制度 (GX-ETS) の期限・未償却相当負担金・CBAM 向けの製品別の実排出量の台帳 (REQ-044)
 *   - LPガスの三部料金の請求書・賃貸の設備料金「該当なし」・4年周期の調査/点検の期限 (REQ-170)
 *   - PCB 廃棄物・使用中の機器の台帳と 2027-03-31 の期限 (REQ-178)
 *
 * 法定値はすべて lib/japan/env_energy_legal_values.ts の値表 (出典URL・基準日・取得日・版つき) から読む (REQ-171)。
 * 一次資料で確かめられない値 (翌年度以降の参考上限取引価格・電気の係数・PCB の改正後の処分期間) は作らず、
 * 「未対応 (unsupported)」「確認できていない (unverified)」「検討中」を返す。
 */

import {
  getEnvEnergyLegalValue,
  requireEnvEnergyLegalNumber as legalNumber,
  requireEnvEnergyLegalString as legalString,
} from './env_energy_legal_values';

// ---------------------------------------------------------------------------
// 日付の小道具 (YYYY-MM-DD の暦日。時刻・時差を持ち込まない)
// ---------------------------------------------------------------------------
function parts(ymd: string): [number, number, number] {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(ymd);
  if (!m) throw new Error(`日付は YYYY-MM-DD で渡してください: ${ymd}`);
  return [Number(m[1]), Number(m[2]), Number(m[3])];
}
const pad = (n: number) => String(n).padStart(2, '0');
function dim(y: number, m: number): number {
  return [31, (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1];
}
/** 年を足す (2/29 は 2/28 に丸める) */
export function addYearsYmd(ymd: string, years: number): string {
  const [y, m, d] = parts(ymd);
  const ty = y + years;
  return `${ty}-${pad(m)}-${pad(Math.min(d, dim(ty, m)))}`;
}
function serial(ymd: string): number {
  const [y, m, d] = parts(ymd);
  return Math.round(Date.UTC(y, m - 1, d) / 86400000);
}
/** b − a の日数 */
export function diffDaysYmd(a: string, b: string): number {
  return serial(b) - serial(a);
}

// ---------------------------------------------------------------------------
// 1. 7月末日の報告期限 (カレンダー連携)
// ---------------------------------------------------------------------------
export interface EnvEnergyDeadlineEvent {
  id: string;
  date: string; // YYYY-MM-DD
  title: string;
  law: string;
  appliesTo: string;
  legalValueKey: string;
  note?: string;
}

/**
 * 報告する年度 (4/1〜翌3/31) の 7月末日の期限を返す。データは前年度分。
 *   ★期限日が土日祝に当たるときの扱いは条文に明記が無いため、7月31日のまま表示する (早めの提出を促す安全側・要確認)。
 */
export function getEnvEnergyReportingDeadlines(p: { reportFiscalYear: number }): EnvEnergyDeadlineEvent[] {
  const fy = p.reportFiscalYear;
  const d = (key: string) => `${fy}-${legalString(key)}`;
  const note = '期限日が土日祝に当たる場合の扱いは要確認。7月31日を期限として表示しています';
  return [
    { id: `shoene-periodic-report-${fy}`, date: d('shoene.periodic_report_due_mmdd'), title: `省エネ法 定期報告書 (${fy - 1}年度分)`, law: '省エネ法施行規則36条', appliesTo: '特定事業者 (原油換算1,500kL以上)', legalValueKey: 'shoene.periodic_report_due_mmdd', note },
    { id: `shoene-midterm-plan-${fy}`, date: d('shoene.midterm_plan_due_mmdd'), title: '省エネ法 中長期計画書', law: '省エネ法施行規則35条1項', appliesTo: '特定事業者 (原油換算1,500kL以上)', legalValueKey: 'shoene.midterm_plan_due_mmdd', note },
    { id: `shk-report-${fy}`, date: d('shk.report_due_mmdd'), title: `温対法 温室効果ガス算定排出量の報告 (${fy - 1}年度分)`, law: '温室効果ガス算定排出量等の報告等に関する命令4条1項', appliesTo: '特定排出者 (原油換算1,500kL以上 / ガスの種類ごとに3,000t以上かつ従業員21人以上)', legalValueKey: 'shk.report_due_mmdd', note },
    { id: `fluoro-leak-report-${fy}`, date: d('fluoro.report_due_mmdd'), title: `フロン法 算定漏えい量の報告 (${fy - 1}年度分)`, law: 'フロン類算定漏えい量等の報告等に関する命令4条1項', appliesTo: '特定漏えい者 (事業者単位で1,000t-CO2以上)', legalValueKey: 'fluoro.report_due_mmdd', note },
  ];
}

/** 期間 (年度) の期限をまとめて日付順に返す。GX-ETS の対象なら gxEts=true で 9月30日・1月31日の期限も入れる */
export function buildEnvEnergyCalendar(p: { fromFiscalYear: number; toFiscalYear: number; gxEts?: boolean }): EnvEnergyDeadlineEvent[] {
  const out: EnvEnergyDeadlineEvent[] = [];
  for (let fy = p.fromFiscalYear; fy <= p.toFiscalYear; fy++) {
    out.push(...getEnvEnergyReportingDeadlines({ reportFiscalYear: fy }));
    if (p.gxEts) {
      const s = getGxEtsSchedule(fy);
      if (s.status === 'mandatory') {
        out.push({ id: `gx-notification-${fy}`, date: s.notificationDue as string, title: `排出量取引制度 届出 (${fy}年度)`, law: 'GX推進法33条1項・施行規則10条1項', appliesTo: '年度平均排出量10万t以上', legalValueKey: 'gx.notification_due_mmdd' });
        out.push({ id: `gx-transition-plan-${fy}`, date: s.transitionPlanDue as string, title: `排出量取引制度 移行計画 (${fy}年度)`, law: 'GX推進法73条1項', appliesTo: '制度対象者', legalValueKey: 'gx.transition_plan_due_mmdd' });
        out.push({ id: `gx-holding-${fy}`, date: s.holdingDeadline as string, title: `排出量取引制度 排出枠の保有 (${fy}年度分)`, law: 'GX推進法36条3項', appliesTo: '制度対象者', legalValueKey: 'gx.holding_due_mmdd_next_fy' });
      }
    }
  }
  return out.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : a.id < b.id ? -1 : 1));
}

/** iCalendar (RFC 5545) の終日予定として書き出す (カレンダーアプリへの取り込み用) */
export function toICalendar(events: EnvEnergyDeadlineEvent[], calName = '環境・エネルギーの法定期限'): string {
  const esc = (s: string) => s.replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');
  const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//SoloptiLinkAI//env-energy-deadlines//JA', `X-WR-CALNAME:${esc(calName)}`];
  for (const e of events) {
    const ymd = e.date.replace(/-/g, '');
    const next = (() => { const [y, m, d] = parts(e.date); const t = new Date(Date.UTC(y, m - 1, d + 1)); return `${t.getUTCFullYear()}${pad(t.getUTCMonth() + 1)}${pad(t.getUTCDate())}`; })();
    lines.push('BEGIN:VEVENT', `UID:${e.id}@soloptilink-env-energy`, `DTSTAMP:${ymd}T000000Z`, `DTSTART;VALUE=DATE:${ymd}`, `DTEND;VALUE=DATE:${next}`, `SUMMARY:${esc(e.title)}`, `DESCRIPTION:${esc(`${e.law} / 対象: ${e.appliesTo}${e.note ? ' / ' + e.note : ''}`)}`, 'END:VEVENT');
  }
  lines.push('END:VCALENDAR');
  return lines.join('\r\n');
}

// ---------------------------------------------------------------------------
// 2. 温対法の報告に使う CO2 算定 (一次資料の係数だけを使う)
// ---------------------------------------------------------------------------
export interface ShkEnergyUse {
  gasolineL?: number;
  keroseneL?: number;
  dieselL?: number;
  heavyOilAL?: number;
  lpgKg?: number;
  electricityKwh?: number;
  cityGasNm3?: number;
}
const FUEL_KEY: Record<string, { k: string; perUnitDivisor: number }> = {
  gasolineL: { k: 'gasoline', perUnitDivisor: 1000 }, // GJ/kL → L あたり
  keroseneL: { k: 'kerosene', perUnitDivisor: 1000 },
  dieselL: { k: 'diesel', perUnitDivisor: 1000 },
  heavyOilAL: { k: 'heavy_oil_a', perUnitDivisor: 1000 },
  lpgKg: { k: 'lpg', perUnitDivisor: 1000 }, // GJ/t → kg あたり
};

/**
 * エネルギー起源 CO2 (t-CO2)。燃料は算定省令 別表第一 の 単位発熱量×排出係数×44/12 (値表の転記値)。
 * 電気・都市ガスは法定の単一値が無いため、事業者別の公表係数 (t-CO2/kWh・t-CO2/Nm3) を渡したときだけ計算する。
 * 渡されなければ status='unverified'・tCo2=null (参考値で計算し続けない)。
 */
export function calcShkEnergyCo2(
  use: ShkEnergyUse,
  factors: { electricityTCo2PerKwh?: number; cityGasTCo2PerNm3?: number } = {},
): { status: 'ok' | 'unverified'; tCo2: number | null; breakdown: Record<string, number>; missingFactors: string[]; reason?: string } {
  const breakdown: Record<string, number> = {};
  const missing: string[] = [];
  const c = legalNumber('shk.co2_per_carbon');
  for (const [field, { k, perUnitDivisor }] of Object.entries(FUEL_KEY)) {
    const q = (use as Record<string, number | undefined>)[field];
    if (!q) continue;
    const tPerUnit = (legalNumber(`shk.fuel.${k}.heat_gj`) * legalNumber(`shk.fuel.${k}.carbon_tc_per_gj`) * c) / perUnitDivisor;
    breakdown[field] = q * tPerUnit;
  }
  if (use.electricityKwh) {
    if (typeof factors.electricityTCo2PerKwh === 'number' && factors.electricityTCo2PerKwh >= 0) breakdown.electricityKwh = use.electricityKwh * factors.electricityTCo2PerKwh;
    else missing.push('electricityTCo2PerKwh (電気事業者別の排出係数)');
  }
  if (use.cityGasNm3) {
    if (typeof factors.cityGasTCo2PerNm3 === 'number' && factors.cityGasTCo2PerNm3 >= 0) breakdown.cityGasNm3 = use.cityGasNm3 * factors.cityGasTCo2PerNm3;
    else missing.push('cityGasTCo2PerNm3 (ガス事業者ごとの公表係数・算定省令2条3項)');
  }
  if (missing.length) {
    const lv = getEnvEnergyLegalValue('shk.electricity_factor');
    return { status: 'unverified', tCo2: null, breakdown, missingFactors: missing, reason: `係数が渡されていないため計算していません: ${missing.join('、')}${lv.ok ? '' : ' (法定の単一値は無い)'}` };
  }
  return { status: 'ok', tCo2: Object.values(breakdown).reduce((s, v) => s + v, 0), breakdown, missingFactors: [] };
}

// ---------------------------------------------------------------------------
// 3. 排出量取引制度 (GX-ETS)
// ---------------------------------------------------------------------------
export interface GxEtsSchedule {
  fiscalYear: number;
  status: 'mandatory' | 'not_mandatory';
  /** 年度平均排出量等の届出 (施行規則10条1項: 毎年度9月末日) */
  notificationDue: string | null;
  /** 移行計画の提出 (経産省マニュアル: 9月30日) */
  transitionPlanDue: string | null;
  /** 排出目標量等の届出 (2026年度は特例で2027-09-30。2027年度以降は届出と同じ日) */
  targetNotificationDue: string | null;
  /** 排出実績量の報告 (施行規則16条1項: 割当年度の翌年度の9月末日) */
  actualEmissionsReportDue: string | null;
  /** 排出枠の保有 = 償却の日 (法36条3項: 割当年度の翌年度の1月31日) */
  holdingDeadline: string | null;
  /** 未償却相当負担金の徴収が始まる日 (法41条1項: 翌年度の2月1日以後) */
  burdenNoticeFrom: string | null;
  notes: string[];
}

/** 割当年度 (fiscalYear) の手続の期限。翌年度の1月31日は暦年では fiscalYear+2 年の1月31日 */
export function getGxEtsSchedule(fiscalYear: number): GxEtsSchedule {
  const from = legalNumber('gx.mandatory_from_fy');
  if (fiscalYear < from) {
    return { fiscalYear, status: 'not_mandatory', notificationDue: null, transitionPlanDue: null, targetNotificationDue: null, actualEmissionsReportDue: null, holdingDeadline: null, burdenNoticeFrom: null, notes: [`${from}年度より前は義務化前 (GXリーグでの任意参加の試行)`] };
  }
  const notificationDue = `${fiscalYear}-${legalString('gx.notification_due_mmdd')}`;
  const notes: string[] = ['移行計画の期日は経済産業省のマニュアルによる (主務省令の条番号は要一次確認)'];
  let targetNotificationDue = notificationDue;
  if (fiscalYear === 2026) {
    targetNotificationDue = legalString('gx.fy2026_target_notification_due');
    notes.push('2026年度の特例: 2026年度に届け出るのは基礎的な情報と年度平均排出量のみ。排出目標量等は2027-09-30まで、排出枠の割当は2027年11月末');
  }
  return {
    fiscalYear,
    status: 'mandatory',
    notificationDue,
    transitionPlanDue: `${fiscalYear}-${legalString('gx.transition_plan_due_mmdd')}`,
    targetNotificationDue,
    actualEmissionsReportDue: `${fiscalYear + 1}-${legalString('gx.actual_report_due_mmdd_next_fy')}`,
    holdingDeadline: `${fiscalYear + 2}-${legalString('gx.holding_due_mmdd_next_fy')}`,
    burdenNoticeFrom: `${fiscalYear + 2}-${legalString('gx.burden_notice_from_mmdd_next_fy')}`,
    notes,
  };
}

/**
 * 未償却相当負担金の試算 (法41条1項): 未償却量 × 参考上限取引価格 × 1.1。
 *   参考上限取引価格は年度ごとの告示値 (値表に転記した年度だけ)。転記していない年度は unsupported (前年度の価格で計算しない)。
 *   排出枠は1t単位のため、不足量に端数があるときは1t単位へ切り上げる (負担を少なく見積もらない安全側・要確認)。
 *   実際の額と納付期限は経済産業大臣の通知 (法42条) による。
 */
export function calcGxEtsUnsurrenderedBurden(p: { fiscalYear: number; obligationT: number; surrenderedT: number }): {
  status: 'ok' | 'unsupported';
  shortfallT: number;
  referenceCapPriceJpy: number | null;
  burdenJpy: number | null;
  reason: string;
} {
  const shortfallT = Math.max(0, Math.ceil(p.obligationT - p.surrenderedT - 1e-9));
  const lv = getEnvEnergyLegalValue(`gx.reference_cap_price.FY${p.fiscalYear}`);
  if (!lv.ok || typeof lv.value !== 'number') {
    return { status: 'unsupported', shortfallT, referenceCapPriceJpy: null, burdenJpy: null, reason: `${p.fiscalYear}年度の参考上限取引価格は告示から転記していないため試算できません (経済産業省の告示を確認してください)` };
  }
  const price = lv.value;
  const mult = legalNumber('gx.burden_multiplier');
  // 1.1 倍は整数演算で行う (浮動小数の誤差で1円ずれないように)
  const burdenJpy = mult === 1.1 ? (shortfallT * price * 11) / 10 : shortfallT * price * mult;
  return { status: 'ok', shortfallT, referenceCapPriceJpy: price, burdenJpy, reason: `不足 ${shortfallT}t × 参考上限取引価格 ${price}円 × 1.1 = ${burdenJpy}円 (${p.fiscalYear}年度・経済産業省告示第二十七号)` };
}

/** CBAM 向け: 製品別の実排出量 (埋め込み排出量) の台帳。内訳 (直接・間接・前駆物質) の和 = 製品の合計、製品合計の和 = 台帳の合計 */
export function buildCbamProductLedger(rows: { productId: string; outputT: number; directT: number; indirectT: number; precursorT?: number; declaredTotalT?: number }[]): {
  rows: { productId: string; outputT: number; directT: number; indirectT: number; precursorT: number; totalT: number; specificTPerT: number | null }[];
  totalT: number;
  identityOk: boolean;
  errors: string[];
} {
  const errors: string[] = [];
  const out = rows.map((r) => {
    const precursorT = r.precursorT ?? 0;
    for (const [k, v] of [['directT', r.directT], ['indirectT', r.indirectT], ['precursorT', precursorT]] as const) {
      if (!(Number.isFinite(v) && v >= 0)) errors.push(`${r.productId}: ${k} が0以上の数ではありません`);
    }
    const totalT = r.directT + r.indirectT + precursorT;
    if (r.declaredTotalT !== undefined && Math.abs(r.declaredTotalT - totalT) > 1e-9) {
      errors.push(`${r.productId}: 申告された合計 ${r.declaredTotalT}t が内訳の和 ${totalT}t と一致しません`);
    }
    let specificTPerT: number | null = null;
    if (r.outputT > 0) specificTPerT = totalT / r.outputT;
    else errors.push(`${r.productId}: 生産量が0以下のため製品1tあたりの排出量 (原単位) を出せません`);
    return { productId: r.productId, outputT: r.outputT, directT: r.directT, indirectT: r.indirectT, precursorT, totalT, specificTPerT };
  });
  const totalT = out.reduce((s, r) => s + r.totalT, 0);
  return { rows: out, totalT, identityOk: errors.length === 0, errors };
}

// ---------------------------------------------------------------------------
// 4. LPガス (液石法施行規則 16条15号の7〜9・36条・37条)
// ---------------------------------------------------------------------------
export type LpgChargeCategory = 'basic' | 'usage' | 'equipment';
export interface LpgInvoiceLine { category: LpgChargeCategory; label?: string; amountJpy: number; display?: string }
const LPG_LABEL: Record<LpgChargeCategory, string> = { basic: '基本料金', usage: '従量料金', equipment: '設備料金' };

/**
 * 三部料金 (基本・従量・設備) の請求書を作る。
 *   - 2025-04-02 以後の請求は3区分に整理して通知 (16条15号の7)。
 *   - 消費者と建物の所有者が異なる (賃貸等) とき、2024-07-02 以後に締結した契約では、所有者が本来負担すべき設備の費用を請求しない (15号の9)。
 *     負担方法の合意がある場合は除く (同ただし書)。請求しないときは設備料金を「該当なし」と表示する。
 *   - 2024-07-02 より前に締結した契約には 15号の8・9 を適用しない (附則2条)。契約の更新に努める (附則3条)。
 */
export function buildLpgInvoice(p: {
  billingDate: string;
  contractDate: string;
  consumerIsBuildingOwner: boolean;
  equipmentCostAgreement?: boolean;
  basicChargeJpy: number;
  usageChargeJpy: number;
  equipmentChargeJpy?: number;
}): { lines: LpgInvoiceLine[]; totalJpy: number; issues: string[]; notes: string[] } {
  const issues: string[] = [];
  const notes: string[] = [];
  const threePartFrom = legalString('lpg.three_part_effective');
  const contractCutoff = legalString('lpg.equipment_rule_contract_cutoff');
  const rule89Applies = p.contractDate >= contractCutoff && p.billingDate >= threePartFrom;
  const rental = !p.consumerIsBuildingOwner;
  const eqAmount = p.equipmentChargeJpy ?? 0;
  let equipment: LpgInvoiceLine;
  if (rental && rule89Applies && !p.equipmentCostAgreement) {
    if (eqAmount > 0) issues.push(`賃貸等 (消費者と建物の所有者が異なる) で負担方法の合意が無いのに設備料金 ${eqAmount}円 を請求しています — 液石法施行規則16条15号の9 に反するおそれ`);
    equipment = { category: 'equipment', label: LPG_LABEL.equipment, amountJpy: eqAmount, display: eqAmount > 0 ? `${eqAmount}円 (要是正)` : '該当なし' };
  } else {
    equipment = { category: 'equipment', label: LPG_LABEL.equipment, amountJpy: eqAmount, display: eqAmount > 0 ? `${eqAmount}円` : '該当なし' };
    if (rental && !rule89Applies && p.contractDate < contractCutoff) notes.push(`${contractCutoff} より前に締結した契約のため16条15号の8・9は適用されません (附則2条)。契約の更新に努めてください (附則3条)`);
  }
  const lines: LpgInvoiceLine[] = [
    { category: 'basic', label: LPG_LABEL.basic, amountJpy: p.basicChargeJpy },
    { category: 'usage', label: LPG_LABEL.usage, amountJpy: p.usageChargeJpy },
    equipment,
  ];
  if (p.billingDate < threePartFrom) notes.push(`三部料金の整理 (16条15号の7) は ${threePartFrom} 以後の請求から義務です`);
  return { lines, totalJpy: lines.reduce((s, l) => s + l.amountJpy, 0), issues, notes };
}

/** 請求書の3区分 (基本・従量・設備) の有無を検査する。設備は「該当なし」の行でもよい */
export function checkLpgInvoiceCategories(inv: { billingDate: string; lines: { category: string; amountJpy?: number | null; display?: string }[] }): {
  ok: boolean;
  required: boolean;
  missing: LpgChargeCategory[];
} {
  const required = inv.billingDate >= legalString('lpg.three_part_effective');
  const have = new Set(inv.lines.map((l) => l.category));
  const missing = (['basic', 'usage', 'equipment'] as LpgChargeCategory[]).filter((c) => !have.has(c));
  return { ok: !required || missing.length === 0, required, missing: required ? missing : [] };
}

/**
 * 保安の4年周期の期限 (規則37条: 消費設備の調査 / 36条: 供給設備の点検。いずれも「供給開始時及び四年に一回以上」の項目)。
 *   期限 = 前回 (無ければ供給開始日) + 4年 (同じ日付。2/29 は 2/28)。基準日が期限より後なら超過。
 *   ★期限当日を含むか前日までかは条文に明記が無いため要確認 (フロンの点検期日と同じ規則に揃えた)。1年・2年の項目は対象外。
 */
export function calcLpgSafetyDue(p: { kind: 'consumer_survey' | 'supply_inspection'; lastDate: string; baseDate: string }): {
  dueDate: string;
  overdue: boolean;
  daysRemaining: number;
  basis: string;
} {
  const years = legalNumber(p.kind === 'consumer_survey' ? 'lpg.consumer_survey_years' : 'lpg.supply_inspection_years');
  const dueDate = addYearsYmd(p.lastDate, years);
  return {
    dueDate,
    overdue: p.baseDate > dueDate,
    daysRemaining: diffDaysYmd(p.baseDate, dueDate),
    basis: p.kind === 'consumer_survey' ? '液石法施行規則37条 (消費設備の調査 4年に1回以上)' : '液石法施行規則36条 (供給設備の点検 4年に1回以上)',
  };
}

// ---------------------------------------------------------------------------
// 5. PCB (PCB特措法14条・施行令7条・令和8年法律第44号)
// ---------------------------------------------------------------------------
export type PcbItemState = 'in_use' | 'stored_waste' | 'disposal_consigned' | 'disposed';
export interface PcbJudgement {
  status: 'within_period' | 'overdue' | 'in_use' | 'done';
  deadline: string | null;
  daysRemaining: number | null;
  message: string;
  /** 2027-04-01 以後の制度 (基準日が期限の後のときだけ) */
  postDeadlineRegime: string | null;
}

/** 期限の後の制度の表示 (改正法は成立済み。処分の期間を定める政令は確認できていない) */
function postRegimeText(): string {
  const eff = legalString('pcb.amendment_effective');
  const period = getEnvEnergyLegalValue('pcb.post_amendment_disposal_period');
  return `期限の後の制度: 令和8年法律第44号 (${eff} 施行) により、低濃度PCB使用製品は使用終了日の翌月末日までに届出し、使用終了日から5年を超えない範囲で政令で定める期間内に処分します。` +
    (period.ok ? '' : 'この政令で定める期間は検討中 (本作業時点で未確認) です。都道府県・環境省の案内を確認してください');
}

/**
 * PCB 機器・廃棄物の1件を判定する。
 *   低濃度の PCB 廃棄物 (保管中) は 2027-03-31 までに処分 (自ら処分又は処分を委託)。基準日がその翌日以後なら期限超過。
 *   旧法で届け出た保管中の低濃度PCB廃棄物の処分義務は改正後も従前の例 (令和8年法律第44号 附則2条4項) — 期限超過のまま。
 *   高濃度は区域ごとの処分期間 (特例を含め最も遅いもので2024-03-31) が終了済み。保管・使用中なら期限超過。
 *   使用中の低濃度PCB含有機器は現行法の処分期間の対象 (廃棄物) ではないが、廃棄物になれば期限内の処分が必要。
 */
export function judgePcbItem(p: { concentration: 'high' | 'low'; state: PcbItemState; baseDate: string }): PcbJudgement {
  const lowDeadline = legalString('pcb.low_disposal_deadline');
  const highLast = legalString('pcb.high_last_deadline');
  const afterDeadline = p.baseDate > lowDeadline;
  const regime = afterDeadline ? postRegimeText() : null;
  if (p.state === 'disposed' || p.state === 'disposal_consigned') {
    return { status: 'done', deadline: null, daysRemaining: null, message: p.state === 'disposed' ? '処分済み' : '処分を委託済み (処分完了の確認を記録してください)', postDeadlineRegime: regime };
  }
  if (p.concentration === 'high') {
    const overdue = p.baseDate > highLast;
    return {
      status: overdue ? 'overdue' : 'within_period',
      deadline: highLast,
      daysRemaining: overdue ? null : diffDaysYmd(p.baseDate, highLast),
      message: overdue ? '高濃度PCBの処分期間は終了しています。直ちに都道府県 (政令市) に相談し処分してください' : '高濃度PCBの処分期間は区域ごとに異なります (施行令別表)。区域の期間を確認してください',
      postDeadlineRegime: regime,
    };
  }
  if (p.state === 'stored_waste') {
    if (afterDeadline) {
      return { status: 'overdue', deadline: lowDeadline, daysRemaining: null, message: `低濃度PCB廃棄物の処分期間 (${lowDeadline}まで・PCB特措法14条/施行令7条) を過ぎて保管しています。直ちに都道府県 (政令市) に相談してください`, postDeadlineRegime: regime };
    }
    return { status: 'within_period', deadline: lowDeadline, daysRemaining: diffDaysYmd(p.baseDate, lowDeadline), message: `低濃度PCB廃棄物は ${lowDeadline} までに処分 (又は処分の委託) が必要です`, postDeadlineRegime: null };
  }
  // in_use (低濃度)
  return {
    status: 'in_use',
    deadline: afterDeadline ? null : lowDeadline,
    daysRemaining: afterDeadline ? null : diffDaysYmd(p.baseDate, lowDeadline),
    message: afterDeadline
      ? '使用中の低濃度PCB含有機器です。改正後の制度による届出と、使用終了後の期間内の処分が必要です'
      : `使用中の低濃度PCB含有機器です。使用を終えて廃棄物になると ${lowDeadline} までの処分が必要です。期限までの更新・処分の計画を立ててください`,
    postDeadlineRegime: regime,
  };
}

/** PCB 台帳の集計 (基準日での期限超過件数など) */
export function summarizePcbLedger(items: { id: string; concentration: 'high' | 'low'; state: PcbItemState }[], opts: { baseDate: string }): {
  items: ({ id: string } & PcbJudgement)[];
  overdueCount: number;
  withinPeriodCount: number;
  inUseCount: number;
} {
  const judged = items.map((it) => ({ id: it.id, ...judgePcbItem({ concentration: it.concentration, state: it.state, baseDate: opts.baseDate }) }));
  return {
    items: judged,
    overdueCount: judged.filter((j) => j.status === 'overdue').length,
    withinPeriodCount: judged.filter((j) => j.status === 'within_period').length,
    inUseCount: judged.filter((j) => j.status === 'in_use').length,
  };
}
