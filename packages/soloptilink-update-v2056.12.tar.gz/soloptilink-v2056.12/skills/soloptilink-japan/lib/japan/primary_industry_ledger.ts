/**
 * lib/japan/primary_industry_ledger.ts — 一次産業知識台帳 v0 (値・期限・出典・確認状態の正本1か所)
 *
 * 2026-10-03 (JPO-T33) 新設。農地・クリーンウッド法・水産流通適正化法・農薬登録情報・収入保険・水田政策の
 * 数値と期限をここに集め、部品 (farmland_procedure.ts / forestry.ts / pesticide_registration_check.ts /
 * farm_tax.ts / farm_income_insurance.ts) はここを読む。値を部品へ書き写さない。
 *
 * 確認状態:
 *   primary_checked = 一次資料 (法令本文・省庁ページ) の本文で当方が確かめた (専門家の確認は経ていない)
 *   needs_primary   = 一次資料で確かめられていない。部品はこの値で計算せず「確認できていない」を返す
 * 消費税の経過措置・2割/3割特例・簡易課税のみなし仕入率は lib/japan/tax-calendar.json が正本 (ここには持たない)。
 */

export type LedgerStatus = 'primary_checked' | 'needs_primary';

export interface LedgerSource {
  title: string;
  url: string;
  checkedAt: string; // YYYY-MM-DD
}

// ============================================================================
// 農地法 (権利移動・転用)
// ============================================================================
export const FARMLAND_RULES = {
  status: 'primary_checked' as LedgerStatus,
  /** 転用の許可で国 (農林水産大臣) との協議が付く面積: これを「超える」 */
  ministerConsultOverHa: 4,
  /** 農業委員会が都道府県機構の意見を聴く面積: 30アールを「超える」 (農地法4条4項) */
  prefecturalOrgOpinionOverHa: 0.3,
  /** 市町村の利用権設定 (農用地利用集積計画) を廃止し農地バンク経由に一本化した日 */
  useRightPlanAbolishedFrom: '2025-04-01',
  sources: [
    { title: '農地法 (e-Gov 327AC0000000229・2025-06-01 施行版) 3条・3条の3・4条・5条・64条・67条', url: 'https://laws.e-gov.go.jp/law/327AC0000000229', checkedAt: '2026-10-03' },
    { title: '農地法施行規則 (e-Gov 327M50010000079・2026-05-27 施行版) 10条・30条・57条の4', url: 'https://laws.e-gov.go.jp/law/327M50010000079', checkedAt: '2026-10-03' },
    { title: '農林水産省「指定市町村制度の概要」(4ha超は国との協議を付して都道府県・指定市町村へ移譲)', url: 'https://www.maff.go.jp/j/nousin/noukei/totiriyo/attach/pdf/nouchi_tenyo-3.pdf', checkedAt: '2026-10-03' },
    { title: '農林水産省「農地バンク よくあるご質問」Q3 (令和7年4月から農地バンク経由に一本化・3条許可は引き続き可能)', url: 'https://www.maff.go.jp/j/keiei/koukai/kikou/shitumon.html', checkedAt: '2026-10-01' },
  ] as LedgerSource[],
} as const;

// ============================================================================
// 行政書士・税理士の業務の線引き
// ============================================================================
export const PROFESSIONAL_BOUNDARY = {
  status: 'primary_checked' as LedgerStatus,
  gyoseishoshi:
    '官公署に提出する書類 (農地法の許可申請書・届出書を含む) を他人の依頼を受け報酬を得て作成することは、行政書士の業務です (行政書士法第1条の3・第19条)。'
    + 'このシステムは手続の分岐の判定・必要書類の一覧・期限の管理までを支援するもので、申請書の作成代行ではありません。許可・不許可の判断は農業委員会・都道府県知事等が行います。',
  zeirishi:
    '税務申告書の作成・税務相談は税理士の業務です (税理士法第52条)。このシステムの判定・計算は帳簿づけと確認のための参考で、'
    + '申告の最終判断は税理士・税務署にご確認ください。',
  sources: [
    { title: '行政書士法 (e-Gov 326AC1000000004・2026-05-21 施行版) 1条の3・19条', url: 'https://laws.e-gov.go.jp/law/326AC1000000004', checkedAt: '2026-10-03' },
    { title: '税理士法 (e-Gov 326AC1000000237) 52条', url: 'https://laws.e-gov.go.jp/law/326AC1000000237', checkedAt: '2026-10-03' },
  ] as LedgerSource[],
} as const;

// ============================================================================
// クリーンウッド法 (合法伐採木材等の流通及び利用の促進に関する法律・平成28年法律第48号)
// ============================================================================
export const CLEAN_WOOD_RULES = {
  status: 'primary_checked' as LedgerStatus,
  originalEnforcedMonth: '2017-05', // 平成29年5月施行 (林野庁ページは月まで。日は持たない)
  amendedEnforced: '2025-04-01', // 令和5年改正法・令和7年4月施行
  recordRetentionYears: 5, // 記録は作成の日から5年間 (譲渡しまで5年を超える場合は譲渡しの時まで)
  periodicReport: {
    /** 「法人として以下の規模以上」(以上 = ちょうどを含む) */
    corporationOnly: true,
    domesticLogsM3: 30000, // 区分1 国産材 (丸太) の総量
    importedWoodM3: 30000, // 区分2 輸入した木材を丸太換算した総量
    importedProductsTon: 15000, // 区分3 輸入した家具・紙等の物品の総量
    firstReportDeadline: '2026-06-30', // 第1回定期報告の報告期限 (令和8年6月末)
  },
  sources: [
    { title: '林野庁 クリーンウッド・ナビ「法制度」(対象事業者・義務・記録の保存期間・定期報告の基準)', url: 'https://www.rinya.maff.go.jp/j/riyou/goho/summary/summary.html', checkedAt: '2026-10-03' },
    { title: '林野庁 クリーンウッド・ナビ トップ (第1回定期報告の報告期限は令和8年6月末・R8.5.13)', url: 'https://www.rinya.maff.go.jp/j/riyou/goho/index.html', checkedAt: '2026-10-03' },
  ] as LedgerSource[],
} as const;

// ============================================================================
// 森林法 (伐採届)
// ============================================================================
export const FOREST_HARVEST_NOTICE = {
  status: 'primary_checked' as LedgerStatus,
  /** 伐採及び伐採後の造林の届出書は、伐採を開始する日前90日から30日までの間に提出 (森林法施行規則9条1項) */
  earliestDaysBefore: 90,
  latestDaysBefore: 30,
  sources: [
    { title: '森林法 (e-Gov 326AC1000000249) 10条の8 / 森林法施行規則 (e-Gov 326M50010000054・2026-04-01 施行版) 9条', url: 'https://laws.e-gov.go.jp/law/326M50010000054', checkedAt: '2026-10-03' },
  ] as LedgerSource[],
} as const;

// ============================================================================
// 水産流通適正化法 (特定第一種水産動植物)
// ============================================================================
export const SPECIFIED_AQUATIC_SPECIES = {
  status: 'primary_checked' as LedgerStatus,
  items: [
    { name: 'アワビ', condition: '', effectiveFrom: '2022-12-01', classNo: '特定第一種第一号' },
    { name: 'ナマコ', condition: '', effectiveFrom: '2022-12-01', classNo: '特定第一種第一号' },
    { name: 'うなぎの稚魚', condition: '全長13cm以下の全てのウナギ属 (国内採捕・輸入・人工生産を問わない)', effectiveFrom: '2025-12-01', classNo: '特定第一種第一号' },
    { name: '太平洋クロマグロの大型魚', condition: '30kg以上で解体前のもの', effectiveFrom: '2026-04-01', classNo: '特定第一種第二号' },
  ],
  tradeRecordRetentionYears: 3,
  sources: [
    { title: '水産庁「特定水産動植物等の国内流通の適正化等に関する法律」', url: 'https://www.jfa.maff.go.jp/j/kakou/tekiseika.html', checkedAt: '2026-10-03' },
    { title: '水産庁「うなぎの稚魚（全長13cm以下）に関するQ&A」(適用施行日 令和7年12月1日・取引記録3年)', url: 'https://www.jfa.maff.go.jp/j/kakou/attach/pdf/tekiseika-38.pdf', checkedAt: '2026-10-03' },
    { title: '水産庁 リーフレット「太平洋クロマグロを取り扱う流通事業者の皆様へ」', url: 'https://www.jfa.maff.go.jp/j/kakou/attach/pdf/fukyuu-8.pdf', checkedAt: '2026-10-01' },
  ] as LedgerSource[],
  /** アワビ・ナマコの適用日 2022-12-01 は G15 調査の検索要約による (本文未照合) */
  notes: ['アワビ・ナマコの適用日 2022-12-01 は一次本文で未照合 (要一次確認)。うなぎの稚魚・クロマグロは一次資料で確認。'],
} as const;

// ============================================================================
// 農薬登録情報 (FAMIC) の扱い
// ============================================================================
export const PESTICIDE_DATA_RULES = {
  status: 'primary_checked' as LedgerStatus,
  /** 登録反映日からこの日数を超えたら「古い」と表示する (FAMIC は月2回程度更新) */
  staleAfterDays: 45,
  sources: [
    { title: 'FAMIC 農薬登録情報ダウンロード (登録基本部・登録適用部一・二)', url: 'https://www.acis.famic.go.jp/ddata/index.htm', checkedAt: '2026-10-03' },
    { title: '農林水産省「農薬を使用する者が遵守すべき基準を定める省令」第2条・第9条', url: 'https://www.maff.go.jp/j/nouyaku/n_tekisei/kijun/', checkedAt: '2026-10-01' },
  ] as LedgerSource[],
  notes: ['staleAfterDays (45日) は FAMIC の更新頻度 (月2回程度) からの当方の運用値で、法令の値ではない。'],
} as const;

// ============================================================================
// 収入保険 (農業保険法)
// ============================================================================
export const INCOME_INSURANCE_RULES = {
  status: 'primary_checked' as LedgerStatus,
  /** 青色申告実績の年数 → 補償限度 (保険方式の補償限度＋積立方式の補償幅) の上限 */
  coverageCapByBlueYears: { 1: 0.75, 2: 0.8, 3: 0.85, 4: 0.88, 5: 0.9 } as Record<number, number>,
  /** 青色申告実績の年数 → 保険方式の補償限度として選べる割合 */
  insuranceLimitChoicesByBlueYears: {
    5: [0.9, 0.88, 0.85, 0.83, 0.8, 0.78, 0.75, 0.7, 0.65, 0.6, 0.55, 0.5],
    4: [0.88, 0.85, 0.83, 0.8, 0.78, 0.75, 0.7, 0.65, 0.6, 0.55, 0.5],
    3: [0.85, 0.83, 0.8, 0.78, 0.75, 0.7, 0.65, 0.6, 0.55, 0.5],
    2: [0.8, 0.78, 0.75, 0.7, 0.65, 0.6, 0.55, 0.5],
    1: [0.75, 0.7, 0.65, 0.6, 0.55, 0.5],
  } as Record<number, number[]>,
  reserveWidthChoices: [0.05, 0.1],
  insurancePayRateChoices: [0.9, 0.8, 0.7, 0.6, 0.5],
  reservePayRateChoices: [0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1],
  floorRateChoices: [0.7, 0.6, 0.5],
  minBlueYears: 1,
  /** 加入申請は保険期間が始まる前の月まで */
  applicationDeadlineRule: 'end_of_previous_month',
  /** 補てん金の円未満の扱い: 一次資料に記載が無いため、安全側 (切り捨て) を既定にする (要確認) */
  yenRounding: 'floor',
  /** 類似制度とは選択加入 */
  exclusiveWith: ['農業共済 (農作物共済等)', 'ナラシ対策 (収入減少影響緩和対策)', '野菜価格安定制度'],
  sources: [
    { title: '農林水産省「収入保険 制度の詳細」', url: 'https://www.maff.go.jp/j/keiei/nogyohoken/syunyuhoken/syousai.html', checkedAt: '2026-10-03' },
  ] as LedgerSource[],
  notes: [
    '補てん金の円未満の端数処理は一次資料で確認できていない (部品は切り捨て。要確認)。',
    '農業共済の申込期限は農業共済組合・作物ごとに異なるため値を持たない (利用者が入力した期限で通知する)。',
  ],
} as const;

// ============================================================================
// 水田政策 (経営所得安定対策・水田活用の直接支払交付金)
// ============================================================================
export const RICE_PADDY_POLICY = {
  status: 'primary_checked' as LedgerStatus,
  /** 現行の実施要綱・パンフレット (令和8年度版) がある最後の年度 */
  lastConfirmedFiscalYear: 2026,
  /** この年度以降は見直し中で値が確定していない → 「暫定」 */
  provisionalFromFiscalYear: 2027,
  sources: [
    { title: '農林水産省「経営所得安定対策等」(令和8年度版パンフレット・《システム事業者向け》水田政策の見直しに係る説明会 令和8年9月30日)', url: 'https://www.maff.go.jp/j/seisaku_tokatu/antei/keiei_antei.html', checkedAt: '2026-10-03' },
  ] as LedgerSource[],
} as const;
