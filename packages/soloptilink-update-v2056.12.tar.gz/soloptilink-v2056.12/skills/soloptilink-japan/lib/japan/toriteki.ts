/**
 * 取適法 (旧 下請法) とフリーランス法の支払期日・遅延利息・適用判定・明示事項 — 値と判定の置き場
 *
 * 正式名称: 製造委託等に係る中小受託事業者に対する代金の支払の遅延等の防止に関する法律
 *   (昭和31年法律第120号・令和7年法律第41号による改正後・2026-01-01施行)
 *   略称: 中小受託取引適正化法 / 取適法 (e-Gov の略称欄)
 *   旧称: 下請代金支払遅延等防止法 (下請法)。旧法の「親事業者」「下請事業者」「下請代金」は
 *   それぞれ「委託事業者」「中小受託事業者」「製造委託等代金」に改められた。
 *
 * ★2026-09-30 新設 (REQ-JPO-FIX-003・REQ-JPO-FIX-015)。
 *   支払期日・遅延利息・締切制度・休業日の順延・適用判定の数値は【この値表 TORITEKI_VALUES だけ】に置く。
 *   laws.ts (Subcontract)・antimonopoly.ts・freelance_law.ts・bug_prevention.ts はここを呼ぶだけにする。
 *
 * 【出典 — 一次情報 (2026-09-30 に本文を開いて確認)】
 *   - 取適法 e-Gov 331AC0000000120 (施行 2026-01-01 版)
 *       第2条4項 役務提供委託から建設工事の再委託を除く / 5項 特定運送委託 / 7項 情報成果物
 *       第2条8項1〜6号・9項1〜6号 委託事業者・中小受託事業者 (資本金基準・従業員基準)
 *       第3条1項 支払期日は受領日から起算して60日の期間内 / 2項 みなしの支払期日
 *       第4条 明示 / 第5条 遵守事項 / 第6条 遅延利息 / 第7条 書類等の作成及び保存
 *   - 同法第2条第8項第1号の情報成果物及び役務を定める政令 (413CO0000000005):
 *       情報成果物 = プログラム / 役務 = 運送・物品の倉庫における保管・情報処理
 *   - 第4条の明示に関する規則 (令和7年公正取引委員会規則第8号・507M60200000008) 第1条
 *   - 第6条第1項及び第2項の率を定める規則 (同第9号・507M60200000009): 年14.6%
 *   - 第7条の書類等の作成及び保存に関する規則 (同第10号・507M60200000010) 第1条・第3条 (2年間)
 *   - 公正取引委員会・中小企業庁「中小受託取引適正化法テキスト」(令和7年11月) p.61-63
 *       「60日以内（受領日を算入する。）」/ 月単位の締切制度は「受領後2か月以内」として運用 /
 *       金融機関の休業日: 順延2日以内かつ書面の合意、順延後も60日(2か月)以内なら合意で2日超も可
 *       https://www.jftc.go.jp/toriteki/r7text.pdf
 *   - 取適法の運用基準 第4-2(6)エ・カ・キ・ク https://www.jftc.go.jp/toriteki/legislation/unyou.html
 *   - 公取委 取適法Q&A Q36・Q38 (特定運送委託に当たらない例)・Q81 (電子記録債権等の手数料)・
 *       Q83 (遅延利息・手形は満期日を支払日とする)・Q98 (円未満の端数)・Q99 (振込手数料)
 *       https://www.jftc.go.jp/toriteki/toriteki_qa.html
 *   - フリーランス法 e-Gov 505AC0000000025 第4条1〜5項
 *
 * 【要一次確認・要確認として残したもの】
 *   - 月単位の締切制度で、受領日の2か月後に応当日が無い月の端 (例 12/29〜12/31 受領) の最終日。
 *     単調性から決まる範囲の外だけを判定し、範囲の中は verdict='unconfirmed' を返す。
 *   - 遅延利息の日割りの分母 (うるう年を含む期間で365と366のどちらか) と円未満の処理。
 *     安全側 (支払側に不足が出ない) として分母365・円未満切上げで計算し、notes に要確認を付ける。
 *   - 施行前 (2025-12-31 以前) の委託は改正法附則により旧法で判定する (旧法の資本金基準だけで判定)。
 *   - ★2026-10-03 (T08): 金融機関の休業日による2日を超える順延は、要件の文言 (2日以内かつ書面の合意のときだけ合格) と
 *     公取委テキスト (60日以内なら合意で2日超も可) が食い違う。法律の専門家の確認までは verdict='unconfirmed' (要確認)。
 *   - ★2026-10-03 (T08): 第7条の書類等の保存期間は民法第140条・第143条で数える (toritekiRetentionLastDay)。
 *     数え方の最終判断は士業の確認待ち (要確認)。確認までは長く保存する側で数える。
 */

// ===========================================================================
// 値表 (数値はここだけに置く)
// ===========================================================================
export const TORITEKI_VALUES = {
  law_title: '製造委託等に係る中小受託事業者に対する代金の支払の遅延等の防止に関する法律',
  law_abbrev: '取適法',
  law_formal_abbrev: '中小受託取引適正化法',
  law_old_title: '下請代金支払遅延等防止法 (下請法)',
  law_id: '331AC0000000120',
  effective_date: '2026-01-01',
  /** 第3条1項: 受領日 (役務・特定運送は提供を受けた日) から起算して60日の期間内 (受領日を算入) */
  payment_limit_days: 60,
  /** テキスト p.62: 月単位の締切制度は「受領後2か月以内」として運用 */
  monthly_closing_limit_months: 2,
  /** テキスト p.62-63・運用基準(6)カ: 金融機関の休業日による順延が認められる日数 (書面の合意が条件) */
  bank_holiday_max_shift_days: 2,
  /** 第6条・規則第9号: 遅延利息の率 年14.6% (千分率の分子で持つ) */
  late_interest_rate_per_mille: 146,
  /** 遅延利息の日割りの分母 (要一次確認: うるう年の扱い。安全側で365) */
  late_interest_day_basis: 365,
  /** 規則第10号 第3条: 書類等の保存期間 */
  record_retention_years: 2,
  /** 第2条8項・9項: 資本金基準 (円) */
  capital: { tier1: 300_000_000, tier2: 10_000_000, tier3: 50_000_000 },
  /** 第2条8項5号・6号: 従業員基準 (常時使用する従業員の数) */
  employees: { groupA: 300, groupB: 100 },
} as const;

/** フリーランス法 第4条の値 */
export const FREELANCE_PAYMENT_VALUES = {
  law_id: '505AC0000000025',
  /** 第4条1項: 受領日から起算して60日の期間内 */
  payment_limit_days: 60,
  /** 第4条3項: 再委託は元委託支払期日から起算して30日の期間内 (明示が条件) */
  reconsign_limit_days: 30,
} as const;

// ===========================================================================
// 暦日の計算 (日本の暦日で数える。Date の時刻は使わない)
// ===========================================================================
export type Ymd = string; // 'YYYY-MM-DD'

const pad2 = (n: number) => String(n).padStart(2, '0');
const JST_OFFSET_MS = 9 * 3600 * 1000;

/**
 * Date または 'YYYY-MM-DD' を日本の暦日に直す。
 * ★Date は日本時間 (UTC+9) の暦日として読む。new Date('2026-06-01') (UTC 0時) も
 *   new Date(2026, 5, 1) (端末の0時) も 2026-06-01 になる (日本とそれより西の時間帯の端末)。
 */
export function toYmd(d: Date | string): Ymd {
  if (typeof d === 'string') {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(d);
    if (!m) throw new Error(`日付は YYYY-MM-DD で渡してください (受け取った値: ${d})`);
    return `${m[1]}-${m[2]}-${m[3]}`;
  }
  const t = new Date(d.getTime() + JST_OFFSET_MS);
  return `${t.getUTCFullYear()}-${pad2(t.getUTCMonth() + 1)}-${pad2(t.getUTCDate())}`;
}
/** 暦日を通し日数に直す (1970-01-01 = 0) */
function toSerial(ymd: Ymd): number {
  const [y, m, d] = ymd.split('-').map(Number);
  return Math.round(Date.UTC(y, m - 1, d) / 86_400_000);
}
function fromSerial(n: number): Ymd {
  const t = new Date(n * 86_400_000);
  return `${t.getUTCFullYear()}-${pad2(t.getUTCMonth() + 1)}-${pad2(t.getUTCDate())}`;
}
/** 暦日を n 日ずらす */
export function addDaysYmd(ymd: Ymd, n: number): Ymd {
  return fromSerial(toSerial(ymd) + n);
}
/** start を1日目として target は何日目か (target が前なら 0 以下) */
export function dayNumber(start: Date | string, target: Date | string): number {
  return toSerial(toYmd(target)) - toSerial(toYmd(start)) + 1;
}
/** start を1日目として n 日目の暦日 (「起算して n 日の期間」の最終日) */
export function nthDayFrom(start: Date | string, n: number): Ymd {
  return addDaysYmd(toYmd(start), n - 1);
}
/** 日本の暦日 → その日の日本時間0時の Date */
export function ymdToJstDate(ymd: Ymd): Date {
  return new Date(`${ymd}T00:00:00+09:00`);
}
const daysInMonth = (y: number, m: number) => new Date(Date.UTC(y, m, 0)).getUTCDate();
const endOfMonthYmd = (y: number, m: number): Ymd => `${y}-${pad2(m)}-${pad2(daysInMonth(y, m))}`;
const cmp = (a: Ymd, b: Ymd) => toSerial(a) - toSerial(b);

/**
 * 受領日を算入して「2か月」の最終日の範囲 (月単位の締切制度の運用)。
 *  - 2か月後に応当日がある: 応当日の前日 (6/1→7/31、5/26→7/25)。lo=hi。
 *  - 応当日が無い (12/29〜12/31 受領の2月など): 単調性から lo=(その月の末日の前日)・hi=(その月の末日)。
 *    lo〜hi の間は要一次確認。
 */
function twoMonthWindow(received: Ymd, months: number): { lo: Ymd; hi: Ymd } {
  const [y0, m0, d0] = received.split('-').map(Number);
  let y = y0; let m = m0 + months;
  while (m > 12) { m -= 12; y++; }
  if (d0 <= daysInMonth(y, m)) {
    const last = addDaysYmd(`${y}-${pad2(m)}-${pad2(d0)}`, -1);
    return { lo: last, hi: last };
  }
  const eom = endOfMonthYmd(y, m);
  return { lo: addDaysYmd(eom, -1), hi: eom };
}

// ===========================================================================
// 支払期日 (第3条) — 締切制度・休業日の順延を含む
// ===========================================================================
export type Verdict = 'ok' | 'violation' | 'unconfirmed';

export interface ToritekiPaymentCheckInput {
  /** 受領日 (役務提供委託・特定運送委託は役務の提供を受けた日。日数を要する場合は終了日) */
  receivedAt: Date | string;
  /** 支払予定日 (定めた支払期日) または実際の支払日 */
  paymentDate: Date | string;
  /** 4条明示された月単位の締切制度か (テキスト p.62) */
  monthlyClosing?: boolean;
  /** 定めた期日が金融機関の休業日のため順延した場合: 元の期日と、翌営業日への順延の書面合意の有無 */
  holidayShift?: { scheduledDate: Date | string; agreedInWriting: boolean };
}
export interface ToritekiPaymentCheckResult {
  verdict: Verdict;
  ok: boolean;
  /** 受領日を1日目として支払日は何日目か */
  dayNumber: number;
  /** 受領日を1日目として60日目 (第3条・締切制度が無い場合の最終日) */
  statutoryLastDay: Ymd;
  /** この取引で許される最終日 (締切制度ありなら 2か月と60日の遅い方。応当日の無い端は下限) */
  limitDate: Ymd;
  /** 期日を60日を超えて定めた場合のみなしの支払期日 (第3条2項) */
  deemedDueDate?: Ymd;
  reasons: string[];
  basis: string[];
}

export function checkToritekiPaymentDate(input: ToritekiPaymentCheckInput): ToritekiPaymentCheckResult {
  const V = TORITEKI_VALUES;
  const recv = toYmd(input.receivedAt);
  const pay = toYmd(input.paymentDate);
  const day60 = nthDayFrom(recv, V.payment_limit_days);
  let lo = day60; let hi = day60;
  const basis = ['取適法 第3条1項 (受領日から起算して60日・受領日を算入)'];
  if (input.monthlyClosing) {
    const w = twoMonthWindow(recv, V.monthly_closing_limit_months);
    // 60日は法の本則。2か月の運用は緩める向きにだけ働く (受領2/1なら60日目の4/1まで可)。
    lo = cmp(w.lo, day60) > 0 ? w.lo : day60;
    hi = cmp(w.hi, day60) > 0 ? w.hi : day60;
    basis.push('取適法テキスト p.62 月単位の締切制度 (受領後2か月以内として運用)');
  }
  const reasons: string[] = [];
  const n = dayNumber(recv, pay);
  let verdict: Verdict;

  if (input.holidayShift) {
    const sched = toYmd(input.holidayShift.scheduledDate);
    const shift = dayNumber(sched, pay) - 1;
    basis.push('取適法テキスト p.62-63・運用基準 第4-2(6)カ (金融機関の休業日による順延)');
    // 元の期日そのものが法定の範囲に収まっているか
    const schedOk = cmp(sched, lo) <= 0 ? 'ok' : cmp(sched, hi) <= 0 ? 'unconfirmed' : 'violation';
    if (schedOk === 'violation') {
      verdict = 'violation';
      reasons.push(`定めた期日 ${sched} が受領日から数えた上限 ${hi} を超えている (第3条)`);
    } else if (shift <= 0) {
      verdict = schedOk;
    } else if (!input.holidayShift.agreedInWriting) {
      verdict = 'violation';
      reasons.push(`翌営業日への順延について書面の合意が無いのに、定めた期日 ${sched} より ${shift} 日遅れて支払っている (第5条1項2号・運用基準(6)カ)`);
    } else if (shift <= V.bank_holiday_max_shift_days) {
      verdict = schedOk;
      reasons.push(`書面の合意があり順延は${shift}日 (2日以内) のため、60日(2か月)を超えても問題としない`);
    } else if (cmp(pay, lo) <= 0) {
      // ★2026-10-03 是正 (REQ-JPO-MNY-014・T08): 安全側の既定。
      //   要件の文言は「順延は2日以内かつ書面の合意あり」のときだけ合格。公取委テキスト p.62-63 は
      //   「順延後も60日(2か月)以内なら合意で2日超も可」とし、両者が食い違う (第1波 I5 の報告・オーナー判断待ち)。
      //   法律の専門家の確認が済むまで、2日を超える順延は合格 (ok) にせず要確認 (unconfirmed) にとどめる。
      //   違反 (violation) とも断定しない (テキストの読みを否定しない)。
      verdict = 'unconfirmed';
      reasons.push(`順延は${shift}日で2日を超える。順延後も受領日から60日(2か月)以内 (${lo} まで) だが、2日を超える順延を書面の合意で認めてよいかは要件の文言と公取委テキストで食い違うため要確認 (法律の専門家の確認待ち・確認までは2日以内に収めるか前の営業日に払うこと)`);
    } else if (cmp(pay, hi) <= 0) {
      verdict = 'unconfirmed';
      reasons.push(`順延後の支払日 ${pay} が応当日の無い月の端にあたり、2か月以内かを確定できない (要一次確認)`);
    } else {
      verdict = 'violation';
      reasons.push(`順延が${shift}日で2日を超え、順延後の支払日 ${pay} が受領日から60日(2か月)を超える`);
    }
  } else if (cmp(pay, lo) <= 0) {
    verdict = 'ok';
  } else if (cmp(pay, hi) <= 0) {
    verdict = 'unconfirmed';
    reasons.push(`受領日 ${recv} の2か月後に応当日が無く、${pay} が2か月以内かを確定できない (公取委への照会待ち・要一次確認)`);
  } else {
    verdict = 'violation';
    reasons.push(input.monthlyClosing
      ? `受領日 ${recv} から2か月 (${hi} まで) を超えている (${n}日目)`
      : `受領日 ${recv} を1日目として ${n} 日目で、60日目 (${day60}) を超えている`);
  }
  const res: ToritekiPaymentCheckResult = {
    verdict, ok: verdict === 'ok', dayNumber: n, statutoryLastDay: day60, limitDate: lo, reasons, basis,
  };
  if (verdict === 'violation' && !input.holidayShift) res.deemedDueDate = day60;
  return res;
}

/** 支払条件 (締め日・支払日・何か月後) */
export interface ClosingPolicy {
  closeDay: number | 'endOfMonth';
  payDay: number | 'endOfMonth';
  offsetMonths: number;
}

/** 受領日と支払条件から支払日 (暦日) を出す。休業日の調整はしない。 */
export function payDateByPolicy(receivedAt: Date | string, policy: ClosingPolicy): Ymd {
  const [y, m, d] = toYmd(receivedAt).split('-').map(Number);
  let cy = y; let cm = m;
  if (policy.closeDay !== 'endOfMonth' && d > policy.closeDay) { cm++; if (cm > 12) { cm = 1; cy++; } }
  let py = cy; let pm = cm + policy.offsetMonths;
  while (pm > 12) { pm -= 12; py++; }
  if (policy.payDay === 'endOfMonth') return endOfMonthYmd(py, pm);
  const pd = Math.min(policy.payDay, daysInMonth(py, pm));
  return `${py}-${pad2(pm)}-${pad2(pd)}`;
}

/**
 * 支払条件そのものが取適法の対象取引で使えるかを、最も不利な受領日 (締め日の翌日) で測る。
 * 12か月×複数年の受領日で試し、1件でも2か月・60日を超えれば violation。
 * (運用基準(6)エ: 締切後30日以内に期日を定めない締切制度は、受領日から60日目までに払えず支払遅延)
 */
export function checkMonthlyClosingTerms(policy: ClosingPolicy, opts: { years?: number[] } = {}): {
  verdict: Verdict;
  worstCase?: { receivedAt: Ymd; payDate: Ymd; dayNumber: number };
  reasons: string[];
} {
  const years = opts.years ?? [2026, 2027, 2028];
  let worst: { receivedAt: Ymd; payDate: Ymd; dayNumber: number } | undefined;
  let verdict: Verdict = 'ok';
  const reasons: string[] = [];
  for (const y of years) for (let m = 1; m <= 12; m++) {
    // 締め日の翌日 = その締め期間の最初の受領日 (最も支払まで長い)
    const candidates: Ymd[] = [];
    if (policy.closeDay === 'endOfMonth') candidates.push(`${y}-${pad2(m)}-01`);
    else if (policy.closeDay + 1 <= daysInMonth(y, m)) candidates.push(`${y}-${pad2(m)}-${pad2(policy.closeDay + 1)}`);
    for (const recv of candidates) {
      const pay = payDateByPolicy(recv, policy);
      const r = checkToritekiPaymentDate({ receivedAt: recv, paymentDate: pay, monthlyClosing: true });
      if (!worst || r.dayNumber > worst.dayNumber) worst = { receivedAt: recv, payDate: pay, dayNumber: r.dayNumber };
      if (r.verdict === 'violation') {
        verdict = 'violation';
        if (reasons.length < 3) reasons.push(`受領${recv}→支払${pay} (${r.dayNumber}日目) が受領後2か月・60日を超える`);
      } else if (r.verdict === 'unconfirmed' && verdict === 'ok') {
        verdict = 'unconfirmed';
        reasons.push(`受領${recv}→支払${pay} は応当日の無い月の端で要一次確認`);
      }
    }
  }
  return { verdict, worstCase: worst, reasons };
}

// ===========================================================================
// 遅延利息 (第6条・年14.6%)
// ===========================================================================
export interface LateInterestInput {
  amountYen: number;
  receivedAt: Date | string;
  /** 実際に支払った日 (手形を交付した場合は満期日を支払日として扱う・Q83) */
  actualPaymentDate: Date | string;
  /** 定めた支払期日 (60日以内に定めていれば、その日を過ぎた支払は支払遅延) */
  agreedDueDate?: Date | string;
}
export function calcToritekiLateInterest(input: LateInterestInput): {
  interestYen: number;
  days: number;
  interestStartDate: Ymd;
  effectiveDueDate: Ymd;
  paymentDelayed: boolean;
  notes: string[];
} {
  const V = TORITEKI_VALUES;
  const recv = toYmd(input.receivedAt);
  const pay = toYmd(input.actualPaymentDate);
  const day60 = nthDayFrom(recv, V.payment_limit_days);
  const start = addDaysYmd(day60, 1); // 60日を経過した日 = 61日目
  const days = Math.max(0, dayNumber(start, pay));
  const agreed = input.agreedDueDate ? toYmd(input.agreedDueDate) : undefined;
  const effectiveDue = agreed && cmp(agreed, day60) <= 0 ? agreed : day60;
  const notes: string[] = [];
  // 整数で 金額×146×日数 / (1000×365)。円未満は安全側 (切上げ)。
  const num = BigInt(Math.round(input.amountYen)) * BigInt(V.late_interest_rate_per_mille) * BigInt(days);
  const den = BigInt(1000 * V.late_interest_day_basis);
  const interest = days === 0 ? 0 : Number(num / den + (num % den > 0n ? 1n : 0n));
  if (days > 0) {
    notes.push('円未満は支払側に不足が出ないよう切上げで計算 (端数の扱いは要確認)');
    // うるう日 (2/29) を含む期間は分母366の読み方があり得る (要一次確認)。安全側で365のまま。
    for (let s = start; cmp(s, pay) <= 0; s = addDaysYmd(s, 1)) {
      if (s.endsWith('-02-29')) { notes.push('期間にうるう日を含む: 日割りの分母は安全側で365 (要一次確認)'); break; }
    }
  }
  return {
    interestYen: interest, days, interestStartDate: start, effectiveDueDate: effectiveDue,
    paymentDelayed: cmp(pay, effectiveDue) > 0, notes,
  };
}

// ===========================================================================
// フリーランス法 第4条 (受領日から60日・再委託は元委託支払期日から30日)
// ===========================================================================
export function checkFreelancePaymentDate(input: {
  receivedAt: Date | string;
  paymentDate: Date | string;
  isReConsignment?: boolean;
  parentPaymentDate?: Date | string;
  /** 再委託である旨・元委託者・元委託支払期日等を明示したか (第4条3項の要件) */
  reconsignmentDisclosed?: boolean;
}): { verdict: Verdict; ok: boolean; lastDay: Ymd; deemedDueDate: Ymd; dayNumber: number; usedReconsignRule: boolean; reasons: string[] } {
  const F = FREELANCE_PAYMENT_VALUES;
  const pay = toYmd(input.paymentDate);
  const reasons: string[] = [];
  const useRecon = !!(input.isReConsignment && input.parentPaymentDate && input.reconsignmentDisclosed);
  if (input.isReConsignment && !useRecon) {
    reasons.push('再委託の特則 (第4条3項) は、再委託である旨・元委託者・元委託支払期日を明示した場合に限る。明示または元委託支払期日が無いため60日の原則で判定');
  }
  const base = useRecon ? toYmd(input.parentPaymentDate as Date | string) : toYmd(input.receivedAt);
  const limit = useRecon ? F.reconsign_limit_days : F.payment_limit_days;
  const last = nthDayFrom(base, limit); // 「起算して…日を経過する日」= limit 日目
  const n = dayNumber(base, pay);
  const ok = cmp(pay, last) <= 0;
  if (!ok) reasons.push(`${useRecon ? '元委託支払期日' : '受領日'} ${base} を1日目として ${n} 日目で、${limit}日目 (${last}) を超えている`);
  return { verdict: ok ? 'ok' : 'violation', ok, lastDay: last, deemedDueDate: last, dayNumber: n, usedReconsignRule: useRecon, reasons };
}

// ===========================================================================
// 適用判定 (第2条8項・9項)
// ===========================================================================
export type ToritekiTransactionType = 'manufacturing' | 'repair' | 'information_product' | 'service' | 'specific_transport';
export interface ToritekiPartyInput {
  capitalYen?: number | null;
  employees?: number | null;
  isIndividual?: boolean;
}
export interface ToritekiApplicabilityInput {
  type: ToritekiTransactionType;
  /** 情報成果物ならプログラム、役務なら運送・倉庫保管・情報処理 (政令 413CO0000000005) か */
  governmentOrderedCategory?: boolean;
  consignor: ToritekiPartyInput;
  contractor: ToritekiPartyInput;
  /** 委託をした日 (YYYY-MM-DD)。2025-12-31 以前は旧法 */
  consignedAt?: string;
  /** 建設業者が請け負った建設工事の再委託か (第2条4項で役務提供委託から除かれる) */
  isConstructionWorkSubcontract?: boolean;
}
export interface ToritekiApplicabilityResult {
  applies: boolean | null;
  verdict: 'applies' | 'not_applicable' | 'unconfirmed';
  basis: string;
  record: { consignor: ToritekiPartyInput; contractor: ToritekiPartyInput; group: 'A' | 'B'; thresholds: Record<string, number>; consignedAt?: string };
  reasons: string[];
}

export function judgeToritekiApplicability(input: ToritekiApplicabilityInput): ToritekiApplicabilityResult {
  const V = TORITEKI_VALUES;
  const groupA = input.type === 'manufacturing' || input.type === 'repair' || input.type === 'specific_transport' || !!input.governmentOrderedCategory;
  const group: 'A' | 'B' = groupA ? 'A' : 'B';
  const upper = groupA ? V.capital.tier1 : V.capital.tier3;
  const empLimit = groupA ? V.employees.groupA : V.employees.groupB;
  const record = {
    consignor: { ...input.consignor }, contractor: { ...input.contractor }, group,
    thresholds: { capital_upper: upper, capital_lower: V.capital.tier2, employees: empLimit },
    consignedAt: input.consignedAt,
  };
  const reasons: string[] = [];
  const out = (applies: boolean | null, basis: string): ToritekiApplicabilityResult => ({
    applies, verdict: applies === null ? 'unconfirmed' : applies ? 'applies' : 'not_applicable', basis, record, reasons,
  });

  if (input.isConstructionWorkSubcontract) {
    reasons.push('建設工事の再委託は取適法の役務提供委託から除かれる (第2条4項)。建設業法 (第24条の3・第24条の6 等) で判定すること');
    return out(false, '第2条第4項 (適用除外)');
  }
  const before = input.consignedAt !== undefined && input.consignedAt < V.effective_date;
  if (before && input.type === 'specific_transport') {
    reasons.push('施行日 (2026-01-01) より前の委託: 旧法に特定運送委託の類型は無い');
    return out(false, '旧法 (改正法附則)');
  }
  const c = input.consignor; const k = input.contractor;
  const kIndiv = !!k.isIndividual;
  const kCap = k.capitalYen;
  // --- 資本金基準 (1〜4号) ---
  let capital: boolean | null = null;
  if (typeof c.capitalYen === 'number') {
    const cc = c.capitalYen;
    if (cc > upper) {
      if (kIndiv) capital = true; else if (typeof kCap === 'number') capital = kCap <= upper;
      if (capital) return out(true, groupA ? '第2条第8項第1号・第9項第1号 (資本金基準)' : '第2条第8項第3号・第9項第3号 (資本金基準)');
    } else if (cc > V.capital.tier2) {
      if (kIndiv) capital = true; else if (typeof kCap === 'number') capital = kCap <= V.capital.tier2;
      if (capital) return out(true, groupA ? '第2条第8項第2号・第9項第2号 (資本金基準)' : '第2条第8項第4号・第9項第4号 (資本金基準)');
    } else {
      capital = false;
    }
  }
  if (before) {
    reasons.push('施行日 (2026-01-01) より前の委託: 改正法附則により旧法 (資本金基準だけ) で判定');
    return out(capital === null ? null : false, '旧法 (改正法附則)');
  }
  // --- 従業員基準 (5号・6号) ---
  if (typeof c.employees === 'number' && typeof k.employees === 'number') {
    if (c.employees > empLimit && k.employees <= empLimit) {
      return out(true, groupA ? '第2条第8項第5号・第9項第5号 (従業員基準)' : '第2条第8項第6号・第9項第6号 (従業員基準)');
    }
    if (capital === null && typeof c.capitalYen !== 'number') {
      reasons.push('委託事業者の資本金が未入力のため資本金基準を確認できていない');
      return out(null, '確認できていない');
    }
    if (capital === null) {
      reasons.push('中小受託事業者の資本金が未入力のため資本金基準を確認できていない');
      return out(null, '確認できていない');
    }
    return out(false, '第2条第8項・第9項のいずれにも該当しない');
  }
  reasons.push('資本金基準で該当せず、常時使用する従業員の数が未入力のため従業員基準 (第2条第8項第5号・第6号) を確認できていない');
  return out(null, '確認できていない');
}

// ===========================================================================
// 特定運送委託 (第2条5項・Q36・Q38)
// ===========================================================================
export type TransportCargo =
  | 'sold_goods' | 'manufactured_goods' | 'repaired_goods' | 'info_product_media'
  | 'free_sample' | 'industrial_waste' | 'free_supplied_material' | 'gift' | 'own_use_goods'
  | 'trade_in_pickup' | 'repair_pickup';
export type TransportDestination = 'counterparty' | 'counterparty_designee' | 'own_site' | 'sales_agent';
export function isSpecificTransportConsignment(input: { cargo: TransportCargo; destination: TransportDestination }): { applies: boolean; reason: string } {
  const objectCargo: TransportCargo[] = ['sold_goods', 'manufactured_goods', 'repaired_goods', 'info_product_media'];
  if (!objectCargo.includes(input.cargo)) {
    return { applies: false, reason: '販売・製造・修理の目的物、情報成果物の媒体ではない物品の運送 (Q36の例: 無償サンプル・産業廃棄物・無償支給品・贈答品・自社使用品・下取り・修理品の引取り)' };
  }
  if (input.destination === 'counterparty' || input.destination === 'counterparty_designee') {
    return { applies: true, reason: '取引の相手方 (相手方が指定する者を含む) に対する目的物の運送 (第2条5項)' };
  }
  return { applies: false, reason: '自社拠点間・自社の販売代理店への運送は取引の相手方に対する運送ではない (Q36⑧・Q38)' };
}

// ===========================================================================
// 支払手段・振込手数料 (第5条1項2号・3号、運用基準キ・ク、Q81・Q99)
// ===========================================================================
export type ToritekiPaymentMethod = 'cash' | 'bank_transfer' | 'promissory_note' | 'electronic_record_claim' | 'factoring' | 'bulk_settlement' | 'other';
export function checkToritekiPaymentMethod(input: {
  method: ToritekiPaymentMethod;
  /** 支払期日に代金の満額の現金を受け取れるか (電子記録債権・一括決済) */
  cashableAtFullAmountByDueDate?: boolean;
  /** 電子記録債権・一括決済の手数料 (受取手数料・システム手数料等) の負担者 */
  settlementFeeBorneBy?: 'consignor' | 'contractor';
  /** 振込手数料の負担者 */
  transferFeeBorneBy?: 'consignor' | 'contractor';
  agreedWithContractor?: boolean;
}): { verdict: 'ok' | 'warning' | 'violation'; reasons: string[] } {
  const reasons: string[] = [];
  if (input.method === 'promissory_note') {
    return { verdict: 'violation', reasons: ['手形の交付は支払遅延に当たる (第5条1項2号・運用基準(6)キ)。現金・振込で支払期日までに満額を支払うこと'] };
  }
  if (input.transferFeeBorneBy === 'contractor') {
    return { verdict: 'violation', reasons: ['振込手数料を中小受託事業者に負担させ代金から差し引くことは、合意の有無にかかわらず減額に当たる (第5条1項3号・Q99)'] };
  }
  if (input.method === 'electronic_record_claim' || input.method === 'factoring' || input.method === 'bulk_settlement') {
    if (input.settlementFeeBorneBy === 'contractor') {
      return { verdict: 'violation', reasons: ['決済に伴う手数料を中小受託事業者に負担させることは、合意の有無にかかわらず支払遅延に当たる (Q81)'] };
    }
    if (input.cashableAtFullAmountByDueDate === false) {
      return { verdict: 'violation', reasons: ['支払期日に満額の現金と引き換えられない電子記録債権・一括決済の使用は支払遅延に当たる (第5条1項2号・運用基準(6)ク)'] };
    }
    if (input.cashableAtFullAmountByDueDate !== true || input.settlementFeeBorneBy === undefined) {
      return { verdict: 'warning', reasons: ['支払期日に満額の現金を受け取れること・手数料を委託側が負担することを確認できていない (割引を要するなら支払遅延)'] };
    }
  }
  if (input.method === 'other') {
    return { verdict: 'warning', reasons: ['金銭・振込以外の支払手段は、支払期日までに満額の金銭と引き換えられるかを確認すること (第5条1項2号)'] };
  }
  return { verdict: 'ok', reasons };
}
/** 振込手数料を代金から差し引く仕訳の可否 (合意があっても不可・Q99) */
export function checkTransferFeeDeduction(input: { deductedYen: number; agreed?: boolean }): { allowed: boolean; reason: string } {
  if (input.deductedYen > 0) {
    return { allowed: false, reason: `振込手数料 ${input.deductedYen} 円を代金から差し引くことは、合意の有無にかかわらず取適法の減額に当たる (第5条1項3号・Q99)。委託側の費用として計上すること` };
  }
  return { allowed: true, reason: '差し引きなし' };
}

// ===========================================================================
// 第4条の明示 (規則第8号 第1条) と第7条の書類 (規則第10号)
// ===========================================================================
/** 常に必要な明示事項 (規則第1条1項1号・2号・4号、法第4条本文の「支払方法」) */
export const TORITEKI_ART4_REQUIRED: ReadonlyArray<{ key: string; label: string; basis: string }> = [
  { key: 'parties', label: '委託事業者及び中小受託事業者の商号・名称 (又は識別できる番号・記号)', basis: '規則第1条1項1号' },
  { key: 'consigned_at', label: '製造委託等をした日', basis: '規則第1条1項2号' },
  { key: 'deliverable', label: '中小受託事業者の給付の内容 (役務提供委託・特定運送委託は提供される役務)', basis: '規則第1条1項2号' },
  { key: 'delivery_date', label: '給付を受領する期日 (役務は提供を受ける期日又は期間)', basis: '規則第1条1項2号' },
  { key: 'delivery_place', label: '給付を受領する場所', basis: '規則第1条1項2号' },
  { key: 'amount', label: '製造委託等代金の額 (やむを得ない事情があるときは算定方法)', basis: '規則第1条1項4号・2項' },
  { key: 'payment_due_date', label: '支払期日', basis: '規則第1条1項4号' },
  { key: 'payment_method', label: '支払方法', basis: '法第4条1項' },
];
/** 条件付きで必要な明示事項 */
export const TORITEKI_ART4_CONDITIONAL: ReadonlyArray<{ key: string; when: string; label: string; basis: string }> = [
  { key: 'inspection_completion_date', when: 'inspects', label: '検査をする場合は、検査を完了する期日', basis: '規則第1条1項3号' },
  { key: 'bulk_settlement_bank_name', when: 'uses_bulk_settlement', label: '一括決済方式: 金融機関の名称', basis: '規則第1条1項5号イ' },
  { key: 'bulk_settlement_amount_and_start', when: 'uses_bulk_settlement', label: '一括決済方式: 貸付け・支払を受けられる額と期間の始期', basis: '規則第1条1項5号ロ' },
  { key: 'bulk_settlement_repayment_date', when: 'uses_bulk_settlement', label: '一括決済方式: 金融機関へ支払う期日', basis: '規則第1条1項5号ハ' },
  { key: 'electronic_record_claim_amount_and_start', when: 'uses_electronic_record_claim', label: '電子記録債権: 額と支払を受けられる期間の始期', basis: '規則第1条1項6号イ' },
  { key: 'electronic_record_claim_due_date', when: 'uses_electronic_record_claim', label: '電子記録債権: 電子記録債権の支払期日', basis: '規則第1条1項6号ロ' },
  { key: 'materials_terms', when: 'supplies_materials', label: '原材料等を購入させる場合は、品名・数量・対価・引渡しの期日・決済の期日及び方法', basis: '規則第1条1項7号' },
  { key: 'undetermined_reason_and_date', when: 'has_undetermined_items', label: '未定事項がある場合は、定められない理由と定める予定期日', basis: '規則第1条1項8号' },
];
/** 第4条の明示事項を満たさない発注は確定させない */
export function validateArt4Disclosure(doc: Record<string, unknown>): { ok: boolean; missing: string[]; labels: string[] } {
  const has = (k: string) => doc[k] !== undefined && doc[k] !== null && doc[k] !== '';
  const missing: string[] = [];
  for (const it of TORITEKI_ART4_REQUIRED) if (!has(it.key)) missing.push(it.key);
  for (const it of TORITEKI_ART4_CONDITIONAL) if (doc[it.when] === true && !has(it.key)) missing.push(it.key);
  const all = [...TORITEKI_ART4_REQUIRED, ...TORITEKI_ART4_CONDITIONAL];
  return { ok: missing.length === 0, missing, labels: missing.map((k) => (all.find((a) => a.key === k) || { label: k }).label) };
}
/** 第7条の書類等に記載する事項 (規則第10号 第1条1項1〜13号)。項目ごとの入力欄は TORITEKI_ART7_FIELDS */
export const TORITEKI_ART7_RECORD_ITEMS: ReadonlyArray<string> = [
  '中小受託事業者の商号・名称 (又は識別できる番号・記号)',
  '製造委託等をした日、給付の内容、受領する期日、受領した給付の内容と受領した日 (役務は提供を受けた日・期間)',
  '検査をした場合は、検査を完了した日・検査の結果・不合格の給付の取扱い',
  '給付の内容を変更させ又はやり直させた場合は、その内容と理由',
  '製造委託等代金の額と支払期日、額に変更があった場合は増減額とその理由',
  '金銭で支払った場合は、支払額・支払日・支払方法',
  '金銭以外の支払手段を使った場合は、その種類・名称・価額・使用日・引換えで得る金銭の額',
  '一括決済方式の場合は、貸付け・支払を受けられる額と期間の始期、金融機関へ支払った日',
  '電子記録債権の場合は、額・支払を受けられる期間の始期・電子記録債権の支払期日',
  '原材料等を購入させた場合は、品名・数量・対価・引渡しの日・決済をした日と方法',
  '代金の一部を支払い又は原材料等の対価を控除した場合は、その後の代金の残額',
  '遅延利息を支払った場合は、その額と支払った日',
  '明示しなかった未定事項がある場合は、定められなかった理由・明示した日・その内容',
];
/**
 * 第7条の書類等の項目 (規則第10号 第1条1項1〜13号)。when が付く項目は、その印が true のときだけ必須。
 * ★2026-10-03 新設 (REQ-JPO-MNY-016・T08): 記載事項を満たさない書類は記録を完了できない (validateArt7Record)。
 *   保存期間 (2年) は「全部の記載又は記録をした日」から数えるため、記録の完了日を確定させる入口になる。
 */
export const TORITEKI_ART7_FIELDS: ReadonlyArray<{ key: string; item: number; when?: string; label: string }> = [
  { key: 'contractor_name', item: 1, label: '中小受託事業者の商号・名称 (又は識別できる番号・記号)' },
  { key: 'consigned_at', item: 2, label: '製造委託等をした日' },
  { key: 'deliverable', item: 2, label: '給付の内容 (役務は提供される役務)' },
  { key: 'delivery_due_date', item: 2, label: '給付を受領する期日 (役務は提供を受ける期日・期間)' },
  { key: 'received_content', item: 2, label: '受領した給付の内容' },
  { key: 'received_at', item: 2, label: '給付を受領した日 (役務は提供を受けた日・期間)' },
  { key: 'inspection_completed_at', item: 3, when: 'inspected', label: '検査を完了した日' },
  { key: 'inspection_result', item: 3, when: 'inspected', label: '検査の結果' },
  { key: 'rejected_goods_handling', item: 3, when: 'inspected', label: '検査に合格しなかった給付の取扱い' },
  { key: 'change_content', item: 4, when: 'changed_or_redone', label: '給付の内容を変更させ又はやり直させた内容' },
  { key: 'change_reason', item: 4, when: 'changed_or_redone', label: '変更・やり直しの理由' },
  { key: 'amount', item: 5, label: '製造委託等代金の額 (算定方法による場合はその算定方法と具体的な金額・規則第1条2項)' },
  { key: 'payment_due_date', item: 5, label: '支払期日' },
  { key: 'amount_change', item: 5, when: 'amount_changed', label: '代金の額の増減額' },
  { key: 'amount_change_reason', item: 5, when: 'amount_changed', label: '増減の理由' },
  { key: 'paid_amount', item: 6, when: 'paid_in_cash', label: '金銭で支払った額' },
  { key: 'paid_at', item: 6, when: 'paid_in_cash', label: '支払日' },
  { key: 'payment_method', item: 6, when: 'paid_in_cash', label: '支払方法' },
  { key: 'instrument_detail', item: 7, when: 'other_instrument_used', label: '金銭以外の支払手段の種類・名称・価額その他' },
  { key: 'instrument_used_at', item: 7, when: 'other_instrument_used', label: 'その支払手段を使用した日' },
  { key: 'instrument_cash_amount', item: 7, when: 'other_instrument_used', label: '引換えで得る金銭の額その他引換えに関する事項' },
  { key: 'bulk_settlement_amount_and_start', item: 8, when: 'bulk_settlement', label: '一括決済方式: 貸付け・支払を受けられる額と期間の始期' },
  { key: 'bulk_settlement_repaid_at', item: 8, when: 'bulk_settlement', label: '一括決済方式: 金融機関へ支払った日' },
  { key: 'erc_amount', item: 9, when: 'electronic_record_claim', label: '電子記録債権の額' },
  { key: 'erc_start', item: 9, when: 'electronic_record_claim', label: '支払を受けられる期間の始期' },
  { key: 'erc_due_date', item: 9, when: 'electronic_record_claim', label: '電子記録債権の支払期日' },
  { key: 'materials_terms', item: 10, when: 'materials_purchased', label: '購入させた原材料等の品名・数量・対価・引渡しの日・決済をした日と方法' },
  { key: 'remaining_amount', item: 11, when: 'partial_paid_or_deducted', label: '一部支払・控除の後の代金の残額' },
  { key: 'late_interest_amount', item: 12, when: 'late_interest_paid', label: '支払った遅延利息の額' },
  { key: 'late_interest_paid_at', item: 12, when: 'late_interest_paid', label: '遅延利息を支払った日' },
  { key: 'undetermined_reason', item: 13, when: 'undetermined_items', label: '明示しなかった事項の内容が定められなかった理由' },
  { key: 'undetermined_disclosed_at', item: 13, when: 'undetermined_items', label: 'その事項を明示した日' },
  { key: 'undetermined_content', item: 13, when: 'undetermined_items', label: '明示した事項の内容' },
];
/** 第7条の書類等の記載事項を満たしているか (満たさない書類は記録を完了させない) */
export function validateArt7Record(record: Record<string, unknown>): { ok: boolean; missing: string[]; labels: string[] } {
  const has = (k: string) => record[k] !== undefined && record[k] !== null && String(record[k]).trim() !== '';
  const missing = TORITEKI_ART7_FIELDS.filter((f) => (f.when === undefined || record[f.when] === true) && !has(f.key));
  return { ok: missing.length === 0, missing: missing.map((f) => f.key), labels: missing.map((f) => `${f.label} (規則第10号 第1条1項${f.item}号)`) };
}

/** 第7条の書類等の保存期間の最終日 (規則第10号 第3条の2年間を民法第140条・第143条で数える) */
export function toritekiRetentionLastDay(recordCompletedAt: Date | string): Ymd {
  // 初日不算入 (民法第140条): 記録を完了した日の翌日から起算する。
  const start = addDaysYmd(toYmd(recordCompletedAt), 1);
  const [y, m, d] = start.split('-').map(Number);
  const yy = y + TORITEKI_VALUES.record_retention_years;
  // 民法第143条2項: 起算日に応当する日の前日に満了。応当する日が無いときはその月の末日に満了。
  if (d > daysInMonth(yy, m)) return endOfMonthYmd(yy, m);
  return addDaysYmd(`${yy}-${pad2(m)}-${pad2(d)}`, -1);
}
/**
 * 第7条の書類等を削除してよいか (規則第10号 第3条: 全部の記載・記録をした日から2年間保存)。
 * ★2026-10-03 是正 (REQ-JPO-MNY-016・T08): 旧実装は「完了日の2年後の同じ月日」まで保存としていたため、
 *   2月28日に完了した書類 (2年後がうるう年) を 2月29日に削除できてしまった (民法第143条では2月29日まで保存期間内)。
 *   いまは toritekiRetentionLastDay (起算日=翌日・応当日の前日に満了) で数える。
 */
export function canDeleteToritekiRecord(recordCompletedAt: Date | string, now: Date | string): boolean {
  return cmp(toYmd(now), toritekiRetentionLastDay(recordCompletedAt)) > 0;
}
/**
 * 生成物の削除操作の前に呼ぶ関所。保存期間内なら allowed=false と日本語の理由を返す。
 * 記録の完了日が無い書類は保存期間を数えられないため削除させない (安全側)。
 * 期間の数え方 (初日不算入) は士業の確認待ち (要確認)。確認までは長く保存する側で数える。
 */
export function guardToritekiRecordDeletion(input: { recordCompletedAt: Date | string | null | undefined; now: Date | string }): {
  allowed: boolean; retainUntil: Ymd | null; deletableFrom: Ymd | null; reason_ja: string; basis: string;
} {
  const basis = '取適法 第7条・令和7年公正取引委員会規則第10号 第3条 (全部の記載又は記録をした日から2年間保存)';
  if (input.recordCompletedAt === null || input.recordCompletedAt === undefined || input.recordCompletedAt === '') {
    return { allowed: false, retainUntil: null, deletableFrom: null, basis,
      reason_ja: '記録を完了した日が入っていないため、保存期間 (2年間) を数えられません。削除できません。記録の完了日を入れてください。' };
  }
  const last = toritekiRetentionLastDay(input.recordCompletedAt);
  const from = addDaysYmd(last, 1);
  if (cmp(toYmd(input.now), last) <= 0) {
    return { allowed: false, retainUntil: last, deletableFrom: from, basis,
      reason_ja: `この書類は取適法の書類等で、${last} まで保存が必要です (2年間)。削除できるのは ${from} からです。` };
  }
  return { allowed: true, retainUntil: last, deletableFrom: from, basis, reason_ja: `保存期間 (${last} まで) を過ぎているため削除できます。` };
}

// ===========================================================================
// 義務・遵守事項の一覧 (条番号は改正後)
// ===========================================================================
export const TORITEKI_DUTIES = [
  '支払期日を定める義務 (第3条) — 受領日から起算して60日以内 (受領日を算入)',
  '発注内容等を明示する義務 (第4条) — 書面又は電磁的方法 (電磁的方法に中小受託事業者の承諾は不要)',
  '遅延利息を支払う義務 (第6条) — 受領日から60日を経過した日から年14.6%',
  '書類等を作成・保存する義務 (第7条) — 2年間保存 (規則第10号 第3条)',
] as const;

export const TORITEKI_PROHIBITIONS = [
  { no: 1, name: '受領拒否', article: '第5条第1項第1号' },
  { no: 2, name: '製造委託等代金の支払遅延 (手形の交付、期日までに満額の金銭と引き換えにくい支払手段の使用を含む)', article: '第5条第1項第2号' },
  { no: 3, name: '製造委託等代金の減額 (振込手数料の差引きを含む)', article: '第5条第1項第3号' },
  { no: 4, name: '返品', article: '第5条第1項第4号' },
  { no: 5, name: '買いたたき', article: '第5条第1項第5号' },
  { no: 6, name: '購入・利用強制', article: '第5条第1項第6号' },
  { no: 7, name: '報復措置', article: '第5条第1項第7号' },
  { no: 8, name: '有償支給原材料等の対価の早期決済', article: '第5条第2項第1号' },
  { no: 9, name: '不当な経済上の利益の提供要請', article: '第5条第2項第2号' },
  { no: 10, name: '不当な給付内容の変更・やり直し', article: '第5条第2項第3号' },
  { no: 11, name: '協議に応じない一方的な代金決定', article: '第5条第2項第4号' },
] as const;
