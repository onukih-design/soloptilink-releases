/**
 * @fileoverview Phase 11 - 介護ドメイン DNA
 *
 * 介護保険法 + 介護報酬告示 + LIFE (科学的介護情報システム) +
 * ケアプランデータ連携標準仕様 + 国保連伝送 を実装。
 *
 * Claude Code は「介護報酬は単位制です」で止まる。
 * 本モジュールは:
 *   1. 要介護度 (要支援1,2 + 要介護1〜5) と区分支給限度基準額
 *   2. 介護報酬: 単位 → 円換算 (地域区分 1〜7級地)
 *   3. サービスコード (居宅介護支援/訪問介護/通所介護/短期入所等)
 *   4. ケアプラン (1表/2表/3表/4表/5表/6表/7表) の構造
 *   5. LIFE 提出データ (令和3年度〜)
 *   6. 国保連伝送フォーマット (簡易版)
 *   7. 加算・減算ロジック (介護職員等処遇改善加算 = 割合の加算・版で率が変わる)
 *   8. 給付管理票
 *
 * ★2026-09-30 是正 (jpo-run I3・REQ-JPO-FIX-011):
 *   - 訪問介護の単位を令和6年度の値へ (旧: 令和3年度の 167/250/396/579/183/225 を「R6」と表示していた)
 *   - 単価をサービスの人件費割合区分 (70/55/45%・福祉用具等は10円) で引く (旧: 訪問介護の70%表を全サービスに流用)
 *   - 利用者負担を記載要領の給付率方式へ (旧: round(費用額×負担割合))
 *   - 処遇改善加算を割合の加算・四捨五入・日付で版を選ぶ形へ (旧: 245単位の固定値・切り捨て・版が1本)
 * ★値の正本は lib/japan/reward-calendar.json (報酬エンジン)。この部品はスキルの配布写しに単独で入るため
 *   値を内に持つが、正本と食い違わないことを lib/japan/_verify/jpo-I3-care-ledger.verify.mjs で照合している。
 */

// ============================================================================
// Types
// ============================================================================

/** 要介護度 */
export type CareLevel =
  | 'support_1' | 'support_2'
  | 'care_1' | 'care_2' | 'care_3' | 'care_4' | 'care_5';

/** 区分支給限度基準額 (R6改定後・単位/月) */
export const CARE_LIMIT_UNITS: Record<CareLevel, number> = {
  support_1: 5_032,
  support_2: 10_531,
  care_1: 16_765,
  care_2: 19_705,
  care_3: 27_048,
  care_4: 30_938,
  care_5: 36_217,
};

/** 地域区分 (1級地〜7級地 + その他) と単価 (10円基準・サービス区分別) */
export type RegionGrade = '1' | '2' | '3' | '4' | '5' | '6' | '7' | 'other';

/** 人件費割合70%区分 (訪問介護・訪問看護・居宅介護支援 等) の 1単位あたり円 (告示第93号) */
export const REGION_UNIT_YEN_HOMECARE: Record<RegionGrade, number> = {
  '1': 11.40,  // 東京特別区など
  '2': 11.12,  // 横浜市・大阪市など
  '3': 11.05,
  '4': 10.84,
  '5': 10.70,
  '6': 10.42,
  '7': 10.21,
  'other': 10.00,
};

/** 人件費割合区分 */
export type LaborCategory = 'ratio70' | 'ratio55' | 'ratio45' | 'fixed10';

/**
 * 人件費割合区分ごとの 1単位あたり円 (平成27年厚労告第93号・千分率の表そのもの)。
 *   55%: 短期入所生活介護・訪問リハ・通所リハ 等 / 45%: 通所介護・施設 等 / fixed10: 福祉用具貸与・居宅療養管理指導 (千分の千)
 */
export const REGION_UNIT_YEN_BY_LABOR: Record<LaborCategory, Record<RegionGrade, number>> = {
  ratio70: REGION_UNIT_YEN_HOMECARE,
  ratio55: { '1': 11.10, '2': 10.88, '3': 10.83, '4': 10.66, '5': 10.55, '6': 10.33, '7': 10.17, 'other': 10.00 },
  ratio45: { '1': 10.90, '2': 10.72, '3': 10.68, '4': 10.54, '5': 10.45, '6': 10.27, '7': 10.14, 'other': 10.00 },
  fixed10: { '1': 10.00, '2': 10.00, '3': 10.00, '4': 10.00, '5': 10.00, '6': 10.00, '7': 10.00, 'other': 10.00 },
};

/** サービスコード (代表) */
export type ServiceCode =
  | 'home_visit_care'        // 訪問介護 (身体介護/生活援助)
  | 'home_visit_bathing'     // 訪問入浴介護
  | 'home_visit_nursing'     // 訪問看護
  | 'home_visit_rehab'       // 訪問リハビリテーション
  | 'day_service'            // 通所介護 (デイサービス)
  | 'day_rehab'              // 通所リハビリテーション (デイケア)
  | 'short_stay'             // 短期入所生活介護 (ショートステイ)
  | 'group_home'             // 認知症対応型共同生活介護
  | 'special_nursing_home'   // 介護老人福祉施設 (特養)
  | 'health_care_facility'   // 介護老人保健施設 (老健)
  | 'medical_care_facility'  // 介護医療院
  | 'care_management';       // 居宅介護支援 (ケアマネ)

/** サービスごとの人件費割合区分 (告示第93号の表) */
export const SERVICE_LABOR_CATEGORY: Record<ServiceCode, LaborCategory> = {
  home_visit_care: 'ratio70',
  home_visit_bathing: 'ratio70',
  home_visit_nursing: 'ratio70',
  care_management: 'ratio70',
  home_visit_rehab: 'ratio55',
  day_rehab: 'ratio55',
  short_stay: 'ratio55',
  day_service: 'ratio45',
  group_home: 'ratio45',
  special_nursing_home: 'ratio45',
  health_care_facility: 'ratio45',
  medical_care_facility: 'ratio45',
};

/** 介護報酬テーブルエントリ */
export interface CareFeeItem {
  serviceCode: ServiceCode;
  /** サービス内容コード (10桁) */
  contentCode: string;
  name: string;
  /** 1回/1日あたりの単位 */
  units: number;
  /** 算定要件 */
  requirements?: string;
  revision: 'R3' | 'R6';
}

export const STANDARD_CARE_FEES: CareFeeItem[] = [
  // 訪問介護 (令和6年度改定・2024-04-01〜。令和8年度期中改定で据え置き)
  //   出典: 介護給付費分科会第239回 参考資料2-1『介護報酬の算定構造』https://www.mhlw.go.jp/content/12300000/001195509.pdf
  { serviceCode: 'home_visit_care', contentCode: '1110', name: '身体介護 20分未満', units: 163, revision: 'R6' },
  { serviceCode: 'home_visit_care', contentCode: '1111', name: '身体介護 20分以上30分未満', units: 244, revision: 'R6' },
  { serviceCode: 'home_visit_care', contentCode: '1112', name: '身体介護 30分以上1時間未満', units: 387, revision: 'R6' },
  { serviceCode: 'home_visit_care', contentCode: '1113', name: '身体介護 1時間以上1時間半未満', units: 567, revision: 'R6' },
  { serviceCode: 'home_visit_care', contentCode: '1211', name: '生活援助 20分以上45分未満', units: 179, revision: 'R6' },
  { serviceCode: 'home_visit_care', contentCode: '1212', name: '生活援助 45分以上', units: 220, revision: 'R6' },

  // 通所介護 (R6改定後・通常規模型・所要時間 7-8時間)
  { serviceCode: 'day_service', contentCode: '5511', name: '通常規模 7-8時間 要介護1', units: 658, revision: 'R6' },
  { serviceCode: 'day_service', contentCode: '5512', name: '通常規模 7-8時間 要介護2', units: 777, revision: 'R6' },
  { serviceCode: 'day_service', contentCode: '5513', name: '通常規模 7-8時間 要介護3', units: 900, revision: 'R6' },
  { serviceCode: 'day_service', contentCode: '5514', name: '通常規模 7-8時間 要介護4', units: 1023, revision: 'R6' },
  { serviceCode: 'day_service', contentCode: '5515', name: '通常規模 7-8時間 要介護5', units: 1148, revision: 'R6' },

  // 短期入所生活介護
  { serviceCode: 'short_stay', contentCode: '2111', name: '短期入所生活介護 (Ⅰ)単独型・従来型個室 要介護1', units: 645, revision: 'R6' },
  { serviceCode: 'short_stay', contentCode: '2112', name: '同 要介護2', units: 715, revision: 'R6' },

  // 居宅介護支援
  { serviceCode: 'care_management', contentCode: '4311', name: '居宅介護支援費(Ⅰ) 要介護1・2', units: 1086, revision: 'R6' },
  { serviceCode: 'care_management', contentCode: '4312', name: '居宅介護支援費(Ⅰ) 要介護3〜5', units: 1411, revision: 'R6' },

  // ★処遇改善加算・特定事業所加算は「所定単位数に対する割合の加算」であり固定単位ではない (是正 #7)。
  //   処遇改善加算は applyProcessingImprovementAddition()、特定事業所加算(Ⅰ)は所定単位 × 20/100 (算定構造) で算定する。
];

// ============================================================================
// 算定: 単位 → 円
// ============================================================================

/**
 * 単位 → 円。1単位の単価はサービスの人件費割合区分で引く (通所介護=45%・短期入所生活介護=55% 等)。
 * 費用額 = floor(総単位 × 単価)、保険請求額 = floor(費用額 × 給付率)、利用者負担 = 費用額 − 保険請求額
 * (厚労省『介護給付費請求書等の記載要領』の給付率方式)。
 * 人件費割合区分の違うサービスを1回で渡すと単価を1つに決められないため例外にする (事業所・サービスごとに呼ぶ)。
 */
export function calcCareFeeYen(input: {
  items: { contentCode: string; quantity?: number }[];
  regionGrade: RegionGrade;
  copayRatio: 0.1 | 0.2 | 0.3; // 1割/2割/3割負担
  feeTable?: CareFeeItem[];
  unitYenTable?: Record<RegionGrade, number>;
}): {
  totalUnits: number;
  totalYen: number;
  copayYen: number;
  insurerYen: number;
  unitYen: number;
} {
  const table = input.feeTable ?? STANDARD_CARE_FEES;
  let totalUnits = 0;
  const categories = new Set<LaborCategory>();
  for (const it of input.items) {
    const fee = table.find((f) => f.contentCode === it.contentCode);
    if (!fee) continue;
    categories.add(SERVICE_LABOR_CATEGORY[fee.serviceCode]);
    totalUnits += fee.units * (it.quantity ?? 1);
  }
  if (!input.unitYenTable && categories.size > 1) {
    throw new Error('calcCareFeeYen: 人件費割合区分の違うサービスが混ざっています。サービスごとに分けて計算してください');
  }
  const category: LaborCategory = [...categories][0] ?? 'ratio70';
  const unitYen = (input.unitYenTable ?? REGION_UNIT_YEN_BY_LABOR[category])[input.regionGrade];
  // 単価は小数2桁なので 100 倍して整数で掛ける (二進浮動小数の 11.3999… による -1円を避ける)
  const totalYen = Math.floor((totalUnits * Math.round(unitYen * 100)) / 100);
  const copayPct = Math.round(input.copayRatio * 100);
  const insurerYen = Math.floor((totalYen * (100 - copayPct)) / 100);
  const copayYen = totalYen - insurerYen;
  return { totalUnits, totalYen, copayYen, insurerYen, unitYen };
}

// ============================================================================
// 区分支給限度額 超過チェック
// ============================================================================

export function checkLimitExcess(input: {
  careLevel: CareLevel;
  plannedUnits: number;
}): { withinLimit: boolean; limitUnits: number; excessUnits: number; excessSelfPayYen: number; excessUnitYen?: number } {
  const limitUnits = CARE_LIMIT_UNITS[input.careLevel];
  const excessUnits = Math.max(0, input.plannedUnits - limitUnits);
  // 限度額超過分は全額自己負担。ここは10円換算の目安であり、実額は地域区分の単価で計算する
  // (報酬エンジン reward-engine の checkUpperLimit に地域区分と人件費割合区分を渡すと実額になる)
  const excessSelfPayYen = excessUnits * 10;
  return {
    withinLimit: excessUnits === 0,
    limitUnits,
    excessUnits,
    excessSelfPayYen,
  };
}

// ============================================================================
// ケアプラン (1表〜7表)
// ============================================================================

export interface CarePlanSheet1 {
  /** 1表: 居宅サービス計画書(1) */
  insuredCardNumber: string;
  insuredName: string;
  birthDate: string;
  careLevel: CareLevel;
  certificationDate: string;
  certificationValidStart: string;
  certificationValidEnd: string;
  careManagerId: string;
  careManagerName: string;
  /** 利用者及び家族の生活に対する意向 */
  userAndFamilyIntent: string;
  /** 介護認定審査会の意見 */
  certificationCommitteeOpinion?: string;
  /** 総合的な援助の方針 */
  comprehensivePolicy: string;
  /** 生活援助中心型の算定理由 */
  livingSupportReason?: string;
}

export interface CarePlanSheet2Item {
  /** 2表: 居宅サービス計画書(2) */
  needsCategory: string; // 生活全般の解決すべき課題
  longTermGoal: { goal: string; period: string };
  shortTermGoal: { goal: string; period: string };
  serviceContent: string;
  serviceCode: ServiceCode;
  frequency: string; // 例: 週3回
  period: string;
}

export interface CarePlanSheet3 {
  /** 3表: 週間サービス計画表 */
  /** 24h × 7days のグリッド */
  weeklyGrid: { day: 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun'; hour: number; serviceCode?: ServiceCode; provider?: string }[];
  /** 主な日常生活上の活動 */
  dailyActivities: string;
  /** 週単位以外のサービス */
  nonWeeklyServices?: string;
}

// ============================================================================
// LIFE (科学的介護情報システム) 提出データ
// ============================================================================

export interface LifeSubmission {
  /** 利用者ID (LIFE 内で発番) */
  lifeUserId: string;
  /** ADL (Barthel Index) */
  barthelIndex: number;
  /** 認知症高齢者の日常生活自立度 */
  dementiaIndependenceLevel: 'Ⅰ' | 'Ⅱa' | 'Ⅱb' | 'Ⅲa' | 'Ⅲb' | 'Ⅳ' | 'M' | 'normal';
  /** 障害高齢者の日常生活自立度 */
  disabilityIndependenceLevel: 'J1' | 'J2' | 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2' | 'normal';
  /** 栄養状態 (BMI/血清アルブミン値/体重変化率) */
  nutritionStatus: { bmi: number; albumin?: number; weightChangePctMonth?: number };
  /** 提出加算種別 */
  additionType: 'science_care_promotion' | 'adl_maintenance' | 'oral_function' | 'rehab_management';
  /** 提出年月 YYYY-MM */
  submissionMonth: string;
}

// ============================================================================
// 給付管理票 (国保連向け)
// ============================================================================

export interface BenefitManagementSheet {
  insuredCardNumber: string;
  serviceMonth: string; // YYYYMM
  careLevel: CareLevel;
  /** 各サービスの給付管理単位 */
  entries: {
    serviceCode: ServiceCode;
    contentCode: string;
    units: number;
    providerNumber: string; // 事業所番号 10 桁
  }[];
  /** 合計給付管理単位 */
  totalManagedUnits: number;
}

export function buildBenefitManagementSheet(input: {
  insuredCardNumber: string;
  serviceMonth: string;
  careLevel: CareLevel;
  serviceItems: { serviceCode: ServiceCode; contentCode: string; units: number; providerNumber: string }[];
}): BenefitManagementSheet {
  const totalManagedUnits = input.serviceItems.reduce((s, e) => s + e.units, 0);
  return {
    insuredCardNumber: input.insuredCardNumber,
    serviceMonth: input.serviceMonth,
    careLevel: input.careLevel,
    entries: input.serviceItems,
    totalManagedUnits,
  };
}

// ============================================================================
// 加算・減算ロジック
// ============================================================================

/** 介護職員等処遇改善加算の区分 (令和8年6月以降は Ia=Ⅰイ/Ib=Ⅰロ/IIa=Ⅱイ/IIb=Ⅱロ・新設サービスは single) */
export type ProcessingImprovementCategory = 'I' | 'II' | 'III' | 'IV' | 'Ia' | 'Ib' | 'IIa' | 'IIb' | 'single' | 'none';

/**
 * 介護職員等処遇改善加算の率 (施行日で切る版)。正本は reward-calendar.json の fy2024 / fy2026_0601。
 * 出典: 老発0313第6号(令和8年3月13日) 別紙1 表1-1(令和6年6月〜令和8年5月の率)・表1-2〜1-5(令和8年6月以降)
 *       https://www.mhlw.go.jp/shogu-kaizen/download/6_tsuuchi_kihontekikangaekata_jimushoritejun.pdf
 */
export const PROCESSING_IMPROVEMENT_RATE_VERSIONS: {
  effectiveFrom: string;
  effectiveTo: string | null;
  rates: Partial<Record<ServiceCode, Partial<Record<ProcessingImprovementCategory, number>>>>;
}[] = [
  {
    effectiveFrom: '2024-06-01',
    effectiveTo: '2026-05-31',
    rates: {
      home_visit_care: { I: 0.245, II: 0.224, III: 0.182, IV: 0.145 },
      day_service: { I: 0.092, II: 0.090, III: 0.080, IV: 0.064 },
      short_stay: { I: 0.140, II: 0.136, III: 0.113, IV: 0.090 },
    },
  },
  {
    effectiveFrom: '2026-06-01',
    effectiveTo: null,
    rates: {
      home_visit_care: { Ia: 0.270, Ib: 0.287, IIa: 0.249, IIb: 0.266, III: 0.207, IV: 0.170 },
      day_service: { Ia: 0.111, Ib: 0.120, IIa: 0.109, IIb: 0.118, III: 0.099, IV: 0.083 },
      short_stay: { Ia: 0.163, Ib: 0.176, IIa: 0.159, IIb: 0.172, III: 0.136, IV: 0.113 },
      care_management: { single: 0.021 },
      home_visit_nursing: { single: 0.018 },
      home_visit_rehab: { single: 0.015 },
    },
  },
];

/**
 * 介護職員等処遇改善加算の単位数 = 所定単位数 × 率 の1単位未満四捨五入
 * (留意事項通知 第2の1(1)①「割合を乗ずる計算を行う度に四捨五入」)。
 * dateISO (サービス提供日) で版を選ぶ。省略時は今日。その版にその区分が無ければ 0 (旧い率で計算しない)。
 */
export function applyProcessingImprovementAddition(input: {
  baseUnits: number;
  /** 処遇改善加算区分 */
  category: ProcessingImprovementCategory;
  /** サービス区分 */
  serviceCode: ServiceCode;
  /** サービス提供日 (YYYY-MM-DD)。版の選択に使う */
  dateISO?: string;
}): number {
  if (input.category === 'none') return 0;
  const d = input.dateISO ?? new Date().toISOString().slice(0, 10);
  const v = PROCESSING_IMPROVEMENT_RATE_VERSIONS.find((x) => d >= x.effectiveFrom && (x.effectiveTo === null || d <= x.effectiveTo));
  const rate = v?.rates[input.serviceCode]?.[input.category];
  if (typeof rate !== 'number') return 0;
  const r = Math.round(rate * 10000);
  return Math.floor((input.baseUnits * r + 5000) / 10000);
}

// ============================================================================
// Default exports
// ============================================================================

export const CARE_LEVEL_LABELS: Record<CareLevel, string> = {
  support_1: '要支援1',
  support_2: '要支援2',
  care_1: '要介護1',
  care_2: '要介護2',
  care_3: '要介護3',
  care_4: '要介護4',
  care_5: '要介護5',
};

export const SERVICE_CODE_LABELS: Record<ServiceCode, string> = {
  home_visit_care: '訪問介護',
  home_visit_bathing: '訪問入浴介護',
  home_visit_nursing: '訪問看護',
  home_visit_rehab: '訪問リハビリ',
  day_service: '通所介護',
  day_rehab: '通所リハビリ',
  short_stay: '短期入所生活介護',
  group_home: '認知症対応型共同生活介護',
  special_nursing_home: '介護老人福祉施設',
  health_care_facility: '介護老人保健施設',
  medical_care_facility: '介護医療院',
  care_management: '居宅介護支援',
};

export const LONGTERM_CARE_REFS = {
  REVENUE_TABLE_URL: 'https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000088373.html',
  LIFE_PORTAL_URL: 'https://life.mhlw.go.jp/',
  CAREPLAN_DATA_LINK_URL: 'https://www.mhlw.go.jp/stf/newpage_22155.html',
};
