/**
 * @fileoverview サプライチェーンのサイバーセキュリティ — 取引先から求められる対策・
 *   事故が起きたときの取引先への報告・サイバー保険 の知識と判定。
 *
 * 収録範囲:
 *   1. 経済産業省「サプライチェーン強化に向けたセキュリティ対策評価制度」(SCS評価制度 ★3/★4)
 *   2. 自工会/部工会・サイバーセキュリティガイドライン (自動車業界 Lv1〜Lv3)
 *   3. 発注者が取引先へ対策を求めるときの取適法・独禁法上の留意点
 *   4. 取引先へのサイバー事故報告の型 (第一報 → 続報 → 最終報)
 *   5. サイバー保険の基礎知識 (補償の区分・一般化してはいけない点)
 *
 * 出典の扱い:
 *   - 各定数の sources に一次資料の名称・URL・本文を確認した日を持つ。
 *   - 制度の状況 (開始時期・版数) は動くため status_as_of を持つ。古くなったら一次資料で確かめ直す。
 *   - 一次資料に根拠が無いものは、根拠欄に「公的資料に明記なし (当社推奨)」と書いて区別する。
 *   - 個情法の報告期限は ppipa_r5.ts の定数が唯一の出典 (ここに日数を直書きしない)。
 *   - 値と一次資料の一致は _verify/cyber-incident.verify.mjs が
 *     legal-values/cyber-incident.legal.json と突き合わせて検査する。
 *
 * ★本モジュールは法的助言ではない。契約要件・保険の補償範囲は契約書・約款の本文で確かめること。
 */

import {
  INITIAL_REPORT_DEADLINE_DAYS,
  FULL_REPORT_DEADLINE_DAYS,
  FULL_REPORT_DEADLINE_DAYS_FOR_INTENTIONAL,
} from './ppipa_r5';

export interface SourceRef {
  title_ja: string;
  url: string;
  /** 発表元の公表日 (分かるもののみ) */
  published?: string;
  /** 本文を確認した日 */
  verified: string;
}

// ============================================================================
// 1. SCS評価制度 (サプライチェーン強化に向けたセキュリティ対策評価制度)
// ============================================================================

export interface ScsLevel {
  star: 3 | 4;
  /** 要求事項の件数 (制度構築方針 p13) */
  requirement_count: number;
  evaluation_ja: string;
  validity_years: number;
  renewal_ja: string;
  /** 自工会/部工会ガイドラインとの対応 (ベンチマーク) */
  benchmark_ja: string;
  /** 登録料 (2028年3月末までの設定。有効期間分の金額) */
  registration_fee_jpy: number;
}

export const SCS_EVALUATION_SCHEME = {
  name_ja: 'サプライチェーン強化に向けたセキュリティ対策評価制度',
  abbreviation_ja: 'SCS評価制度',
  supervisors_ja: ['経済産業省', '内閣官房 国家サイバー統括室'],
  operator_ja: '独立行政法人 情報処理推進機構 (IPA) ※経済産業省の監督のもとで制度を運営',
  status_as_of: '2026-10-10',
  status_ja:
    '制度構築方針 (2026-03-27 公表) と基本規程 (2026-08-28) に基づき準備中。'
    + '申請受付による制度開始は 2027年3月頃の予定 (経済産業省の表記は「2026年度末頃」)。'
    + '開始時点では★を取得した企業はまだ存在しない。',
  planned_start_ym: '2027-03',
  levels: [
    {
      star: 3,
      requirement_count: 26,
      evaluation_ja: '専門家確認付き自己評価 (所定の資格と研修を持つ専門家が確認する)',
      validity_years: 1,
      renewal_ja: '有効期間の満了前に、専門家の確認を経た自己評価の更新版を提出する',
      benchmark_ja: '自工会/部工会ガイドライン Lv1 相当',
      registration_fee_jpy: 10_000,
    },
    {
      star: 4,
      requirement_count: 43,
      evaluation_ja: '第三者評価 (文書確認 + 実地審査 (リモート可) + VPN装置など外部公開機器の技術検証)',
      validity_years: 3,
      renewal_ja: '毎年 自己評価を評価機関へ提出し、3年ごとに第三者評価を受ける',
      benchmark_ja: '自工会/部工会ガイドライン Lv2〜一部Lv3 相当',
      registration_fee_jpy: 60_000,
    },
  ] as ScsLevel[],
  level_relations_ja: [
    '上位の★は下位の要求事項を包含する。ただし★3を取得していないと★4を取得できない関係ではない',
    '★1・★2 は IPA「SECURITY ACTION」を参照する扱い',
    '★5 は 2026年度以降に検討',
  ],
  pass_criteria_ja: '原則として、すべての評価基準に適合すること',
  requirement_categories_ja: ['ガバナンス', '取引先管理', 'リスクの特定', '防御', '検知', 'インシデント対応', '復旧'],
  star3_reviewer_qualifications_ja: [
    '情報処理安全確保支援士', '公認情報セキュリティ監査人', 'CISSP', 'CISM', 'CISA', 'ISO/IEC 27001 主任審査員',
  ],
  upcoming_ja: [
    '申請方法・解説書 (取得ガイド): 2026年10月頃の公開予定 (2026-10-10 時点で未掲載を確認)',
    '評価機関の公表: 2026年12月末頃の予定',
    'SCSセキュリティ専門家の公開: 2027年1月以降の予定',
  ],
  cautions_ja: [
    '制度名をかたる不適切な勧誘について、経済産業省と国家サイバー統括室が注意喚起している (2026-04-27)',
  ],
  sources: [
    { title_ja: '経済産業省「サプライチェーン強化に向けたセキュリティ対策評価制度」特設ページ', url: 'https://www.meti.go.jp/policy/netsecurity/scs.html', verified: '2026-10-10' },
    { title_ja: '経済産業省・国家サイバー統括室「サプライチェーン強化に向けたセキュリティ対策評価制度 制度構築方針」(令和8年3月、IPA 掲載の写し)', url: 'https://www.ipa.go.jp/security/scs/rcu1hd0000007ajp-att/20260327001-br.pdf', published: '2026-03-27', verified: '2026-10-10' },
    { title_ja: 'IPA「SCS評価制度 基本規程 (SCS-100)」', url: 'https://www.ipa.go.jp/security/scs/rcu1hd0000007af3-att/SCS-100.pdf', published: '2026-08-28', verified: '2026-10-10' },
    { title_ja: 'IPA「SCS評価制度 料金設定」', url: 'https://www.ipa.go.jp/security/scs/rcu1hd00000075om-att/pricelist.pdf', published: '2026-09-18', verified: '2026-10-10' },
    { title_ja: 'IPA「SCS評価制度」トップページ・FAQ', url: 'https://www.ipa.go.jp/security/scs/index.html', verified: '2026-10-10' },
  ] as SourceRef[],
} as const;

// ============================================================================
// 2. 自工会/部工会・サイバーセキュリティガイドライン
// ============================================================================

export const JAMA_JAPIA_CYBER_GUIDELINE = {
  name_ja: '自工会/部工会・サイバーセキュリティガイドライン',
  publishers_ja: ['一般社団法人 日本自動車工業会 (自工会)', '一般社団法人 日本自動車部品工業会 (部工会)'],
  version: '2.3',
  published: '2025-09-01',
  scope_ja: 'エンタープライズ領域 (OA環境)。工場 (OT) 領域は別冊の工場領域版 v1.0 (2026-04-16) で扱う',
  requirement_count: 37,
  achievement_condition_count: 153,
  levels: [
    { level: 1, meaning_ja: '企業規模や扱う情報によらず、最低限必要な項目' },
    { level: 2, meaning_ja: '顧客情報や取引先の技術情報を扱う会社が、標準として達成すべき項目' },
    { level: 3, meaning_ja: '到達点 (ベストプラクティス)。完成車メーカー・大規模Tier1・高度な技術を持つ会社に目指すことを求めている' },
  ],
  self_assessment_ja: '付録のチェックシート (Excel・日英) で自己評価する。採点は 0=未実施 / 1=対応中 / 2=対応完了 の3段階。グループ会社は連結ではなく単体ごとに回答する',
  fy2026: {
    target_ja: 'Lv1・Lv2 の達成。難しい場合でも、2026年度末までに Lv1 の全項目を達成すること',
    submission_deadline: '2026-12-31',
  },
  cascade_ja: '自己評価の依頼を受けた会社は、自社の1次仕入先にも自己評価を要請し、さらにその先へ順次展開する。結果は自工会が集計し、業界平均を公表する',
  relation_to_scs_ja: [
    'SCS評価制度は本ガイドラインをベンチマークとして参照する (★3 ≒ Lv1、★4 ≒ Lv2〜一部Lv3)。評価基準ごとに本ガイドライン 2.3版の達成条件番号との対応表が公表されている',
    '自工会・部工会は、最終的に国の制度のガイドへ一本化する方針 (業界としての一本化は2028年度以降。切替えの大日程は検討中)',
    '業界として★3・★4の取得は必須とせず、各社の任意とする方針',
    '自工会の自己評価の結果をもって★を取得したとみなす読み替えは、2026-10-10 時点で公表されていない',
  ],
  status_as_of: '2026-10-10',
  sources: [
    { title_ja: '自工会「自動車産業サイバーセキュリティガイドライン」掲載ページ', url: 'https://www.jama.or.jp/operation/it/cyb_sec/cyb_sec_guideline.html', verified: '2026-10-10' },
    { title_ja: '自工会/部工会・サイバーセキュリティガイドライン 2.3版 (本体PDF)', url: 'https://www.jama.or.jp/operation/it/cyb_sec/docs/cyb_sec_guideline_V02_03.pdf', published: '2025-09-01', verified: '2026-10-10' },
    { title_ja: '自工会「サプライチェーン サイバーセキュリティ推進活動 2026年度説明会資料」', url: 'https://www.jama.or.jp/operation/it/cyb_sec/docs/cyb_sec_supply_chain_FY2026_briefing_materials.pdf', published: '2026-09-16', verified: '2026-10-10' },
    { title_ja: '部工会「サイバーセキュリティガイドライン 最新版」掲載ページ', url: 'https://www.japia.or.jp/work/ict/cybersecurity-newest', verified: '2026-10-10' },
  ] as SourceRef[],
} as const;

// ============================================================================
// 3. 発注者が取引先へ対策を求めるときの留意点 (取適法・独禁法)
// ============================================================================

export const SUPPLY_CHAIN_REQUEST_CAUTIONS = {
  summary_ja: '取引先にセキュリティ対策を要請すること自体は、直ちに独禁法・取適法上の問題にはならない。ただし進め方によっては問題になり得る',
  may_be_problematic_ja: [
    '対策によるコスト上昇分について協議せず、取引価格を据え置く',
    '根拠が不明確なセキュリティ対策費を取引先に負担させる',
    '同等の対策を講じている取引先に、発注者が指定する高価なサービスの利用を強制する',
  ],
  recommended_practice_ja: [
    '説明会などで、費用負担の考え方と、対策費用が価格交渉の対象になることを取引先へ周知する',
    '価格交渉の結果は、双方が書面に記録して保存する',
    '★をどう契約要件とするかは当事者間で円満に合意する (SCS FAQ)',
  ],
  sources: [
    { title_ja: '経済産業省・公正取引委員会「サプライチェーン全体のサイバーセキュリティ向上のための取引先とのパートナーシップの構築に向けて」(令和4年10月28日、令和7年12月26日更新)', url: 'https://www.meti.go.jp/policy/netsecurity/partnership2.html', published: '2025-12-26', verified: '2026-10-10' },
    { title_ja: '同 想定事例及び解説 (概要)', url: 'https://www.meti.go.jp/policy/netsecurity/partnership_gaiyou.pdf', verified: '2026-10-10' },
  ] as SourceRef[],
} as const;

/** 取引先から求められている対策の目安を返す (参考。最終判断は取引先との合意と契約による) */
export function recommendSupplyChainSecurityTargets(input: {
  /** 自動車業界のサプライチェーンに属している */
  inAutomotiveSupplyChain: boolean;
  /** 顧客情報や取引先の技術情報を扱っている */
  handlesCustomerOrTechInfo: boolean;
  /** 取引先から要請されている★ (要請が無ければ undefined) */
  requestedStar?: 3 | 4;
}): { targets_ja: string[]; notes_ja: string[] } {
  const targets: string[] = [];
  const notes: string[] = [];
  if (input.inAutomotiveSupplyChain) {
    targets.push(input.handlesCustomerOrTechInfo
      ? '自工会/部工会ガイドライン Lv2 (2026年度の業界目標は Lv1・Lv2 の達成)'
      : '自工会/部工会ガイドライン Lv1 (2026年度末までに全項目の達成が求められている)');
    notes.push(`自己評価チェックシートの提出期限は ${JAMA_JAPIA_CYBER_GUIDELINE.fy2026.submission_deadline} (2026年度分)`);
  }
  if (input.requestedStar) {
    const lv = SCS_EVALUATION_SCHEME.levels.find((l) => l.star === input.requestedStar)!;
    targets.push(`SCS評価制度 ★${lv.star} (${lv.evaluation_ja} / 有効期間 ${lv.validity_years}年)`);
    notes.push(`SCS評価制度の申請受付は ${SCS_EVALUATION_SCHEME.planned_start_ym} 頃の開始予定。それまでは★を取得できない`);
  } else if (input.handlesCustomerOrTechInfo) {
    targets.push('SCS評価制度 ★3 相当の対策 (取得の要否は取引先との合意による)');
  }
  if (targets.length === 0) {
    targets.push('IPA「SECURITY ACTION」の宣言と、IPA「中小企業の情報セキュリティ対策ガイドライン」の基本的対策');
  }
  notes.push('対策費用は価格交渉の対象になり得る。取引先から一方的に費用負担や特定サービスの利用を求められた場合は、経済産業省・公正取引委員会の想定事例を確認する');
  return { targets_ja: targets, notes_ja: notes };
}

// ============================================================================
// 4. 取引先へのサイバー事故報告の型
// ============================================================================

export type SupplierNoticeStage = 'first' | 'update' | 'final';

export interface SupplierNoticeItem {
  key: string;
  label_ja: string;
  /** その報告段階で書くべきか */
  stages: SupplierNoticeStage[];
  /** 根拠となる資料 (公的資料に無いものはそう書く) */
  basis_ja: string;
}

/** 根拠が公的資料に無い項目の印。ここに当たる項目は当社推奨として区別する */
export const NOT_IN_PUBLIC_SOURCE_JA = '公的資料に明記なし (当社推奨)';

export const SUPPLIER_INCIDENT_NOTICE_ITEMS: SupplierNoticeItem[] = [
  { key: 'facts', label_ja: '発生した事象 (確認済みの事実と、調査中の事項を分けて書く)', stages: ['first', 'update', 'final'],
    basis_ja: 'サイバー攻撃被害に係る情報の共有・公表ガイダンス Q16 / IPA 中小企業ガイドライン 付録8' },
  { key: 'dates', label_ja: '発生日時・発覚日時 (分かっている範囲)', stages: ['first', 'update', 'final'],
    basis_ja: 'ガイダンス Q16 / IPA 付録8 / 自工会ガイドライン 達成条件 No.19 (報告フォーマット)' },
  { key: 'scope', label_ja: '影響範囲 (現時点で判明している範囲と明記。貴社に関係する情報・システムの有無)', stages: ['first', 'update', 'final'],
    basis_ja: 'ガイダンス Q16 / 自工会ガイドライン No.19「業務影響」' },
  { key: 'actions', label_ja: '当社の対応状況 (初動対応・専門組織への相談・所管省庁等への報告状況)', stages: ['first', 'update', 'final'],
    basis_ja: 'ガイダンス Q16 / IPA 付録8「対応経過」' },
  { key: 'cause', label_ja: '原因', stages: ['final'],
    basis_ja: 'ガイダンス Q16 (調査終了後) / IPA 付録8 / IPA 付録5 9.5' },
  { key: 'prevention', label_ja: '再発防止策', stages: ['final'],
    basis_ja: 'ガイダンス Q16 (調査終了後) / IPA 付録8 / IPA 付録5 9.5' },
  { key: 'contact', label_ja: 'お問い合わせ窓口', stages: ['first', 'update', 'final'],
    basis_ja: 'ガイダンス Q16 / IPA 付録8 (受付専用の問い合わせ窓口)' },
  { key: 'requests', label_ja: '貴社にお願いしたいこと (二次被害を防ぐための注意・対応)', stages: ['first', 'update'],
    basis_ja: `${NOT_IN_PUBLIC_SOURCE_JA}。近い根拠はガイダンス Q24 (二次被害防止のための通知)` },
  { key: 'next_report', label_ja: '次回のご報告予定', stages: ['first', 'update'],
    basis_ja: `${NOT_IN_PUBLIC_SOURCE_JA}。多段階で報告する考え方はガイダンス Q17 / IPA 付録8` },
];

export const SUPPLIER_NOTICE_SOURCES: SourceRef[] = [
  { title_ja: 'サイバー攻撃被害に係る情報の共有・公表ガイダンス (同ガイダンス検討会、2023年3月8日)', url: 'https://www.soumu.go.jp/main_content/000867112.pdf', published: '2023-03-08', verified: '2026-10-10' },
  { title_ja: 'IPA「中小企業の情報セキュリティ対策ガイドライン」第4.0版 (付録8 中小企業のためのセキュリティインシデント対応の手引き / 付録5 情報セキュリティ関連規程(サンプル))', url: 'https://www.ipa.go.jp/security/guide/sme/about.html', published: '2026-03-27', verified: '2026-10-10' },
  { title_ja: '経済産業省・IPA「サイバーセキュリティ経営ガイドライン Ver3.0」(指示7・9・10)', url: 'https://www.meti.go.jp/policy/netsecurity/mng_guide.html', published: '2023-03-24', verified: '2026-10-10' },
  { title_ja: '自工会/部工会・サイバーセキュリティガイドライン 2.3版 チェックシート (No.19 報告フォーマット / No.46 委託元への報告・連絡窓口の取り交わし)', url: 'https://www.jama.or.jp/operation/it/cyb_sec/docs/cyb_sec_guideline_CS_v02_03.xlsx', verified: '2026-10-10' },
];

export interface SupplierNoticeInput {
  stage: SupplierNoticeStage;
  senderCompany: string;
  recipientCompany: string;
  detectedAt: string;
  occurredAt?: string;
  /** 確認済みの事実 */
  confirmedFacts: string[];
  /** 調査中の事項 (推測を事実として書かないため、別欄にする) */
  underInvestigation?: string[];
  /** 影響範囲 (現時点で判明している範囲) */
  scope: string;
  /** 貴社への影響の見立て */
  recipientImpact: 'confirmed' | 'possible' | 'none_found_so_far' | 'unknown';
  actionsTaken: string[];
  /** 相談・報告済みの先 (専門組織・所管省庁・警察・個人情報保護委員会 等) */
  reportedTo?: string[];
  requestsToRecipient?: string[];
  /** 次回報告の予定 (例: 「10月15日までに続報」) */
  nextReportPlan?: string;
  rootCause?: string;
  preventiveMeasures?: string[];
  contact: { desk: string; person?: string; phone?: string; email?: string };
  /** 個人データの漏えい等を含む (含むなら個人情報保護委員会への報告が別途必要になり得る) */
  involvesPersonalData?: boolean;
  /** 不正の目的をもって行われたおそれがある行為による (個情法施行規則 第7条第3号) */
  intentionalAct?: boolean;
}

export interface SupplierNotice {
  subject: string;
  body: string;
  /** 段階ごとに書くべき項目が埋まっているか */
  checklist: { key: string; label_ja: string; filled: boolean; basis_ja: string }[];
  /** 送る前に確かめること */
  warnings_ja: string[];
}

const STAGE_LABEL: Record<SupplierNoticeStage, string> = { first: '第一報', update: '続報', final: '最終報' };
const IMPACT_LABEL: Record<SupplierNoticeInput['recipientImpact'], string> = {
  confirmed: '貴社に関係する情報・システムへの影響を確認しています。',
  possible: '貴社に関係する情報・システムに影響が及んでいる可能性があり、調査を進めています。',
  none_found_so_far: '現時点では、貴社に関係する情報・システムへの影響は確認されていません (調査は継続中です)。',
  unknown: '貴社に関係する情報・システムへの影響の有無は、現在調査中です。',
};

/** 取引先へのサイバー事故の報告文 (第一報・続報・最終報) を組み立てる */
export function buildSupplierIncidentNotice(input: SupplierNoticeInput): SupplierNotice {
  const stage = STAGE_LABEL[input.stage];
  const filled: Record<string, boolean> = {
    facts: input.confirmedFacts.length > 0,
    dates: !!input.detectedAt,
    scope: input.scope.trim().length > 0,
    actions: input.actionsTaken.length > 0,
    cause: !!input.rootCause && input.rootCause.trim().length > 0,
    prevention: (input.preventiveMeasures ?? []).length > 0,
    contact: !!input.contact.desk && !!(input.contact.phone || input.contact.email),
    requests: (input.requestsToRecipient ?? []).length > 0,
    next_report: !!input.nextReportPlan && input.nextReportPlan.trim().length > 0,
  };
  const checklist = SUPPLIER_INCIDENT_NOTICE_ITEMS
    .filter((it) => it.stages.includes(input.stage))
    .map((it) => ({ key: it.key, label_ja: it.label_ja, filled: filled[it.key] ?? false, basis_ja: it.basis_ja }));

  const warnings: string[] = [];
  for (const c of checklist) {
    if (!c.filled) warnings.push(`「${c.label_ja}」が未記入です (${stage}で書くべき項目)`);
  }
  warnings.push('取引先との契約・覚書に、事故時の通知期限・通知方法の定めがないか確かめてください (IPA 付録5 8.3 / 経営ガイドライン 指示9)');
  warnings.push('調査中の事項を、事実として断定して書かないでください (ガイダンス Q16: 現時点で判明している範囲として書く)');
  if (input.involvesPersonalData) {
    const finalDays = input.intentionalAct ? FULL_REPORT_DEADLINE_DAYS_FOR_INTENTIONAL : FULL_REPORT_DEADLINE_DAYS;
    warnings.push(
      '個人データの漏えい等を含むため、取引先への連絡とは別に、個人情報保護委員会への報告と本人への通知が必要になり得ます'
      + ` (報告対象に当たる場合、速報は速やかに・目安 概ね3〜${INITIAL_REPORT_DEADLINE_DAYS}日以内 / 確報は${finalDays}日以内。いずれも知った日を1日目として数える)。`
      + ' 委託を受けて扱っている個人データなら、委託元への通知で報告義務を果たす扱いもあるため、委託契約を確かめてください',
    );
  }

  const L: string[] = [];
  L.push(`${input.recipientCompany} 御中`);
  L.push('');
  L.push(input.senderCompany);
  L.push('');
  L.push(`【${stage}】当社におけるサイバーセキュリティ事案についてのご報告`);
  L.push('');
  L.push('平素より大変お世話になっております。');
  L.push('当社において下記のサイバーセキュリティ事案が発生しましたので、'
    + (input.stage === 'final' ? '調査結果と再発防止策をご報告いたします。' : '現時点で判明している内容をご報告いたします。'));
  L.push('ご心配とご迷惑をおかけしておりますことを、深くお詫び申し上げます。');
  L.push('');
  L.push('1. 発生した事象 (確認済みの事実)');
  for (const f of input.confirmedFacts) L.push(`   ・${f}`);
  if ((input.underInvestigation ?? []).length > 0) {
    L.push('   調査中の事項 (現時点で確定していません)');
    for (const f of input.underInvestigation!) L.push(`   ・${f}`);
  }
  L.push('');
  L.push('2. 日時');
  if (input.occurredAt) L.push(`   発生日時: ${input.occurredAt}`);
  L.push(`   発覚日時: ${input.detectedAt}`);
  L.push('');
  L.push('3. 影響範囲 (現時点で判明している範囲)');
  L.push(`   ${input.scope}`);
  L.push(`   ${IMPACT_LABEL[input.recipientImpact]}`);
  L.push('');
  L.push('4. 当社の対応状況');
  for (const a of input.actionsTaken) L.push(`   ・${a}`);
  if ((input.reportedTo ?? []).length > 0) L.push(`   相談・報告済みの先: ${input.reportedTo!.join('、')}`);
  if (input.stage === 'final') {
    L.push('');
    L.push('5. 原因');
    L.push(`   ${input.rootCause ?? '(未記入)'}`);
    L.push('');
    L.push('6. 再発防止策');
    for (const p of input.preventiveMeasures ?? []) L.push(`   ・${p}`);
  } else {
    if ((input.requestsToRecipient ?? []).length > 0) {
      L.push('');
      L.push('5. 貴社にお願いしたいこと');
      for (const r of input.requestsToRecipient!) L.push(`   ・${r}`);
    }
    if (input.nextReportPlan) {
      L.push('');
      L.push(`${(input.requestsToRecipient ?? []).length > 0 ? 6 : 5}. 次回のご報告予定`);
      L.push(`   ${input.nextReportPlan}`);
    }
  }
  L.push('');
  L.push('【お問い合わせ窓口】');
  L.push(`   ${input.contact.desk}${input.contact.person ? ` (担当: ${input.contact.person})` : ''}`);
  if (input.contact.phone) L.push(`   電話: ${input.contact.phone}`);
  if (input.contact.email) L.push(`   メール: ${input.contact.email}`);
  L.push('');
  L.push('以上');

  return {
    subject: `【${stage}】当社におけるサイバーセキュリティ事案についてのご報告 (${input.senderCompany})`,
    body: L.join('\n'),
    checklist,
    warnings_ja: warnings,
  };
}

// ============================================================================
// 5. サイバー保険
// ============================================================================

export type CyberInsuranceCostCategory = 'incident_response_costs' | 'liability' | 'business_interruption';

export const CYBER_INSURANCE_KNOWLEDGE = {
  /** 補償の対象となる事故の類型 (日本損害保険協会) */
  covered_incident_types_ja: [
    '情報の漏えい、またはそのおそれ',
    'ネットワークの所有・使用・管理に起因する他人の業務阻害',
    'サイバー攻撃に起因する他人の身体傷害・財物損壊',
  ],
  /** 発生し得る費用の区分 (日本損害保険協会) */
  cost_categories: [
    { key: 'incident_response_costs' as CyberInsuranceCostCategory, label_ja: '事故対応費用',
      examples_ja: '原因調査、コールセンター、記者会見、見舞金、法律相談、再発防止策 など' },
    { key: 'liability' as CyberInsuranceCostCategory, label_ja: '損害賠償費用',
      examples_ja: '法律上負担する損害賠償金、争訟費用 など' },
    { key: 'business_interruption' as CyberInsuranceCostCategory, label_ja: '利益損害・営業継続費用',
      examples_ja: '喪失利益、収益減少防止費用 など' },
  ],
  /** ランサムウェアの身代金 (日本損害保険協会の注記) */
  ransom_payment_covered: false,
  ransom_note_ja: '日本損害保険協会は、ランサムウェアの被害によって支払った身代金はサイバー保険の対象にならないと注記している',
  public_positioning_ja: [
    'サイバーセキュリティ経営ガイドライン Ver3.0 指示4: リスク対応計画に「サイバー保険の活用」を含め、リスク移転策の例として加入を挙げる。保険はリスクをゼロにしないため、効果と責任範囲を把握すること (脚注17)',
    '同 指示9: 委託先に起因する被害の補償手段として、委託先にサイバー保険への加入を勧める',
    'IPA サイバーセキュリティお助け隊サービス基準 2.1版: インシデント対応時の各種コストを補償する簡易サイバー保険の付帯が、サービスの必須要件 (補償内容と利用者の自己負担を契約に明記)',
    'IPA 中小企業ガイドライン 第4.0版: SECURITY ACTION の宣言や認証の取得で保険料が割引になる場合がある',
  ],
  do_not_generalize_ja: [
    '補償内容は保険会社・プランによって異なる。一般論で「補償される」と答えない',
    '保険料は売上高・業種・セキュリティ対策の状況で決まり、支払限度額と免責金額が設定される',
    '国家レベルの攻撃は戦争扱いとなり補償されない可能性がある (経営ガイドライン Ver3.0 脚注30)',
    '事故発生時に保険会社へ通知する期限は約款ごとに定められる。一般的な期限を定めた公的資料は無い',
  ],
  sources: [
    { title_ja: '日本損害保険協会「企業のための保険ナビ」サイバー保険', url: 'https://www.sonpo.or.jp/sme_insurance/cyber-hoken/', verified: '2026-10-10' },
    { title_ja: 'IPA「サイバーセキュリティお助け隊サービス基準」2.1版', url: 'https://www.ipa.go.jp/security/sme/otasuketai/nq6ept000000faii-att/000092713.pdf', published: '2025-09-08', verified: '2026-10-10' },
    { title_ja: '経済産業省・IPA「サイバーセキュリティ経営ガイドライン Ver3.0」', url: 'https://www.meti.go.jp/policy/netsecurity/downloadfiles/guide_v3.0.pdf', published: '2023-03-24', verified: '2026-10-10' },
    { title_ja: 'IPA「中小企業の情報セキュリティ対策ガイドライン」第4.0版', url: 'https://www.ipa.go.jp/security/guide/sme/about.html', published: '2026-03-27', verified: '2026-10-10' },
  ] as SourceRef[],
} as const;

/** 加入中・検討中のサイバー保険について、確かめるべき点を返す */
export function reviewCyberInsuranceCoverage(policy: {
  coveredCategories: CyberInsuranceCostCategory[];
  /** 区分ごとの支払限度額・免責金額を把握しているか */
  limitsAndDeductiblesKnown: boolean;
  /** 事故時に保険会社へ通知する期限・方法を把握しているか */
  notificationTermsKnown: boolean;
  /** 委託先に起因する事故の扱いを確認したか */
  vendorCausedIncidentsChecked?: boolean;
}): { gaps_ja: string[]; reminders_ja: string[] } {
  const gaps: string[] = [];
  for (const c of CYBER_INSURANCE_KNOWLEDGE.cost_categories) {
    if (!policy.coveredCategories.includes(c.key)) gaps.push(`${c.label_ja} (${c.examples_ja}) が補償に含まれていません`);
  }
  if (!policy.limitsAndDeductiblesKnown) gaps.push('区分ごとの支払限度額と免責金額を、証券・約款で確かめてください');
  if (!policy.notificationTermsKnown) gaps.push('事故時に保険会社へ通知する期限と方法を、約款で確かめてください (期限は約款ごとに異なります)');
  if (policy.vendorCausedIncidentsChecked === false) gaps.push('委託先 (クラウド・保守業者 等) に起因する事故が補償されるかを確かめてください');
  return {
    gaps_ja: gaps,
    reminders_ja: [CYBER_INSURANCE_KNOWLEDGE.ransom_note_ja, ...CYBER_INSURANCE_KNOWLEDGE.do_not_generalize_ja],
  };
}
