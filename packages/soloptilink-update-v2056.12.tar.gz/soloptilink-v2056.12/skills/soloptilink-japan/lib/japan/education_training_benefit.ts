/**
 * lib/japan/education_training_benefit.ts — 教育訓練給付の指定講座の管理と給付見込み
 *
 * 2026-10-04 新設（日本最適化 T32・REQ-140）。
 * 出典（2026-10-03 取得）:
 *  - e-Gov 雇用保険法施行規則（350M50002000003・2026-08-25版）第101条の2の7（率）・第101条の2の8（上限）・
 *    第101条の2の9（4,000円を超えないときは不支給）・第101条の2の12（特定一般: 開始日の14日前までに受給資格確認票）
 *  - 厚生労働省「教育訓練給付金の講座指定等に関するQ&A」（講座指定は年2回・申請受付の時期）
 *  - 厚生労働省「特定一般教育訓練の指定講座を公表しました（令和8年4月1日付け）」
 */

const KISOKU_URL = 'https://laws.e-gov.go.jp/law/350M50002000003';
const QA_URL = 'https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/jinzaikaihatsu/kyouiku_qa.html';

export type KunrenCourseType = 'general' | 'specific_general' | 'professional';

/** 率と上限（施行規則101条の2の7・101条の2の8）。専門実践の上限は連続した2支給単位期間（1年）ごと */
export const KYOIKU_KUNREN_RATES = Object.freeze({
  general: { ratePercent: 20, capJpy: 100_000 },
  specific_general: { ratePercent: 40, capJpy: 200_000 },
  specific_general_qualified: { ratePercent: 50, capJpy: 250_000 },
  professional: { ratePercent: 50, capPerYearJpy: 400_000, capTotalJpy: 1_200_000 },
  professional_qualified: { ratePercent: 70, capPerYearJpy: 560_000, capTotalJpy: 1_680_000 },
  professional_wage105: { ratePercent: 80, capPerYearJpy: 640_000, capTotalJpy: 1_920_000 },
  minimumExclusiveJpy: 4_000, // 算定額が4,000円を超えないときは支給しない
  requiredEligibilityYears: 3, // 支給要件期間3年以上（初回の特例は本部品では判定しない）
  sourceUrl: KISOKU_URL, checkedAt: '2026-10-03',
});

/**
 * 給付見込み。指定講座ID（厚生労働大臣の指定講座の番号）の入力を必須にする。
 *   ★円未満の端数は切り捨てで見込みを出す（端数処理の根拠は要確認）。実際の支給額はハローワークの決定による。
 *   ★専門実践は costJpy を1年分（連続した2支給単位期間）の受講費用として計算する。
 */
export function estimateKyoikuKunrenKyufu(input: { courseId?: string; courseType: KunrenCourseType; costJpy: number; qualifiedAndEmployed?: boolean; wageIncreased105?: boolean; eligibilityYears?: number }) {
  const errors: string[] = [];
  if (!input.courseId || !String(input.courseId).trim()) errors.push('指定講座ID（厚生労働大臣の指定講座の番号）を入力してください。指定講座でない講座は給付の対象になりません');
  if (!(input.costJpy >= 0)) errors.push('受講費用を0円以上で入力してください');
  if (errors.length) return { status: 'invalid' as const, benefitJpy: null, errors, notes: [] as string[] };

  const R = KYOIKU_KUNREN_RATES;
  if (input.eligibilityYears == null || input.eligibilityYears < R.requiredEligibilityYears) {
    return { status: 'needs_confirmation' as const, benefitJpy: null, errors: [] as string[], notes: ['支給要件期間が3年未満、または不明です。初めて受給する方の特例を含め、ハローワークで受給資格を確認してください'] };
  }
  let ratePercent: number; let cap: number;
  if (input.courseType === 'general') { ratePercent = R.general.ratePercent; cap = R.general.capJpy; }
  else if (input.courseType === 'specific_general') {
    const r = input.qualifiedAndEmployed ? R.specific_general_qualified : R.specific_general;
    ratePercent = r.ratePercent; cap = r.capJpy;
  } else {
    const r = input.qualifiedAndEmployed ? (input.wageIncreased105 ? R.professional_wage105 : R.professional_qualified) : R.professional;
    ratePercent = r.ratePercent; cap = r.capPerYearJpy;
  }
  const raw = Math.floor((input.costJpy * ratePercent) / 100);
  const notes: string[] = [];
  let benefitJpy = Math.min(raw, cap);
  if (raw > cap) notes.push(`上限 ${cap.toLocaleString()}円 を適用`);
  if (benefitJpy <= R.minimumExclusiveJpy) {
    notes.push(`算定額 ${benefitJpy.toLocaleString()}円 が4,000円を超えないため支給されません（施行規則101条の2の9）`);
    benefitJpy = 0;
  }
  return { status: 'estimated' as const, benefitJpy, ratePercent, capJpy: cap, errors: [] as string[], notes, sourceUrl: R.sourceUrl };
}

/** 指定講座の登録の検査（指定日は毎年4月1日か10月1日。指定期間は原則3年） */
export function validateDesignatedCourse(input: { courseId?: string; courseType?: KunrenCourseType; designatedFrom?: string; designatedUntil?: string }) {
  const errors: string[] = [];
  if (!input.courseId || !String(input.courseId).trim()) errors.push('指定講座IDは必須です');
  if (!input.courseType || !['general', 'specific_general', 'professional'].includes(input.courseType)) errors.push('講座の類型（一般／特定一般／専門実践）を選んでください');
  const md = (input.designatedFrom || '').slice(5, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.designatedFrom || '') || !['04-01', '10-01'].includes(md)) errors.push('指定日は4月1日または10月1日です（講座指定は年2回）');
  return { ok: errors.length === 0, errors, sourceUrl: QA_URL };
}

/** 講座指定の申請時期のカレンダー（年2回）。具体の受付日は都度公表のため「上旬」までの粒度で持つ */
export function getDesignationApplicationCalendar(year: number) {
  return [
    { designationDate: `${year}-04-01`, applicationWindow: `${year - 1}年10月上旬〜${year - 1}年11月上旬`, exactDates: '未確認（その都度厚生労働省が公表）', sourceUrl: QA_URL, checkedAt: '2026-10-03' },
    { designationDate: `${year}-10-01`, applicationWindow: `${year}年4月上旬〜${year}年5月上旬`, exactDates: '未確認（その都度厚生労働省が公表）', sourceUrl: QA_URL, checkedAt: '2026-10-03' },
  ];
}

/** 特定一般教育訓練: 受給資格確認票の提出期限（訓練開始日の14日前まで） */
export function jukyuShikakuKakuninDeadline(trainingStartDate: string): string {
  const [y, m, d] = trainingStartDate.slice(0, 10).split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1, d) - 14 * 86400000);
  return `${t.getUTCFullYear()}-${String(t.getUTCMonth() + 1).padStart(2, '0')}-${String(t.getUTCDate()).padStart(2, '0')}`;
}
