/**
 * lib/japan/forestry.ts — 林業・木材流通DNA
 *
 * 法令カバレッジ:
 *  - 森林法 (S26法律249) 森林経営計画 / 林地開発許可 (1ha超。太陽光発電設備は2023-04-01以降0.5ha超)
 *  - クリーンウッド法 (合法伐採木材等の流通及び利用の促進に関する法律 H28法律48・H29.5施行 / R5改正・R7.4施行)
 *    2026-10-03 (JPO-T33): 役割区分を改正後の区分 (素材生産販売事業者・第1種・第2種) に是正。値は primary_industry_ledger.ts
 *  - 森林経営管理法 (R1.4施行)
 *  - 木材利用促進法 (R3.10改正 / 公共建築物等木材利用促進法→脱炭素社会木材利用促進法)
 *  - 国有林野管理経営法
 *  - 建築基準法 CLT (Cross Laminated Timber) H28告示611号
 *
 * 参考: 林野庁HP, クリーンウッド法登録事業者リスト, FSC/PEFC/SGEC認証スキーム
 */
import { CLEAN_WOOD_RULES } from './primary_industry_ledger';

// ============================================================================
// 1. 樹種・材積・歩留り
// ============================================================================

export type TreeSpecies =
  | 'sugi' // 杉
  | 'hinoki' // 桧
  | 'akamatsu' // 赤松
  | 'karamatsu' // 唐松
  | 'todomatsu' // トドマツ
  | 'ezomatsu' // エゾマツ
  | 'buna' // ブナ
  | 'nara' // ナラ
  | 'keyaki' // ケヤキ
  | 'douglas_fir' // ベイマツ (輸入)
  | 'spf'; // SPF (輸入)

/** 樹種別 標準密度 (kg/m³ 気乾比重) */
export const TIMBER_DENSITY: Record<TreeSpecies, number> = {
  sugi: 380,
  hinoki: 410,
  akamatsu: 530,
  karamatsu: 530,
  todomatsu: 400,
  ezomatsu: 430,
  buna: 650,
  nara: 670,
  keyaki: 690,
  douglas_fir: 480,
  spf: 420,
};

/**
 * 立木材積計算 (Pressler の片対数式の簡易版)
 *  V = (D/100)^2 × π/4 × H × f
 *    D: 胸高直径 cm, H: 樹高 m, f: 形状係数 (杉0.42 / 桧0.45 / 広葉樹0.50)
 */
export function calcStandingVolumeM3(input: {
  dbhCm: number; // 胸高直径
  heightM: number; // 樹高
  species: TreeSpecies;
}): number {
  const f =
    input.species === 'sugi'
      ? 0.42
      : input.species === 'hinoki'
        ? 0.45
        : input.species === 'akamatsu' || input.species === 'karamatsu'
          ? 0.44
          : 0.5;
  return ((input.dbhCm / 100) ** 2 * Math.PI) / 4 * input.heightM * f;
}

/** 製材歩留り (素材丸太 → 製材品) 目安 50-65% */
export function calcLumberYield(roughM3: number, species: TreeSpecies): number {
  const yieldRate =
    species === 'sugi' || species === 'hinoki'
      ? 0.6
      : species === 'spf' || species === 'douglas_fir'
        ? 0.62
        : 0.5;
  return roughM3 * yieldRate;
}

// ============================================================================
// 2. 森林経営計画 / 林地開発
// ============================================================================

/**
 * 森林経営計画の面積の要件 (値表)
 *   出典: 林野庁「森林所有者又は森林の経営の委託を受けた者がたてる『森林経営計画』」
 *         https://www.rinya.maff.go.jp/j/keikaku/sinrin_keikaku/con_6.html
 *   林班計画: 林班又は隣接する複数林班の面積の2分の1以上 / 区域計画: 市町村長が定める区域内で30ha以上 /
 *   属人計画: 自ら所有する森林の面積が100ha以上 (単独作成に限る)
 */
export const FOREST_PLAN_AREA_RULES = {
  rinpanShareMin: 0.5,
  kuikiMinHa: 30,
  zokujinOwnMinHa: 100,
} as const;

/** 林地開発許可の面積 (値表) — 森林法施行令2条の3。出典: 林野庁「林地開発許可制度の見直しについて（令和4年度）」 */
export const FOREST_DEVELOPMENT_PERMIT_RULES = {
  /** 太陽光発電設備の設置を目的とする開発行為: この面積を超えると許可 (2023-04-01 以後に着手するもの) */
  solarOverHa: 0.5,
  solarFrom: '2023-04-01',
  /** それ以外の目的の開発行為: この面積を超えると許可 */
  otherOverHa: 1.0,
} as const;

/** 森林経営計画の認定要件 (森林法11条) */
export interface ForestPlan {
  ownerHa: number; // 所有森林面積
  planAreaHa: number; // 計画対象面積
  isContiguous: boolean; // 集約化されているか
  hasManagementPath: boolean; // 路網整備
  /** 計画の種類: rinpan=林班計画 / kuiki=区域計画 / zokujin=属人計画 */
  planType?: 'rinpan' | 'kuiki' | 'zokujin';
  /** 林班計画のときの林班 (又は隣接する複数林班) の面積 ha */
  rinpanAreaHa?: number;
}

/** 森林経営計画の面積要件の判定 (林班計画・区域計画・属人計画) */
export function isForestPlanEligible(p: ForestPlan): {
  eligible: boolean;
  reason: string[];
} {
  const R = FOREST_PLAN_AREA_RULES;
  const r: string[] = [];
  if (!p.planType) {
    r.push('計画の種類 (林班計画・区域計画・属人計画) が指定されていないため面積の要件を判定できない (確認できていない)');
  } else if (p.planType === 'zokujin') {
    if (!(p.ownerHa >= R.zokujinOwnMinHa)) r.push(`属人計画は自ら所有する森林が${R.zokujinOwnMinHa}ha以上必要`);
  } else if (p.planType === 'kuiki') {
    if (!(p.planAreaHa >= R.kuikiMinHa)) r.push(`区域計画は市町村長が定める区域内で${R.kuikiMinHa}ha以上必要`);
  } else if (p.planType === 'rinpan') {
    if (!(p.rinpanAreaHa && p.rinpanAreaHa > 0)) r.push('林班計画は林班 (又は隣接する複数林班) の面積の入力が必要');
    else if (!(p.planAreaHa * 2 >= p.rinpanAreaHa)) r.push('林班計画は林班等の面積の2分の1以上が必要');
  }
  if (!p.hasManagementPath) r.push('路網整備が必要');
  return { eligible: r.length === 0, reason: r };
}

/**
 * 林地開発許可 (森林法10条の2・施行令2条の3)
 *   太陽光発電設備の設置が目的で 2023-04-01 以後に着手するもの: 0.5ha を超えると許可
 *   それ以外: 1ha を超えると許可。目的が分からないときは、太陽光なら許可が要る面積を安全側で「要」とする
 */
export function requiresForestDevelopmentPermit(input: {
  developmentHa: number;
  isProtectedForest: boolean; // 保安林か
  /** 開発の目的: solar=太陽光発電設備の設置 / other=それ以外。未指定は不明として扱う */
  purpose?: 'solar' | 'other';
  /** 開発行為の着手日 (YYYY-MM-DD)。省略時は今日 */
  startDate?: string;
}): { permitRequired: boolean; authority: string; reason: string } {
  if (input.isProtectedForest) {
    return {
      permitRequired: true,
      authority: '都道府県知事 (保安林解除)',
      reason: '保安林指定区域内のため、まず保安林解除が必要 (森林法27条)',
    };
  }
  const R = FOREST_DEVELOPMENT_PERMIT_RULES;
  const day = input.startDate ?? new Date().toISOString().slice(0, 10);
  const solarRule = day >= R.solarFrom;
  if (input.purpose === 'solar' && solarRule && input.developmentHa > R.solarOverHa) {
    return { permitRequired: true, authority: '都道府県知事', reason: `森林法10条の2・施行令2条の3 — 太陽光発電設備の設置が目的で${R.solarOverHa}haを超える林地開発は知事許可が必要 (${R.solarFrom}以後)` };
  }
  if (input.purpose === undefined && solarRule && input.developmentHa > R.solarOverHa && input.developmentHa <= R.otherOverHa) {
    return { permitRequired: true, authority: '都道府県知事 (目的により要否が分かれる)', reason: `開発の目的が未入力のため安全側で「要」としている。太陽光発電設備の設置が目的なら${R.solarOverHa}ha超で許可が必要、それ以外は${R.otherOverHa}ha超で必要` };
  }
  if (input.developmentHa > R.otherOverHa) {
    return { permitRequired: true, authority: '都道府県知事', reason: `森林法10条の2 — ${R.otherOverHa}haを超える林地開発は知事許可が必要` };
  }
  return { permitRequired: false, authority: '不要', reason: '許可の面積に達しないため許可不要 (伐採届など他の手続は要確認。都道府県へ事前相談)' };
}

// ============================================================================
// 3. クリーンウッド法 (合法伐採木材等の流通及び利用の促進に関する法律 H29.5施行 / R5改正・R7.4施行)
// ============================================================================
// 2026-10-03 (JPO-T33) 是正: 旧実装は「第一種 = 素材生産・輸入」としていたが、改正後の区分は
//   素材生産販売事業者 (譲渡し先を主体的に決める樹木の所有者・その決定を委ねられた事業者) / 第1種木材関連事業者
//   (国内市場に最初に木材等を持ち込む者: 素材生産販売事業者から丸太を購入・販売を受託する者、自社林を伐採し加工する者、輸入する者) /
//   第2種木材関連事業者 (それ以外の木材関連事業者)。義務は登録の有無ではなく第1種の事業に掛かる (林野庁 クリーンウッド・ナビ)。

/**
 * 互換のため残した区分。first_distributor = 第1種木材関連事業者 (国内市場に最初に木材等を持ち込む者)、
 * second_distributor = 第2種木材関連事業者、unregistered = 区分が分からない (登録の有無と義務の区分は別。classifyCleanWoodRole で判定する)
 */
export type CleanWoodTier =
  | 'first_distributor' // 第1種木材関連事業者 (素材生産販売事業者から丸太を購入・販売受託 / 自社林を伐採し加工 / 輸入)
  | 'second_distributor' // 第2種木材関連事業者 (第1種木材関連事業以外の事業)
  | 'unregistered'; // 区分が分からない (登録木材関連事業者の登録は任意で、義務の区分とは別)

/** 改正後の役割区分 */
export type CleanWoodRole = 'material_producer_seller' | 'first_kind' | 'second_kind' | 'not_target';

/** 事業の実態 (林野庁「対象となる事業者について」の例示に対応) */
export type CleanWoodActivity =
  | 'tree_owner_decides_sale' // 所有する樹木の譲渡し先等を自ら決める樹木の所有者 (自伐林家等)
  | 'entrusted_harvest_and_sale' // 樹木の所有者から譲渡し先の決定を委ねられた事業者 (伐採と販売の両方を受託)
  | 'harvest_only' // 伐採のみを行う (売却の判断をしない)
  | 'buy_logs_from_producer' // 素材生産販売事業者から丸太を購入する (製材工場・原木市場・原木輸出)
  | 'sales_consignment_from_producer' // 素材生産販売事業者から丸太の販売を受託する (原木市場・原木流通)
  | 'harvest_own_and_process' // 自ら所有する樹木を伐採し加工する
  | 'import' // 木材・木材製品を輸入する
  | 'buy_from_wood_business' // 木材関連事業者 (原木市場・輸入商社等) から木材等を譲り受けて譲り渡す
  | 'processing_or_logistics_only' // 加工や物流のみ (譲渡し先の決定権を持たない)
  | 'self_consumption'; // 木材等を自家消費する (譲渡しを行わない)

const CW_OBLIGATIONS: Record<CleanWoodRole, { item: string; kind: '義務' | '努力義務' }[]> = {
  material_producer_seller: [{ item: '原材料情報の提供 (第1種木材関連事業者の求めに応じて)', kind: '義務' }],
  first_kind: [
    { item: '原材料情報の収集・整理', kind: '義務' },
    { item: '合法性の確認 (遅くとも木材等を次の者へ譲り渡す時まで)', kind: '義務' },
    { item: `記録の作成・保存 (作成の日から${CLEAN_WOOD_RULES.recordRetentionYears}年間。譲渡しまで${CLEAN_WOOD_RULES.recordRetentionYears}年を超える場合は譲渡しの時まで)`, kind: '義務' },
    { item: '木材関連事業者に対する情報の伝達', kind: '義務' },
    { item: '定期報告 (一定規模以上の法人のみ・needsCleanWoodPeriodicReport で判定)', kind: '義務' },
  ],
  second_kind: [
    { item: '情報の受取', kind: '努力義務' },
    { item: '情報の保存', kind: '努力義務' },
    { item: '木材関連事業者に対する情報の伝達', kind: '努力義務' },
  ],
  not_target: [],
};

/** クリーンウッド法の役割区分 (素材生産販売事業者・第1種・第2種・対象外) と義務を返す */
export function classifyCleanWoodRole(input: { activity: CleanWoodActivity; isConstructionOrFitOperator?: boolean }): {
  role: CleanWoodRole;
  roleJa: string;
  obligations: { item: string; kind: '義務' | '努力義務' }[];
  notes: string[];
  source: string;
} {
  const src = `${CLEAN_WOOD_RULES.sources[0].title} ${CLEAN_WOOD_RULES.sources[0].url}`;
  const notes: string[] = [];
  let role: CleanWoodRole;
  switch (input.activity) {
    case 'tree_owner_decides_sale':
    case 'entrusted_harvest_and_sale':
      role = 'material_producer_seller';
      break;
    case 'buy_logs_from_producer':
    case 'sales_consignment_from_producer':
    case 'harvest_own_and_process':
    case 'import':
      role = 'first_kind';
      notes.push('自社が第1種・第2種のどちらにも当たる場合、第2種として譲り受ける木材等には第1種の義務は掛かりません。消費者への譲渡し・輸出には情報伝達の義務は無く (努力義務)、合法性の確認と記録の義務は残ります。');
      break;
    case 'buy_from_wood_business':
      role = 'second_kind';
      break;
    default:
      role = 'not_target';
      if (input.activity === 'self_consumption') notes.push('木材等を自家消費する事業者は基本的に木材関連事業者に当たりませんが、建築・建設事業者と FIT/FIP 認定事業者は例外として木材関連事業者に当たります (努力義務)。');
  }
  if (input.isConstructionOrFitOperator) notes.push('建築・建設事業者と FIT/FIP 認定事業者には体制整備などの努力義務があります。');
  const ja: Record<CleanWoodRole, string> = {
    material_producer_seller: '素材生産販売事業者',
    first_kind: '第1種木材関連事業者',
    second_kind: '第2種木材関連事業者',
    not_target: 'クリーンウッド法の対象事業者に当たらない',
  };
  return { role, roleJa: ja[role], obligations: CW_OBLIGATIONS[role], notes, source: src };
}

/** 第1種木材関連事業者の定期報告の対象か (法人として、区分ごとの量が基準「以上」) */
export function needsCleanWoodPeriodicReport(input: {
  isCorporation: boolean;
  domesticLogsM3?: number;
  importedWoodM3?: number;
  importedProductsTon?: number;
}): { required: boolean; reasons: string[]; firstReportDeadline: string; note: string } {
  const P = CLEAN_WOOD_RULES.periodicReport;
  const reasons: string[] = [];
  if (P.corporationOnly && !input.isCorporation) {
    return { required: false, reasons: ['定期報告の基準は「法人として」取り扱う量で判定します (個人事業者は対象外)。'], firstReportDeadline: P.firstReportDeadline, note: '' };
  }
  if ((input.domesticLogsM3 ?? 0) >= P.domesticLogsM3) reasons.push(`国産材 (丸太) の総量が${P.domesticLogsM3.toLocaleString('ja-JP')}m3以上`);
  if ((input.importedWoodM3 ?? 0) >= P.importedWoodM3) reasons.push(`輸入した木材 (丸太換算) の総量が${P.importedWoodM3.toLocaleString('ja-JP')}m3以上`);
  if ((input.importedProductsTon ?? 0) >= P.importedProductsTon) reasons.push(`輸入した家具・紙等の物品の総量が${P.importedProductsTon.toLocaleString('ja-JP')}トン以上`);
  return {
    required: reasons.length > 0,
    reasons,
    firstReportDeadline: P.firstReportDeadline,
    note: `第1種事業として譲り受けた木材等の総量と、そのうち合法性が確認できた数量を毎年1回報告します。第1回の報告期限は ${P.firstReportDeadline} (令和8年6月末)。`,
  };
}

export interface CleanWoodCheck {
  tier: CleanWoodTier;
  hasLegalityProof: boolean; // 合法性確認書類
  countryOfOrigin: string; // 伐採国
  hasFscOrPefc: boolean; // FSC/PEFC認証
  hasDueDiligence: boolean; // R7.4改正で義務化された確認措置
}

export interface CleanWoodResult {
  compliant: boolean;
  level: 'A' | 'B' | 'C' | 'X';
  riskScore: number; // 0(低) - 100(高)
  recommendations: string[];
}

/**
 * クリーンウッド法 適合性判定 (R7.4改正で第1種木材関連事業者の合法性の確認・記録・情報伝達が義務化)
 */
export function evaluateCleanWoodCompliance(c: CleanWoodCheck): CleanWoodResult {
  const recs: string[] = [];
  let risk = 0;

  // 高リスク国 (UNEP/UNODC 違法伐採率高)
  const HIGH_RISK_COUNTRIES = ['Myanmar', 'Cambodia', 'Laos', 'PNG', 'Russia', 'Mozambique'];
  if (HIGH_RISK_COUNTRIES.includes(c.countryOfOrigin)) {
    risk += 50;
    recs.push(`高リスク産地 (${c.countryOfOrigin}) — 第三者監査必須`);
  }

  if (!c.hasLegalityProof) {
    risk += 40;
    recs.push('合法性証明書類が不足 (伐採届出受理通知書 / 森林経営計画認定書など)');
  }
  if (!c.hasDueDiligence && c.tier === 'first_distributor') {
    risk += 30;
    recs.push('R7.4改正: 第1種木材関連事業者は合法性の確認・記録の作成保存 (5年)・情報の伝達が義務');
  }
  if (c.tier === 'unregistered') {
    recs.push('役割区分が分かりません。登録の有無と義務の区分は別です (classifyCleanWoodRole で素材生産販売事業者・第1種・第2種を判定してください)');
  }
  if (!c.hasFscOrPefc) {
    risk += 10;
    recs.push('FSC / PEFC / SGEC認証取得を推奨 (法的要件ではないが調達優位)');
  }

  let level: CleanWoodResult['level'];
  if (risk >= 80) level = 'X';
  else if (risk >= 50) level = 'C';
  else if (risk >= 20) level = 'B';
  else level = 'A';

  return {
    compliant: risk < 50 && c.hasLegalityProof,
    level,
    riskScore: Math.min(100, risk),
    recommendations: recs,
  };
}

// ============================================================================
// 4. CLT (Cross Laminated Timber) 構造設計
// ============================================================================

/** CLT 強度等級 (JAS 3079:2014) */
export const CLT_GRADES = {
  Mx60: { fc: 21.6, fb: 25.2, E: 6000 }, // 杉ベース
  Mx90: { fc: 27.0, fb: 31.5, E: 7000 },
  Mx120: { fc: 32.4, fb: 37.8, E: 9000 }, // 唐松/桧
  S60: { fc: 19.2, fb: 23.4, E: 5500 },
  S90: { fc: 24.0, fb: 27.0, E: 6500 },
} as const;

/** CLT パネル設計判定 (建築基準法 H28告示611号) */
export function checkCltDesign(input: {
  spanM: number;
  panelThicknessMm: number;
  grade: keyof typeof CLT_GRADES;
  loadKnPerM2: number;
  isFireZone: boolean; // 防火地域か
}): { ok: boolean; deflectionMm: number; warnings: string[] } {
  const g = CLT_GRADES[input.grade];
  const I = (1000 * input.panelThicknessMm ** 3) / 12; // 単位幅あたり断面二次モーメント (mm^4/m)
  const w = input.loadKnPerM2; // kN/m²
  const L = input.spanM * 1000; // mm
  // たわみ δ = 5wL^4 / (384 EI)  (簡略)
  const deflectionMm = (5 * (w / 1000) * L ** 4) / (384 * g.E * I);

  const warnings: string[] = [];
  if (deflectionMm > L / 250) warnings.push(`たわみ過大 (許容 L/250 = ${(L / 250).toFixed(1)}mm)`);
  if (input.isFireZone && input.panelThicknessMm < 150) {
    warnings.push('防火地域内では45分準耐火を満たすため150mm以上推奨');
  }
  return { ok: warnings.length === 0, deflectionMm, warnings };
}

// ============================================================================
// 5. 森林経営管理法 (R1.4施行) 集積計画
// ============================================================================

export interface ManagementConsignment {
  ownerName: string;
  forestAreaHa: number;
  consignTo: 'municipality' | 'private_operator';
  termYears: number; // 経営管理権の存続期間
}

/** 森林経営管理法: 経営管理権集積計画の妥当性チェック */
export function validateConsignmentPlan(c: ManagementConsignment): {
  valid: boolean;
  errors: string[];
} {
  const e: string[] = [];
  if (c.forestAreaHa <= 0) e.push('森林面積は正の値');
  if (c.termYears < 5 || c.termYears > 50) e.push('経営管理権の存続期間は5-50年');
  return { valid: e.length === 0, errors: e };
}

// ============================================================================
// 6. 木材利用促進法 (R3.10改正 — 脱炭素社会木材利用促進法)
// ============================================================================

/** 公共建築物の木造化率目標: R12までに低層公共建築物の木造化100% */
export function evaluateWoodUtilizationTarget(input: {
  buildingType: 'low_rise_public' | 'mid_rise_public' | 'high_rise' | 'private';
  storeys: number;
  woodVolumeM3: number;
  totalFloorAreaM2: number;
}): {
  targetMet: boolean;
  recommendation: string;
  carbonStorageTon: number; // 炭素貯蔵量 (CO2換算)
} {
  // 木材1m³あたり約0.25 t-C ≒ 0.92 t-CO2
  const carbonStorageTon = input.woodVolumeM3 * 0.92;

  if (input.buildingType === 'low_rise_public' && input.storeys <= 3) {
    const woodPerArea = input.woodVolumeM3 / input.totalFloorAreaM2;
    const targetMet = woodPerArea >= 0.15; // 0.15 m³/m² が目安
    return {
      targetMet,
      recommendation: targetMet
        ? '木材利用促進法の目標を達成'
        : `木材使用量が目安 (0.15 m³/m²) を下回る — 現在 ${woodPerArea.toFixed(3)}`,
      carbonStorageTon,
    };
  }
  return {
    targetMet: input.woodVolumeM3 > 0,
    recommendation: '中高層・民間建築物も改正法の対象 — 木造ハイブリッド化を検討',
    carbonStorageTon,
  };
}

// ============================================================================
// 7. 認証スキーム比較
// ============================================================================

export const FOREST_CERTIFICATION_SCHEMES = {
  FSC: { fullName: 'Forest Stewardship Council', global: true, costJpyPerYear: 500_000 },
  PEFC: { fullName: 'Programme for Endorsement of Forest Certification', global: true, costJpyPerYear: 350_000 },
  SGEC: { fullName: 'Sustainable Green Ecosystem Council (緑の循環認証)', global: false, costJpyPerYear: 200_000 },
} as const;

/** 認証スキームのレコメンド */
export function recommendForestCert(input: {
  exportTarget: 'EU' | 'US' | 'domestic';
  budgetJpy: number;
  forestAreaHa: number;
}): keyof typeof FOREST_CERTIFICATION_SCHEMES {
  if (input.exportTarget === 'EU' && input.budgetJpy >= 500_000) return 'FSC';
  if (input.exportTarget === 'US') return 'PEFC';
  return 'SGEC'; // 国内向け / 中小規模
}
