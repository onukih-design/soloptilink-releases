/**
 * @fileoverview 承認処理の共通の歯止め (職務分掌・代決の授権・後閲)
 *
 * 稟議 (ringi.ts) と決裁ルート (workflow_engine.ts) の両方が、ここにある判定だけを使う。
 * 判定の決まりを1か所に置き、2つの部品で食い違わないようにする (JPO-FIX-016)。
 *
 * 【決まり】
 *   1. 起案者本人は、自分の起案した案件のどの段も承認・代決できない (職務分掌)。
 *      根拠: 金融庁「財務報告に係る内部統制の評価及び監査に関する実施基準」II.2(2) 職務の分掌
 *            https://www.fsa.go.jp/news/r4/sonota/20230407/1.pdf
 *   2. 段の担当者が決まっていない段は、誰も承認できない (担当者未設定の段の承認を0件にする)。
 *   3. 担当者以外が承認できるのは「代決の授権」の内側だけ。授権は
 *        本人 (principalId)・代決者 (proxyId)・期間 (validFrom〜validTo)・範囲 (scope)
 *      をすべて持つこと。範囲の定めの無い授権 (白紙委任) は無効として扱う。
 *   4. 代決したときは、代決の記録を段に残し、本人への後閲 (事後の確認) の依頼を1件作る。
 *
 * ★要確認 (顧客の決裁規程で決まる点・安全側の既定を置いている):
 *   - 期間は「開始日・終了日を含む・日本時間の暦日」で判定する。
 *   - 金額の上限は「上限ちょうどまで可・1円でも超えたら不可」とする。
 *   - 代決者の職位の下限 (本人の1つ下の職位まで等) は判定していない。規程に定めがあれば授権を出す側で絞ること。
 */

/** 代決の授権 (本人が不在の間、代決者に決裁を任せる取り決め) */
export interface ProxyGrant {
  /** 授権の番号 (代決の記録と後閲の依頼に残す) */
  grantId: string;
  /** 本人 (本来の担当者) */
  principalId: string;
  /** 代決者 */
  proxyId: string;
  /** 期間の開始日 'YYYY-MM-DD' (この日を含む・日本時間) */
  validFrom: string;
  /** 期間の終了日 'YYYY-MM-DD' (この日を含む・日本時間) */
  validTo: string;
  /** 範囲。少なくとも1つの定めが必要 (無いものは白紙委任として無効) */
  scope?: {
    /** 稟議の案件種別 (ringi.ts の RingiCategory) */
    categories?: string[];
    /** 決裁ルートの番号 (workflow_engine.ts の routeId) */
    routeIds?: string[];
    /** 金額の上限 [円] (この額ちょうどまで可) */
    maxAmountYen?: number;
  };
  /** 授権の理由 (出張・休暇など) */
  reason?: string;
}

/** 代決の記録 (段に残す) */
export interface ProxyDecisionRecord {
  grantId: string;
  principalId: string;
  proxyId: string;
  decidedAt: string;
  reason?: string;
}

/** 本人への後閲の依頼 */
export interface PostReviewRequest {
  postReviewId: string;
  /** 稟議の番号 (ringi) / 決裁の番号 (workflow_engine) */
  documentId: string;
  /** ringi の段の番号 */
  stepIndex?: number;
  /** workflow_engine のノード番号 */
  nodeId?: string;
  /** 後閲する人 = 本人 */
  reviewerId: string;
  proxyId: string;
  grantId: string;
  requestedAt: string;
  status: 'pending' | 'reviewed';
}

/** 判定の結果 */
export interface GuardResult {
  ok: boolean;
  reason?: string;
}

const YMD = /^\d{4}-\d{2}-\d{2}$/;

/** 時刻 → 日本時間の暦日 'YYYY-MM-DD' */
export function toJstDate(at: string | Date): string {
  const d = typeof at === 'string' ? new Date(YMD.test(at) ? `${at}T00:00:00+09:00` : at) : at;
  if (Number.isNaN(d.getTime())) throw new Error(`日時が読めません: ${String(at)}`);
  return new Date(d.getTime() + 9 * 3600 * 1000).toISOString().slice(0, 10);
}

/** 承認する人が起案者本人でないか */
export function checkNotApplicant(actorId: string, applicantId: string): GuardResult {
  if (!actorId) return { ok: false, reason: '承認する人が指定されていません。' };
  if (actorId === applicantId) {
    return { ok: false, reason: '起案者本人は自分の起案した案件を承認できません (職務分掌)。別の担当者に承認を依頼してください。' };
  }
  return { ok: true };
}

/**
 * 代決の授権が、この承認に使えるかを判定する。
 * 期間・範囲・本人・代決者・起案者との重なりをすべて確かめ、1つでも外れたら使えない。
 */
export function checkProxyGrant(input: {
  grant: ProxyGrant | undefined | null;
  principalId: string;
  proxyId: string;
  applicantId: string;
  at: string | Date;
  category?: string;
  routeId?: string;
  amountYen?: number;
}): GuardResult {
  const g = input.grant;
  if (!g) return { ok: false, reason: '代決の授権がありません。担当者本人が承認するか、授権を登録してください。' };
  if (!g.grantId) return { ok: false, reason: '代決の授権に番号がありません。' };
  if (!g.principalId || !g.proxyId || !input.principalId || !input.proxyId) {
    return { ok: false, reason: '代決の授権の本人・代決者、または段の担当者が空です。空の欄どうしを一致とはみなしません。' };
  }
  if (g.principalId !== input.principalId) {
    return { ok: false, reason: `代決の授権の本人 (${g.principalId}) がこの段の担当者 (${input.principalId}) と違います。` };
  }
  if (g.proxyId !== input.proxyId) {
    return { ok: false, reason: `代決の授権の代決者 (${g.proxyId}) と承認しようとした人 (${input.proxyId}) が違います。` };
  }
  if (g.proxyId === input.applicantId) {
    return { ok: false, reason: '起案者本人を代決者にすることはできません (職務分掌)。' };
  }
  if (g.proxyId === g.principalId) return { ok: false, reason: '本人と代決者が同じ授権は使えません。' };
  if (!YMD.test(g.validFrom ?? '') || !YMD.test(g.validTo ?? '')) {
    return { ok: false, reason: '代決の期間 (開始日・終了日) が定められていません。' };
  }
  const day = toJstDate(input.at);
  if (day < g.validFrom || day > g.validTo) {
    return { ok: false, reason: `代決の期間 (${g.validFrom}〜${g.validTo}) の外です (承認日 ${day})。` };
  }
  const s = g.scope;
  const hasScope = !!s && ((s.categories && s.categories.length > 0) || (s.routeIds && s.routeIds.length > 0) || typeof s.maxAmountYen === 'number');
  if (!s || !hasScope) {
    return { ok: false, reason: '代決の範囲 (案件の種類・ルート・金額の上限) が定められていません。範囲の無い授権 (白紙委任) は使えません。' };
  }
  if (s.categories && s.categories.length > 0) {
    if (!input.category || !s.categories.includes(input.category)) {
      return { ok: false, reason: `案件の種類 (${input.category ?? '不明'}) が代決の範囲 (${s.categories.join('・')}) の外です。` };
    }
  }
  if (s.routeIds && s.routeIds.length > 0) {
    if (!input.routeId || !s.routeIds.includes(input.routeId)) {
      return { ok: false, reason: `決裁ルート (${input.routeId ?? '不明'}) が代決の範囲 (${s.routeIds.join('・')}) の外です。` };
    }
  }
  if (typeof s.maxAmountYen === 'number') {
    if (typeof input.amountYen !== 'number' || !Number.isFinite(input.amountYen)) {
      return { ok: false, reason: '金額が分からない案件は、金額の上限つきの代決の範囲に入りません。' };
    }
    if (input.amountYen > s.maxAmountYen) {
      return { ok: false, reason: `金額 ${input.amountYen.toLocaleString('ja-JP')}円 が代決の上限 ${s.maxAmountYen.toLocaleString('ja-JP')}円 を超えています。` };
    }
  }
  return { ok: true };
}

/** 授権の一覧から、この承認に使える授権を1つ探す (使えるものが無ければ最初の不可の理由を返す) */
export function findUsableGrant(
  grants: readonly ProxyGrant[] | undefined,
  input: Omit<Parameters<typeof checkProxyGrant>[0], 'grant'>,
): { grant?: ProxyGrant; reason?: string } {
  const list = (grants ?? []).filter((g) => g && g.principalId === input.principalId && g.proxyId === input.proxyId);
  if (list.length === 0) {
    return { reason: `承認しようとした人 (${input.proxyId}) はこの段の担当者 (${input.principalId}) ではなく、代決の授権もありません。` };
  }
  let first: string | undefined;
  for (const g of list) {
    const r = checkProxyGrant({ ...input, grant: g });
    if (r.ok) return { grant: g };
    first = first ?? r.reason;
  }
  return { reason: first };
}

let seq = 0;
/** 後閲の依頼を1件作る */
export function makePostReviewRequest(input: {
  documentId: string;
  stepIndex?: number;
  nodeId?: string;
  grant: ProxyGrant;
  requestedAt: string;
}): PostReviewRequest {
  seq += 1;
  return {
    postReviewId: `PR-${input.documentId}-${input.stepIndex ?? input.nodeId ?? 'x'}-${seq}`,
    documentId: input.documentId,
    ...(input.stepIndex !== undefined ? { stepIndex: input.stepIndex } : {}),
    ...(input.nodeId !== undefined ? { nodeId: input.nodeId } : {}),
    reviewerId: input.grant.principalId,
    proxyId: input.grant.proxyId,
    grantId: input.grant.grantId,
    requestedAt: input.requestedAt,
    status: 'pending',
  };
}
