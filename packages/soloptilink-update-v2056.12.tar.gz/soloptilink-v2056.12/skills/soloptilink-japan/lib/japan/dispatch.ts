/**
 * lib/japan/dispatch.ts — 労働者派遣/職業紹介DNA
 *
 * 法令カバレッジ:
 *  - 労働者派遣法 (S60法律88) H27改正 (3年ルール) + R2改正 (同一労働同一賃金)
 *  - 労働者派遣事業の適正な運営の確保及び派遣労働者の保護等に関する法律施行規則
 *  - 職業安定法 (S22法律141) — 有料職業紹介/無料職業紹介
 *  - 職業安定法施行規則
 *  - 同一労働同一賃金ガイドライン (H30告示)
 *  - 労使協定方式 / 派遣先均等均衡方式
 *  - 派遣禁止業務 (港湾運送/建設/警備/医療等)
 *  - 雇用保険法 / 労災保険法 (派遣元責任)
 *
 * 参考: 厚生労働省職業安定局, 一般社団法人日本人材派遣協会 (JASSA)
 *
 * 2026-10-04 (T12) 追加: 抵触日 (事業所単位・個人単位・例外)・3段階通知・管理台帳・個別契約書/就業条件明示書の版
 *   (令和8年厚生労働省令第87号 2026-10-01 施行)・契約の形ごとの禁止機能・転職勧奨の禁止期間・返戻金。末尾の 8〜12 節。
 */
import { getGeneralWageVersion } from './haken_general_wage';

const ymdOf = (d: Date): string =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

// ============================================================================
// 1. 派遣禁止業務 (派遣法4条)
// ============================================================================

export const DISPATCH_PROHIBITED_BUSINESSES = [
  { kind: 'port_transport', ja: '港湾運送業務', law: '派遣法4条1項1号' },
  { kind: 'construction', ja: '建設業務', law: '派遣法4条1項2号' },
  { kind: 'security', ja: '警備業務', law: '派遣法4条1項3号' },
  { kind: 'medical_at_hospital', ja: '医療関係業務 (病院・診療所内)', law: '施行令2条' },
  { kind: 'lawyer', ja: '弁護士・司法書士・税理士等の士業', law: '施行令2条' },
] as const;

export type ProhibitedKind = typeof DISPATCH_PROHIBITED_BUSINESSES[number]['kind'];

/**
 * 派遣可否判定
 *   禁止されるのは「業務」そのもの (派遣法4条1項)。業種の名前ではない。
 *   - 建設業務 = 建設工事の現場で、土木・建築その他工作物の建設・改造・保存・修理・変更・破壊・解体の作業
 *     又はその準備の作業に **直接従事する** もの (労働者派遣事業関係業務取扱要領)。
 *     建設会社の経理・総務などの事務、現場事務所の事務、CAD、施工管理 (専任の主任技術者・監理技術者を除く) は派遣できる。
 *   - 警備業務 = 警備業法2条1項各号の業務。警備会社の事務は派遣できる。
 *   - 港湾運送業務 = 港湾運送事業法の港湾運送 (荷役等) の業務。
 *   旧版は説明に「建設」「警備」の文字があれば一律に禁止と返していた (2026-10-01 是正)。
 *   文字だけで判断がつかないときは、許可側に倒さず allowed=false・needsReview=true を返す。
 */
const OFFICE_WORK_RE = /経理|総務|人事|事務|受付|庶務|営業事務|データ入力|ＣＡＤ|cad|設計補助|施工管理|積算/;
const CONSTRUCTION_WORK_RE = /土工|左官|鳶|とび|大工|型枠|鉄筋|解体|塗装|配管工事|配電|掘削|資材(の)?運搬|現場作業|建設作業|建設業務|足場|組立|組み立て|作業員|交通誘導/;
const SECURITY_WORK_RE = /警備業務|施設警備|交通誘導警備|雑踏警備|身辺警護|貴重品運搬|警備員|巡回保安/;
const PORT_WORK_RE = /港湾運送|荷役|沿岸荷役|船内荷役|はしけ|いかだ|港運/;

export function isDispatchAllowed(input: { businessDescription: string; isAtHospital?: boolean }): {
  allowed: boolean;
  reason: string;
  needsReview?: boolean;
} {
  const desc = input.businessDescription.toLowerCase();
  const office = OFFICE_WORK_RE.test(desc);
  if (PORT_WORK_RE.test(desc) && !office) {
    return { allowed: false, reason: '港湾運送業務は派遣禁止 (派遣法4条1項1号)' };
  }
  if (CONSTRUCTION_WORK_RE.test(desc) && !office) {
    return { allowed: false, reason: '建設業務 (建設工事の現場で直接作業に従事する業務) は派遣禁止 (派遣法4条1項2号)' };
  }
  if (SECURITY_WORK_RE.test(desc) && !office) {
    return { allowed: false, reason: '警備業務は派遣禁止 (派遣法4条1項3号)' };
  }
  if (!office && (desc.includes('建設') || desc.includes('警備') || desc.includes('港湾'))) {
    return {
      allowed: false,
      needsReview: true,
      reason: '建設・警備・港湾に関わる業務ですが、現場の作業に直接従事するかが説明から判断できません。業務の内容を確認してください (派遣法4条1項)',
    };
  }
  if (office && /施工管理/.test(desc)) {
    return { allowed: true, reason: '施工管理は建設業務に当たらず派遣可能 (ただし工事現場の作業を一切させないこと・専任の主任技術者/監理技術者には充てられない)' };
  }
  if (input.isAtHospital && (desc.includes('看護') || desc.includes('診療補助'))) {
    return { allowed: false, reason: '病院内の医療関係業務は派遣禁止 (施行令2条)' };
  }
  return { allowed: true, reason: '派遣可能業務' };
}

// ============================================================================
// 2. 派遣事業の許可 (派遣法5条 H27改正 — 一般+特定の区分廃止)
// ============================================================================

export interface DispatchBusinessApplication {
  hasPermit: boolean; // 厚生労働大臣許可 (5年/3年更新)
  // 財産的基礎要件 (規則1条の4)
  baseCapitalJpy: number; // 基準資産額 2000万円以上
  baseCapitalPerOfficeJpy: number; // 1事業所当たり 2000万円以上
  cashHoldingJpy: number; // 現金預金 1500万円以上
  // 適正運営要件
  hasResponsibleManager: boolean; // 派遣元責任者
  responsibleManagerHasTrainingCert: boolean; // 派遣元責任者講習修了
  hasOfficeFloorM2: number; // 事業所面積 20m²以上
  hasComplianceProgram: boolean; // 派遣労働者教育訓練計画
  hasSocialInsuranceEnrollment: boolean; // 社保加入
}

/** 派遣事業許可の事前審査 */
export function evaluateDispatchPermit(a: DispatchBusinessApplication): {
  approvable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (a.baseCapitalJpy < 20_000_000) blockers.push('基準資産 2000万円以上必須 (規則1条の4)');
  if (a.cashHoldingJpy < 15_000_000) blockers.push('現金預金 1500万円以上必須');
  if (a.baseCapitalPerOfficeJpy < 20_000_000) blockers.push('1事業所当たり基準資産 2000万円以上必須');
  if (!a.hasResponsibleManager) blockers.push('派遣元責任者の選任必須 (法36条)');
  if (!a.responsibleManagerHasTrainingCert) {
    blockers.push('派遣元責任者講習 (3年以内に受講) 修了証必須');
  }
  if (a.hasOfficeFloorM2 < 20) blockers.push('事業所面積 20m²以上必須');
  if (!a.hasSocialInsuranceEnrollment) blockers.push('派遣労働者の社会保険加入義務 — 未加入は許可不可');
  if (!a.hasComplianceProgram) blockers.push('派遣労働者教育訓練計画 必須 (法30条の2)');
  return { approvable: blockers.length === 0, blockers };
}

// ============================================================================
// 3. 3年ルール (派遣法 H27改正)
// ============================================================================

/** 個人単位 3年 + 事業所単位 3年 (過半数労組意見聴取で延長可) */
export interface DispatchAssignment {
  workerName: string;
  startDate: Date;
  organizationUnit: string; // 課/部署
  hasMajorityUnionConsultation: boolean; // 過半数労組意見聴取
  hasUnionExtensionOk: boolean;
}

/**
 * 抵触日 (派遣を受け入れられなくなる最初の日) = 派遣開始日から暦で3年の応当日。
 *   期間は暦に従って数え (民法143条)、開始日の3年後の応当日の前日で満了する。応当日が無い月 (2/29 開始など) は
 *   その月の末日で満了し、翌日 (3/1) が抵触日。旧版は 3*365 日で数え、うるう年をまたぐと1日早かった (2026-10-01 是正)。
 *   ★事業所単位と個人単位の区別、クーリング期間 (3か月超の空白) は本関数では扱っていない (要対応)。
 */
export function calcDispatchConflictDate(startDate: Date): Date {
  const y = startDate.getFullYear() + 3;
  const m = startDate.getMonth();
  const d = startDate.getDate();
  const lastDay = new Date(y, m + 1, 0).getDate();
  // 応当日が無い月は、その月の末日の翌日が抵触日
  return d > lastDay ? new Date(y, m + 1, 1) : new Date(y, m, d);
}

export function checkThreeYearRule(input: DispatchAssignment, today: Date = new Date()): {
  exceedsLimit: boolean;
  remainingDays: number;
  recommendation: string;
  conflictDate?: Date;
} {
  const conflict = calcDispatchConflictDate(input.startDate);
  const dayOf = (x: Date) => Date.UTC(x.getFullYear(), x.getMonth(), x.getDate()) / 86400000;
  const remainingDays = Math.max(0, dayOf(conflict) - dayOf(today));

  if (dayOf(today) >= dayOf(conflict)) {
    if (input.hasUnionExtensionOk) {
      return {
        exceedsLimit: false,
        remainingDays: 0,
        conflictDate: conflict,
        recommendation: '事業所単位で過半数労組意見聴取済 — 延長可、ただし個人単位3年は別途判定',
      };
    }
    return {
      exceedsLimit: true,
      remainingDays: 0,
      conflictDate: conflict,
      recommendation: '3年経過 (抵触日に到達) — 直接雇用申込み or 別の組織単位への異動 or 派遣終了',
    };
  }
  return {
    exceedsLimit: false,
    remainingDays,
    conflictDate: conflict,
    recommendation:
      remainingDays < 90
        ? `残り${remainingDays}日 — 過半数労組意見聴取の手続を開始 (満了1ヶ月前まで)`
        : '通常運用可',
  };
}

// ============================================================================
// 4. 同一労働同一賃金 (R2.4施行)
// ============================================================================

export type WageDetermineMethod = 'labor_management_agreement' | 'dispatching_destination_balance';

/** 派遣労働者の賃金決定方式 */
export interface SameWorkSameWageScheme {
  method: WageDetermineMethod;
  // 労使協定方式 (一般賃金水準以上)
  hasLaborManagementAgreement?: boolean;
  /** 旧い入力 (互換のため残す)。法は「毎年3/31満了」を求めていないので判定には使わない */
  laborMgmtAgreementValidThroughMar31?: boolean;
  /** 労使協定の有効期間の終期 (YYYY-MM-DD)。法30条の4第1項第6号の有効期間 */
  agreementValidUntil?: string;
  /** 判定の基準日 (YYYY-MM-DD)。省略時は今日 */
  asOf?: string;
  /** 労使協定が参照している一般賃金の年度 (例 'FY2027' = 令和9年度) */
  generalWageFiscalYear?: string;
  /** 旧い入力 (互換のため残す): 統計データ年度 */
  generalWageDataReferenceYear?: number;
  // 派遣先均等均衡方式
  destinationCompanyComparableWageJpy?: number; // 派遣先同種業務の賃金
  ourWorkerWageJpy?: number;
  benefitsParityWithDestination: boolean; // 教育訓練/福利厚生の均衡
}

/**
 * 同一労働同一賃金 (R2.4) のコンプライアンスチェック
 *   2026-10-04 是正 (T12):
 *   - 旧版は均等・均衡方式で「派遣先の95%未満なら違反」と数で断定していた。法30条の3 は待遇ごとに不合理な相違を禁じるもので、
 *     5% という閾値の根拠は無い → 下回るときは違反と断定せず「待遇ごとの不合理性の確認が要る」を返す (要確認)。
 *   - 旧版は労使協定を「毎年3/31満了・4/1更新」を必須として扱っていた。法が求めるのは有効期間の定め (法30条の4第1項第6号) で、
 *     3/31 満了は慣行 → 有効期間の終期 (agreementValidUntil) と基準日で判定する。
 *   - 一般賃金の年度は今日の暦年ではなく、基準日に適用される局長通達の年度 (haken_general_wage.ts の値表) と照合する。
 */
export function checkEqualPayCompliance(s: SameWorkSameWageScheme): {
  compliant: boolean;
  alerts: string[];
  needsReview?: string[];
} {
  const alerts: string[] = [];
  const needsReview: string[] = [];
  const asOf = s.asOf || ymdOf(new Date());
  if (s.method === 'labor_management_agreement') {
    if (!s.hasLaborManagementAgreement) alerts.push('労使協定書面 必須 (法30条の4第1項)');
    if (!s.agreementValidUntil) {
      alerts.push('労使協定の有効期間 (終期) が未入力です (法30条の4第1項第6号)');
    } else if (s.agreementValidUntil < asOf) {
      alerts.push(`労使協定の有効期間が ${s.agreementValidUntil} で終わっています (基準日 ${asOf})。再締結が必要です`);
    }
    const v = getGeneralWageVersion(asOf);
    if (!v) {
      needsReview.push(`基準日 ${asOf} に適用される一般賃金の通達が値表にありません。最新の局長通達で確認してください`);
    } else if (!s.generalWageFiscalYear) {
      alerts.push(`労使協定が参照する一般賃金の年度が未入力です (基準日の年度は ${v.wareki}・${v.notice})`);
    } else if (s.generalWageFiscalYear !== v.fiscal_year) {
      alerts.push(`労使協定が参照する一般賃金 (${s.generalWageFiscalYear}) が基準日の年度 ${v.wareki} (${v.fiscal_year}・${v.notice}) と違います`);
    }
  } else {
    // 派遣先均等均衡方式
    if (!s.destinationCompanyComparableWageJpy || !s.ourWorkerWageJpy) {
      alerts.push('派遣先同種業務の賃金比較データ必須 (法26条7項の比較対象労働者の待遇情報)');
    } else if (s.ourWorkerWageJpy < s.destinationCompanyComparableWageJpy) {
      needsReview.push(
        `派遣先の比較対象労働者 ${s.destinationCompanyComparableWageJpy}円 に対し自社 ${s.ourWorkerWageJpy}円。` +
          '相違が不合理でないかを待遇ごとに確認してください (法30条の3。数の閾値で違反とは断定しない。要確認)'
      );
    }
    if (!s.benefitsParityWithDestination) {
      alerts.push('教育訓練/福利厚生の均衡 必須');
    }
  }
  return { compliant: alerts.length === 0, alerts, needsReview };
}

// ============================================================================
// 5. 有料職業紹介 (職業安定法30条)
// ============================================================================

export interface JobPlacementApplication {
  isProfit: boolean; // 有料 (true) / 無料 (false)
  hasPermit: boolean; // 厚生労働大臣許可
  baseCapitalJpy: number;
  cashHoldingJpy: number;
  hasResponsibleManager: boolean;
  responsibleManagerHasTrainingCert: boolean; // 職業紹介責任者講習
  servesProhibitedJobs: boolean; // 港湾運送/建設の紹介 (有料禁止)
}

/** 有料職業紹介 許可審査 */
export function evaluateJobPlacementPermit(a: JobPlacementApplication): {
  approvable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (a.isProfit && a.servesProhibitedJobs) {
    blockers.push('港湾運送・建設業務は有料職業紹介禁止 (職安法32条の11)');
  }
  if (a.isProfit) {
    if (a.baseCapitalJpy < 5_000_000) blockers.push('有料職業紹介 — 基準資産 500万円以上');
    if (a.cashHoldingJpy < 1_500_000) blockers.push('現金預金 150万円以上必須');
  }
  if (!a.hasResponsibleManager) blockers.push('職業紹介責任者の選任必須');
  if (!a.responsibleManagerHasTrainingCert) {
    blockers.push('職業紹介責任者講習 (5年以内に受講) 必須');
  }
  return { approvable: blockers.length === 0, blockers };
}

// ============================================================================
// 6. 紹介手数料の上限 (職業安定法32条の3)
// ============================================================================

/**
 * 上限制手数料の最高額の率 (職業安定法施行規則20条・別表。令和元年10月1日施行の改正後)
 *   出典: 厚生労働省「有料職業紹介事業における手数料の最高額の改正について」https://www.mhlw.go.jp/stf/newpage_06885.html
 *   - 支払われた賃金額の 100分の11.0 (免税事業者 100分の10.3)
 *   - 同一の者に引き続き6箇月を超えて雇用された場合は、6箇月間の雇用に係る賃金について同率
 *   - 期間の定めのない雇用で6箇月超は、上の額 又は 臨時に支払われる賃金及び3箇月を超える期間ごとに支払われる賃金を
 *     除いた額の 100分の14.8 (免税事業者 100分の13.9) のいずれか大きい額
 *   ※旧実装は消費税8%時代の率を年収全体に掛けており、6箇月分を上限とする規定の約2倍になっていた (2026-10-01 是正)。
 */
export const JOB_PLACEMENT_FEE_CAP_RATES = {
  /** 率は 1000分率の整数で持つ (110 = 11.0%)。浮動小数の誤差を出さないため */
  wagePermille: { taxable: 110, exempt: 103 },
  regularWagePermille: { taxable: 148, exempt: 139 },
  maxMonths: 6,
} as const;

/** 紹介手数料: 上限制 (規則20条・別表) と届出制 (規則20条2項) */
export function calcJobPlacementMaxFee(input: {
  annualSalaryJpy: number;
  feeKind: 'fixed_table' | 'percentage_consent'; // fixed_table=届出制手数料 / percentage_consent=上限制手数料
  /** 6箇月以内 (6箇月を超える雇用は最初の6箇月間) に支払われた賃金額。無ければ年収の2分の1 (6箇月分) で概算する */
  wagesPaidJpy?: number;
  /** 期間の定めのない雇用で6箇月を超える場合の、臨時の賃金・3箇月を超える期間ごとの賃金 (賞与等) を除いた6箇月分の賃金額 */
  regularWagesJpy?: number;
  /** 期間の定めのない雇用契約で、同一の者に6箇月を超えて雇用された (14.8% の選択肢が使える) */
  indefiniteOver6m?: boolean;
  /** 紹介事業者が消費税の免税事業者 */
  taxExempt?: boolean;
}): { maxFeeJpy: number | null; reason: string } {
  if (input.feeKind === 'percentage_consent') {
    const R = JOB_PLACEMENT_FEE_CAP_RATES;
    const k = input.taxExempt ? 'exempt' : 'taxable';
    const estimated = input.wagesPaidJpy === undefined;
    const wages = estimated ? Math.floor(input.annualSalaryJpy / 2) : input.wagesPaidJpy!;
    // 1円未満は切り捨て (上限を超えない側。端数の扱いは規定に無いため要確認)
    const byWage = Math.floor((wages * R.wagePermille[k]) / 1000);
    let maxFee = byWage;
    let basis = `賃金 ${wages}円 × ${R.wagePermille[k] / 10}%`;
    if (input.indefiniteOver6m && input.regularWagesJpy !== undefined) {
      const byRegular = Math.floor((input.regularWagesJpy * R.regularWagePermille[k]) / 1000);
      if (byRegular > maxFee) {
        maxFee = byRegular;
        basis = `臨時・3箇月超ごとの賃金を除いた額 ${input.regularWagesJpy}円 × ${R.regularWagePermille[k] / 10}%`;
      }
    }
    return {
      maxFeeJpy: maxFee,
      reason: `上限制手数料 (職業安定法施行規則20条・別表) — ${basis}${estimated ? ' (支払賃金が未入力のため年収の2分の1を6箇月分として概算)' : ''}`,
    };
  }
  // 届出制手数料: 厚生労働大臣に届け出た手数料表による。法定の上限率は無いので、上限額を数で作らない
  return {
    maxFeeJpy: null,
    reason: '届出制手数料 — 厚生労働大臣に届け出た手数料表の額による (法定の上限率は無い。届出の手数料表を確認すること)',
  };
}

// ============================================================================
// 7. 紹介予定派遣 (法2条4号) — 派遣→直接雇用切替
// ============================================================================

/**
 * 紹介予定派遣: 派遣期間最長6ヶ月、その後直接雇用
 * 直接雇用採用に至らなかった場合、派遣元/派遣先双方に理由開示義務
 */
export function evaluateIntroductionDispatch(input: {
  dispatchPeriodMonths: number;
  hasInterviewBeforeDispatch: boolean; // 派遣前面接 (派遣法ではNGだが紹介予定はOK)
  hasFinalDecisionRecorded: boolean;
  hadDirectEmploymentOffer: boolean;
  hasReasonDisclosure: boolean; // 採用しない場合の理由開示
}): { compliant: boolean; alerts: string[] } {
  const alerts: string[] = [];
  if (input.dispatchPeriodMonths > 6) {
    alerts.push('紹介予定派遣の派遣期間は最長6ヶ月');
  }
  if (!input.hadDirectEmploymentOffer && !input.hasReasonDisclosure) {
    alerts.push('採用に至らなかった場合 — 派遣元・派遣先双方に理由開示義務');
  }
  return { compliant: alerts.length === 0, alerts };
}

// ============================================================================
// 8. 抵触日 (事業所単位・個人単位) と 3段階通知 — 2026-10-04 (T12)
// ============================================================================
//   根拠 (e-Gov 360AC0000000088 asof=2026-10-01):
//     法40条の2第1項・第2項 (派遣先の事業所その他派遣就業の場所ごとの業務について3年)、第3項 (意見聴取により3年を限り延長・
//     意見聴取期間は抵触日の「一月前の日」まで)、第1項各号 (例外)、法35条の3 (組織単位ごとの同一の派遣労働者は3年。延長は無い)、
//     規則32条の4 (法40条の2第1項第2号の者 = 60歳以上の者)。
//   期間は暦で数える (民法143条)。派遣の開始日の午前零時から始まるので初日を算入し、3年後の応当日の前日で満了、その翌日が抵触日。
//   ★クーリング (空白期間による通算のリセット) は派遣先指針 (告示) の定めで、この版では一次資料を開いていない → 日付を作らず「要確認」。

/** YYYY-MM-DD の暦計算 (時刻・時差に左右されないよう UTC の日数で扱う) */
const DAY_MS = 86400000;
const parseYmd = (s: string): [number, number, number] => {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(s));
  if (!m) throw new Error(`日付は YYYY-MM-DD で渡してください: ${s}`);
  return [Number(m[1]), Number(m[2]), Number(m[3])];
};
const dimOf = (y: number, m: number) => new Date(Date.UTC(y, m, 0)).getUTCDate();
const fmtYmd = (y: number, m: number, d: number) => `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
const toDayNo = (s: string) => { const [y, m, d] = parseYmd(s); return Date.UTC(y, m - 1, d) / DAY_MS; };
const fromDayNo = (n: number) => { const t = new Date(n * DAY_MS); return fmtYmd(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate()); };
const addDaysYmd = (s: string, n: number) => fromDayNo(toDayNo(s) + n);
/** 民法143条2項: 起算日 start (算入) から years 年の期間の満了日 */
export function periodEndByYears(start: string, years: number): string {
  const [y, m, d] = parseYmd(start);
  const ty = y + years;
  if (d > dimOf(ty, m)) return fmtYmd(ty, m, dimOf(ty, m)); // 応当日が無い → その月の末日
  return addDaysYmd(fmtYmd(ty, m, d), -1);
}

export type DispatchPeriodExemption =
  | 'indefinite' // 無期雇用派遣労働者 (法40条の2第1項第1号)
  | 'age60plus' // 60歳以上 (同第2号・規則32条の4)
  | 'fixed_project' // 有期プロジェクト業務 (同第3号イ)
  | 'limited_days' // 日数限定業務 (同第3号ロ)
  | 'maternity_childcare_substitute' // 産前産後休業・育児休業等の代替 (同第4号)
  | 'family_care_substitute'; // 介護休業等の代替 (同第5号)

export const DISPATCH_PERIOD_EXEMPTIONS: Record<DispatchPeriodExemption, string> = {
  indefinite: '無期雇用派遣労働者 (法40条の2第1項第1号)',
  age60plus: '60歳以上の者 (法40条の2第1項第2号・規則32条の4)',
  fixed_project: '事業の開始・転換・拡大・縮小・廃止のための業務で一定の期間内に完了するもの (同第3号イ)',
  limited_days: '1か月の日数が通常の労働者の所定労働日数に比し相当程度少ない業務 (同第3号ロ)',
  maternity_childcare_substitute: '産前産後休業・育児休業等をする労働者の業務 (同第4号・規則33条)',
  family_care_substitute: '介護休業等をする労働者の業務 (同第5号・規則33条の2)',
};

export interface ConflictDateResult {
  conflictDate: string | null;
  exempt: boolean;
  /** 期間の満了日 (抵触日の前日) */
  periodEnd?: string;
  reason: string;
  warnings: string[];
}

function conflictCore(start: string, years: number, exemption: string | undefined, unitLabel: string): ConflictDateResult {
  if (exemption && (DISPATCH_PERIOD_EXEMPTIONS as Record<string, string>)[exemption]) {
    return { conflictDate: null, exempt: true, reason: `期間制限の例外: ${(DISPATCH_PERIOD_EXEMPTIONS as Record<string, string>)[exemption]}`, warnings: [] };
  }
  const warnings: string[] = [];
  if (exemption) warnings.push(`例外区分「${exemption}」は法40条の2第1項各号に当たらないため、期間制限を掛けたまま計算しました`);
  const periodEnd = periodEndByYears(start, years);
  return { conflictDate: addDaysYmd(periodEnd, 1), exempt: false, periodEnd, reason: `${unitLabel}: ${start} から${years}年 (暦で計算・民法143条)`, warnings };
}

/** 事業所単位の抵触日 (派遣先の事業所その他派遣就業の場所ごとの業務・法40条の2) */
export function calcOfficeConflictDate(input: { firstAcceptanceDate: string; extensions?: number; exemption?: string }): ConflictDateResult {
  const ext = Math.max(0, Math.floor(input.extensions || 0));
  const r = conflictCore(input.firstAcceptanceDate, 3 * (1 + ext), input.exemption, '事業所単位');
  if (ext > 0 && r.conflictDate) r.reason += ` (意見聴取による延長 ${ext} 回・法40条の2第3項)`;
  return r;
}

/** 個人単位の抵触日 (同一の派遣労働者 × 同一の組織単位・法35条の3)。延長は無い */
export function calcIndividualConflictDate(input: { unitStartDate: string; extensions?: number; exemption?: string }): ConflictDateResult {
  const r = conflictCore(input.unitStartDate, 3, input.exemption, '個人単位 (組織単位)');
  if (input.extensions && input.extensions > 0) r.warnings.push('個人単位 (組織単位) の期間制限は意見聴取で延長できません (法35条の3)。延長の入力は無視しました');
  return r;
}

/** 空白期間による通算のリセット (クーリング)。一次資料未確認のため日付を作らない */
export function evaluateCoolingPeriod(input: { previousEndDate: string; restartDate: string }): { status: 'needs_review'; gapDays: number; message: string; conflictDate?: undefined } {
  const gapDays = toDayNo(input.restartDate) - toDayNo(input.previousEndDate) - 1;
  return {
    status: 'needs_review',
    gapDays,
    message: `空白期間 ${gapDays} 日。通算がリセットされるか (派遣先が講ずべき措置に関する指針の「3か月を超える」期間) は一次資料で確認できていません。抵触日を自動では置き直しません (要確認・社労士/労働局に確認)`,
  };
}

/** 意見聴取期間の終わり = 抵触日の1月前の日 (法40条の2第3項)。応当日が無い月は末日とし要確認の印を付ける */
export function calcOpinionHearingDeadline(conflictDate: string): { deadline: string; needsReview: boolean; basis: string } {
  const [y, m, d] = parseYmd(conflictDate);
  const py = m === 1 ? y - 1 : y;
  const pm = m === 1 ? 12 : m - 1;
  const last = dimOf(py, pm);
  return {
    deadline: fmtYmd(py, pm, Math.min(d, last)),
    needsReview: d > last,
    basis: '法40条の2第3項 (抵触日の一月前の日までの間に意見聴取)' + (d > last ? '。1月前の応当日が無いため前月末日としました (要確認)' : ''),
  };
}

/** 抵触日の通知の段階 (日前) */
export const CONFLICT_NOTICE_STAGES = [90, 60, 30] as const;

export interface ConflictNotice {
  targetId: string;
  stageDays: number;
  notifyOn: string;
  conflictDate: string;
  /** 本来の通知日より後に出した (巡回の遅れ) */
  late: boolean;
  scheduledOn: string;
}

/** 抵触日に対する 90/60/30 日前の通知予定日 */
export function buildConflictNoticeSchedule(conflictDate: string): { stageDays: number; notifyOn: string }[] {
  return CONFLICT_NOTICE_STAGES.map((n) => ({ stageDays: n, notifyOn: addDaysYmd(conflictDate, -n) }));
}

/**
 * 日次の巡回: today の時点で出すべき通知 (まだ履歴に無いもの) を返す。呼び出し側が履歴に足して保存し、メール等で送る。
 *   巡回が遅れて本来の日を過ぎた段階も「遅れ」の印つきで出す (取りこぼさない)。抵触日の当日以降は出さない (超過は別の警告)。
 */
export function runConflictNoticeSweep(input: {
  targets: { id: string; conflictDate: string | null }[];
  today: string;
  history: { targetId: string; stageDays: number; conflictDate?: string }[];
}): ConflictNotice[] {
  const out: ConflictNotice[] = [];
  const t = toDayNo(input.today);
  for (const tg of input.targets) {
    if (!tg.conflictDate) continue;
    if (t >= toDayNo(tg.conflictDate)) continue;
    for (const s of buildConflictNoticeSchedule(tg.conflictDate)) {
      if (t < toDayNo(s.notifyOn)) continue;
      const done = input.history.some((h) => h.targetId === tg.id && h.stageDays === s.stageDays && (!h.conflictDate || h.conflictDate === tg.conflictDate));
      if (done) continue;
      out.push({ targetId: tg.id, stageDays: s.stageDays, notifyOn: input.today, conflictDate: tg.conflictDate, late: t > toDayNo(s.notifyOn), scheduledOn: s.notifyOn });
    }
  }
  return out;
}

// ============================================================================
// 9. 派遣元管理台帳・派遣先管理台帳 — 2026-10-04 (T12)
// ============================================================================
//   根拠 (e-Gov asof=2026-10-01): 法37条1項1〜13号・2項 (3年保存)・規則30条〜32条 (事業所ごと・起算日は労働者派遣の終了の日)・規則31条1〜12号
//            法42条1項1〜11号・2項・3項・規則35条〜38条 (事業所ごと・5人以下は不要・起算日・月1回以上の通知)・規則36条1〜12号
//   ★「労働局のモデル様式」そのものは今回取得していない。欄は様式の基になる法・規則の号で持つ (欄の名前は条文の言葉)。

export interface LedgerField {
  key: string;
  label: string;
  basis: string;
  /** 条件付きの欄: 条件の名前 (ctx[condition] が真のときだけ必須) */
  condition?: string;
}

export const DISPATCH_ORIGIN_LEDGER_FIELDS: LedgerField[] = [
  { key: 'law37_1_1', label: '協定対象派遣労働者であるか否かの別', basis: '法37条1項1号' },
  { key: 'law37_1_2', label: '無期雇用派遣労働者か有期雇用派遣労働者かの別 (有期は労働契約の期間)', basis: '法37条1項2号' },
  { key: 'law37_1_3', label: '60歳以上の者であるか否かの別', basis: '法37条1項3号・規則32条の4' },
  { key: 'law37_1_4', label: '派遣先の氏名又は名称', basis: '法37条1項4号' },
  { key: 'law37_1_5', label: '事業所の所在地その他派遣就業の場所及び組織単位', basis: '法37条1項5号' },
  { key: 'law37_1_6', label: '労働者派遣の期間及び派遣就業をする日', basis: '法37条1項6号' },
  { key: 'law37_1_7', label: '始業及び終業の時刻', basis: '法37条1項7号' },
  { key: 'law37_1_8', label: '従事する業務の種類', basis: '法37条1項8号' },
  { key: 'law37_1_9', label: '法30条1項 (雇用安定措置) により講じた措置', basis: '法37条1項9号' },
  { key: 'law37_1_10', label: '教育訓練 (法30条の2第1項) を行った日時及び内容', basis: '法37条1項10号・規則30条の2' },
  { key: 'law37_1_11', label: '派遣労働者から申出を受けた苦情の処理に関する事項', basis: '法37条1項11号' },
  { key: 'law37_1_12', label: '紹介予定派遣に関する事項', basis: '法37条1項12号', condition: 'introductionDispatch' },
  { key: 'rule31_1', label: '派遣労働者の氏名', basis: '規則31条1号' },
  { key: 'rule31_2', label: '派遣労働者が従事する業務に伴う責任の程度', basis: '規則31条2号' },
  { key: 'rule31_3', label: '事業所の名称', basis: '規則31条3号' },
  { key: 'rule31_4', label: '派遣元責任者及び派遣先責任者に関する事項', basis: '規則31条4号' },
  { key: 'rule31_5', label: '令4条1項各号の業務 (日雇派遣の例外業務) の号番号', basis: '規則31条5号', condition: 'dailyDispatchExceptionWork' },
  { key: 'rule31_6', label: '有期プロジェクト業務に該当する旨 (規則22条の2第2号)', basis: '規則31条6号', condition: 'fixedProject' },
  { key: 'rule31_7', label: '日数限定業務に該当する旨・月の日数・通常の労働者の所定労働日数 (規則22条の2第3号)', basis: '規則31条7号', condition: 'limitedDays' },
  { key: 'rule31_8', label: '産前産後休業・育児休業等をする労働者の氏名・業務・期間 (規則22条の2第4号)', basis: '規則31条8号', condition: 'maternitySubstitute' },
  { key: 'rule31_9', label: '介護休業等をする労働者の氏名・業務・期間 (規則22条の2第5号)', basis: '規則31条9号', condition: 'careSubstitute' },
  { key: 'rule31_10', label: '規則25条の2第3項により聴取した内容 (雇用安定措置の希望)', basis: '規則31条10号' },
  { key: 'rule31_11', label: '法30条の2第2項の援助 (キャリアコンサルティング) を行った日及び内容', basis: '規則31条11号' },
  { key: 'rule31_12', label: '規則27条の2の通知の内容 (社会保険・雇用保険の資格取得届の提出の有無)', basis: '規則31条12号' },
];

export const DISPATCH_DESTINATION_LEDGER_FIELDS: LedgerField[] = [
  { key: 'law42_1_1', label: '協定対象派遣労働者であるか否かの別', basis: '法42条1項1号' },
  { key: 'law42_1_2', label: '無期雇用派遣労働者か有期雇用派遣労働者かの別', basis: '法42条1項2号' },
  { key: 'law42_1_3', label: '60歳以上の者であるか否かの別', basis: '法42条1項3号・規則32条の4' },
  { key: 'law42_1_4', label: '派遣元事業主の氏名又は名称', basis: '法42条1項4号' },
  { key: 'law42_1_5', label: '派遣就業をした日', basis: '法42条1項5号' },
  { key: 'law42_1_6', label: '派遣就業をした日ごとの始業・終業の時刻並びに休憩した時間', basis: '法42条1項6号' },
  { key: 'law42_1_7', label: '従事した業務の種類', basis: '法42条1項7号' },
  { key: 'law42_1_8', label: '派遣労働者から申出を受けた苦情の処理に関する事項', basis: '法42条1項8号' },
  { key: 'law42_1_9', label: '紹介予定派遣に関する事項', basis: '法42条1項9号', condition: 'introductionDispatch' },
  { key: 'law42_1_10', label: '教育訓練を行った日時及び内容', basis: '法42条1項10号' },
  { key: 'rule36_1', label: '派遣労働者の氏名', basis: '規則36条1号' },
  { key: 'rule36_2', label: '派遣労働者が従事する業務に伴う責任の程度', basis: '規則36条2号' },
  { key: 'rule36_3', label: '派遣元事業主の事業所の名称', basis: '規則36条3号' },
  { key: 'rule36_4', label: '派遣元事業主の事業所の所在地', basis: '規則36条4号' },
  { key: 'rule36_5', label: '派遣就業をした事業所の名称及び所在地その他派遣就業をした場所並びに組織単位', basis: '規則36条5号' },
  { key: 'rule36_6', label: '派遣先責任者及び派遣元責任者に関する事項', basis: '規則36条6号' },
  { key: 'rule36_7', label: '令4条1項各号の業務の号番号', basis: '規則36条7号', condition: 'dailyDispatchExceptionWork' },
  { key: 'rule36_8', label: '有期プロジェクト業務に該当する旨', basis: '規則36条8号', condition: 'fixedProject' },
  { key: 'rule36_9', label: '日数限定業務に該当する旨等', basis: '規則36条9号', condition: 'limitedDays' },
  { key: 'rule36_10', label: '産前産後休業・育児休業等の代替に関する事項', basis: '規則36条10号', condition: 'maternitySubstitute' },
  { key: 'rule36_11', label: '介護休業等の代替に関する事項', basis: '規則36条11号', condition: 'careSubstitute' },
  { key: 'rule36_12', label: '規則27条の2の通知の内容', basis: '規則36条12号' },
];

/** 派遣先から派遣元への月1回以上の通知事項 (規則38条1項: 法42条1項5〜7号・規則36条1・2・5号) */
export const DESTINATION_MONTHLY_NOTICE_FIELDS: string[] = ['law42_1_5', 'law42_1_6', 'law42_1_7', 'rule36_1', 'rule36_2', 'rule36_5'];

const filled = (v: unknown) => v !== undefined && v !== null && !(typeof v === 'string' && v.trim() === '') && v !== false;

/** 台帳の記録の欠落を調べる (条件付きの欄は ctx の条件が真のときだけ必須) */
export function validateDispatchLedger(
  kind: 'origin' | 'destination',
  record: Record<string, unknown>,
  ctx: Record<string, boolean> = {},
): { ok: boolean; missing: string[]; missingLabels: string[] } {
  const fields = kind === 'origin' ? DISPATCH_ORIGIN_LEDGER_FIELDS : DISPATCH_DESTINATION_LEDGER_FIELDS;
  const missing = fields.filter((f) => (!f.condition || ctx[f.condition]) && !filled(record[f.key])).map((f) => f.key);
  return { ok: missing.length === 0, missing, missingLabels: missing.map((k) => fields.find((f) => f.key === k)!.label) };
}

/** 派遣先管理台帳の作成の要否 (規則35条3項: 派遣労働者 + 雇用する労働者 が5人を超えないときは不要) */
export function isDestinationLedgerRequired(input: { dispatchedWorkers: number; ownEmployees: number }): { required: boolean; total: number; basis: string } {
  const total = input.dispatchedWorkers + input.ownEmployees;
  return { required: total > 5, total, basis: '規則35条3項 (派遣労働者の数と雇用する労働者の数の合計が5人を超えないときは作成不要)' };
}

/** 台帳の保存期限 (法37条2項・42条2項 3年。起算日は労働者派遣の終了の日: 規則32条・37条。満了は民法143条2項) */
export function calcLedgerRetention(endDate: string): { startDate: string; expiresOn: string; safeSideKeepUntil: string; needsReview: boolean; basis: string } {
  const expiresOn = periodEndByYears(endDate, 3);
  return {
    startDate: endDate,
    expiresOn,
    safeSideKeepUntil: addDaysYmd(expiresOn, 1),
    needsReview: true,
    basis: '法37条2項・42条2項 (3年保存)・規則32条・37条 (起算日=労働者派遣の終了の日)・民法143条2項。満了日の数え方は社労士確認を推奨 (安全側は満了日の翌日まで保管)',
  };
}

/** 台帳の CSV 出力 (見出しは欄の日本語名。値の改行・カンマ・引用符はエスケープ) */
export function exportDispatchLedgerCsv(kind: 'origin' | 'destination', records: Record<string, unknown>[]): string {
  const fields = kind === 'origin' ? DISPATCH_ORIGIN_LEDGER_FIELDS : DISPATCH_DESTINATION_LEDGER_FIELDS;
  const esc = (v: unknown) => {
    const s = v === undefined || v === null ? '' : String(v);
    return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [fields.map((f) => esc(f.label)).join(',')];
  for (const r of records) lines.push(fields.map((f) => esc(r[f.key])).join(','));
  return lines.join('\r\n') + '\r\n';
}

// ============================================================================
// 10. 個別契約書・就業条件明示書・雇入れ時の明示の記載事項 (様式の版) — 2026-10-04 (T12)
// ============================================================================
//   根拠 (e-Gov 施行規則 361M50002000020 を asof=2026-09-30 と 2026-10-01 で条ごとに差分):
//     令和8年厚生労働省令第87号 (公布 2026-04-28・施行 2026-10-01) で変わったのは規則25条の16 だけ:
//       第5号「法第三十一条の二第四項の規定による説明を求めることができる旨」を追加 (苦情処理は第6号へ)。
//     → 雇入れ時の明示 (法31条の2第2項1号) と、派遣時の明示 (同第3項1号・労使協定方式以外の派遣) に加わる。
//     個別契約の記載事項 (法26条1項・規則21条・22条) と就業条件明示 (法34条・規則26条の2) は改正なし。
//   ★「様式」は法定の様式ではなく、記載事項の集合で版を持つ。業界団体・厚労省の様式例そのものは取り込んでいない。

export type DispatchDocumentKind = 'individual_contract' | 'work_conditions' | 'hiring_notice';
export interface DispatchDocumentContext {
  /** 紹介予定派遣 (法26条1項9号) */
  introductionDispatch?: boolean;
  /** 派遣就業日以外の就業・時間延長の定めがある (規則22条3号) */
  overtimeClause?: boolean;
  /** 福利厚生の便宜供与の定めがある (規則22条4号) */
  welfareClause?: boolean;
  /** 待遇決定方式 (balance=派遣先均等・均衡方式 / agreement=労使協定方式) */
  wageMethod?: 'balance' | 'agreement';
  /** 期間制限の例外 (法40条の2第1項各号) に当たる派遣 */
  exemptFromPeriodLimit?: boolean;
  /** 社会保険等の資格取得届が未提出 (規則26条の2: 具体的な理由の明示が要る) */
  socialInsuranceNotFiled?: boolean;
}
export interface DocumentItem { key: string; label: string; basis: string }

export const DISPATCH_DOC_AMENDMENT_2026 = {
  effectiveFrom: '2026-10-01',
  ordinance: '令和8年厚生労働省令第87号 (公布 2026-04-28)',
  addedItem: { key: 'rule25_16_5', label: '待遇の相違の内容及び理由等について説明を求めることができる旨 (法31条の2第4項)', basis: '規則25条の16第5号 (2026-10-01〜)' },
} as const;

const I = (key: string, label: string, basis: string): DocumentItem => ({ key, label, basis });
const LAW26_ITEMS: DocumentItem[] = [
  I('law26_1_1', '派遣労働者が従事する業務の内容', '法26条1項1号'),
  I('law26_1_2', '派遣就業の場所 (事業所の名称・所在地) 及び組織単位', '法26条1項2号'),
  I('law26_1_3', '就業中の派遣労働者を直接指揮命令する者に関する事項', '法26条1項3号'),
  I('law26_1_4', '労働者派遣の期間及び派遣就業をする日', '法26条1項4号'),
  I('law26_1_5', '派遣就業の開始及び終了の時刻並びに休憩時間', '法26条1項5号'),
  I('law26_1_6', '安全及び衛生に関する事項', '法26条1項6号'),
  I('law26_1_7', '派遣労働者からの苦情の処理に関する事項', '法26条1項7号'),
  I('law26_1_8', '労働者派遣契約の解除に当たって講ずる派遣労働者の雇用の安定を図るための措置', '法26条1項8号'),
];
const RULE22_BASE: DocumentItem[] = [
  I('rule22_1', '派遣労働者が従事する業務に伴う責任の程度', '規則22条1号'),
  I('rule22_2', '派遣元責任者及び派遣先責任者に関する事項', '規則22条2号'),
  I('rule22_5', '派遣終了後に派遣先が派遣労働者を雇用する場合の紛争防止措置', '規則22条5号'),
  I('rule22_6', '派遣労働者を協定対象派遣労働者に限るか否かの別', '規則22条6号'),
  I('rule22_7', '派遣労働者を無期雇用派遣労働者又は60歳以上の者に限るか否かの別', '規則22条7号'),
];
const BALANCE_ITEMS_BASE: DocumentItem[] = [
  I('law31_2_3_wage', '賃金の決定・計算・支払の方法、締切り・支払の時期 (労基則5条1項3号のうち書面明示事項)', '法31条の2第3項1号'),
  I('rule25_16_1', '昇給の有無', '規則25条の16第1号'),
  I('rule25_16_2', '退職手当の有無', '規則25条の16第2号'),
  I('rule25_16_3', '賞与の有無', '規則25条の16第3号'),
  I('rule25_16_4', '協定対象派遣労働者であるか否か (協定対象の場合は協定の有効期間の終期)', '規則25条の16第4号'),
];

/** 書面の版 (基準日=明示・締結の日) */
export function getDispatchDocumentVersion(kind: DispatchDocumentKind, asOf: string, ctx: DispatchDocumentContext = {}): { versionId: string; label: string; effectiveFrom: string } {
  const after = String(asOf).slice(0, 10) >= DISPATCH_DOC_AMENDMENT_2026.effectiveFrom;
  const affected = kind === 'hiring_notice' || (kind === 'work_conditions' && ctx.wageMethod === 'balance');
  if (!affected) return { versionId: `${kind}@2020-04-01`, label: '2020-04-01 以降の記載事項 (2026-10-01 の省令改正の影響なし)', effectiveFrom: '2020-04-01' };
  return after
    ? { versionId: `${kind}@2026-10-01`, label: `2026-10-01 以降 (${DISPATCH_DOC_AMENDMENT_2026.ordinance})`, effectiveFrom: '2026-10-01' }
    : { versionId: `${kind}@2020-04-01`, label: '2026-09-30 以前 (説明を求めることができる旨の明示は不要)', effectiveFrom: '2020-04-01' };
}

/** 書面の必須記載事項 (基準日と条件で決まる) */
export function getDispatchDocumentItems(kind: DispatchDocumentKind, asOf: string, ctx: DispatchDocumentContext = {}): DocumentItem[] {
  const after = String(asOf).slice(0, 10) >= DISPATCH_DOC_AMENDMENT_2026.effectiveFrom;
  const cond: DocumentItem[] = [];
  if (ctx.introductionDispatch) cond.push(I('law26_1_9', '紹介予定派遣に関する事項 (業務内容・労働条件等)', '法26条1項9号'));
  if (ctx.overtimeClause) cond.push(I('rule22_3', '派遣就業日以外の就業・就業時間の延長ができる日又は時間数', '規則22条3号'));
  if (ctx.welfareClause) cond.push(I('rule22_4', '福利厚生のための便宜供与の内容及び方法', '規則22条4号'));
  if (kind === 'individual_contract') {
    return [...LAW26_ITEMS, ...RULE22_BASE, ...cond,
      I('rule21_1_headcount', '派遣労働者の人数 (内容の組合せごと)', '法26条1項柱書・規則21条1項'),
      I('law26_3_permit', '派遣元事業主が許可を受けている旨', '法26条3項・規則21条4項')];
  }
  if (kind === 'work_conditions') {
    const items: DocumentItem[] = [I('law34_1_1', '労働者派遣をしようとする旨', '法34条1項1号'), ...LAW26_ITEMS, ...RULE22_BASE, ...cond];
    if (!ctx.exemptFromPeriodLimit) {
      items.push(I('law34_1_3', '組織単位の業務について派遣元が法35条の3に抵触することとなる最初の日', '法34条1項3号'));
      items.push(I('law34_1_4', '事業所その他派遣就業の場所の業務について派遣先が法40条の2第1項に抵触することとなる最初の日', '法34条1項4号'));
    }
    items.push(I('law34_3', '派遣先が法40条の6第1項3号・4号の行為を行った場合の労働契約申込みみなし制度の旨', '法34条3項'));
    if (ctx.socialInsuranceNotFiled) items.push(I('rule26_2', '社会保険・雇用保険の資格取得届が提出されていない具体的な理由', '規則26条の2'));
    if (ctx.wageMethod === 'balance') {
      items.push(...BALANCE_ITEMS_BASE);
      if (after) items.push(DISPATCH_DOC_AMENDMENT_2026.addedItem);
    }
    return items;
  }
  // hiring_notice (法31条の2第2項1号・規則25条の16)
  const items: DocumentItem[] = [BALANCE_ITEMS_BASE[1], BALANCE_ITEMS_BASE[2], BALANCE_ITEMS_BASE[3], BALANCE_ITEMS_BASE[4]];
  if (after) items.push(DISPATCH_DOC_AMENDMENT_2026.addedItem);
  items.push(I('rule25_16_complaint', '派遣労働者から申出を受けた苦情の処理に関する事項', after ? '規則25条の16第6号' : '規則25条の16第5号'));
  return items;
}

/** 書面の記載事項の欠落を調べる (空文字・空白だけは記載なし) */
export function checkDispatchDocument(
  kind: DispatchDocumentKind,
  doc: Record<string, unknown>,
  opts: { asOf: string; ctx?: DispatchDocumentContext },
): { ok: boolean; version: string; missing: string[]; missingLabels: string[] } {
  const items = getDispatchDocumentItems(kind, opts.asOf, opts.ctx || {});
  const missing = items.filter((i) => !filled(doc[i.key]));
  return { ok: missing.length === 0, version: getDispatchDocumentVersion(kind, opts.asOf, opts.ctx || {}).versionId, missing: missing.map((i) => i.key), missingLabels: missing.map((i) => i.label) };
}

// ============================================================================
// 11. 契約の形 (派遣・紹介予定派遣・準委任・請負・紹介・媒体・個人への業務委託) と、形ごとに作らない機能 — 2026-10-04 (T12)
// ============================================================================

export const CONTRACT_KINDS = [
  { key: 'HAKEN', ja: '労働者派遣 (登録型・常用型・日雇)', employer: '派遣元', command: '派遣先' },
  { key: 'SHOKAI_YOTEI_HAKEN', ja: '紹介予定派遣', employer: '派遣元 (派遣期間中)', command: '派遣先' },
  { key: 'JUNIN', ja: '準委任 (SES)', employer: '受託者', command: '受託者 (発注者は指示しない)' },
  { key: 'UKEOI', ja: '請負', employer: '請負人', command: '請負人' },
  { key: 'SHOKAI', ja: '有料職業紹介', employer: '求人者 (雇用後)', command: '求人者' },
  { key: 'MEDIA', ja: '募集情報等提供 (求人メディア)', employer: '—', command: '—' },
  { key: 'FREELANCE', ja: '個人への業務委託 (フリーランス)', employer: '—', command: '受託者' },
] as const;

type FeatureRule = { feature: string; ja: string; basis: string; sourceGrade: 'primary' | 'secondary' };
const HAKEN_SELECTION: FeatureRule[] = [
  { feature: 'selection_result', ja: '派遣先による合否の記録 (面談・顔合わせの合否欄)', basis: '労働者派遣法第26条第6項 (派遣労働者を特定することを目的とする行為をしないよう努める。紹介予定派遣を除く)', sourceGrade: 'primary' },
  { feature: 'resume_request', ja: '派遣先への履歴書の送付・取り寄せ', basis: '労働者派遣法第26条第6項', sourceGrade: 'primary' },
  { feature: 'pre_interview', ja: '派遣前の事前面接', basis: '労働者派遣法第26条第6項', sourceGrade: 'primary' },
  { feature: 'age_gender_filter', ja: '年齢・性別による派遣労働者の絞り込み', basis: '労働者派遣法第26条第6項', sourceGrade: 'primary' },
];
const DIRECT_COMMAND: FeatureRule[] = [
  { feature: 'client_direct_instruction', ja: '発注者から作業者への直接の業務指示の画面・連絡', basis: '労働者派遣事業と請負により行われる事業との区分に関する基準 (昭和61年労働省告示第37号) — 告示本文は未取得 (二次の記載)', sourceGrade: 'secondary' },
  { feature: 'client_attendance_control', ja: '発注者による作業者の出退勤・作業時間の管理', basis: '同上 (昭和61年労働省告示第37号) — 告示本文は未取得 (二次の記載)', sourceGrade: 'secondary' },
];
const FORBIDDEN_FEATURES_BY_KIND: Record<string, FeatureRule[]> = {
  HAKEN: HAKEN_SELECTION,
  SHOKAI_YOTEI_HAKEN: [],
  JUNIN: DIRECT_COMMAND,
  UKEOI: DIRECT_COMMAND,
  SHOKAI: [
    { feature: 'job_change_solicitation', ja: '紹介により就職した者 (無期) への就職から2年間の転職勧奨', basis: '職業紹介事業の許可条件 (2025-01-01〜・厚生労働省 001327688.pdf)・職業安定法指針 (平成11年労働省告示第141号)', sourceGrade: 'primary' },
    { feature: 'celebration_money', ja: 'お祝い金その他の名目で社会通念上相当な程度を超える金銭等の提供', basis: '職業紹介事業の許可条件 (2025-01-01〜)', sourceGrade: 'primary' },
  ],
  MEDIA: [
    { feature: 'celebration_money', ja: 'お祝い金等の提供による求職の勧奨', basis: '職業安定法指針 (平成11年労働省告示第141号。募集情報等提供事業者への適用は厚労省リーフレットの記載・指針本文は未取得)', sourceGrade: 'secondary' },
  ],
  FREELANCE: [
    { feature: 'client_attendance_control', ja: '発注者による受託者の作業時間・出退勤の管理 (労働者性を強める)', basis: '労働者性の判断は士業の確認事項 (要確認)', sourceGrade: 'secondary' },
  ],
};
export function getForbiddenFeatures(kind: string): FeatureRule[] {
  return FORBIDDEN_FEATURES_BY_KIND[kind] || [];
}

/** 画面・データ定義の機能の一覧が、契約の形で作ってはいけない機能を含まないかを調べる */
export function checkContractKindFeatures(kind: string, features: string[]): { ok: boolean; status: 'ok' | 'violation' | 'unknown_kind'; violations: FeatureRule[] } {
  if (!(kind in FORBIDDEN_FEATURES_BY_KIND)) return { ok: false, status: 'unknown_kind', violations: [] };
  const rules = FORBIDDEN_FEATURES_BY_KIND[kind];
  const violations = rules.filter((r) => features.includes(r.feature));
  return { ok: violations.length === 0, status: violations.length ? 'violation' : 'ok', violations };
}

/** 一覧・検索・帳票は契約の形ごとに分ける。形が2つ以上混ざる一覧・形の指定が無い一覧を返す */
export function checkContractListsNotMixed(lists: { id: string; contractKinds: string[] }[]): { ok: boolean; mixed: string[] } {
  const mixed = lists.filter((l) => !Array.isArray(l.contractKinds) || new Set(l.contractKinds).size !== 1).map((l) => l.id);
  return { ok: mixed.length === 0, mixed };
}

// ============================================================================
// 12. 有料職業紹介: 転職勧奨の禁止期間と返戻金 — 2026-10-04 (T12)
// ============================================================================
//   転職勧奨: 厚生労働省「職業紹介事業の許可条件が追加されます」(2025-01-01 施行) —
//     「その紹介により就職した者（期間の定めのない労働契約を締結した者に限る。）に対し、当該就職した日から２年間、転職の勧奨を行ってはならない」
//     2年間の満了日は、就職日を算入する読み (応当日の前日) と算入しない読み (応当日) で1日ずれる。一次資料で決まらないため、
//     既定は安全側 (長い方まで禁止) とし needsReview を返す (要確認: 労働局・社労士)。
//   返戻金: 職業安定法施行規則24条の5第1項2号 (返戻金制度に関する事項の明示)・同第2項 (受理後速やかに)・第4項 (掲示・インターネット等)・
//     24条の8第3項5号 (インターネットによる情報提供)。返戻の率・期間は法令に定めが無く、事業者の返戻金規定による。

export function calcSolicitationBanPeriod(input: { employmentDate: string; indefiniteContract: boolean }): {
  applies: boolean; from: string; banUntil: string | null; banUntilIfFirstDayCounted: string | null; needsReview: boolean; basis: string;
} {
  const basis = '職業紹介事業の許可条件 (2025-01-01〜): 紹介により就職した者 (期間の定めのない労働契約に限る) に対し就職した日から2年間の転職の勧奨の禁止';
  if (!input.indefiniteContract) {
    return { applies: false, from: input.employmentDate, banUntil: null, banUntilIfFirstDayCounted: null, needsReview: false, basis: basis + ' — 有期雇用で就職した者は対象外' };
  }
  const counted = periodEndByYears(input.employmentDate, 2);
  return { applies: true, from: input.employmentDate, banUntil: addDaysYmd(counted, 1), banUntilIfFirstDayCounted: counted, needsReview: true, basis: basis + ' — 満了日の数え方は要確認のため安全側 (長い方) まで禁止' };
}

export function isJobChangeSolicitationBanned(input: { employmentDate: string; indefiniteContract: boolean; date: string }): boolean {
  const p = calcSolicitationBanPeriod(input);
  if (!p.applies || !p.banUntil) return false;
  const t = toDayNo(input.date);
  return t >= toDayNo(input.employmentDate) && t <= toDayNo(p.banUntil);
}

export interface RefundPolicy {
  /** 返戻金制度の有無 (無い場合も無いことを明示する) */
  hasRefundSystem?: boolean;
  /** 在籍日数 (就職日と離職日を含む) の上限ごとの返戻率 (%)。上限の小さい順でなくてもよい */
  tiers?: { maxDaysEmployed: number; refundPercent: number }[];
  /** 求人者への明示 (規則24条の5第1項2号・第2項) */
  disclosedToEmployer?: boolean;
  /** 事業所内の掲示その他の適切な方法による情報提供 (規則24条の5第4項) */
  publiclyDisclosed?: boolean;
  /** インターネットによる情報提供 (規則24条の8第3項5号) */
  webPublished?: boolean;
}

export function validateRefundPolicy(p: RefundPolicy): { ok: boolean; missing: string[] } {
  const missing: string[] = [];
  if (p.hasRefundSystem === undefined || p.hasRefundSystem === null) missing.push('返戻金制度の有無 (規則24条の5第1項2号)');
  if (p.hasRefundSystem && !(p.tiers && p.tiers.length)) missing.push('返戻金制度の内容 (期間と返戻の割合)');
  if (!p.disclosedToEmployer) missing.push('求人者への明示 (規則24条の5第1項2号・第2項: 求人の申込みの受理後速やかに)');
  if (!p.publiclyDisclosed) missing.push('返戻金制度に関する事項を記載した書面の掲示等 (規則24条の5第4項)');
  if (!p.webPublished) missing.push('インターネットによる返戻金制度の情報提供 (規則24条の8第3項5号)');
  return { ok: missing.length === 0, missing };
}

/** 返戻金の計算 (事業者の返戻金規定による。1円未満は切り捨て: 規定より多く見せない。端数は規定に従うこと・要確認) */
export function calcPlacementRefund(input: { policy: RefundPolicy; feeYen: number; employmentDate: string; separationDate: string }): {
  refundYen: number; daysEmployed: number; tier: { maxDaysEmployed: number; refundPercent: number } | null;
} {
  const daysEmployed = toDayNo(input.separationDate) - toDayNo(input.employmentDate) + 1;
  if (!input.policy.hasRefundSystem || !input.policy.tiers) return { refundYen: 0, daysEmployed, tier: null };
  const tier = [...input.policy.tiers].sort((a, b) => a.maxDaysEmployed - b.maxDaysEmployed).find((t) => daysEmployed <= t.maxDaysEmployed) || null;
  if (!tier) return { refundYen: 0, daysEmployed, tier: null };
  return { refundYen: Math.floor((input.feeYen * Math.round(tier.refundPercent * 100)) / 10000), daysEmployed, tier };
}
