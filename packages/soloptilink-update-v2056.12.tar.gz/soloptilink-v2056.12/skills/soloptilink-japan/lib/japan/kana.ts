/**
 * 全角半角変換ユーティリティ
 *
 * 2026-09-30 REQ-JPO-FIX-006: 半角カナは hankaku_kana.ts、電話番号は phone_jp.ts（値表 phone_jp_data.ts）の
 *   唯一の処理を呼ぶ形に寄せた（濁点の未合成・句読点の素通り・4桁/5桁の市外局番と 0800・+81 の誤整形を是正）。
 */
import { hankakuKanaToZenkaku as hankakuKanaToZenkakuCore } from './hankaku_kana';
import { formatJapanesePhone } from './phone_jp';

/**
 * 半角英数字 → 全角
 */
export function toZenkaku(s: string): string {
  return s.replace(/[A-Za-z0-9]/g, ch => String.fromCharCode(ch.charCodeAt(0) + 0xfee0));
}

/**
 * 全角英数字 → 半角
 */
export function toHankaku(s: string): string {
  return s.replace(/[Ａ-Ｚａ-ｚ０-９]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0xfee0));
}

/**
 * カタカナ半角 → 全角（ｶﾞ→ガ・ﾊﾟ→パ・ｳﾞ→ヴ を1字に合成。ﾜﾞ・ｦﾞ は Shift_JIS のため合成しない既定）
 * 本体は hankaku_kana.ts。
 */
export function hankakuKanaToZenkaku(s: string): string {
  return hankakuKanaToZenkakuCore(s);
}

/**
 * カナ → ひらがな
 */
export function katakanaToHiragana(s: string): string {
  return s.replace(/[\u30A1-\u30F6]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0x60));
}

/**
 * ひらがな → カタカナ
 */
export function hiraganaToKatakana(s: string): string {
  return s.replace(/[\u3041-\u3096]/g, ch => String.fromCharCode(ch.charCodeAt(0) + 0x60));
}

/**
 * 氏名・住所用: 半角→全角 + 半角カナ→全角カナ
 */
export function normalizeForJapaneseField(s: string): string {
  return hankakuKanaToZenkaku(toZenkaku(s));
}

/**
 * 金額・数値用: 全角→半角
 */
export function normalizeForNumericField(s: string): string {
  return toHankaku(s);
}

/**
 * 郵便番号フォーマット (1234567 / 123-4567 → 全角統一)
 */
export function formatPostalCode(s: string): string {
  const hankaku = toHankaku(s).replace(/[^0-9]/g, '');
  if (hankaku.length !== 7) return s;
  return `${hankaku.slice(0, 3)}-${hankaku.slice(3)}`;
}

/**
 * 電話番号フォーマット（総務省「市外局番の一覧」令和8年3月1日現在と電気通信番号計画に基づく）
 * 例: 0422123456 → 0422-12-3456 / 0120123456 → 0120-123-456 / 08001234567 → 0800-123-4567
 * 判断できない番号は入力のまま返す。本体は phone_jp.ts。
 */
export function formatPhone(s: string): string {
  return formatJapanesePhone(s);
}
