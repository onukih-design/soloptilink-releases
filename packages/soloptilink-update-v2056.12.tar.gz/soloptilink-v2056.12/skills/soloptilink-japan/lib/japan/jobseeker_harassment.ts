/**
 * lib/japan/jobseeker_harassment.ts — 就活セクハラ（求職活動等における性的な言動）の雇用管理上の措置義務
 *
 * 根拠（一次資料・取得日 2026-10-03。写しは ~/jpo-run/証跡/A1_実装/T12_一次資料/）:
 *   - 男女雇用機会均等法（昭和47年法律第113号）e-Gov 347AC0000000113
 *       asof=2026-10-01（revision 347AC0000000113_20261001_507AC0000000063）:
 *       第13条（求職活動等における性的な言動に起因する問題に関する雇用管理上の措置等）
 *         第1項 措置義務／第2項 相談への対応に協力した労働者への不利益取扱いの禁止／第3項 指針
 *       第14条（国、事業主及び労働者の責務）
 *       改正法: 令和7年法律第63号（公布 2025-06-11・施行 2026-10-01）。asof=2026-09-30 には求職者等への措置義務の条は無い。
 *       同時に旧第11条の2→第12条、旧第11条の3→第15条、旧第11条の4→第16条へ繰り下がった。
 *   - 均等法施行規則（昭和61年労働省令第2号）第2条の3（asof=2026-10-01）: 求職者等＝求職者のほか
 *       一 事業主の実施する労働者の採用に資する活動に参加する者／二 教育実習、看護実習その他の実習を受ける者
 *   - 厚生労働省「事業主が求職活動等における性的な言動に起因する問題に関して雇用管理上講ずべき措置等についての指針」
 *       令和8年厚生労働省告示第52号（https://www.mhlw.go.jp/content/11900000/001662589.pdf・告示番号は厚労省
 *       「職場におけるハラスメントの防止のために」のページの掲載名で確認）。第4節の措置は (1)イ〜ハ・(2)イ〜ロ・(3)イ〜ニ・(4)イ〜ロ の11項目。
 *
 * カスタマーハラスメント（労働施策総合推進法 第33条・令和8年厚生労働省告示第51号）は customer_harassment.ts が受け持つ。
 * ★措置の当否（例: 個別の事案が就活セクハラに当たるか）は断定しない。判断は事業主・弁護士・都道府県労働局（雇用環境・均等部（室））へ。
 */

export const JOBSEEKER_SH_LEGAL_VALUES = {
  law: '雇用の分野における男女の均等な機会及び待遇の確保等に関する法律（男女雇用機会均等法）',
  lawId: '347AC0000000113',
  measureArticle: '第13条第1項',
  retaliationArticle: '第13条第2項',
  dutyArticle: '第14条',
  amendmentLaw: '令和7年法律第63号',
  promulgated: '2025-06-11',
  effective: '2026-10-01',
  guideline: '事業主が求職活動等における性的な言動に起因する問題に関して雇用管理上講ずべき措置等についての指針（令和8年厚生労働省告示第52号）',
  guidelineUrl: 'https://www.mhlw.go.jp/content/11900000/001662589.pdf',
  /**
   * 2026-10-01 の繰り下げ（旧→新）。旧番号を新しい日付の表示に使わないため。
   * e-Gov の asof=2026-09-30 と 2026-10-01 の条の見出しの一致で機械照合した（同じ見出しが複数ある条は載せていない）。
   */
  renumbered: {
    '11の2': '12', '11の3': '15', '11の4': '16', '12': '17', '13の2': '19', '15': '21', '16': '22', '17': '23', '18': '24', '19': '25',
    '24': '30', '25': '31', '26': '32', '27': '33', '28': '34', '29': '35', '30': '36', '31': '37', '32': '38',
  } as Record<string, string>,
  jobseekerCategories: [
    { key: 'jobseeker', ja: '求職者（応募者・選考中の者・内定者等）', basis: '均等法第13条第1項' },
    { key: 'recruiting_activity', ja: '事業主の実施する労働者の採用に資する活動に参加する者（インターンシップ・説明会・社員訪問等）', basis: '均等則第2条の3第1号' },
    { key: 'practicum', ja: '教育実習、看護実習その他の実習を受ける者', basis: '均等則第2条の3第2号' },
  ],
  measures: [
    { key: '1-i', ja: '方針（就活セクハラの内容・行ってはならない旨）の明確化と、管理監督者を含む労働者への周知・啓発', basis: '指針4(1)イ' },
    { key: '1-ro', ja: '行為者に厳正に対処する旨の方針・対処の内容の就業規則等への規定と周知・啓発', basis: '指針4(1)ロ' },
    { key: '1-ha', ja: '求職活動等に関するルール（面談の時間・場所・実施体制・使うSNS等）の明確化と、労働者・求職者等への周知・啓発', basis: '指針4(1)ハ' },
    { key: '2-i', ja: '相談窓口をあらかじめ定め、求職者等に周知する', basis: '指針4(2)イ' },
    { key: '2-ro', ja: '相談窓口の担当者が内容や状況に応じ適切に対応できるようにする', basis: '指針4(2)ロ' },
    { key: '3-i', ja: '事実関係を迅速かつ正確に確認する', basis: '指針4(3)イ' },
    { key: '3-ro', ja: '事実が確認できた場合、速やかに被害者に対する配慮の措置を適正に行う', basis: '指針4(3)ロ' },
    { key: '3-ha', ja: '事実が確認できた場合、行為者に対する措置を適正に行う', basis: '指針4(3)ハ' },
    { key: '3-ni', ja: '再発防止に向けた措置を講ずる（事実が確認できなかった場合も同様）', basis: '指針4(3)ニ' },
    { key: '4-i', ja: '相談者・行為者等のプライバシーを保護する措置と、その旨の労働者・求職者等への周知', basis: '指針4(4)イ' },
    { key: '4-ro', ja: '相談・協力等を理由に解雇その他不利益な取扱いをされない旨の定めと労働者への周知・啓発', basis: '指針4(4)ロ・法第13条第2項' },
  ],
  sourceCheckedOn: '2026-10-03',
} as const;

const ymd = (d: string | Date): string =>
  typeof d === 'string'
    ? d.slice(0, 10)
    : `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export function isJobseekerHarassmentDutyInForce(asOf: string | Date = new Date()): boolean {
  return ymd(asOf) >= JOBSEEKER_SH_LEGAL_VALUES.effective;
}

/** 画面に出す法令の表示（基準日で切り替える） */
export function getJobseekerHarassmentDisplay(asOf: string | Date = new Date()): { inForce: boolean; text: string } {
  const v = JOBSEEKER_SH_LEGAL_VALUES;
  if (!isJobseekerHarassmentDutyInForce(asOf)) {
    return { inForce: false, text: `求職者等に対するセクシュアルハラスメントの防止措置は ${v.effective}（令和8年10月1日）から事業主の義務になります（${v.amendmentLaw}による改正後の男女雇用機会均等法${v.measureArticle}）。` };
  }
  return { inForce: true, text: `男女雇用機会均等法${v.measureArticle}により、事業主は求職者等に対するセクシュアルハラスメントの防止措置を講じなければなりません（${v.effective} 施行・指針は令和8年厚生労働省告示第52号）。` };
}

/** 指針の11項目の点検。施行前は「準備事項」（違反と断定しない: compliant=null） */
export function checkJobseekerHarassmentMeasures(measures: Record<string, boolean>, asOf: string | Date = new Date()): {
  inForce: boolean; compliant: boolean | null; missing: string[]; missingLabels: string[]; message: string;
} {
  const v = JOBSEEKER_SH_LEGAL_VALUES;
  const missingItems = v.measures.filter((m) => !measures[m.key]);
  const inForce = isJobseekerHarassmentDutyInForce(asOf);
  const missing = missingItems.map((m) => m.key);
  const missingLabels = missingItems.map((m) => `${m.basis} ${m.ja}`);
  if (!inForce) {
    return { inForce, compliant: null, missing, missingLabels, message: missing.length ? `${v.effective} の施行までに整える準備事項が ${missing.length} 件あります` : `${v.effective} の施行に向けた措置はそろっています` };
  }
  return {
    inForce,
    compliant: missing.length === 0,
    missing,
    missingLabels,
    message: missing.length
      ? `施行済み（${v.effective}〜）の措置義務のうち ${missing.length} 件が未整備です。都道府県労働局の助言・指導・勧告の対象になり得ます（均等法第35条・2026-10-01 の繰り下げ後の条番号）`
      : '指針の措置11項目がそろっています',
  };
}

/**
 * 応対記録の閲覧の権限（指針4(4)イ: 相談者・行為者等のプライバシー保護）
 *   既定は拒否。閲覧できるのは、その記録の相談窓口の担当者・その記録に指定された人事担当・法務だけ。
 *   行為者とされた労働者は役割に関わらず拒否する。面接官・一般社員・役割の無い利用者は拒否。
 */
export function canViewJobseekerConsultation(
  viewer: { userId?: string; role?: string },
  record: { consultationDeskUserIds?: string[]; designatedHrUserIds?: string[]; accusedEmployeeIds?: string[] },
): boolean {
  if (!viewer || !viewer.userId) return false;
  if ((record.accusedEmployeeIds || []).includes(viewer.userId)) return false;
  if (viewer.role === 'legal') return true;
  if (viewer.role === 'consultation_desk') return (record.consultationDeskUserIds || []).includes(viewer.userId);
  if (viewer.role === 'hr') return (record.designatedHrUserIds || []).includes(viewer.userId);
  return false;
}

/** 応対記録の必須欄（受付日時・経路・求職者等の区分・申出の事実・対応者） */
export function validateJobseekerConsultationRecord(rec: Record<string, unknown>): { ok: boolean; missing: string[] } {
  const missing: string[] = [];
  const has = (k: string) => rec[k] !== undefined && rec[k] !== null && String(rec[k]).trim() !== '';
  for (const k of ['receivedAt', 'channel', 'jobseekerCategory', 'facts', 'handledBy']) if (!has(k)) missing.push(k);
  if (has('jobseekerCategory') && !JOBSEEKER_SH_LEGAL_VALUES.jobseekerCategories.some((c) => c.key === rec.jobseekerCategory)) {
    missing.push('jobseekerCategory（均等法第13条第1項・均等則第2条の3 の区分に無い値）');
  }
  return { ok: missing.length === 0, missing };
}
