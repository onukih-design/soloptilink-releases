/**
 * SoloptiLinkAI Phase 45 — フリーランス新法対応
 *
 * 特定受託事業者に係る取引の適正化等に関する法律 (令和5年法律第25号)
 * 通称: フリーランス・事業者間取引適正化等法 / フリーランス新法
 *
 * - 公布: 2023-05-12 (R5.5.12)
 * - 施行: 2024-11-01 (R6.11.1)
 * - ガイドライン: 2024-05-31 公表 / 2025-10-01 改正版 (R7.10.1)
 * - 主管庁: 公正取引委員会・中小企業庁 (取引適正化) / 厚生労働省 (就業環境整備)
 *
 * カバー範囲:
 *  - 第3条 取引条件明示義務 (11項目)
 *  - 第4条 報酬支払期日 (給付受領日 + 60日以内、再委託特則 30日)
 *  - 第5条 禁止行為7類型 (受領拒否/減額/返品/買いたたき/購入強制/利益提供/不当やり直し)
 *  - 第8条・第9条 勧告・命令・公表 (公正取引委員会: 第3条〜第5条関係)
 *  - 第13条 妊娠・出産・育児・介護に対する配慮 (6ヶ月以上の継続的業務委託は義務・それ以外は努力義務)
 *  - 第14条 業務委託に関して行われる言動に起因する問題（ハラスメント）に関して講ずべき措置
 *  - 第16条 解除等の予告 (継続的業務委託の解除・不更新は少なくとも30日前)
 *  - 第18条・第19条 勧告・命令・公表 (厚生労働大臣: 第12条・第14条・第16条関係)
 *  - 第24条 罰則 (50万円以下の罰金) / 第25条 両罰規定 / 第26条 過料 (20万円以下)
 *  条番号は e-Gov 505AC0000000025 (asof=2026-09-30・revision 20241101) で照合 (2026-09-30 是正 I2)
 *  - 取適法 (旧 下請法) との二重適用ロジック (資本金基準・従業員基準・5類型)
 *
 * SoT: https://laws.e-gov.go.jp/law/505AC0000000025
 *      https://www.jftc.go.jp/file/fl_jftcmhlwguidelines.pdf
 */

import { checkFreelancePaymentDate, judgeToritekiApplicability, ymdToJstDate, FREELANCE_PAYMENT_VALUES, type ToritekiTransactionType } from "./toriteki";

export const FREELANCE_LAW_VERSION = "R7.10.1";
export const FREELANCE_LAW_EFFECTIVE = "2024-11-01";

export const FREELANCE_LAW_ARTICLES = {
  ART_3: { name: "取引条件明示", method: "書面/電磁的方法", timing: "直ちに" },
  // 値は toriteki.ts の FREELANCE_PAYMENT_VALUES (第4条) を唯一の置き場とする
  ART_4: { name: "報酬支払期日", limit_days: FREELANCE_PAYMENT_VALUES.payment_limit_days, base: "給付受領日 (受領日を1日目として数える)", reconsign_limit_days: FREELANCE_PAYMENT_VALUES.reconsign_limit_days },
  ART_5: { name: "禁止行為7類型", scope: "1ヶ月以上の業務委託" },
  ART_8: { name: "勧告 (公正取引委員会)" },
  ART_9: { name: "命令・公表 (公正取引委員会)" },
  ART_13: { name: "妊娠・出産・育児・介護に対する配慮", scope: "6ヶ月以上の継続的業務委託 (それ以外は努力義務)" },
  ART_14: { name: "業務委託に関して行われる言動（ハラスメント）に起因する問題に関して講ずべき措置" },
  ART_16: { name: "解除等の予告", notice_days: 30, scope: "6ヶ月以上の継続的業務委託 (不更新を含む)" },
  ART_18: { name: "勧告 (厚生労働大臣)" },
  ART_19: { name: "命令等・公表 (厚生労働大臣)" },
  ART_24: { name: "罰則", fine_jpy: 500_000 },
  ART_25: { name: "両罰規定", dual_liability: true },
  ART_26: { name: "過料", non_penal_fine_jpy: 200_000 },
} as const;

/** 条番号の表記（rule 文字列はここを読む） */
const ARTICLE_LABEL = {
  harassment: "第14条",
  termination: "第16条",
} as const;

export const PROHIBITED_ACTS_7 = [
  "RECEIPT_REFUSAL",
  "PAYMENT_REDUCTION",
  "RETURN",
  "BUYING_AT_LOW_PRICE",
  "FORCED_PURCHASE",
  "UNJUST_PROFIT",
  "UNJUST_REWORK",
] as const;
export type ProhibitedAct = (typeof PROHIBITED_ACTS_7)[number];

export const DISCLOSURE_REQUIRED_11 = [
  "ordering_party_name",
  "receiving_party_name",
  "consigned_at",
  "work_description",
  "delivery_received_at",
  "delivery_received_place",
  "inspection_completed_at",
  "remuneration_amount",
  "payment_due_at",
  "payment_method_when_non_cash",
  "electronic_method_designation",
] as const;
export type DisclosureItem = (typeof DISCLOSURE_REQUIRED_11)[number];

export const HARASSMENT_TYPES = ["SEXUAL", "MATERNITY", "POWER"] as const;
export type HarassmentType = (typeof HARASSMENT_TYPES)[number];

export interface ApplicabilityInput {
  receiver: { isIndividual: boolean; isOnePersonCorp: boolean; hasEmployees: boolean };
  commissioner: { hasEmployees: boolean };
  hasLaborSubordination: boolean;
}

export interface DisclosureDoc {
  items_present: ReadonlyArray<DisclosureItem>;
  is_written_or_electronic: boolean;
  delivered_immediately: boolean;
}

export interface PaymentInput {
  receivedAt: Date;
  paymentDueAt: Date;
  isReConsignment: boolean;
  /** 元委託支払期日 (再委託の場合) */
  parentPaymentDate?: Date;
  /** 再委託である旨・元委託者の氏名又は名称・元委託支払期日等を明示したか (第4条3項の要件) */
  reconsignmentDisclosed?: boolean;
}

export interface TransactionEvent {
  kind: ProhibitedAct;
  cause_attributable_to_receiver: boolean;
  agreed_in_advance?: boolean;
  evidence?: string;
}

export interface TerminationInput {
  contractStart: Date;
  contractEnd: Date;
  terminationDate: Date;
  noticeSentAt: Date;
  noticeMethod: "WRITTEN" | "FAX" | "EMAIL" | "VERBAL";
}

export interface HarassmentPolicy {
  has_sop_sexual: boolean;
  has_sop_maternity: boolean;
  has_sop_power: boolean;
  has_consult_desk: boolean;
  has_training_program: boolean;
}

export type ErrorCode =
  | "ART3_MISSING_ITEM"
  | "ART3_NOT_WRITTEN"
  | "ART3_NOT_IMMEDIATE"
  | "ART4_OVER_60D"
  | "ART4_OVER_30D_RECON"
  | "ART4_NO_DUE_DATE"
  | `ART5_${ProhibitedAct}`
  | "ART16_LESS_THAN_30D"
  | "ART16_INVALID_METHOD"
  | "ART16_NOT_APPLICABLE_UNDER_6M"
  | "ART14_MISSING_SOP";

export interface Finding {
  code: ErrorCode;
  rule: string;
  severity: "info" | "warning" | "violation";
  hint: string;
  field?: string;
}

const DAY_MS = 24 * 3600 * 1000;
const diffDays = (a: Date, b: Date) => Math.floor((a.getTime() - b.getTime()) / DAY_MS);

/** 適用判定: フリーランス新法が適用される取引か */
export function isFreelanceLawApplicable(input: ApplicabilityInput): { applies: boolean; reason: string } {
  if (input.hasLaborSubordination) {
    return { applies: false, reason: "労働者性が認められるため労働関係法令が優先" };
  }
  const isFreelance = input.receiver.isIndividual || (input.receiver.isOnePersonCorp && !input.receiver.hasEmployees);
  if (!isFreelance) {
    return { applies: false, reason: "受託者が特定受託事業者に該当しない" };
  }
  if (!input.commissioner.hasEmployees) {
    return { applies: false, reason: "委託者が個人かつ従業員なし → 法対象外 (BtoB除外)" };
  }
  return { applies: true, reason: "特定受託事業者×特定業務委託事業者の構成を満たす" };
}

/** 第3条: 取引条件11項目の明示チェック */
export function validateDisclosure(doc: DisclosureDoc): { ok: boolean; missing: DisclosureItem[]; findings: Finding[] } {
  const findings: Finding[] = [];
  const present = new Set<DisclosureItem>(doc.items_present);
  const missing = DISCLOSURE_REQUIRED_11.filter((k) => !present.has(k)) as DisclosureItem[];

  for (const m of missing) {
    findings.push({
      code: "ART3_MISSING_ITEM",
      rule: "フリーランス新法 第3条 (取引条件明示)",
      severity: "violation",
      hint: `必須項目「${m}」が欠落。書面/電磁的方法での明示が必要。`,
      field: m,
    });
  }
  if (!doc.is_written_or_electronic) {
    findings.push({
      code: "ART3_NOT_WRITTEN",
      rule: "フリーランス新法 第3条",
      severity: "violation",
      hint: "口頭のみの取引条件は違反。書面または電磁的方法で明示すること。",
    });
  }
  if (!doc.delivered_immediately) {
    findings.push({
      code: "ART3_NOT_IMMEDIATE",
      rule: "フリーランス新法 第3条",
      severity: "violation",
      hint: "業務委託をしたとき直ちに明示する必要がある。",
    });
  }
  return { ok: findings.length === 0 && missing.length === 0, missing, findings };
}

/**
 * 第4条: 報酬支払期日
 *   原則: 給付を受領した日 (役務は提供を受けた日) から起算して60日の期間内 (受領日を1日目として60日目まで)。
 *   違反して定めたときは「六十日を経過する日」(=60日目) を支払期日とみなす (第4条2項)。
 *   再委託の特則: 再委託である旨・元委託者・元委託支払期日等を明示した場合に限り、
 *   元委託支払期日から起算して30日の期間内 (第4条3項・4項)。
 * ★2026-09-30 是正 (REQ-JPO-FIX-015): 旧実装は受領日を算入せず61日目 (受領6/1→7/31) を適法とし、
 *   再委託は元委託支払期日ではなく受領日から30日で判定していた。日数の数え方は toriteki.ts に一本化した。
 */
export function validatePaymentDeadline(input: PaymentInput): {
  ok: boolean;
  effectiveDueAt: Date;
  /** 受領日 (再委託の特則を使う場合は元委託支払期日) を1日目として、支払期日は何日目か */
  daysFromReceived: number;
  findings: Finding[];
} {
  const findings: Finding[] = [];
  const r = checkFreelancePaymentDate({
    receivedAt: input.receivedAt,
    paymentDate: input.paymentDueAt,
    isReConsignment: input.isReConsignment,
    parentPaymentDate: input.parentPaymentDate,
    reconsignmentDisclosed: input.reconsignmentDisclosed,
  });
  const limitDays = r.usedReconsignRule ? FREELANCE_LAW_ARTICLES.ART_4.reconsign_limit_days : FREELANCE_LAW_ARTICLES.ART_4.limit_days;
  const effectiveDueAt = r.ok ? input.paymentDueAt : ymdToJstDate(r.deemedDueDate);

  if (!r.ok) {
    findings.push({
      code: r.usedReconsignRule ? "ART4_OVER_30D_RECON" : "ART4_OVER_60D",
      rule: "フリーランス新法 第4条 (報酬支払期日)",
      severity: "violation",
      hint: `支払期日が法定上限 (${r.usedReconsignRule ? "元委託支払期日" : "受領日"}を1日目として${limitDays}日目 = ${r.lastDay}) を超過 (${r.dayNumber}日目)。法定期日 ${r.deemedDueDate} を支払期日とみなす。`,
    });
  }
  if (input.isReConsignment && !r.usedReconsignRule) {
    findings.push({
      code: "ART4_NO_DUE_DATE",
      rule: "フリーランス新法 第4条3項 (再委託の特則)",
      severity: "warning",
      hint: "再委託の特則 (元委託支払期日から30日) は、再委託である旨・元委託者・元委託支払期日を明示した場合に限る。明示または元委託支払期日が無いため、受領日から60日の原則で判定した。",
    });
  }
  return { ok: findings.every((f) => f.severity !== "violation"), effectiveDueAt, daysFromReceived: r.dayNumber, findings };
}

/** 第5条: 禁止行為7類型の検出 */
export function detectProhibitedActs(events: ReadonlyArray<TransactionEvent>): { findings: Finding[] } {
  const findings: Finding[] = [];
  for (const e of events) {
    if (e.cause_attributable_to_receiver) continue;
    findings.push({
      code: `ART5_${e.kind}` as ErrorCode,
      rule: "フリーランス新法 第5条 (禁止行為)",
      severity: "violation",
      hint: `${e.kind} は受託者の責に帰すべき事由がない場合は禁止。${e.agreed_in_advance ? "事前合意があっても違反。" : ""}${e.evidence ?? ""}`,
    });
  }
  return { findings };
}

/** 第16条: 解除等の予告 (少なくとも30日前) */
export function validateTerminationNotice(input: TerminationInput): {
  ok: boolean;
  daysAhead: number;
  findings: Finding[];
} {
  const findings: Finding[] = [];
  const contractMonths = (input.contractEnd.getTime() - input.contractStart.getTime()) / (30 * DAY_MS);
  if (contractMonths < 6) {
    findings.push({
      code: "ART16_NOT_APPLICABLE_UNDER_6M",
      rule: `フリーランス新法 ${ARTICLE_LABEL.termination} (解除等の予告)`,
      severity: "info",
      hint: "6ヶ月以上の継続契約のみ予告義務あり。本契約は適用外。",
    });
    return { ok: true, daysAhead: 0, findings };
  }
  const daysAhead = diffDays(input.terminationDate, input.noticeSentAt);
  if (daysAhead < 30) {
    findings.push({
      code: "ART16_LESS_THAN_30D",
      rule: `フリーランス新法 ${ARTICLE_LABEL.termination} (解除等の予告)`,
      severity: "violation",
      hint: `予告日数 ${daysAhead}日 が法定30日未満。書面/FAX/電子メールでの30日前予告が必須。`,
    });
  }
  if (input.noticeMethod === "VERBAL") {
    findings.push({
      code: "ART16_INVALID_METHOD",
      rule: `フリーランス新法 ${ARTICLE_LABEL.termination} (解除等の予告)`,
      severity: "violation",
      hint: "口頭予告は無効。書面・FAX・電子メールのいずれかが必要。",
    });
  }
  return { ok: findings.length === 0, daysAhead, findings };
}

/** 第14条: ハラスメント対策の体制チェック (業務委託に関して行われる言動に起因する問題に関して講ずべき措置) */
export function validateHarassmentSystem(policy: HarassmentPolicy): { ok: boolean; findings: Finding[] } {
  const findings: Finding[] = [];
  if (!policy.has_sop_sexual) {
    findings.push({ code: "ART14_MISSING_SOP", rule: `フリーランス新法 ${ARTICLE_LABEL.harassment}`, severity: "violation", hint: "セクハラ防止規程が未整備。" });
  }
  if (!policy.has_sop_maternity) {
    findings.push({ code: "ART14_MISSING_SOP", rule: `フリーランス新法 ${ARTICLE_LABEL.harassment}`, severity: "violation", hint: "マタハラ防止規程が未整備。" });
  }
  if (!policy.has_sop_power) {
    findings.push({ code: "ART14_MISSING_SOP", rule: `フリーランス新法 ${ARTICLE_LABEL.harassment}`, severity: "violation", hint: "パワハラ防止規程が未整備。" });
  }
  if (!policy.has_consult_desk) {
    findings.push({ code: "ART14_MISSING_SOP", rule: `フリーランス新法 ${ARTICLE_LABEL.harassment}`, severity: "warning", hint: "相談窓口の設置が望ましい。" });
  }
  if (!policy.has_training_program) {
    findings.push({ code: "ART14_MISSING_SOP", rule: `フリーランス新法 ${ARTICLE_LABEL.harassment}`, severity: "warning", hint: "教育研修プログラムの整備が望ましい。" });
  }
  return { ok: findings.length === 0, findings };
}

/**
 * 取適法 (旧 下請法) との二重適用判定
 * ★2026-09-30 是正 (REQ-JPO-FIX-003): 旧実装は「資本金1000万円超 × 4取引類型」だけで判定していた。
 *   取適法は従業員基準 (第2条8項5号・6号) と特定運送委託 (第2条5項) を加えた5類型で判定する。
 *   判定は toriteki.judgeToritekiApplicability に一本化。受託者 (特定受託事業者) は個人または従業員のいない法人。
 */
export function dualLawCompliance(input: {
  commissioner_capital_jpy: number;
  subcontract_act_categories_match: boolean;
  /** 委託者の常時使用する従業員の数 (従業員基準の判定に使う) */
  commissioner_employees?: number;
  /** 取引の類型 (取適法の5類型)。省略時は区分Aの製造委託として扱う */
  transaction_type?: ToritekiTransactionType;
  /** 政令の情報成果物 (プログラム) / 役務 (運送・倉庫保管・情報処理) か */
  government_ordered_category?: boolean;
}): {
  primary: "FREELANCE_LAW";
  secondary: "SUBCONTRACT_LAW" | "NONE";
  reason: string;
} {
  if (!input.subcontract_act_categories_match) {
    return { primary: "FREELANCE_LAW", secondary: "NONE", reason: "取適法の5類型 (製造・修理・情報成果物作成・役務提供・特定運送) に当たらない → フリーランス新法のみ適用。" };
  }
  const j = judgeToritekiApplicability({
    type: input.transaction_type ?? "manufacturing",
    governmentOrderedCategory: input.government_ordered_category,
    consignor: { capitalYen: input.commissioner_capital_jpy, employees: input.commissioner_employees ?? null },
    // 特定受託事業者は個人または従業員を使用しない法人 (資本金は通常1千万円以下の扱いとせず個人として判定)
    contractor: { isIndividual: true, employees: 0 },
  });
  const apply = j.applies === true;
  return {
    primary: "FREELANCE_LAW",
    secondary: apply ? "SUBCONTRACT_LAW" : "NONE",
    reason: apply
      ? `取適法も同時適用 (${j.basis})。フリーランス新法を優先適用しつつ監査ログには両方記録。`
      : j.applies === null
        ? `取適法の適用を確認できていない (${j.reasons.join(" / ")})。委託者の従業員数を入力すること。`
        : "取適法非該当 (資本金基準・従業員基準のいずれにも当たらない) → フリーランス新法のみ適用。",
  };
}

/** Phase 45 self check: モジュール健全性 (tests からも呼ばれる) */
export function selfCheck(): { ok: boolean; checks: Array<{ name: string; pass: boolean }> } {
  const checks = [
    { name: "ART_4 60日定数", pass: FREELANCE_LAW_ARTICLES.ART_4.limit_days === 60 },
    { name: "ART_4 再委託30日定数", pass: FREELANCE_LAW_ARTICLES.ART_4.reconsign_limit_days === 30 },
    { name: "禁止行為7類型", pass: PROHIBITED_ACTS_7.length === 7 },
    { name: "明示11項目", pass: DISCLOSURE_REQUIRED_11.length === 11 },
    // 旧: 本則に無い条 (ART_28) を罰則として固定していた → 第24条へ是正 (2026-09-30 I2)
    { name: "罰則50万円 (第24条)", pass: FREELANCE_LAW_ARTICLES.ART_24.fine_jpy === 500_000 },
    { name: "両罰規定 (第25条)", pass: FREELANCE_LAW_ARTICLES.ART_25.dual_liability === true },
    { name: "解除予告30日 (第16条)", pass: FREELANCE_LAW_ARTICLES.ART_16.notice_days === 30 },
    {
      name: "60日違反検出",
      pass: validatePaymentDeadline({ receivedAt: new Date("2026-01-01"), paymentDueAt: new Date("2026-04-01"), isReConsignment: false }).ok === false,
    },
    {
      // 受領日を1日目として60日目 (6/1→7/30) は適法、61日目 (7/31) は違反
      name: "60日の境目 (受領日を算入)",
      pass: validatePaymentDeadline({ receivedAt: new Date("2026-06-01"), paymentDueAt: new Date("2026-07-30"), isReConsignment: false }).ok === true
        && validatePaymentDeadline({ receivedAt: new Date("2026-06-01"), paymentDueAt: new Date("2026-07-31"), isReConsignment: false }).ok === false,
    },
    {
      name: "適用判定: 個人×法人発注",
      pass: isFreelanceLawApplicable({ receiver: { isIndividual: true, isOnePersonCorp: false, hasEmployees: false }, commissioner: { hasEmployees: true }, hasLaborSubordination: false }).applies === true,
    },
    {
      name: "適用判定: 労働者性ありで除外",
      pass: isFreelanceLawApplicable({ receiver: { isIndividual: true, isOnePersonCorp: false, hasEmployees: false }, commissioner: { hasEmployees: true }, hasLaborSubordination: true }).applies === false,
    },
  ];
  return { ok: checks.every((c) => c.pass), checks };
}
