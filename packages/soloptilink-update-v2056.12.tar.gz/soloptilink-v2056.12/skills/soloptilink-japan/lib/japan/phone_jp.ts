/**
 * 日本の電話番号の整形（lib/japan の電話整形の唯一の処理）
 *
 * 2026-09-30 REQ-JPO-FIX-006: 電話整形が3系統（kana.ts formatPhone／bug_prevention.ts formatPhoneJP／
 *   templates/japan-ui phone.ts）に分かれ、4桁・5桁の市外局番（0422・01267・04992 ほか）を 3-3-4 で区切り、
 *   0800 を携帯の 080 と取り違え、+81 を「813-…」にしていた。3系統ともこの関数を呼ぶ形に寄せた。
 *
 * 決まり（値は phone_jp_data.ts。出典はそちらに記載）:
 *   - 全角数字・ハイフン類・空白・括弧は読み飛ばす。それ以外の文字（「内線」・英字など）があれば整形しない。
 *   - 先頭の「+81」（全角可）は国番号として外し、国内プレフィックス 0 を補う（告示 第5の注）。「+81(0)3…」の (0) も受け付ける。
 *   - 0AB0 番号・携帯・IP 電話は桁数が合うときだけ整形する。0800 は 080 より先に照合する。
 *   - 固定電話は10桁のときだけ、市外局番の一覧の最長一致で「0-市外局番-市内局番-加入者番号」に区切る
 *     （市外局番＋市内局番＝5桁・加入者番号4桁。0550 のような 0AB0 型の市外局番もここで扱う）。
 *     ただし市外局番「04」と 042・047・0470 が重なる先頭は AREA_CODE_OVERRIDES（総務省「電話番号の変更」）を先に見る
 *     （0471→04-71XX・04709→04-709X。0429 は所沢ほかと飯能・日高が共有するため整形しない）。
 *   - 判断できない番号（桁数が合わない・一覧に無い・020・00 始まりなど）は【入力をそのまま】返す。
 */
import { AREA_CODES, AREA_CODE_OVERRIDES, SERVICE_NUMBER_FORMATS } from './phone_jp_data';

const AREA_CODE_SET: ReadonlySet<string> = new Set(AREA_CODES);

export type JapanesePhoneKind = 'fixed' | 'service' | 'unknown';

export interface JapanesePhoneAnalysis {
  /** 整形できたか（false のときは formatted に入力をそのまま入れる） */
  ok: boolean;
  /** 整形結果（整形できないときは入力のまま） */
  formatted: string;
  /** 数字だけにした国内形式（読めなかったときは null） */
  digits: string | null;
  kind: JapanesePhoneKind;
  /** 種類の日本語名（固定電話・携帯電話・IP電話・着信課金 など） */
  kind_ja: string;
  /** 整形できなかった理由（日本語） */
  reason_ja?: string;
}

/** 全角数字・区切り記号・国番号を読み、国内形式の数字列にする。読めなければ null */
function toDomesticDigits(input: string): string | null {
  let s = String(input ?? '').trim();
  if (!s) return null;
  s = s.replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0)).replace(/＋/g, '+');
  let international = false;
  if (s.startsWith('+')) {
    if (!/^\+[\s　\-‐‑‒–—―−－ー]*81/.test(s)) return null;
    s = s.replace(/^\+[\s　\-‐‑‒–—―−－ー]*81/, '');
    international = true;
  }
  // 国番号の後の「(0)」は国内プレフィックスの書き添え
  if (international) s = s.replace(/^[\s　\-‐‑‒–—―−－ー]*[(（]0[)）]/, '');
  // 許す文字は数字と区切り記号だけ
  if (!/^[0-9\s　\-‐‑‒–—―−－ー()（）.]+$/.test(s)) return null;
  let d = s.replace(/[^0-9]/g, '');
  if (!d) return null;
  if (international) {
    if (d.startsWith('0')) return null; // +81 の後に 0 が重なる書き方は判断しない
    d = '0' + d;
  }
  return d;
}

function group(d: string, sizes: readonly number[]): string {
  const out: string[] = [];
  let i = 0;
  for (const n of sizes) { out.push(d.slice(i, i + n)); i += n; }
  return out.join('-');
}

/** 電話番号を読み、種類と整形結果を返す。判断できないときは ok=false・formatted=入力のまま */
export function analyzeJapanesePhone(input: string): JapanesePhoneAnalysis {
  const raw = String(input ?? '');
  const d = toDomesticDigits(raw);
  const ng = (reason_ja: string, digits: string | null = d): JapanesePhoneAnalysis =>
    ({ ok: false, formatted: raw, digits, kind: 'unknown', kind_ja: '不明', reason_ja });
  if (!d) return ng('電話番号として読めない文字が含まれています', null);
  if (!d.startsWith('0')) return ng('先頭が0ではないため、国内の電話番号と判断できません');
  if (d.startsWith('00')) return ng('00 から始まる番号（事業者識別番号・国際）は整形しません');

  for (const f of SERVICE_NUMBER_FORMATS) {
    if (!d.startsWith(f.prefix)) continue;
    if (f.cNotZero && d.charAt(f.prefix.length) === '0') continue;
    if (d.length !== f.length) return ng(`${f.kind_ja}の番号は${f.length}桁です（入力は${d.length}桁）`);
    return { ok: true, formatted: group(d, f.groups), digits: d, kind: 'service', kind_ja: f.kind_ja };
  }
  if (d.length !== 10) return ng(`固定電話の番号は10桁です（入力は${d.length}桁）`);
  // 最長一致では区切れない先頭（市外局番「04」と 042・047・0470 の重なり）を先に見る
  const ov = [...AREA_CODE_OVERRIDES].sort((a, b) => b.prefix.length - a.prefix.length).find((o) => d.slice(1).startsWith(o.prefix));
  if (ov) {
    if (ov.area === null) return ng(`${ov.note_ja}ため、区切り位置を判断できません`);
    return {
      ok: true,
      formatted: `0${ov.area}-${d.slice(1 + ov.area.length, 6)}-${d.slice(6)}`,
      digits: d,
      kind: 'fixed',
      kind_ja: '固定電話',
    };
  }
  for (let len = 4; len >= 1; len--) {
    const area = d.slice(1, 1 + len);
    if (!AREA_CODE_SET.has(area)) continue;
    return {
      ok: true,
      formatted: `0${area}-${d.slice(1 + len, 6)}-${d.slice(6)}`,
      digits: d,
      kind: 'fixed',
      kind_ja: '固定電話',
    };
  }
  return ng('市外局番の一覧に無い番号のため、区切り位置を判断できません');
}

/** 電話番号を日本の表記に整形する。判断できない番号は入力をそのまま返す */
export function formatJapanesePhone(input: string): string {
  return analyzeJapanesePhone(input).formatted;
}
