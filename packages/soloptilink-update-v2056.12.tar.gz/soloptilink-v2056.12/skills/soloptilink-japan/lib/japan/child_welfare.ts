/**
 * SoloptiLinkAI Phase 47-CH — こども家庭DX (こども基本法 / 児童虐待防止法 / DBS)
 *
 * カバー範囲:
 *  - こども基本法 (R4.6.22 公布 / R5.4.1 施行)
 *      6つの基本理念 (法3条) + こども施策 (法11条)
 *      意見表明機会の確保 (法11条) + こども大綱 (法9条)
 *  - こども家庭庁設置法 (R4.6.22 / R5.4.1)
 *      内閣府外局として設置 + 内閣府特命担当大臣 (こども政策)
 *      長官官房 + 成育局 + 支援局 + 政策立案総括官
 *  - 児童虐待の防止等に関する法律 (H12法82号)
 *      虐待4類型: 身体/性的/ネグレクト/心理 (法2条)
 *      通告義務 (法6条) — 児童相談所/福祉事務所/市町村
 *      48時間ルール (児相 安全確認) — 厚労省通知
 *  - 保育所等の職員による虐待の通報義務 (令和7年法律第29号 / 2025-10-01 施行・児童福祉法33条の10〜33条の16)
 *      通報記録の必須項目・所管行政庁の判定 (createStaffAbuseReport / routeStaffAbuseReport)
 *  - 児童福祉法 R4.6.15 改正 / R6.4.1 施行
 *      こども家庭センター設置 (法10条の2)
 *      在宅指導措置の強化 + 一時保護開始時の司法審査 (法33条)
 *  - こども性暴力防止法 (日本版DBS・令和6年法律第69号) 2024-06-26 公布 / 2026-12-25 施行
 *      正式題名: 学校設置者等及び民間教育保育等事業者による児童対象性暴力等の防止等のための措置に関する法律
 *      施行日は施行令 (令和7年政令第440号) 附則1項「法の施行の日（令和八年十二月二十五日）」
 *      義務: 学校設置者等 (法2条3項) / 任意の認定: 民間教育保育等事業者 (法2条5項・19条)
 *      確認は国が行い、事業者は犯罪事実確認書を受け取るだけ (法33〜35条)。採否は事業者が判断 (法6条)
 *      → 本部品は判定をせず「確認の状態の記録」と期限の計算だけを行う (オーナー決定 X1)
 *  - 配偶者暴力防止法 (R6.4.1 改正施行)
 *      接近禁止命令の対象拡大 (子・親族) + 接近禁止期間 6ヶ月→1年
 *  - 児童ポルノ禁止法 (H11法52号)
 *  - ヤングケアラー支援 (R6.4 改正児童福祉法)
 *  - 「異次元の少子化対策」(R5.6 こども未来戦略方針)
 *
 * 出典:
 *  - こども家庭庁 https://www.cfa.go.jp/
 *  - 厚労省 児童虐待 https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kodomo/kodomo_kosodate/
 */

// ----------------------------------------------------------------------
// 1) 児童虐待 4類型 (法2条) + 通告義務
// ----------------------------------------------------------------------

export const ABUSE_TYPES = [
  { id: "physical", name: "身体的虐待", examples: ["殴る", "蹴る", "投げ落とす", "激しく揺さぶる", "やけど", "逆さ吊り"] },
  { id: "sexual", name: "性的虐待", examples: ["子どもへの性的行為", "性的行為を見せる", "性器・性交を見せる", "ポルノの被写体にする"] },
  { id: "neglect", name: "ネグレクト (養育放棄)", examples: ["食事を与えない", "ひどく不潔にする", "学校に行かせない", "車中放置", "病気でも病院に連れていかない"] },
  { id: "psychological", name: "心理的虐待", examples: ["言葉による脅し", "無視", "兄弟間差別", "DV目撃 (面前DV)", "子どもの目の前で家族に暴力"] },
] as const;

export type AbuseType = (typeof ABUSE_TYPES)[number]["id"];

export type ReportSeverity = "info" | "watch" | "intervention" | "emergency";

export interface AbuseReport {
  case_id: string;
  child_age: number;
  reporter: "school" | "medical" | "police" | "neighbor" | "family" | "self" | "anonymous";
  abuse_types: AbuseType[];
  visible_injury: boolean;
  threats_to_life: boolean;
  past_reports_count: number;
  reported_at: string; // ISO 8601
}

export interface AbuseTriageResult {
  severity: ReportSeverity;
  required_actions: string[];
  safety_check_deadline: string; // 「48時間ルール」(厚労省通知) ISO 8601
  applicable_laws: string[];
}

/**
 * 児童相談所のトリアージ (厚労省 児童相談所運営指針)
 *  - 「48時間ルール」: 安全確認は48時間以内に直接目視
 *  - 緊急一時保護 (法33条) は児相所長の判断
 */
export function triageAbuseReport(r: AbuseReport): AbuseTriageResult {
  const reportedAt = new Date(r.reported_at);
  const deadline = new Date(reportedAt.getTime() + 48 * 60 * 60 * 1000);

  let severity: ReportSeverity;
  if (r.threats_to_life || (r.visible_injury && r.child_age <= 6)) {
    severity = "emergency";
  } else if (r.visible_injury || r.abuse_types.includes("sexual") || r.past_reports_count >= 2) {
    severity = "intervention";
  } else if (r.past_reports_count >= 1 || r.abuse_types.includes("psychological")) {
    severity = "watch";
  } else {
    severity = "info";
  }

  const actions: string[] = [];
  switch (severity) {
    case "emergency":
      actions.push("即時 (24時間以内) 安全確認 + 緊急一時保護検討", "警察への援助要請 (法10条)", "医療機関への搬送");
      break;
    case "intervention":
      actions.push("48時間以内に直接目視 + リスクアセスメント実施", "在宅指導 or 一時保護判断", "要対協への情報共有");
      break;
    case "watch":
      actions.push("48時間以内に直接目視", "学校・保育所・医療機関の継続見守り依頼", "要対協 個別ケース検討会議");
      break;
    case "info":
      actions.push("48時間以内の安全確認 (リスク低でも厚労省通知遵守)", "市町村へ送致検討");
      break;
  }

  return {
    severity,
    required_actions: actions,
    safety_check_deadline: deadline.toISOString(),
    applicable_laws: [
      "児童虐待防止法 6条 (通告義務)",
      "児童虐待防止法 8条 (児相の対応)",
      "児童福祉法 33条 (一時保護)",
      "厚労省 児童相談所運営指針 第4章",
    ],
  };
}

// ----------------------------------------------------------------------
// 1b) 保育所等の職員による虐待の通報（令和7年法律第29号・2025-10-01 施行）
//     2026-10-03 T45（REQ-134 / JPO-IND-111）
//     根拠: 児童福祉法（令和7年10月1日施行版・e-Gov 322AC0000000164_20251001_507AC0000000029）
//       第33条の10第1項（施設職員等・4類型）・第2項（所管行政庁）、第33条の12（通告・不利益取扱いの禁止）、
//       第33条の13（通告者を特定させる事項の秘匿）、第33条の14（所管行政庁への通知と事実確認）
//     記録の項目: こども家庭庁「保育所や幼稚園等における虐待防止及び発生時の対応等に関するガイドライン」（令和8年4月改訂）
//       「通報受理の際に確認する事項」（最低限確認すべき情報の例）
// ----------------------------------------------------------------------

export const STAFF_ABUSE_REPORT_LAW = {
  law_title: "児童福祉法",
  law_id: "322AC0000000164",
  amending_act_ja: "児童福祉法等の一部を改正する法律（令和7年法律第29号）",
  effective_from: "2025-10-01",
  basis_ja: "児童福祉法第33条の12（被措置児童等虐待を受けたと思われる児童を発見した者は、速やかに都道府県知事又は市町村長に通告）",
  guideline_ja: "保育所や幼稚園等における虐待防止及び発生時の対応等に関するガイドライン（令和8年4月改訂）",
  source_url: "https://www.cfa.go.jp/policies/hoiku/hoiku-gyakutaiboushi",
} as const;

/** 4類型（第33条の10第1項各号） */
export const STAFF_ABUSE_TYPES = [
  { id: "physical", name: "身体的虐待", article_ja: "第33条の10第1項第1号（身体に外傷が生じ、又は生じるおそれのある暴行）" },
  { id: "sexual", name: "性的虐待", article_ja: "第33条の10第1項第2号（わいせつな行為をすること又はさせること）" },
  { id: "neglect", name: "ネグレクト", article_ja: "第33条の10第1項第3号（著しい減食又は長時間の放置その他業務を著しく怠ること）" },
  { id: "psychological", name: "心理的虐待", article_ja: "第33条の10第1項第4号（著しい暴言又は著しく拒絶的な対応その他の著しい心理的外傷を与える言動）" },
] as const;

/** 通報記録の必須項目（ガイドラインの最低限確認すべき情報＋受付の記録） */
export const STAFF_ABUSE_REPORT_REQUIRED_FIELDS = [
  { key: "receivedAt", label_ja: "受付日時" },
  { key: "facilityName", label_ja: "こどもの在籍する園の情報（施設名等）" },
  { key: "facilityType", label_ja: "施設・事業の種類（所管行政庁の判定に使う）" },
  { key: "childSex", label_ja: "こどもの性別" },
  { key: "childAge", label_ja: "こどもの年齢" },
  { key: "abuseTypes", label_ja: "虐待の類型（第33条の10第1項各号）" },
  { key: "abuseDescription", label_ja: "虐待の具体的な状況（内容）" },
  { key: "abuseWhen", label_ja: "虐待の時期" },
  { key: "facilityResponse", label_ja: "保育所等の対応" },
  { key: "childCondition", label_ja: "こどもの心身の状況" },
  { key: "relationAbuserChild", label_ja: "虐待者とこどもの関係" },
  { key: "reporter", label_ja: "相談者・通報者の情報（氏名・連絡先・関係。匿名の希望に配慮）" },
] as const;

export interface StaffAbuseReportInput {
  receivedAt?: string;
  receivedBy?: string;
  facilityName?: string;
  facilityType?: string;
  childSex?: string;
  childAge?: number;
  abuseTypes?: string[];
  abuseDescription?: string;
  abuseWhen?: string;
  facilityResponse?: string;
  childCondition?: string;
  relationAbuserChild?: string;
  otherRelations?: string;
  reporter?: { anonymous?: boolean; name?: string; contact?: string; relation?: string };
}

/** 通報の受付記録を作る。欠けた必須項目を挙げ、そろうまで complete にしない */
export function createStaffAbuseReport(input: StaffAbuseReportInput) {
  const x: Record<string, unknown> = { ...(input || {}) };
  const missing: string[] = [];
  for (const f of STAFF_ABUSE_REPORT_REQUIRED_FIELDS) {
    const v = x[f.key];
    if (f.key === "reporter") {
      const r = input?.reporter;
      // 匿名の通報も受け付ける（ガイドライン: 匿名でも丁寧に聞く）。匿名でないなら氏名か連絡先が要る
      if (!r || (r.anonymous !== true && !String(r.name || "").trim() && !String(r.contact || "").trim())) missing.push(f.key);
      continue;
    }
    if (f.key === "abuseTypes") {
      const ids = STAFF_ABUSE_TYPES.map((t) => t.id) as readonly string[];
      if (!Array.isArray(v) || v.length === 0 || !(v as string[]).every((t) => ids.includes(t))) missing.push(f.key);
      continue;
    }
    if (f.key === "childAge") {
      if (typeof v !== "number" || !Number.isFinite(v) || v < 0) missing.push(f.key);
      continue;
    }
    if (v === undefined || v === null || String(v).trim() === "") missing.push(f.key);
  }
  const route = input?.facilityType ? routeStaffAbuseReport({ facilityType: input.facilityType }) : null;
  return {
    status: missing.length ? ("incomplete" as const) : ("complete" as const),
    missing_keys: missing,
    missing_ja: missing.map((k) => STAFF_ABUSE_REPORT_REQUIRED_FIELDS.find((f) => f.key === k)?.label_ja || k),
    record: { ...x, reporter: input?.reporter?.anonymous ? { anonymous: true } : input?.reporter },
    route,
    protections_ja: [
      "通報者を特定させる事項は漏らさない（児童福祉法第33条の13）",
      "施設職員等は通告をしたことを理由に解雇その他不利益な取扱いを受けない（児童福祉法第33条の12第6項）",
      "守秘義務の規定は通告を妨げない（虚偽・過失によるものを除く。第33条の12第5項）",
    ],
    law: STAFF_ABUSE_REPORT_LAW,
  };
}

/** 所管行政庁（第33条の10第2項）。区分ごとの号と、本文で確かめていない施設 */
const STAFF_ABUSE_JURISDICTION: Record<string, { who: "都道府県知事" | "市町村長"; item_ja: string }> = {
  ichiji_azukari: { who: "都道府県知事", item_ja: "第1号（一時預かり事業）" },
  byouji: { who: "都道府県知事", item_ja: "第1号（病児保育事業）" },
  houkago_jido: { who: "市町村長", item_ja: "第2号（放課後児童健全育成事業）" },
  katei: { who: "市町村長", item_ja: "第2号（家庭的保育事業等）" },
  shokibo_a: { who: "市町村長", item_ja: "第2号（家庭的保育事業等・小規模保育）" },
  shokibo_b: { who: "市町村長", item_ja: "第2号（家庭的保育事業等・小規模保育）" },
  shokibo_c: { who: "市町村長", item_ja: "第2号（家庭的保育事業等・小規模保育）" },
  kyotaku_houmon: { who: "市町村長", item_ja: "第2号（家庭的保育事業等・居宅訪問型保育）" },
  jigyosho_nai: { who: "市町村長", item_ja: "第2号（家庭的保育事業等・事業所内保育）" },
  daredemo_tsuen: { who: "市町村長", item_ja: "第2号（乳児等通園支援事業）" },
  hoikusho: { who: "都道府県知事", item_ja: "第4号（保育所。設置の認可を行った都道府県知事）" },
  jidokan: { who: "都道府県知事", item_ja: "第4号（児童館）" },
  ninkagai: { who: "都道府県知事", item_ja: "第5号（認可外保育施設。所在地の都道府県知事）" },
};
/** 通報義務の対象だが、所管行政庁の号を児童福祉法の本文で確かめていない施設（学校教育法・認定こども園法の側） */
const STAFF_ABUSE_UNCONFIRMED = ["kindergarten", "kodomoen", "youho_renkei", "tokubetsu_shien_youchibu"];

/** 通報の経路: 通告先（都道府県知事又は市町村長のどちらでもよい）と、事実確認をする所管行政庁 */
export function routeStaffAbuseReport(input: { facilityType: string }) {
  const ft = String(input?.facilityType || "");
  const report_to = ["都道府県知事", "市町村長"];
  const common_ja = [
    "通告は都道府県知事又は市町村長のどちらにしてもよい（第33条の12第1項）。児童委員を介してもよい（同第2項）",
    "通告を受けた側が所管行政庁でなければ、所管行政庁へ速やかに通知する（第33条の14第1項）",
    "指定都市・中核市・児童相談所設置市では都道府県知事の事務を市長が行う場合がある（大都市等の特例。要確認）",
  ];
  const j = STAFF_ABUSE_JURISDICTION[ft];
  if (j) return { status: "ok" as const, covered: true, report_to, jurisdiction: j.who, basis_ja: `児童福祉法第33条の10第2項${j.item_ja}`, notes_ja: common_ja };
  if (STAFF_ABUSE_UNCONFIRMED.includes(ft)) {
    return { status: "unconfirmed" as const, covered: true, report_to, jurisdiction: null, basis_ja: "通報義務の対象施設。所管行政庁の号は学校教育法・認定こども園法側で本文を確かめていない（確認できていない）", notes_ja: common_ja };
  }
  return { status: "not_covered" as const, covered: false, report_to: [], jurisdiction: null, basis_ja: "保育所等の職員による虐待の通報義務の対象施設・事業に含まれない（児童虐待防止法第6条の通告は別）", notes_ja: [] };
}

// ----------------------------------------------------------------------
// 2) 一時保護開始時の司法審査 (R6.4.1 施行 — 児童福祉法33条改正)
// ----------------------------------------------------------------------

/**
 * 「一時保護開始時の司法審査」の導入
 *  - 親権者の同意がない一時保護 → 7日以内に家庭裁判所に「一時保護状」を請求
 *  - 司法判断による正当性確認 (国際基準への整合)
 */
export interface TemporaryShelterRequest {
  case_id: string;
  child_name_hash: string; // PII保護のためハッシュ化
  parental_consent: boolean;
  shelter_started_at: string; // ISO 8601
  reason: string;
}

export interface ShelterReviewSchedule {
  judicial_review_required: boolean;
  petition_deadline: string; // ISO 8601 (7日以内)
  estimated_court_decision: string; // 通常1週間以内
}

export function planShelterJudicialReview(req: TemporaryShelterRequest): ShelterReviewSchedule {
  if (req.parental_consent) {
    return {
      judicial_review_required: false,
      petition_deadline: "",
      estimated_court_decision: "",
    };
  }
  const start = new Date(req.shelter_started_at);
  const deadline = new Date(start.getTime() + 7 * 24 * 60 * 60 * 1000);
  const courtDecision = new Date(start.getTime() + 14 * 24 * 60 * 60 * 1000);
  return {
    judicial_review_required: true,
    petition_deadline: deadline.toISOString().slice(0, 10),
    estimated_court_decision: courtDecision.toISOString().slice(0, 10),
  };
}

// ----------------------------------------------------------------------
// 3) 日本版DBS (こども性暴力防止法・令和6年法律第69号 2024-06-26 公布 — 2026-12-25 施行)
//    判定はしない。「確認の状態の記録」と期限の計算（再確認の周期・経過措置・猶予・記録の廃棄）だけを行う。
// ----------------------------------------------------------------------

/**
 * 仕組み（一次資料: e-Gov 法令API v2 506AC0000000069_20261225 / 施行令 507CO0000000440・2026-09-30 取得）
 *  - 確認は国が行う。事業者は申請し、犯罪事実確認書を受け取るだけ（法33〜35条）。
 *    確認書の記載は「特定性犯罪事実該当者と認められない」か「認められる（区分・裁判確定日）」の2つ（法35条4項）。
 *  - 従事させるかどうかは、事業者が確認書の結果・把握した状況・相談の内容などを踏まえて判断し、
 *    必要な措置を講じる（学校設置者等は法6条、認定事業者等は児童対象性暴力等対処規程の防止措置・法20条1項4号イ）。
 *    システムが自動で採否を決める仕組みではない。
 *  - 特定性犯罪（法2条7項）: 刑法176条・177条・179〜182条・241条1項/3項・243条（241条1項の罪に係る部分）、
 *    盗犯等防止法4条（刑法241条1項の罪を犯す行為に係るもの）、児童福祉法60条1項、
 *    児童買春・児童ポルノ禁止法4〜8条、性的姿態撮影等処罰法2〜6条、施行令2条に列挙された都道府県条例の罪。
 *  - 該当者の期間（法2条8項）: 実刑の拘禁刑は刑の執行を終わった日等から20年／執行猶予は裁判確定日から10年／
 *    罰金は刑の執行を終わった日等から10年。★この期間の当てはめは国が行う。本部品は計算しない。
 *  - オーナー決定 X1: 犯罪歴の内容（罪名・区分・確定日・判決）は保存しない。渡されても記録に入れない。
 *    記録（犯罪事実確認記録）は管理・目的外利用の禁止・廃棄（法38条）の対象。管理と目的外利用の条は次の項目のとおり。
 *  - 記録の管理の条は、義務を負う側で書き分ける（2026-12-25 施行の版で確かめた）。
 *    学校設置者等（法2条3項）: 管理措置＝法11条／目的外利用・第三者提供の禁止＝法12条／漏えい等の報告＝法13条。
 *    認定事業者等（法2条5項の民間教育保育等事業者で認定を受けた者・法22条1号）: 法11〜13条は直接には掛からない。
 *      適正な管理＝法27条1項／管理の措置（管理責任者の設置など）＝認定の基準 法20条1項6号・施行規則12条1項／
 *      目的外利用・第三者提供の禁止＝法27条2項で準用する法12条／漏えい等の報告＝同項で準用する法13条。
 *    廃棄（法38条）はどちらにも掛かる（犯罪事実確認書受領者等）。
 *
 * ★要確認（士業・こども家庭庁「準備ガイド」）:
 *  - 急な欠員の猶予（法4条2項・26条2項「従事させた日から」）は「起算して」の語が無い。
 *    民法140条（初日不算入）で読むと期限は1日遅くなる。本部品は安全側（初日を含める＝1日早い期限）を既定にしている。
 */

/** 値表（出典つき）。本節の値はここだけから読む。 */
export const DBS_LAW = {
  law_title: "学校設置者等及び民間教育保育等事業者による児童対象性暴力等の防止等のための措置に関する法律",
  law_number: "令和6年法律第69号",
  law_id: "506AC0000000069",
  promulgated_on: "2024-06-26", // e-Gov 法令API law_info.promulgation_date（6/19 は成立日）
  effective_on: "2026-12-25", // 施行令（令和7年政令第440号）附則1項
  enforcement_date_order: "令和7年政令第439号", // 施行期日を定める政令（こども家庭庁のページで確認）
  enforcement_order: "令和7年政令第440号",
  recheck_years: 5, // 法4条4項・26条6項（確認日の翌日から起算して5年を経過する日の属する年度）
  incumbent_years_school: 3, // 法4条3項・施行令4条（施行時現職者）
  incumbent_years_certified: 1, // 法26条3項・施行令6条（認定時現職者）
  urgent_grace_months: 3, // 法4条2項・26条2項・施行令3条・5条（急な欠員）
  urgent_grace_months_disaster: 6, // 同（大規模な災害その他内閣府令で定める場合）
  record_retention_years: 5, // 法38条1項
  disposal_days: 30, // 法38条1〜3項
  private_education_min_instructors: 3, // 法2条5項3号ニ・施行令1条
  private_education_min_course_months: 6, // 法2条5項3号イ
  fee_jpy: 31_500, // 施行令7条（書面申請）
  fee_online_jpy: 30_000, // 施行令7条（電子申請）
} as const;

export type DbsCheckStatus = "unconfirmed" | "applied" | "certificate_received" | "provisional_deemed";

export const DBS_STATUS_LABEL_JA: Record<DbsCheckStatus, string> = {
  unconfirmed: "確認できていない",
  applied: "申請中（確認できていない）",
  certificate_received: "確認書受領",
  provisional_deemed: "猶予中（確認できていない・特定性犯罪事実該当者とみなして措置）",
};

/** 確認書の区分（法35条4項）。区分の中身（2条8項の何号か）と裁判確定日は持たない（X1）。 */
export type DbsCertificateOutcome = "not_recognized" | "recognized";

export interface DbsRecordInput {
  person_ref?: string; // 氏名は持たない。社内の従業者ID・ハッシュなど
  status?: string;
  confirmation_date?: string; // 犯罪事実確認書に記載された確認日（法34条2項）YYYY-MM-DD
  certificate_outcome?: string;
  confirmed_by?: string; // 確認書を受け取り記録した担当者（記録の管理責任者・法11条／認定事業者等は法20条1項6号・施行規則12条1項）
  provisional_since?: string; // 急な欠員で確認前に従事させた日（法4条2項・26条2項）
  disaster?: boolean; // 大規模な災害等（猶予6月）
  [k: string]: unknown;
}

export interface DbsStatusRecord {
  person_ref: string | null;
  status: DbsCheckStatus;
  status_label_ja: string;
  confirmation_date: string | null;
  confirmed_by: string | null;
  needs_business_judgment: boolean; // 確認書が「認められる」→ 事業者が法6条の措置を判断する
  recheck_fiscal_year: { start: string; end: string } | null;
  disposal_deadline: string | null;
  provisional_deadline: string | null;
  stores_criminal_details: false;
  decision_owner_ja: string;
  notes_ja: string[];
}

// ---- 日付の計算（民法143条: 起算日を含めて数え、応当日の前日が満了日。応当日が無い月は月末） ----
const DBS_YMD = /^(\d{4})-(\d{2})-(\d{2})$/;
function dbsDaysInMonth(y: number, m: number): number {
  return new Date(Date.UTC(y, m, 0)).getUTCDate();
}
function dbsParse(s: unknown): { y: number; m: number; d: number } | null {
  const mm = typeof s === "string" ? DBS_YMD.exec(s) : null;
  if (!mm) return null;
  const y = Number(mm[1]), m = Number(mm[2]), d = Number(mm[3]);
  if (m < 1 || m > 12 || d < 1 || d > dbsDaysInMonth(y, m)) return null;
  return { y, m, d };
}
function dbsFmt(y: number, m: number, d: number): string {
  return `${String(y).padStart(4, "0")}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}
function dbsAddDays(s: string, n: number): string {
  const p = dbsParse(s);
  if (!p) throw new Error(`日付の形式が正しくありません: ${String(s)}`);
  const t = new Date(Date.UTC(p.y, p.m - 1, p.d + n));
  return dbsFmt(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate());
}
/** 起算日 start から months か月の期間の満了日（＝「起算して〜を経過する日」） */
export function dbsPeriodEnd(start: string, months: number): string {
  const p = dbsParse(start);
  if (!p) throw new Error(`日付の形式が正しくありません: ${String(start)}`);
  const idx = p.m - 1 + months;
  const ty = p.y + Math.floor(idx / 12);
  const tm = (idx % 12) + 1;
  const dim = dbsDaysInMonth(ty, tm);
  if (p.d > dim) return dbsFmt(ty, tm, dim); // 応当日が無い → その月の末日（民法143条2項ただし書）
  return dbsAddDays(dbsFmt(ty, tm, p.d), -1); // 応当日の前日
}
/** その日が属する年度（4月1日〜翌3月31日） */
function dbsFiscalYearOf(s: string): { start: string; end: string } {
  const p = dbsParse(s);
  if (!p) throw new Error(`日付の形式が正しくありません: ${String(s)}`);
  const fy = p.m >= 4 ? p.y : p.y - 1;
  return { start: dbsFmt(fy, 4, 1), end: dbsFmt(fy + 1, 3, 31) };
}

/** 再確認を行う年度（法4条4項・26条6項）: 確認日の翌日から起算して5年を経過する日の属する年度 */
export function dbsRecheckFiscalYear(confirmationDate: string): { start: string; end: string; period_end: string } {
  const periodEnd = dbsPeriodEnd(dbsAddDays(confirmationDate, 1), DBS_LAW.recheck_years * 12);
  return { ...dbsFiscalYearOf(periodEnd), period_end: periodEnd };
}

export type DbsDisposalInput =
  | { kind: "retention"; confirmation_date: string } // 法38条1項
  | { kind: "left"; base_date: string } // 法38条2項1号（離職の日）
  | { kind: "not_hired"; planned_start_date: string; issued_date: string } // 法38条2項2号
  | { kind: "ceased_business"; base_date: string }; // 法38条3項

/** 犯罪事実確認記録等を廃棄・消去する期限（法38条）。罰則: 法46条3号 */
export function dbsDisposalDeadline(input: DbsDisposalInput): { deadline: string; basis_ja: string } {
  const days = DBS_LAW.disposal_days - 1; // 「起算して30日を経過する日」＝起算日+29日
  switch (input.kind) {
    case "retention": {
      // 確認日から起算して5年を経過した日（＝満了日の翌日）の属する年度の末日から起算して30日を経過する日
      const passed = dbsAddDays(dbsPeriodEnd(input.confirmation_date, DBS_LAW.record_retention_years * 12), 1);
      const fyEnd = dbsFiscalYearOf(passed).end;
      return { deadline: dbsAddDays(fyEnd, days), basis_ja: "法38条1項（確認日から5年を経過した日の属する年度の末日から30日以内）" };
    }
    case "left":
      return { deadline: dbsAddDays(input.base_date, days), basis_ja: "法38条2項1号（離職の日から30日以内）" };
    case "not_hired": {
      if (!dbsParse(input.planned_start_date) || !dbsParse(input.issued_date)) throw new Error("従事予定日と交付日が必要です");
      const base = input.issued_date > input.planned_start_date ? input.issued_date : input.planned_start_date;
      return { deadline: dbsAddDays(base, days), basis_ja: "法38条2項2号（従事予定日か交付日の遅いほうから30日以内）" };
    }
    case "ceased_business":
      return { deadline: dbsAddDays(input.base_date, days), basis_ja: "法38条3項（対象の事業者でなくなった日から30日以内）" };
    default:
      throw new Error("廃棄の期限の種類が正しくありません");
  }
}

export interface DbsTransitionInput {
  kind: "incumbent_school" | "incumbent_certified" | "urgent_vacancy";
  base_date?: string; // incumbent_certified: 認定等の日 / urgent_vacancy: 従事させた日
  disaster?: boolean;
}

/** 経過措置・猶予の期限（法4条2〜3項・26条2〜3項・施行令3〜6条） */
export function dbsTransitionDeadline(input: DbsTransitionInput): { deadline: string | null; basis_ja: string; notes_ja: string[] } {
  if (input.kind === "incumbent_school") {
    return {
      deadline: dbsPeriodEnd(DBS_LAW.effective_on, DBS_LAW.incumbent_years_school * 12),
      basis_ja: "法4条3項・施行令4条（施行時現職者は施行日から起算して3年を経過する日まで）",
      notes_ja: [],
    };
  }
  if (!dbsParse(input.base_date)) {
    return { deadline: null, basis_ja: "基準日が無いため期限を計算できません", notes_ja: ["確認できていない"] };
  }
  if (input.kind === "incumbent_certified") {
    return {
      deadline: dbsPeriodEnd(input.base_date as string, DBS_LAW.incumbent_years_certified * 12),
      basis_ja: "法26条3項・施行令6条（認定時現職者は認定等の日から起算して1年を経過する日まで）",
      notes_ja: [],
    };
  }
  const months = input.disaster ? DBS_LAW.urgent_grace_months_disaster : DBS_LAW.urgent_grace_months;
  return {
    deadline: dbsPeriodEnd(input.base_date as string, months),
    basis_ja: `法4条2項・26条2項・施行令3条・5条（従事させた日から${months}月以内）`,
    notes_ja: [
      "確認が済むまでは、その者を特定性犯罪事実該当者とみなして必要な措置を講じる（法4条2項ただし書）",
      "要確認: 初日を含めて数えた安全側の期限です。民法140条（初日不算入）で読むと1日遅くなります",
    ],
  };
}

/** 判定日 asOf が期限内か（期限日の当日までは期限内） */
export function dbsDeadlineStatus(deadline: string, asOf: string): "within" | "overdue" {
  if (!dbsParse(deadline) || !dbsParse(asOf)) throw new Error("日付の形式が正しくありません");
  return asOf <= deadline ? "within" : "overdue";
}

const DBS_CRIME_DETAIL_KEY = /crime|offen[cs]e|conviction|sentenc|verdict|罪|判決|確定日|区分/i;
const DBS_STATUSES: DbsCheckStatus[] = ["unconfirmed", "applied", "certificate_received", "provisional_deemed"];

/**
 * 確認の状態の記録を作る。既定は「確認できていない」。
 * 採否は返さない（法6条: 事業者が判断する）。犯罪歴の内容は記録に入れない（X1）。
 */
export function recordDbsStatus(input: DbsRecordInput = {}): DbsStatusRecord {
  const notes: string[] = [];
  const dropped = Object.keys(input || {}).filter((k) => DBS_CRIME_DETAIL_KEY.test(k));
  if (dropped.length) notes.push("犯罪歴の内容（罪名・区分・確定日・判決）は保存しません（オーナー決定 X1）");

  let status: DbsCheckStatus = DBS_STATUSES.includes(input.status as DbsCheckStatus) ? (input.status as DbsCheckStatus) : "unconfirmed";
  if (input.status !== undefined && status !== input.status) notes.push("状態の値が正しくないため「確認できていない」として記録します");

  const confDate = dbsParse(input.confirmation_date) ? (input.confirmation_date as string) : null;
  const outcome: DbsCertificateOutcome | null =
    input.certificate_outcome === "not_recognized" || input.certificate_outcome === "recognized" ? input.certificate_outcome : null;
  if (status === "certificate_received" && (!confDate || !outcome)) {
    status = "unconfirmed";
    notes.push("確認書の確認日または区分が無いため「確認できていない」として記録します");
  }
  const provisionalSince = dbsParse(input.provisional_since) ? (input.provisional_since as string) : null;
  if (status === "provisional_deemed" && !provisionalSince) {
    status = "unconfirmed";
    notes.push("従事させた日が無いため「確認できていない」として記録します");
  }

  const received = status === "certificate_received";
  return {
    person_ref: typeof input.person_ref === "string" ? input.person_ref : null,
    status,
    status_label_ja: DBS_STATUS_LABEL_JA[status],
    confirmation_date: received ? confDate : null,
    confirmed_by: received && typeof input.confirmed_by === "string" ? input.confirmed_by : null,
    needs_business_judgment: received && outcome === "recognized",
    recheck_fiscal_year: received && confDate ? (({ start, end }) => ({ start, end }))(dbsRecheckFiscalYear(confDate)) : null,
    disposal_deadline: received && confDate ? dbsDisposalDeadline({ kind: "retention", confirmation_date: confDate }).deadline : null,
    provisional_deadline:
      status === "provisional_deemed"
        ? dbsTransitionDeadline({ kind: "urgent_vacancy", base_date: provisionalSince as string, disaster: !!input.disaster }).deadline
        : null,
    stores_criminal_details: false,
    decision_owner_ja:
      "業務に就かせるかどうかは、事業者が確認書の結果・把握した状況・相談の内容などを踏まえて判断します（学校設置者等は法6条、認定事業者等は児童対象性暴力等対処規程の防止措置・法20条1項4号イ）。本システムは判定しません。",
    notes_ja: notes,
  };
}

export type DbsSector = "mandatory" | "certification_eligible" | "not_covered" | "unknown";

/** 学校設置者等（義務・法2条3項）の施設・事業 */
const DBS_MANDATORY_KINDS: Record<string, string> = {
  elementary_school: "2条3項1号イ（学校・大学を除く）",
  junior_high_school: "2条3項1号イ（学校・大学を除く）",
  high_school: "2条3項1号イ（学校・大学を除く）",
  special_needs_school: "2条3項1号イ（学校・大学を除く）",
  kindergarten: "2条3項1号イ（学校・大学を除く）",
  technical_college: "2条3項1号イ（学校・大学を除く）",
  senshu_upper_secondary: "2条3項1号ロ（専修学校の高等課程）",
  kodomoen_integrated: "2条3項1号ハ（幼保連携型認定こども園）",
  kodomoen_other: "2条3項1号ニ（その他の認定こども園）",
  child_guidance_center: "2条3項1号ホ（児童相談所）",
  designated_disabled_child_facility: "2条3項1号ヘ（指定障害児入所施設等）",
  infant_home: "2条3項1号ト（乳児院）",
  mother_child_support_facility: "2条3項1号チ（母子生活支援施設）",
  nursery: "2条3項1号リ（保育所）",
  jidoukan: "2条3項1号ヌ（児童館）",
  children_home: "2条3項1号ル（児童養護施設）",
  disabled_child_facility: "2条3項1号ヲ（障害児入所施設）",
  child_psychological_facility: "2条3項1号ワ（児童心理治療施設）",
  child_independence_facility: "2条3項1号カ（児童自立支援施設）",
  designated_child_development_support: "2条3項2号イ（指定障害児通所支援事業）",
  infant_commuting_support: "2条3項2号ロ（乳児等通園支援事業）",
  family_daycare: "2条3項2号ハ（家庭的保育事業等）",
  registered_temporary_custody: "2条3項3号（登録一時保護委託者）",
};
/** 民間教育保育等事業者（任意の認定・法2条5項）の事業（民間教育事業を除く） */
const DBS_CERTIFICATION_KINDS: Record<string, string> = {
  senshu_general_or_misc_school: "2条5項1号（専修学校の一般課程・各種学校で児童等を専ら対象とするもの）",
  child_development_support_undesignated: "2条5項4号（児童発達支援事業・指定を受けないもの）",
  after_school_day_service_undesignated: "2条5項5号（放課後等デイサービス事業・指定を受けないもの）",
  child_self_reliance_support: "2条5項8号（児童自立生活援助事業）",
  after_school_club: "2条5項9号（放課後児童健全育成事業等）",
  short_stay_support: "2条5項10号（子育て短期支援事業）",
  temporary_childcare: "2条5項11号（一時預かり事業）",
  foster_home_small: "2条5項12号（小規模住居型児童養育事業）",
  sick_child_care: "2条5項13号（病児保育事業）",
  unlicensed_childcare: "2条5項17号（認可外保育事業）",
};

export interface DbsSectorInput {
  kind: string;
  // 民間教育事業（学習塾・スポーツ・音楽・語学など。法2条5項3号）の4要件
  course_months?: number; // 標準的な修業期間（イ: 6月以上）
  face_to_face?: boolean; // 対面による指導（ロ）
  at_provider_premises?: boolean; // 事業者が用意する場所で指導（ハ）
  instructors?: number; // 教える人の人数（ニ: 施行令1条で3人以上）
}

/** 義務（学校設置者等）・認定の対象（民間教育保育等事業者）・対象外の区分。分からないときは unknown */
export function classifyDbsSector(input: DbsSectorInput): { sector: DbsSector; basis_ja: string; missing_ja: string[] } {
  const k = String(input?.kind || "");
  if (k === "university") return { sector: "not_covered", basis_ja: "2条3項1号イ（大学は除かれる）", missing_ja: [] };
  if (DBS_MANDATORY_KINDS[k]) return { sector: "mandatory", basis_ja: `義務（学校設置者等）: 法${DBS_MANDATORY_KINDS[k]}`, missing_ja: [] };
  if (DBS_CERTIFICATION_KINDS[k]) return { sector: "certification_eligible", basis_ja: `認定の対象（任意）: 法${DBS_CERTIFICATION_KINDS[k]}`, missing_ja: [] };
  if (k === "private_education") {
    const missing: string[] = [];
    if (typeof input.course_months !== "number") missing.push("標準的な修業期間（月数）");
    if (typeof input.face_to_face !== "boolean") missing.push("対面による指導か");
    if (typeof input.at_provider_premises !== "boolean") missing.push("事業者が用意する場所での指導か");
    if (typeof input.instructors !== "number") missing.push("教える人の人数");
    if (missing.length) return { sector: "unknown", basis_ja: "法2条5項3号の要件を判断する情報が足りません（確認できていない）", missing_ja: missing };
    const ok =
      (input.course_months as number) >= DBS_LAW.private_education_min_course_months &&
      input.face_to_face === true &&
      input.at_provider_premises === true &&
      (input.instructors as number) >= DBS_LAW.private_education_min_instructors;
    return ok
      ? { sector: "certification_eligible", basis_ja: "認定の対象（任意）: 法2条5項3号（民間教育事業の4要件を満たす）", missing_ja: [] }
      : { sector: "not_covered", basis_ja: "法2条5項3号の要件（修業6月以上・対面・事業者が用意する場所・教える人3人以上）を満たさない", missing_ja: [] };
  }
  return { sector: "unknown", basis_ja: "区分を判断できません（要確認）", missing_ja: ["施設・事業の種類"] };
}

/**
 * 確認記録を見てよい立場（管理の措置: 学校設置者等は法11条、認定事業者等は法20条1項6号・27条1項）。要件 REQ-JPO-LAW-021「確認の記録の閲覧は人事責任者だけ」に合わせ、
 * 人事責任者だけにする（2026-10-03 T45。I7 の版は記録管理責任者も見られた）。記録管理責任者が記録を付ける
 * （recordDbsStatus の confirmed_by）ことは妨げないが、記録を一覧・閲覧する口は人事責任者に限る。
 */
export const DBS_VIEWER_ROLES = ["hr_manager"] as const;

/**
 * 犯罪事実確認記録等を使ってよい目的（法12条: 目的外利用の禁止。認定事業者等は法27条2項で準用する法12条）。
 *   employment_measures … 業務に就かせるかの判断と防止措置（法6条・対処規程の措置・法20条1項4号イ）
 *   record_management   … 記録の保存・廃棄（法38条）と管理（学校設置者等は法11条、認定事業者等は法27条1項）
 *   regulator_response  … 内閣総理大臣（こども家庭庁）からの報告徴収・検査への対応
 * これ以外（人事評価・配置の参考・採用の広告・研修の題材など）は目的外として拒否し、監査ログに残す。
 */
export const DBS_ALLOWED_PURPOSES = ["employment_measures", "record_management", "regulator_response"] as const;

export interface DbsAccessEntry {
  seq: number;
  at: string;
  actor: string;
  role: string;
  purpose: string;
  recordId: string;
  allowed: boolean;
  out_of_purpose: boolean;
  reason_ja: string;
}

/**
 * 目的外利用で拒否したときに示す条。義務を負う側で条が異なる（2026-12-25 施行の版で確かめた）。
 *   学校設置者等（classifyDbsSector の mandatory）: 法12条
 *   認定事業者等（certification_eligible の事業者が認定を受けた場合）: 法27条2項で準用する法12条
 *   区分を渡されないとき: 両方を示す（どちらの事業者が使っても条を取り違えない）
 */
const DBS_OUT_OF_PURPOSE_ARTICLE_JA = {
  mandatory: "法12条",
  certification_eligible: "法27条2項で準用する法12条",
  unspecified: "法12条。認定事業者等は法27条2項で準用する法12条",
} as const;

/**
 * 目的外利用の監査ログ（REQ-JPO-LAW-021・NFR-034）。閲覧の許可も拒否もすべて連番つきで残す。
 * 取り出した記録は写しで、書き換えてもログは変わらない。犯罪歴の内容（罪名など）の欄は持たない（X1）。
 * options.sector に classifyDbsSector の区分（mandatory / certification_eligible）を渡すと、拒否の理由に示す条を
 * その側の条にする。渡さないときは両方の条を示す。
 */
export function createDbsAccessLog(options: { sector?: DbsSector | string } = {}) {
  const sector = String(options?.sector || "");
  const outOfPurposeArticle =
    sector === "mandatory"
      ? DBS_OUT_OF_PURPOSE_ARTICLE_JA.mandatory
      : sector === "certification_eligible"
        ? DBS_OUT_OF_PURPOSE_ARTICLE_JA.certification_eligible
        : DBS_OUT_OF_PURPOSE_ARTICLE_JA.unspecified;
  const entries: DbsAccessEntry[] = [];
  return {
    record(input: { role: string; actor: string; purpose: string; recordId: string; at?: string }): DbsAccessEntry {
      const role = String(input?.role || "");
      const purpose = String(input?.purpose || "");
      const roleOk = (DBS_VIEWER_ROLES as readonly string[]).includes(role);
      const purposeGiven = purpose.trim().length > 0;
      const purposeOk = (DBS_ALLOWED_PURPOSES as readonly string[]).includes(purpose);
      const outOfPurpose = purposeGiven && !purposeOk;
      const allowed = roleOk && purposeOk;
      const reason_ja = !roleOk
        ? "人事責任者でないため閲覧できません"
        : !purposeGiven
          ? "閲覧の目的が書かれていません（目的の明示が要ります）"
          : outOfPurpose
            ? `目的外利用の試み（${outOfPurposeArticle}）として拒否しました`
            : "許可（法の目的の範囲内）";
      const e: DbsAccessEntry = Object.freeze({
        seq: entries.length + 1, at: String(input?.at || new Date().toISOString()), actor: String(input?.actor || ""), role, purpose,
        recordId: String(input?.recordId || ""), allowed, out_of_purpose: outOfPurpose, reason_ja,
      }) as DbsAccessEntry;
      entries.push(e);
      return { ...e };
    },
    entries(): DbsAccessEntry[] {
      return entries.map((e) => ({ ...e }));
    },
  };
}

/** 確認記録の閲覧可否と、監査の記録（拒否した試みも残す）。REQ-JPO-NFR-034 */
export function canViewDbsRecord(role: string, actor: string, at: string = new Date().toISOString()) {
  const allowed = (DBS_VIEWER_ROLES as readonly string[]).includes(role);
  return {
    allowed,
    audit: { at, actor, role, action: "view_dbs_record", allowed },
  };
}

// ----------------------------------------------------------------------
// 4) こども家庭センター (R6.4.1 施行 — 児童福祉法10条の2)
// ----------------------------------------------------------------------

/**
 * 全市区町村 設置努力義務
 *  - 母子保健 (旧子育て世代包括支援センター) と
 *  - 児童福祉 (旧子ども家庭総合支援拠点) を一体化
 */
export interface KateiCenterRequirements {
  area_population: number; // 自治体人口
  staff_required_count: number; // 統括支援員 + 母子保健担当 + 子ども家庭支援員
  estimated_setup_cost_jpy: number;
  required_functions: string[];
}

export function calcKateiCenterRequirements(populationCount: number): KateiCenterRequirements {
  // 厚労省 配置基準 (児童福祉法10条の2 厚労省告示)
  const staffPer10k = 0.6;
  const baseStaff = 4; // 統括支援員1 + 母子保健2 + 子家支援1
  const required = Math.max(baseStaff, Math.ceil((populationCount / 10000) * staffPer10k));
  return {
    area_population: populationCount,
    staff_required_count: required,
    estimated_setup_cost_jpy: 30_000_000 + required * 6_000_000, // 概算 (運営費 1人あたり600万/年 + 初期設置3000万)
    required_functions: [
      "妊産婦・子育て家庭・こどもの相談支援",
      "支援を要するこども・家庭の包括的支援 (サポートプラン作成)",
      "在宅指導措置 (児相からの委託)",
      "ヤングケアラー支援",
      "母子保健事業 (乳幼児健診・新生児訪問)",
      "要保護児童対策地域協議会 (要対協) 調整機関",
    ],
  };
}

// ----------------------------------------------------------------------
// 5) こども基本法 6つの基本理念 (法3条) — 施策設計チェック
// ----------------------------------------------------------------------

export const KIHON_PRINCIPLES = [
  "全てのこどもについて、個人として尊重され、その基本的人権が保障されること",
  "差別的取扱いを受けることがないこと",
  "適切に養育されること、生活を保障されること、愛され保護されること、その健やかな成長及び発達並びに自立が図られること等の福祉に係る権利が等しく保障されること",
  "意見の尊重 + 最善の利益が優先して考慮されること",
  "家庭で養育されること等が原則 — 家庭養育が困難な場合は家庭に近い環境",
  "こどもの養育は家庭を基本としつつ、家庭での養育が困難なこどもにも家庭と同様の養育環境",
] as const;

export interface PolicyAlignmentCheck {
  policy_name: string;
  has_child_voice_mechanism: boolean; // 意見表明機会
  age_groups_targeted: string[];
  budget_allocation_jpy: number;
  evaluates_against_principles: boolean;
}

export interface PolicyAlignmentResult {
  alignment_score: number; // 0-100
  missing_principles: string[];
  recommendations: string[];
}

export function checkPolicyAlignment(p: PolicyAlignmentCheck): PolicyAlignmentResult {
  const missing: string[] = [];
  const recs: string[] = [];

  if (!p.has_child_voice_mechanism) {
    missing.push("こども基本法11条 意見表明機会の確保");
    recs.push("こどもアンケート / こども会議 / こどもパブコメ等の手段");
  }
  if (p.age_groups_targeted.length < 3) {
    missing.push("ライフステージ別施策 (乳幼児・学齢期・思春期・若者) の網羅");
    recs.push("若者 (18-29歳) を含むライフステージ全段階のサービス設計");
  }
  if (!p.evaluates_against_principles) {
    missing.push("法3条 6基本理念に基づく事前評価");
    recs.push("こども政策評価 (CDIA: Child Development Impact Assessment)");
  }
  const score = Math.max(0, 100 - missing.length * 25);
  return { alignment_score: score, missing_principles: missing, recommendations: recs };
}

// ----------------------------------------------------------------------
// 6) ヤングケアラー支援 (R6.4 改正児童福祉法)
// ----------------------------------------------------------------------

/**
 * R6.4 改正で「家族の世話を日常的に行っているこども」を法律上明記
 *  - 自治体 学校 + 福祉部門の連携
 *  - 支援対象: 約4-6%の中高生 (厚労省 R3 全国調査)
 */
export interface YoungCarerScreening {
  age: number;
  daily_care_hours: number;
  school_attendance_pct: number; // 0-100
  has_homework_difficulty: boolean;
  has_health_issues: boolean;
  family_situation: "single_parent" | "ill_family_member" | "elderly_family" | "disabled_sibling" | "other";
}

export type YoungCarerRisk = "low" | "moderate" | "high" | "severe";

export interface YoungCarerSupportPlan {
  risk: YoungCarerRisk;
  recommended_services: string[];
  needs_immediate_intervention: boolean;
}

export function planYoungCarerSupport(s: YoungCarerScreening): YoungCarerSupportPlan {
  let risk: YoungCarerRisk = "low";
  if (s.daily_care_hours >= 7 || s.school_attendance_pct < 70) risk = "severe";
  else if (s.daily_care_hours >= 4 || s.school_attendance_pct < 85 || s.has_health_issues) risk = "high";
  else if (s.daily_care_hours >= 2 || s.has_homework_difficulty) risk = "moderate";

  const services: string[] = [];
  if (risk === "severe" || risk === "high") {
    services.push(
      "ヤングケアラー・コーディネーター 介入",
      "家事支援サービス (有償ボランティア / 家事支援員派遣 厚労省事業)",
      "学習支援 (スクールソーシャルワーカー)",
      "健康診断 + メンタルヘルス支援",
    );
  }
  if (risk === "moderate") {
    services.push("学校との連携 + 担任への情報共有", "オンライン相談 (LINE 厚労省事業)");
  }
  services.push("当事者同士の交流 (ピアサポート)");

  return {
    risk,
    recommended_services: services,
    needs_immediate_intervention: risk === "severe",
  };
}
