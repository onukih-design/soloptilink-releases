/**
 * lib/japan/beauty.ts — 美容/理容/ネイル/エステDNA
 *
 * 法令カバレッジ:
 *  - 美容師法 (S32法律163) 美容師資格 / 美容所開設届
 *  - 理容師法 (S22法律234) 理容師資格 / 理容所開設届
 *  - 美容師法施行規則 / 理容師法施行規則 (構造設備基準)
 *  - 環境衛生関係営業の運営の適正化に関する法律 (S32法律164)
 *  - 公衆衛生 (細菌検査・消毒・換気)
 *  - 特定商取引法 (エステ等の継続的役務提供)
 *  - 景表法 / 薬機法 (広告規制)
 *  - 化粧品基準 (薬機法施行規則)
 *
 * 参考: 厚生労働省生活衛生課, 全美連 (全国理容生活衛生同業組合連合会), 全衛連
 */

// 特定継続的役務の期間・金額・上限・関連商品は版つき台帳 tokutei_keizoku.ts が正本 (REQ-JPO-IND-011)。ここでは値を持たずに読む
import { TOKUTEI_KEIZOKU_LEDGER, type DesignatedContinuousService as LedgerDesignatedContinuousService } from './tokutei_keizoku.ts';

// ============================================================================
// 1. 業態区分
// ============================================================================

export type SalonKind =
  | 'beauty_salon' // 美容所 (美容師法)
  | 'barber_shop' // 理容所 (理容師法)
  | 'nail_salon' // ネイルサロン (理美容資格不要 — 一部刃物使用は除外)
  | 'esthetic_salon' // エステサロン (法定資格なし)
  | 'eyelash_salon' // まつ毛エクステ (美容師資格必須 — H20通達)
  | 'reflexology'; // リフレクソロジー (資格不要)

export const SALON_LICENSING = {
  beauty_salon: { law: '美容師法', requiresLicense: true, opening: '美容所開設届+検査' },
  barber_shop: { law: '理容師法', requiresLicense: true, opening: '理容所開設届+検査' },
  nail_salon: { law: 'なし (景表法・特商法のみ)', requiresLicense: false, opening: '届出不要' },
  esthetic_salon: { law: '特商法 (継続的役務)', requiresLicense: false, opening: '届出不要' },
  eyelash_salon: { law: '美容師法 (H20通達)', requiresLicense: true, opening: '美容所開設届+検査' },
  reflexology: { law: 'なし', requiresLicense: false, opening: '届出不要' },
} as const;

// ============================================================================
// 2. 美容所/理容所 開設要件 (構造設備基準)
// ============================================================================

export interface SalonOpeningApplication {
  kind: 'beauty_salon' | 'barber_shop' | 'eyelash_salon';
  hasOpeningNotice: boolean; // 開設届 (使用前検査)
  qualifiedStaffCount: number; // 美容師/理容師の人数
  workSpaceM2: number; // 作業面積
  hasSeparateWaitingArea: boolean; // 待合所と作業所の区分
  hasRunningWaterPerSeat: boolean; // 各作業所に給水・給湯設備
  hasUvSterilizer: boolean; // 紫外線消毒器
  hasBoilingSterilizer: boolean; // 煮沸消毒器
  toiletDistanceM: number; // 便所からの距離
}

/** 美容師法/理容師法施行規則 の構造設備基準 */
export function evaluateSalonOpening(a: SalonOpeningApplication): {
  approvable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (!a.hasOpeningNotice) blockers.push('開設届+使用前検査が必要 (美容師法/理容師法 施行規則)');
  if (a.qualifiedStaffCount < 1) blockers.push('美容師/理容師 1名以上の配置必須');

  // 構造設備基準
  const minM2 = 13; // 1作業所あたり概ね13m²目安 (都道府県条例で変動)
  if (a.workSpaceM2 < minM2) blockers.push(`作業面積 ${minM2}m² 以上が目安 (条例)`);
  if (!a.hasSeparateWaitingArea) blockers.push('待合所と作業所の区分必須 (公衆衛生上)');
  if (!a.hasRunningWaterPerSeat) blockers.push('各作業所に給水・給湯設備必須');
  if (!a.hasUvSterilizer && !a.hasBoilingSterilizer) {
    blockers.push('器具の消毒設備 (紫外線消毒器 or 煮沸消毒器) いずれか必須');
  }
  if (a.toiletDistanceM < 1.5) blockers.push('便所と作業所の距離が近すぎる (1.5m以上)');

  return { approvable: blockers.length === 0, blockers };
}

// ============================================================================
// 3. 美容師/理容師 資格
// ============================================================================

/** 美容師国家試験 受験資格: 厚生労働省指定養成施設 (2年以上) 卒業 */
export interface BeautyLicenseHolder {
  name: string;
  licenseKind: 'beauty' | 'barber' | 'both';
  licenseNumber: string;
  issuedAt: Date;
  hasManagedSalonExperience3y: boolean; // 管理美容師/管理理容師研修受講要件
}

/** 管理美容師/管理理容師 (営業者2人以上の美容師/理容師を配置する場合に必須) */
export function isManagerEligible(input: {
  hasLicense: boolean;
  yearsOfExperience: number;
  hasManagementTraining: boolean; // 都道府県知事指定講習会受講
}): { eligible: boolean; reason: string } {
  if (!input.hasLicense) return { eligible: false, reason: '美容師/理容師免許必須' };
  if (input.yearsOfExperience < 3) {
    return { eligible: false, reason: '3年以上の実務経験必須 (美容師法8条の2)' };
  }
  if (!input.hasManagementTraining) {
    return { eligible: false, reason: '都道府県知事指定の管理者講習会修了必須' };
  }
  return { eligible: true, reason: '管理美容師/管理理容師として選任可能' };
}

// ============================================================================
// 4. 消毒・衛生管理 (環境衛生関係営業の運営適正化法)
// ============================================================================

/** 器具の消毒方法 (美容師法施行規則25条 / 理容師法施行規則25条) */
export const STERILIZATION_METHODS = {
  boiling: { ja: '煮沸消毒', minutes: 2, temperature: 80 }, // 沸騰水中で2分以上
  uv: { ja: '紫外線消毒', minutes: 20, energyMjPerCm2: 85 }, // 85μW/cm² × 20分
  ethanol: { ja: 'エタノール (76.9-81.4%) 浸漬', minutes: 10 },
  cresol: { ja: 'クレゾール石鹸液 (3%)', minutes: 10 },
  benzalkonium: { ja: '逆性石鹸 (0.1%)', minutes: 10 },
  hypochlorite: { ja: '次亜塩素酸ナトリウム (0.01-0.1%)', minutes: 10 },
} as const;

/** 一日の消毒記録チェック */
export function checkDailyHygieneLog(input: {
  sterilizationMethod: keyof typeof STERILIZATION_METHODS;
  isMultipleClientsServed: boolean;
  hasNailKitSterilization: boolean;
  hasTowelSterilization: boolean;
  hasFloorCleaningPerDay: number; // 床清掃回数
}): { compliant: boolean; alerts: string[] } {
  const alerts: string[] = [];
  if (!input.hasNailKitSterilization) alerts.push('ネイル器具の消毒記録が必要');
  if (!input.hasTowelSterilization) alerts.push('タオル消毒 (煮沸 or 80℃/10分以上) 必須');
  if (input.hasFloorCleaningPerDay < 1) alerts.push('床清掃 1日1回以上必要 (環境衛生)');
  return { compliant: alerts.length === 0, alerts };
}

// ============================================================================
// 5. エステサロン (特定商取引法 — 継続的役務提供)
// ============================================================================

/** 特商法 41条以下: 継続的役務 (エステ/語学/家庭教師/学習塾/結婚紹介/PCスクール) */
export interface EstheticContract {
  totalServiceFeeJpy: number;
  contractPeriodMonths: number;
  isContractWithSalesOfRelatedGoods: boolean; // 関連商品 (化粧品等) 販売を伴うか
}

/** 特商法 41条 — エステティック役務の規制対象判定 */
export function isEstheticServiceRegulated(c: EstheticContract): {
  regulated: boolean;
  reason: string;
} {
  // 期間・金額の境目は台帳 (tokutei_keizoku.ts) の値を使う: エステは 1か月を超え 5万円を超えるもの
  const row = TOKUTEI_KEIZOKU_LEDGER.services.esthetic;
  if (c.totalServiceFeeJpy > row.minFeeExclusiveJpy && c.contractPeriodMonths > row.minMonthsExclusive) {
    return { regulated: true, reason: `${row.minFeeExclusiveJpy.toLocaleString()}円超 + ${row.minMonthsExclusive}か月超 — 特商法41条の特定継続的役務提供に該当` };
  }
  return { regulated: false, reason: '期間・金額の境目を超えないため規制対象外' };
}

/**
 * クーリング・オフの最終日 (特商法48条1項)。
 *   法定の書面 (契約書面) を【受け取った日】を1日目として8日間 → 最終日は受領日の7日後。
 *   ★引数は契約日ではなく書面の受領日を渡すこと (契約日と受領日が違えば受領日から数える)。
 *   出典: 消費者庁「特定商取引法ガイド 特定継続的役務提供」https://www.no-trouble.caa.go.jp/what/continuousservices/
 */
export function calcEstheticCoolingOffDeadline(documentReceivedDate: Date): Date {
  const d = new Date(documentReceivedDate);
  d.setDate(d.getDate() + 7);
  return d;
}

/**
 * 特定継続的役務の指定7役務と、中途解約時の損害賠償等の上限 (特商法41条・49条・施行令別表第四) — 値表
 *   出典: 消費者庁「特定商取引法ガイド 特定継続的役務提供」https://www.no-trouble.caa.go.jp/what/continuousservices/ (2026-10-01 確認)
 *   minMonthsExclusive: この月数を【超える】期間 / 金額はいずれも 5万円を【超える】もの
 *   beforeStartJpy: 役務提供開始前の上限 (契約の締結と履行に通常要する費用)
 *   afterStart: 役務提供開始後に、提供済み役務の対価に加えて請求できる額 = min(fixedJpy, 契約残額×rate または 1か月分の授業料)
 *   ★フィットネス・スイミング・音楽教室などは指定役務に含まれない (中途解約は利用規約と消費者契約法9条1号の平均的な損害で扱う)。
 */
export type DesignatedContinuousService = LedgerDesignatedContinuousService;

/** 値は台帳 (tokutei_keizoku.ts の TOKUTEI_KEIZOKU_LEDGER.services) をそのまま参照する (写しを持たない) */
export const DESIGNATED_CONTINUOUS_SERVICES: Record<DesignatedContinuousService, {
  label: string; minMonthsExclusive: number; minFeeExclusiveJpy: number; beforeStartJpy: number;
  afterStart: { fixedJpy: number; remainingRate?: number; monthlyFee?: true };
  relatedGoods: readonly string[];
}> = TOKUTEI_KEIZOKU_LEDGER.services;

/** 契約が特定継続的役務提供 (指定7役務・期間・金額) に当たるか */
export function isDesignatedContinuousService(p: { service: string; contractPeriodMonths: number; totalFeeJpy: number }): {
  designated: boolean; reason: string;
} {
  const def = (DESIGNATED_CONTINUOUS_SERVICES as Record<string, (typeof DESIGNATED_CONTINUOUS_SERVICES)[DesignatedContinuousService]>)[p.service];
  if (!def) {
    return { designated: false, reason: `「${p.service}」は特商法の指定7役務 (エステ・美容医療・語学教室・家庭教師・学習塾・パソコン教室・結婚相手紹介) に含まれません。中途解約は利用規約と消費者契約法9条1号 (平均的な損害) で扱います` };
  }
  const ok = p.contractPeriodMonths > def.minMonthsExclusive && p.totalFeeJpy > def.minFeeExclusiveJpy;
  return {
    designated: ok,
    reason: ok
      ? `${def.label}: 期間${def.minMonthsExclusive}か月超・5万円超のため特定継続的役務提供に該当`
      : `${def.label}: 期間${def.minMonthsExclusive}か月超かつ5万円超の両方を満たさないため該当しない`,
  };
}

/**
 * 中途解約時に事業者が請求できる額の上限 (特商法49条2項)。円未満は切り捨てる (受け取れる額を多く見積もらない安全側。要確認)。
 *   指定役務でないとき・家庭教師/学習塾で1か月分の授業料が無いときは capJpy=null (上限を作らない)。
 */
export function calcContinuousServiceCancellationCapJpy(p: {
  service: string; started: boolean; contractFeeJpy: number; providedValueJpy: number; monthlyFeeJpy?: number;
}): { capJpy: number | null; reason: string } {
  const def = (DESIGNATED_CONTINUOUS_SERVICES as Record<string, (typeof DESIGNATED_CONTINUOUS_SERVICES)[DesignatedContinuousService]>)[p.service];
  if (!def) return { capJpy: null, reason: '特商法の指定役務ではないため、法49条の上限はありません (利用規約と消費者契約法9条1号で扱う)' };
  if (!p.started) return { capJpy: def.beforeStartJpy, reason: `${def.label}: 役務提供開始前の上限 ${def.beforeStartJpy.toLocaleString()}円 (特商法49条2項2号)` };
  const remaining = Math.max(0, p.contractFeeJpy - p.providedValueJpy);
  let variable: number;
  if (def.afterStart.monthlyFee) {
    if (!(typeof p.monthlyFeeJpy === 'number' && p.monthlyFeeJpy >= 0)) {
      return { capJpy: null, reason: `${def.label}: 1か月分の授業料が無いため上限を出せません` };
    }
    variable = p.monthlyFeeJpy;
  } else {
    variable = Math.floor(remaining * Math.round((def.afterStart.remainingRate ?? 0) * 100) / 100);
  }
  const extra = Math.min(def.afterStart.fixedJpy, variable);
  return {
    capJpy: p.providedValueJpy + extra,
    reason: `${def.label}: 提供済み ${p.providedValueJpy.toLocaleString()}円 + min(${def.afterStart.fixedJpy.toLocaleString()}円, ${variable.toLocaleString()}円) (特商法49条2項1号)`,
  };
}

/**
 * 中途解約 違約金上限 (特商法49条・エステティック)
 *   提供開始【前】: 2万円 (契約の締結・履行に通常要する費用)
 *   提供開始【後】: 提供済み役務の対価 + min(2万円, 契約残額×10%)
 *   serviceStarted を省くと、提供済みの対価か割合が 0 より大きいときに開始後とみなす。
 */
export function calcMidwayCancellationFeeMax(input: {
  receivedServiceValueJpy: number;
  alreadyServedFraction: number; // 0.0-1.0
  contractFeeJpy: number;
  serviceStarted?: boolean;
}): { feeMaxJpy: number; reason: string } {
  const started = input.serviceStarted ?? (input.receivedServiceValueJpy > 0 || input.alreadyServedFraction > 0);
  const r = calcContinuousServiceCancellationCapJpy({
    service: 'esthetic', started, contractFeeJpy: input.contractFeeJpy, providedValueJpy: input.receivedServiceValueJpy,
  });
  return { feeMaxJpy: r.capJpy as number, reason: started ? '特商法49条 提供済+min(2万円, 残額10%)' : '特商法49条 役務提供開始前 2万円' };
}

// ============================================================================
// 6. まつ毛エクステ (H20通達)
// ============================================================================

/** まつ毛エクステは美容師資格必須 — H20通達 */
export function isEyelashExtensionPermitted(input: {
  hasBeautyLicense: boolean;
  isAtRegisteredBeautySalon: boolean;
  hasGlueAllergyTesting: boolean;
}): { permitted: boolean; warnings: string[] } {
  const w: string[] = [];
  if (!input.hasBeautyLicense) {
    return { permitted: false, warnings: ['美容師免許必須 (H20厚生労働省通達)'] };
  }
  if (!input.isAtRegisteredBeautySalon) w.push('美容所開設届のある店舗でのみ営業可');
  if (!input.hasGlueAllergyTesting) w.push('グルー (接着剤) のパッチテスト推奨');
  return { permitted: true, warnings: w };
}

// ============================================================================
// 7. 広告規制 (景表法 + 薬機法)
// ============================================================================

/** 美容/エステ広告で禁止される表現の検出 */
export function scanBeautyAdViolation(adText: string): { violations: string[] } {
  const violations: string[] = [];
  // 薬機法違反: 医薬品的効能効果の標榜
  const medicalClaims = ['シミが消える', 'シワが治る', 'アトピー改善', '若返り', '肌が再生', 'ニキビ完治'];
  for (const c of medicalClaims) {
    if (adText.includes(c)) violations.push(`薬機法違反 (医薬品的効能効果): "${c}"`);
  }
  // 景表法違反: 優良誤認
  const exaggerations = ['100%', '絶対', '必ず痩せる', '効果保証', 'No.1 (※不当根拠)'];
  for (const e of exaggerations) {
    if (adText.includes(e)) violations.push(`景表法 優良誤認: "${e}"`);
  }
  return { violations };
}
