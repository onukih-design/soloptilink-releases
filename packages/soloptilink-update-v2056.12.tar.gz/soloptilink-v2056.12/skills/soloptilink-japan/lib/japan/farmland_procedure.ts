/**
 * lib/japan/farmland_procedure.ts — 農地の権利移動・転用の手続の分岐と期限 (REQ-159 / JPO-IND-136)
 *
 * 2026-10-03 (JPO-T33) 新設。農地法3条・3条の3・4条・5条の分岐を判定し、手続・許可権者・窓口・期限・必要書類・
 * 止める理由・根拠条文と、行政書士の業務の線引きの文言を返す。面積の閾値などの値は primary_industry_ledger.ts を読む。
 *
 * これは判定の支援で、申請書の作成代行ではない (行政書士法第1条の3・第19条)。許可の判断は農業委員会・都道府県知事等が行う。
 * 都道府県の条例・運用 (事前相談・受付締切日・添付書類の上乗せ) は含まない。
 */
import { FARMLAND_RULES, PROFESSIONAL_BOUNDARY } from './primary_industry_ledger';

export type FarmlandProcedure =
  | 'permit_art3' // 3条許可 (農業委員会)
  | 'notify_art3_3' // 3条の3 届出 (相続・遺産分割等)
  | 'farmland_bank_plan' // 農地バンク (農用地利用集積等促進計画) — 3条許可不要
  | 'not_required' // 許可・届出とも不要 (国・都道府県の取得 等)
  | 'not_available' // その手続は使えない (廃止された利用権設定 等)
  | 'permit_art4' // 4条許可 (自己転用)
  | 'notify_art4' // 4条届出 (市街化区域)
  | 'permit_art5' // 5条許可 (転用目的の権利移動)
  | 'notify_art5' // 5条届出 (市街化区域)
  | 'consultation_state' // 国・都道府県等の協議 (協議の成立で許可とみなす)
  | 'undetermined'; // 入力不足で判定しない

export interface FarmlandProcedureInput {
  /** keep_farming = 農地のまま権利を移す / convert = 農地以外にする (転用) */
  purpose: 'keep_farming' | 'convert';
  /** 転用のとき: self = 自分の農地を自分で転用 (4条) / other = 転用のために権利を取得 (5条) */
  actor?: 'self' | 'other';
  /** 農地のままのとき: 権利の取得の仕方 */
  acquisition?: 'contract' | 'inheritance' | 'estate_division' | 'farmland_bank';
  /** 転用目的の権利の種類 (5条の一時転用の判定に使う) */
  rightKind?: 'ownership' | 'lease' | 'other';
  areaHa: number;
  /** urbanization = 市街化区域 / urbanization_control = 市街化調整区域 / other = それ以外 / unknown = 不明 */
  zone?: 'urbanization' | 'urbanization_control' | 'other' | 'unknown';
  /** 農業振興地域の農用地区域 (いわゆる青地) 内か */
  inAgriPromotionArea?: boolean;
  /** 農林水産大臣が指定する指定市町村の区域内か */
  designatedMunicipality?: boolean;
  /** 一時転用 (資材置場・仮設工作物 等) か */
  temporary?: boolean;
  /** 取得者が国又は都道府県 (転用は都道府県等＝都道府県・指定市町村を含む) か */
  acquirerIsStateOrPrefecture?: boolean;
  /** 市町村の利用権設定 (農用地利用集積計画) を使いたいか */
  legacyUseRightPlan?: boolean;
  /** 手続をする日 (YYYY-MM-DD)。省略時は今日 */
  procedureDate?: string;
}

export interface FarmlandProcedureResult {
  procedure: FarmlandProcedure;
  procedureJa: string;
  permitRequired: boolean;
  /** 許可権者 (許可が要らないときは空) */
  authority: string;
  /** 申請・届出の窓口 */
  window: string;
  /** 4ha 超の転用で国 (農林水産大臣) との協議が付くか */
  ministerConsultation: boolean;
  /** 30アール超の転用で農業委員会が都道府県機構の意見を聴くか */
  prefecturalOrgOpinion: boolean;
  deadline: string;
  requiredDocuments: string[];
  /** 許可できない・その手続が使えない理由 (空なら止める理由なし) */
  blockers: string[];
  notes: string[];
  basis: string[];
  professionalBoundary: string;
}

const DOCS_ART3 = [
  '許可申請書 (当事者の連署。競売・遺贈等の単独行為は除く: 施行規則10条1項)',
  '土地の登記事項証明書 (全部事項証明書)',
  '取得者が法人の場合は定款又は寄附行為の写し',
  '取得者が農地所有適格法人 (農事組合法人・株式会社) の場合は組合員名簿又は株主名簿の写し',
  '解除条件付きの貸借 (3条3項) の場合は条件を付した契約書の写し',
  'その他参考となるべき書類 (営農計画書など市町村の様式は農業委員会で確認)',
];
const DOCS_ART4 = [
  '許可申請書 (農業委員会を経由して提出)',
  '申請者が法人の場合は定款若しくは寄附行為の写し又は法人の登記事項証明書',
  '土地の位置を示す地図及び土地の登記事項証明書',
  '設置しようとする建物その他の施設・道路・用排水施設の位置を明らかにした図面',
  '資金計画に基づき事業を実施するために必要な資力及び信用があることを証する書面',
  '転用の妨げとなる権利を有する者がある場合はその同意があったことを証する書面',
  '土地改良区の地区内にある場合は土地改良区の意見書',
  'その他参考となるべき書類',
];
const DOCS_ART5 = [
  '許可申請書 (当事者の連署・農業委員会を経由して提出)',
  '権利を取得しようとする者が法人の場合は定款若しくは寄附行為の写し又は法人の登記事項証明書',
  '土地の位置を示す地図及び土地の登記事項証明書',
  '設置しようとする建物その他の施設・道路・用排水施設の位置を明らかにした図面',
  '資金計画に基づき事業を実施するために必要な資力及び信用があることを証する書面',
  '転用の妨げとなる権利を有する者がある場合はその同意があったことを証する書面',
  '土地改良区の地区内にある場合は土地改良区の意見書',
  'その他参考となるべき書類',
];
const DOCS_NOTIFY_CONVERT = [
  '農地転用届出書 (市街化区域内・農業委員会へ事前に)',
  '土地の位置を示す地図',
  '土地の登記事項証明書',
  '(5条の届出は) 当事者の連署',
  '添付の詳細は農業委員会の様式で確認',
];
const DOCS_NOTIFY_3_3 = ['農地法第3条の3の届出書 (農業委員会の様式)', '権利の取得を証する書面 (登記事項証明書・遺産分割協議書の写し等。詳細は農業委員会で確認)'];

const PENALTY = '無許可の転用・権利移動は3年以下の拘禁刑又は300万円以下の罰金 (農地法64条)。転用の無許可は法人に1億円以下の罰金 (67条)';

function base(): Omit<FarmlandProcedureResult, 'procedure' | 'procedureJa'> {
  return {
    permitRequired: false,
    authority: '',
    window: '',
    ministerConsultation: false,
    prefecturalOrgOpinion: false,
    deadline: '',
    requiredDocuments: [],
    blockers: [],
    notes: [],
    basis: [],
    professionalBoundary: PROFESSIONAL_BOUNDARY.gyoseishoshi,
  };
}

/** 農地の権利移動・転用で必要な手続を判定する */
export function judgeFarmlandProcedure(i: FarmlandProcedureInput): FarmlandProcedureResult {
  const R = FARMLAND_RULES;
  const day = i.procedureDate ?? new Date().toISOString().slice(0, 10);
  if (!(typeof i.areaHa === 'number' && Number.isFinite(i.areaHa) && i.areaHa > 0)) {
    return { ...base(), procedure: 'undetermined', procedureJa: '判定できません (面積が入力されていません)', notes: ['農地の面積 (ha) を入力してください。面積で国との協議・都道府県機構の意見の要否が変わります。'] };
  }

  // ---------------- 農地のまま権利を移す ----------------
  if (i.purpose === 'keep_farming') {
    if (i.legacyUseRightPlan) {
      if (day >= R.useRightPlanAbolishedFrom) {
        return {
          ...base(),
          procedure: 'not_available',
          procedureJa: '市町村の利用権設定 (農用地利用集積計画) は使えません',
          blockers: [`農業経営基盤強化促進法の改正により、${R.useRightPlanAbolishedFrom} (令和7年4月) から農地の貸し借りの計画は農地バンク (農地中間管理機構) を経由する方法に一本化されました。`],
          notes: ['代わりの方法: ①農地バンクの農用地利用集積等促進計画 (3条許可は不要) ②農業委員会の農地法3条許可 (引き続き利用可能)。'],
          basis: ['農林水産省「農地バンク よくあるご質問」Q3'],
        };
      }
      return {
        ...base(),
        procedure: 'undetermined',
        procedureJa: '旧制度の期間の手続です (令和7年3月31日まで)',
        notes: ['令和7年3月31日までの市町村の農用地利用集積計画による利用権設定の扱いは、当時の計画の内容を市町村・農業委員会で確認してください。'],
        basis: ['農林水産省「農地バンク よくあるご質問」Q3'],
      };
    }
    if (i.acquirerIsStateOrPrefecture) {
      return {
        ...base(),
        procedure: 'not_required',
        procedureJa: '許可・届出とも不要 (国又は都道府県が取得)',
        basis: ['農地法3条1項5号 (取得者が国又は都道府県)', '農地法3条の3 (3条1項各号に該当する場合は届出不要。12号・16号を除く)'],
      };
    }
    if (i.acquisition === 'farmland_bank') {
      return {
        ...base(),
        procedure: 'farmland_bank_plan',
        procedureJa: '農地バンク (農地中間管理機構) の農用地利用集積等促進計画 — 農地法3条許可は不要',
        window: '農地中間管理機構 (農地バンク)',
        deadline: '促進計画を都道府県知事が認可・公告した時に権利設定の効力が生じます (作成の頻度は農地バンクごと。多くは月1回以上)',
        requiredDocuments: ['農地バンクの申込書 (出し手・受け手の様式は各農地バンクで確認)'],
        notes: ['地域計画 (目標地図) に位置付けられた受け手への貸付が基本です。'],
        basis: ['農地法3条1項7号 (農用地利用集積等促進計画)', '農林水産省「農地バンク よくあるご質問」Q3・基本用語5'],
      };
    }
    if (i.acquisition === 'inheritance' || i.acquisition === 'estate_division') {
      const isDivision = i.acquisition === 'estate_division';
      return {
        ...base(),
        procedure: 'notify_art3_3',
        procedureJa: isDivision ? '農地法3条の3の届出 (遺産の分割による取得・3条許可は不要)' : '農地法3条の3の届出 (相続による取得・3条許可は不要)',
        window: '農業委員会 (農地の所在する市町村)',
        deadline: '遅滞なく農業委員会に届け出る (農地法3条の3)',
        requiredDocuments: DOCS_NOTIFY_3_3,
        basis: isDivision
          ? ['農地法3条1項12号 (遺産の分割)', '農地法3条の3 (12号は届出の対象から除かれない)']
          : ['農地法3条1項本文 (相続は権利の設定・移転の行為でなく許可の対象外)', '農地法3条の3'],
      };
    }
    // 相対の売買・貸借 (既定)
    return {
      ...base(),
      procedure: 'permit_art3',
      procedureJa: '農地法3条の許可 (農地のまま所有権の移転・貸借)',
      permitRequired: true,
      authority: '農業委員会',
      window: '農業委員会',
      deadline: '契約の効力が生じる前に許可を受ける。許可を受けないでした行為は効力を生じない (農地法3条6項)',
      requiredDocuments: DOCS_ART3,
      notes: i.zone === 'urbanization' ? ['市街化区域内でも、農地のまま権利を移すときは3条許可が要ります (届出で足りるのは転用だけ)。'] : [],
      basis: ['農地法3条1項', '農地法3条6項', '農地法施行規則10条'],
    };
  }

  // ---------------- 転用 ----------------
  const art5 = i.actor === 'other';
  const R0 = base();
  R0.ministerConsultation = i.areaHa > R.ministerConsultOverHa;
  R0.prefecturalOrgOpinion = i.areaHa > R.prefecturalOrgOpinionOverHa;

  if (i.acquirerIsStateOrPrefecture) {
    return {
      ...R0,
      procedure: 'consultation_state',
      procedureJa: '国又は都道府県等と都道府県知事等との協議 (協議の成立をもって許可とみなす)',
      ministerConsultation: false,
      prefecturalOrgOpinion: false,
      window: '都道府県知事等 (協議)',
      deadline: '転用の前に協議を成立させる',
      basis: [art5 ? '農地法5条4項' : '農地法4条8項', '農地法4条1項2号・5条1項1号 (農林水産省令で定める施設は許可不要)'],
    };
  }

  if (i.zone === 'urbanization') {
    return {
      ...R0,
      procedure: art5 ? 'notify_art5' : 'notify_art4',
      procedureJa: art5 ? '農地法5条の届出 (市街化区域内の転用目的の権利移動)' : '農地法4条の届出 (市街化区域内の転用)',
      ministerConsultation: false,
      prefecturalOrgOpinion: false,
      window: '農業委員会',
      deadline: 'あらかじめ (転用・権利移動の前に) 農業委員会に届け出る',
      requiredDocuments: DOCS_NOTIFY_CONVERT,
      basis: [art5 ? '農地法5条1項6号' : '農地法4条1項7号'],
    };
  }

  const authority = i.designatedMunicipality ? '指定市町村の長' : '都道府県知事';
  const res: FarmlandProcedureResult = {
    ...R0,
    procedure: art5 ? 'permit_art5' : 'permit_art4',
    procedureJa: art5 ? '農地法5条の許可 (転用のための権利移動)' : '農地法4条の許可 (自己所有の農地の転用)',
    permitRequired: true,
    authority,
    window: '農業委員会 (申請書は農業委員会を経由して許可権者へ)',
    deadline: `転用 (工事の着手) ・権利移動の前に許可を受ける。${PENALTY}`,
    requiredDocuments: art5 ? DOCS_ART5 : DOCS_ART4,
    basis: art5
      ? ['農地法5条1項', '農地法5条3項 (4条2項〜5項・7項の準用)', '農地法施行規則57条の4']
      : ['農地法4条1項', '農地法4条2項 (農業委員会経由)', '農地法施行規則30条'],
  };
  if (res.ministerConsultation) {
    res.notes.push(`同一の事業の目的で${R.ministerConsultOverHa}haを超える転用は、国 (農林水産大臣) との協議を付した上で${authority}が許可します (指定市町村制度の概要)。`);
    res.basis.push('農林水産省「指定市町村制度の概要」(4ha超は国協議)');
  }
  if (res.prefecturalOrgOpinion) {
    res.notes.push('30アールを超える転用は、農業委員会が意見を述べる前に都道府県機構 (都道府県農業会議) の意見を聴きます (都道府県知事の指定が無い場合を除く)。');
    res.basis.push('農地法4条4項');
  }
  if (i.inAgriPromotionArea) {
    res.blockers.push(`農用地区域内 (いわゆる青地) の農地は、原則として転用の許可ができません (${art5 ? '農地法5条2項1号イ' : '農地法4条6項1号イ'})。`);
    res.notes.push('先に市町村へ農業振興地域整備計画 (農用地利用計画) の変更 (いわゆる農振除外) を相談してください。');
    res.basis.push(art5 ? '農地法5条2項1号イ' : '農地法4条6項1号イ');
  }
  if (i.temporary) {
    if (art5 && i.rightKind === 'ownership') {
      res.blockers.push('一時的な利用 (仮設工作物の設置等) のために所有権を取得する場合は、転用の許可ができません (農地法5条2項6号)。賃借など所有権以外の権利での一時転用を検討してください。');
      res.basis.push('農地法5条2項6号');
    } else {
      res.notes.push('一時転用は、利用の後に耕作の目的に供されること (農地への復元) が確実でなければ許可されません。');
      res.basis.push(art5 ? '農地法5条2項7号' : '農地法4条6項6号');
    }
  }
  if (i.zone === 'unknown' || i.zone === undefined) {
    res.notes.push('市街化区域かどうかが分からないため、安全側で許可として扱っています。市街化区域内なら農業委員会への届出で足ります (農地法4条1項7号・5条1項6号)。');
  }
  return res;
}
