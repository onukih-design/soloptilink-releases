/**
 * SoloptiLinkAI JAPAN-NATIVE Mode - Bug Prevention DNA (v2015.4 Phase 6)
 *
 * 生成時点で日本の中小企業向け業務システムによく出るバグを未然に封じ込める
 * 「バグ予防DNA」ライブラリ。save_guarantee.ts と一緒に generated project に注入される。
 *
 * 対応領域:
 *   - 数値計算の丸め (消費税端数処理: 切り捨て/切り上げ/四捨五入の混在)
 *   - 金額の int / decimal 誤用
 *   - 電話/郵便番号のフォーマット揺れ
 *   - 和暦/西暦の取り違え
 *   - CSV import/export の BOM と文字コード
 *   - PDF 出力時の A4 はみ出し検知
 *   - お客様からのクレーム頻出ポイント (金額表示/印影位置/送り先住所の敬称)
 */

import { checkToritekiPaymentDate, checkMonthlyClosingTerms, payDateByPolicy, ymdToJstDate } from './toriteki';
import { ymdToCalendarDate } from './calendar/jp_calendar';
import { formatJapanesePhone } from './phone_jp';
import { formatAtena } from './atena';

// =============================================================================
// 消費税端数処理 (インボイス制度: 1 インボイスあたり税率ごとに 1 回)
// =============================================================================

export type RoundingPolicy = 'floor' | 'ceil' | 'round';

/**
 * 消費税計算の端数処理を明示的に指定する。
 * インボイス制度では「1 インボイスあたり税率ごとに 1 回」が原則。
 */
export function calcTax(subtotal: number, rate: 0.1 | 0.08 | 0, policy: RoundingPolicy = 'floor'): number {
  const raw = subtotal * rate;
  switch (policy) {
    case 'floor': return Math.floor(raw);
    case 'ceil': return Math.ceil(raw);
    case 'round': return Math.round(raw);
  }
}

/**
 * 取引明細を税率でグルーピングし、税率ごとに 1 回の端数処理を行う。
 * インボイス要件を満たす税額計算。
 */
export function groupAndCalcTax(
  items: Array<{ amount: number; rate: 'standard' | 'reduced' | 'exempt' }>,
  policy: RoundingPolicy = 'floor',
): { standard: { subtotal: number; tax: number }; reduced: { subtotal: number; tax: number }; exempt: { subtotal: number } } {
  const groups = { standard: 0, reduced: 0, exempt: 0 };
  for (const it of items) groups[it.rate] += it.amount;
  return {
    standard: { subtotal: groups.standard, tax: calcTax(groups.standard, 0.1, policy) },
    reduced: { subtotal: groups.reduced, tax: calcTax(groups.reduced, 0.08, policy) },
    exempt: { subtotal: groups.exempt },
  };
}

// =============================================================================
// 金額表記 (数値フォーマットと型安全)
// =============================================================================

/**
 * 日本の金額表記: カンマ区切り + ¥ 接頭辞。
 * 通貨単位は円のみ (本スキルではマルチ通貨非対応)。
 */
export function formatYen(amount: number, opts: { withSymbol?: boolean } = {}): string {
  const sign = amount < 0 ? '△' : '';
  const n = Math.abs(Math.floor(amount)).toLocaleString('ja-JP');
  return opts.withSymbol === false ? `${sign}${n}` : `¥${sign}${n}`;
}

/**
 * 金額パース: ¥1,234,567 / １２３４ / ￥500 / -1000 等を全て受け付ける。
 * 失敗時は null を返す (NaN 事故防止)。
 */
export function parseYen(input: string | number | null | undefined): number | null {
  if (typeof input === 'number') return Number.isFinite(input) ? input : null;
  if (!input) return null;
  const normalized = input
    .trim()
    .replace(/[￥¥]/g, '')
    .replace(/[０-９]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0xFEE0))
    .replace(/[−ー－]/g, '-')
    .replace(/,/g, '')
    .replace(/△/g, '-');
  const n = Number(normalized);
  return Number.isFinite(n) ? n : null;
}

// =============================================================================
// 電話番号フォーマット (日本固有)
// =============================================================================

/**
 * 国内電話番号の正規化。
 * 入力: 090-1234-5678 / 0901234567 / ０９０−１２３４−５６７８ / +81 90 1234 5678
 * 出力: 09012345678 (ハイフンなし・半角)
 */
export function normalizePhoneJP(input: string): string {
  return input
    .trim()
    .replace(/[０-９]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0xFEE0))
    .replace(/[−ー－\s()（）]/g, '')
    .replace(/^\+?81/, '0');
}

/**
 * 表示用ハイフン付き: 09012345678 → 090-1234-5678 / 0422123456 → 0422-12-3456 / 08001234567 → 0800-123-4567
 * ★2026-09-30 REQ-JPO-FIX-006: 03・06 以外の固定電話を整形せず、0800 を携帯の 080 と取り違えていた。
 *   本体は phone_jp.ts（総務省「市外局番の一覧」令和8年3月1日現在・電気通信番号計画）。
 *   判断できない番号は入力のまま返す（以前は数字だけにした文字列を返していた）。
 */
export function formatPhoneJP(input: string): string {
  return formatJapanesePhone(input);
}

// =============================================================================
// 郵便番号
// =============================================================================

export function normalizePostalJP(input: string): string {
  return input
    .trim()
    .replace(/[０-９]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0xFEE0))
    .replace(/[−ー－\s]/g, '')
    .replace(/^〒/, '');
}

export function isValidPostalJP(input: string): boolean {
  return /^\d{7}$/.test(normalizePostalJP(input));
}

export function formatPostalJP(input: string): string {
  const raw = normalizePostalJP(input);
  if (!isValidPostalJP(raw)) return input;
  return `〒${raw.slice(0, 3)}-${raw.slice(3)}`;
}

// =============================================================================
// CSV: 日本のビジネスで UTF-8 BOM + Shift_JIS 両対応が必須
// =============================================================================

/**
 * CSV を日本向けに安全に書き出す。
 * - Excel 互換のため UTF-8 BOM を付与
 * - CRLF 改行 (RFC 4180)
 * - ダブルクォート/改行/カンマを含むセルは必ずクォート
 * - 先頭文字が =/+/-/@ の場合は CSV Injection 対策でシングルクォートを付与
 */
export function toCsvJP(rows: Array<Record<string, string | number | null | undefined>>, opts: { bom?: boolean } = {}): string {
  if (rows.length === 0) return opts.bom === false ? '' : '\uFEFF';
  const headers = Object.keys(rows[0]);
  const lines: string[] = [];
  lines.push(headers.map(escape).join(','));
  for (const row of rows) {
    lines.push(headers.map(h => escape(row[h] ?? '')).join(','));
  }
  const body = lines.join('\r\n');
  return (opts.bom === false ? '' : '\uFEFF') + body;
}

function escape(v: string | number | null | undefined): string {
  if (v === null || v === undefined) return '';
  let s = String(v);
  // CSV Injection 対策
  if (/^[=+\-@]/.test(s)) s = `'${s}`;
  if (/[",\r\n]/.test(s)) s = `"${s.replace(/"/g, '""')}"`;
  return s;
}

// =============================================================================
// 敬称 (顧客向け表示)
// =============================================================================

export type HonorificKind = 'company' | 'person' | 'division';

/**
 * 宛先に応じた敬称自動付与。
 * - 個人: 様
 * - 法人: 御中
 * - 部署: 御中
 * - 既に付いていれば二重付与しない（「山田様 様」「御中 御中」「各位様」「行 様」を出さない）
 * - 「株式会社ABC 山田」のように法人名＋個人名なら kind に関わらず「様」（敬語の指針【21】）
 * ★2026-09-30 REQ-JPO-FIX-006: 本体は atena.ts（宛名の敬称の唯一の処理）。
 */
export function attachHonorific(name: string, kind: HonorificKind = 'person'): string {
  return formatAtena(name, { kind: kind === 'person' ? 'person' : 'organization' });
}

// =============================================================================
// 契約日/発行日/支払期日: バリデーションと自動計算
// =============================================================================

/**
 * 月末締翌月末払い等の日本の商慣習日計算。
 * baseDate から指定日数/月末まで計算。
 *
 * ★2026-09-30 是正 (REQ-JPO-FIX-015 の時刻帯・第1波 I5 の残り): 旧実装は端末の現地時刻 (getFullYear/getMonth/getDate) で
 *   発行日を読み、協定世界時のサーバーでは日本時間 0〜8 時台の発行日を前日として締め日を判定していた
 *   (20日締め: 日本時間 7/21 8:59 発行 → 前月締めの 8/31 払いと誤る)。いまは日本時間の暦日で読み (toriteki.payDateByPolicy)、
 *   返す Date はその暦日の協定世界時 0 時 (日本時間 9 時。日本時間でも協定世界時の端末の getDate() でも同じ暦日に読める)。
 *   あわせて、支払日 (payDay) がその月に無いとき (2月の30日・31日など) は月末にする (旧実装は翌月へあふれていた)。
 */
export function calcPaymentDueDate(
  issuedAt: Date,
  policy: { closeDay: number | 'endOfMonth'; payDay: number | 'endOfMonth'; offsetMonths: number },
): Date {
  return ymdToCalendarDate(payDateByPolicy(issuedAt, policy));
}

/**
 * 締め日・支払日から支払日を出し、取適法 (旧 下請法) の対象取引なら支払期日の上限を検査する。
 *
 * ★2026-09-30 追加 (REQ-JPO-FIX-015・REQ-JPO-MNY-014/020): 上の calcPaymentDueDate は日付を返すだけで、
 *   20日締め翌々月10日払い (受領7/21 → 10/10・82日目) のように取適法の上限を超える条件でも警告しなかった。
 *   - 起算日は発行日ではなく【受領日】(役務は提供を受けた日) を渡すこと (取適法 第3条)。
 *   - 取適法の対象なら、受領日から2か月 (4条明示された月単位の締切制度の運用)・60日の上限と、
 *     支払条件そのもの (最も不利な受領日) を toriteki.ts で検査する。
 *   - 休業日の扱いは行わない (祝日表を持たない)。休業日に当たる場合の順延は toriteki.checkToritekiPaymentDate の
 *     holidayShift (書面の合意・2日以内) で検査すること。
 */
export function calcPaymentDueDateChecked(
  receivedAt: Date,
  policy: { closeDay: number | 'endOfMonth'; payDay: number | 'endOfMonth'; offsetMonths: number },
  opts: { toriteki?: boolean } = {},
): { dueDate: Date; verdict: 'ok' | 'violation' | 'unconfirmed' | 'not_checked'; warnings: string[] } {
  const ymd = payDateByPolicy(receivedAt, policy);
  const dueDate = ymdToJstDate(ymd);
  if (!opts.toriteki) return { dueDate, verdict: 'not_checked', warnings: [] };
  const warnings: string[] = [];
  const one = checkToritekiPaymentDate({ receivedAt, paymentDate: ymd, monthlyClosing: true });
  const terms = checkMonthlyClosingTerms(policy);
  let verdict: 'ok' | 'violation' | 'unconfirmed' = one.verdict;
  if (one.verdict !== 'ok') warnings.push(...one.reasons);
  if (terms.verdict === 'violation') {
    verdict = 'violation';
    warnings.push(`この支払条件は取適法の対象取引で使えない (最も不利な受領日: ${terms.worstCase?.receivedAt} → ${terms.worstCase?.payDate}・${terms.worstCase?.dayNumber}日目)。締切後30日以内に支払期日を定めること (運用基準 第4-2(6)エ)`);
  } else if (terms.verdict === 'unconfirmed' && verdict === 'ok') {
    verdict = 'unconfirmed';
    warnings.push(...terms.reasons);
  }
  return { dueDate, verdict, warnings };
}

// =============================================================================
// バグ予防アノテーション (開発者向け)
// =============================================================================

/**
 * Prisma/Drizzle スキーマから自動生成された型を「保存時に必ず通すべき関数」に
 * 通していることを静的に強制する型アノテーション。
 *
 * 使用例:
 *   type CustomerSaveInput = Brand<RawCustomerInput, 'SaveGuaranteed'>;
 *   function saveCustomer(input: CustomerSaveInput) { ... }
 */
export type Brand<T, B extends string> = T & { readonly __brand: B };

export function markSaveGuaranteed<T>(value: T): Brand<T, 'SaveGuaranteed'> {
  return value as Brand<T, 'SaveGuaranteed'>;
}
