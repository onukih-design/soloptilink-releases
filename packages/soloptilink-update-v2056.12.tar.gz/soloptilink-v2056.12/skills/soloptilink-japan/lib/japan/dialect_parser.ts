/**
 * lib/japan/dialect_parser.ts — 方言・擬音語・曖昧表現パーサ (v2.0 Phase 5)
 *
 * 柱6 AI-NATIVE JP-INTERFACE の中核モジュール。
 * 日本業務現場の「バッと出る」「ピッと反応する」「しゃっきりさせて」を
 * 具体的な動作仕様に変換する。関西弁・東北弁・九州弁・名古屋弁の
 * 主要語彙にも対応。
 *
 * なぜClaude Codeに作れないか:
 *   LLM の多言語理解は進化したが、業務現場の擬音語・擬態語・方言を
 *   一貫した仕様に変換するには業務ドメインのラベル付きデータセットが必要。
 *   汎用 LLM は「バッと出る」を「快速顯示」程度にしか訳せない。
 *   本モジュールで「即座にフルスクリーン表示 (アニメーション < 200ms)」
 *   まで落とし込む。
 */

// ───────────────────────────────────────────────
// 型定義
// ───────────────────────────────────────────────

/** 入力テキストの方言推定 */
export type Dialect =
  | "standard" // 標準語
  | "kansai" // 関西弁
  | "tohoku" // 東北弁
  | "kyushu" // 九州弁
  | "nagoya" // 名古屋弁
  | "hokkaido"; // 北海道弁

/** 擬音語・擬態語のカテゴリ */
export type OnomatopoeiaCategory =
  | "speed" // バッと、パッと、ピッと
  | "smoothness" // スッと、スルスル、しゃっきり
  | "visibility" // はっきり、くっきり、パッと見
  | "responsiveness" // キビキビ、サクサク、もっさり
  | "completeness" // がっつり、きっちり、ざっくり
  | "subtlety"; // ちょい、少し、ちょこっと

/** パース結果 */
export interface ParsedIntent {
  rawText: string;
  dialect: Dialect;
  normalizedText: string; // 標準語に正規化
  onomatopoeiaList: OnomatopoeiaHit[];
  actionSpecs: ActionSpec[]; // 具体動作仕様
  confidence: number; // 0.0 - 1.0
}

export interface OnomatopoeiaHit {
  original: string;
  category: OnomatopoeiaCategory;
  intensity: "mild" | "moderate" | "strong";
  translatedAction: string;
}

export interface ActionSpec {
  kind: "duration" | "animation" | "layout" | "priority" | "interaction";
  specification: string;
  measurable?: string; // 例: "< 200ms"
}

// ───────────────────────────────────────────────
// 方言辞書
// ───────────────────────────────────────────────

interface DialectEntry {
  word: string;
  standard: string;
  dialect: Dialect;
  /** 直前の字の条件（文頭・直前も辞書語のときは常に可）。無ければ条件なし */
  before?: RegExp;
  /** 直後の字の条件（文末は常に可）。無ければ条件なし */
  after?: RegExp;
  /** 直後に来てはいけない字 */
  notAfter?: RegExp;
  /** 標準語でも使う両義語: 置き換えず、方言とも判定せず、findAmbiguousDialect で「要確認」として返す */
  ambiguous?: boolean;
  /** 両義の説明（要確認の理由） */
  note_ja?: string;
}

// ★2026-09-30 REQ-JPO-FIX-006: 以前は語の境界を見ない部分一致で、標準語を壊していた
//   （「読んだ」→「読そうだ」、「よかった」→「いいった」、「忘れちゃう」→「忘れ違う」、「なんだか」→「なそうだか」）。
//   短い語（んだ・ちゃう・よか・でら・あかん）には前後の字の条件を付け、両義語（ぼちぼち・けろ・したっけ）は置き換えない。
//   「〜だがや」の「〜」は照合できないため外した。
const SEP = /[\s\u3000、。，．,.！？!?「」『』（）()・…]/;
const PARTICLE_OR_SEP = /[\s\u3000、。，．,.！？!?「」『』（）()・…はがもを]/;
const DIALECT_DICTIONARY: DialectEntry[] = [
  // 関西弁
  { word: "ほんまに", standard: "本当に", dialect: "kansai" },
  { word: "ほんま", standard: "本当", dialect: "kansai" },
  { word: "めっちゃ", standard: "とても", dialect: "kansai" },
  { word: "あかん", standard: "だめ", dialect: "kansai", notAfter: /[ぼべ]/ },
  { word: "しゃあない", standard: "仕方ない", dialect: "kansai" },
  { word: "ちゃう", standard: "違う", dialect: "kansai", before: PARTICLE_OR_SEP },
  { word: "せやな", standard: "そうだね", dialect: "kansai" },
  { word: "なんやかんや", standard: "色々", dialect: "kansai" },
  { word: "まいど", standard: "いつもありがとう", dialect: "kansai" },
  { word: "おおきに", standard: "ありがとう", dialect: "kansai" },
  { word: "ぼちぼち", standard: "ぼちぼち", dialect: "kansai", ambiguous: true, note_ja: "「そろそろ」と「まあまあ」の両義（標準語でも使う）" },
  // 東北弁
  { word: "んだんだ", standard: "そうそう", dialect: "tohoku", before: SEP },
  { word: "んだ", standard: "そうだ", dialect: "tohoku", before: SEP, after: SEP },
  { word: "けろ", standard: "けろ", dialect: "tohoku", ambiguous: true, notAfter: /[っりけ]/, note_ja: "東北の「くれ」の意か判断が要る（「けろっと」等の標準語とも重なる）" },
  { word: "しゃべらねで", standard: "言わないで", dialect: "tohoku" },
  { word: "おばんです", standard: "こんばんは", dialect: "tohoku" },
  // 九州弁
  { word: "とっとーと", standard: "持っている", dialect: "kyushu" },
  { word: "ばってん", standard: "しかし", dialect: "kyushu" },
  { word: "よか", standard: "いい", dialect: "kyushu", before: PARTICLE_OR_SEP, after: /[\s\u3000、。，．,.！？!?よねばた]/ },
  { word: "やけん", standard: "だから", dialect: "kyushu" },
  { word: "しとっと", standard: "している", dialect: "kyushu" },
  // 名古屋弁
  { word: "だがや", standard: "だよ", dialect: "nagoya" },
  { word: "だでかん", standard: "だからダメ", dialect: "nagoya" },
  { word: "きしょい", standard: "気持ち悪い", dialect: "nagoya" },
  { word: "でら", standard: "とても", dialect: "nagoya", before: PARTICLE_OR_SEP, notAfter: /[れっらりん]/ },
  // 北海道弁
  { word: "なまら", standard: "とても", dialect: "hokkaido" },
  { word: "したっけ", standard: "したっけ", dialect: "hokkaido", ambiguous: true, note_ja: "北海道の「そうしたら・じゃあね」と標準語の「〜したかな」の両義" },
  { word: "しばれる", standard: "凍える", dialect: "hokkaido" },
];
// 長い語から先に照合する（「んだんだ」を「んだ」より先に、「ほんまに」を「ほんま」より先に）
const DIALECT_BY_LENGTH: DialectEntry[] = [...DIALECT_DICTIONARY].sort((a, b) => b.word.length - a.word.length);

interface DialectHit { index: number; entry: DialectEntry }

/** 語の境界の条件つきで辞書語を拾う（重ならない・左から・長い語優先） */
function scanDialect(text: string): DialectHit[] {
  const hits: DialectHit[] = [];
  let prevMatchEnd = -1;
  for (let i = 0; i < text.length; ) {
    let found: DialectEntry | null = null;
    for (const e of DIALECT_BY_LENGTH) {
      if (!text.startsWith(e.word, i)) continue;
      const prev = i === 0 ? '' : text.charAt(i - 1);
      const next = text.charAt(i + e.word.length);
      if (e.before && prev !== '' && prevMatchEnd !== i && !e.before.test(prev)) continue;
      if (e.after && next !== '' && !e.after.test(next)) continue;
      if (e.notAfter && next !== '' && e.notAfter.test(next)) continue;
      found = e;
      break;
    }
    if (found) {
      hits.push({ index: i, entry: found });
      i += found.word.length;
      prevMatchEnd = i;
    } else {
      i++;
    }
  }
  return hits;
}

// ───────────────────────────────────────────────
// 擬音語・擬態語辞書
// ───────────────────────────────────────────────

interface OnomatopoeiaEntry {
  word: string;
  /** この形で始まる出現は擬態語として数えない（熟語・慣用句） */
  except?: RegExp;
  category: OnomatopoeiaCategory;
  intensity: OnomatopoeiaHit["intensity"];
  translatedAction: string;
  actionSpec: ActionSpec[];
}

const ONOMATOPOEIA_DICTIONARY: OnomatopoeiaEntry[] = [
  // 速度系
  {
    word: "バッと",
    category: "speed",
    intensity: "strong",
    translatedAction: "即座に全画面表示",
    actionSpec: [
      { kind: "duration", specification: "アニメーション時間", measurable: "< 200ms" },
      { kind: "animation", specification: "フェードイン or スライド" },
    ],
  },
  {
    word: "パッと",
    // 「パッと見」（一見して）・「パッとしない」（冴えない）は速さの意味ではない
    except: /^パッと(見|しな|せ)/,
    category: "speed",
    intensity: "strong",
    translatedAction: "瞬時に表示 (アニメなし)",
    actionSpec: [
      { kind: "duration", specification: "アニメーション時間", measurable: "0ms (即表示)" },
    ],
  },
  {
    word: "ピッと",
    category: "responsiveness",
    intensity: "strong",
    translatedAction: "1回のクリック/タップで完了",
    actionSpec: [
      { kind: "interaction", specification: "単一アクションで完結" },
      { kind: "duration", specification: "フィードバック時間", measurable: "< 100ms" },
    ],
  },
  {
    word: "スッと",
    category: "smoothness",
    intensity: "moderate",
    translatedAction: "なめらかなアニメーションで表示",
    actionSpec: [
      { kind: "duration", specification: "アニメーション時間", measurable: "300-500ms" },
      { kind: "animation", specification: "ease-out イージング" },
    ],
  },
  {
    word: "サッと",
    category: "speed",
    intensity: "moderate",
    translatedAction: "軽快に表示",
    actionSpec: [{ kind: "duration", specification: "アニメーション時間", measurable: "250ms" }],
  },
  // なめらか系
  {
    word: "スルスル",
    category: "smoothness",
    intensity: "strong",
    translatedAction: "引っかからず連続スクロール",
    actionSpec: [
      { kind: "duration", specification: "60fps 維持" },
      { kind: "animation", specification: "慣性スクロール有効" },
    ],
  },
  {
    word: "しゃっきり",
    category: "visibility",
    intensity: "strong",
    translatedAction: "視覚的メリハリを付ける (コントラスト強化)",
    actionSpec: [
      { kind: "layout", specification: "コントラスト比 ≥ 7:1 (WCAG AAA)" },
      { kind: "layout", specification: "余白を統一" },
    ],
  },
  // 見やすさ系
  {
    word: "はっきり",
    category: "visibility",
    intensity: "strong",
    translatedAction: "文字・アイコンを大きく明瞭に",
    actionSpec: [
      { kind: "layout", specification: "フォントサイズ ≥ 16px" },
      { kind: "layout", specification: "コントラスト比 ≥ 4.5:1 (WCAG AA)" },
    ],
  },
  {
    word: "くっきり",
    category: "visibility",
    intensity: "strong",
    translatedAction: "境界を明確化",
    actionSpec: [{ kind: "layout", specification: "ボーダー 2px 以上 or 背景色差" }],
  },
  // 応答速度系
  {
    word: "キビキビ",
    category: "responsiveness",
    intensity: "strong",
    translatedAction: "全操作で即時応答",
    actionSpec: [
      { kind: "duration", specification: "UI応答時間", measurable: "< 100ms" },
      { kind: "priority", specification: "optimistic update" },
    ],
  },
  {
    word: "サクサク",
    category: "responsiveness",
    intensity: "moderate",
    translatedAction: "ストレスなく連続操作可能",
    actionSpec: [
      { kind: "duration", specification: "ページ遷移", measurable: "< 300ms" },
      { kind: "priority", specification: "Skeleton Loading" },
    ],
  },
  // 充実度系
  {
    word: "がっつり",
    category: "completeness",
    intensity: "strong",
    translatedAction: "機能を完全実装 (省略なし)",
    actionSpec: [{ kind: "priority", specification: "全MVP機能+エッジケース実装" }],
  },
  {
    word: "きっちり",
    category: "completeness",
    intensity: "strong",
    translatedAction: "仕様通り厳密に実装",
    actionSpec: [{ kind: "priority", specification: "バリデーション完備, エラー処理網羅" }],
  },
  {
    word: "ざっくり",
    category: "completeness",
    intensity: "mild",
    translatedAction: "骨組みのみ実装 (詳細後回し)",
    actionSpec: [{ kind: "priority", specification: "MVP最小セットのみ" }],
  },
  // 控えめ系
  {
    word: "ちょい",
    category: "subtlety",
    intensity: "mild",
    translatedAction: "軽微な調整",
    actionSpec: [{ kind: "priority", specification: "小さな変更のみ" }],
  },
  {
    word: "ちょこっと",
    category: "subtlety",
    intensity: "mild",
    translatedAction: "最小限の変更",
    actionSpec: [{ kind: "priority", specification: "破壊的変更なし" }],
  },
];

// ───────────────────────────────────────────────
// 方言推定
// ───────────────────────────────────────────────

export function detectDialect(text: string): Dialect {
  const hits: Record<Dialect, number> = {
    standard: 0,
    kansai: 0,
    tohoku: 0,
    kyushu: 0,
    nagoya: 0,
    hokkaido: 0,
  };
  for (const h of scanDialect(text)) {
    if (h.entry.ambiguous) continue; // 両義語は方言の根拠にしない
    hits[h.entry.dialect] += 1;
  }
  const max = Object.entries(hits).reduce(
    (acc, [k, v]) => (v > acc.v ? { k: k as Dialect, v } : acc),
    { k: "standard" as Dialect, v: 0 },
  );
  return max.v === 0 ? "standard" : max.k;
}

// ───────────────────────────────────────────────
// 方言→標準語変換
// ───────────────────────────────────────────────

export function normalizeToStandard(text: string): string {
  let out = "";
  let last = 0;
  for (const h of scanDialect(text)) {
    out += text.slice(last, h.index) + (h.entry.ambiguous ? h.entry.word : h.entry.standard);
    last = h.index + h.entry.word.length;
  }
  return out + text.slice(last);
}

/** 両義語（標準語でも使う語）を「要確認」として返す。置き換えはしない（REQ-JPO-LNG-014 の下準備） */
export function findAmbiguousDialect(text: string): Array<{ index: number; word: string; dialect: Dialect; note_ja: string }> {
  return scanDialect(text)
    .filter((h) => h.entry.ambiguous)
    .map((h) => ({ index: h.index, word: h.entry.word, dialect: h.entry.dialect, note_ja: h.entry.note_ja ?? "両義語のため要確認" }));
}

// ───────────────────────────────────────────────
// 擬音語検出
// ───────────────────────────────────────────────

export function findOnomatopoeia(text: string): OnomatopoeiaHit[] {
  const hits: OnomatopoeiaHit[] = [];
  for (const entry of ONOMATOPOEIA_DICTIONARY) {
    let counted = false;
    for (let at = text.indexOf(entry.word); at !== -1; at = text.indexOf(entry.word, at + 1)) {
      if (entry.except && entry.except.test(text.slice(at))) continue;
      counted = true;
      break;
    }
    if (counted) {
      hits.push({
        original: entry.word,
        category: entry.category,
        intensity: entry.intensity,
        translatedAction: entry.translatedAction,
      });
    }
  }
  return hits;
}

// ───────────────────────────────────────────────
// 一括パース (メインAPI)
// ───────────────────────────────────────────────

export function parseJapaneseIntent(rawText: string): ParsedIntent {
  const dialect = detectDialect(rawText);
  const normalizedText = normalizeToStandard(rawText);
  const onomatopoeiaList = findOnomatopoeia(rawText);

  const actionSpecs: ActionSpec[] = [];
  for (const hit of onomatopoeiaList) {
    const entry = ONOMATOPOEIA_DICTIONARY.find((e) => e.word === hit.original);
    if (entry) actionSpecs.push(...entry.actionSpec);
  }

  // 重複除去
  const uniqueSpecs = actionSpecs.filter(
    (s, i, arr) =>
      arr.findIndex((t) => t.kind === s.kind && t.specification === s.specification) === i,
  );

  // 信頼度 = 擬音語ヒット数 * 0.15 + 方言検出の明瞭度 * 0.3 + ベース 0.4
  const dialectConfidence = dialect === "standard" ? 0.3 : 0.15;
  const onomatoConfidence = Math.min(1.0, onomatopoeiaList.length * 0.15);
  const confidence = Math.min(1.0, 0.4 + dialectConfidence + onomatoConfidence);

  return {
    rawText,
    dialect,
    normalizedText,
    onomatopoeiaList,
    actionSpecs: uniqueSpecs,
    confidence,
  };
}

// ───────────────────────────────────────────────
// 敬語レベル自動調整
// ───────────────────────────────────────────────

export type HonorificLevel = "casual" | "polite" | "business" | "executive";

export interface HonorificAdjustResult {
  original: string;
  adjusted: string;
  level: HonorificLevel;
}

/** 業種・役職からふさわしい敬語レベルを判定 */
export function recommendHonorificLevel(params: {
  industry?: string;
  audience?: "colleague" | "customer" | "partner" | "executive" | "public";
}): HonorificLevel {
  const { industry, audience } = params;
  if (audience === "executive") return "executive";
  if (audience === "public" || audience === "customer") return "business";
  if (industry === "finance" || industry === "public_sector" || industry === "healthcare") {
    return "business";
  }
  if (audience === "partner") return "business";
  if (audience === "colleague") return "polite";
  return "polite";
}

/**
 * 敬語レベルで文章を変換（原文を壊さない範囲だけ）
 *
 * ★2026-09-30 REQ-JPO-FIX-006: 以前は文中のどこでも一括置換し、主語を見ずに謙譲語・尊敬語を当てていた
 *   （「社長が来る」→「社長がお越しいただきます」＝他者の行為に謙譲語Ⅰ、executive で「ご臨席賜ります」＝意味が変わる、
 *    「資料を確認するため送る」→「資料をご確認いたしますためお送りいたします」＝従属節に「ます」、
 *    executive で「確認」→「拝見」、「行く」→「参上いたします」）。
 *   出典: 文化審議会答申「敬語の指針」（平成19年2月2日）第2章 第1 — 尊敬語は相手側・第三者の行為、謙譲語は自分側の行為。
 * 決まり:
 *   - 変えるのは【文末の動詞】だけ（句点・感嘆符・疑問符の直前、または文字列の末尾）。
 *   - casual は変えない。polite は丁寧語（ます）だけ。
 *   - business・executive は、opts.subject で「誰の行為か」が分かるときだけ謙譲語（self）・尊敬語（other）にする。
 *     分からないときは丁寧語にとどめる（壊すくらいなら変換しない）。
 */
const HONORIFIC_VERBS: Array<{ plain: string; polite: string; humble: string; humbleExec: string; respectful: string }> = [
  { plain: "送る", polite: "送ります", humble: "お送りいたします", humbleExec: "お送り申し上げます", respectful: "お送りになります" },
  { plain: "見る", polite: "見ます", humble: "拝見します", humbleExec: "拝見いたします", respectful: "ご覧になります" },
  { plain: "言う", polite: "言います", humble: "申し上げます", humbleExec: "申し上げます", respectful: "おっしゃいます" },
  { plain: "もらう", polite: "もらいます", humble: "いただきます", humbleExec: "頂戴いたします", respectful: "お受け取りになります" },
  { plain: "来る", polite: "来ます", humble: "参ります", humbleExec: "参ります", respectful: "いらっしゃいます" },
  { plain: "行く", polite: "行きます", humble: "伺います", humbleExec: "伺います", respectful: "いらっしゃいます" },
];

function adjustSentenceEnd(body: string, level: HonorificLevel, subject?: "self" | "other"): string {
  const form: "polite" | "humble" | "humbleExec" | "respectful" =
    level === "polite" || !subject ? "polite"
      : subject === "other" ? "respectful"
        : level === "executive" ? "humbleExec" : "humble";
  // 漢語・カタカナ語＋「する」（確認する・連絡する 等）
  const suru = body.match(/([\u4E00-\u9FFF\u3005\u30A0-\u30FF])する$/);
  if (suru) {
    const tail = { polite: "します", humble: "いたします", humbleExec: "いたします", respectful: "なさいます" }[form];
    return body.slice(0, -2) + tail;
  }
  for (const v of HONORIFIC_VERBS) {
    if (body.endsWith(v.plain)) return body.slice(0, body.length - v.plain.length) + v[form];
  }
  return body;
}

export function adjustHonorific(
  text: string,
  level: HonorificLevel,
  opts: { subject?: "self" | "other" } = {},
): HonorificAdjustResult {
  if (level === "casual") return { original: text, adjusted: text, level };
  const src = String(text ?? "");
  let adjusted = "";
  const re = /([^。！？!?\n]*)([。！？!?\n]|$)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(src)) !== null) {
    if (m[0] === "") { re.lastIndex++; if (re.lastIndex > src.length) break; continue; }
    adjusted += adjustSentenceEnd(m[1], level, opts.subject) + m[2];
  }
  return { original: text, adjusted, level };
}

// ───────────────────────────────────────────────
// ユーティリティ
// ───────────────────────────────────────────────

/** BOOST から呼び出される便利関数: テキストからParseResult + 推奨アクション仕様を返す */
export function explainIntent(rawText: string): {
  parsed: ParsedIntent;
  humanReadableExplanation: string;
} {
  const parsed = parseJapaneseIntent(rawText);
  let explanation = `# 意図解釈\n\n`;
  explanation += `**原文**: ${parsed.rawText}\n\n`;
  if (parsed.dialect !== "standard") {
    explanation += `**検出方言**: ${parsed.dialect}\n**標準語化**: ${parsed.normalizedText}\n\n`;
  }
  if (parsed.onomatopoeiaList.length > 0) {
    explanation += `**擬音語・擬態語**:\n`;
    for (const hit of parsed.onomatopoeiaList) {
      explanation += `- \`${hit.original}\` (${hit.category}, ${hit.intensity}) → ${hit.translatedAction}\n`;
    }
    explanation += "\n";
  }
  if (parsed.actionSpecs.length > 0) {
    explanation += `**具体動作仕様**:\n`;
    for (const spec of parsed.actionSpecs) {
      explanation += `- [${spec.kind}] ${spec.specification}${spec.measurable ? ` (${spec.measurable})` : ""}\n`;
    }
    explanation += "\n";
  }
  explanation += `**信頼度**: ${(parsed.confidence * 100).toFixed(0)}%\n`;
  return { parsed, humanReadableExplanation: explanation };
}
