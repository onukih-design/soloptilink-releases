/**
 * energy.ts — Phase 23 エネルギー
 *
 * カバレッジ:
 *   - FIT/FIP (再エネ特措法): 調達価格・FIP プレミアム計算
 *   - RE100 / SBT / TCFD 適合
 *   - J-クレジット (吸収/削減プロジェクト)
 *   - 省エネ法 (エネルギー使用合理化法 / 特定事業者 1,500kL/年)
 *   - 温対法 (温室効果ガス排出量算定・報告・公表制度 / SHK 制度)
 *   - 高度化法 (非化石電源比率 44% 2030)
 *   - カーボンプライシング (GX-ETS / 排出量取引)
 *   - 電気事業法 (一般送配電/小売電気事業者/発電事業者 区分)
 *
 * 主要 export:
 *   - FIT_PRICES_2024 / calcFitRevenue
 *   - FIP_REFERENCE_PRICES_2024 / calcFipPremium
 *   - SBT_TARGET_TYPES / isSbtEligible
 *   - JCREDIT_METHODOLOGIES / calcJCreditEmissionReduction
 *   - SHOENE_LAW_THRESHOLDS / isShoeneSpecifiedBusiness / requireSHKReport
 *   - SHK_EMISSION_FACTORS / calcCo2EmissionsTonnes
 *   - GX_ETS_PHASES / estimateCarbonCost
 *   - ELECTRICITY_BUSINESS_KINDS / classifyElectricityBusiness
 *
 * 法定値 (調達価格・閾値・排出係数) は lib/japan/env_energy_legal_values.ts の値表 (出典・基準日・取得日つき) から読む。
 * ここに同じ値の写しを書かない (REQ-171)。
 */

import { requireEnvEnergyLegalNumber as legalNumber } from './env_energy_legal_values';

// ===== FIT (Feed-in Tariff) =====

export type FitCategory =
  | 'solar_residential_10kw_under'
  | 'solar_business_10_50kw'
  | 'solar_business_50_250kw'
  | 'wind_onshore_under_50kw'
  | 'wind_onshore_50kw_over'
  | 'wind_offshore'
  | 'hydro_under_200kw'
  | 'hydro_200_1000kw'
  | 'biomass_woody_under_2000kw'
  | 'geothermal_under_15000kw';

/**
 * 2024年度 FIT 調達価格 (円/kWh)。値は値表 (資源エネルギー庁「買取価格・期間等」2024年度の価格表・2026-10-03 取得) の転記値。
 *   ★旧版の陸上風力50kW未満19円・陸上風力50kW以上17円・洋上風力18円は一次資料と違っていた (2024年度: 50kW未満14円・50kW以上と着床式洋上は入札)。
 *   入札で価格が決まる区分は固定の価格を持たない (FIT_AUCTION_CATEGORIES_2024)。
 */
export const FIT_PRICES_2024: Partial<Record<FitCategory, number>> = {
  solar_residential_10kw_under: legalNumber('fit.2024.solar_residential_10kw_under'),
  solar_business_10_50kw: legalNumber('fit.2024.solar_business_10_50kw'),
  solar_business_50_250kw: legalNumber('fit.2024.solar_business_50_250kw'),
  wind_onshore_under_50kw: legalNumber('fit.2024.wind_onshore_under_50kw'),
  hydro_under_200kw: legalNumber('fit.2024.hydro_under_200kw'),
  hydro_200_1000kw: legalNumber('fit.2024.hydro_200_1000kw'),
  biomass_woody_under_2000kw: legalNumber('fit.2024.biomass_woody_under_2000kw'),
  geothermal_under_15000kw: legalNumber('fit.2024.geothermal_under_15000kw'),
};

export const FIT_PROCUREMENT_PERIOD_YEARS: Partial<Record<FitCategory, number>> = {
  solar_residential_10kw_under: legalNumber('fit.2024.period.solar_residential_10kw_under'),
  solar_business_10_50kw: legalNumber('fit.2024.period.default'),
  solar_business_50_250kw: legalNumber('fit.2024.period.default'),
  wind_onshore_under_50kw: legalNumber('fit.2024.period.default'),
  hydro_under_200kw: legalNumber('fit.2024.period.default'),
  hydro_200_1000kw: legalNumber('fit.2024.period.default'),
  biomass_woody_under_2000kw: legalNumber('fit.2024.period.default'),
  geothermal_under_15000kw: legalNumber('fit.2024.period.geothermal'),
};

/** 2024年度に入札制度で価格が決まる区分 (固定の調達価格を持たない)。調達期間は20年間 */
export const FIT_AUCTION_CATEGORIES_2024: Partial<Record<FitCategory, { periodYears: number; note: string }>> = {
  wind_onshore_50kw_over: { periodYears: legalNumber('fit.2024.period.default'), note: '陸上風力50kW以上は入札制度で決定 (2024年度 第4回 14円)。落札価格で計算してください' },
  wind_offshore: { periodYears: legalNumber('fit.2024.period.default'), note: '着床式洋上風力は入札制度で決定 (浮体式は36円)。落札価格・区分を確認してください' },
};

/** FIT_PRICES_2024 が当てはまる認定年度 (調達価格は認定を受けた年度の価格で固定される) */
export const FIT_PRICES_FISCAL_YEAR = 2024;

/**
 * 単純な FIT 売電収入計算 (税抜)
 *   調達価格は認定年度ごとに違う。この部品が持つのは2024年度の表だけなので、2024年度以外の認定年度を渡されたら
 *   2024年度の価格で計算せず status='unsupported' を返す (要一次確認: 他の年度の調達価格は経済産業省の告示から転記してから使う)。
 *   認定年度を渡さない呼び出しは互換のため2024年度の表で計算する (年度は FIT_PRICES_FISCAL_YEAR)。
 */
export function calcFitRevenue(p: {
  category: FitCategory;
  generatedKwh: number;
  /** 認定を受けた年度 (省略時は2024年度の表で計算) */
  certifiedFiscalYear?: number;
}): { revenueJpy: number | null; periodYears: number; priceFiscalYear?: number; status?: 'unsupported'; reason?: string } {
  const price = FIT_PRICES_2024[p.category];
  const auction = FIT_AUCTION_CATEGORIES_2024[p.category];
  const periodYears = (FIT_PROCUREMENT_PERIOD_YEARS[p.category] ?? auction?.periodYears) as number;
  if (price === undefined) {
    return {
      revenueJpy: null,
      periodYears,
      priceFiscalYear: FIT_PRICES_FISCAL_YEAR,
      status: 'unsupported',
      reason: auction ? `${auction.note}` : `区分 ${p.category} の調達価格を値表に持っていないため計算できません`,
    };
  }
  if (p.certifiedFiscalYear !== undefined && p.certifiedFiscalYear !== FIT_PRICES_FISCAL_YEAR) {
    return {
      revenueJpy: null,
      periodYears,
      priceFiscalYear: FIT_PRICES_FISCAL_YEAR,
      status: 'unsupported',
      reason: `${p.certifiedFiscalYear}年度認定の調達価格をこの部品は持っていないため計算できません (持っているのは${FIT_PRICES_FISCAL_YEAR}年度の表だけ)。経済産業省の告示で確認してください`,
    };
  }
  // 認定年度を渡さない呼び出しは互換のため2024年度の表 (FIT_PRICES_FISCAL_YEAR) で計算する
  // 1円未満切り捨て。浮動小数の誤差 (例: 4.1999…×1000) で1円少なくならないよう、ごく小さい幅を足してから切り捨てる
  return { revenueJpy: Math.floor(p.generatedKwh * price + 1e-7), periodYears };
}

// ===== FIP (Feed-in Premium) =====

/**
 * FIP 基準価格 (2024年度)。値表の転記値だけを持つ。
 * プレミアム = 基準価格 - 参照価格 (市場連動)。
 *   ★旧版の陸上風力14.0・洋上風力11.99 (落札例)・バイオマス27 は一次資料で確かめられない値だったため外した。
 *     基準価格を持たない区分は 0 円と status='unverified' を返す (0 は「プレミアムなし」ではなく「計算していない」)。
 */
export const FIP_REFERENCE_PRICES_2024: Partial<Record<FitCategory, number>> = {
  solar_business_50_250kw: legalNumber('fip.2024.solar_business_50_250kw'),
};

export function calcFipPremium(p: {
  category: FitCategory;
  marketPriceYenPerKwh: number;
  generatedKwh: number;
}): { premiumYenPerKwh: number; totalPremiumJpy: number; status?: 'unverified'; reason?: string } {
  const ref = FIP_REFERENCE_PRICES_2024[p.category];
  if (ref === undefined) {
    return {
      premiumYenPerKwh: 0,
      totalPremiumJpy: 0,
      status: 'unverified',
      reason: `区分 ${p.category} の FIP 基準価格は一次資料から転記していないため計算していません (入札区分は落札価格を確認してください)`,
    };
  }
  // FIP プレミアムは原則 max(基準 - 参照, 0)
  // 円/kWh の差は小数第8位で丸める (9.2−5 = 4.1999… を 4.2 に戻す。旧版は 1,000kWh で 4,199円と1円少なかった)
  const premiumPerKwh = Math.round(Math.max(ref - p.marketPriceYenPerKwh, 0) * 1e8) / 1e8;
  return {
    premiumYenPerKwh: premiumPerKwh,
    totalPremiumJpy: Math.floor(premiumPerKwh * p.generatedKwh + 1e-7),
  };
}

// ===== SBT (Science Based Targets) / RE100 / TCFD =====

export type SbtTargetType = 'NearTerm' | 'NetZero' | 'SBTi_FLAG';

export const SBT_TARGET_TYPES: Record<SbtTargetType, string> = {
  NearTerm: '5-10年でScope1+2 を 1.5℃整合 (年4.2%減 等)',
  NetZero: '2050年までに Scope1+2+3 を 90%以上削減 + 残余を除去',
  SBTi_FLAG: 'Forest, Land, Agriculture セクター向け追加要件',
};

export interface SbtSubmission {
  baselineYear: number;
  targetYear: number;
  scope1ReductionPct: number;
  scope2ReductionPct: number;
  scope3ReductionPct?: number;
  /** Scope3 が排出全体の 40% 超なら Scope3 目標必須 */
  scope3SharePct: number;
}

export function isSbtEligible(s: SbtSubmission): { eligible: boolean; reasons: string[] } {
  const r: string[] = [];
  const yearGap = s.targetYear - s.baselineYear;
  if (yearGap < 5 || yearGap > 10) r.push('近期目標は基準年から5-10年');
  // 1.5℃整合: 年 4.2% 直線減 → 5年で約 21%
  const requiredMin = yearGap * 4.2;
  if (s.scope1ReductionPct < requiredMin || s.scope2ReductionPct < requiredMin)
    r.push(`Scope1/2 削減率が1.5℃整合に不足 (要 ${requiredMin.toFixed(1)}%以上)`);
  if (s.scope3SharePct >= 40 && (s.scope3ReductionPct ?? 0) <= 0)
    r.push('Scope3 排出が40%超のためScope3目標必須');
  return { eligible: r.length === 0, reasons: r };
}

// ===== J-クレジット =====

export type JCreditMethodology =
  | 'EN-S-001' // 太陽光発電
  | 'EN-S-016' // バイオマス熱利用
  | 'FO-001' // 森林経営活動
  | 'AG-001' // 茶園における中切り更新
  | 'WA-001' // 廃棄物の埋立処分量削減
  ;

export const JCREDIT_METHODOLOGIES: Record<JCreditMethodology, { kind: 'reduction' | 'absorption'; label: string }> = {
  'EN-S-001': { kind: 'reduction', label: '太陽光発電による系統電力代替' },
  'EN-S-016': { kind: 'reduction', label: 'バイオマス熱利用 (チップ/ペレット等)' },
  'FO-001': { kind: 'absorption', label: '森林経営活動による吸収量' },
  'AG-001': { kind: 'reduction', label: '茶園中切り更新によるN2O削減' },
  'WA-001': { kind: 'reduction', label: '廃棄物の埋立処分量削減' },
};

/** ベースライン排出 - プロジェクト排出 = 削減量 (t-CO2) */
export function calcJCreditEmissionReduction(p: {
  methodology: JCreditMethodology;
  baselineEmissionTCo2: number;
  projectEmissionTCo2: number;
}): { reductionTCo2: number; fee?: number } {
  const reduction = Math.max(p.baselineEmissionTCo2 - p.projectEmissionTCo2, 0);
  // 認証手数料: 削減量 × 数百円相当 (公募/制度で変動) — 試算値として 500 円/t
  return { reductionTCo2: reduction, fee: reduction * 500 };
}

// ===== 省エネ法 (エネルギー使用合理化法) =====

export const SHOENE_LAW_THRESHOLDS = {
  /** 特定事業者: 全社のエネルギー使用量が 1,500 kL (原油換算) 以上 (省エネ法施行令2条1項・値表 shoene.specified_business_kl) */
  specifiedBusinessKl: legalNumber('shoene.specified_business_kl'),
  /** 特定連鎖化事業者: フランチャイズ加盟店合算で 1,500 kL 以上 */
  specifiedChainKl: legalNumber('shoene.specified_business_kl'),
  /** 中長期計画書の年率改善目標 */
  annualImprovementPct: 1.0,
} as const;

export function isShoeneSpecifiedBusiness(annualEnergyUseKl: number): boolean {
  return annualEnergyUseKl >= SHOENE_LAW_THRESHOLDS.specifiedBusinessKl;
}

// ===== 温対法 SHK 制度 (温室効果ガス算定・報告・公表) =====

/**
 * 燃料1単位あたりの CO2 (kg-CO2)。算定省令 別表第一の 単位発熱量 (GJ/kL・GJ/t) × 排出係数 (tC/GJ) × 44/12 から計算する
 *   (値は値表 shk.fuel.* の転記値。kL あたり t-CO2 = L あたり kg-CO2)。
 *   ★旧版のガソリン2.32・灯油2.49・A重油2.71 は別表第一 (2026-04-01 版) と合わなかった。
 * 電気・都市ガスは法定の単一値が無い (電気事業者別・ガス事業者別の公表係数) ため、下の2つは「参考値」であり法定値ではない。
 *   報告に使う計算は env_energy_compliance.ts の calcShkEnergyCo2 (事業者別の係数を渡さないと計算しない) を使うこと。
 */
const fuelKgPerUnit = (k: string) => legalNumber(`shk.fuel.${k}.heat_gj`) * legalNumber(`shk.fuel.${k}.carbon_tc_per_gj`) * legalNumber('shk.co2_per_carbon');
export const SHK_EMISSION_FACTORS = {
  /** 電力 kWh あたり kg-CO2 — ★参考値 (法定の単一値は無い。電気事業者別の公表係数を使うこと) */
  electricity_kwh_kgco2: 0.434,
  /** 都市ガス Nm3 あたり kg-CO2 — ★参考値 (算定省令2条3項: ガス事業者ごとの公表係数を使うこと) */
  city_gas_nm3_kgco2: 2.234,
  /** 軽油 L あたり kg-CO2 (別表第一 一七 軽油 38.0 GJ/kL × 0.0188 tC/GJ × 44/12) */
  diesel_l_kgco2: fuelKgPerUnit('diesel'),
  /** ガソリン L あたり kg-CO2 (別表第一 一三 揮発油 33.4 × 0.0187 × 44/12) */
  gasoline_l_kgco2: fuelKgPerUnit('gasoline'),
  /** 灯油 L あたり kg-CO2 (別表第一 一六 灯油 36.5 × 0.0187 × 44/12) */
  kerosene_l_kgco2: fuelKgPerUnit('kerosene'),
  /** A 重油 L あたり kg-CO2 (別表第一 一八 Ａ重油 38.9 × 0.0193 × 44/12) */
  heavy_oil_a_l_kgco2: fuelKgPerUnit('heavy_oil_a'),
  /** LPG kg あたり kg-CO2 (別表第一 二一 ＬＰＧ 50.1 GJ/t × 0.0163 × 44/12) */
  lpg_kg_kgco2: fuelKgPerUnit('lpg'),
} as const;

export interface EnergyConsumption {
  electricityKwh?: number;
  cityGasNm3?: number;
  dieselL?: number;
  gasolineL?: number;
  keroseneL?: number;
  heavyOilAL?: number;
  lpgKg?: number;
}

/**
 * Scope1 + Scope2 (場所基準) の年間排出量の概算を t-CO2 で返す。Scope2 マーケット基準は契約電源係数で別途。
 *   ★電気・都市ガスは参考値の係数で計算する概算。温対法の報告値には使わず、calcShkEnergyCo2 (env_energy_compliance.ts) を使うこと。
 */
export function calcCo2EmissionsTonnes(c: EnergyConsumption): number {
  let kg = 0;
  kg += (c.electricityKwh ?? 0) * SHK_EMISSION_FACTORS.electricity_kwh_kgco2;
  kg += (c.cityGasNm3 ?? 0) * SHK_EMISSION_FACTORS.city_gas_nm3_kgco2;
  kg += (c.dieselL ?? 0) * SHK_EMISSION_FACTORS.diesel_l_kgco2;
  kg += (c.gasolineL ?? 0) * SHK_EMISSION_FACTORS.gasoline_l_kgco2;
  kg += (c.keroseneL ?? 0) * SHK_EMISSION_FACTORS.kerosene_l_kgco2;
  kg += (c.heavyOilAL ?? 0) * SHK_EMISSION_FACTORS.heavy_oil_a_l_kgco2;
  kg += (c.lpgKg ?? 0) * SHK_EMISSION_FACTORS.lpg_kg_kgco2;
  return kg / 1000; // → t-CO2
}

/**
 * SHK (温対法 算定・報告・公表制度) の報告対象か。
 *   エネルギー起源CO2: 全事業所のエネルギー使用量が原油換算1,500kL/年以上
 *   その他のガス: ガスの種類ごとにCO2換算3,000t以上 かつ 常時使用する従業員21人以上
 *   出典: 環境省 SHK制度 制度概要 https://policies.env.go.jp/earth/ghg-santeikohyo/about.html
 *   ★CO2のトン数 (数値) だけを渡された場合は判定できないため null を返す (旧版は「エネルギー起源CO2で3,000t」と誤っていた)。
 */
export function requireSHKReport(
  p: number | { energyKlOilEquivalent?: number; nonEnergyGhgByGasTCo2?: Record<string, number>; employees?: number },
): boolean | null {
  if (typeof p === 'number') return null;
  const kl = legalNumber('shk.energy_threshold_kl');
  const perGas = legalNumber('shk.per_gas_threshold_t');
  const minEmp = legalNumber('shk.min_employees');
  if ((p.energyKlOilEquivalent ?? 0) >= kl) return true;
  const gases = p.nonEnergyGhgByGasTCo2;
  if (gases && typeof p.employees === 'number') {
    return p.employees >= minEmp && Object.values(gases).some((v) => v >= perGas);
  }
  if (gases && Object.values(gases).some((v) => v >= perGas)) return null; // 従業員数が無いと判定できない
  return p.energyKlOilEquivalent !== undefined ? false : null;
}

// ===== GX-ETS (排出量取引) =====

/**
 * 排出量取引制度 (GX-ETS) の段階
 *   出典: 経済産業省「排出量取引制度」https://www.meti.go.jp/policy/energy_environment/global_warming/ets.html (最終更新 2026-09-30)
 *   2026年度から GX推進法に基づき義務化。CO2の直接排出量が前年度までの3年度平均で10万t以上の事業者が対象。
 *   政府が排出枠を割り当て、毎年度、排出実績量と同量の排出枠を期限までに保有する義務。届出・移行計画は ERMS で提出。
 *   届出は毎年度9月末日まで (施行規則10条1項・2026年度も2026-09-30)。発電事業者 (特定事業者) への有償割当は令和十五年度 (2033年度) から (法27条1項)。
 *   (2026-10-03 に e-Gov で確認。期限の一覧は env_energy_compliance.ts の getGxEtsSchedule)
 */
export const GX_ETS_PHASES = {
  /** 2023-2025年度: GXリーグでの試行 (任意参加・自主目標) */
  phase1: { fromYear: 2023, toYear: 2025, mandatory: false },
  /** 2026年度-: 排出量取引制度の義務化 (直接排出量の3年度平均10万t以上・排出枠の割当と保有義務) */
  phase2: { fromYear: 2026, toYear: 2032, mandatory: true },
  /** 2033年度-: 発電事業者 (特定事業者) への排出枠の有償割当 (GX推進法27条1項「令和十五年度から」) */
  phase3: { fromYear: 2033, toYear: 9999, mandatory: true },
} as const;

/** 排出量取引制度の対象となる直接排出量の基準 (前年度までの3年度平均・t-CO2)。GX推進法施行令2条 (値表 gx.threshold_t) */
export const GX_ETS_THRESHOLD_TCO2 = legalNumber('gx.threshold_t');

/** 排出量取引制度 (2026年度〜) の対象か: CO2の直接排出量の前年度までの3年度平均が10万t以上 */
export function isGxEtsCovered(threeYearAvgDirectCo2T: number): boolean {
  return threeYearAvgDirectCo2T >= GX_ETS_THRESHOLD_TCO2;
}

export function estimateCarbonCost(p: {
  emissionsTCo2: number;
  /**
   * カーボンプライス (円/t-CO2) — 利用者が与える試算用の単価。法定の価格ではない。
   * 排出量取引制度の未償却相当負担金は env_energy_compliance.ts の calcGxEtsUnsurrenderedBurden (告示の参考上限取引価格×1.1) を使うこと。
   */
  pricePerTCo2: number;
}): number {
  return Math.floor(p.emissionsTCo2 * p.pricePerTCo2);
}

// ===== 電気事業法 =====

export type ElectricityBusinessKind =
  | 'general_transmission_distribution'
  | 'retail_electricity'
  | 'power_generation'
  | 'specified_transmission'
  | 'specified_supply';

export const ELECTRICITY_BUSINESS_KINDS: Record<ElectricityBusinessKind, string> = {
  general_transmission_distribution: '一般送配電事業者 (10エリア+OCCTO接続)',
  retail_electricity: '小売電気事業者 (登録制)',
  power_generation: '発電事業者 (届出制 1万kW以上)',
  specified_transmission: '特定送配電事業者 (限定エリア配電)',
  specified_supply: '特定供給 (自家発電→グループ会社供給)',
};

export interface ElectricityBusinessProfile {
  hasRetailContracts: boolean;
  generationCapacityKw: number;
  ownsTransmissionLines: boolean;
  isAreaWide: boolean;
}

export function classifyElectricityBusiness(p: ElectricityBusinessProfile): ElectricityBusinessKind[] {
  const k: ElectricityBusinessKind[] = [];
  if (p.hasRetailContracts) k.push('retail_electricity');
  if (p.generationCapacityKw >= 10_000) k.push('power_generation');
  if (p.ownsTransmissionLines && p.isAreaWide) k.push('general_transmission_distribution');
  if (p.ownsTransmissionLines && !p.isAreaWide) k.push('specified_transmission');
  return k;
}

/** 高度化法: 小売電気事業者は 2030 年までに販売電力量の 44% 以上を非化石電源化 */
export const KODOKA_LAW_2030_NONFOSSIL_PCT = 44;
export function checkKodokaCompliance(nonFossilSharePct: number): boolean {
  return nonFossilSharePct >= KODOKA_LAW_2030_NONFOSSIL_PCT;
}
