/**
 * SoloptiLinkAI Phase 22 — 公益通報者保護法対応 (2026-10-17 書き直し: 台帳 L-03・L-12)
 *
 * 公益通報者保護法 (平成16年法律第122号)。令和2年改正 (令和2年法律第51号・2022-06-01 施行) の今の法律と、
 * 令和7年改正 (令和7年法律第62号・2026-12-01 施行) を基準日 asOf (省略時は日本時間の今日) で切り替える。
 *   〜2026-11-30: e-Gov 416AC0000000122_20260717_508AC0000000062
 *                (2026-11-02〜11-30 は 416AC0000000122_20261102_508AC0000000062。第2条第4項に防災庁を加えるだけで、部品が引く条は同じ)
 *   2026-12-01〜: e-Gov 416AC0000000122_20261201_507AC0000000062
 * 条番号・罰則・保護の範囲は値表 WHISTLEBLOWER_LEGAL_VALUES に1か所で持ち、関数はそこを読む。
 * 既存の関数名・引数の順は変えず、省略可能な引数と省略可能な項目だけを足している。
 *
 * カバー範囲 (R2 = 〜2026-11-30 / R7 = 2026-12-01〜):
 *  - 公益通報対応業務従事者を定める義務: 第11条第1項
 *  - 内部公益通報に応じる体制の整備: 第11条第2項 (R7 は「労働者等に対するその周知」を含む)
 *  - 常時使用する労働者の数が300人以下の事業者は努力義務: 第11条第3項
 *  - 従事者の守秘義務: 第12条 (罰則 R2 第21条 / R7 第22条・30万円以下の罰金)
 *  - 労働者: R2 第3条 (解雇の無効)・第5条第1項 (不利益取扱いの禁止)
 *            R7 第3条第1項 (解雇その他不利益な取扱いの禁止)・第2項 (解雇・懲戒の無効)・第3項 (1年以内の解雇・懲戒の推定)
 *  - 派遣労働者: R2 第4条・第5条第2項 / R7 第4条
 *  - 役員: R2 第5条第3項・第6条 / R7 第6条
 *  - フリーランス (特定受託業務従事者): R7 第2条第1項第3号・第5条 (R2 は公益通報者に当たらない)
 *  - 通報妨害の禁止 (R7 第11条の2)・通報者探索の禁止 (R7 第11条の3)
 *  - 通報を理由とする解雇・懲戒の刑事罰: R7 第21条第1項・第23条 (施行前の行為には適用しない・附則第7条)
 *  - 通報先ごとの保護の条件: R2 第3条第1号〜第3号 / R7 第3条第1項第1号〜第3号 (中身は同じ・番号だけ変わる)
 * 経過措置 (令和7年法律第62号 附則第2条・第3条・第5条・第7条) は値表 transitional_ja。
 * ★解釈が分かれうる点 (施行前のフリーランスの通報・「1年以内」の数え方) は needs_confirmation に書き、断定しない。
 */

/** 令和7年改正 (令和7年法律第62号) の施行日。e-Gov 416AC0000000122_20261201_507AC0000000062 */
export const KOEKI_TSUHO_R7_EFFECTIVE = "2026-12-01";
/** 令和7年改正の施行前の準備を知らせ始める日 (施行の90日前) */
const KOEKI_TSUHO_R7_PREP_FROM = "2026-09-02";
export type KoekiTsuhoVersion = "R2" | "R7";

/** 値表 (法令の値の唯一の置き場)。2026-10-17 に e-Gov の2つの版の本文と附則で照合 */
export const WHISTLEBLOWER_LEGAL_VALUES = {
  checked_on: "2026-10-17",
  law: "公益通報者保護法",
  law_number: "平成16年法律第122号",
  law_id: "416AC0000000122",
  employee_threshold: 300, // 常時使用する労働者の数が300人以下は努力義務 (第11条第3項)
  versions: {
    R2: { label_ja: "令和2年改正法 (令和2年法律第51号)", effective_from: "2022-06-01", effective_to: "2026-11-30", egov_revision_id: "416AC0000000122_20260717_508AC0000000062", also_ja: "2022-06-01 の版 416AC0000000122_20220601_502AC0000000051 で施行。2026-11-02〜11-30 は 416AC0000000122_20261102_508AC0000000062 (第2条第4項に防災庁を加えるだけ・部品が引く条は同じ)" },
    R7: { label_ja: "令和7年改正法 (令和7年法律第62号)", effective_from: "2026-12-01", effective_to: null, egov_revision_id: "416AC0000000122_20261201_507AC0000000062" },
  },
  articles: {
    R2: {
      internal: "第3条第1号",
      administrative: "第3条第2号",
      external: "第3条第3号",
      worker_dismissal: "第3条 (解雇の無効)",
      worker_disadvantage: "第5条第1項 (不利益取扱いの禁止)",
      dispatch_termination: "第4条 (労働者派遣契約の解除の無効)",
      dispatch_disadvantage: "第5条第2項 (派遣労働者の交代を求めることその他不利益な取扱いの禁止)",
      officer_disadvantage: "第5条第3項 (役員に対する報酬の減額その他不利益な取扱いの禁止)",
      officer_dismissal: "第6条 (解任による損害の賠償請求)",
      freelance: null,
      handler: "第11条第1項 (公益通報対応業務従事者を定める義務)",
      system: "第11条第2項 (体制の整備その他の必要な措置)",
      small: "第11条第3項 (常時使用する労働者の数が300人以下は努力義務)",
      obstruction: null,
      search: null,
      confidentiality: "第12条",
      confidentiality_penalty: "第21条 (30万円以下の罰金)",
      admin: "第15条 (報告の徴収・助言・指導・勧告)・第16条 (勧告に従わない場合の公表)",
      report_penalty: "第22条 (第15条の報告をしない・虚偽の報告 = 20万円以下の過料)",
      presumption: null,
      disadvantage_penalty: null,
      order_penalty: null,
    },
    R7: {
      internal: "第3条第1項第1号",
      administrative: "第3条第1項第2号",
      external: "第3条第1項第3号",
      worker_dismissal: "第3条第2項 (解雇・懲戒の無効)",
      worker_disadvantage: "第3条第1項 (解雇その他不利益な取扱いの禁止)",
      dispatch_termination: "第4条第1項第1号・第2項 (労働者派遣契約の解除の禁止・無効)",
      dispatch_disadvantage: "第4条第1項第2号 (派遣労働者の交代を求めることその他不利益な取扱いの禁止)",
      officer_disadvantage: "第6条第1項 (役員に対する報酬の減額その他不利益な取扱いの禁止)",
      officer_dismissal: "第6条第2項 (解任による損害の賠償請求)",
      freelance: "第2条第1項第3号・第5条 (特定受託事業者に対する不利益取扱いの禁止)",
      handler: "第11条第1項 (公益通報対応業務従事者を定める義務)",
      system: "第11条第2項 (体制の整備・労働者等に対するその周知その他の必要な措置)",
      small: "第11条第3項 (常時使用する労働者の数が300人以下は努力義務)",
      obstruction: "第11条の2 (通報妨害の禁止・違反する合意等は無効)",
      search: "第11条の3 (通報者探索の禁止)",
      confidentiality: "第12条",
      confidentiality_penalty: "第22条 (30万円以下の罰金)",
      admin: "第15条 (助言・指導)・第15条の2 (勧告・命令・公表)・第16条 (報告・立入検査)",
      report_penalty: "第24条 (第16条第2項の報告をしない・虚偽の報告 = 20万円以下の過料)",
      presumption: "第3条第3項 (通報の日から1年以内の解雇・懲戒は通報を理由とするものと推定。2号・3号通報を知って行った場合は事業者が知った日から1年)",
      disadvantage_penalty: "第21条第1項 (通報を理由とする解雇・懲戒 = 6月以下の拘禁刑又は30万円以下の罰金)・第23条第1項第1号 (法人 3,000万円以下の罰金)",
      order_penalty: "第21条第2項 (命令違反・報告拒否・虚偽報告・検査拒否 = 30万円以下の罰金)・第23条第1項第2号 (法人も同額)",
    },
  },
  transitional_ja: [
    "改正法附則第2条: 新法 (罰則を除く) は施行前にされた旧法の公益通報にも適用する",
    "附則第3条第1項: 新第3条第1項・第2項は施行後にされた解雇その他不利益な取扱いに適用する (施行前は従前の例)",
    "附則第3条第2項・第3項: 推定 (新第3条第3項) は、解雇以外は施行後に懲戒としてされたものに、解雇は施行前のものにも適用する",
    "附則第5条: 通報妨害の合意等の無効 (新第11条の2第2項) は施行後の合意等だけ",
    "附則第7条: 施行前の行為に新しい罰則は適用しない",
  ],
  guideline_ja: "公益通報者保護法第11条第1項及び第2項の規定に基づき事業者がとるべき措置に関して、その適切かつ有効な実施を図るために必要な指針 (令和3年内閣府告示第118号・2026-12-01 から改正後の内容を適用。改正告示の番号は要確認)",
} as const;

type ArticleSet = (typeof WHISTLEBLOWER_LEGAL_VALUES.articles)["R7"] | (typeof WHISTLEBLOWER_LEGAL_VALUES.articles)["R2"];

/** 基準日を日本時間の暦日 YYYY-MM-DD にそろえる。省略時は今日 */
function toYmdJst(asOf?: string | Date): string {
  const jst = (t: number) => new Date(t + 9 * 3600 * 1000).toISOString().slice(0, 10);
  if (asOf == null) return jst(Date.now());
  if (asOf instanceof Date) return Number.isNaN(asOf.getTime()) ? jst(Date.now()) : jst(asOf.getTime());
  const s = String(asOf).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  if (/^\d{4}-\d{2}-\d{2}T/.test(s)) {
    const t = Date.parse(s);
    return Number.isNaN(t) ? s.slice(0, 10) : jst(t);
  }
  return s.slice(0, 10);
}

/**
 * 暦で n 年後 (n<0 なら前) の同じ月日。応当日が無い (2月29日) ときはその月の末日。
 * ★「一年以内」の数え方は民法の期間計算 (初日不算入・応当日の前日に満了) に沿って、
 *   起算日の翌年の同じ月日までを「1年以内」とする (要確認: 専門家の確認を経ていない)。
 */
function addYearsYmd(ymd: string, n: number): string {
  const [y, m, d] = ymd.split("-").map((x) => Number(x));
  const ny = y + n;
  const last = new Date(Date.UTC(ny, m, 0)).getUTCDate();
  return `${ny}-${String(m).padStart(2, "0")}-${String(Math.min(d, last)).padStart(2, "0")}`;
}

/** 基準日に効いている版 */
export function koekiTsuhoVersion(asOf?: string | Date): KoekiTsuhoVersion {
  return toYmdJst(asOf) >= KOEKI_TSUHO_R7_EFFECTIVE ? "R7" : "R2";
}

export type EmployeeSize = "S" | "M" | "L"; // S: <=300, M: 301-1000, L: >1000

export interface OrgProfile {
  org_name: string;
  /** 常時使用する労働者の数 (第11条第3項の基準。役員・退職者は含まない) */
  total_employees: number;
  has_internal_window: boolean;
  has_external_window: boolean; // 顧問弁護士/外部CSR窓口
  designated_handler_count: number; // 公益通報対応業務従事者として定めた人数
  has_anonymous_channel: boolean;
  /** 労働者等への窓口・保護の仕組みの周知 (R7 第11条第2項)。未入力なら判定しない */
  notifies_workers?: boolean;
  /** 業務委託先のフリーランスへの窓口の周知 (R7 から・指針)。未入力なら判定しない */
  notifies_freelancers?: boolean;
  /** 通報妨害を防ぐ措置 (R7 第11条の2)。未入力なら判定しない */
  has_obstruction_prevention?: boolean;
  /** 通報者探索を防ぐ措置 (R7 第11条の3)。未入力なら判定しない */
  has_search_prevention?: boolean;
}

export interface ComplianceFinding {
  rule: string;
  severity: "info" | "warning" | "violation";
  hint: string;
}

export function classifyOrgSize(profile: OrgProfile): EmployeeSize {
  if (profile.total_employees > 1000) return "L";
  if (profile.total_employees >= 301) return "M";
  return "S";
}

/**
 * 事業者の体制を点検する。
 * @param opts.asOf 基準日 (省略時は日本時間の今日)。2026-12-01 以後は令和7年改正後の条番号・罰則で返す
 */
export function checkOrgCompliance(profile: OrgProfile, opts?: { asOf?: string | Date }): ComplianceFinding[] {
  const findings: ComplianceFinding[] = [];
  const asOf = toYmdJst(opts?.asOf);
  const v = koekiTsuhoVersion(asOf);
  const A: ArticleSet = WHISTLEBLOWER_LEGAL_VALUES.articles[v];
  const R7 = WHISTLEBLOWER_LEGAL_VALUES.articles.R7;
  const large = profile.total_employees > WHISTLEBLOWER_LEGAL_VALUES.employee_threshold;

  if (large && !profile.has_internal_window) {
    findings.push({
      rule: `公益通報者保護法 ${A.system}`,
      severity: "violation",
      hint:
        v === "R7"
          ? "常時使用する労働者が300人を超える事業者は、内部公益通報に応じる体制の整備と労働者等への周知が義務 (第11条第2項)。違反すると助言・指導・勧告、勧告に従わないと公表 (第15条・第15条の2第4項・第5項)。報告を求められて応じない・虚偽の報告は20万円以下の過料 (第16条第2項・第24条)。"
          : "常時使用する労働者が300人を超える事業者は、内部公益通報に応じる体制 (窓口の設置・内部規程など) の整備が義務 (第11条第2項)。違反すると内閣総理大臣による報告の徴収・助言・指導・勧告、勧告に従わないと公表の対象 (第15条・第16条)。窓口が無いこと自体への罰則は無い。報告を求められて応じない・虚偽の報告は20万円以下の過料 (第22条)。",
    });
  }
  if (!large && !profile.has_internal_window) {
    findings.push({
      rule: `公益通報者保護法 ${A.small}`,
      severity: "warning",
      hint: "常時使用する労働者が300人以下の事業者は、従事者を定めることと体制の整備が努力義務 (第11条第3項)。内部通報窓口の設置に努めること。",
    });
  }
  if (large && profile.designated_handler_count === 0) {
    findings.push({
      rule: `公益通報者保護法 ${A.handler}`,
      severity: "violation",
      hint:
        "常時使用する労働者が300人を超える事業者は、通報の受付・調査・是正に従事する者 (公益通報対応業務従事者) を定める義務 (第11条第1項)。定め方 (書面での指定・本人への明示など) は指針 (令和3年内閣府告示第118号) で確かめる。" +
        (v === "R7"
          ? "定めないと勧告、従わないと命令・公表 (第15条の2第1項〜第3項)。命令違反は30万円以下の罰金 (第21条第2項第1号・法人も同額 第23条第1項第2号)。報告・立入検査の対象 (第16条第1項)。従事者の守秘義務違反は30万円以下の罰金 (第12条・第22条)。"
          : "従事者の守秘義務違反は30万円以下の罰金 (第12条・第21条)。"),
    });
  }

  // 令和7年改正で加わる義務 (施行日以後は所見・施行の90日前からは準備の知らせ)
  const prep = v === "R2" && asOf >= KOEKI_TSUHO_R7_PREP_FROM;
  if (v === "R7" || prep) {
    const pre = prep ? "【2026-12-01 施行の準備】" : "";
    const sev = (s: ComplianceFinding["severity"]): ComplianceFinding["severity"] => (prep ? "info" : s);
    if (profile.notifies_workers === false) {
      findings.push({
        rule: "公益通報者保護法 第11条第2項 (労働者等への周知)",
        severity: sev(large ? "violation" : "warning"),
        hint: `${pre}受付窓口 (連絡先)・利益相反の排除・不利益な取扱いの防止・通報妨害と通報者探索の防止の措置・調査への協力などを労働者等に周知する (第11条第2項・指針・2026-12-01 から)。300人以下の事業者は努力義務 (第11条第3項)。`,
      });
    }
    if (profile.notifies_freelancers === false) {
      findings.push({
        rule: "公益通報者保護法 第2条第1項第3号・指針 (フリーランスへの周知)",
        severity: sev("warning"),
        hint: `${pre}業務委託中と委託終了後1年以内のフリーランス (特定受託業務従事者) も公益通報者に加わる (2026-12-01 から)。受付窓口をフリーランスにも周知する。`,
      });
    }
    if (profile.has_obstruction_prevention === false) {
      findings.push({
        rule: `公益通報者保護法 ${R7.obstruction}`,
        severity: sev("warning"),
        hint: `${pre}「通報しない」旨の合意を求める・通報すれば不利益に扱うと告げるなどの通報妨害は禁止され、そうした合意等は無効 (施行後の合意等に限る・改正法附則第5条)。防止措置を規程に入れる。`,
      });
    }
    if (profile.has_search_prevention === false) {
      findings.push({
        rule: `公益通報者保護法 ${R7.search}`,
        severity: sev("warning"),
        hint: `${pre}正当な理由なく通報者を特定しようとする行為 (通報者であることを明らかにするよう求めることなど) は禁止。閲覧権限の限定と探索の禁止を規程に入れる。`,
      });
    }
  }

  if (!profile.has_external_window) {
    findings.push({
      rule: "公益通報者保護法に基づく指針 (令和3年内閣府告示第118号)・指針の解説 (推奨)",
      severity: "warning",
      hint: "外部窓口 (顧問弁護士/外部CSR会社) の併設が望ましい (内部のみだと心理的ハードル高)。",
    });
  }
  if (!profile.has_anonymous_channel) {
    findings.push({
      rule: "公益通報者保護法に基づく指針 (令和3年内閣府告示第118号)・指針の解説 (推奨)",
      severity: "warning",
      hint: "匿名通報チャネルの提供を推奨 (報復リスクへの配慮)。",
    });
  }
  return findings;
}

export type ReporterType =
  | "employee" // 現職労働者 (第2条第1項第1号)
  | "retired_employee" // 退職者 (通報の日前1年以内に使用されていた者・第2条第1項第1号。令和2年改正で追加)
  | "dispatched_worker" // 派遣労働者 (第2条第1項第2号)
  | "freelance" // 特定受託業務従事者 (フリーランス・委託終了後1年以内を含む。2026-12-01 から第2条第1項第3号)
  | "officer" // 役員 (R2: 第2条第1項第4号 / R7: 第5号。令和2年改正で追加)
  | "subcontractor" // 取引先の労働者等 (R2: 第2条第1項第3号 / R7: 第4号)
  | "outside";

export interface WhistleblowerCase {
  case_id: string;
  reported_at: string; // ISO (YYYY-MM-DD 又は日時)
  reporter_type: ReporterType;
  reporter_anonymity: "named" | "pseudonym" | "anonymous";
  channel: "internal_hr" | "external_lawyer" | "compliance_committee" | "regulatory_authority" | "media";
  category: "labor_violation" | "fraud" | "harassment" | "safety" | "data_breach" | "antitrust" | "other";
  description: string;
  evidence_attached?: boolean;
  status: "received" | "triage" | "investigating" | "concluded" | "rejected";
  protected_under_law?: boolean;
  /** 退職日・派遣の終了日・業務委託の終了日 (YYYY-MM-DD)。通報の日前1年以内かの判定に使う */
  left_at?: string;
}

export interface ReporterProtectionStatus {
  protected: boolean;
  basis: string | null;
  reason: string;
  needs_confirmation: string | null;
}

/** 通報者が公益通報者の範囲に入るかを、理由と根拠つきで返す (通報の日の版で判定) */
export function protectedReporterStatus(c: WhistleblowerCase): ReporterProtectionStatus {
  const reported = toYmdJst(c.reported_at);
  const v = koekiTsuhoVersion(reported);
  const oneYearBefore = addYearsYmd(reported, -1);
  const withinYear = (label: string, basis: string): ReporterProtectionStatus => {
    if (!c.left_at) {
      return { protected: true, basis, reason: `${label} (終了日が未入力のため、通報の日前1年以内かは確かめていない)`, needs_confirmation: "終了日 (left_at) を入れると、通報の日前1年以内かを判定できる" };
    }
    const left = toYmdJst(c.left_at);
    return left >= oneYearBefore
      ? { protected: true, basis, reason: `${label} (終了日 ${left} は通報の日 ${reported} の前1年以内)`, needs_confirmation: null }
      : { protected: false, basis, reason: `${label}だが、終了日 ${left} が通報の日 ${reported} の1年より前のため公益通報者に当たらない`, needs_confirmation: null };
  };
  switch (c.reporter_type) {
    case "employee":
      return { protected: true, basis: "第2条第1項第1号 (労働者)", reason: "労働者", needs_confirmation: null };
    case "retired_employee":
      return withinYear("退職者", "第2条第1項第1号 (労働者であった者)");
    case "dispatched_worker":
      return withinYear("派遣労働者", "第2条第1項第2号 (派遣労働者)");
    case "officer":
      return { protected: true, basis: v === "R7" ? "第2条第1項第5号 (役員)" : "第2条第1項第4号 (役員)", reason: "役員", needs_confirmation: null };
    case "subcontractor":
      return { protected: true, basis: v === "R7" ? "第2条第1項第4号 (取引先の労働者等)" : "第2条第1項第3号 (取引先の労働者等)", reason: "取引先の労働者等", needs_confirmation: null };
    case "freelance":
      if (v === "R2") {
        return {
          protected: false,
          basis: null,
          reason: `フリーランスは ${KOEKI_TSUHO_R7_EFFECTIVE} 施行の改正後に公益通報者に加わる。通報の日 ${reported} はその前のため対象外`,
          needs_confirmation: "施行前のフリーランスの通報は、改正法附則第2条 (旧法の公益通報に新法を適用) の対象に当たらないと読んだ。専門家の確認を経ていない (要確認)",
        };
      }
      return withinYear("フリーランス (特定受託業務従事者)", "第2条第1項第3号 (特定受託業務従事者)");
    default:
      return { protected: false, basis: null, reason: "公益通報者保護法の公益通報者の範囲に当たらない", needs_confirmation: null };
  }
}

export function isProtectedReporter(c: WhistleblowerCase): boolean {
  // 令和2年改正 (2022-06-01 施行) で退職後1年以内の者・役員が加わり、
  // 令和7年改正 (2026-12-01 施行) でフリーランス (特定受託業務従事者) が加わった
  return protectedReporterStatus(c).protected;
}

export interface ChannelEvaluation {
  channel: WhistleblowerCase["channel"];
  protection_strength: "strong" | "medium" | "weak";
  required_conditions: string[];
  /** 根拠条 (基準日の版の番号) */
  basis?: string;
}

/**
 * 通報先ごとの保護の条件 (労働者の場合)。役員は別の条件 (調査是正措置に努めたこと等・R2/R7 第6条) がある。
 * @param opts.asOf 基準日 (省略時は今日)。条の番号だけが版で変わり、中身は同じ
 */
export function evaluateChannelProtection(
  channel: WhistleblowerCase["channel"],
  opts?: { asOf?: string | Date },
): ChannelEvaluation {
  const A: ArticleSet = WHISTLEBLOWER_LEGAL_VALUES.articles[koekiTsuhoVersion(opts?.asOf)];
  const internalCond = "通報対象事実が生じ、又はまさに生じようとしていると思料すること (真実相当性は不要)";
  const table: ChannelEvaluation[] = [
    { channel: "internal_hr", protection_strength: "strong", required_conditions: [internalCond], basis: A.internal },
    {
      channel: "external_lawyer",
      protection_strength: "strong",
      required_conditions: [
        internalCond,
        "事業者があらかじめ定めた外部窓口 (弁護士/外部CSR会社) への通報は、事業者 (役務提供先等) への通報 (1号) に当たる",
        "事業者が定めていない外部の者への通報は1号に当たらない (3号の条件で判断する)",
      ],
      basis: A.internal,
    },
    { channel: "compliance_committee", protection_strength: "strong", required_conditions: [internalCond], basis: A.internal },
    {
      channel: "regulatory_authority",
      protection_strength: "medium",
      required_conditions: [
        "通報対象事実が生じ、又はまさに生じようとしていると信ずるに足りる相当の理由があること",
        "又は、思料し、かつ氏名又は名称・住所又は居所・通報対象事実の内容・思料する理由・措置がとられるべきと思料する理由を記載した書面 (電磁的記録を含む) を提出すること",
        "通報先は、その事実について処分又は勧告等をする権限を有する行政機関等",
      ],
      basis: A.administrative,
    },
    {
      channel: "media",
      protection_strength: "weak",
      required_conditions: [
        "通報対象事実が生じ、又はまさに生じようとしていると信ずるに足りる相当の理由があること (真実であることまでは要らない)",
        "かつ次のいずれか: イ 1号・2号通報をすれば解雇その他不利益な取扱いを受けると信ずるに足りる相当の理由 / ロ 1号通報では証拠が隠滅・偽造・変造されるおそれ / ハ 1号通報では通報者を特定させる事項を正当な理由なく漏らすと信ずるに足りる相当の理由 / ニ 1号・2号通報をしないことを正当な理由なく要求された / ホ 書面による1号通報から20日を経過しても調査を行う旨の通知がない、又は正当な理由なく調査を行わない / ヘ 生命・身体への危害、又は財産への回復できない損害・著しく多数の個人の多額の損害が発生する急迫した危険",
        "通報先は、発生又は被害の拡大を防止するために必要と認められる者 (報道機関など。事業者の競争上の地位その他正当な利益を害するおそれがある者を除く)",
      ],
      basis: A.external,
    },
  ];
  return table.find((c) => c.channel === channel) ?? {
    channel,
    protection_strength: "weak",
    required_conditions: ["公益通報者保護法の保護要件を充足していること"],
  };
}

export type RetaliationEventType =
  | "demotion"
  | "salary_cut"
  | "transfer"
  | "termination"
  | "harassment"
  | "contract_termination" // 業務委託契約・労働者派遣契約の解除
  | "volume_reduction" // 取引の数量の削減 (フリーランス)
  | "transaction_stop" // 取引の停止 (フリーランス)
  | "fee_reduction" // 報酬の減額 (フリーランス)
  | "dispatch_replacement" // 派遣労働者の交代を求めること
  | "other";

export interface RetaliationEvent {
  ts: string;
  type: RetaliationEventType;
  description: string;
  /** 懲戒 (就業規則・労働契約に定めた制裁) としてされたか。R7 の推定は解雇と懲戒だけに働く */
  disciplinary?: boolean;
}

export interface RetaliationFinding {
  ts: string;
  type: RetaliationEventType;
  version: KoekiTsuhoVersion;
  basis: string;
  presumed: boolean;
  reasoning: string;
}

export interface RetaliationCheck {
  case_id: string;
  events: RetaliationEvent[];
  is_likely_retaliation: boolean;
  reasoning: string;
  /** 推定 (R7 第3条第3項・附則第3条第3項) が働く事象があるか */
  presumed?: boolean;
  /** 事象ごとの判定 (事象の日の版で判定) */
  findings?: RetaliationFinding[];
  needs_confirmation?: string | null;
}

const FIRST_CLASS_CHANNELS: WhistleblowerCase["channel"][] = ["internal_hr", "external_lawyer", "compliance_committee"];
const WORKER_LIKE: ReporterType[] = ["employee", "retired_employee", "subcontractor"];
const WORKER_ADVERSE: RetaliationEventType[] = ["termination", "demotion", "salary_cut", "transfer", "harassment"];
const FREELANCE_ADVERSE: RetaliationEventType[] = ["contract_termination", "volume_reduction", "transaction_stop", "fee_reduction", "termination", "salary_cut"];
const PENALTY_NOTE = "通報を理由とする解雇・懲戒は刑事罰の対象 (第21条第1項: 6月以下の拘禁刑又は30万円以下の罰金・法人は3,000万円以下の罰金 第23条)。推定 (第3条第3項) は無効の判断 (第3条第2項) のためのもので、刑事罰の判断には働かない。";

/**
 * 通報後の不利益な取扱いを点検する。事象ごとに「事象の日」の版で判定する。
 * @param opts.asOf 判断する日 (省略時は今日)。2026-12-01 以後は施行前の解雇にも推定が働く (改正法附則第3条第3項)
 * @param opts.employerLearnedAt 2号 (行政機関)・3号 (報道機関等) の通報を事業者が知った日。推定の起算日に使う
 */
export function detectRetaliation(
  c: WhistleblowerCase,
  events: RetaliationEvent[],
  opts?: { asOf?: string | Date; employerLearnedAt?: string },
): RetaliationCheck {
  const asOf = toYmdJst(opts?.asOf);
  const reported = toYmdJst(c.reported_at);
  const status = protectedReporterStatus(c);
  const firstClass = FIRST_CLASS_CHANNELS.includes(c.channel);
  const learned = opts?.employerLearnedAt ? toYmdJst(opts.employerLearnedAt) : null;
  // 推定の起算日: 1号は通報の日、2号・3号は事業者が知った日 (分からなければ決めない)
  const presumptionStart: string | null = firstClass ? reported : learned;
  const windowStart = reported;
  const windowEnd = addYearsYmd(presumptionStart && presumptionStart > reported ? presumptionStart : reported, 1);
  const inWindow = events.filter((e) => {
    const d = toYmdJst(e.ts);
    return d >= windowStart && d <= windowEnd;
  });
  if (!status.protected) {
    return {
      case_id: c.case_id,
      events: inWindow,
      is_likely_retaliation: false,
      reasoning: `保護対象外: ${status.reason}`,
      presumed: false,
      findings: [],
      needs_confirmation: status.needs_confirmation,
    };
  }

  const notes = new Set<string>();
  if (status.needs_confirmation) notes.add(status.needs_confirmation);
  notes.add("「1年以内」は起算日の翌年の同じ月日までとして数えた (民法の期間計算に沿う読み・要確認)");
  const findings: RetaliationFinding[] = [];
  const presumable = (d: string) => presumptionStart !== null && d >= presumptionStart && d <= addYearsYmd(presumptionStart, 1);
  const noStartNote = "事業者が通報を知った日 (employerLearnedAt) が分からないため、推定の起算日を決められない (2号・3号通報は事業者が知った日から1年)。";

  for (const e of inWindow) {
    const d = toYmdJst(e.ts);
    const ev = koekiTsuhoVersion(d);
    const A: ArticleSet = WHISTLEBLOWER_LEGAL_VALUES.articles[ev];
    const push = (basis: string, presumed: boolean, reasoning: string) => findings.push({ ts: e.ts, type: e.type, version: ev, basis, presumed, reasoning });
    const workerLike = WORKER_LIKE.includes(c.reporter_type) || (c.reporter_type === "dispatched_worker" && WORKER_ADVERSE.includes(e.type));

    if (c.reporter_type === "freelance") {
      if (ev === "R2") continue; // 施行前の事象は第2条の対象に無い
      if (FREELANCE_ADVERSE.includes(e.type) || e.type === "other") {
        push(A.freelance ?? "", false, "特定受託事業者に対する契約の解除・取引の数量の削減・取引の停止・報酬の減額その他不利益な取扱いの禁止 (第5条)。推定の規定は労働者だけで、フリーランスには働かない。");
      }
      continue;
    }
    if (c.reporter_type === "officer") {
      if (e.type === "termination") {
        push(A.officer_dismissal, false, `通報を理由とする解任は、損害の賠償を請求できる (${A.officer_dismissal})。役員の行政機関・報道機関等への通報は、調査是正措置に努めたこと等の条件がある。推定の規定は働かない。`);
      } else if (e.type !== "other" || e.disciplinary) {
        push(A.officer_disadvantage, false, `通報を理由とする報酬の減額その他不利益な取扱いは禁止 (${A.officer_disadvantage})。推定の規定は働かない。`);
      }
      continue;
    }
    if (c.reporter_type === "dispatched_worker" && (e.type === "contract_termination" || e.type === "dispatch_replacement")) {
      const basis = e.type === "contract_termination" ? A.dispatch_termination : A.dispatch_disadvantage;
      push(basis, false, `派遣先による通報を理由とする行為の禁止 (${basis})。推定の規定は働かない。`);
      continue;
    }
    if (!workerLike) continue;
    if (c.reporter_type === "dispatched_worker") notes.add("派遣労働者への解雇・降格などは派遣元 (雇用主) による措置として労働者の規定で判定した (要確認)");
    if (!WORKER_ADVERSE.includes(e.type) && !e.disciplinary) continue;

    const isDismissalOrDiscipline = e.type === "termination" || e.disciplinary === true;
    if (ev === "R7") {
      if (isDismissalOrDiscipline) {
        if (presumable(d)) {
          push(`${A.presumption}・${A.worker_dismissal}`, true, `通報から1年以内の解雇・懲戒は、通報を理由とするものと推定される (第3条第3項)。事業者が通報以外の理由を立証しない限り無効 (第3条第2項)。${PENALTY_NOTE}`);
        } else {
          push(A.worker_disadvantage, false, `${presumptionStart === null ? noStartNote : "推定の期間 (1年) の外。"}通報を理由とする解雇その他不利益な取扱いは禁止 (第3条第1項)。${PENALTY_NOTE}`);
        }
      } else {
        push(A.worker_disadvantage, false, "通報を理由とする不利益な取扱いは禁止 (第3条第1項)。懲戒でない措置には推定は働かないため、通報が理由であることを確かめる必要がある。");
      }
    } else {
      const basis = e.type === "termination" ? A.worker_dismissal : A.worker_disadvantage;
      let reasoning = `通報を理由とする${e.type === "termination" ? "解雇は無効" : "不利益な取扱いは禁止"} (${basis})。この時点の法律に推定の規定は無い。`;
      let presumed = false;
      if (e.type === "termination" && asOf >= KOEKI_TSUHO_R7_EFFECTIVE) {
        if (presumable(d)) {
          presumed = true;
          reasoning += "2026-12-01 以後に判断する場合、施行前の解雇にも推定が働く (改正法附則第3条第3項)。";
        } else if (presumptionStart === null) {
          reasoning += noStartNote;
        }
      }
      if (c.reporter_type === "subcontractor") notes.add("取引先の労働者等の場合、不利益な取扱いをしたのが自分を使用する事業者かを確かめる (要確認)");
      push(basis, presumed, reasoning);
    }
  }

  if (findings.length > 0) {
    const reasons = Array.from(new Set(findings.map((f) => f.reasoning)));
    return {
      case_id: c.case_id,
      events: inWindow,
      is_likely_retaliation: true,
      reasoning: `保護対象通報者に対して、通報後に不利益な取扱いが ${findings.length} 件ある。${reasons.join(" / ")}`,
      presumed: findings.some((f) => f.presumed),
      findings,
      needs_confirmation: Array.from(notes).join(" / ") || null,
    };
  }
  return {
    case_id: c.case_id,
    events: inWindow,
    is_likely_retaliation: false,
    reasoning: "通報後の不利益取扱いは検出されていない、または保護対象外。",
    presumed: false,
    findings: [],
    needs_confirmation: Array.from(notes).join(" / ") || null,
  };
}

export interface CaseTimeline {
  received_at: string;
  acknowledged_within_days: number; // 調査を行う旨の通知までの日数 (20日を過ぎると3号通報が保護される)
  initial_response_within_days: number; // 調査着手までの日数 (社内の目安。法令の定めではない)
  conclusion_within_days?: number;
  exceeded_recommended_window: boolean;
}

// 調査を行う旨 (又は行わない旨と理由) の通知。書面による内部通報から20日を経過しても通知が無いと、
// 報道機関等への通報 (3号) が保護される (R2: 第3条第3号ホ / R7: 第3条第1項第3号ホ)
const RECOMMENDED_ACKNOWLEDGE_DAYS = 20;
// 調査着手 (社内の目安。法令の定めではない)
const RECOMMENDED_INVESTIGATION_START_DAYS = 30;

export function evaluateTimeline(
  receivedAt: string,
  acknowledgedAt: string,
  investigationStartedAt: string,
  concludedAt?: string,
): CaseTimeline {
  const r = Date.parse(receivedAt);
  const a = Date.parse(acknowledgedAt);
  const i = Date.parse(investigationStartedAt);
  const c = concludedAt ? Date.parse(concludedAt) : undefined;
  const ackDays = Math.round((a - r) / (24 * 60 * 60 * 1000));
  const investDays = Math.round((i - r) / (24 * 60 * 60 * 1000));
  const concDays = c ? Math.round((c - r) / (24 * 60 * 60 * 1000)) : undefined;
  return {
    received_at: receivedAt,
    acknowledged_within_days: ackDays,
    initial_response_within_days: investDays,
    conclusion_within_days: concDays,
    exceeded_recommended_window:
      ackDays > RECOMMENDED_ACKNOWLEDGE_DAYS ||
      investDays > RECOMMENDED_INVESTIGATION_START_DAYS,
  };
}

/**
 * 社内規程のひな形 (令和7年改正後の文面)。
 * @param opts.asOf 基準日 (省略時は今日)。2026-12-01 より前なら、施行前である旨を先頭に入れる
 */
export function buildPolicyTemplate(orgName: string, opts?: { asOf?: string | Date }): string {
  const before = koekiTsuhoVersion(opts?.asOf) === "R2";
  const head = before
    ? "> ★2026年12月1日に改正法 (令和7年法律第62号) が施行されます。第2条のフリーランス、第3条第4項の周知、第5条第2項、第6条・第7条は施行日から法律上の義務になります (それまでは社内の取組として運用)。\n\n"
    : "";
  return `${head}# ${orgName} 公益通報者保護規程

## 第1条 (目的)
本規程は、公益通報者保護法 (平成16年法律第122号) に基づき、
${orgName} (以下「当社」) における公益通報の処理体制及び公益通報者の保護を定めることを目的とする。

## 第2条 (定義)
1. 「公益通報」とは、労働者 (退職後1年以内の者を含む)・派遣労働者・役員・取引先の労働者等、
   及び当社と業務委託の関係にあるフリーランス (委託の終了後1年以内の者を含む。2026年12月1日から) が、
   不正の利益を得る目的等でなく、当社又は当社の役員・従業員等の通報対象事実を、
   通報先 (内部窓口/外部窓口/行政機関/その他) に通報することをいう。

## 第3条 (通報窓口)
1. 内部通報窓口: コンプライアンス部
2. 外部通報窓口: 顧問弁護士事務所 (XX法律事務所)
3. 匿名通報も受け付ける。
4. 当社は、窓口の連絡先、利益相反の排除、不利益な取扱いの防止、通報妨害及び通報者探索の防止の措置、調査への協力について、労働者等及び業務委託先のフリーランスに周知する。

## 第4条 (公益通報対応業務従事者の指定)
代表取締役は、公益通報対応業務 (受付・調査・是正措置) に従事する者を書面により指定する。指定された者には、その旨を本人に明らかにする。
被指定者は刑事罰付き守秘義務 (30万円以下の罰金) を負う。

## 第5条 (不利益取扱いの禁止)
1. 当社は、公益通報を行ったことを理由として、解雇・降格・減給・配置転換・嫌がらせ等の
   不利益な取扱いをしてはならない。
2. 当社は、業務委託先のフリーランスに対し、公益通報を理由として、契約の解除、取引の数量の削減、取引の停止、報酬の減額その他不利益な取扱いをしてはならない。

## 第6条 (通報妨害の禁止)
当社は、正当な理由がなく、公益通報をしない旨の合意を求めること、公益通報をした場合に不利益な取扱いをすることを告げることその他の行為により、公益通報を妨げてはならない。これに反する合意は無効とする。

## 第7条 (通報者探索の禁止)
当社は、正当な理由がなく、公益通報者である旨を明らかにすることを求めることその他の公益通報者を特定することを目的とする行為をしてはならない。

## 第8条 (調査・是正)
1. 書面による通報を受けた日から20日以内に、調査を行う旨 (行わない場合はその旨と理由) を通報者に通知する (匿名で連絡先の無い通報を除く)。
2. 正当な理由がある場合を除き、必要な調査を行う (着手の目安は社内で定める)。
3. 是正措置を講じた場合、その内容を通報者に通知する (匿名通報を除く)。

## 第9条 (記録の保存)
通報の受付日・調査・是正・人事上の措置の記録は、改ざんできない形で社内規程の定める期間保存する。
通報から1年以内の解雇・懲戒は通報を理由とするものと推定されるため、通報の受付日と人事上の措置の日を突き合わせられる記録を1年を超えて保存する。

本規程は雛形です。運用前に専門家の確認を受けてください。根拠: 公益通報者保護法 (平成16年法律第122号・令和7年法律第62号による改正後)・同法に基づく指針 (令和3年内閣府告示第118号)。
`;
}
