/**
 * rent_delinquency.ts — 家賃の督促の段階と、作ってはいけない文書の線
 *
 *   段階の日数は delinquency_ladder.json (単一の定義) から読む。ここに数値を書かない。
 *   自力救済 (鍵の交換・荷物の撤去・ライフラインの停止など) と、管理会社による明渡し・立退きの交渉や合意書は
 *   文書として作らず、弁護士への移管へ進める。
 *
 * 【出典】delinquency_ladder.json の sources を参照 (弁護士法72条は e-Gov で 2026-10-03 に確認。判例は要確認)。
 * ★どこからが「争いが具体化・顕在化した交渉」かの線引きは個別判断のため、弁護士の確認が要る (要確認)。
 *   本部品は安全側に、明渡し・立退きに関わる交渉・合意の文書は一律に作らない。
 */
import ladder from './delinquency_ladder.json';

export interface DelinquencyStage { code: string; from: number; action_ja: string; document_ja: string | null; actor_ja: string }
export interface ForbiddenDelinquencyAction { code: string; label_ja: string; keywords: string[]; basis_ja: string }

export const DELINQUENCY_LADDER_VERSION: string = ladder.version;
/** 家賃の督促の段階 (滞納日数) */
export const RENT_DELINQUENCY_LADDER: readonly DelinquencyStage[] = ladder.rent.stages as DelinquencyStage[];
/** 管理費・修繕積立金の督促の段階 (滞納月数) */
export const CONDO_FEE_DELINQUENCY_LADDER: readonly DelinquencyStage[] = ladder.condo_fee.stages as DelinquencyStage[];
/** 督促で作ってはいけない文書・してはいけない行為 */
export const DELINQUENCY_FORBIDDEN_ACTIONS: readonly ForbiddenDelinquencyAction[] = ladder.forbidden_actions as ForbiddenDelinquencyAction[];

/** 滞納日数から、いま行うべき段階を返す (段階に入る前は null) */
export function rentDelinquencyStage(daysOverdue: number): DelinquencyStage | null {
  let cur: DelinquencyStage | null = null;
  for (const s of RENT_DELINQUENCY_LADDER) if (daysOverdue >= s.from) cur = s;
  return cur;
}

/** 滞納月数から、管理費等の督促の段階を返す */
export function condoFeeDelinquencyStage(monthsOverdue: number): DelinquencyStage | null {
  let cur: DelinquencyStage | null = null;
  for (const s of CONDO_FEE_DELINQUENCY_LADDER) if (monthsOverdue >= s.from) cur = s;
  return cur;
}

/** 依頼文・行為コードが、作ってはいけない文書に当たるかを返す */
export function findForbiddenDelinquencyActions(request: { actionCodes?: string[]; text?: string }): ForbiddenDelinquencyAction[] {
  const codes = new Set(request.actionCodes ?? []);
  const text = String(request.text ?? '').replace(/\s+/g, '');
  return DELINQUENCY_FORBIDDEN_ACTIONS.filter((a) => codes.has(a.code) || a.keywords.some((k) => text.includes(k)));
}

export interface DelinquencyDocumentRequest {
  /** 滞納日数 */
  daysOverdue: number;
  /** 作りたい文書・行為の説明 (例:「30日滞納したら鍵を交換する通知」) */
  text?: string;
  /** 行為コード (forbidden_actions の code) */
  actionCodes?: string[];
  tenantName?: string;
  amountJpy?: number;
}

export interface DelinquencyDocumentResult {
  generated: boolean;
  stage: DelinquencyStage | null;
  /** 作った文書 (generated=true のときだけ) */
  document?: { title: string; body: string };
  /** 作らなかった理由 */
  blockedBy?: { code: string; label_ja: string; basis_ja: string }[];
  /** 次に進める先 */
  next?: { code: string; label_ja: string; reason: string };
}

/**
 * 督促の文書の下書きを作る。作ってはいけない行為を含む依頼は文書を作らず、弁護士への移管を返す。
 *   弁護士への移管の段階 (LAWYER_REFERRAL) に入った滞納も、督促の文書は作らず移管を返す。
 */
export function planDelinquencyDocument(req: DelinquencyDocumentRequest): DelinquencyDocumentResult {
  const stage = rentDelinquencyStage(req.daysOverdue);
  const hits = findForbiddenDelinquencyActions(req);
  const transfer = ladder.transfer_to;
  if (hits.length > 0) {
    return {
      generated: false,
      stage,
      blockedBy: hits.map((h) => ({ code: h.code, label_ja: h.label_ja, basis_ja: h.basis_ja })),
      next: { code: transfer.code, label_ja: transfer.label_ja, reason: `「${hits.map((h) => h.label_ja).join('」「')}」は管理会社・貸主が行えないため文書を作りません。滞納の経過と催告の記録をまとめて弁護士へ引き継いでください` },
    };
  }
  if (!stage) return { generated: false, stage: null, next: { code: 'NONE', label_ja: '督促の段階の前', reason: '支払期日を過ぎた日数が最初の段階に届いていません' } };
  if (stage.code === transfer.code) {
    return { generated: false, stage, next: { code: transfer.code, label_ja: transfer.label_ja, reason: '弁護士への移管の段階です。解除・明渡し・訴訟の判断と交渉は弁護士が行います' } };
  }
  const who = req.tenantName ? `${req.tenantName} 様` : 'ご契約者様';
  const amt = typeof req.amountJpy === 'number' ? `${req.amountJpy.toLocaleString('ja-JP')}円` : '未払いの賃料等';
  const title = stage.document_ja ?? stage.action_ja;
  const body = `${who}\n\nお支払期日を過ぎた ${amt} について、${stage.action_ja}としてご連絡いたします。\nすでにお支払いいただいている場合は、行き違いをご容赦ください。\nご事情がおありの場合は、お早めにご相談ください。`;
  return { generated: true, stage, document: { title, body } };
}
