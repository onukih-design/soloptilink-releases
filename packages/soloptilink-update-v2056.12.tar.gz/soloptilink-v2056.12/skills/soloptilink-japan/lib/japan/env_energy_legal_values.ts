/**
 * lib/japan/env_energy_legal_values.ts — 環境・エネルギーの法定値の値表 (1か所に寄せた正本)
 *
 * 決まり (REQ-171 / JPO-IND-148):
 *   - 法定値は一次資料から転記したものだけを transcribed=true で置く。出典URL・出典名・基準日 (施行日/版の日)・取得日・版 を必ず書く。
 *   - 一次資料で確かめられない値は transcribed=false のまま置き、値は持たない (value=null)。
 *     requireEnvEnergyLegalNumber() で使おうとすると例外になり、部品は「確認できていない」を返す。
 *   - energy.ts / esg_carbon.ts / waste.ts / env_energy_compliance.ts は、ここに置いた値を読む (同じ値の写しを持たない)。
 *   - 値を改める時は、新しい版の行を足すか値を差し替え、basisDate・retrievedOn・version を必ず更新する。
 *
 * 取得: 2026-10-03 (e-Gov 法令API v2・資源エネルギー庁・経済産業省・環境省)。写し: ~/jpo-run/証跡/A1_実装/T42_一次資料/
 */

export interface EnvEnergyLegalValue {
  key: string;
  /** 数値・日付 (YYYY-MM-DD / MM-DD)。未転記なら null */
  value: number | string | null;
  unit: string;
  transcribed: boolean;
  sourceTitle: string;
  sourceUrl: string;
  /** 値が効力を持つ基準日 (施行日・版の日) */
  basisDate: string;
  /** 一次資料を取得した日 */
  retrievedOn: string;
  /** 法令番号・告示番号・版 */
  version: string;
  note?: string;
}

const EGOV = (lawId: string) => `https://laws.e-gov.go.jp/law/${lawId}`;
const GOT = '2026-10-03';

// e-Gov の法令ID (2026-10-03 に API v2 で確認)
const L = {
  ondankaRei: '411CO0000000143', // 地球温暖化対策の推進に関する法律施行令 (版 2026-04-01)
  ondankaReport: '418M60001FFA002', // 温室効果ガス算定排出量等の報告等に関する命令 (版 2026-07-01)
  santeiShorei: '418M60001400003', // 特定排出者の事業活動に伴う温室効果ガスの排出量の算定に関する省令 (版 2026-04-01)
  shoeneRei: '354CO0000000267', // 省エネ法施行令 (版 2026-07-01)
  shoeneKisoku: '354M50000400074', // 省エネ法施行規則 (版 2026-07-01)
  gxHo: '505AC0000000032', // GX推進法 (版 2026-04-01)
  gxRei: '505CO0000000379', // GX推進法施行令 (版 2026-04-01)
  gxKisoku: '506M60000400003', // GX推進法施行規則 (版 2026-04-01)
  fluoroMeirei: '426M60003FFA002', // フロン類算定漏えい量等の報告等に関する命令 (版 2021-01-22)
  wasteRei: '346CO0000000300', // 廃棄物処理法施行令 (版 2026-09-16)
  wasteKisoku: '346M50000100035', // 廃棄物処理法施行規則 (版 2026-09-16)
  lpgKisoku: '409M50000400011', // 液石法施行規則 (版 2025-12-25)
  pcbHo: '413AC0000000065', // PCB特措法 (現行版 2026-07-01)
  pcbRei: '413CO0000000215', // PCB特措法施行令 (版 2020-04-01)
};

const SHK_FUEL = (key: string, fuel: string, unit: string, heat: number, carbon: number, row: string): EnvEnergyLegalValue[] => [
  { key: `shk.fuel.${key}.heat_gj`, value: heat, unit: `GJ/${unit}`, transcribed: true, sourceTitle: `算定省令 別表第一 ${row} ${fuel} 第四欄 (単位発熱量)`, sourceUrl: EGOV(L.santeiShorei), basisDate: '2026-04-01', retrievedOn: GOT, version: '平成十八年経済産業省・環境省令第三号' },
  { key: `shk.fuel.${key}.carbon_tc_per_gj`, value: carbon, unit: 'tC/GJ', transcribed: true, sourceTitle: `算定省令 別表第一 ${row} ${fuel} 第五欄 (排出係数)`, sourceUrl: EGOV(L.santeiShorei), basisDate: '2026-04-01', retrievedOn: GOT, version: '平成十八年経済産業省・環境省令第三号' },
];

const ENECHO_FIT = 'https://www.enecho.meti.go.jp/category/saving_and_new/saiene/kaitori/kakaku.html';
const FIT = (key: string, value: number, label: string, unit = '円/kWh'): EnvEnergyLegalValue => ({
  key, value, unit, transcribed: true, sourceTitle: `資源エネルギー庁 買取価格・期間等 2024年度の価格表 ${label}`, sourceUrl: ENECHO_FIT, basisDate: '2024-04-01', retrievedOn: GOT, version: '2024年度 (令和6年度) 調達価格・調達期間',
});

export const ENV_ENERGY_LEGAL_VALUES: readonly EnvEnergyLegalValue[] = [
  // ===== 温対法 (SHK) =====
  { key: 'shk.energy_threshold_kl', value: 1500, unit: 'kL (原油換算/年)', transcribed: true, sourceTitle: '温対法施行令 5条1号 (全事業所の原油換算エネルギー使用量の合計が千五百キロリットル以上)', sourceUrl: EGOV(L.ondankaRei), basisDate: '2026-04-01', retrievedOn: GOT, version: '平成十一年政令第百四十三号' },
  { key: 'shk.per_gas_threshold_t', value: 3000, unit: 't-CO2 (ガスの種類ごと)', transcribed: true, sourceTitle: '温対法施行令 5条10号〜16号 (ガスの種類ごとの排出量が三千トン以上)', sourceUrl: EGOV(L.ondankaRei), basisDate: '2026-04-01', retrievedOn: GOT, version: '平成十一年政令第百四十三号' },
  { key: 'shk.min_employees', value: 21, unit: '人 (常時使用する従業員)', transcribed: true, sourceTitle: '温対法施行令 5条柱書 (第十号から第十六号までは常時使用する従業員の数が二十一人以上である者に限る)', sourceUrl: EGOV(L.ondankaRei), basisDate: '2026-04-01', retrievedOn: GOT, version: '平成十一年政令第百四十三号' },
  { key: 'shk.report_due_mmdd', value: '07-31', unit: '毎年度の月日', transcribed: true, sourceTitle: '温室効果ガス算定排出量等の報告等に関する命令 4条1項 (毎年度七月末日まで)', sourceUrl: EGOV(L.ondankaReport), basisDate: '2026-07-01', retrievedOn: GOT, version: '平成十八年内閣府・総務省…環境省令第二号' },
  ...SHK_FUEL('gasoline', '揮発油', 'kL', 33.4, 0.0187, '一三'),
  ...SHK_FUEL('kerosene', '灯油', 'kL', 36.5, 0.0187, '一六'),
  ...SHK_FUEL('diesel', '軽油', 'kL', 38.0, 0.0188, '一七'),
  ...SHK_FUEL('heavy_oil_a', 'Ａ重油', 'kL', 38.9, 0.0193, '一八'),
  ...SHK_FUEL('lpg', '液化石油ガス（ＬＰＧ）', 't', 50.1, 0.0163, '二一'),
  { key: 'shk.co2_per_carbon', value: 44 / 12, unit: 't-CO2/tC', transcribed: true, sourceTitle: '算定省令 2条4項 (燃料の使用量×単位発熱量×排出係数×四十四／十二)', sourceUrl: EGOV(L.santeiShorei), basisDate: '2026-04-01', retrievedOn: GOT, version: '平成十八年経済産業省・環境省令第三号' },
  { key: 'shk.electricity_factor', value: null, unit: 't-CO2/kWh', transcribed: false, sourceTitle: '電気事業者ごとに環境大臣・経済産業大臣が公表する係数 (単一の法定値は無い)', sourceUrl: '', basisDate: '', retrievedOn: GOT, version: '', note: '要一次確認: 年度・電気事業者ごとの公表値を利用者が入力する。単一の全国平均値を法定値として持たない' },
  { key: 'shk.city_gas_factor', value: null, unit: 't-CO2/千Nm3', transcribed: false, sourceTitle: '算定省令 2条3項1号 (ガス事業者ごとに環境大臣及び経済産業大臣が公表する係数)', sourceUrl: EGOV(L.santeiShorei), basisDate: '', retrievedOn: GOT, version: '', note: '要一次確認: ガス事業者ごとの公表値を利用者が入力する' },

  // ===== 省エネ法 =====
  { key: 'shoene.specified_business_kl', value: 1500, unit: 'kL (原油換算/年)', transcribed: true, sourceTitle: '省エネ法施行令 2条1項 (特定事業者の指定 千五百キロリットル)', sourceUrl: EGOV(L.shoeneRei), basisDate: '2026-07-01', retrievedOn: GOT, version: '昭和五十四年政令第二百六十七号' },
  { key: 'shoene.periodic_report_due_mmdd', value: '07-31', unit: '毎年度の月日', transcribed: true, sourceTitle: '省エネ法施行規則 36条 (定期の報告 毎年度七月末日まで)', sourceUrl: EGOV(L.shoeneKisoku), basisDate: '2026-07-01', retrievedOn: GOT, version: '昭和五十四年通商産業省令第七十四号' },
  { key: 'shoene.midterm_plan_due_mmdd', value: '07-31', unit: '毎年度の月日', transcribed: true, sourceTitle: '省エネ法施行規則 35条1項 (中長期的な計画の提出 毎年度七月末日まで)', sourceUrl: EGOV(L.shoeneKisoku), basisDate: '2026-07-01', retrievedOn: GOT, version: '昭和五十四年通商産業省令第七十四号' },

  // ===== 排出量取引制度 (GX推進法) =====
  { key: 'gx.threshold_t', value: 100000, unit: 't-CO2 (前3年度の年度平均)', transcribed: true, sourceTitle: 'GX推進法 33条1項・同法施行令 2条 (十万トン)', sourceUrl: EGOV(L.gxRei), basisDate: '2026-04-01', retrievedOn: GOT, version: '令和五年政令第三百七十九号' },
  { key: 'gx.mandatory_from_fy', value: 2026, unit: '年度', transcribed: true, sourceTitle: 'GX推進法 (令和7年改正・2026-04-01施行) / 経済産業省 セットアップマニュアル 4.2', sourceUrl: EGOV(L.gxHo), basisDate: '2026-04-01', retrievedOn: GOT, version: '令和五年法律第三十二号' },
  { key: 'gx.notification_due_mmdd', value: '09-30', unit: '毎年度の月日', transcribed: true, sourceTitle: 'GX推進法施行規則 10条1項 (法33条1項の届出は毎年度九月末日まで)', sourceUrl: EGOV(L.gxKisoku), basisDate: '2026-04-01', retrievedOn: GOT, version: '令和六年経済産業省令第三号' },
  { key: 'gx.actual_report_due_mmdd_next_fy', value: '09-30', unit: '割当年度の翌年度の月日', transcribed: true, sourceTitle: 'GX推進法施行規則 16条1項 (法35条1項の報告は割当年度の翌年度の九月末日まで)', sourceUrl: EGOV(L.gxKisoku), basisDate: '2026-04-01', retrievedOn: GOT, version: '令和六年経済産業省令第三号' },
  { key: 'gx.transition_plan_due_mmdd', value: '09-30', unit: '毎年度の月日', transcribed: true, sourceTitle: '経済産業省「排出量取引制度 手続の全体像（セットアップマニュアル）」Step5 (移行計画は9月30日まで。根拠は法73条1項の主務省令)', sourceUrl: 'https://www.meti.go.jp/policy/energy_environment/global_warming/ets_setup.pdf', basisDate: '2026-06-01', retrievedOn: GOT, version: 'セットアップマニュアル 2026年6月1日', note: '主務省令の条番号は e-Gov で見つからず要一次確認 (期日はマニュアルの記載)' },
  { key: 'gx.fy2026_target_notification_due', value: '2027-09-30', unit: '日付', transcribed: true, sourceTitle: '経済産業省 セットアップマニュアル 4.2 (2026年度の特例: 排出目標量等の届出は2027年9月30日まで)', sourceUrl: 'https://www.meti.go.jp/policy/energy_environment/global_warming/ets_setup.pdf', basisDate: '2026-06-01', retrievedOn: GOT, version: 'セットアップマニュアル 2026年6月1日' },
  { key: 'gx.holding_due_mmdd_next_fy', value: '01-31', unit: '割当年度の翌年度の月日', transcribed: true, sourceTitle: 'GX推進法 36条3項 (割当年度の翌年度の一月三十一日に保有)', sourceUrl: EGOV(L.gxHo), basisDate: '2026-04-01', retrievedOn: GOT, version: '令和五年法律第三十二号' },
  { key: 'gx.burden_notice_from_mmdd_next_fy', value: '02-01', unit: '割当年度の翌年度の月日', transcribed: true, sourceTitle: 'GX推進法 41条1項 (割当年度の翌年度の二月一日以後に徴収)', sourceUrl: EGOV(L.gxHo), basisDate: '2026-04-01', retrievedOn: GOT, version: '令和五年法律第三十二号' },
  { key: 'gx.burden_multiplier', value: 1.1, unit: '倍', transcribed: true, sourceTitle: 'GX推進法 41条1項 (未償却量×参考上限取引価格×一・一)', sourceUrl: EGOV(L.gxHo), basisDate: '2026-04-01', retrievedOn: GOT, version: '令和五年法律第三十二号' },
  { key: 'gx.reference_cap_price.FY2026', value: 4300, unit: '円/t-CO2', transcribed: true, sourceTitle: '経済産業省告示第二十七号 (令和8年3月30日) 2条1号 令和八年度の参考上限取引価格', sourceUrl: 'https://www.meti.go.jp/policy/energy_environment/global_warming/torihikikakaku.pdf', basisDate: '2026-04-01', retrievedOn: GOT, version: '経済産業省告示第二十七号' },
  { key: 'gx.adjustment_base_price.FY2026', value: 1700, unit: '円/t-CO2', transcribed: true, sourceTitle: '経済産業省告示第二十七号 (令和8年3月30日) 2条2号 令和八年度の調整基準取引価格', sourceUrl: 'https://www.meti.go.jp/policy/energy_environment/global_warming/torihikikakaku.pdf', basisDate: '2026-04-01', retrievedOn: GOT, version: '経済産業省告示第二十七号' },
  { key: 'gx.reference_cap_price.FY2027', value: null, unit: '円/t-CO2', transcribed: false, sourceTitle: '令和9年度の参考上限取引価格 (年度開始前に告示される・未告示)', sourceUrl: '', basisDate: '', retrievedOn: GOT, version: '', note: '要一次確認: 告示後に転記する。告示27号附則2項の算定式 (前年度×(1.03+物価見通し)) で値を作らない' },

  // ===== フロン排出抑制法 =====
  ...([
    ['fluoro.simple_inspection_months', 3, 'か月', '簡易点検 すべての機器 3か月に1回以上'],
    ['fluoro.periodic_threshold_kw', 7.5, 'kW (圧縮機の定格出力)', '定期点検の対象 7.5kW以上'],
    ['fluoro.ac_large_threshold_kw', 50, 'kW', 'エアコンディショナー 50kW以上は1年に1回'],
    ['fluoro.periodic_months_refrigeration', 12, 'か月', '冷凍冷蔵機器 7.5kW以上 1年に1回以上'],
    ['fluoro.periodic_months_ac_large', 12, 'か月', 'エアコンディショナー 50kW以上 1年に1回以上'],
    ['fluoro.periodic_months_ac_medium', 36, 'か月', 'エアコンディショナー 7.5kW以上50kW未満 3年に1回以上'],
  ] as const).map(([key, value, unit, label]): EnvEnergyLegalValue => ({
    key, value, unit, transcribed: true,
    sourceTitle: `環境省・経済産業省「フロン排出抑制法の概要【機器ユーザー編】」${label} (根拠: 平成26年経済産業省・環境省告示第13号 管理者の判断の基準)`,
    sourceUrl: 'https://www.env.go.jp/earth/furon/files/outline_02.pdf', basisDate: '2020-04-01', retrievedOn: GOT, version: '平成26年経済産業省・環境省告示第13号 (令和2年4月施行の改正法後の資料)',
  })),
  { key: 'fluoro.report_threshold_t', value: 1000, unit: 't-CO2 (事業者単位)', transcribed: true, sourceTitle: 'フロン類算定漏えい量等の報告等に関する命令 3条 (フロン類算定漏えい量が千トン以上である者)', sourceUrl: EGOV(L.fluoroMeirei), basisDate: '2021-01-22', retrievedOn: GOT, version: '平成二十六年内閣府・…・防衛省令第二号' },
  { key: 'fluoro.report_due_mmdd', value: '07-31', unit: '毎年度の月日', transcribed: true, sourceTitle: 'フロン類算定漏えい量等の報告等に関する命令 4条1項 (毎年度七月末日まで)', sourceUrl: EGOV(L.fluoroMeirei), basisDate: '2021-01-22', retrievedOn: GOT, version: '平成二十六年内閣府・…・防衛省令第二号' },
  { key: 'fluoro.gwp_table', value: null, unit: '-', transcribed: false, sourceTitle: '地球温暖化係数 (命令2条3号: 環境大臣及び経済産業大臣が定める係数・告示)', sourceUrl: '', basisDate: '', retrievedOn: GOT, version: '', note: '要一次確認: 告示の本文を取得していないため冷媒ごとの値は持たない。利用者が入力する' },

  // ===== 産業廃棄物の委託契約書 =====
  { key: 'waste.contract_prtr_item_effective', value: '2026-01-01', unit: '日付', transcribed: true, sourceTitle: '令和7年環境省令第15号 附則1条1号 (施行規則8条の4の2の改正規定 令和八年一月一日)', sourceUrl: EGOV(L.wasteKisoku), basisDate: '2026-01-01', retrievedOn: GOT, version: '令和七年四月二二日環境省令第一五号' },
  { key: 'waste.contract_prtr_transition_cutoff', value: '2025-04-22', unit: '日付 (この日より前に締結され更新されていない契約は従前の例)', transcribed: true, sourceTitle: '令和7年環境省令第15号 附則1条柱書 (公布の日から施行) ・附則2条 (施行の際現に締結されている契約は更新までの間は従前の例)', sourceUrl: EGOV(L.wasteKisoku), basisDate: '2025-04-22', retrievedOn: GOT, version: '令和七年四月二二日環境省令第一五号', note: '2025-04-22〜2025-12-31 に締結した契約の扱いは条文の読みによる。安全側 (2026-01-01 から必要) とし士業の確認を推奨' },

  // ===== LPガス (液石法施行規則) =====
  { key: 'lpg.three_part_effective', value: '2025-04-02', unit: '日付', transcribed: true, sourceTitle: '令和6年経済産業省令第32号 附則1条ただし書 (16条15号の7〜9 は公布の日から起算して一年を経過した日)', sourceUrl: EGOV(L.lpgKisoku), basisDate: '2025-04-02', retrievedOn: GOT, version: '令和六年四月二日経済産業省令第三二号' },
  { key: 'lpg.equipment_rule_contract_cutoff', value: '2024-07-02', unit: '日付 (この日より前に締結された契約には15号の8・9を適用しない)', transcribed: true, sourceTitle: '令和6年経済産業省令第32号 附則1条 (公布の日から起算して三月を経過した日に施行)・附則2条', sourceUrl: EGOV(L.lpgKisoku), basisDate: '2024-07-02', retrievedOn: GOT, version: '令和六年四月二日経済産業省令第三二号' },
  { key: 'lpg.consumer_survey_years', value: 4, unit: '年', transcribed: true, sourceTitle: '液石法施行規則 37条1号 表イ(2) (消費設備の調査 供給開始時及び四年に一回以上)', sourceUrl: EGOV(L.lpgKisoku), basisDate: '2025-12-25', retrievedOn: GOT, version: '平成九年通商産業省令第十一号', note: '地下室等・埋設の亜鉛めっき配管の項目は1年に1回以上 (本部品は4年の項目のみ)' },
  { key: 'lpg.supply_inspection_years', value: 4, unit: '年', transcribed: true, sourceTitle: '液石法施行規則 36条1号 表イ(4) (供給設備の点検 供給開始時及び四年に一回以上)', sourceUrl: EGOV(L.lpgKisoku), basisDate: '2025-12-25', retrievedOn: GOT, version: '平成九年通商産業省令第十一号', note: '容器交換時・1年・2年の項目は別 (本部品は4年の項目のみ)' },

  // ===== PCB =====
  { key: 'pcb.low_disposal_deadline', value: '2027-03-31', unit: '日付', transcribed: true, sourceTitle: 'PCB特措法 14条・同法施行令 7条 (法の施行の日から令和九年三月三十一日まで)', sourceUrl: EGOV(L.pcbRei), basisDate: '2020-04-01', retrievedOn: GOT, version: '平成十三年政令第二百十五号' },
  { key: 'pcb.high_last_deadline', value: '2024-03-31', unit: '日付', transcribed: true, sourceTitle: 'PCB特措法施行令 別表 (高濃度の処分期間の末日は最も遅いもので令和5年3月31日) ＋ 法10条3項 (特例処分期限日は末日から1年)', sourceUrl: EGOV(L.pcbRei), basisDate: '2020-04-01', retrievedOn: GOT, version: '平成十三年政令第二百十五号' },
  { key: 'pcb.amendment_effective', value: '2027-04-01', unit: '日付', transcribed: true, sourceTitle: '令和8年法律第44号 附則1条 (令和九年四月一日から施行)', sourceUrl: EGOV(L.pcbHo), basisDate: '2026-06-19', retrievedOn: GOT, version: '令和八年法律第四十四号' },
  { key: 'pcb.post_amendment_disposal_period', value: null, unit: '期間', transcribed: false, sourceTitle: '令和8年法律第44号による改正後12条3項 (使用終了日から五年を超えない範囲内において政令で定める期間)', sourceUrl: EGOV(L.pcbHo), basisDate: '', retrievedOn: GOT, version: '', note: '要一次確認: 政令が未確認 (検討中)。期間を作らない' },

  // ===== FIT/FIP 2024年度 =====
  FIT('fit.2024.solar_residential_10kw_under', 16, '太陽光 10kW未満'),
  FIT('fit.2024.solar_business_10_50kw', 10, '太陽光 10kW以上50kW未満'),
  FIT('fit.2024.solar_business_50_250kw', 9.2, '太陽光 50kW以上 (地上設置・入札制度対象外)'),
  FIT('fit.2024.wind_onshore_under_50kw', 14, '陸上風力 50kW未満'),
  FIT('fit.2024.hydro_under_200kw', 34, '水力 200kW未満'),
  FIT('fit.2024.hydro_200_1000kw', 29, '水力 200kW以上1,000kW未満'),
  FIT('fit.2024.biomass_woody_under_2000kw', 40, '間伐材等由来の木質バイオマス 2,000kW未満'),
  FIT('fit.2024.geothermal_under_15000kw', 40, '地熱 新設 1,000kW以上15,000kW未満 (1,000kW未満も40円)'),
  FIT('fit.2024.period.solar_residential_10kw_under', 10, '太陽光 10kW未満 調達期間', '年'),
  FIT('fit.2024.period.default', 20, '太陽光(10kW以上)・風力・水力・バイオマス 調達期間', '年'),
  FIT('fit.2024.period.geothermal', 15, '地熱 調達期間', '年'),
  FIT('fip.2024.solar_business_50_250kw', 9.2, '太陽光 50kW以上 (地上設置・入札制度対象外) の調達価格/基準価格'),
];

const INDEX = new Map(ENV_ENERGY_LEGAL_VALUES.map((e) => [e.key, e]));

export type LegalValueLookup =
  | { ok: true; key: string; value: number | string; entry: EnvEnergyLegalValue }
  | { ok: false; key: string; status: 'unverified' | 'unknown'; reason: string };

/** 値を取り出す。未転記・未登録なら ok=false (値を作らない) */
export function getEnvEnergyLegalValue(key: string): LegalValueLookup {
  const e = INDEX.get(key);
  if (!e) return { ok: false, key, status: 'unknown', reason: `値表に「${key}」がありません` };
  if (!e.transcribed || e.value === null) {
    return { ok: false, key, status: 'unverified', reason: `「${e.sourceTitle}」は一次資料から転記されていないため使えません (${e.note ?? '要一次確認'})` };
  }
  return { ok: true, key, value: e.value, entry: e };
}

/** 数値の法定値を取り出す。未転記・未登録・数値でないなら例外 (検査が不合格になる) */
export function requireEnvEnergyLegalNumber(key: string): number {
  const r = getEnvEnergyLegalValue(key);
  if (!r.ok) throw new Error(`法定値を使えません: ${r.reason}`);
  if (typeof r.value !== 'number') throw new Error(`法定値「${key}」は数値ではありません`);
  return r.value;
}

/** 文字列 (日付・月日) の法定値を取り出す。未転記なら例外 */
export function requireEnvEnergyLegalString(key: string): string {
  const r = getEnvEnergyLegalValue(key);
  if (!r.ok) throw new Error(`法定値を使えません: ${r.reason}`);
  if (typeof r.value !== 'string') throw new Error(`法定値「${key}」は文字列ではありません`);
  return r.value;
}

/** 値表の監査: 転記済みの値に 出典URL (https)・出典名・基準日・取得日・版 があるか。未転記の値が value を持っていないか */
export function auditEnvEnergyLegalValues(entries: readonly EnvEnergyLegalValue[] = ENV_ENERGY_LEGAL_VALUES): {
  ok: boolean;
  problems: { key: string; problem: string }[];
} {
  const problems: { key: string; problem: string }[] = [];
  const ymd = /^\d{4}-\d{2}-\d{2}$/;
  const seen = new Set<string>();
  for (const e of entries) {
    if (seen.has(e.key)) problems.push({ key: e.key, problem: '鍵が重複しています' });
    seen.add(e.key);
    if (e.transcribed) {
      if (!/^https:\/\//.test(e.sourceUrl || '')) problems.push({ key: e.key, problem: '出典URL (https) がありません' });
      if (!e.sourceTitle) problems.push({ key: e.key, problem: '出典名がありません' });
      if (!ymd.test(e.basisDate || '')) problems.push({ key: e.key, problem: '基準日 (YYYY-MM-DD) がありません' });
      if (!ymd.test(e.retrievedOn || '')) problems.push({ key: e.key, problem: '取得日 (YYYY-MM-DD) がありません' });
      if (!e.version) problems.push({ key: e.key, problem: '版 (法令番号・告示番号) がありません' });
      if (e.value === null || e.value === undefined) problems.push({ key: e.key, problem: '転記済みなのに値がありません' });
    } else if (e.value !== null) {
      problems.push({ key: e.key, problem: '未転記なのに値を持っています (値を作らない決まりに反する)' });
    }
  }
  return { ok: problems.length === 0, problems };
}
