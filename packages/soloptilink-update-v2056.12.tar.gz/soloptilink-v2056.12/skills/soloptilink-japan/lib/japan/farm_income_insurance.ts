/**
 * lib/japan/farm_income_insurance.ts — 収入保険・共済・水田政策の加入期限と補てん (REQ-162 / JPO-IND-139)
 *
 * 2026-10-03 (JPO-T33) 新設。値 (補償限度の上限・選べる割合・支払率・補償の下限・類似制度) は primary_industry_ledger.ts を読む。
 *   - 収入保険の補てん金: 補償限度額 (基準収入×補償限度) を下回った額 × 支払率。積立方式併用は
 *     「保険方式の補償限度まで = 保険方式の支払率、その上の補償幅 = 積立方式の支払率」。補償の下限を選んだら下限より下は補てん無し
 *   - 加入申請の期限: 保険期間が始まる前の月の末日 (個人は1〜12月の保険期間 → 前年12月末)
 *   - 期限の事前通知 (60日前から・7日前からは急ぎ・過ぎたら期限切れ)
 *   - 水田政策: 令和9年度 (2027) 以降は見直し中で値が確定していない → 「暫定」の印
 *   - 収入保険と農業共済・ナラシ対策・野菜価格安定制度は選択加入
 * 補てん金の円未満の扱いは一次資料に無いため切り捨てを既定にしている (要確認)。実際の補てん額は NOSAI (農業共済組合) の算定による。
 */
import { INCOME_INSURANCE_RULES as R, RICE_PADDY_POLICY } from './primary_industry_ledger';

export interface IncomeInsuranceInput {
  /** 基準収入 (円) */
  standardIncome: number;
  /** 青色申告実績の年数 (5年以上は5) */
  blueYears: number;
  /** insurance_only = 保険方式補償充実タイプ / with_reserve = 積立方式併用タイプ */
  type: 'insurance_only' | 'with_reserve';
  /** 保険方式の補償限度 (例 0.8) */
  insuranceLimitRate: number;
  /** 積立方式の補償幅 (0.05 又は 0.1・積立方式併用のとき) */
  reserveWidthRate?: number;
  /** 保険方式の支払率 (0.9〜0.5) */
  insurancePayRate: number;
  /** 積立方式の支払率 (0.9〜0.1・保険方式の支払率以下) */
  reservePayRate?: number;
  /** 補償の下限 (0.7 / 0.6 / 0.5)。選ばなければ無し */
  floorRate?: number;
  /** 保険期間の収入 (円) */
  actualIncome: number;
}

export interface IncomeInsuranceResult {
  status: 'ok' | 'invalid';
  payout: number;
  insurancePart: number;
  reservePart: number;
  /** 補償限度額 (円) */
  coverageLimitAmount: number;
  /** 補てんの上限 (収入が0又は補償の下限まで下がったときの補てん金) */
  maxPayout: number;
  errors: string[];
  notes: string[];
}

const near = (a: number, list: readonly number[]) => list.some((x) => Math.abs(x - a) < 1e-9);
/** 円×割合 を 1/10000 の整数で計算して切り捨てる (浮動小数の誤差を避ける) */
const mul = (yen: number, rate: number) => Math.floor((yen * Math.round(rate * 10000)) / 10000);

export function calcIncomeInsurancePayout(i: IncomeInsuranceInput): IncomeInsuranceResult {
  const errors: string[] = [];
  const notes = ['補てん金の円未満は切り捨てで計算しています (一次資料に端数処理の記載が無いため要確認)。実際の補てん額は農業共済組合 (NOSAI) の算定によります。'];
  const yrs = Math.min(5, Math.floor(Number(i.blueYears)));
  if (!(yrs >= R.minBlueYears)) errors.push('収入保険に加入するには、保険期間の前年1年分以上の青色申告実績が必要です。');
  if (!(i.standardIncome > 0)) errors.push('基準収入を入力してください。');
  if (!(i.actualIncome >= 0)) errors.push('保険期間の収入を入力してください。');
  const w = i.type === 'with_reserve' ? Number(i.reserveWidthRate ?? NaN) : 0;
  if (i.type === 'with_reserve' && !near(w, R.reserveWidthChoices)) errors.push('積立方式の補償幅は5%又は10%から選びます。');
  if (yrs >= 1) {
    const cap = R.coverageCapByBlueYears[yrs];
    if (!near(i.insuranceLimitRate, R.insuranceLimitChoicesByBlueYears[yrs] || [])) errors.push(`青色申告実績${yrs}年で選べる保険方式の補償限度ではありません (${(R.insuranceLimitChoicesByBlueYears[yrs] || []).map((x) => `${Math.round(x * 100)}%`).join('・')})。`);
    if (i.insuranceLimitRate + (Number.isFinite(w) ? w : 0) > cap + 1e-9) errors.push(`補償限度 (保険方式＋積立方式) が青色申告実績${yrs}年の上限 ${Math.round(cap * 100)}% を超えています。`);
  }
  if (!near(i.insurancePayRate, R.insurancePayRateChoices)) errors.push('保険方式の支払率は9割〜5割から選びます。');
  const b = i.type === 'with_reserve' ? Number(i.reservePayRate ?? NaN) : 0;
  if (i.type === 'with_reserve') {
    if (!near(b, R.reservePayRateChoices)) errors.push('積立方式の支払率は9割〜1割から選びます。');
    else if (b > i.insurancePayRate + 1e-9) errors.push('積立方式の支払率は保険方式の支払率以下から選びます。');
  }
  if (i.floorRate !== undefined && !near(i.floorRate, R.floorRateChoices)) errors.push('補償の下限は基準収入の7割・6割・5割から選びます。');
  if (errors.length) return { status: 'invalid', payout: 0, insurancePart: 0, reservePart: 0, coverageLimitAmount: 0, maxPayout: 0, errors, notes };

  const B = i.standardIncome;
  const P = mul(B, i.insuranceLimitRate); // 保険方式の補償限度額
  const L = mul(B, i.insuranceLimitRate + w); // 補償限度額 (全体)
  const F = i.floorRate !== undefined ? mul(B, i.floorRate) : 0; // 補償の下限
  const calc = (income: number) => {
    const r = Math.max(income, F);
    const ins = mul(Math.max(0, P - r), i.insurancePayRate);
    const res = i.type === 'with_reserve' ? mul(Math.max(0, L - Math.max(r, P)), b) : 0;
    return { ins, res };
  };
  const now = calc(i.actualIncome);
  const mx = calc(0);
  if (i.floorRate !== undefined) notes.push(`補償の下限 (基準収入の${Math.round(i.floorRate * 100)}%) を選んでいるため、収入がそれを下回った分の補てんはありません。`);
  return {
    status: 'ok',
    payout: now.ins + now.res,
    insurancePart: now.ins,
    reservePart: now.res,
    coverageLimitAmount: L,
    maxPayout: mx.ins + mx.res,
    errors: [],
    notes,
  };
}

// ---------------- 加入申請の期限 ----------------
const lastDayOfPrevMonth = (iso: string) => {
  const d = new Date(`${iso.slice(0, 7)}-01T00:00:00Z`);
  d.setUTCDate(0);
  return d.toISOString().slice(0, 10);
};

/** 収入保険の加入申請の期限 (保険期間が始まる前の月の末日) */
export function incomeInsuranceApplicationDeadline(i: { kind: 'individual' | 'corporation'; periodStart: string }): { deadline: string; note: string } {
  const start = i.kind === 'individual' ? `${i.periodStart.slice(0, 4)}-01-01` : i.periodStart;
  return {
    deadline: lastDayOfPrevMonth(start),
    note: `加入申請は保険期間が始まる前の月までに、最寄りの農業共済組合で行います (保険期間の開始 ${start})。${i.kind === 'individual' ? '個人の保険期間は1〜12月です。' : '法人は事業年度の1年間が保険期間です。'}`,
  };
}

// ---------------- 期限の事前通知 ----------------
export interface DeadlineItem { label: string; deadline: string }
export interface DeadlineNotice { label: string; deadline: string; daysLeft: number; level: 'upcoming' | 'urgent' | 'overdue'; message: string }

/** 期限の60日前から事前通知・7日前から急ぎ・過ぎたら期限切れ (共済の申込期限など、利用者が入力した期限にも使う) */
export function deadlineNotices(items: DeadlineItem[], today: string, opts: { leadDays?: number; urgentDays?: number } = {}): DeadlineNotice[] {
  const lead = opts.leadDays ?? 60;
  const urgent = opts.urgentDays ?? 7;
  const t = Date.parse(`${today}T00:00:00Z`);
  const out: DeadlineNotice[] = [];
  for (const it of items) {
    const d = Date.parse(`${it.deadline}T00:00:00Z`);
    if (Number.isNaN(d) || Number.isNaN(t)) continue;
    const left = Math.round((d - t) / 86400000);
    if (left > lead) continue;
    const level: DeadlineNotice['level'] = left < 0 ? 'overdue' : left <= urgent ? 'urgent' : 'upcoming';
    const message = level === 'overdue'
      ? `${it.label}の期限 (${it.deadline}) を${-left}日過ぎています。農業共済組合に至急ご相談ください。`
      : level === 'urgent'
        ? `${it.label}の期限 (${it.deadline}) まであと${left}日です。お早めに手続をしてください。`
        : `${it.label}の期限は ${it.deadline} です (あと${left}日)。`;
    out.push({ label: it.label, deadline: it.deadline, daysLeft: left, level, message });
  }
  return out;
}

// ---------------- 水田政策の暫定表示 ----------------
export function ricePaddyPolicyStatus(fiscalYear: number): { fiscalYear: number; provisional: boolean; label: string; message: string; source: string } {
  const P = RICE_PADDY_POLICY;
  const src = P.sources[0];
  if (fiscalYear >= P.provisionalFromFiscalYear) {
    return {
      fiscalYear,
      provisional: true,
      label: `暫定 (令和${fiscalYear - 2018}年度・制度見直し中)`,
      message: `令和${fiscalYear - 2018}年度以降の水田政策 (水田活用の直接支払交付金・経営所得安定対策) は見直し中で、単価・要件が確定していません。表示している内容は暫定です。確定したら差し替えます。確認先: 農林水産省「経営所得安定対策等」`,
      source: `${src.title} ${src.url}`,
    };
  }
  return {
    fiscalYear,
    provisional: false,
    label: `令和${fiscalYear - 2018}年度`,
    message: `令和${fiscalYear - 2018}年度の実施要綱・パンフレットに基づきます。単価・要件は農林水産省の資料で確認してください。`,
    source: `${src.title} ${src.url}`,
  };
}

// ---------------- 類似制度との選択加入 ----------------
export function checkSafetyNetOverlap(i: { incomeInsurance?: boolean; cropMutualAid?: boolean; narashi?: boolean; vegetablePriceStabilization?: boolean }): { conflict: boolean; message: string } {
  const others = [i.cropMutualAid && '農業共済', i.narashi && 'ナラシ対策', i.vegetablePriceStabilization && '野菜価格安定制度'].filter(Boolean) as string[];
  if (i.incomeInsurance && others.length) {
    return { conflict: true, message: `収入保険と${others.join('・')}は、どちらかを選択して加入する制度です (国費の二重助成を避けるため)。加入の組み合わせを農業共済組合で確認してください。` };
  }
  return { conflict: false, message: '' };
}
