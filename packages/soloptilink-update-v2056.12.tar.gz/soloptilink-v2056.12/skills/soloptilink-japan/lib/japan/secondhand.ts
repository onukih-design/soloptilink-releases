/**
 * lib/japan/secondhand.ts — 古物商/質屋DNA
 *
 * 法令カバレッジ:
 *  - 古物営業法 (S24法律108)
 *  - 古物営業法施行規則 (古物台帳/HP届出/非対面取引時の本人確認)
 *  - 質屋営業法 (S25法律158)
 *  - 質屋営業法施行規則
 *  - 犯罪収益移転防止法 (古物商も対象 — 200万円超現金取引時)
 *  - 国家公安委員会規則 (古物の品目13区分)
 *  - 古物市場主許可
 *
 * 参考: 警察庁生活安全局, 全日本古物商連合会, 全国質屋組合連合会
 */

// ============================================================================
// 1. 古物 13区分 (古物営業法施行規則2条)
// ============================================================================

export const KOBUTSU_CATEGORIES = [
  { code: '01', ja: '美術品類', examples: ['書画', '彫刻', '骨董'] },
  { code: '02', ja: '衣類', examples: ['古着', '織物', 'ビンテージ'] },
  { code: '03', ja: '時計・宝飾品類', examples: ['ロレックス', 'ダイヤ', '指輪'] },
  { code: '04', ja: '自動車', examples: ['中古車'] },
  { code: '05', ja: '自動二輪車及び原動機付自転車', examples: ['バイク', '原付'] },
  { code: '06', ja: '自転車類', examples: ['中古自転車'] },
  { code: '07', ja: '写真機類', examples: ['カメラ', 'レンズ'] },
  { code: '08', ja: '事務機器類', examples: ['PC', 'コピー機', 'プリンタ'] },
  { code: '09', ja: '機械工具類', examples: ['電動工具', '農機具'] },
  { code: '10', ja: '道具類', examples: ['家具', '楽器', 'スポーツ用品', 'CD/DVD'] },
  { code: '11', ja: '皮革・ゴム製品類', examples: ['ブランドバッグ', '靴'] },
  { code: '12', ja: '書籍', examples: ['古本', '中古教科書'] },
  { code: '13', ja: '金券類', examples: ['商品券', 'チケット', '株主優待券'] },
] as const;

export type KobutsuCategory = typeof KOBUTSU_CATEGORIES[number]['code'];

// ============================================================================
// 2. 古物商許可 (古物営業法3条)
// ============================================================================

export interface KobutsuPermitApplication {
  applicantKind: 'individual' | 'corporation';
  hasResponsibleManager: boolean; // 営業所管理者 (古物営業法13条)
  managerHasNoCriminalRecord5y: boolean; // 5年以内に古物営業法違反/刑法違反等なし
  isAdult: boolean;
  hasFixedBusinessLocation: boolean;
  primaryCategories: KobutsuCategory[]; // 主として扱う品目
  hasPlateAtSite: boolean; // 標識掲示
  hasURL?: string; // ネット上で取引する場合は届出
  hasNonFaceToFaceVerificationProcess: boolean; // 非対面本人確認手順
}

/** 古物商許可 事前審査 */
export function evaluateKobutsuPermit(a: KobutsuPermitApplication): {
  approvable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (!a.isAdult) blockers.push('成年被後見人/被保佐人 — 欠格事由 (4条1号)');
  if (!a.managerHasNoCriminalRecord5y) {
    blockers.push('5年以内に禁錮以上 or 古物営業法違反 — 欠格 (4条2-3号)');
  }
  if (!a.hasResponsibleManager) blockers.push('営業所管理者必須 (法13条)');
  if (!a.hasFixedBusinessLocation) blockers.push('営業所所在地 (固定) 必須');
  if (a.primaryCategories.length === 0) blockers.push('主として扱う品目を1つ以上指定');
  if (a.hasURL && !a.hasNonFaceToFaceVerificationProcess) {
    blockers.push('HP取引 — 非対面本人確認手順 必須 (規則15条 H30改正)');
  }
  if (!a.hasPlateAtSite) blockers.push('営業所に標識掲示必須 (法12条)');
  return { approvable: blockers.length === 0, blockers };
}

// ============================================================================
// 3. 古物台帳 (法16条) — 取引記録義務
// ============================================================================

export interface KobutsuTransactionEntry {
  transactionDate: Date;
  transactionType: 'buy' | 'sell' | 'swap' | 'consignment'; // 買受/売却/交換/委託
  itemDescription: string;
  itemCategory: KobutsuCategory;
  itemPriceJpy: number;
  serialOrFeature: string; // 製造番号 or 特徴
  // 相手方情報
  counterpartyName: string;
  counterpartyAddress: string;
  counterpartyAge?: number;
  counterpartyOccupation?: string;
  identityVerifiedBy: 'driver_license' | 'passport' | 'mynumber_card' | 'health_insurance' | 'foreign_id';
}

/**
 * 対価の総額が1万円未満でも、相手方の確認と帳簿等への記載が要る古物 (古物営業法施行規則16条2項)
 *   令和7年10月1日施行の改正で エアコンの室外ユニット・電気温水機器のヒートポンプ／電線／金属製グレーチング が追加された。
 *   美術品・時計・宝飾品・金券・機械工具は含まれない (旧実装の「強制6品目」は誤り・2026-10-01 是正)。
 *   出典: 古物営業法施行規則 (平成7年国家公安委員会規則第10号) 第16条 — e-Gov 法令API v2 で 2026-09-30 に確認 (調査報告 F9-42)、
 *         警視庁「古物営業法施行規則の一部改正について（令和7年10月1日施行）」
 */
export const KOBUTSU_SMALL_AMOUNT_EXCEPTION_ITEMS = [
  { kind: 'motorcycle', ja: '自動二輪車及び原動機付自転車 (部分品を含む)' },
  { kind: 'ac_outdoor_unit_or_heat_pump', ja: 'エアコンディショナーの室外ユニット・電気温水機器のヒートポンプ (令和7年10月1日追加)' },
  { kind: 'game_software', ja: '専ら家庭用コンピュータゲームに用いられるプログラムを記録した物' },
  { kind: 'optical_media', ja: '光学的方法により音・影像・プログラムを記録した物 (CD・DVD・BD 等)' },
  { kind: 'electric_wire', ja: '電線 (令和7年10月1日追加。LANケーブル・家庭用延長コード・充電ケーブル等は対象外)' },
  { kind: 'metal_grating', ja: 'グレーチング (金属製のものに限る。令和7年10月1日追加)' },
  { kind: 'book', ja: '書籍' },
] as const;

export type KobutsuSmallAmountExceptionKind = typeof KOBUTSU_SMALL_AMOUNT_EXCEPTION_ITEMS[number]['kind'];

/** 令和7年10月1日施行の改正で追加された品目 (この日より前の取引では例外品目に当たらない) */
export const KOBUTSU_EXCEPTION_ADDED_2025_10_01: ReadonlyArray<KobutsuSmallAmountExceptionKind> = ['ac_outdoor_unit_or_heat_pump', 'electric_wire', 'metal_grating'];
export const KOBUTSU_EXCEPTION_REVISION_DATE = '2025-10-01';

/** 13区分のうち、区分そのものが少額の例外に当たるもの (05 自動二輪車及び原付 / 12 書籍) */
const CATEGORY_TO_EXCEPTION: Partial<Record<KobutsuCategory, KobutsuSmallAmountExceptionKind>> = {
  '05': 'motorcycle',
  '12': 'book',
};

/** 取引記録義務の判定 (法16条) — 1万円未満の一部例外あり */
export function requiresLedgerEntry(input: {
  transactionType: KobutsuTransactionEntry['transactionType'];
  itemPriceJpy: number;
  itemCategory: KobutsuCategory;
  /** 少額の例外品目に当たるときの種類 (13区分では判別できない 室外機・電線・ゲームソフト等を指定する) */
  itemKind?: KobutsuSmallAmountExceptionKind;
  /** 取引日 (省略時は今日)。令和7年10月1日より前は追加3品目を例外品目として扱わない */
  transactionDate?: Date | string;
}): { required: boolean; reason: string } {
  if (input.transactionType === 'sell') {
    // 売却時の記録対象の品目は施行規則で別に定められている (本関数では未照合・要一次確認)。
    // 記録漏れを防ぐ安全側として、従来どおり 美術品類・時計宝飾品類・自動車・自動二輪車 は金額に関わらず記録とする。
    const sellCategories: KobutsuCategory[] = ['01', '03', '04', '05'];
    if (sellCategories.includes(input.itemCategory)) {
      return { required: true, reason: `売却: 品目 ${input.itemCategory} — 記録する (売却時の対象品目は要一次確認・安全側)` };
    }
    if (input.itemPriceJpy >= 10_000) return { required: true, reason: '売却: 1万円以上 — 記録する (要一次確認・安全側)' };
    return { required: false, reason: '売却: 1万円未満 — 記録義務の対象外の可能性 (売却時の対象品目は要一次確認)' };
  }
  // 買受け・交換・委託: 対価の総額が1万円以上なら確認・記録が要る
  if (input.itemPriceJpy >= 10_000) {
    return { required: true, reason: '1万円以上 — 確認・記録が必要 (古物営業法15条・16条)' };
  }
  const kind = input.itemKind ?? CATEGORY_TO_EXCEPTION[input.itemCategory];
  const hit = kind ? KOBUTSU_SMALL_AMOUNT_EXCEPTION_ITEMS.find((x) => x.kind === kind) : undefined;
  const td = input.transactionDate ?? new Date();
  const ymd = typeof td === 'string'
    ? td.slice(0, 10)
    : `${td.getFullYear()}-${String(td.getMonth() + 1).padStart(2, '0')}-${String(td.getDate()).padStart(2, '0')}`;
  if (hit && KOBUTSU_EXCEPTION_ADDED_2025_10_01.includes(hit.kind) && ymd < KOBUTSU_EXCEPTION_REVISION_DATE) {
    return { required: false, reason: `1万円未満・${hit.ja} は ${KOBUTSU_EXCEPTION_REVISION_DATE} 以後の取引から例外品目 (この取引日は改正前)` };
  }
  if (hit) {
    return { required: true, reason: `1万円未満でも確認・記録が必要な古物 — ${hit.ja} (施行規則16条2項)` };
  }
  return { required: false, reason: '1万円未満・例外品目に当たらない — 確認・記録の義務なし (任意の記録は推奨)' };
}

/** 古物台帳 保存期間: 最終記入日から3年 (規則18条) */
export const KOBUTSU_LEDGER_RETENTION_YEARS = 3;

// ============================================================================
// 4. 犯罪収益移転防止法 — 古物商も対象 (200万円超現金取引時)
// ============================================================================

/** 200万円超の現金取引で本人確認+取引記録+疑わしい取引届出 (犯収法4条/8条) */
export function requiresAmlVerification(input: {
  transactionPriceJpy: number;
  isCashTransaction: boolean;
  itemCategory: KobutsuCategory;
}): { required: boolean; reason: string } {
  if (input.transactionPriceJpy > 2_000_000 && input.isCashTransaction) {
    return {
      required: true,
      reason: '犯収法4条 — 200万円超現金取引で本人確認+取引記録 7年保存',
    };
  }
  // 貴金属 (金/プラチナ) は更に厳格 — 200万円超で本人確認 (犯収法施行令)
  if (input.itemCategory === '03' && input.transactionPriceJpy > 2_000_000) {
    return {
      required: true,
      reason: '時計宝飾品類 200万円超 — 犯収法本人確認',
    };
  }
  return { required: false, reason: '閾値以下' };
}

// ============================================================================
// 5. 質屋営業法 (S25法律158)
// ============================================================================

export interface ShichiyaPermitApplication {
  hasPermit: boolean; // 都道府県公安委員会許可 (法2条)
  hasFireResistantStorage: boolean; // 質物保管施設 (耐火構造)
  storageM2: number;
  hasResponsibleManager: boolean;
  managerHasNoCriminalRecord5y: boolean;
}

/** 質屋営業 許可審査 */
export function evaluateShichiyaPermit(a: ShichiyaPermitApplication): {
  approvable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (!a.hasFireResistantStorage) blockers.push('耐火構造の質物保管庫必須 (規則4条)');
  if (a.storageM2 < 5) blockers.push('保管庫 5m²以上が目安');
  if (!a.hasResponsibleManager) blockers.push('営業所管理者必須');
  if (!a.managerHasNoCriminalRecord5y) blockers.push('管理者の欠格事由なきこと');
  return { approvable: blockers.length === 0, blockers };
}

// ============================================================================
// 6. 質屋利息制限 (質屋営業法 36条 + 利息制限法 連動)
// ============================================================================

/**
 * 質屋営業法36条の上限利息 — 年109.5% (2月29日を含む1年は109.8%)、1日あたり0.3%
 *   1日あたり0.3% で日数を掛けて上限を出す (30日なら9%)。旧実装の「月8%」は誤り (2026-10-01 是正)。
 *   出典: 質屋営業法 (昭和25年法律第158号) 第36条 — e-Gov 法令API v2 で 2026-09-30 に確認 (調査報告 F9-41)
 */
export const SHICHIYA_MAX_DAILY_RATE = 0.003;

export function calcMaxShichiyaInterest(input: {
  principalJpy: number;
  loanPeriodDays: number;
}): { maxInterestJpy: number; maxRatePerMonthPct: number; reason: string } {
  // 円未満は切り捨て (上限額なので、切り捨てれば上限を超えない側になる)
  const maxInterest = Math.floor((input.principalJpy * Math.round(SHICHIYA_MAX_DAILY_RATE * 10000) * input.loanPeriodDays) / 10000);
  return {
    maxInterestJpy: maxInterest,
    maxRatePerMonthPct: 9.0, // 30日を1か月とした換算 (0.3% × 30日)
    reason: '質屋営業法36条 1日あたり0.3% (年109.5%。30日換算で9%) — 利息制限法より緩和',
  };
}

/** 質物の流質期限 — 弁済期日から3ヶ月 (法18条) */
export function calcShichiyaForfeitureDate(loanDate: Date, loanPeriodDays: number): {
  redemptionDeadline: Date;
  forfeitureDate: Date;
} {
  const redemptionDeadline = new Date(loanDate);
  redemptionDeadline.setDate(redemptionDeadline.getDate() + loanPeriodDays);
  const forfeitureDate = new Date(redemptionDeadline);
  forfeitureDate.setMonth(forfeitureDate.getMonth() + 3);
  return { redemptionDeadline, forfeitureDate };
}

// ============================================================================
// 7. 質物台帳 (法11条 — 古物台帳と類似)
// ============================================================================

/** 質物台帳 保存期間: 最終記入日から3年 */
export const SHICHIYA_LEDGER_RETENTION_YEARS = 3;

// ============================================================================
// 8. 古物市場主許可 (古物営業法2条2項3号)
// ============================================================================

/** 古物市場主 (古物商間の取引市場を主催) の許可要件 */
export function evaluateKobutsuMarketPermit(input: {
  hasMarketRules: boolean; // 市場規程
  hasMemberAuthenticationProcess: boolean; // 会員古物商の許可番号確認
  hasTransactionLogPersistence: boolean; // 落札記録の永続保存
}): { approvable: boolean; blockers: string[] } {
  const blockers: string[] = [];
  if (!input.hasMarketRules) blockers.push('市場規程の制定必須');
  if (!input.hasMemberAuthenticationProcess) {
    blockers.push('会員古物商の古物商許可番号確認手順必須');
  }
  if (!input.hasTransactionLogPersistence) {
    blockers.push('市場での落札記録の永続保存 (3年以上)');
  }
  return { approvable: blockers.length === 0, blockers };
}
