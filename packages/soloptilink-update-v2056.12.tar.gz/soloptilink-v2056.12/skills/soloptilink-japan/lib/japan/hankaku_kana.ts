/**
 * 半角カナ → 全角カナ（lib/japan の半角カナ変換の唯一の処理）
 *
 * 2026-09-30 REQ-JPO-FIX-006: 旧実装は1文字ずつ写すだけで濁点を合成せず（ｶﾞ→「カ゛」）、
 *   句読点 ｡｢｣､ を範囲外として素通りさせていた。ひな形側は2文字ずつ区切って照合したため、
 *   連続カナで1字おきに変換されなかった（ｱｲｳｴｵ→ｱｲｳｴオ）。両方ともこの関数を呼ぶ形に寄せた。
 *
 * 決まり:
 *   - 半角カナ（U+FF61〜U+FF9F）だけを変換する。全角文字・英数字には触らない。
 *   - 直後の半角濁点 ﾞ・半濁点 ﾟ は、合成できる字（ｶﾞ→ガ、ﾊﾟ→パ、ｳﾞ→ヴ）なら1字に合成する
 *     （Unicode 正規化 UAX #15 の NFKC と同じ結果。ただし下の ﾜﾞ・ｦﾞ を除く）。
 *   - 合成できない濁点・半濁点は、単独の「゛」(U+309B)「゜」(U+309C) にする（結合用 U+3099/U+309A は使わない）。
 *   - ★ﾜﾞ・ｦﾞ は合成しない既定（「ワ゛」「ヲ゛」）: 合成先の「ヷ」「ヺ」は JIS X 0208 に無く、
 *     Shift_JIS で CSV 等を書き出す業務で文字化けの原因になるため（オーナー判断の既定・要確認）。
 *     該当箇所は findUncomposedVoicedKana() で要確認として取り出せる。
 */

// 半角カナ（U+FF61〜U+FF9D）→ 全角カナ・記号（清音の形）
const BASE: Readonly<Record<string, string>> = {
  '｡': '。', '｢': '「', '｣': '」', '､': '、', '･': '・',
  'ｦ': 'ヲ', 'ｧ': 'ァ', 'ｨ': 'ィ', 'ｩ': 'ゥ', 'ｪ': 'ェ', 'ｫ': 'ォ', 'ｬ': 'ャ', 'ｭ': 'ュ', 'ｮ': 'ョ', 'ｯ': 'ッ', 'ｰ': 'ー',
  'ｱ': 'ア', 'ｲ': 'イ', 'ｳ': 'ウ', 'ｴ': 'エ', 'ｵ': 'オ',
  'ｶ': 'カ', 'ｷ': 'キ', 'ｸ': 'ク', 'ｹ': 'ケ', 'ｺ': 'コ',
  'ｻ': 'サ', 'ｼ': 'シ', 'ｽ': 'ス', 'ｾ': 'セ', 'ｿ': 'ソ',
  'ﾀ': 'タ', 'ﾁ': 'チ', 'ﾂ': 'ツ', 'ﾃ': 'テ', 'ﾄ': 'ト',
  'ﾅ': 'ナ', 'ﾆ': 'ニ', 'ﾇ': 'ヌ', 'ﾈ': 'ネ', 'ﾉ': 'ノ',
  'ﾊ': 'ハ', 'ﾋ': 'ヒ', 'ﾌ': 'フ', 'ﾍ': 'ヘ', 'ﾎ': 'ホ',
  'ﾏ': 'マ', 'ﾐ': 'ミ', 'ﾑ': 'ム', 'ﾒ': 'メ', 'ﾓ': 'モ',
  'ﾔ': 'ヤ', 'ﾕ': 'ユ', 'ﾖ': 'ヨ',
  'ﾗ': 'ラ', 'ﾘ': 'リ', 'ﾙ': 'ル', 'ﾚ': 'レ', 'ﾛ': 'ロ',
  'ﾜ': 'ワ', 'ﾝ': 'ン',
};

// 濁点で合成する組（全角の清音 → 濁音）。ﾜﾞ・ｦﾞ は既定で合成しないため載せない
const DAKUTEN: Readonly<Record<string, string>> = {
  'カ': 'ガ', 'キ': 'ギ', 'ク': 'グ', 'ケ': 'ゲ', 'コ': 'ゴ',
  'サ': 'ザ', 'シ': 'ジ', 'ス': 'ズ', 'セ': 'ゼ', 'ソ': 'ゾ',
  'タ': 'ダ', 'チ': 'ヂ', 'ツ': 'ヅ', 'テ': 'デ', 'ト': 'ド',
  'ハ': 'バ', 'ヒ': 'ビ', 'フ': 'ブ', 'ヘ': 'ベ', 'ホ': 'ボ',
  'ウ': 'ヴ',
};
// 半濁点で合成する組
const HANDAKUTEN: Readonly<Record<string, string>> = {
  'ハ': 'パ', 'ヒ': 'ピ', 'フ': 'プ', 'ヘ': 'ペ', 'ホ': 'ポ',
};

const HALF_DAKU = 'ﾞ'; // ﾞ
const HALF_HANDAKU = 'ﾟ'; // ﾟ
const LONE_DAKU = '゛'; // ゛
const LONE_HANDAKU = '゜'; // ゜

/** 半角カナを全角カナにする（濁点・半濁点は合成できる字だけ1字に合成） */
export function hankakuKanaToZenkaku(s: string): string {
  return String(s ?? '').replace(/[｡-ﾟ]+/g, (run) => {
    let out = '';
    for (let i = 0; i < run.length; i++) {
      const ch = run[i];
      if (ch === HALF_DAKU) { out += LONE_DAKU; continue; }
      if (ch === HALF_HANDAKU) { out += LONE_HANDAKU; continue; }
      const base = BASE[ch] ?? ch;
      const next = run[i + 1];
      if (next === HALF_DAKU && DAKUTEN[base]) { out += DAKUTEN[base]; i++; continue; }
      if (next === HALF_HANDAKU && HANDAKUTEN[base]) { out += HANDAKUTEN[base]; i++; continue; }
      out += base;
    }
    return out;
  });
}

/** ﾜﾞ・ｦﾞ（合成しない既定の字）の位置を要確認として返す */
export function findUncomposedVoicedKana(s: string): Array<{ index: number; text: string; reason_ja: string }> {
  const hits: Array<{ index: number; text: string; reason_ja: string }> = [];
  const re = /[ﾜｦ]ﾞ/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(String(s ?? ''))) !== null) {
    hits.push({ index: m.index, text: m[0], reason_ja: '「ヷ」「ヺ」は Shift_JIS で書き出せないため合成していません（要確認）' });
  }
  return hits;
}
