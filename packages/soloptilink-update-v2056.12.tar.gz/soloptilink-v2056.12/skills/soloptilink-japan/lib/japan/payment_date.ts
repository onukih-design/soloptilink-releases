/**
 * 締め日・支払日・休日の繰り方から支払日を出す (取引日 → 締め → 支払予定日 → 休業日の調整)
 *
 * ★2026-10-03 新設 (REQ-JPO-MNY-020・T08)。
 *   既存の toriteki.payDateByPolicy・bug_prevention.calcPaymentDueDate は休業日の調整をせず、土日祝の支払日を出し得た。
 *   ここでは祝日・銀行の休日の正本 calendar/jp_calendar.ts で営業日を判定し、休日の繰り方 (前の営業日・翌営業日) を当てる。
 *
 * 【出典 — 一次情報】
 *   - 国民の祝日に関する法律 第2条・第3条 / 内閣府「国民の祝日」CSV (jp_calendar.ts が正本。2028年以降は予定値)
 *   - 銀行法施行令 (e-Gov 357CO0000000040) 第5条1項: 12月31日〜1月3日は銀行の休日 (振込で払うため既定の休業日)
 *   - 取適法 第3条 (受領日から起算して60日以内) と休業日の順延は toriteki.checkToritekiPaymentDate で検査する
 *
 * 【決めごと】
 *   - 締め日・支払日が月の日数を超えるときは、その月の末日 (例: 30日締めの2月は2月末日)。
 *   - 取引日が締め日以前ならその月の締め、締め日の翌日以降なら翌月の締め。支払月 = 締めの月 + offsetMonths。
 *   - 支払日が締め日以前になる条件 (例: 20日締め・当月10日払い) は拒む (日本語の理由を付けた例外)。
 *   - 2028年以降の祝日は公示前の予定値。支払日・予定日のどちらかが2028年以降なら certainty='provisional' と注意を返す。
 */
import {
  JP_HOLIDAY_LAST_OFFICIAL_YEAR, daysInMonth, toJstYmd, isJpBusinessDay, addJpBusinessDays, diffDaysYmd,
  type JpClosedDaySet,
} from './calendar/jp_calendar';
import { checkToritekiPaymentDate, type Verdict } from './toriteki';

export interface PaymentTerms {
  /** 締め日 (1〜31・月の日数を超えれば月末) または 'endOfMonth' */
  closeDay: number | 'endOfMonth';
  /** 支払日 (1〜31・月の日数を超えれば月末) または 'endOfMonth' */
  payDay: number | 'endOfMonth';
  /** 締めの月から何か月後に払うか (0=当月・1=翌月・2=翌々月) */
  offsetMonths: number;
  /** 支払予定日が休業日のとき: previous=前の営業日 / next=翌営業日 */
  holidayRule: 'previous' | 'next';
  /** 休業日の集合 (既定 'bank' = 土日・祝日・12/31〜1/3) */
  closedDays?: JpClosedDaySet;
  /** 会社独自の休業日 */
  extraClosedDates?: readonly string[];
}

export interface PaymentDateResult {
  transactionDate: string;
  closingDate: string;
  /** 休業日の調整をする前の支払予定日 */
  scheduledDate: string;
  /** 休業日を調整した支払日 */
  paymentDate: string;
  adjusted: boolean;
  /** 予定日から支払日までの日数 (前倒しは負) */
  shiftDays: number;
  /** 2028年以降の祝日 (公示前の予定値) に依存するなら provisional */
  certainty: 'confirmed' | 'provisional';
  warnings: string[];
  /** toriteki を渡したときだけ: 取適法の支払期日の検査 */
  toriteki?: { verdict: Verdict; reasons: string[] };
}

const pad2 = (n: number) => String(n).padStart(2, '0');
const ymd = (y: number, m: number, d: number) => `${y}-${pad2(m)}-${pad2(d)}`;
function norm(y: number, m: number): [number, number] {
  let yy = y; let mm = m;
  while (mm > 12) { mm -= 12; yy++; }
  while (mm < 1) { mm += 12; yy--; }
  return [yy, mm];
}
function dayOf(spec: number | 'endOfMonth', y: number, m: number): number {
  const last = daysInMonth(y, m);
  return spec === 'endOfMonth' ? last : Math.min(spec, last);
}

export function calcPaymentDate(
  transactionDate: Date | string,
  terms: PaymentTerms,
  opts: { toriteki?: { receivedAt?: Date | string; agreedShiftInWriting?: boolean; monthlyClosing?: boolean } } = {},
): PaymentDateResult {
  const { closeDay, payDay, offsetMonths, holidayRule } = terms;
  if (!(closeDay === 'endOfMonth' || (Number.isInteger(closeDay) && closeDay >= 1 && closeDay <= 31))) throw new Error(`締め日は1〜31日か「月末」で指定してください (受け取った値: ${String(closeDay)})`);
  if (!(payDay === 'endOfMonth' || (Number.isInteger(payDay) && payDay >= 1 && payDay <= 31))) throw new Error(`支払日は1〜31日か「月末」で指定してください (受け取った値: ${String(payDay)})`);
  if (!Number.isInteger(offsetMonths) || offsetMonths < 0 || offsetMonths > 12) throw new Error(`支払月は締めの月から0〜12か月後で指定してください (受け取った値: ${String(offsetMonths)})`);
  if (holidayRule !== 'previous' && holidayRule !== 'next') throw new Error(`休日の繰り方は「前の営業日 (previous)」か「翌営業日 (next)」で指定してください (受け取った値: ${String(holidayRule)})`);
  const cal = { closedDays: terms.closedDays ?? ('bank' as JpClosedDaySet), extraClosedDates: terms.extraClosedDates };

  const tx = toJstYmd(transactionDate);
  const [y, m, d] = tx.split('-').map(Number);
  let [cy, cm] = [y, m];
  if (d > dayOf(closeDay, y, m)) [cy, cm] = norm(y, m + 1);
  const closingDate = ymd(cy, cm, dayOf(closeDay, cy, cm));
  const [py, pm] = norm(cy, cm + offsetMonths);
  const scheduledDate = ymd(py, pm, dayOf(payDay, py, pm));
  if (scheduledDate <= closingDate) {
    throw new Error(`支払日 (${scheduledDate}) が締め日 (${closingDate}) 以前になる支払条件です。締め日・支払日・何か月後の組合せを見直してください。`);
  }
  let paymentDate = scheduledDate;
  if (!isJpBusinessDay(scheduledDate, cal)) {
    paymentDate = addJpBusinessDays(scheduledDate, holidayRule === 'previous' ? -1 : 1, cal);
  }
  const warnings: string[] = [];
  const lastOfficial = `${JP_HOLIDAY_LAST_OFFICIAL_YEAR}-12-31`;
  const provisional = scheduledDate > lastOfficial || paymentDate > lastOfficial;
  if (provisional) {
    warnings.push(`${JP_HOLIDAY_LAST_OFFICIAL_YEAR + 1}年以降の祝日は内閣府の公表前の予定値 (未確定) で判定しています。春分の日・秋分の日は前年2月の官報で確定するため、確定後に支払日を確かめ直してください。`);
  }
  const res: PaymentDateResult = {
    transactionDate: tx, closingDate, scheduledDate, paymentDate,
    adjusted: paymentDate !== scheduledDate, shiftDays: diffDaysYmd(scheduledDate, paymentDate),
    certainty: provisional ? 'provisional' : 'confirmed', warnings,
  };
  if (opts.toriteki) {
    const received = opts.toriteki.receivedAt ?? tx;
    const r = checkToritekiPaymentDate({
      receivedAt: received, paymentDate, monthlyClosing: opts.toriteki.monthlyClosing ?? true,
      holidayShift: res.adjusted && res.shiftDays > 0 ? { scheduledDate, agreedInWriting: !!opts.toriteki.agreedShiftInWriting } : undefined,
    });
    res.toriteki = { verdict: r.verdict, reasons: r.reasons };
    if (r.verdict !== 'ok') warnings.push(...r.reasons);
  }
  return res;
}
