/**
 * 型・治具・木型・抜型・印版の台帳と、保管の「要対応」判定
 *
 * ★2026-10-03 新設 (REQ-JPO-MNY-018・T08)。
 *
 * 【出典 — 一次情報 (2026-10-03 に本文を開いて確認)】
 *   - 取適法 (e-Gov 331AC0000000120) 第5条2項2号「自己のために金銭、役務その他の経済上の利益を提供させること」
 *   - 取適法 第2条1項: 製造委託には「専らこれらの製造に用いる金型、木型その他の物品の成形用の型若しくは
 *       工作物保持具その他の特殊な工具」の製造の委託を含む
 *   - 公取委 取適法Q&A Q119 https://www.jftc.go.jp/toriteki/toriteki_qa.html
 *       型等 (金型・木型・治具・検具・製造設備等) を中小受託事業者に保管させ、発注を長期間行わない等の事情があるのに
 *       保管費用を支払わずに保管させたときは、不当な経済上の利益の提供要請に「該当するおそれ」がある。
 *       事情の例: ①1年間以上発注しない ②廃棄・引取りの希望を伝えられている ③今後1年間の具体的な発注時期を示せない
 *       ④再使用が想定されていない。保管費用は請求の有無にかかわらず保管期間に応じて支払う。
 *       廃棄・回収か保管継続かも中小受託事業者と協議する。
 *       ※1 委託事業者以外が所有する型等でも、委託事業者が事実上管理しているもの (廃棄に承認が要る等) を含む。
 *
 * 【決めごと】
 *   - 文言は「おそれ」「協議してください」にとどめ、違反と断定しない (違反かどうかは個別の事情で決まる)。
 *   - 「1年間以上」は最終発注日の1年後の応当日以降を該当とする (警告を遅らせない安全側。境目の扱いは要確認)。
 *   - 保管費用の算定根拠の欄は必須 (保管費用が0円のときも、無償の理由を書かせる)。
 */
import { toYmd, type Ymd } from './toriteki';

export type MoldKind = 'die' | 'wooden_pattern' | 'jig' | 'gauge' | 'cutting_die' | 'printing_plate' | 'equipment' | 'other';
export const MOLD_KINDS: ReadonlyArray<{ key: MoldKind; label_ja: string }> = [
  { key: 'die', label_ja: '金型' },
  { key: 'wooden_pattern', label_ja: '木型' },
  { key: 'jig', label_ja: '治具' },
  { key: 'gauge', label_ja: '検具' },
  { key: 'cutting_die', label_ja: '抜型' },
  { key: 'printing_plate', label_ja: '印版' },
  { key: 'equipment', label_ja: '製造設備' },
  { key: 'other', label_ja: 'その他の型・工具' },
];

export interface MoldLedgerEntry {
  id?: string;
  kind: MoldKind;
  name: string;
  contractorName: string;
  /** consignor=委託側所有 / contractor_managed_by_consignor=受託側所有だが委託側が事実上管理 / contractor=受託側所有 */
  owner: 'consignor' | 'contractor_managed_by_consignor' | 'contractor';
  /** 保管している側 */
  storedBy: 'contractor' | 'consignor';
  lastOrderDate: string | null;
  /** 今後の具体的な発注予定日 (示せないなら null) */
  nextOrderPlan?: string | null;
  /** 再使用の予定 (false=予定なし) */
  reuseExpected?: boolean;
  /** 支払った保管費用 (円)。0 は無償 */
  storageFeeYenPaid: number;
  /** 保管費用の算定根拠 (必須。無償ならその理由) */
  storageFeeBasis: string;
  disposalOrReturnRequested: boolean;
  disposalOrReturnRequestedAt?: string | null;
  [k: string]: unknown;
}

export const MOLD_LEDGER_FIELDS: ReadonlyArray<{ key: string; label_ja: string; required: boolean; help_ja?: string }> = [
  { key: 'kind', label_ja: '種類 (金型・木型・治具・検具・抜型・印版・製造設備)', required: true },
  { key: 'name', label_ja: '名称・品番', required: true },
  { key: 'contractorName', label_ja: '保管している取引先', required: true },
  { key: 'owner', label_ja: '所有者', required: true, help_ja: '受託側の所有でも、廃棄に当社の承認が要るなど当社が管理している型は「当社が管理」を選んでください。' },
  { key: 'storedBy', label_ja: '保管している側', required: true },
  { key: 'lastOrderDate', label_ja: '最終発注日', required: true },
  { key: 'nextOrderPlan', label_ja: '今後の発注予定 (具体的な時期)', required: false, help_ja: '今後1年間の具体的な発注時期を示せないときは空欄にしてください。' },
  { key: 'reuseExpected', label_ja: '再使用の予定', required: false },
  { key: 'storageFeeYenPaid', label_ja: '支払った保管費用 (円)', required: false },
  { key: 'storageFeeBasis', label_ja: '保管費用の算定根拠', required: true, help_ja: '自社倉庫の使用料相当額・外部倉庫の使用料・運送費・メンテナンス費用など。無償のときはその理由を書いてください。' },
  { key: 'disposalOrReturnRequested', label_ja: '廃棄・引取りの申出', required: false },
  { key: 'disposalOrReturnRequestedAt', label_ja: '申出の日', required: false },
];

const filled = (v: unknown) => v !== undefined && v !== null && String(v).trim() !== '';

/** 台帳の1行が保存できるか (必須欄。保管費用の算定根拠は空白だけでも不可) */
export function validateMoldLedgerEntry(e: Partial<MoldLedgerEntry>): { ok: boolean; missing: string[]; labels: string[] } {
  const miss = MOLD_LEDGER_FIELDS.filter((f) => f.required && !filled((e as Record<string, unknown>)[f.key]));
  return { ok: miss.length === 0, missing: miss.map((f) => f.key), labels: miss.map((f) => f.label_ja) };
}

function addYears(ymd: Ymd, n: number): Ymd {
  const [y, m, d] = ymd.split('-').map(Number);
  const yy = y + n;
  const last = new Date(Date.UTC(yy, m, 0)).getUTCDate();
  return `${yy}-${String(m).padStart(2, '0')}-${String(Math.min(d, last)).padStart(2, '0')}`;
}
function monthsBetween(from: Ymd, to: Ymd): number {
  const [y1, m1, d1] = from.split('-').map(Number);
  const [y2, m2, d2] = to.split('-').map(Number);
  return (y2 - y1) * 12 + (m2 - m1) - (d2 < d1 ? 1 : 0);
}

export type MoldStorageStatus = 'action_required' | 'check_recommended' | 'no_issue' | 'not_applicable';
const STATUS_JA: Record<MoldStorageStatus, string> = {
  action_required: '要対応', check_recommended: '確認推奨', no_issue: '対応不要', not_applicable: '対象外',
};
const BASIS = '取適法 第5条第2項第2号 (不当な経済上の利益の提供要請)・公取委 取適法Q&A Q119';

/** 保管の状況を Q119 の4つの事情で判定する */
export function assessMoldStorage(e: MoldLedgerEntry, asOf: Date | string): {
  status: MoldStorageStatus; status_ja: string; factors: string[]; message_ja: string; basis: string;
} {
  const today = toYmd(asOf);
  const out = (status: MoldStorageStatus, factors: string[], message_ja: string) => ({ status, status_ja: STATUS_JA[status], factors, message_ja, basis: BASIS });
  if (e.storedBy !== 'contractor') {
    return out('not_applicable', [], '当社が自社で保管している型のため、取引先に保管させている型の確認の対象外です。');
  }
  if (e.owner === 'contractor') {
    return out('not_applicable', [], '取引先が所有し、当社が管理していない型のため対象外です (廃棄に当社の承認が要るなら所有者を「当社が管理」にしてください)。');
  }
  const factors: string[] = [];
  if (filled(e.lastOrderDate)) {
    const last = toYmd(e.lastOrderDate as string);
    if (today >= addYears(last, 1)) factors.push(`最終発注日 ${last} から1年以上 (${monthsBetween(last, today)}か月) 発注がありません`);
  } else {
    factors.push('最終発注日が記入されていないため、発注のない期間を確かめられません');
  }
  if (e.disposalOrReturnRequested) factors.push(`取引先から廃棄・引取りの希望が伝えられています${e.disposalOrReturnRequestedAt ? ` (${toYmd(e.disposalOrReturnRequestedAt)})` : ''}`);
  if (!filled(e.nextOrderPlan) || toYmd(e.nextOrderPlan as string) > addYears(today, 1)) factors.push('今後1年間の具体的な発注時期を示せていません');
  if (e.reuseExpected === false) factors.push('再使用の予定がありません');

  const unpaid = !(Number(e.storageFeeYenPaid) > 0);
  if (factors.length === 0) {
    return out('no_issue', [], '発注が続いており、Q119 の事情に当たる点は見当たりません。保管の条件は引き続き記録してください。');
  }
  if (unpaid) {
    factors.push('保管費用を支払っていません (無償で保管させています)');
    return out('action_required', factors,
      `取引先に無償で型を保管させており、${BASIS.split('・')[0]} に該当するおそれがあります。` +
      '保管費用は取引先からの請求の有無にかかわらず、保管期間に応じて支払う必要があります (公取委Q&A Q119)。' +
      '取引先と協議のうえ、保管費用の支払、または廃棄・引取り・保管の継続を決めて、この台帳に記録してください。');
  }
  return out('check_recommended', factors,
    '保管費用は支払われていますが、廃棄・回収か保管継続かについても取引先と協議することが求められます (公取委Q&A Q119)。協議の結果を記録してください。');
}
