/**
 * @fileoverview Phase 12 - SRE 日本適応版 DNA
 *
 * Google SRE 本 + 日本企業の運用実態 (営業時間/休業日/情報システム部門特性)
 * を統合した日本仕様の SRE モジュール:
 *   - 営業時間別 SLO (オフィスアワー/夜間/休日)
 *   - エラーバジェット (休業日除外計算)
 *   - 日本祝日カレンダー (内閣府発表ベース)
 *   - 障害対応の TOIL 削減判定
 *   - オンコール体制 (情報システム部の慣習: 平日対応中心 + 夜間SES)
 *   - サポートデスク (お客様窓口) との連動
 *   - リリースカレンダー (年末年始/GW/お盆 凍結期間)
 */

import {
  HolidayRangeError,
  vernalEquinoxDay,
  autumnalEquinoxDay,
  jpHolidaysOfYear,
  getJpHolidayInfo,
  isJpHoliday,
  getJpBusinessDayInfo,
  isJpBusinessDay,
  toJstYmd,
  JP_HOLIDAY_FIRST_YEAR,
  JP_HOLIDAY_PROVISIONAL_MAX_YEAR,
  type JpHolidayKind,
  type JpHolidayCertainty,
  type JpBusinessDayOptions,
  type JpClosedDaySet,
} from './calendar/jp_calendar';

// ============================================================================
// 日本祝日 — 正本 calendar/jp_calendar.ts を読む薄い包み
//   ★2026-09-30 是正 (REQ-JPO-FIX-007): 祝日の判定は正本 1 か所 (内閣府 CSV の写し + 公示前の年の予定値) に寄せた。
//     ここは従来の API (関数名・引数) を保つための包みだけで、祝日の日付も規則も持たない。
//     - 1955〜2027 年は内閣府 CSV の値で答える (確定)。1988 年以前も判定できるようになった。
//     - 2028〜2099 年は法律の規則と近似式による予定値で、provisional=true (未確定) を付けて返す。
//     - 名称は CSV のまま (振替休日・国民の休日は「休日」。どちらかは kind で区別する)。
//     - 日付は日本時間の暦日で決める ('YYYY-MM-DD' はその暦日、時差つきの日時は日本時間に直す)。
// ============================================================================

/** 判定できる最初の年 (内閣府 CSV の最初の年) */
export const JP_HOLIDAY_CALC_MIN_YEAR = JP_HOLIDAY_FIRST_YEAR;
/** 判定できる最後の年 (春分・秋分の近似式による予定値の上限) */
export const JP_HOLIDAY_CALC_MAX_YEAR = JP_HOLIDAY_PROVISIONAL_MAX_YEAR;

export { HolidayRangeError, vernalEquinoxDay, autumnalEquinoxDay };

export type HolidayKind = JpHolidayKind;

export interface JapaneseHoliday {
  date: string;
  name: string;
  kind: HolidayKind;
  /** confirmed=内閣府の公示済み / provisional=公示前の予定 (未確定) */
  certainty: 'confirmed' | 'provisional';
}

export interface HolidayInfo {
  date: string;
  /** 判定できたか */
  supported: boolean;
  /** 祝日か。supported=false のときは null (=判定不能。false=平日 と混同しない) */
  holiday: boolean | null;
  name: string | null;
  kind: HolidayKind | null;
  /** confirmed / provisional (未確定) / unsupported (判定できない) */
  certainty: JpHolidayCertainty;
  confirmed: boolean;
  provisional: boolean;
  /** 判定できない理由・未確定である旨 (日本語) */
  reason?: string;
}

/**
 * 指定年の祝日 (国民の祝日 + 振替休日 + 国民の休日 + 特別の休日)。
 * @throws HolidayRangeError 判定できない年 (1954 年以前・2100 年以降)
 */
export function computeJapaneseHolidays(year: number): JapaneseHoliday[] {
  return jpHolidaysOfYear(year).map((h) => ({ ...h }));
}

/**
 * 祝日判定の詳細 (例外を投げない版)。
 * 判定できない場合は holiday=null / supported=false を返す (=「平日」と答えない)。
 * 公示前の年は provisional=true (未確定) を付けて返す。
 */
export function getHolidayInfo(date: string): HolidayInfo {
  return getJpHolidayInfo(date);
}

/**
 * 祝日判定。
 * @param date 'YYYY-MM-DD'
 * @param holidays 明示的に祝日表を渡した場合はその表で判定する (従来互換)。
 *                 省略時は正本 (内閣府 CSV の写し + 予定値) で判定する。
 * @throws HolidayRangeError 表を渡さず、かつ判定できない年/不正な日付のとき
 */
export function isJapaneseHoliday(date: string, holidays?: { date: string }[]): boolean {
  if (holidays) {
    const key = String(date ?? '').slice(0, 10);
    return holidays.some((h) => h.date === key);
  }
  return isJpHoliday(date);
}

/** 祝日名 (祝日でなければ null)。表を渡さない場合は正本の名称 (CSV のまま) を返す */
export function holidayNameOf(date: string, holidays?: { date: string; name?: string }[]): string | null {
  if (holidays) {
    const key = String(date ?? '').slice(0, 10);
    return holidays.find((h) => h.date === key)?.name ?? null;
  }
  return getJpHolidayInfo(date).name;
}

export type BusinessDayOptions = JpBusinessDayOptions;
export type ClosedDaySet = JpClosedDaySet;

export interface BusinessDayInfo {
  date: string;
  /** unmeasurable = 判定できない年/不正入力・事業者カレンダーに設定の無い年 / year_end = 選んだ休業日の集合の年末年始 / extra_closed = 会社独自の休業日 / company_closed = 事業者・工場のカレンダーの休業日 */
  status: 'business_day' | 'weekend' | 'holiday' | 'year_end' | 'extra_closed' | 'company_closed' | 'unmeasurable';
  /** 日本語の答え (営業日 / 休業日 / 不明) */
  label: '営業日' | '休業日' | '不明';
  certainty: JpHolidayCertainty;
  holidayName?: string;
  reason?: string;
}

/**
 * 営業日判定の詳細 (例外を投げない版)。
 * opts.closedDays の既定は 'holidays_only' (土日と祝日法の休日)。年末年始を含めるかはオーナー判断待ちのため選べる形にとどめる。
 */
export function getBusinessDayInfo(date: string, opts: BusinessDayOptions = {}): BusinessDayInfo {
  return getJpBusinessDayInfo(date, opts);
}

/**
 * 営業日判定 (土日・祝日・振替休日・国民の休日を除く。opts で年末年始・会社独自の休業日を足せる)。
 * @throws HolidayRangeError 判定できない年/不正な日付のとき (判定できないものを営業日と答えない)
 */
export function isBusinessDay(date: string, opts: BusinessDayOptions = {}): boolean {
  return isJpBusinessDay(date, opts);
}

// ============================================================================
// SLO (営業時間別)
// ============================================================================

export type SLOWindow = 'business_hours' | 'after_hours' | 'weekend' | 'holiday' | 'all_24x7';

export interface SLODefinition {
  serviceName: string;
  window: SLOWindow;
  /** 目標可用性 % (例: 99.9) */
  availabilityPct: number;
  /** 目標レイテンシ p99 (ms) */
  latencyP99Ms?: number;
  /** 目標エラー率 % */
  errorRatePct?: number;
}

export const STANDARD_SLOS: SLODefinition[] = [
  { serviceName: '基幹業務系API', window: 'business_hours', availabilityPct: 99.95, latencyP99Ms: 500, errorRatePct: 0.1 },
  { serviceName: '基幹業務系API', window: 'after_hours', availabilityPct: 99.0, latencyP99Ms: 2000, errorRatePct: 1.0 },
  { serviceName: '社内ポータル', window: 'business_hours', availabilityPct: 99.9, latencyP99Ms: 1000 },
  { serviceName: '社外公開API', window: 'all_24x7', availabilityPct: 99.95, latencyP99Ms: 800, errorRatePct: 0.1 },
  { serviceName: '夜間バッチ', window: 'after_hours', availabilityPct: 99.5 },
];

// ============================================================================
// エラーバジェット (営業日のみ計算するモード)
// ============================================================================

export interface ErrorBudgetCalc {
  serviceName: string;
  window: SLOWindow;
  totalMinutes: number;
  allowedDowntimeMinutes: number;
  consumedDowntimeMinutes: number;
  remainingBudgetMinutes: number;
  burnRate: number;
  exhausted: boolean;
}

export function calcErrorBudget(input: {
  slo: SLODefinition;
  /** 期間 (日) */
  periodDays: number;
  /** 期間内の合計ダウンタイム分 */
  consumedDowntimeMinutes: number;
  /** true: 営業日のみカウント / false: 全日 */
  businessDayOnly?: boolean;
}): ErrorBudgetCalc {
  // 1日 = 営業時間 9h or 24h
  const minutesPerDay = input.slo.window === 'business_hours' ? 9 * 60 : 24 * 60;
  let activeDays = input.periodDays;
  if (input.businessDayOnly) {
    // ざっくり 5/7 (週末除外) — 祝日まで厳密にしたい場合は呼び出し側で実日数を渡す
    activeDays = Math.round(input.periodDays * (5 / 7));
  }
  const totalMinutes = activeDays * minutesPerDay;
  const allowedDowntimeMinutes = Math.round(totalMinutes * (1 - input.slo.availabilityPct / 100));
  const remaining = allowedDowntimeMinutes - input.consumedDowntimeMinutes;
  const burnRate = allowedDowntimeMinutes === 0 ? 0 : input.consumedDowntimeMinutes / allowedDowntimeMinutes;
  return {
    serviceName: input.slo.serviceName,
    window: input.slo.window,
    totalMinutes,
    allowedDowntimeMinutes,
    consumedDowntimeMinutes: input.consumedDowntimeMinutes,
    remainingBudgetMinutes: remaining,
    burnRate: Math.round(burnRate * 1000) / 1000,
    exhausted: remaining <= 0,
  };
}

// ============================================================================
// リリース凍結カレンダー (年末年始/GW/お盆)
// ============================================================================

export interface ReleaseFreezeWindow {
  name: string;
  startDate: string;
  endDate: string;
  reason: string;
  allowEmergencyOnly: boolean;
}

/**
 * 【要年次更新】この凍結期間は 2024/2025 の固定値。
 * 凍結期間は法律ではなく各社の運用方針で決まるため自動算出していない。
 * 2026 年以降を判定したい場合は、呼び出し側で当年の期間を渡すこと
 * (渡さないと年末年始/GW/お盆の凍結判定は効かない)。
 * ★2026-09-30: 既定の凍結期間をどうするか (既定を持つか・案件ごとに入力させるか) はオーナー判断待ち。
 *   既定は変えず、月日の型から当年の期間を作る freezeWindowsForYear() を足して選べる形にとどめた。
 */
export const STANDARD_RELEASE_FREEZE_WINDOWS: ReleaseFreezeWindow[] = [
  { name: '年末年始凍結', startDate: '2024-12-28', endDate: '2025-01-05', reason: '保守要員不在 + 取引先休業', allowEmergencyOnly: true },
  { name: 'GW凍結', startDate: '2025-04-29', endDate: '2025-05-06', reason: 'GW10連休対応', allowEmergencyOnly: true },
  { name: 'お盆凍結', startDate: '2025-08-11', endDate: '2025-08-15', reason: 'お盆休業', allowEmergencyOnly: true },
  { name: '月末月初', startDate: '*-*-28', endDate: '*-*-03', reason: '会計/請求処理ピーク', allowEmergencyOnly: false },
];

/** 凍結期間の型 (月日 'MM-DD' の組) から、指定年の凍結期間を作る。to が from より前なら翌年へまたぐ */
export function freezeWindowsForYear(
  year: number,
  spec: ReadonlyArray<{ name: string; from: string; to: string; reason: string; allowEmergencyOnly: boolean }>,
): ReleaseFreezeWindow[] {
  return spec.map((w) => ({
    name: w.name,
    startDate: `${year}-${w.from}`,
    endDate: `${w.to < w.from ? year + 1 : year}-${w.to}`,
    reason: w.reason,
    allowEmergencyOnly: w.allowEmergencyOnly,
  }));
}

export function isWithinFreezeWindow(date: string, freeze: ReleaseFreezeWindow[] = STANDARD_RELEASE_FREEZE_WINDOWS): { frozen: boolean; window?: ReleaseFreezeWindow } {
  // 2026-09-30: 日本時間の暦日で比べる (協定世界時の暦日で読むと日本時間 0〜8 時台が前日扱いになるため)
  const ymd = toJstYmd(date);
  for (const w of freeze) {
    if (w.startDate.includes('*')) continue; // 月末月初パターンは別ロジック
    if (ymd >= w.startDate.slice(0, 10) && ymd <= w.endDate.slice(0, 10)) return { frozen: true, window: w };
  }
  // 月末月初判定
  const dom = Number(ymd.slice(8, 10));
  if (dom >= 28 || dom <= 3) {
    return { frozen: true, window: freeze.find((w) => w.name === '月末月初') };
  }
  return { frozen: false };
}

// ============================================================================
// オンコール体制 (日本仕様)
// ============================================================================

export interface OncallSchedule {
  primary: string;
  secondary?: string;
  manager?: string;
  shift: 'business_hours' | 'after_hours' | 'weekend';
  date: string;
}

export function suggestOncallShift(input: {
  teamSize: number;
  isB2B: boolean;
  serviceType: 'internal' | 'customer_facing';
}): { rotation: 'weekly' | 'daily' | 'no_oncall'; recommendation: string } {
  if (input.teamSize < 3 && !input.isB2B) {
    return { rotation: 'no_oncall', recommendation: '人員不足のため、夜間障害は外部SES (NOC) 委託を推奨' };
  }
  if (input.serviceType === 'internal') {
    return { rotation: 'weekly', recommendation: '社内システムは平日日中対応、夜間障害は翌営業日対応で OK' };
  }
  return { rotation: 'daily', recommendation: '24x7 対応のため、デイリーローテーション推奨。連続出勤は2日まで' };
}

// ============================================================================
// TOIL 削減 (定型運用作業の自動化判定)
// ============================================================================

export interface ToilTask {
  taskName: string;
  /** 月あたり実施回数 */
  monthlyExecutions: number;
  /** 1回あたり所要時間 (分) */
  minutesPerExecution: number;
  /** 自動化難易度 */
  automationDifficulty: 'low' | 'medium' | 'high';
}

export function evaluateToilReduction(tasks: ToilTask[]): { task: ToilTask; monthlyMinutes: number; recommendAutomation: boolean; estimatedRoiMonths: number }[] {
  return tasks.map((t) => {
    const monthlyMinutes = t.monthlyExecutions * t.minutesPerExecution;
    const automationCostMinutes = t.automationDifficulty === 'low' ? 600 : t.automationDifficulty === 'medium' ? 2400 : 9600;
    const recommend = monthlyMinutes >= 60 && (automationCostMinutes / monthlyMinutes) <= 12;
    const roiMonths = monthlyMinutes === 0 ? Infinity : Math.round((automationCostMinutes / monthlyMinutes) * 10) / 10;
    return { task: t, monthlyMinutes, recommendAutomation: recommend, estimatedRoiMonths: roiMonths };
  });
}

export const SRE_JP_REFS = {
  CABINET_HOLIDAYS_CSV: 'https://www8.cao.go.jp/chosei/shukujitsu/syukujitsu.csv',
  GOOGLE_SRE_BOOK: 'https://sre.google/books/',
};
