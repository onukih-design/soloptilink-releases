// @ts-check
/**
 * 物流運輸 DNA (Phase 19)
 *
 * Claude Code がカバーしない日本の物流・運輸業を完全カバー。
 *
 *  - 貨物自動車運送事業法 (一般貨物 / 特定貨物 / 貨物軽自動車)
 *  - 改善基準告示 (R6.4 改正) - 拘束時間 / 休息期間 / 連続運転時間
 *  - 2024年問題 (時間外労働の上限規制 年960時間)
 *  - 標準的な運賃 (国交省告示 R2 / R6改訂)
 *  - 運行管理者 (旅客 / 貨物)
 *  - 点呼 (始業 / 終業 / 中間 IT点呼)
 *  - デジタコ (タコグラフ) - 速度/距離/時間
 *  - 運送状 (国際: B/L 国内: 配達伝票)
 *  - 燃料サーチャージ
 *  - 3PL / 4PL ロジスティクス
 *  - 倉庫業法 (1類 / 2類 / 3類 / 危険品)
 *  - 標準引越運送約款
 *
 * 出典 (一次情報):
 *   - 自動車運転者の労働時間等の改善のための基準 (改善基準告示)
 *     平成元年労働省告示第7号 / 令和4年12月23日厚生労働省告示第367号による改正
 *     令和6年4月1日適用
 *     https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/gyosyu/roudoujouken05/index.html
 *   - 全日本トラック協会/国土交通省「トラック運転者の改善基準告示 ー2024年4月適用ー 解説」
 *     https://wwwtb.mlit.go.jp/kinki/content/000306033.pdf
 *   - 標準的な運賃 (国交省) https://www.mlit.go.jp/jidosha/jidosha_tk1_000094.html
 */

// =============================================================================
// 改善基準告示 (令和6年4月1日適用)
// =============================================================================

/**
 * 改善基準告示 第4条 に定めるトラック運転者の基準値 (一次情報から転記)。
 *
 * 【出典】全日本トラック協会/国土交通省「トラック運転者の改善基準告示 解説」
 *   https://wwwtb.mlit.go.jp/kinki/content/000306033.pdf
 *
 *   第4条第1項第1号 1年の拘束時間   : 3,300時間以内 (労使協定により 3,400時間まで延長可)
 *   第4条第1項第2号 1か月の拘束時間 : 284時間以内 (労使協定により年6か月まで 310時間まで延長可)
 *                                     ただし284時間超が4か月連続することは認められない
 *   第4条第1項第3号/第4号 1日の拘束時間: 原則13時間以内 / 上限15時間
 *                                     (14時間超は1週間で2回以内が目安)
 *                                     宿泊を伴う長距離貨物運送の特例に限り週2回まで16時間
 *   第4条第1項第5号 1日の休息期間   : 継続11時間以上となるよう努めることを基本とし、
 *                                     継続9時間を下回ってはならない
 *                                     長距離特例時は週2回に限り継続8時間以上
 *                                     (その場合は運行終了後に継続12時間以上の休息期間が必要)
 *   第4条第1項第6号 運転時間         : 2日平均1日9時間以内 / 2週平均1週44時間以内
 *   第4条第1項第7号/第8号 連続運転時間: 4時間以内 (やむを得ない場合は4時間30分まで延長可)
 *                                     運転の中断は1回おおむね10分以上で合計30分以上
 *   第4条第4項第1号 分割休息の特例   : 1回3時間以上。2分割で合計10時間以上 /
 *                                     3分割で合計12時間以上。分割休息の日は1か月の2分の1が限度
 */
export const KAIZEN_KIJUN_KOKUJI = {
  /** 1日の拘束時間 原則 (13時間) */
  daily_binding_principle_minutes: 13 * 60,
  /** 1日の拘束時間 上限 (15時間) — 改正前は16時間だった */
  daily_binding_max_minutes: 15 * 60,
  /** 14時間超は1週間で2回以内が目安 */
  daily_binding_weekly_caution_minutes: 14 * 60,
  /** 宿泊を伴う長距離貨物運送の特例における1日の拘束時間の上限 (16時間・週2回まで) */
  daily_binding_long_haul_special_minutes: 16 * 60,
  /** 休息期間の努力義務 (継続11時間以上) */
  rest_effort_min_minutes: 11 * 60,
  /** 休息期間の絶対的下限 (継続9時間) */
  rest_absolute_min_minutes: 9 * 60,
  /** 宿泊を伴う長距離貨物運送の特例における休息期間の下限 (継続8時間・週2回まで) */
  rest_long_haul_special_min_minutes: 8 * 60,
  /** 分割休息: 1回あたりの下限 (3時間) */
  split_rest_each_min_minutes: 3 * 60,
  /** 分割休息: 2分割の合計下限 (10時間) */
  split_rest_total_2_min_minutes: 10 * 60,
  /** 分割休息: 3分割の合計下限 (12時間) */
  split_rest_total_3_min_minutes: 12 * 60,
  /** 連続運転時間の原則 (4時間) */
  continuous_driving_principle_minutes: 4 * 60,
  /** 連続運転時間のやむを得ない場合の上限 (4時間30分) */
  continuous_driving_max_minutes: 4 * 60 + 30,
  /** 連続運転の中断に必要な合計休憩 (30分) */
  driving_break_required_minutes: 30,
  /** 1か月の拘束時間 原則 (284時間) */
  monthly_binding_principle_hours: 284,
  /** 1か月の拘束時間 労使協定時 (310時間・年6か月まで) */
  monthly_binding_agreement_hours: 310,
  /** 1年の拘束時間 原則 (3,300時間) */
  annual_binding_principle_hours: 3300,
  /** 1年の拘束時間 労使協定時 (3,400時間) */
  annual_binding_agreement_hours: 3400,
  /** 労使協定で月284時間を超えられるのは年6か月まで */
  monthly_over_principle_max_months: 6,
  /** 月284時間超が連続してよいのは3か月まで (4か月連続は不可) */
  monthly_over_principle_max_consecutive_months: 3,
  /** 労働基準法上のドライバーの時間外労働の上限 (年960時間) */
  annual_overtime_limit_hours: 960,
} as const;

export interface DriverWorkRecord {
  driver_id: string;
  date: string; // YYYY-MM-DD
  /** 拘束時間 (始業から終業まで) - 分 */
  binding_minutes: number;
  /** 運転時間 - 分 */
  driving_minutes: number;
  /** 休息期間 (前日終業〜当日始業) - 分 */
  rest_minutes: number;
  /** 連続運転時間 (4 時間連続超で休憩必要) - 分 */
  max_continuous_driving_minutes: number;
  /** 休憩時間 (4時間運転で30分以上 等) - 分 */
  break_minutes: number;
  /** 分割休息の特例を適用しているか (第4条第4項第1号) */
  uses_split_rest: boolean;
  /** 分割休息の分割数 (2 または 3。省略時は 2 とみなす) */
  rest_split_count?: number;
  /** 分割休息の各回の長さ - 分 (与えられた場合は1回3時間以上を検査する) */
  rest_split_minutes?: number[];
  /**
   * 宿泊を伴う長距離貨物運送の特例を適用しているか (第4条第1項第4号)。
   *
   * ★適用要件: 1週間における運行が全て一の運行 450km 以上の長距離輸送であり、
   *   かつその間の休息期間が運転者の住所地以外の場所となること。1週間に2回まで。
   *   16時間まで延長した場合は、一の運行終了後に継続12時間以上の休息期間が必要。
   *   要件充足の確認は運行計画側の責務であり、本関数は上限値のみを切り替える。
   */
  long_haul_lodging_special?: boolean;
  /**
   * 連続運転時間を4時間30分まで延長できる「やむを得ない場合」の記録があるか (第4条第1項第7号ただし書)。
   * 高速道路等のSA・PA等に駐車又は停車できないため、やむを得ず4時間を超えた場合に限る。
   * ★既定は false。記録が無いのに4時間超を警告だけで通すと、告示違反を見逃す (2026-10-04 是正)。
   */
  unavoidable_sapa_extension?: boolean;
}

/** 分の値として使える数か (有限で0以上)。NaN・負・未入力・文字列は使えない。 */
function isValidMinutes(v: unknown): v is number {
  return typeof v === 'number' && Number.isFinite(v) && v >= 0;
}

/**
 * 改善基準告示 (令和6年4月1日適用) の1日単位の違反チェック (貨物自動車運送業)
 *
 *  - 拘束時間 : 原則13時間以内 / 上限15時間 (長距離特例時のみ16時間)
 *  - 休息期間 : 継続11時間以上に努める (努力義務) / 継続9時間が絶対的下限
 *  - 連続運転 : 4時間以内 (やむを得ない場合4時間30分まで)、中断は合計30分以上
 *  - 月次・年次の拘束時間は checkMonthlyAggregation / checkAnnualAggregation を使う
 */
export interface DriverComplianceResult {
  date: string;
  driver_id: string;
  violations: string[];
  warnings: string[];
  ok: boolean;
}

export function checkDriverCompliance(rec: DriverWorkRecord): DriverComplianceResult {
  const K = KAIZEN_KIJUN_KOKUJI;
  const violations: string[] = [];
  const warnings: string[] = [];
  const h = (min: number) => (min / 60).toFixed(1);
  const longHaul = rec.long_haul_lodging_special === true;

  // --- 入力値の検査 (2026-10-04 是正) ---
  // NaN・未入力の値は比較がすべて false になり、違反0件＝適法に見えてしまう。判定できない入力は合格にしない。
  const badFields = (['binding_minutes', 'rest_minutes', 'max_continuous_driving_minutes'] as const)
    .filter((k) => !isValidMinutes(rec[k]));
  if (badFields.length > 0) {
    return {
      date: rec.date,
      driver_id: rec.driver_id,
      violations: [`入力値が読めないため判定できません (${badFields.join(', ')})。勤務記録を確認してください。`],
      warnings,
      ok: false,
    };
  }

  // --- 1日の拘束時間 (第4条第1項第3号・第4号) ---
  // ★改正後の上限は15時間。16時間は「宿泊を伴う長距離貨物運送の特例」を
  //   適用する場合に限り、1週間に2回まで認められる値であり、既定の上限ではない。
  const bindingMax = longHaul ? K.daily_binding_long_haul_special_minutes : K.daily_binding_max_minutes;
  if (rec.binding_minutes > bindingMax) {
    violations.push(
      `1日拘束時間が上限${bindingMax / 60}時間を超過: ${h(rec.binding_minutes)}時間` +
      (longHaul ? ' (宿泊を伴う長距離貨物運送の特例適用中)' : ''),
    );
  } else if (longHaul && rec.binding_minutes > K.daily_binding_max_minutes) {
    warnings.push(
      `1日拘束時間が15時間超: ${h(rec.binding_minutes)}時間。` +
      '宿泊を伴う長距離貨物運送の特例 (1週間に2回まで/一の運行450km以上/住所地以外での休息) の' +
      '要件充足と、運行終了後の継続12時間以上の休息期間を確認してください。',
    );
  } else if (rec.binding_minutes > K.daily_binding_weekly_caution_minutes) {
    warnings.push(
      `1日拘束時間が原則13時間超: ${h(rec.binding_minutes)}時間。` +
      '14時間超は1週間で2回以内が目安とされています。',
    );
  } else if (rec.binding_minutes > K.daily_binding_principle_minutes) {
    warnings.push(`1日拘束時間が原則13時間超: ${h(rec.binding_minutes)}時間 (上限15時間)`);
  }

  // --- 1日の休息期間 (第4条第1項第5号 / 第4項第1号) ---
  if (rec.uses_split_rest) {
    // 分割休息の特例: 1回3時間以上、2分割で合計10時間以上 / 3分割で合計12時間以上
    const splitCount = rec.rest_split_count ?? 2;
    const requiredTotal =
      splitCount >= 3 ? K.split_rest_total_3_min_minutes : K.split_rest_total_2_min_minutes;
    if (rec.rest_minutes < requiredTotal) {
      violations.push(
        `分割休息の合計が不足: ${h(rec.rest_minutes)}時間 ` +
        `(${splitCount}分割は合計${requiredTotal / 60}時間以上が必要)`,
      );
    }
    if (splitCount > 3) {
      violations.push(`休息期間の分割は3分割までです (${splitCount}分割)`);
    }
    for (const piece of rec.rest_split_minutes ?? []) {
      if (piece < K.split_rest_each_min_minutes) {
        violations.push(`分割休息の1回が3時間未満: ${h(piece)}時間`);
        break;
      }
    }
    if (splitCount >= 3) {
      warnings.push('3分割となる日が連続しないよう努める必要があります。分割休息の日は1か月の勤務回数の2分の1が限度です。');
    }
  } else {
    const restMin = longHaul ? K.rest_long_haul_special_min_minutes : K.rest_absolute_min_minutes;
    if (rec.rest_minutes < restMin) {
      violations.push(
        `休息期間が継続${restMin / 60}時間を下回る: ${h(rec.rest_minutes)}時間` +
        (longHaul ? ' (宿泊を伴う長距離貨物運送の特例適用中)' : ''),
      );
    } else if (longHaul && rec.rest_minutes < K.rest_absolute_min_minutes) {
      warnings.push(
        `休息期間が継続9時間未満: ${h(rec.rest_minutes)}時間。` +
        '長距離特例 (1週間に2回まで) の要件と、運行終了後の継続12時間以上の休息期間を確認してください。',
      );
    } else if (rec.rest_minutes < K.rest_effort_min_minutes) {
      // 継続11時間は努力義務。9時間以上あれば告示違反ではないため警告に留める。
      warnings.push(
        `休息期間が継続11時間未満: ${h(rec.rest_minutes)}時間。` +
        '告示は継続11時間以上を与えるよう努めることを基本としています (絶対的下限は継続9時間)。',
      );
    }
  }

  // --- 連続運転時間 (第4条第1項第7号・第8号) ---
  if (rec.max_continuous_driving_minutes > K.continuous_driving_max_minutes) {
    violations.push(
      `連続運転時間が4時間30分超: ${h(rec.max_continuous_driving_minutes)}時間`,
    );
  } else if (rec.max_continuous_driving_minutes > K.continuous_driving_principle_minutes) {
    if (rec.unavoidable_sapa_extension !== true) {
      // 4時間30分までの延長は、SA・PA等に駐停車できずやむを得ない場合に限られる (第4条第1項第7号ただし書)。
      violations.push(
        `連続運転時間が4時間を超えています: ${h(rec.max_continuous_driving_minutes)}時間。` +
        '4時間30分までの延長は、高速道路等のSA・PA等に駐停車できないためやむを得ない場合に限られます (その記録がありません)。',
      );
    } else if (!(rec.break_minutes >= K.driving_break_required_minutes)) {
      violations.push('連続運転の中断 (合計30分以上の休憩) が不足しています');
    } else {
      warnings.push(
        `連続運転時間が原則4時間超: ${h(rec.max_continuous_driving_minutes)}時間。` +
        '4時間30分までの延長はSA・PA等に駐停車できない等やむを得ない場合に限られます。',
      );
    }
  }

  return {
    date: rec.date,
    driver_id: rec.driver_id,
    violations,
    warnings,
    ok: violations.length === 0,
  };
}

export interface BindingAggregationOptions {
  /**
   * 労使協定 (改善基準告示第4条第1項第1号ただし書・第2号ただし書) を締結しているか。
   * 締結時のみ 1か月310時間 / 1年3,400時間まで延長できる。
   * ★既定は false。協定がないのに例外値で判定すると、原則超過の違反を見逃す。
   */
  has_labor_agreement?: boolean;
}

export interface MonthlyBindingResult {
  total_binding_hours: number;
  total_driving_hours: number;
  /** 適用した1か月の拘束時間の上限 (284 または 310) */
  limit_hours: number;
  /** 原則284時間を超えているか (労使協定の有無に関わらず) */
  exceeds_principle: boolean;
  /** 適用上限を超えているか = 告示違反 */
  monthly_binding_violation: boolean;
  warnings: string[];
}

/**
 * 1か月の拘束時間の集計と判定 (改善基準告示 第4条第1項第2号)
 *
 *  - 原則 284時間以内
 *  - 労使協定を締結した場合に限り、年6か月までは 310時間まで延長可
 *    (ただし284時間を超える月が4か月連続することは認められない)
 *
 * ★旧実装は労使協定の有無を問わず 310時間のみで判定していたため、
 *   協定がない事業者の 300時間 (原則284時間超) を違反として検出できなかった。
 */
export function checkMonthlyAggregation(
  records: DriverWorkRecord[],
  opts: BindingAggregationOptions = {},
): MonthlyBindingResult {
  const K = KAIZEN_KIJUN_KOKUJI;
  const hasAgreement = opts.has_labor_agreement === true;
  const total_binding_minutes = records.reduce((s, r) => s + r.binding_minutes, 0);
  const total_driving_minutes = records.reduce((s, r) => s + r.driving_minutes, 0);
  const total_binding_hours = Math.round((total_binding_minutes / 60) * 10) / 10;
  const total_driving_hours = Math.round((total_driving_minutes / 60) * 10) / 10;

  const limit_hours = hasAgreement
    ? K.monthly_binding_agreement_hours
    : K.monthly_binding_principle_hours;
  // ★比較は分で行う (2026-10-04 是正)。0.1時間に丸めた値で比べると 284時間2分 (17,042分) が 284.0時間に見えて素通りする。
  const exceeds_principle = total_binding_minutes > K.monthly_binding_principle_hours * 60;
  const warnings: string[] = [];
  if (exceeds_principle && hasAgreement && total_binding_hours <= limit_hours) {
    warnings.push(
      `1か月の拘束時間が原則284時間を超えています (${total_binding_hours}時間)。` +
      '労使協定により310時間まで延長できるのは年6か月までです。' +
      'また284時間を超える月が4か月連続することは認められません。' +
      '1か月の時間外・休日労働時間数が100時間未満となるよう努めてください。',
    );
  }
  if (exceeds_principle && !hasAgreement) {
    warnings.push(
      '労使協定の締結が確認できないため原則284時間で判定しました。' +
      '協定を締結している場合は has_labor_agreement を指定してください。',
    );
  }

  return {
    total_binding_hours,
    total_driving_hours,
    limit_hours,
    exceeds_principle,
    monthly_binding_violation: !Number.isFinite(total_binding_minutes) || total_binding_minutes > limit_hours * 60,
    warnings,
  };
}

export interface AnnualBindingResult {
  total_binding_hours: number;
  total_driving_hours: number;
  /** 適用した1年の拘束時間の上限 (3,300 または 3,400) */
  limit_hours: number;
  /** 原則3,300時間を超えているか */
  exceeds_principle: boolean;
  /** 適用上限を超えているか = 告示違反 */
  annual_binding_violation: boolean;
  warnings: string[];
}

/**
 * 1年の拘束時間の集計と判定 (改善基準告示 第4条第1項第1号)
 *
 *  - 原則 3,300時間以内
 *  - 労使協定を締結した場合に限り 3,400時間まで延長可
 *
 * ★旧実装では年間の上限判定が存在せず、月次関数の説明文に「年960時間」と
 *   書かれているだけで実装されていなかった (関数名だけの死配線)。
 *   なお年960時間は労働基準法上の「時間外労働」の上限であり、
 *   ここで扱う「拘束時間」とは別物なので混同しないこと。
 */
export function checkAnnualAggregation(
  records: DriverWorkRecord[],
  opts: BindingAggregationOptions = {},
): AnnualBindingResult {
  const K = KAIZEN_KIJUN_KOKUJI;
  const hasAgreement = opts.has_labor_agreement === true;
  const total_binding_minutes = records.reduce((s, r) => s + r.binding_minutes, 0);
  const total_driving_minutes = records.reduce((s, r) => s + r.driving_minutes, 0);
  const total_binding_hours = Math.round((total_binding_minutes / 60) * 10) / 10;
  const total_driving_hours = Math.round((total_driving_minutes / 60) * 10) / 10;

  const limit_hours = hasAgreement
    ? K.annual_binding_agreement_hours
    : K.annual_binding_principle_hours;
  const exceeds_principle = total_binding_minutes > K.annual_binding_principle_hours * 60;
  const warnings: string[] = [];
  if (exceeds_principle && hasAgreement && total_binding_hours <= limit_hours) {
    warnings.push(
      `1年の拘束時間が原則3,300時間を超えています (${total_binding_hours}時間)。` +
      '労使協定により3,400時間まで延長できますが、月284時間超は年6か月までである点も併せて確認してください。',
    );
  }
  if (exceeds_principle && !hasAgreement) {
    warnings.push(
      '労使協定の締結が確認できないため原則3,300時間で判定しました。' +
      '協定を締結している場合は has_labor_agreement を指定してください。',
    );
  }

  return {
    total_binding_hours,
    total_driving_hours,
    limit_hours,
    exceeds_principle,
    annual_binding_violation: !Number.isFinite(total_binding_minutes) || total_binding_minutes > limit_hours * 60,
    warnings,
  };
}

// =============================================================================
// 改善基準告示の業態別判定 (トラックの月・年 / バス / タクシー日勤・隔勤) — 2026-10-04 追加
// =============================================================================
//
// 【出典 — 一次情報】自動車運転者の労働時間等の改善のための基準 改正後全文
//   (平成元年労働省告示第7号・最終改正 令和4年12月23日厚生労働省告示第367号・令和6年4月1日適用)
//   https://www.mhlw.go.jp/content/001035032.pdf
//   第2条 (一般乗用旅客自動車運送事業 = タクシー) / 第4条 (貨物) / 第5条 (バス運転者等)
//
// ★値は下の値表 (KAIZEN_KIJUN_KOKUJI / KAIZEN_KIJUN_BUS / KAIZEN_KIJUN_TAXI) だけに置く。判定関数は値表を読む。
//   判定関数の区画 (<kaizen-bus-taxi-judge>) には数値を直書きしない (検体 jpo-T27-kaizen-kijun の静的検査が見る)。
// ★比較はすべて分で行う。「超えない」は ちょうど が適法、「下回らない」は ちょうど が適法。
// ★判定できない入力 (NaN・未入力・回数の未入力で延長の可否を確かめられない) は ok=false にする (危険側に倒さない)。

/** 判定の結果 (業態共通)。ok=false は「違反」か「入力が足りず確かめられない」のどちらか。 */
export interface KaizenJudgement {
  ok: boolean;
  status: 'ok' | 'violation' | 'invalid_input';
  violations: string[];
  warnings: string[];
  /** 適用した上限 (分)。月・年などの集計の判定で返す */
  limit_minutes?: number;
}

/** 時間 → 分 */
const hm = (hours: number): number => hours * 60;
/** 回数として使える数か (0以上の整数) */
function isCount(v: unknown): v is number {
  return typeof v === 'number' && Number.isInteger(v) && v >= 0;
}
function judged(violations: string[], warnings: string[], limit_minutes?: number): KaizenJudgement {
  return {
    ok: violations.length === 0,
    status: violations.length === 0 ? 'ok' : 'violation',
    violations,
    warnings,
    ...(limit_minutes === undefined ? {} : { limit_minutes }),
  };
}
function invalidInput(fields: string[]): KaizenJudgement {
  return {
    ok: false,
    status: 'invalid_input',
    violations: [`入力値が読めないため判定できません (${fields.join(', ')})。記録を確認してください。`],
    warnings: [],
  };
}
function badMinutes(obj: Record<string, unknown>, keys: string[]): string[] {
  return keys.filter((k) => !isValidMinutes(obj[k]));
}

// ---- トラック (第4条第1項第1号・第2号) の月・年の判定 (分で比較) ----

export interface TruckMonthlyInput {
  /** その月の拘束時間の合計 (分) */
  total_binding_minutes: number;
  /** 労使協定 (第4条第1項第1号ただし書) を締結しているか。既定 false */
  has_labor_agreement?: boolean;
  /** その年に284時間を超えた月の数 (この月を含む) */
  months_over_principle_in_year?: number;
  /** 284時間を超えた月の連続数 (この月を含む) */
  consecutive_months_over_principle?: number;
}

/**
 * トラックの1箇月の拘束時間。原則284時間、労使協定で年6箇月まで310時間、284時間超は3箇月を超えて連続しない。
 * 協定ありで284時間を超える月に、年の回数・連続数が未入力なら確かめられないので ok=false。
 */
export function checkTruckMonthlyBinding(i: TruckMonthlyInput): KaizenJudgement {
  const K = KAIZEN_KIJUN_KOKUJI;
  const bad = badMinutes(i as unknown as Record<string, unknown>, ['total_binding_minutes']);
  if (bad.length) return invalidInput(bad);
  const principle = hm(K.monthly_binding_principle_hours);
  const agreement = i.has_labor_agreement === true;
  const limit = agreement ? hm(K.monthly_binding_agreement_hours) : principle;
  const v: string[] = [];
  const w: string[] = [];
  if (i.total_binding_minutes > limit) {
    v.push(`1箇月の拘束時間が上限${limit / 60}時間を超えています (${(i.total_binding_minutes / 60).toFixed(2)}時間)。`);
  }
  if (agreement && i.total_binding_minutes > principle) {
    if (!isCount(i.months_over_principle_in_year) || !isCount(i.consecutive_months_over_principle)) {
      v.push('284時間を超える月の年の回数・連続数が入力されていないため、延長できる月か確かめられません。');
    } else {
      if (i.months_over_principle_in_year > K.monthly_over_principle_max_months) {
        v.push(`284時間を超えられるのは1年に${K.monthly_over_principle_max_months}箇月までです (${i.months_over_principle_in_year}箇月目)。`);
      }
      if (i.consecutive_months_over_principle > K.monthly_over_principle_max_consecutive_months) {
        v.push(`284時間を超える月は${K.monthly_over_principle_max_consecutive_months}箇月を超えて連続できません (${i.consecutive_months_over_principle}箇月連続)。`);
      }
    }
    w.push('1箇月の時間外労働及び休日労働の合計が100時間未満となるよう努めてください。');
  }
  return judged(v, w, limit);
}

/** トラックの1年の拘束時間。原則3,300時間、労使協定で3,400時間。 */
export function checkTruckAnnualBinding(i: { total_binding_minutes: number; has_labor_agreement?: boolean }): KaizenJudgement {
  const K = KAIZEN_KIJUN_KOKUJI;
  const bad = badMinutes(i as unknown as Record<string, unknown>, ['total_binding_minutes']);
  if (bad.length) return invalidInput(bad);
  const limit = hm(i.has_labor_agreement === true ? K.annual_binding_agreement_hours : K.annual_binding_principle_hours);
  const v: string[] = [];
  if (i.total_binding_minutes > limit) v.push(`1年の拘束時間が上限${limit / 60}時間を超えています。`);
  return judged(v, [], limit);
}

/**
 * バス運転者等の基準値 (改善基準告示 第5条)。単位は名前のとおり (hours / minutes / 回 / 週)。
 *   一イ 1箇月281時間・1年3,300時間 (貸切バス等乗務者は労使協定で年6箇月まで294時間・3,400時間)
 *   一ロ 4週平均1週65時間・52週3,300時間 (貸切バス等乗務者は協定で52週のうち24週まで68時間・3,400時間)
 *   二 281時間超は4箇月を超えて連続しない / 65時間超は16週を超えて連続しない
 *   三 1日13時間・最大15時間 (14時間超はできるだけ少なく) / 四 休息は継続11時間を基本・9時間を下回らない
 *   五 運転 2日平均9時間・4週平均1週40時間 (貸切バス等乗務者は協定で52週2,080時間以内・16週まで44時間)
 *   六 連続運転4時間 / 七 駐停車した自動車の移動のための運転は記録があれば30分を上限に連続運転から除く
 *   4項一 分割休息は2回・1回継続4時間以上・合計11時間以上 / 4項二 2人乗務 イ専用座席19時間・休息5時間 ロベッド20時間・休息4時間
 *   4項三 隔日勤務 2暦日21時間・休息20時間。仮眠施設で夜間4時間以上の仮眠なら2週126時間以内で2週3回まで24時間
 */
export const KAIZEN_KIJUN_BUS = {
  daily_binding_principle_hours: 13,
  daily_binding_max_hours: 15,
  daily_binding_caution_hours: 14,
  rest_effort_min_hours: 11,
  rest_absolute_min_hours: 9,
  split_rest_max_pieces: 2,
  split_rest_each_min_hours: 4,
  split_rest_total_min_hours: 11,
  two_crew_seat_max_binding_hours: 19,
  two_crew_seat_min_rest_hours: 5,
  two_crew_bed_max_binding_hours: 20,
  two_crew_bed_min_rest_hours: 4,
  continuous_driving_max_hours: 4,
  traffic_move_deduction_max_minutes: 30,
  monthly_binding_hours: 281,
  monthly_binding_agreement_hours: 294,
  annual_binding_hours: 3300,
  annual_binding_agreement_hours: 3400,
  monthly_over_max_months_per_year: 6,
  monthly_over_max_consecutive_months: 4,
  averaging_weeks: 4,
  weekly_avg_binding_hours: 65,
  weekly_avg_binding_agreement_hours: 68,
  weekly_over_max_weeks_in_52: 24,
  weekly_over_max_consecutive_weeks: 16,
  fifty_two_week_binding_hours: 3300,
  fifty_two_week_binding_agreement_hours: 3400,
  two_day_days: 2,
  two_day_avg_driving_hours: 9,
  weekly_avg_driving_hours: 40,
  weekly_avg_driving_agreement_hours: 44,
  weekly_driving_over_max_weeks_in_52: 16,
  fifty_two_week_driving_agreement_hours: 2080,
  alternate_two_day_binding_hours: 21,
  alternate_rest_min_hours: 20,
  alternate_nap_extended_two_day_binding_hours: 24,
  alternate_nap_min_hours: 4,
  alternate_nap_extended_max_count_in_two_weeks: 3,
  alternate_nap_two_week_binding_max_hours: 126,
} as const;

/**
 * タクシー (一般乗用旅客自動車運送事業) 運転者の基準値 (改善基準告示 第2条)。
 *   第1項 (日勤) 一 1箇月288時間・車庫待ち等は労使協定で300時間 二 1日13時間・最大15時間。車庫待ち等は
 *     イ勤務終了後継続20時間以上の休息 ロ16時間超は1箇月7回以内 ハ18時間超は夜間4時間以上の仮眠 ニ1回の勤務24時間以内 なら15時間を超えられる
 *     四 休息は継続11時間を基本・9時間を下回らない
 *   第2項 (隔勤) 一 1箇月262時間・地域的事情その他特別の事情があれば労使協定で1年6箇月まで270時間
 *     二 2暦日22時間以内・2回の隔日勤務の平均で1回21時間以内
 *     三 車庫待ち等は262時間 (協定で270時間)。夜間4時間以上の仮眠を与え、22時間を超える回数を協定で1箇月7回以内に
 *        定めた場合に限り、2暦日24時間・1箇月は本文の時間に10時間を加えた時間まで
 *     四 休息は継続24時間を基本・22時間を下回らない
 */
export const KAIZEN_KIJUN_TAXI = {
  day_monthly_binding_hours: 288,
  day_garage_monthly_binding_hours: 300,
  day_daily_binding_principle_hours: 13,
  day_daily_binding_max_hours: 15,
  day_daily_binding_caution_hours: 14,
  day_garage_rest_after_min_hours: 20,
  day_garage_over_hours: 16,
  day_garage_over_max_count_per_month: 7,
  day_garage_nap_required_over_hours: 18,
  day_garage_nap_min_hours: 4,
  day_garage_max_binding_hours: 24,
  day_rest_effort_min_hours: 11,
  day_rest_min_hours: 9,
  alternate_monthly_binding_hours: 262,
  alternate_monthly_binding_agreement_hours: 270,
  alternate_over_max_months_per_year: 6,
  alternate_two_day_binding_hours: 22,
  alternate_two_shift_avg_hours: 21,
  alternate_two_shift_count: 2,
  alternate_garage_two_day_binding_hours: 24,
  alternate_garage_nap_min_hours: 4,
  alternate_garage_over_max_count_per_month: 7,
  alternate_garage_monthly_addition_hours: 10,
  alternate_rest_effort_min_hours: 24,
  alternate_rest_min_hours: 22,
} as const;

export interface BusDailyInput {
  binding_minutes: number;
  rest_minutes: number;
  max_continuous_driving_minutes: number;
  /** 分割休息の特例 (第5条第4項第1号) を使うか */
  uses_split_rest?: boolean;
  /** 分割休息の各回 (分) */
  rest_split_minutes?: number[];
  /** 2人乗務 (第5条第4項第2号)。'seat' = 専用の座席 (局長の定める要件を満たす) / 'bed' = ベッド等 */
  two_crew?: 'seat' | 'bed';
  /** 駐停車した自動車を予定の場所から移動させるために運転した時間 (分・第5条第1項第7号) */
  moved_for_traffic_minutes?: number;
  /** その必要が生じたことの記録があるか */
  moved_for_traffic_recorded?: boolean;
}

export interface BusAlternateShiftInput {
  two_day_binding_minutes: number;
  rest_minutes: number;
  /** 局長の定める施設での夜間の仮眠 (分) */
  nap_facility_night_nap_minutes?: number;
  /** その2週間で2暦日21時間を超えて延長した回数 (この勤務を含む) */
  extended_count_in_two_weeks?: number;
  /** その2週間の拘束時間の合計 (分) */
  two_week_binding_minutes?: number;
}

export interface BusMonthlyInput {
  total_binding_minutes: number;
  has_labor_agreement?: boolean;
  /** 貸切バス等乗務者 (第5条第1項第1号イ) か */
  chartered_bus_driver?: boolean;
  months_over_principle_in_year?: number;
  consecutive_months_over_principle?: number;
  /** 1年の拘束時間の合計 (分・与えられたときだけ判定する) */
  annual_binding_minutes?: number;
}

export interface BusFourWeekInput {
  four_week_binding_minutes: number;
  has_labor_agreement?: boolean;
  chartered_bus_driver?: boolean;
  weeks_over_principle_in_52?: number;
  consecutive_weeks_over_principle?: number;
  fifty_two_week_binding_minutes?: number;
}

export interface BusDrivingInput {
  /** 連続する2日 (始業時刻から48時間) の運転時間 (分) */
  two_day_driving_minutes?: number[];
  four_week_driving_minutes?: number;
  has_labor_agreement?: boolean;
  chartered_bus_driver?: boolean;
  /** 52週のうち4週平均1週40時間を超えた週の数 (この週を含む) */
  weeks_over_40_in_52?: number;
  fifty_two_week_driving_minutes?: number;
}

export interface TaxiDayShiftInput {
  binding_minutes: number;
  rest_minutes: number;
  /** 車庫待ち等 (顧客の需要に応ずるため常態として車庫等で待機する就労形態) か */
  garage_waiting?: boolean;
  /** 勤務終了後の休息期間 (分) */
  rest_after_minutes?: number;
  /** その月に1日の拘束が16時間を超えた回数 (この日を含む) */
  count_over_16h_in_month?: number;
  /** 夜間の仮眠 (分) */
  night_nap_minutes?: number;
}

export interface TaxiAlternateShiftInput {
  two_day_binding_minutes: number;
  rest_minutes: number;
  /** 直前の隔日勤務の拘束時間 (分・与えられたときは2回平均21時間を判定する) */
  previous_shift_binding_minutes?: number;
  garage_waiting?: boolean;
  night_nap_minutes?: number;
  /** 労使協定で定めた「22時間を超える回数」(1箇月) */
  agreed_over_22h_count?: number;
  /** その月に22時間を超えた回数 (この勤務を含む) */
  count_over_22h_in_month?: number;
}

export interface TaxiMonthlyInput {
  shift: 'day' | 'alternate';
  total_binding_minutes: number;
  garage_waiting?: boolean;
  has_labor_agreement?: boolean;
  /** 隔勤で「地域的事情その他の特別の事情」があるか */
  special_circumstances?: boolean;
  /** 隔勤で262時間を超えた月の年の数 (この月を含む) */
  months_over_principle_in_year?: number;
  /** 隔勤・車庫待ち等で、夜間4時間以上の仮眠と22時間超の回数の協定 (1箇月7回以内) の要件を満たしているか */
  garage_extension_conditions_met?: boolean;
}

// <kaizen-bus-taxi-judge>
/** バス運転者等の1日の判定 (第5条第1項第3号・第4号・第6号・第7号、第4項第1号・第2号) */
export function checkBusDaily(i: BusDailyInput): KaizenJudgement {
  const B = KAIZEN_KIJUN_BUS;
  const bad = badMinutes(i as unknown as Record<string, unknown>, ['binding_minutes', 'rest_minutes', 'max_continuous_driving_minutes']);
  if (bad.length) return invalidInput(bad);
  const v: string[] = [];
  const w: string[] = [];
  const seat = i.two_crew === 'seat';
  const bed = i.two_crew === 'bed';
  const maxBinding = hm(seat ? B.two_crew_seat_max_binding_hours : bed ? B.two_crew_bed_max_binding_hours : B.daily_binding_max_hours);
  if (i.binding_minutes > maxBinding) {
    v.push(`1日の拘束時間が最大${maxBinding / hm(1)}時間を超えています。`);
  } else if (!seat && !bed && i.binding_minutes > hm(B.daily_binding_caution_hours)) {
    w.push('1日の拘束時間が14時間を超えています。14時間を超える回数をできるだけ少なくしてください。');
  } else if (!seat && !bed && i.binding_minutes > hm(B.daily_binding_principle_hours)) {
    w.push('1日の拘束時間が原則13時間を超えています。');
  }
  if (seat || bed) {
    const minRest = hm(seat ? B.two_crew_seat_min_rest_hours : B.two_crew_bed_min_rest_hours);
    if (i.rest_minutes < minRest) v.push(`2人乗務の休息期間が${minRest / hm(1)}時間を下回っています。`);
  } else if (i.uses_split_rest === true) {
    const pieces = Array.isArray(i.rest_split_minutes) ? i.rest_split_minutes : [];
    if (pieces.length > B.split_rest_max_pieces) v.push(`バス運転者等の分割休息は${B.split_rest_max_pieces}回までです (${pieces.length}回)。`);
    if (pieces.some((p) => !isValidMinutes(p) || p < hm(B.split_rest_each_min_hours))) {
      v.push(`分割休息の1回が継続${B.split_rest_each_min_hours}時間を下回っています。`);
    }
    const total = pieces.length ? pieces.reduce((s, p) => s + (isValidMinutes(p) ? p : 0), 0) : i.rest_minutes;
    if (total < hm(B.split_rest_total_min_hours)) v.push(`分割休息の合計が${B.split_rest_total_min_hours}時間を下回っています。`);
  } else if (i.rest_minutes < hm(B.rest_absolute_min_hours)) {
    v.push(`休息期間が継続${B.rest_absolute_min_hours}時間を下回っています。`);
  } else if (i.rest_minutes < hm(B.rest_effort_min_hours)) {
    w.push(`休息期間が継続${B.rest_effort_min_hours}時間を下回っています (基本は${B.rest_effort_min_hours}時間以上)。`);
  }
  const deduct = i.moved_for_traffic_recorded === true && isValidMinutes(i.moved_for_traffic_minutes)
    ? Math.min(i.moved_for_traffic_minutes, B.traffic_move_deduction_max_minutes)
    : 0;
  if (i.max_continuous_driving_minutes - deduct > hm(B.continuous_driving_max_hours)) {
    v.push(`連続運転時間が${B.continuous_driving_max_hours}時間を超えています (バス運転者等に延長の定めはありません)。`);
  }
  return judged(v, w);
}

/** バス運転者等の隔日勤務 (第5条第4項第3号) */
export function checkBusAlternateShift(i: BusAlternateShiftInput): KaizenJudgement {
  const B = KAIZEN_KIJUN_BUS;
  const bad = badMinutes(i as unknown as Record<string, unknown>, ['two_day_binding_minutes', 'rest_minutes']);
  if (bad.length) return invalidInput(bad);
  const v: string[] = [];
  if (i.two_day_binding_minutes > hm(B.alternate_two_day_binding_hours)) {
    const napOk = isValidMinutes(i.nap_facility_night_nap_minutes) && i.nap_facility_night_nap_minutes >= hm(B.alternate_nap_min_hours);
    const countOk = isCount(i.extended_count_in_two_weeks) && i.extended_count_in_two_weeks <= B.alternate_nap_extended_max_count_in_two_weeks;
    const weekOk = isValidMinutes(i.two_week_binding_minutes) && i.two_week_binding_minutes <= hm(B.alternate_nap_two_week_binding_max_hours);
    const capOk = i.two_day_binding_minutes <= hm(B.alternate_nap_extended_two_day_binding_hours);
    if (!(napOk && countOk && weekOk && capOk)) {
      v.push(`隔日勤務の2暦日の拘束時間が${B.alternate_two_day_binding_hours}時間を超えています` +
        '（仮眠施設での夜間4時間以上の仮眠・2週3回まで・2週126時間以内・24時間以内の要件を満たしていません）。');
    }
  }
  if (i.rest_minutes < hm(B.alternate_rest_min_hours)) v.push(`隔日勤務の勤務終了後の休息期間が継続${B.alternate_rest_min_hours}時間を下回っています。`);
  return judged(v, []);
}

/** バス運転者等の1箇月・1年の拘束時間 (第5条第1項第1号イ・第2号) */
export function checkBusMonthlyBinding(i: BusMonthlyInput): KaizenJudgement {
  const B = KAIZEN_KIJUN_BUS;
  const bad = badMinutes(i as unknown as Record<string, unknown>, ['total_binding_minutes']);
  if (i.annual_binding_minutes !== undefined && !isValidMinutes(i.annual_binding_minutes)) bad.push('annual_binding_minutes');
  if (bad.length) return invalidInput(bad);
  const ext = i.has_labor_agreement === true && i.chartered_bus_driver === true;
  const principle = hm(B.monthly_binding_hours);
  const limit = ext ? hm(B.monthly_binding_agreement_hours) : principle;
  const v: string[] = [];
  if (i.total_binding_minutes > limit) v.push(`1箇月の拘束時間が上限${limit / hm(1)}時間を超えています。`);
  if (ext && i.total_binding_minutes > principle) {
    if (!isCount(i.months_over_principle_in_year) || !isCount(i.consecutive_months_over_principle)) {
      v.push('281時間を超える月の年の回数・連続数が入力されていないため、延長できる月か確かめられません。');
    } else {
      if (i.months_over_principle_in_year > B.monthly_over_max_months_per_year) v.push(`281時間を超えられるのは1年に${B.monthly_over_max_months_per_year}箇月までです。`);
      if (i.consecutive_months_over_principle > B.monthly_over_max_consecutive_months) v.push(`281時間を超える月は${B.monthly_over_max_consecutive_months}箇月を超えて連続できません。`);
    }
  }
  if (i.annual_binding_minutes !== undefined) {
    const annualLimit = hm(ext ? B.annual_binding_agreement_hours : B.annual_binding_hours);
    if (i.annual_binding_minutes > annualLimit) v.push(`1年の拘束時間が上限${annualLimit / hm(1)}時間を超えています。`);
  }
  return judged(v, [], limit);
}

/** バス運転者等の4週平均1週・52週の拘束時間 (第5条第1項第1号ロ・第2号) */
export function checkBusFourWeekBinding(i: BusFourWeekInput): KaizenJudgement {
  const B = KAIZEN_KIJUN_BUS;
  const bad = badMinutes(i as unknown as Record<string, unknown>, ['four_week_binding_minutes']);
  if (i.fifty_two_week_binding_minutes !== undefined && !isValidMinutes(i.fifty_two_week_binding_minutes)) bad.push('fifty_two_week_binding_minutes');
  if (bad.length) return invalidInput(bad);
  const ext = i.has_labor_agreement === true && i.chartered_bus_driver === true;
  const principle = hm(B.weekly_avg_binding_hours) * B.averaging_weeks;
  const limit = ext ? hm(B.weekly_avg_binding_agreement_hours) * B.averaging_weeks : principle;
  const v: string[] = [];
  if (i.four_week_binding_minutes > limit) v.push('4週平均1週の拘束時間が上限を超えています。');
  if (ext && i.four_week_binding_minutes > principle) {
    if (!isCount(i.weeks_over_principle_in_52) || !isCount(i.consecutive_weeks_over_principle)) {
      v.push('65時間を超える週の52週の中の数・連続数が入力されていないため、延長できる週か確かめられません。');
    } else {
      if (i.weeks_over_principle_in_52 > B.weekly_over_max_weeks_in_52) v.push(`68時間まで延長できるのは52週のうち${B.weekly_over_max_weeks_in_52}週までです。`);
      if (i.consecutive_weeks_over_principle > B.weekly_over_max_consecutive_weeks) v.push(`65時間を超える週は${B.weekly_over_max_consecutive_weeks}週を超えて連続できません。`);
    }
  }
  if (i.fifty_two_week_binding_minutes !== undefined) {
    const yl = hm(ext ? B.fifty_two_week_binding_agreement_hours : B.fifty_two_week_binding_hours);
    if (i.fifty_two_week_binding_minutes > yl) v.push(`52週の拘束時間が上限${yl / hm(1)}時間を超えています。`);
  }
  return judged(v, [], limit);
}

/** バス運転者等の運転時間 (第5条第1項第5号) */
export function checkBusDriving(i: BusDrivingInput): KaizenJudgement {
  const B = KAIZEN_KIJUN_BUS;
  const bad: string[] = [];
  const two = i.two_day_driving_minutes;
  if (two !== undefined && (!Array.isArray(two) || two.length !== B.two_day_days || !two.every(isValidMinutes))) bad.push('two_day_driving_minutes');
  if (i.four_week_driving_minutes !== undefined && !isValidMinutes(i.four_week_driving_minutes)) bad.push('four_week_driving_minutes');
  if (two === undefined && i.four_week_driving_minutes === undefined) bad.push('two_day_driving_minutes / four_week_driving_minutes');
  if (bad.length) return invalidInput(bad);
  const v: string[] = [];
  if (two !== undefined && two.reduce((s, x) => s + x, 0) > hm(B.two_day_avg_driving_hours) * B.two_day_days) {
    v.push(`2日を平均した1日当たりの運転時間が${B.two_day_avg_driving_hours}時間を超えています。`);
  }
  if (i.four_week_driving_minutes !== undefined) {
    const ext = i.has_labor_agreement === true && i.chartered_bus_driver === true;
    const principle = hm(B.weekly_avg_driving_hours) * B.averaging_weeks;
    const limit = ext ? hm(B.weekly_avg_driving_agreement_hours) * B.averaging_weeks : principle;
    if (i.four_week_driving_minutes > limit) v.push('4週平均1週の運転時間が上限を超えています。');
    if (ext && i.four_week_driving_minutes > principle) {
      if (!isCount(i.weeks_over_40_in_52) || !isValidMinutes(i.fifty_two_week_driving_minutes)) {
        v.push('40時間を超える週の数・52週の運転時間が入力されていないため、延長できるか確かめられません。');
      } else {
        if (i.weeks_over_40_in_52 > B.weekly_driving_over_max_weeks_in_52) v.push(`44時間まで延長できるのは52週のうち${B.weekly_driving_over_max_weeks_in_52}週までです。`);
        if (i.fifty_two_week_driving_minutes > hm(B.fifty_two_week_driving_agreement_hours)) v.push(`52週の運転時間が${B.fifty_two_week_driving_agreement_hours}時間を超えています。`);
      }
    }
  }
  return judged(v, []);
}

/** タクシー日勤の1日の判定 (第2条第1項第2号〜第4号) */
export function checkTaxiDayShift(i: TaxiDayShiftInput): KaizenJudgement {
  const T = KAIZEN_KIJUN_TAXI;
  const bad = badMinutes(i as unknown as Record<string, unknown>, ['binding_minutes', 'rest_minutes']);
  if (bad.length) return invalidInput(bad);
  const v: string[] = [];
  const w: string[] = [];
  if (i.binding_minutes > hm(T.day_daily_binding_max_hours)) {
    if (i.garage_waiting !== true) {
      v.push(`1日の拘束時間が最大${T.day_daily_binding_max_hours}時間を超えています。`);
    } else {
      const reasons: string[] = [];
      if (!(isValidMinutes(i.rest_after_minutes) && i.rest_after_minutes >= hm(T.day_garage_rest_after_min_hours))) reasons.push(`勤務終了後に継続${T.day_garage_rest_after_min_hours}時間以上の休息`);
      if (i.binding_minutes > hm(T.day_garage_over_hours) && !(isCount(i.count_over_16h_in_month) && i.count_over_16h_in_month <= T.day_garage_over_max_count_per_month)) reasons.push(`${T.day_garage_over_hours}時間超は1箇月${T.day_garage_over_max_count_per_month}回以内`);
      if (i.binding_minutes > hm(T.day_garage_nap_required_over_hours) && !(isValidMinutes(i.night_nap_minutes) && i.night_nap_minutes >= hm(T.day_garage_nap_min_hours))) reasons.push(`${T.day_garage_nap_required_over_hours}時間超は夜間${T.day_garage_nap_min_hours}時間以上の仮眠`);
      if (i.binding_minutes > hm(T.day_garage_max_binding_hours)) reasons.push(`1回の勤務の拘束は${T.day_garage_max_binding_hours}時間以内`);
      if (reasons.length) v.push(`車庫待ち等で15時間を超えるための要件を満たしていません: ${reasons.join('・')}。`);
    }
  } else if (i.binding_minutes > hm(T.day_daily_binding_caution_hours)) {
    w.push('1日の拘束時間が14時間を超えています。14時間を超える回数をできるだけ少なくしてください (週3回までが目安)。');
  } else if (i.binding_minutes > hm(T.day_daily_binding_principle_hours)) {
    w.push('1日の拘束時間が原則13時間を超えています。');
  }
  if (i.rest_minutes < hm(T.day_rest_min_hours)) v.push(`休息期間が継続${T.day_rest_min_hours}時間を下回っています。`);
  else if (i.rest_minutes < hm(T.day_rest_effort_min_hours)) w.push(`休息期間が継続${T.day_rest_effort_min_hours}時間を下回っています (基本は${T.day_rest_effort_min_hours}時間以上)。`);
  return judged(v, w);
}

/** タクシー隔勤の判定 (第2条第2項第2号〜第4号) */
export function checkTaxiAlternateShift(i: TaxiAlternateShiftInput): KaizenJudgement {
  const T = KAIZEN_KIJUN_TAXI;
  const bad = badMinutes(i as unknown as Record<string, unknown>, ['two_day_binding_minutes', 'rest_minutes']);
  if (i.previous_shift_binding_minutes !== undefined && !isValidMinutes(i.previous_shift_binding_minutes)) bad.push('previous_shift_binding_minutes');
  if (bad.length) return invalidInput(bad);
  const v: string[] = [];
  const w: string[] = [];
  let garageExtended = false;
  if (i.two_day_binding_minutes > hm(T.alternate_two_day_binding_hours)) {
    const agreedOk = isCount(i.agreed_over_22h_count) && i.agreed_over_22h_count <= T.alternate_garage_over_max_count_per_month;
    const countOk = agreedOk && isCount(i.count_over_22h_in_month) && i.count_over_22h_in_month <= (i.agreed_over_22h_count as number);
    const napOk = isValidMinutes(i.night_nap_minutes) && i.night_nap_minutes >= hm(T.alternate_garage_nap_min_hours);
    const capOk = i.two_day_binding_minutes <= hm(T.alternate_garage_two_day_binding_hours);
    if (i.garage_waiting === true && agreedOk && countOk && napOk && capOk) {
      garageExtended = true;
    } else {
      v.push(`2暦日の拘束時間が${T.alternate_two_day_binding_hours}時間を超えています` +
        '（車庫待ち等で夜間4時間以上の仮眠・22時間超の回数を協定で1箇月7回以内・24時間以内の要件を満たしていません）。');
    }
  }
  // 2回の隔日勤務の平均 (第2条第2項第2号)。車庫待ち等の延長 (第3号) を使った勤務には当てない (要確認: 2026-10-04)。
  if (!garageExtended && i.previous_shift_binding_minutes !== undefined &&
      i.previous_shift_binding_minutes + i.two_day_binding_minutes > hm(T.alternate_two_shift_avg_hours) * T.alternate_two_shift_count) {
    v.push(`2回の隔日勤務の平均で1回当たり${T.alternate_two_shift_avg_hours}時間を超えています。`);
  }
  if (i.rest_minutes < hm(T.alternate_rest_min_hours)) v.push(`勤務終了後の休息期間が継続${T.alternate_rest_min_hours}時間を下回っています。`);
  else if (i.rest_minutes < hm(T.alternate_rest_effort_min_hours)) w.push(`勤務終了後の休息期間が継続${T.alternate_rest_effort_min_hours}時間を下回っています (基本は${T.alternate_rest_effort_min_hours}時間以上)。`);
  return judged(v, w);
}

/** タクシーの1箇月の拘束時間 (第2条第1項第1号・第2項第1号・第3号) */
export function checkTaxiMonthlyBinding(i: TaxiMonthlyInput): KaizenJudgement {
  const T = KAIZEN_KIJUN_TAXI;
  const bad = badMinutes(i as unknown as Record<string, unknown>, ['total_binding_minutes']);
  if (i.shift !== 'day' && i.shift !== 'alternate') bad.push('shift');
  if (bad.length) return invalidInput(bad);
  const agreement = i.has_labor_agreement === true;
  const garage = i.garage_waiting === true;
  const v: string[] = [];
  let limitHours: number;
  if (i.shift === 'day') {
    limitHours = garage && agreement ? T.day_garage_monthly_binding_hours : T.day_monthly_binding_hours;
  } else if (garage) {
    limitHours = (agreement ? T.alternate_monthly_binding_agreement_hours : T.alternate_monthly_binding_hours) +
      (i.garage_extension_conditions_met === true ? T.alternate_garage_monthly_addition_hours : 0);
  } else if (agreement && i.special_circumstances === true) {
    limitHours = T.alternate_monthly_binding_agreement_hours;
    if (i.total_binding_minutes > hm(T.alternate_monthly_binding_hours)) {
      if (!isCount(i.months_over_principle_in_year)) {
        v.push('262時間を超える月の年の回数が入力されていないため、延長できる月か確かめられません。');
      } else if (i.months_over_principle_in_year > T.alternate_over_max_months_per_year) {
        v.push(`270時間まで延長できるのは1年に${T.alternate_over_max_months_per_year}箇月までです。`);
      }
    }
  } else {
    limitHours = T.alternate_monthly_binding_hours;
  }
  const limit = hm(limitHours);
  if (i.total_binding_minutes > limit) v.push(`1箇月の拘束時間が上限${limitHours}時間を超えています。`);
  return judged(v, [], limit);
}
// </kaizen-bus-taxi-judge>

// =============================================================================
// 運行管理者 (Operations Manager)
// =============================================================================

export type OperationsManagerKind = 'cargo' | 'passenger';

export interface OperationsManagerCertification {
  manager_id: string;
  name: string;
  kind: OperationsManagerKind;
  /** 国家試験合格番号 */
  certification_no: string;
  /** 講習受講日 (5年に1回) */
  last_training_date: string;
  /** 営業所名 (選任は営業所単位。必要人数は floor(両数/30)+1 — 輸送安全規則第18条第1項) */
  branch_name: string;
}

/**
 * 運行管理者の法定選任人数 = floor(事業用自動車の数 / 30) + 1
 *
 * 【出典 — 一次情報】貨物自動車運送事業輸送安全規則 (平成2年運輸省令第22号)
 *   第18条第1項 (運行管理者等の選任) — e-Gov 法令検索で原文確認
 *   https://laws.e-gov.go.jp/law/402M50000800022
 *
 *   「…当該営業所が運行を管理する事業用自動車の数を三十で除して得た数
 *     （その数に一未満の端数があるときは、これを切り捨てるものとする。）に
 *     一を加算して得た数以上の運行管理者を選任しなければならない。」
 *
 * ★「30両ごとに1名」= ceil(n/30) と読むのは誤り。法定式は floor(n/30) + 1 である。
 *   両者は【30の倍数のときだけ】食い違い、常に法定人数を1名下回る:
 *     29両 → ceil 1 / 法定 1 (一致)   ← ここだけ検査すると欠陥が素通りする
 *     30両 → ceil 1 / 法定 2 (不足)
 *     60両 → ceil 2 / 法定 3 (不足)
 *   選任数の不足は貨物自動車運送事業法上の行政処分の対象となるため、
 *   切り上げ方式へ戻してはならない。
 *
 * ★判定は【営業所ごと】。被けん引自動車は両数に算入しない (同項かっこ書き)。
 * ★同項ただし書き: 5両未満の事業用自動車を管理する営業所であって、地方運輸局長が
 *   運行の安全確保に支障を生ずるおそれがないと認めたものは選任を要しない。
 *   ただしこれは個別認定が前提であり、5両未満なら自動的に不要になるわけではないため、
 *   本関数は既定では認定なし (=選任必要) として法定人数を返す。
 * ★1営業所で複数名を選任する場合は統括運行管理者の選任も必要 (同条第2項)。
 *
 * @param vehicle_count 当該営業所が運行を管理する事業用自動車の数 (被けん引自動車を除く)
 */
export function getRequiredOperationsManagerCount(vehicle_count: number): number {
  if (vehicle_count <= 0) return 0;
  return Math.floor(vehicle_count / 30) + 1;
}

// =============================================================================
// 点呼 (Tenko)
// =============================================================================

export type TenkoKind = 'start' | 'end' | 'middle' | 'it_tenko';

export interface TenkoRecord {
  driver_id: string;
  manager_id: string;
  kind: TenkoKind;
  ts: string;
  /** アルコール検知器の測定値 (呼気 mg/L)。0 を超えれば「酒気を帯びた状態」= 乗務不可 */
  alcohol_mg_per_l: number;
  /** 健康状態確認 */
  health_check_passed: boolean;
  /** 車両点検確認 */
  vehicle_check_passed: boolean;
  remarks?: string;
}

/**
 * 点呼における酒気帯びの判定閾値 (mg/L)。
 *
 * 【出典 — 一次情報】
 *   (1) 貨物自動車運送事業輸送安全規則 第3条第5項 — e-Gov 法令検索で原文確認
 *       https://laws.e-gov.go.jp/law/402M50000800022
 *       「貨物自動車運送事業者は、酒気を帯びた状態にある乗務員等を
 *         事業用自動車の運行の業務に従事させてはならない。」
 *       → 条文に mg/L 等の数値基準は【存在しない】。
 *   (2) 国土交通省通達「貨物自動車運送事業輸送安全規則の解釈及び運用について」
 *       (平成15年3月10日 国自総第510号ほか) 第3条第5項関係
 *       https://www.mlit.go.jp/jidosha/anzen/03safety/resourse/data/construction_kamotsu.pdf
 *       「『酒気を帯びた状態』とは、道路交通法施行令第44条の3に規定する
 *         血液中のアルコール濃度0.3mg/mℓ又は呼気中のアルコール濃度0.15mg/ℓ以上で
 *         あるか否かを問わないものである。」
 *       → 監督官庁が明文で「0.15mg/L 以上か否かは問わない」と declare している。
 *
 * ★0.15mg/L は道路交通法施行令第44条の3が定める【酒気帯び運転の検挙基準】であり、
 *   運送事業の点呼基準ではない。これを点呼の合否閾値に流用すると、
 *   0.14mg/L の運転者を「乗務可」と判定して乗務させることになり、輸送安全規則違反
 *   (および事業者に対する行政処分) を実装が誘発する。検挙基準を業務基準に転用しないこと。
 *
 * ★したがって閾値は 0。検知器が微量でも検知したら乗務不可とする。
 */
export const TENKO_ALCOHOL_THRESHOLD_MG_PER_L = 0;

/**
 * 点呼の合否判定。
 *
 * 酒気帯びの有無・疾病/疲労等の有無・日常点検の実施を確認する
 * (輸送安全規則 第7条第1項各号)。酒気帯びの確認は目視等に加え、営業所に備えた
 * アルコール検知器を用いて行わなければならない (同条第4項)。
 *
 * ★アルコールは「検知されないこと」が条件であり、数値の大小比較で
 *   一定量までを許容してはならない (上記 TENKO_ALCOHOL_THRESHOLD_MG_PER_L の出典を参照)。
 *   NaN 等の不正な測定値は比較が false となり、安全側 (不合格) に倒れる。
 */
export function isTenkoPassed(rec: TenkoRecord): boolean {
  // ★2026-10-04 是正: 旧実装は `rec.alcohol_mg_per_l <= 0` だけで判定していたため、
  //   null・空文字 ("" <= 0 は真)・負の異常値を「検知なし」として乗務可にしていた。
  //   健康状態・日常点検も真偽の別 (文字列 "false" は真に見える) を確かめていなかった。
  return isAlcoholCheckClear(rec.alcohol_mg_per_l) &&
    rec.health_check_passed === true &&
    rec.vehicle_check_passed === true;
}

/**
 * アルコール検知器の測定値が「酒気を帯びていない」と言えるか (運送事業の点呼・白ナンバーの安全運転管理者の確認で共通)。
 *
 * ★数値として読めて、0 以上かつ閾値 (0) 以下 = 0 のときだけ true。0.00 以外は乗務・運転させない。
 *   null・undefined・NaN・空文字・文字列・負の値 (機器の異常) は確かめられないので false (安全側)。
 *   道路交通法施行規則 第9条の10第6号 (安全運転管理者による検知器での確認) も数値基準を置いていない。
 */
export function isAlcoholCheckClear(alcohol_mg_per_l: unknown): boolean {
  return typeof alcohol_mg_per_l === 'number' &&
    Number.isFinite(alcohol_mg_per_l) &&
    alcohol_mg_per_l >= 0 &&
    alcohol_mg_per_l <= TENKO_ALCOHOL_THRESHOLD_MG_PER_L;
}

/**
 * 点呼の方式 (対面 / 遠隔 / 業務前自動 / 業務後自動)。
 *   出典: 国土交通省「遠隔点呼・自動点呼 解説パンフレット」(令和7年11月) https://www.mlit.go.jp/jidosha/content/001970917.pdf
 *   点呼告示 (対面による点呼と同等の効果を有するものとして国土交通大臣が定める方法を定める告示・令和5年国交省告示第266号、
 *   令和7年4月30日改正で業務前自動点呼を制度化。改正告示の番号「第347号」は二次情報で一次未照合)。
 */
export type TenkoMethod = 'face_to_face' | 'remote' | 'auto_pre' | 'auto_post';

/** 点呼の方式ごとの要件の値 (パンフレット p.6・p.8・p.9) */
export const TENKO_METHOD_RULES = {
  /** 遠隔点呼・自動点呼の届出は実施予定日の10日前まで (管轄の運輸支局等) */
  notification_lead_days: 10,
} as const;

export interface TenkoMethodInput {
  method?: TenkoMethod | string;
  /** 遠隔点呼・自動点呼の実施予定日 (YYYY-MM-DD) */
  implementation_date?: string;
  /** 運輸支局等へ届け出た日 (YYYY-MM-DD) */
  notification_filed_on?: string;
  /** 自動点呼機器の国土交通省の認定番号 (例: JM25-002) */
  device_certification_no?: string;
  /** 生体認証等で運転者等を識別できたか (自動点呼) */
  biometric_identified?: boolean;
  /** アルコール検知器使用中の静止画・動画を記録したか (自動点呼) */
  alcohol_image_recorded?: boolean;
  /** 平時の体温・血圧を点呼機器に登録してあるか (業務前自動点呼) */
  baseline_vitals_registered?: boolean;
  /** 遠隔点呼を別の会社と実施するか (事業者間遠隔点呼) */
  inter_company?: boolean;
  /** 業務の管理受委託の許可を受けているか (事業者間遠隔点呼) */
  management_entrustment_permitted?: boolean;
}

function ymdToUtcMs(s: unknown): number | null {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const [y, m, d] = s.split('-').map(Number);
  const ms = Date.UTC(y, m - 1, d);
  const back = new Date(ms);
  if (back.getUTCFullYear() !== y || back.getUTCMonth() !== m - 1 || back.getUTCDate() !== d) return null;
  return ms;
}

/**
 * 点呼の方式が要件を満たしているか。満たさない・記録が無い場合は ok=false (その点呼では乗務させない)。
 *   ・対面: 方式としての追加要件なし
 *   ・遠隔: 届出 (実施予定日の10日前まで)。別の会社と実施するなら業務の管理受委託の許可。機器の認定は要らない
 *   ・業務前自動 / 業務後自動: 国土交通省の認定機器 (認定番号)・届出 (10日前まで)・生体認証等での識別・
 *     検知器使用中の静止画/動画の記録。業務前は平時の体温・血圧の登録も要る
 * ★「10日前まで」は実施予定日の前日から遡って10日目 (例: 11/11 実施 → 11/1 まで) と読んだ。運輸支局の運用で要確認。
 */
export function judgeTenkoMethod(i: TenkoMethodInput): { ok: boolean; method: string; reasons: string[] } {
  const reasons: string[] = [];
  const method = String(i && i.method);
  const needsNotification = method === 'remote' || method === 'auto_pre' || method === 'auto_post';
  if (method === 'face_to_face') return { ok: true, method, reasons };
  if (!needsNotification) return { ok: false, method, reasons: ['点呼の方式が分かりません (対面・遠隔・業務前自動・業務後自動のいずれか)。'] };
  const filed = ymdToUtcMs(i.notification_filed_on);
  const impl = ymdToUtcMs(i.implementation_date);
  if (filed === null) reasons.push('運輸支局等への届出の記録 (届出日) がありません。');
  else if (impl === null) reasons.push('実施予定日が無いため、届出が10日前までか確かめられません。');
  else if (filed > impl - TENKO_METHOD_RULES.notification_lead_days * 86400000) {
    reasons.push(`届出が実施予定日の${TENKO_METHOD_RULES.notification_lead_days}日前までに行われていません。`);
  }
  if (method === 'remote') {
    if (i.inter_company === true && i.management_entrustment_permitted !== true) {
      reasons.push('別の会社と遠隔点呼を行うには、業務の管理受委託の許可が必要です (許可の記録がありません)。');
    }
  } else {
    if (typeof i.device_certification_no !== 'string' || i.device_certification_no.trim() === '') {
      reasons.push('自動点呼機器の国土交通省の認定番号がありません (認定を受けた機器でなければ自動点呼はできません)。');
    }
    if (i.biometric_identified !== true) reasons.push('生体認証等で運転者等を識別できていません。');
    if (i.alcohol_image_recorded !== true) reasons.push('アルコール検知器使用中の静止画・動画の記録がありません。');
    if (method === 'auto_pre' && i.baseline_vitals_registered !== true) {
      reasons.push('業務前自動点呼に必要な平時の体温・血圧の登録がありません。');
    }
  }
  return { ok: reasons.length === 0, method, reasons };
}

/** 点呼の結果 (酒気帯び・健康状態・日常点検) と方式の要件をあわせて、乗務させてよいかを返す。 */
export function judgeTenko(rec: TenkoRecord, method: TenkoMethodInput): { fit_for_duty: boolean; reasons: string[] } {
  const reasons: string[] = [];
  if (!isAlcoholCheckClear(rec && rec.alcohol_mg_per_l)) reasons.push('アルコールが検知された (0.00 以外) か、測定値が読めません。乗務させないでください。');
  if (!(rec && rec.health_check_passed === true)) reasons.push('疾病・疲労・睡眠不足等の確認が済んでいません。');
  if (!(rec && rec.vehicle_check_passed === true)) reasons.push('日常点検の確認が済んでいません。');
  const m = judgeTenkoMethod(method || {});
  reasons.push(...m.reasons);
  return { fit_for_duty: reasons.length === 0, reasons };
}

// =============================================================================
// 白ナンバー (自家用自動車) の安全運転管理者 — 2026-10-04 追加
// =============================================================================

/**
 * 安全運転管理者・副安全運転管理者の選任台数 (一次情報: e-Gov 法令API v2 で現行条文を取得・2026-10-03)。
 *   道路交通法 第74条の3第1項 (自動車の使用者は内閣府令で定める台数以上の使用の本拠ごとに安全運転管理者を選任。
 *     道路運送法の自動車運送事業者 (貨物軽自動車運送事業を経営する者を除く)・第二種貨物利用運送事業者・
 *     道路運送法79条の登録を受けた者は除く) / 第4項 (副安全運転管理者)
 *   道路交通法施行規則 第9条の8 第1項 乗車定員11人以上は1台・その他は5台 / 第2項 副は20台 / 第3項 大型・普通自動二輪車は0.5台
 *   同 第9条の11 20台以上40台未満は1人、40台以上は20台を増すごとに1人を加算 (= floor(台数 / 20))
 *   同 第9条の10第6号・第7号 運転前後に目視等とアルコール検知器で酒気帯びの有無を確認し、記録を1年間保存
 */
export const SAFE_DRIVING_MANAGER_RULES = {
  passenger_11plus_threshold: 1,
  other_vehicle_threshold: 5,
  vice_threshold: 20,
  vice_step: 20,
  motorcycle_weight: 0.5,
  alcohol_record_retention_years: 1,
} as const;

export type CarrierType = 'none' | 'light_cargo' | 'general_cargo' | 'specific_cargo' | 'passenger' | 'second_class_forwarding' | 'private_paid_79';

export function getRequiredSafeDrivingManagers(i: {
  /** 乗車定員11人以上の自動車の台数 */
  vehicles_11plus_seats?: number;
  /** その他の自動車 (乗用車・トラック等) の台数 */
  other_vehicles?: number;
  /** 大型自動二輪車・普通自動二輪車の台数 (1台0.5台で数える。原動機付自転車は数えない) */
  motorcycles?: number;
  /** 事業の種類。緑ナンバーの自動車運送事業者等は道交法の安全運転管理者の対象外 (貨物軽自動車運送事業者は対象) */
  carrier_type?: CarrierType;
}): { status: 'ok' | 'not_applicable' | 'invalid_input'; safe_driving_manager_required: boolean | null; vice_managers_required: number | null; vehicle_count: number | null; basis_ja: string } {
  const R = SAFE_DRIVING_MANAGER_RULES;
  const num = (v: unknown) => (v === undefined ? 0 : v);
  const big = num(i.vehicles_11plus_seats);
  const other = num(i.other_vehicles);
  const moto = num(i.motorcycles);
  const valid = (v: unknown) => typeof v === 'number' && Number.isFinite(v) && v >= 0 && Number.isInteger(v);
  if (![big, other, moto].every(valid)) {
    return { status: 'invalid_input', safe_driving_manager_required: null, vice_managers_required: null, vehicle_count: null, basis_ja: '台数が読めないため判定できません。' };
  }
  const ct = i.carrier_type ?? 'none';
  if (ct !== 'none' && ct !== 'light_cargo') {
    return { status: 'not_applicable', safe_driving_manager_required: false, vice_managers_required: 0, vehicle_count: null, basis_ja: '道路交通法第74条の3第1項かっこ書により対象外 (運行管理者の制度による)。' };
  }
  const count = (big as number) + (other as number) + (moto as number) * R.motorcycle_weight;
  const required = (big as number) >= R.passenger_11plus_threshold || count >= R.other_vehicle_threshold;
  const vice = count >= R.vice_threshold ? Math.floor(count / R.vice_step) : 0;
  return {
    status: 'ok',
    safe_driving_manager_required: required,
    vice_managers_required: vice,
    vehicle_count: count,
    basis_ja: '道路交通法第74条の3・同施行規則第9条の8・第9条の11。選任から15日以内に公安委員会へ届出 (第74条の3第5項)。',
  };
}

// =============================================================================
// 運転者の画面 — 走行中の入力の禁止 (2026-10-04 追加)
// =============================================================================

export interface VehicleMotionState {
  /** 車速 (km/h)。数値で 0 と確かめられたときだけ停止とみなす */
  speed_kmh?: unknown;
  /** 走行中の印 (車両・デジタコ側の信号)。true なら速度に関わらず走行中 */
  moving?: unknown;
  parking_brake?: unknown;
}

/**
 * 運転者に入力させてよいか。停止していると確かめられたときだけ true。
 *   道路交通法 第71条第5号の5 (自動車が停止しているときを除き、携帯電話等の画面を注視しない) に沿い、
 *   速度が未入力・NaN・文字列・負・0 より大きい、又は走行中の印が立っているときは false (安全側)。
 */
export function isDriverInputAllowed(s: VehicleMotionState): boolean {
  if (!s || typeof s !== 'object') return false;
  const v = s.speed_kmh;
  return typeof v === 'number' && Number.isFinite(v) && v === 0 && s.moving !== true;
}

const escapeHtml = (x: unknown) => String(x ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string));

/**
 * 運転者の画面 (業務の記録の入力) を描画する。走行中 (又は停止を確かめられない) ときは入力部品を1つも描画しない。
 * 生成するアプリの運転者画面はこの関数 (又は isDriverInputAllowed) で描き分ける。
 */
export function renderDriverScreenHtml(state: VehicleMotionState, opts: { driver_name?: string } = {}): string {
  const name = escapeHtml(opts.driver_name || '');
  if (!isDriverInputAllowed(state)) {
    return [
      '<main class="driver-screen" data-driving-lock="on" aria-live="polite">',
      '<h1>走行中は入力できません</h1>',
      '<p>安全な場所に停車してから操作してください。停車すると入力の画面に切り替わります。</p>',
      name ? `<p class="driver-name">運転者: ${name}</p>` : '',
      '</main>',
    ].join('');
  }
  return [
    '<main class="driver-screen" data-driving-lock="off">',
    '<h1>業務の記録</h1>',
    name ? `<p class="driver-name">運転者: ${name}</p>` : '',
    '<form method="post" action="/driver/records">',
    '<label>記録の種類 <select name="kind">',
    '<option value="waiting_start">荷待ちの開始</option><option value="waiting_end">荷待ちの終了</option>',
    '<option value="loading_start">荷役の開始</option><option value="loading_end">荷役の終了</option>',
    '<option value="break">休憩</option></select></label>',
    '<label>時刻 <input type="datetime-local" name="at" required></label>',
    '<label>地点 <input type="text" name="place"></label>',
    '<label>メモ <textarea name="note" rows="2"></textarea></label>',
    '<button type="submit">記録する</button>',
    '</form>',
    '</main>',
  ].join('');
}

// =============================================================================
// 軽貨物 (貨物軽自動車運送事業) の安全管理者・講習・記録の期限 — 2026-10-04 追加
// =============================================================================

/**
 * 【出典 — 一次情報 (e-Gov 法令API v2 の現行条文)】
 *   貨物自動車運送事業法 第36条の2第1項 (四輪以上の軽自動車を使用する事業者に限る。届出後、速やかに、営業所ごとに
 *     貨物軽自動車安全管理者1人を選任。1号 講習を選任の日前2年以内に修了した者 / 3号 運行管理者として選任されている者)
 *     第3項 (選任の日から2年以内において省令で定める期間ごとに定期講習) / 輸送安全規則 第33条の3 (期間は2年)
 *   令和6年法律第23号 附則第4条 (施行の際現に経営している者は、施行の日 (2025-04-01) から起算して2年を経過する日
 *     (2027-03-31) までの間は選任しなくてよい)
 *   輸送安全規則 第8条第1項 (業務の記録 1年間保存・四輪以上に限る) / 第9条の2 (事故の記録 3年間) /
 *     第10条第1項 (指導監督の記録 3年間) / 第9条の6第2項 (運転者でなくなった者の台帳 3年間)
 *   民法 第140条 (初日不算入) / 第143条 (暦による計算。応当日の前日に満了。応当日が無いときはその月の末日)
 *
 * ★講習の起算 (2026-10-04 時点で運輸支局・士業の確認待ち): 1日違いの読みが2つある箇所は、
 *   どちらの読みでも違反にならない側 (安全側) で判定し、もう一方 (民法の読み) も併せて返す。
 */
export const KEI_CARGO_SAFETY = {
  enforcement_date: '2025-04-01',
  grace_end_date: '2027-03-31',
  lecture_window_years: 2,
  periodic_lecture_years: 2,
  record_retention_years: {
    business_record: 1,
    accident_record: 3,
    guidance_record: 3,
    driver_ledger_after_leaving: 3,
  },
} as const;

function ymdOf(ms: number): string {
  return new Date(ms).toISOString().slice(0, 10);
}
function addDaysYmd(s: string, n: number): string | null {
  const ms = ymdToUtcMs(s);
  return ms === null ? null : ymdOf(ms + n * 86400000);
}
/** 起算日 start (その日を1日目) から years 年の期間の末日 (民法143条) */
function civilYearPeriodEnd(start: string, years: number): string | null {
  const ms = ymdToUtcMs(start);
  if (ms === null) return null;
  const d = new Date(ms);
  const y = d.getUTCFullYear() + years;
  const m = d.getUTCMonth();
  const day = d.getUTCDate();
  const lastDay = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  if (day > lastDay) return ymdOf(Date.UTC(y, m, lastDay)); // 応当日が無い月はその月の末日に満了
  return ymdOf(Date.UTC(y, m, day) - 86400000); // 応当日の前日に満了
}
/** start から years 年遡った「応当日」(無い月はその月の末日) */
function correspondingDayBack(start: string, years: number): string | null {
  const ms = ymdToUtcMs(start);
  if (ms === null) return null;
  const d = new Date(ms);
  const y = d.getUTCFullYear() - years;
  const m = d.getUTCMonth();
  const lastDay = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  return ymdOf(Date.UTC(y, m, Math.min(d.getUTCDate(), lastDay)));
}

/** 営業所ごとの貨物軽自動車安全管理者の選任の期限と状態 */
export function judgeKeiSafetyManagerDeadline(i: { four_wheel?: boolean; notified_on: string; base_date: string; appointed_on?: string | null }): { status: 'not_applicable' | 'appointed' | 'grace' | 'overdue' | 'required_now' | 'invalid_input'; deadline: string | null; basis_ja: string } {
  const K = KEI_CARGO_SAFETY;
  if (i && i.four_wheel === false) return { status: 'not_applicable', deadline: null, basis_ja: '四輪以上の軽自動車を使用する事業者に限る (法36条の2第1項)。二輪のみは対象外。' };
  if (ymdToUtcMs(i && i.notified_on) === null || ymdToUtcMs(i && i.base_date) === null) {
    return { status: 'invalid_input', deadline: null, basis_ja: '届出日・基準日が読めないため判定できません。' };
  }
  const existing = i.notified_on < K.enforcement_date; // 施行の際に現に経営していた者 (届出日で代える・休業等は人が確かめる)
  const deadline = existing ? K.grace_end_date : 'without_delay_after_notification';
  const appointed = typeof i.appointed_on === 'string' && ymdToUtcMs(i.appointed_on) !== null && i.appointed_on <= i.base_date;
  if (appointed) return { status: 'appointed', deadline, basis_ja: '選任済み。選任後は遅滞なく氏名を届け出る (法36条の2第2項)。' };
  if (existing) {
    return i.base_date <= K.grace_end_date
      ? { status: 'grace', deadline, basis_ja: '令和6年法律第23号附則4条: 2027-03-31 まで選任の猶予 (施行の日から起算して2年を経過する日)。' }
      : { status: 'overdue', deadline, basis_ja: '猶予は 2027-03-31 で終わっています。速やかに選任してください。' };
  }
  return { status: 'required_now', deadline, basis_ja: '法36条の2第1項: 届出後、速やかに選任 (施行日以後の届出に猶予はありません)。' };
}

/** 選任しようとする者が「選任の日前2年以内」に講習を修了しているか */
export function checkKeiLectureEligibility(i: { appointed_on: string; lecture_completed_on: string; is_operations_manager?: boolean }): { eligible: boolean; legal_reading_eligible: boolean; needs_confirmation: boolean; earliest_safe: string | null; earliest_legal_reading: string | null; basis_ja: string } {
  const K = KEI_CARGO_SAFETY;
  if (i && i.is_operations_manager === true) {
    return { eligible: true, legal_reading_eligible: true, needs_confirmation: false, earliest_safe: null, earliest_legal_reading: null, basis_ja: '法36条の2第1項3号: 運行管理者として選任されている者は講習の修了に代えられる。' };
  }
  const ap = i && i.appointed_on;
  const done = i && i.lecture_completed_on;
  if (ymdToUtcMs(ap) === null || ymdToUtcMs(done) === null) {
    return { eligible: false, legal_reading_eligible: false, needs_confirmation: true, earliest_safe: null, earliest_legal_reading: null, basis_ja: '日付が読めないため判定できません。' };
  }
  // 民法の読み: 選任日の前日を1日目に遡る → 応当日の翌日が最も古い修了日
  const dayBefore = addDaysYmd(ap, -1) as string;
  const earliestLegal = addDaysYmd(correspondingDayBack(dayBefore, K.lecture_window_years) as string, 1) as string;
  // 安全側の読み: 選任日を1日目に遡る → 1日新しくなる
  const earliestSafe = addDaysYmd(correspondingDayBack(ap, K.lecture_window_years) as string, 1) as string;
  const legal = done >= earliestLegal && done < ap;
  const safe = done >= earliestSafe && done < ap;
  return {
    eligible: safe,
    legal_reading_eligible: legal,
    needs_confirmation: safe !== legal,
    earliest_safe: earliestSafe,
    earliest_legal_reading: earliestLegal,
    basis_ja: safe !== legal
      ? `境目の日です。民法の読みでは選任できますが、選任日を1日目に数える読みではできません。安全側で「不可」とし、運輸支局へ確認してください (民法の読みの最も古い修了日 ${earliestLegal})。`
      : '法36条の2第1項1号・2号 (選任の日前2年以内の修了)。',
  };
}

/** 定期講習を受けさせる期限 (選任の日から2年ごと) */
export function computeKeiPeriodicLectureDue(i: { from: string }): { deadline: string | null; legal_reading_deadline: string | null; needs_confirmation: boolean; basis_ja: string } {
  const K = KEI_CARGO_SAFETY;
  if (ymdToUtcMs(i && i.from) === null) return { deadline: null, legal_reading_deadline: null, needs_confirmation: true, basis_ja: '日付が読めないため判定できません。' };
  const safe = civilYearPeriodEnd(i.from, K.periodic_lecture_years);
  const legal = civilYearPeriodEnd(addDaysYmd(i.from, 1) as string, K.periodic_lecture_years);
  return {
    deadline: safe,
    legal_reading_deadline: legal,
    needs_confirmation: safe !== legal,
    basis_ja: '法36条の2第3項・輸送安全規則33条の3 (2年)。期限は選任日を1日目に数えた安全側の日。民法140条 (翌日起算) の読みの期限を legal_reading_deadline に示す。',
  };
}

/** 記録の保存の満了日 (記録の日の翌日を1日目に年数を数える) */
export function computeKeiRecordRetention(i: { record_type: string; from: string }): { retain_until: string | null; years: number | null; status: 'ok' | 'unknown_record_type' | 'invalid_input'; basis_ja: string } {
  const table = KEI_CARGO_SAFETY.record_retention_years as Record<string, number>;
  const years = Object.prototype.hasOwnProperty.call(table, i && i.record_type) ? table[i.record_type] : undefined;
  if (years === undefined) return { retain_until: null, years: null, status: 'unknown_record_type', basis_ja: '表に無い記録の種類です。保存期間を確かめてください。' };
  if (ymdToUtcMs(i.from) === null) return { retain_until: null, years, status: 'invalid_input', basis_ja: '日付が読めないため判定できません。' };
  return {
    retain_until: civilYearPeriodEnd(addDaysYmd(i.from, 1) as string, years),
    years,
    status: 'ok',
    basis_ja: '輸送安全規則 8条1項 (1年)・9条の2 (3年)・10条1項 (3年)・9条の6第2項 (3年)。民法140条・143条。満了日までは削除できない設計にする。',
  };
}

// =============================================================================
// 標準的な運賃 (国交省告示 R6改訂)
// =============================================================================

/**
 * 標準的な運賃 (一般貨物自動車運送事業に係る標準的な運賃を定めた件・令和6年国土交通省告示第209号。
 * 根拠は貨物自動車運送事業法附則第1条の3。出典: 国土交通省 通達 国自貨第844号 https://www.mlit.go.jp/jidosha/content/001732622.pdf)
 *
 * ★未対応: 告示の運賃表は「運輸局 × 車種 × 距離帯 (距離制) / 時間制」の表で決まり、この部品はその表を持っていない。
 *   旧実装の「100kmまで30,000円・以降250円/km・5,500円/時間・待機2,500円/30分」は告示の表と照合できない独自の式で、
 *   見積の金額を誤らせるため、金額を作らずに status='unsupported' を返す (値は null)。
 *   告示の表を一次資料から転記して版つきで持つまで、運賃は国土交通省・各運輸局の告示の表から引くこと。
 */
export function calcStandardFreight(args: {
  vehicle_class: '2t' | '4t' | '10t' | '20t';
  distance_km: number;
  hours: number;
  waiting_minutes?: number;
  highway_fee?: number;
  fuel_surcharge_rate?: number; // 0.0〜0.2 程度
}): {
  status: 'unsupported';
  distance_fee: null;
  time_fee: null;
  waiting_fee: null;
  highway_fee: number;
  fuel_surcharge: null;
  total: null;
  reason: string;
  source: string;
} {
  return {
    status: 'unsupported',
    distance_fee: null,
    time_fee: null,
    waiting_fee: null,
    highway_fee: args.highway_fee ?? 0,
    fuel_surcharge: null,
    total: null,
    reason:
      `標準的な運賃は告示の表 (運輸局×車種×距離帯/時間制) から引く必要があり、この部品は表を持っていないため計算できません (${args.vehicle_class}・${args.distance_km}km・${args.hours}時間)。国土交通省・各運輸局が公表している告示の表で確認してください`,
    source: '令和6年国土交通省告示第209号 (貨物自動車運送事業法附則第1条の3) https://www.mlit.go.jp/jidosha/jidosha_tk4_000118.html',
  };
}

// =============================================================================
// 倉庫業法 (倉庫種別)
// =============================================================================

export const WAREHOUSE_CLASSES = [
  { class: '1類', desc: '通常品 (常温品全般)', requirements: ['防火壁', '防湿', '防鼠', '耐震', '床荷重'] },
  { class: '2類', desc: '燃えにくい品 (金属/陶磁器)', requirements: ['防湿', '防鼠'] },
  { class: '3類', desc: '燃えにくく湿気にも強い品 (鉱物)', requirements: ['防鼠'] },
  { class: '野積', desc: '原木/タイヤ/車両', requirements: ['周囲塀', '滅火設備'] },
  { class: '貯蔵槽', desc: '穀物/食用油 (タンク)', requirements: ['気密性', '害虫'] },
  { class: '危険品', desc: '消防法/高圧ガス保安法 危険物', requirements: ['消防適合', '保安距離', '避難計画'] },
  { class: '冷蔵', desc: '10℃以下', requirements: ['断熱', '冷却', '温度記録'] },
] as const;

// =============================================================================
// 配車最適化 (TSP/VRP の Greedy 最適化)
// =============================================================================

export interface DeliveryStop {
  stop_id: string;
  /** 緯度経度 (簡易距離計算用) */
  lat: number;
  lng: number;
  /** 配達指定時間帯 (開始) */
  window_start?: string;
  /** 配達指定時間帯 (終了) */
  window_end?: string;
  /** 重量 (kg) */
  weight_kg: number;
}

/**
 * Haversine 距離 (km)
 */
export function distanceKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

/**
 * Greedy Nearest Neighbor で配車順を決定 (簡易)
 *  - 始点から最も近い未訪問先を順次選択
 */
export function greedyTSP(
  startLat: number,
  startLng: number,
  stops: DeliveryStop[],
): DeliveryStop[] {
  const remaining = [...stops];
  const route: DeliveryStop[] = [];
  let curLat = startLat;
  let curLng = startLng;
  while (remaining.length > 0) {
    let bestIdx = 0;
    let bestDist = Infinity;
    for (let i = 0; i < remaining.length; i++) {
      const d = distanceKm(curLat, curLng, remaining[i].lat, remaining[i].lng);
      if (d < bestDist) {
        bestDist = d;
        bestIdx = i;
      }
    }
    const next = remaining.splice(bestIdx, 1)[0];
    route.push(next);
    curLat = next.lat;
    curLng = next.lng;
  }
  return route;
}

/**
 * 積載量超過チェック
 */
export function isOverloaded(stops: DeliveryStop[], vehicle_max_kg: number): boolean {
  const total = stops.reduce((s, x) => s + x.weight_kg, 0);
  return total > vehicle_max_kg;
}
