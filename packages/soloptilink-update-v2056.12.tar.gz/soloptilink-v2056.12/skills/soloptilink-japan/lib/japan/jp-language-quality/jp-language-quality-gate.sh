#!/usr/bin/env bash
# 日本語Windowsで python3 / node の出力が cp932 になり途中停止するのを防ぐ
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# ----------------------------------------------------------------
# 日本語品質・感性ゲート（jp-language-quality-gate）
#   設計書: ~/jpo-run/_原本_計画書類一式/05_設計/05_日本語品質・感性ゲート設計書.md（JPO-D05 第1.1版）§1.3 の B
#   生成物の画面の固定文言・帳票・メールのひな形を 115 規則のうち機械で判定できる規則で調べ、
#   同梱の日本語部品に部品検体を通し、<project_dir>/.soloptilink/jp-language-quality.json に書く。
#
#   ★段階は「観察」（記録のみ・止めない・設計書 §7.3）。verdict が WARN でも終了コードは 0。
#     止めるへの昇格は、規則ごとに誤検出3%以下・検出95%以上・検体数の条件（§7.3）を満たしてから判定会で決める。
#   ★判定は Node で行う（bash で文面を照合しない。bash 3.2 は長い文字列の置換が極端に遅い・本体の教訓）。
#   ★外部への通信はしない。書き込むのは結果の JSON 1 本だけ。
#
# CLI:
#   bash jp-language-quality-gate.sh run <project_dir>   … 走査して結果を書く（exit 0 = PASS/WARN/not_applicable/unmeasurable）
#   bash jp-language-quality-gate.sh selftest            … 検体（lib/japan/_verify/jpo-B4-jq-*.verify.mjs）を走らせる
# exit: 0=観察として記録した / 2=対象フォルダが無い / 64=使い方の誤り / 127=node が無く測れない
# kill-switch: SOLOPTILINK_JP_LANGUAGE_QUALITY_GATE=off → 走査せず verdict=disabled を書く（合格とは書かない）
# ----------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLI="$HERE/jq-cli.mjs"
cmd="${1:-}"
case "$cmd" in
  run)
    dir="${2:-}"
    if [ -z "$dir" ]; then echo "使い方: bash jp-language-quality-gate.sh run <project_dir>" >&2; exit 64; fi
    if [ ! -d "$dir" ]; then echo "対象のフォルダがありません: $dir" >&2; exit 2; fi
    if [ "${SOLOPTILINK_JP_LANGUAGE_QUALITY_GATE:-on}" = "off" ]; then
      mkdir -p "$dir/.soloptilink" 2>/dev/null
      printf '{"gate":"jp-language-quality-gate","verdict":"disabled","stage":"観察","block":false,"reason_ja":"kill-switch で無効化されています（合格ではありません）","produced_at_epoch":%s}\n' "$(date +%s)" > "$dir/.soloptilink/jp-language-quality.json"
      exit 0
    fi
    if ! command -v node >/dev/null 2>&1; then
      mkdir -p "$dir/.soloptilink" 2>/dev/null
      printf '{"gate":"jp-language-quality-gate","verdict":"unmeasurable","stage":"観察","block":false,"reason_ja":"node が無いため測れていません（合格ではありません）","produced_at_epoch":%s}\n' "$(date +%s)" > "$dir/.soloptilink/jp-language-quality.json"
      exit 127
    fi
    exec node "$CLI" run "$dir"
    ;;
  selftest)
    exec node "$CLI" selftest
    ;;
  *)
    echo "使い方: bash jp-language-quality-gate.sh run <project_dir> | selftest" >&2
    exit 64
    ;;
esac
