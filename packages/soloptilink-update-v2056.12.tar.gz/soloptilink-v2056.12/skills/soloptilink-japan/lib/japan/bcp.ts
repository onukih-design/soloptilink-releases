/**
 * @fileoverview Phase 12 - 事業継続計画 (BCP) DNA
 *
 * 内閣府「事業継続ガイドライン」+ ISO 22301 + 日本特有のリスクシナリオ:
 *   - 地震 (首都直下/南海トラフ/各地震動予測。想定値は 2025年の内閣府公表値・出典つき)
 *   - 津波 (東日本大震災教訓・浸水想定区域)
 *   - 豪雨/洪水 (河川氾濫・内水)
 *   - 火山噴火 (富士山降灰想定)
 *   - 台風 (停電 + 通信途絶)
 *   - パンデミック (新型インフル等対策行動計画)
 *   - サイバー攻撃 (重要インフラ事案)
 *
 * RTO/RPO/MTPD 計算 + 重要業務優先順位付け + 代替拠点設計 + 訓練計画。
 */

// ============================================================================
// Types
// ============================================================================

export type DisasterScenario =
  | 'earthquake_metropolitan'   // 首都直下地震
  | 'earthquake_nankai'         // 南海トラフ巨大地震
  | 'earthquake_regional'       // 地域地震 (内陸活断層)
  | 'tsunami'                   // 津波
  | 'flood_river'               // 河川氾濫
  | 'flood_inland'              // 内水氾濫
  | 'volcano_eruption'          // 火山噴火 (降灰)
  | 'typhoon'                   // 台風
  | 'heavy_snow'                // 豪雪
  | 'pandemic'                  // パンデミック
  | 'cyber_attack'              // サイバー攻撃
  | 'power_outage_wide'         // 広域停電
  | 'supply_chain_disruption'   // サプライチェーン途絶
  | 'pandemic_employee'         // 社員多数感染
  | 'data_center_loss';         // データセンター喪失

export interface CriticalBusinessFunction {
  /** 重要業務 ID */
  id: string;
  /** 業務名 */
  name: string;
  /** 業務概要 */
  description: string;
  /** 復旧目標時間 (時間単位) */
  rtoHours: number;
  /** 復旧目標時点 (時間単位) */
  rpoHours: number;
  /** 最大許容停止時間 (時間単位) */
  mtpdHours: number;
  /** 優先度: 1=最重要 / 2=重要 / 3=通常 */
  priority: 1 | 2 | 3;
  /** 業務担当部門 */
  ownerDepartment: string;
  /** 依存システム */
  dependsOnSystems: string[];
  /** 依存外部サービス */
  dependsOnExternalServices: string[];
}

// ============================================================================
// 災害シナリオの想定影響度 (政府の公表値。出典・基準日つき)
// ============================================================================
//
// 2026-10-01 是正（REQ-JPO-FIX-018）:
//   - 旧い値（南海トラフ 80%・32.3万人・220兆円／首都直下 2.3万人・95兆円）を 2025年の公表値へ直した。
//   - 全プロファイルに出典URL・公表日・基準日・想定の種類を必須にした。
//   - 出典の無い値（津波 20万人・パンデミック 6.4万人/30兆円・サイバー/データセンターの停止日数・
//     南海トラフ/首都直下の「業務停止 60日/30日」）は削除した。業務停止日数は国の公表値ではなく、
//     事業所ごとの被害想定で決めるもの（内閣府「事業継続ガイドライン」）なので、お客様の想定
//     （assumedDowntimeDays＋assumptionSource）が無い限り「未評価」を返す。

/** 想定値の出典（一次資料） */
export interface DisasterProfileSource {
  /** 公表資料の URL */
  url: string;
  /** 公表元 */
  publisher: string;
  /** 資料名 */
  title: string;
  /** 公表日 (YYYY-MM-DD) */
  publishedOn: string;
  /** 基準日 (YYYY-MM-DD)。想定・確率の算定の基準となる日。資料に明記が無い場合は公表日 */
  asOf: string;
  /** 想定の種類 (最大クラス・季節/時間帯・ケース 等) */
  estimateType: string;
}

export interface DisasterImpactProfile {
  scenario: DisasterScenario;
  /** 想定発生確率 (今後30年以内・%)。幅や併記がある場合は置かず probability30yText に書く */
  probability30yPct?: number;
  /** 想定発生確率の公表どおりの表記 (併記・幅を含む) */
  probability30yText?: string;
  /** 推定死者数 (直接死。災害関連死は含まない) */
  casualtiesEst?: number;
  /** 経済被害額 (兆円・資産等の被害＋経済活動への影響) */
  economicDamageTrillionYen?: number;
  /** 経済被害額 (兆円・交通寸断の影響を含む場合) */
  economicDamageInclTrafficTrillionYen?: number;
  /** 業務停止期間 (日)。出典のある公表値がある場合だけ置く。無ければ RTO 評価は「未評価」 */
  downtimeDays?: number;
  /** 通信途絶日数 (出典がある場合だけ) */
  comDowntimeDays?: number;
  /** 停電日数 (出典がある場合だけ) */
  powerOutageDays?: number;
  /** 主要対策 */
  mitigations: string[];
  /** 被害想定の出典 (必須) */
  source: DisasterProfileSource;
  /** 発生確率の出典 (被害想定と別の資料の場合) */
  probabilitySource?: DisasterProfileSource;
}

export const DISASTER_PROFILES: DisasterImpactProfile[] = [
  {
    scenario: 'earthquake_metropolitan',
    // 南関東のM7程度の地震（相模トラフ沿い）30年以内 70%程度（ポアソン過程のため基準日で変わらない）
    probability30yPct: 70,
    probability30yText: '70%程度（南関東のM7程度の地震・30年以内）',
    // 都心南部直下地震・冬・夕・風速8m/s の死者数合計 約18,000人
    casualtiesEst: 18000,
    // 資産等の被害 45.1兆円 ＋ 生産・サービス低下による影響 37.5兆円 ＝ 82.6兆円（概要は「約83兆円」）
    economicDamageTrillionYen: 82.6,
    mitigations: ['代替拠点 (関西圏推奨)', '在宅勤務体制', '重要データの遠隔バックアップ', '従業員安否確認システム'],
    source: {
      url: 'https://www.bousai.go.jp/jishin/syuto/taisaku_wg_02/pdf/r7higai_soutei1.pdf',
      publisher: '内閣府 中央防災会議 首都直下地震対策検討ワーキンググループ',
      title: '都心南部直下地震の被害想定【定量的な被害量】（報告書概要 https://www.bousai.go.jp/jishin/syuto/taisaku_wg_02/pdf/r7houkoku1.pdf）',
      publishedOn: '2025-12-19',
      asOf: '2025-12-19',
      estimateType: '都心南部直下地震（M7.3）・冬・夕・風速8m/s（死者・焼失が最大のケース）',
    },
    probabilitySource: {
      url: 'https://www.jishin.go.jp/regional_seismicity/rs_kaiko/k_sagami/',
      publisher: '地震調査研究推進本部 地震調査委員会',
      title: '相模トラフ沿いの地震活動の長期評価（第二版）／長期評価による地震発生確率値の更新',
      publishedOn: '2014-04-25',
      asOf: '2025-01-01',
      estimateType: 'プレートの沈み込みに伴うM7程度の地震（M6.7〜M7.3）・ポアソン過程',
    },
  },
  {
    scenario: 'earthquake_nankai',
    // 30年以内の発生確率は2つのモデルの併記。高い方を示すときは出典を添える（地震本部の手引き）。
    probability30yText: '60〜90%程度以上（すべり量依存BPTモデル）／20〜50%（BPTモデル）の併記・基準日2025-01-01',
    // 最大クラス・冬・深夜 の死者 最大約29.8万人（災害関連死 約2.6万〜5.2万人は含まない）
    casualtiesEst: 298000,
    // 資産等の被害 約224.9兆円 ＋ 経済活動への影響 約45.4兆円 ＝ 270.3兆円（陸側ケース）
    economicDamageTrillionYen: 270.3,
    // 交通寸断に起因するもの（道路5.2・鉄道2.7・港湾14.1兆円）を含む場合 292.3兆円
    economicDamageInclTrafficTrillionYen: 292.3,
    mitigations: ['東日本に冗長拠点', '津波浸水域からの拠点移転', '燃料・食料の3日分備蓄'],
    source: {
      url: 'https://www.bousai.go.jp/jishin/nankai/taisaku_wg_02/pdf/nankai_gaiyo.pdf',
      publisher: '内閣府 中央防災会議 南海トラフ巨大地震対策検討ワーキンググループ',
      title: '南海トラフ巨大地震対策検討ワーキンググループ報告書 概要（定量的な被害量 https://www.bousai.go.jp/jishin/nankai/taisaku_wg_02/pdf/saidai_01.pdf）',
      publishedOn: '2025-03-31',
      asOf: '2025-03-31',
      estimateType: '最大クラス地震・死者は冬・深夜、経済被害は陸側ケース',
    },
    probabilitySource: {
      url: 'https://www.jishin.go.jp/evaluation/long_term_evaluation/subduction_fault/summary_nankai/',
      publisher: '地震調査研究推進本部 地震調査委員会',
      title: '南海トラフの地震活動の長期評価（第二版一部改訂）',
      publishedOn: '2025-09-26',
      asOf: '2025-01-01',
      estimateType: '30年以内の発生確率（2モデルの併記）',
    },
  },
];

/**
 * 災害シナリオごとの主要対策（助言。数値の想定ではないので出典の対象外）。
 * プロファイル（数値の想定）が無いシナリオでも、対策の提案だけは返す。
 */
export const SCENARIO_MITIGATIONS: Partial<Record<DisasterScenario, string[]>> = {
  earthquake_metropolitan: ['代替拠点 (関西圏推奨)', '在宅勤務体制', '重要データの遠隔バックアップ', '従業員安否確認システム'],
  earthquake_nankai: ['東日本に冗長拠点', '津波浸水域からの拠点移転', '燃料・食料の3日分備蓄'],
  tsunami: ['浸水想定区域からの移転', '高所避難経路の確保', '津波警報連動の自動データ退避'],
  pandemic: ['全社在宅勤務体制', '感染症対策BCP発動基準明文化', '出社必要業務の特定と最小化'],
  cyber_attack: ['EDR/XDR導入', 'バックアップの3-2-1ルール', 'インシデント対応チーム (CSIRT)', '外部脅威インテリジェンス'],
  data_center_loss: ['マルチリージョン (Tokyo + Osaka)', 'マルチクラウド (AWS + Azure等)', 'コールドスタンバイの定期検証'],
};

// ============================================================================
// RTO/RPO 評価 + 必要対策ギャップ分析
// ============================================================================

/** RTO 評価の結果。想定停止日数の根拠が無いときは「未評価」（達成とも未達とも言わない） */
export type RecoveryGapStatus = '達成' | '未達' | '未評価';

export interface RecoveryGapAnalysis {
  function: CriticalBusinessFunction;
  scenario: DisasterScenario;
  /** 判定。想定停止日数の根拠が無ければ '未評価' */
  status: RecoveryGapStatus;
  /** 想定停止日数（根拠が無ければ null） */
  expectedDowntimeDays: number | null;
  expectedDowntimeHours: number | null;
  /** RTO を満たすか（未評価なら null。0日を仮定して true にしない） */
  meetsRTO: boolean | null;
  rtoGapHours: number | null;
  /** 想定停止日数の出どころ: 'profile'＝出典つきの公表値 / 'assumption'＝お客様の被害想定 / null＝無し */
  downtimeBasis: 'profile' | 'assumption' | null;
  /** 判定の理由（日本語） */
  reasonJa: string;
  recommendedMitigations: string[];
}

export function analyzeRecoveryGap(input: {
  function: CriticalBusinessFunction;
  scenario: DisasterScenario;
  profiles?: DisasterImpactProfile[];
  /** お客様の被害想定による停止日数（自社の想定。根拠 assumptionSource とセットで使う） */
  assumedDowntimeDays?: number;
  /** assumedDowntimeDays の根拠（自社の被害想定の資料名など）。空なら未評価 */
  assumptionSource?: string;
}): RecoveryGapAnalysis {
  const profiles = input.profiles ?? DISASTER_PROFILES;
  const profile = profiles.find((p) => p.scenario === input.scenario);
  const mitigations = profile?.mitigations ?? SCENARIO_MITIGATIONS[input.scenario] ?? [];
  const rto = input.function.rtoHours;

  let downDays: number | null = null;
  let basis: 'profile' | 'assumption' | null = null;
  const assumed = input.assumedDowntimeDays;
  const assumedOk = typeof assumed === 'number' && Number.isFinite(assumed) && assumed >= 0
    && typeof input.assumptionSource === 'string' && input.assumptionSource.trim().length > 0;
  if (assumedOk) {
    downDays = assumed as number;
    basis = 'assumption';
  } else if (
    profile && typeof profile.downtimeDays === 'number' && Number.isFinite(profile.downtimeDays)
    && profile.source && typeof profile.source.url === 'string' && profile.source.url.trim().length > 0
  ) {
    downDays = profile.downtimeDays;
    basis = 'profile';
  }

  if (downDays === null) {
    const why = typeof assumed === 'number' && !assumedOk
      ? '想定停止日数の根拠（assumptionSource）が無いため'
      : (profile ? 'このシナリオの業務停止日数に出典つきの想定値が無いため' : 'このシナリオの想定値が無いため');
    return {
      function: input.function,
      scenario: input.scenario,
      status: '未評価',
      expectedDowntimeDays: null,
      expectedDowntimeHours: null,
      meetsRTO: null,
      rtoGapHours: null,
      downtimeBasis: null,
      reasonJa: `${why}、RTO の達成・未達を判定していません（未評価）。自社の被害想定で停止日数と根拠を入れてください。`,
      recommendedMitigations: mitigations,
    };
  }

  const downHours = downDays * 24;
  const meets = downHours <= rto;
  return {
    function: input.function,
    scenario: input.scenario,
    status: meets ? '達成' : '未達',
    expectedDowntimeDays: downDays,
    expectedDowntimeHours: downHours,
    meetsRTO: meets,
    rtoGapHours: Math.max(0, downHours - rto),
    downtimeBasis: basis,
    reasonJa: meets
      ? `想定停止 ${downHours}時間 が RTO ${rto}時間 以内です。`
      : `想定停止 ${downHours}時間 が RTO ${rto}時間 を ${downHours - rto}時間 超えます。`,
    recommendedMitigations: mitigations,
  };
}

// ============================================================================
// 安否確認 + 連絡網
// ============================================================================

export interface SafetyConfirmation {
  employeeId: string;
  employeeName: string;
  status: 'safe' | 'injured' | 'cannot_contact' | 'evacuated' | 'unknown';
  location?: string;
  contactedAt: string;
  comment?: string;
}

/** 未回答者（連絡不能・未確認）の一覧の1行 */
export interface UnansweredPerson {
  employeeId: string;
  employeeName: string;
  status: 'cannot_contact' | 'unknown';
}

/**
 * 安否の集計。
 * 2026-10-01 是正（REQ-JPO-FIX-018）: 回答率は「本人から実際に回答があった人」（無事・負傷・避難）だけを
 * 分子に数える。連絡不能（cannot_contact）と未確認（unknown）は未回答として一覧に出す
 * （旧実装は連絡不能を回答済みに数え、10人中5人が連絡不能でも回答率100%になっていた）。
 */
export function summarizeSafety(confirmations: SafetyConfirmation[]): {
  total: number;
  safe: number;
  injured: number;
  cannotContact: number;
  evacuated: number;
  unknown: number;
  /** 回答があった人数（無事＋負傷＋避難） */
  responded: number;
  /** 回答率 (%・小数1桁)。対象0人のときは 0 */
  responseRate: number;
  /** 未回答者の一覧（連絡不能・未確認）。追跡の対象 */
  unanswered: UnansweredPerson[];
} {
  const total = confirmations.length;
  const safe = confirmations.filter((c) => c.status === 'safe').length;
  const injured = confirmations.filter((c) => c.status === 'injured').length;
  const cannotContact = confirmations.filter((c) => c.status === 'cannot_contact').length;
  const evacuated = confirmations.filter((c) => c.status === 'evacuated').length;
  const unknown = confirmations.filter((c) => c.status === 'unknown').length;
  const responded = safe + injured + evacuated;
  const unanswered: UnansweredPerson[] = confirmations
    .filter((c) => c.status === 'cannot_contact' || c.status === 'unknown')
    .map((c) => ({ employeeId: c.employeeId, employeeName: c.employeeName, status: c.status as 'cannot_contact' | 'unknown' }));
  return {
    total,
    safe,
    injured,
    cannotContact,
    evacuated,
    unknown,
    responded,
    responseRate: total === 0 ? 0 : Math.round((responded / total) * 1000) / 10,
    unanswered,
  };
}

// ============================================================================
// BCP 訓練計画
// ============================================================================

export type DrillType = 'tabletop' | 'walkthrough' | 'functional' | 'fullscale';

export interface BcpDrillPlan {
  drillId: string;
  scenario: DisasterScenario;
  type: DrillType;
  scheduledDate: string;
  duration: string;
  participants: string[];
  objectives: string[];
  evaluationCriteria: string[];
}

export function suggestDrillFrequency(priority: 1 | 2 | 3, type: DrillType): { perYear: number } {
  // 優先度1の業務 + 全規模訓練 = 年1回最低
  const matrix: Record<DrillType, Record<1 | 2 | 3, number>> = {
    tabletop: { 1: 4, 2: 2, 3: 1 },
    walkthrough: { 1: 2, 2: 1, 3: 0.5 },
    functional: { 1: 2, 2: 1, 3: 0 },
    fullscale: { 1: 1, 2: 0.5, 3: 0 },
  };
  return { perYear: matrix[type][priority] };
}

// ============================================================================
// 内閣府・各省庁 BCP 関連リンク
// ============================================================================

export const BCP_REFS = {
  CABINET_OFFICE_GUIDELINE: 'https://www.bousai.go.jp/kyoiku/kigyou/keizoku/sk_03.html',
  ISO22301: 'https://www.iso.org/standard/75106.html',
  CHUUKIBO_BCP: 'https://www.chusho.meti.go.jp/bcp/',
  // キー名は互換のため据え置き。NISC は 2025-07-01 に国家サイバー統括室へ改組され、
  // 旧 www.nisc.go.jp の下層ページはすべて新サイトのトップへ転送されるため、重要インフラ対策のページを直接指す
  NISC_CRITICAL_INFRA: 'https://www.cyber.go.jp/policy/group/infra/policy.html',
  PANDEMIC_PLAN: 'https://www.cas.go.jp/jp/seisaku/ful/keikaku.html',
};
