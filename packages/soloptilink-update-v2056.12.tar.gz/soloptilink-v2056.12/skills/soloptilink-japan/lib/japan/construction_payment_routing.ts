/**
 * 建設工事の下請負と、建設業者が行う委託取引の支払の規律の振り分け (建設業法 / 取適法)
 *
 * ★2026-10-03 新設 (REQ-JPO-IND-037・T08)。
 *   建設工事の再委託 (下請負) の代金は建設業法の規律で、取適法の規律 (受領日から起算して60日・手形の交付の禁止) を
 *   当てない。建設業者が行う取引でも、建設資材の製造委託・設計や工事図面の作成・販売先への運送などは取適法の対象になり得る。
 *
 * 【出典 — 一次情報 (2026-10-03 に e-Gov API v2 と公取委の Q&A で本文を確認)】
 *   - 建設業法 (324AC0000000100) 第2条4項・5項 (下請契約・元請負人・下請負人)
 *       第24条の3第1項: 元請負人は、支払を受けた日から一月以内で、かつ、できる限り短い期間内に下請代金を支払う
 *       第24条の6第1項: 特定建設業者が注文者となった下請契約 (請負人が特定建設業者又は資本金額が政令の額以上の法人を除く) は、
 *         引渡しの申出の日から起算して五十日を経過する日以前の支払期日
 *       第24条の6第3項: 支払期日までに一般の金融機関による割引を受けることが困難であると認められる手形の交付の禁止
 *   - 建設業法施行令 (331CO0000000273) 第7条の2: 第24条の6第1項の政令で定める金額は四千万円
 *   - 取適法 (331AC0000000120) 第2条4項 (建設業を営む者が業として請け負う建設工事の全部又は一部を他の建設業を営む者に
 *       請け負わせることを役務提供委託から除く)・第3条・第5条1項2号 (手形の交付は支払遅延)
 *   - 公取委 取適法Q&A Q5 (建設業者でも、建設資材の製造委託は製造委託、設計・内装設計・工事図面の作成は情報成果物作成委託、
 *       建売住宅の設計図等は情報成果物作成委託 (類型1)、販売する建設資材の販売先への運送は特定運送委託)・
 *       Q6 (ビルメンテナンス: 建設工事に当たらない部品交換等は修理委託又は役務提供委託、建設工事に当たる改修は適用なし)
 *   - 民法 第140条・第143条 (一月の期間: 初日不算入・起算日に応当する日の前日に満了・応当日が無ければその月の末日)
 *
 * 【要確認として残したもの】
 *   - 注文者が建設業を営む者でない場合 (発注者からの元請負など) は、建設業法の下請代金の規律の対象でなく、取適法の役務提供委託に
 *     当たるかも個別の判断になるため 'unconfirmed' を返す。
 *   - 手形期間が長い手形が「割引困難」に当たるかの目安 (国土交通省の通知) は一次確認をしていないため、日数の目安は出さない。
 *   - 一人親方など個人の下請負人には、フリーランス法 (特定受託事業者に係る取引の適正化等に関する法律) が重なり得る。
 *     この部品は建設業法と取適法の振り分けだけを返す。
 */
import { judgeToritekiApplicability, nthDayFrom, toYmd, addDaysYmd, TORITEKI_VALUES, type ToritekiTransactionType, type Ymd } from './toriteki';

/** 建設業法の値 (建設業法・同施行令) */
export const CONSTRUCTION_PAYMENT_VALUES = {
  /** 第24条の3第1項: 支払を受けた日から一月以内 */
  pay_after_client_payment_months: 1,
  /** 第24条の6第1項: 引渡しの申出の日から起算して五十日 */
  specific_licensee_limit_days: 50,
  /** 施行令第7条の2: 第24条の6第1項の除外となる資本金額 (以上) */
  specific_exclusion_capital_yen: 40_000_000,
  law_id: '324AC0000000100',
} as const;

export type ConstructionRelatedTransaction =
  | 'construction_work_subcontract'            // 建設工事の下請負 (再委託)
  | 'maintenance_renovation_construction'      // 建設工事に当たる改修 (Q6)
  | 'construction_material_manufacturing'      // 請け負った建設工事に使う建設資材の製造委託 (Q5: 製造委託)
  | 'construction_material_for_sale_manufacturing' // 業として販売する建設資材の製造委託 (Q5: 製造委託)
  | 'design_or_drawing'                        // 請け負った建築物の設計・内装設計・工事図面の作成 (Q5: 情報成果物作成委託)
  | 'spec_home_design'                         // 建売住宅の設計図等の作成 (Q5: 情報成果物作成委託 類型1)
  | 'material_sale_transport'                  // 販売する建設資材の販売先への運送 (Q5: 特定運送委託)
  | 'maintenance_repair_non_construction';     // 建設工事に当たらない部品交換・修理 (Q6: 修理委託)

export interface RoutingParty {
  isConstructionBusiness?: boolean;
  isSpecificLicensee?: boolean;
  capitalYen?: number | null;
  employees?: number | null;
  isIndividual?: boolean;
}
export interface RoutingInput {
  transaction: ConstructionRelatedTransaction;
  orderer: RoutingParty;
  contractor: RoutingParty;
  dates?: {
    /** 取適法: 給付を受領した日 (役務は提供を受けた日) */
    receivedAt?: string | Date;
    /** 建設業法 第24条の3: 元請負人が注文者から出来形・完成の支払を受けた日 */
    paymentReceivedFromClientAt?: string | Date;
    /** 建設業法 第24条の6: 下請負人からの引渡しの申出の日 */
    deliveryRequestAt?: string | Date;
  };
  consignedAt?: string;
}
export type PromissoryNoteRule = 'prohibited' | 'restricted_hard_to_discount' | 'not_prohibited_by_statute' | 'unconfirmed';
export interface RoutingResult {
  applicableLaw: 'construction_business_act' | 'toriteki' | 'neither' | 'unconfirmed';
  applicableLaw_ja: string;
  articles: string[];
  paymentRule_ja: string;
  /** 入力の日付から出せる最終の支払期日 (出せなければ null) */
  dueDate: Ymd | null;
  dueDateParts: Array<{ basis: string; date: Ymd }>;
  promissoryNote: PromissoryNoteRule;
  promissoryNote_ja: string;
  toritekiType?: ToritekiTransactionType;
  reasons: string[];
}

const pad2 = (n: number) => String(n).padStart(2, '0');
const dim = (y: number, m: number) => new Date(Date.UTC(y, m, 0)).getUTCDate();
/** 民法第140条・第143条: ある日の翌日から起算して n か月の期間の最終日 */
export function monthsPeriodLastDay(from: string | Date, n: number): Ymd {
  const start = addDaysYmd(toYmd(from), 1);
  const [y, m, d] = start.split('-').map(Number);
  let yy = y; let mm = m + n;
  while (mm > 12) { mm -= 12; yy++; }
  if (d > dim(yy, mm)) return `${yy}-${pad2(mm)}-${pad2(dim(yy, mm))}`;
  return addDaysYmd(`${yy}-${pad2(mm)}-${pad2(d)}`, -1);
}

const TORITEKI_TYPE: Partial<Record<ConstructionRelatedTransaction, { type: ToritekiTransactionType; label: string }>> = {
  construction_material_manufacturing: { type: 'manufacturing', label: '製造委託 (建設工事に使う建設資材の製造・公取委Q&A Q5)' },
  construction_material_for_sale_manufacturing: { type: 'manufacturing', label: '製造委託 (販売する建設資材の製造・公取委Q&A Q5)' },
  design_or_drawing: { type: 'information_product', label: '情報成果物作成委託 (設計・内装設計・工事図面の作成・公取委Q&A Q5)' },
  spec_home_design: { type: 'information_product', label: '情報成果物作成委託 (建売住宅の設計図等・公取委Q&A Q5)' },
  material_sale_transport: { type: 'specific_transport', label: '特定運送委託 (販売する建設資材の販売先への運送・公取委Q&A Q5)' },
  maintenance_repair_non_construction: { type: 'repair', label: '修理委託 (建設工事に当たらない部品交換等・公取委Q&A Q6)' },
};

export function routeConstructionPayment(input: RoutingInput): RoutingResult {
  const reasons: string[] = [];
  const dates = input.dates ?? {};
  const isWork = input.transaction === 'construction_work_subcontract' || input.transaction === 'maintenance_renovation_construction';

  if (isWork) {
    if (!input.orderer.isConstructionBusiness || !input.contractor.isConstructionBusiness) {
      reasons.push('建設業法の「下請契約」は、建設工事を請け負った建設業を営む者と他の建設業を営む者との請負契約です (第2条4項)。当事者が建設業を営む者か確認できないため、適用法を確定できません。');
      return { applicableLaw: 'unconfirmed', applicableLaw_ja: '確認できていない', articles: ['建設業法 第2条4項', '取適法 第2条4項'],
        paymentRule_ja: '当事者が建設業を営む者かを入力してください。', dueDate: null, dueDateParts: [], promissoryNote: 'unconfirmed',
        promissoryNote_ja: '確認できていません。', reasons };
    }
    reasons.push('建設工事の下請負は取適法の役務提供委託から除かれます (取適法 第2条4項)。支払は建設業法で管理します。');
    const articles = ['建設業法 第24条の3第1項 (注文者から支払を受けた日から一月以内)'];
    const parts: Array<{ basis: string; date: Ymd }> = [];
    if (dates.paymentReceivedFromClientAt) {
      parts.push({ basis: '建設業法 第24条の3第1項', date: monthsPeriodLastDay(dates.paymentReceivedFromClientAt, CONSTRUCTION_PAYMENT_VALUES.pay_after_client_payment_months) });
    }
    // 第24条の6 の対象か
    let specific: boolean | null = false;
    if (input.orderer.isSpecificLicensee) {
      if (input.contractor.isSpecificLicensee) specific = false;
      else if (input.contractor.isIndividual) specific = true;
      else if (typeof input.contractor.capitalYen === 'number') specific = input.contractor.capitalYen < CONSTRUCTION_PAYMENT_VALUES.specific_exclusion_capital_yen;
      else specific = null;
    } else if (input.orderer.isSpecificLicensee === undefined) {
      specific = null;
    }
    let promissoryNote: PromissoryNoteRule; let promissoryNote_ja: string;
    if (specific === true) {
      articles.push('建設業法 第24条の6第1項 (引渡しの申出の日から起算して50日を経過する日以前)', '建設業法 第24条の6第3項 (割引困難な手形の交付の禁止)');
      if (dates.deliveryRequestAt) parts.push({ basis: '建設業法 第24条の6第1項', date: nthDayFrom(dates.deliveryRequestAt, CONSTRUCTION_PAYMENT_VALUES.specific_licensee_limit_days) });
      promissoryNote = 'restricted_hard_to_discount';
      promissoryNote_ja = '支払期日までに一般の金融機関で割引を受けることが困難と認められる手形は交付できません (建設業法 第24条の6第3項)。電子交換所の交換廃止 (2027-03-31) にも備え、振込への切替えをおすすめします。';
    } else if (specific === false) {
      promissoryNote = 'not_prohibited_by_statute';
      promissoryNote_ja = '建設業法に手形の交付そのものを禁じる定めはありません (第24条の6 の対象外の下請契約)。労務費に相当する部分は現金で支払うよう配慮が必要です (第24条の3第2項)。電子交換所の交換廃止 (2027-03-31) にも備えてください。';
      articles.push('建設業法 第24条の3第2項 (労務費相当分は現金で支払うよう配慮)');
    } else {
      promissoryNote = 'unconfirmed';
      promissoryNote_ja = '注文者が特定建設業者か、下請負人の資本金 (4,000万円以上か) を確認できないため、第24条の6 (割引困難な手形の交付の禁止・50日) に当たるか確認できていません。';
      reasons.push('建設業法 第24条の6 に当たるかを確認できていません (注文者が特定建設業者か・下請負人が特定建設業者か資本金4,000万円以上の法人かを入力してください)。');
    }
    parts.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
    return {
      applicableLaw: 'construction_business_act', applicableLaw_ja: '建設業法', articles,
      paymentRule_ja: specific === true
        ? '建設業法により、注文者から支払を受けた日から一月以内 (第24条の3) と、引渡しの申出の日から起算して50日を経過する日以前 (第24条の6) の早い方までに支払います。'
        : '建設業法により、注文者から支払を受けた日から一月以内 (第24条の3) に支払います。',
      dueDate: parts.length ? parts[0].date : null, dueDateParts: parts, promissoryNote, promissoryNote_ja, reasons,
    };
  }

  const map = TORITEKI_TYPE[input.transaction];
  if (!map) {
    return { applicableLaw: 'unconfirmed', applicableLaw_ja: '確認できていない', articles: [], paymentRule_ja: '取引の種類を判定できません。',
      dueDate: null, dueDateParts: [], promissoryNote: 'unconfirmed', promissoryNote_ja: '確認できていません。', reasons: ['未知の取引の種類です'] };
  }
  const j = judgeToritekiApplicability({ type: map.type, consignor: input.orderer, contractor: input.contractor, consignedAt: input.consignedAt });
  reasons.push(`取引の種類: ${map.label}`, ...j.reasons);
  if (j.verdict === 'applies') {
    const due = dates.receivedAt ? nthDayFrom(dates.receivedAt, TORITEKI_VALUES.payment_limit_days) : null;
    return {
      applicableLaw: 'toriteki', applicableLaw_ja: '取適法 (中小受託取引適正化法)', toritekiType: map.type,
      articles: [`取適法 ${j.basis}`, '取適法 第3条 (受領日から起算して60日以内)', '取適法 第5条第1項第2号 (手形の交付は支払遅延)'],
      paymentRule_ja: '取適法により、受領日 (役務は提供を受けた日) を1日目として60日目までの支払期日を定めます。',
      dueDate: due, dueDateParts: due ? [{ basis: '取適法 第3条', date: due }] : [],
      promissoryNote: 'prohibited', promissoryNote_ja: '代金の支払に手形を交付することは支払遅延に当たります (取適法 第5条第1項第2号)。振込で支払期日までに満額を支払ってください。',
      reasons,
    };
  }
  if (j.verdict === 'not_applicable') {
    return {
      applicableLaw: 'neither', applicableLaw_ja: '建設業法・取適法の支払の規律の対象外', toritekiType: map.type,
      articles: [`取適法 ${j.basis}`],
      paymentRule_ja: '取適法の資本金・従業員の基準に当たらず、建設工事の下請負でもないため、両法の支払期日の上限はありません。契約で定めた支払期日を守ってください (優越的地位の濫用は独占禁止法で別に問題になり得ます)。',
      dueDate: null, dueDateParts: [], promissoryNote: 'not_prohibited_by_statute',
      promissoryNote_ja: '両法による手形の禁止はありません。電子交換所の交換廃止 (2027-03-31) に備え、振込への切替えをおすすめします。', reasons,
    };
  }
  return {
    applicableLaw: 'unconfirmed', applicableLaw_ja: '確認できていない', toritekiType: map.type, articles: ['取適法 第2条第8項・第9項'],
    paymentRule_ja: '取引先の資本金・常時使用する従業員の数が未入力のため、取適法に当たるか確認できていません。入力してから判定してください。',
    dueDate: null, dueDateParts: [], promissoryNote: 'unconfirmed', promissoryNote_ja: '確認できていません。', reasons,
  };
}
