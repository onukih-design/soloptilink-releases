/**
 * 日本語品質・感性ゲートの検査器（JPO-D05「日本語品質・感性ゲート設計書」第1.1版 の 115 規則）
 *
 * 何をするか:
 *   生成物の画面の固定文言・帳票・メールのひな形・AIの応答文を、機械で合否を出せる規則で調べ、
 *   「どこで・何が・なぜ・どう直すか」を日本語の指摘として返す。止めない（すべての規則は「観察」から始める・設計書 §7.3）。
 *
 * 規則と辞書の置き場（値は1か所）:
 *   - 規則表 lib/japan/jp-language-quality/rules.json  … 設計書 §3 の 115 規則（対象・判定方法・根拠・目標の重さ）と、
 *     本検査器で「機械」で判定するか「人の確認」に回すか（理由つき）・閾値（計画値の印つき）
 *   - 辞書   lib/japan/jp-language-quality/lexicon.json … 規則ごとの語と出典（敬語の指針・公用文作成の考え方・
 *     やさしい日本語ガイドライン・国立国語研究所「外来語」言い換え提案・校正規則・慣行）
 *   この検査器は語や閾値を書き写さず、上の2つを読む（設計書 §4.3 原則3）。
 *
 * 使う日本語部品（第2波で是正済み）:
 *   hankaku_kana.ts（半角カナの直し方の提案）・phone_jp.ts（電話番号の区切りの照合）・atena.ts（宛名の種類の判定）・
 *   wareki.ts（和暦の日付の曜日の照合）
 *
 * 形態素解析は使わない（設計書 §1.3: 応答の直前の検査は1秒以内・正規表現と辞書だけ）。形態素解析が要る規則は
 * 「人の確認（前提未整備）」として数え、無理に機械化しない。近似で判定する規則は rules.json の approx に印がある。
 *
 * 公開する口:
 *   checkText(text, opts)        … 文字列を1つの単位（1画面・1帳票・1通・1応答）として調べる
 *   checkResponse(text, opts)    … AIの応答文（コード・インラインのコード・URL・パスを除いてから調べる）。止めない
 *   checkSource(path, content)   … 生成物のソース1本（固定文言を取り出して文字列の規則に掛け、ソースの規則も見る）
 *   runPartsProbes(parts)        … 同梱の部品に検体を通す（【検】の規則）
 *   ruleCatalog() / implementedRuleIds()
 */
import RULES_TABLE from './jp-language-quality/rules.json';
import LEXICON from './jp-language-quality/lexicon.json';
import { hankakuKanaToZenkaku } from './hankaku_kana';
import { analyzeJapanesePhone } from './phone_jp';
import { inferAtenaSuffix } from './atena';
import { parseWareki } from './wareki';

export type JqTarget = '画' | '帳' | 'メ' | '応';

export interface JqOptions {
  target: JqTarget;
  /** 業種タグ（medical / care / legal / tax / construction / manufacturing / wedding / funeral など） */
  industry?: string[];
  /** 読み手（foreign = 外国人向け。やさしい日本語の規則を掛ける） */
  audience?: 'foreign' | 'general';
  /** 出力の文字コード（shift_jis のときだけ HK-11 を見る） */
  encoding?: 'shift_jis' | 'utf-8';
  /** 案件の固有名詞（漢字の連続の規則から外す） */
  properNouns?: string[];
  /** ソースの規則用: 案件の共通CSSに印刷用の指定があるか */
  projectHasPrintCss?: boolean;
  /** WB-01 の単位（line=文言1行ごと・unit=1画面のどこかに次の行動があればよい） */
  wbUnit?: 'line' | 'unit';
}

export interface JqFinding {
  rule_id: string;
  sub?: string;
  target: JqTarget | '—';
  excerpt: string;
  index: number;
  /** お客様にお見せできる1文（社内の規則番号を含めない・設計書 §7.2） */
  message_ja: string;
  why_ja: string;
  fix_ja?: string;
  /** 自動で直してよいか（設計書 §7.4。意味が変わりうるものは提案だけ） */
  auto_fix: boolean;
  severity_target: '止める' | '警告';
  stage: '観察';
  approx: boolean;
  path?: string;
}

export interface JqResult {
  findings: JqFinding[];
  counts: Record<string, number>;
  elapsed_ms?: number;
  block?: boolean;
}

interface RuleRow {
  rule_id: string; group: string; content_ja: string; targets: JqTarget[]; methods: string[]; basis_ja: string; basis_status: string;
  severity_target: '止める' | '警告'; severity_by_target?: Record<string, '止める' | '警告'> | null; stage: '観察';
  judge: '機械' | '人の確認'; human_reason?: string; human_reason_ja?: string; how?: string; probe?: string; approx?: boolean; approx_ja?: string;
  params?: Record<string, number | boolean>; exception_allowed: boolean;
}
const RULES: RuleRow[] = (RULES_TABLE as any).rules as RuleRow[];
const RULE_BY_ID: Map<string, RuleRow> = new Map(RULES.map((r) => [r.rule_id, r]));
const LEX: any = LEXICON as any;
const lex = (id: string): any => LEX[id] || {};
const param = (id: string, key: string): number => Number((RULE_BY_ID.get(id)?.params || {})[key]);

// ---------------------------------------------------------------- 文字の道具
const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
/** 辞書の語の並び（正規表現を含む語は印 re: を付けずにそのまま使う。長い語から照合） */
const alt = (words: string[], raw = false) => [...words].sort((a, b) => b.length - a.length).map((w) => (raw ? w : esc(w))).join('|');
const KANJI = '一-龥々〆ヶ';
const toHalfDigits = (s: string) => s.replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0));

interface Sentence { text: string; start: number; terminated: boolean }
/** 句点・感嘆符・疑問符・改行で文に分ける */
function splitSentences(text: string): Sentence[] {
  const out: Sentence[] = [];
  let buf = ''; let start = 0;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === '\n' || c === '\r') {
      if (buf.trim()) out.push({ text: buf, start, terminated: false });
      buf = ''; start = i + 1; continue;
    }
    buf += c;
    if ('。！？!?'.includes(c)) {
      // 閉じ括弧が続くときは文に含める
      while (i + 1 < text.length && '」』）)'.includes(text[i + 1])) { buf += text[++i]; }
      out.push({ text: buf, start, terminated: c === '。' });
      buf = ''; start = i + 1;
    }
  }
  if (buf.trim()) out.push({ text: buf, start, terminated: false });
  return out;
}
const bodyOf = (s: string) => s.replace(/\s+/g, '').replace(/[。！？!?」』）)]+$/, '');
const charLen = (s: string) => Array.from(s).length;
const sentenceLen = (s: string) => charLen(bodyOf(s));

// ---------------------------------------------------------------- 規則の実装（文字列）
type Hit = { excerpt: string; index: number; sub?: string; fix?: string; count?: number };
interface Ctx { text: string; sentences: Sentence[]; opts: JqOptions }
type TextRule = (c: Ctx) => Hit[];

function allMatches(re: RegExp, text: string): RegExpExecArray[] {
  const out: RegExpExecArray[] = [];
  const g = new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g');
  let m: RegExpExecArray | null;
  while ((m = g.exec(text))) { out.push(m); if (m[0].length === 0) g.lastIndex++; }
  return out;
}
const hitsOf = (re: RegExp, text: string, fix?: (m: RegExpExecArray) => string | undefined): Hit[] =>
  allMatches(re, text).map((m) => ({ excerpt: m[0], index: m.index, fix: fix ? fix(m) : undefined }));
const hasIndustry = (o: JqOptions, tags: string[]) => (o.industry || []).some((t) => tags.includes(t));
/** 回数の規則: 単位の中で count_min 回以上なら1件 */
const countRule = (id: string, re: RegExp, key = 'count_min'): TextRule => (c) => {
  const ms = allMatches(re, c.text);
  const min = param(id, key);
  return ms.length >= min ? [{ excerpt: ms.map((m) => m[0]).slice(0, 5).join('・'), index: ms[0].index, count: ms.length }] : [];
};

// 敬語
// 「ご（御）……される」「お……される」は尊敬語の適切な形ではない（敬語の指針 keigo2.txt 890行「御説明される」「御利用される」）
const RE_KG01 = new RegExp(`(?:${alt(lex('JQ-KG-01').double_honorific)})|お[${KANJI}][ぁ-ん]{0,2}になられ|ご[${KANJI}]{1,3}になられ|[ご御][${KANJI}]{2}され(?:る|ます|まし|た|て)|お[${KANJI}][ぁ-ん]?され(?:る|ます|まし|た|て)`);
const RE_KG02 = new RegExp(alt(lex('JQ-KG-02').humble_plus_saseteitadaku));
const RE_KG03_SELF = new RegExp(`(?:${alt(lex('JQ-KG-03').self_subjects, true)})(?:が|は|も|より)`, 'g');
const RE_KG03_RESP = new RegExp(alt(lex('JQ-KG-03').respectful_verbs, true));
const RE_KG03_OTHER = new RegExp(alt(lex('JQ-KG-03').other_party, true));
// 謙譲語Ⅰの依頼形・「お（ご）……しますか」（相手の行為を謙譲語で尋ねる。指針 889行「お持ちしますか」）・
// 不適切な敬語連結「伺ってくださる／伺っていただく」「御案内してくださる／していただく」（指針 1092〜1115行）
const RE_KG04_REQ = new RegExp(`(?:${alt(lex('JQ-KG-04').humble_request)})(?:ください|下さい)|[おご][${KANJI}]{1,3}[ぁ-ゖ]?して(?:ください|下さい)|[おご][${KANJI}]{1,3}[ぁ-ゖ]?しますか|伺って(?:くださ|いただ)|[ご御]案内して(?:くださ|いただ)`);
/** 伺う・御案内するの向かう先が立てるべき人物として明示されていれば、敬語連結は使える（指針 1100〜1110行の限られた場合） */
const RE_KG04_ELEVATED_DEST = /(先生|社長|部長|課長|会長|院長|所長|お客様|[一-龥]{1,4}様)(?:の(?:ところ|お宅|ご自宅|事務所|会社|家)[にへ]|を)/;
const RE_KG04_OTHER = new RegExp(`(?:${alt(lex('JQ-KG-04').other_subjects, true)})(?:が|は|も)([^。、\\n]{0,12}?)(?:${alt(lex('JQ-KG-04').humble_after_other)})`);
const PARTICLE_KANA = 'をがはにでとものへや';
const RE_RANUKI = new RegExp(`(?:${alt(lex('JQ-KG-10').ichidan_stems)})れ(?:る|ま|な|た|て)`);

const TEXT_RULES: Record<string, TextRule> = {
  'JQ-KG-01': (c) => hitsOf(RE_KG01, c.text, () => '尊敬語は一度だけにします（例: おっしゃられる → おっしゃる）'),
  'JQ-KG-02': (c) => hitsOf(RE_KG02, c.text, (m) => `「${m[0].replace(/させていただ|せていただ$/, '')}」の謙譲語だけにします（例: 拝見させていただきます → 拝見します）`),
  'JQ-KG-03': (c) => {
    const out: Hit[] = [];
    for (const s of c.sentences) {
      for (const m of allMatches(RE_KG03_SELF, s.text)) {
        const rest = s.text.slice(m.index + m[0].length);
        const r = rest.match(RE_KG03_RESP);
        if (!r || r.index === undefined) continue;
        const between = rest.slice(0, r.index);
        if (RE_KG03_OTHER.test(between)) continue;
        out.push({ excerpt: m[0] + rest.slice(0, r.index + r[0].length), index: s.start + m.index, fix: '自分側の行為には謙譲語を使います（例: 担当者がおっしゃいます → 担当者が申します）' });
        break;
      }
    }
    return out;
  },
  'JQ-KG-04': (c) => {
    const out: Hit[] = [];
    for (const m of allMatches(RE_KG04_REQ, c.text)) {
      const mid = m[0].match(/^[おご][一-龥々〆ヶ]{1,3}([ぁ-ゖ]?)し(?:て|ます)/);
      if (mid && mid[1] && PARTICLE_KANA.includes(mid[1])) continue;
      if (/^(伺って|[ご御]案内して)/.test(m[0])) {
        const sent = c.sentences.find((s) => m.index >= s.start && m.index < s.start + s.text.length);
        const before = sent ? c.text.slice(sent.start, m.index) : c.text.slice(0, m.index);
        if (RE_KG04_ELEVATED_DEST.test(before)) continue;
      }
      out.push({ excerpt: m[0], index: m.index, fix: '相手の行為には尊敬語を使います（例: 伺ってください → お尋ねください／ご相談してください → ご相談ください）' });
    }
    for (const m of allMatches(RE_KG04_OTHER, c.text)) {
      if (/(私|わたくし|弊社|当社|担当)/.test(m[1] || '')) continue;
      out.push({ excerpt: m[0], index: m.index, fix: '相手の行為には尊敬語を使います（例: お客様が申されました → お客様がおっしゃいました）' });
    }
    return out;
  },
  'JQ-KG-05': countRule('JQ-KG-05', /せていただ|せて頂/),
  'JQ-KG-06': (c) => hitsOf(new RegExp(alt(lex('JQ-KG-06').words)), c.text, () => '目上の方やお客様には「お疲れ様です」などを使います'),
  'JQ-KG-07': (c) => {
    const ex: string[] = lex('JQ-KG-07').greeting_exclusions;
    return allMatches(/ございま/, c.text)
      .filter((m) => !ex.some((g) => c.text.slice(Math.max(0, m.index - g.length + 4), m.index + 4).endsWith(g)))
      .map((m) => ({ excerpt: c.text.slice(Math.max(0, m.index - 6), m.index + 5), index: m.index, fix: '画面の文末は「です・ます」にします（例: 一覧でございます → 一覧です）' }));
  },
  'JQ-KG-08': countRule('JQ-KG-08', /おりま|いたしま/),
  'JQ-KG-09': (c) => {
    const polite = /(?:です|ます|ました|でした|ません|ましょう|ください|下さい|でしょう|ませんか|ますか|ですか|ませんでした)$/;
    const plain = /(?:だ|である|だった|ない|なかった|[^ま]した|[^まで]た|[うくすつぬむるぐぶ])$/;
    let p = 0; const plains: Sentence[] = [];
    for (const s of c.sentences) {
      if (!s.terminated) continue;
      const b = bodyOf(s.text);
      if (polite.test(b)) p++;
      else if (plain.test(b)) plains.push(s);
    }
    return p > 0 && plains.length > 0 ? [{ excerpt: plains[0].text.trim(), index: plains[0].start, fix: '同じ画面・文書では「です・ます」か「だ・である」のどちらかにそろえます' }] : [];
  },
  'JQ-KG-10': (c) => hitsOf(RE_RANUKI, c.text, (m) => `「${m[0].replace(/れ(.)$/, 'られ$1')}」と書きます（ら抜き言葉）`),
  // 宛名・敬称
  'JQ-AT-01': (c) => hitsOf(new RegExp(`(?:${alt(lex('JQ-AT-01').titles)})[\\s　]*(?:様|殿)(?![式子々相態])|各位[\\s　]*(?:様|殿)`), c.text,
    () => '役職名や「各位」には敬称を重ねません（例: 山田部長様 → 営業部長 山田太郎様）'),
  'JQ-AT-02': (c) => {
    const out: Hit[] = [];
    for (const m of allMatches(/御中/, c.text)) {
      const before = c.text.slice(0, m.index);
      const cut = Math.max(before.lastIndexOf('\n'), before.lastIndexOf('、'), before.lastIndexOf('。'), before.lastIndexOf('「'));
      const seg = before.slice(cut + 1).trim();
      const tokens = seg.split(/[\s　]+/).filter(Boolean);
      if (tokens.length < 2) continue;
      if (inferAtenaSuffix(seg) !== '様') continue; // 宛名の部品で「個人宛て」と判定されたものだけ
      out.push({ excerpt: `${seg} 御中`, index: m.index - seg.length, fix: `個人宛てには「様」を使います（例: ${seg} 様）` });
    }
    return out;
  },
  'JQ-AT-03': (c) => hitsOf(/御中[\s　]*(?:[^\s　、。\n]{0,15}[\s　]*)?様(?![式子々相態])/, c.text, () => '「御中」と「様」は併用しません。個人宛てなら「様」だけにします'),
  'JQ-AT-04': (c) => hitsOf(new RegExp(`(?:${alt(lex('JQ-AT-04').self)})(?:様|御中|殿)(?![式子々相態])`), c.text, () => '自社には敬称を付けません（例: 弊社様 → 弊社）'),
  'JQ-AT-05': (c) => hitsOf(/[\s　](?:行|宛て|宛)[\s　]*$/m, c.text, () => '発行する帳票の宛先には「行」「宛」を残さず、「様」「御中」に直します'),
  'JQ-AT-06': (c) => hitsOf(/御社/, c.text, () => '書面・メールでは「貴社」と書きます'),
  'JQ-AT-07': (c) => hitsOf(new RegExp(alt(lex('JQ-AT-07').abbrev)), c.text, () => '宛名の法人格は略さず「株式会社」「有限会社」と書きます'),
  // 謝り方・断り方・エラー
  'JQ-WB-01': (c) => {
    const err = new RegExp(alt(lex('JQ-WB-01').error_words)); const act = new RegExp(alt(lex('JQ-WB-01').action_words));
    const isMsg = (l: string) => { const t = l.trim(); return !/^\[[^\]]+\]/.test(t) && charLen(t) >= 6 && /(。|した|ません|です|でした|ない)$/.test(t.replace(/[。！？!?]+$/, (m) => (m.includes('。') ? '。' : ''))); };
    const out: Hit[] = []; let pos = 0;
    if (c.opts.wbUnit === 'unit' && act.test(c.text)) return out; // 1画面の中に次の行動（ボタン・案内）がある
    for (const line of c.text.split('\n')) {
      if (err.test(line) && isMsg(line) && !act.test(line)) out.push({ excerpt: line.trim().slice(0, 60), index: pos, fix: '何が起きたかに続けて、次にすること（例: 時間をおいてもう一度お試しください）を書きます' });
      pos += line.length + 1;
    }
    return out;
  },
  'JQ-WB-02': (c) => {
    const toks: string[] = lex('JQ-WB-02').raw_tokens;
    const words = toks.filter((t) => /^[A-Za-z]+$/.test(t)); const others = toks.filter((t) => !/^[A-Za-z]+$/.test(t));
    const re = new RegExp(`(?<![A-Za-z])(?:${alt(words)})(?![A-Za-z])|${alt(others)}`);
    return hitsOf(re, c.text, () => '英語のエラーや技術語は表示せず、何が起きたかと次にすることを日本語で書きます');
  },
  'JQ-WB-03': (c) => hitsOf(new RegExp(alt(lex('JQ-WB-03').blame)), c.text, () => '利用者を責めず、正しい入れ方を示します（例: 半角数字7桁で入力してください）'),
  'JQ-WB-04': countRule('JQ-WB-04', new RegExp(alt(lex('JQ-WB-04').apologies))),
  'JQ-WB-05': (c) => {
    const first = c.sentences[0];
    if (!first) return [];
    const b = bodyOf(first.text);
    const onlyApology = /^(?:大変|誠に|まことに|本当に)?(?:申し訳(?:ございません|ありません)(?:でした)?|すみません(?:でした)?|すいません(?:でした)?|(?:大変)?失礼いたしました|ご迷惑をおかけ(?:して)?(?:しまい)?(?:申し訳ございません|いたしました|しました)?)$/.test(b);
    if (!onlyApology) return [];
    const second = c.sentences[1];
    const ev = new RegExp(alt(lex('JQ-WB-05').event_words));
    if (second && ev.test(second.text)) return [];
    return [{ excerpt: first.text.trim(), index: first.start, fix: '謝罪だけで始めず、何が起きたかを先に書きます' }];
  },
  'JQ-WB-06': (c) => {
    const re = new RegExp(alt(lex('JQ-WB-06').cushions), 'g'); const min = param('JQ-WB-06', 'per_sentence_min');
    return c.sentences.filter((s) => allMatches(re, s.text).length >= min).map((s) => ({ excerpt: s.text.trim(), index: s.start, fix: 'クッション言葉は1文に1つにします' }));
  },
  'JQ-WB-07': (c) => {
    const out: Hit[] = []; let pos = 0;
    for (const line of c.text.split('\n')) {
      const confirm = /(削除|取り消|取消|消去)/.test(line) && /(よろしいですか|しますか|ますか|？|\?)/.test(line);
      if (confirm) {
        const undo = /(元に戻せ|取り消せ|復元|戻すことはできません|戻せません|元に戻す|戻せます|取り消すことはできません)/.test(line);
        const name = /(「[^」]+」|『[^』]+』|\$\{[^}]+\}|\{[^}]+\}|%s|\{\{)/.test(line);
        if (!undo || !name) out.push({ excerpt: line.trim().slice(0, 60), index: pos, fix: '何を消すのか（対象の名前）と、元に戻せるかどうかを書きます' });
      }
      pos += line.length + 1;
    }
    return out;
  },
  // 翻訳調・AIの応答
  'JQ-HY-01': (c) => hitsOf(/あなた/, c.text, () => '「お客様」「貴社」など、相手に合わせた呼び方にします'),
  'JQ-HY-02': countRule('JQ-HY-02', /ことができ/),
  'JQ-HY-03': (c) => hitsOf(/を可能にし|を可能にさせ|あなたに[^。、\n]{0,20}させ/, c.text, () => '人を主語にして書きます（例: この機能は効率化を可能にします → この機能で効率よく作業できます）'),
  'JQ-HY-05': (c) => hitsOf(new RegExp(`${alt(lex('JQ-HY-05').marks)}|${alt(lex('JQ-HY-05').hype)}`), c.text, () => '業務の文書では感嘆符や誇張した言葉を使わず、事実を書きます'),
  'JQ-HY-06': (c) => {
    const allow = new Set((lex('JQ-HY-06').allow as string[]).map((w) => w.toLowerCase()));
    const cleaned = c.text.replace(/https?:\/\/\S+/g, ' ').replace(/[\w.+-]+@[\w-]+\.[\w.]+/g, ' ').replace(/\S*\/\S*/g, ' ').replace(/\$?\{[^}]*\}/g, ' ');
    const min = param('JQ-HY-06', 'min_letters');
    const pn = (c.opts.properNouns || []).map((w) => w.toLowerCase());
    return allMatches(new RegExp(`[A-Za-z]{${min},}`), cleaned).filter((m) => !allow.has(m[0].toLowerCase()) && !/^[A-Z]+$/.test(m[0]) && !/[A-Za-z]/.test(cleaned[m.index + m[0].length] || '')
      && !pn.some((w) => w.includes(m[0].toLowerCase())))
      .map((m) => ({ excerpt: m[0], index: m.index, fix: '画面のラベルやボタンは日本語にします（例: Submit → 送信する）' }));
  },
  'JQ-HY-07': (c) => {
    // コードの塊・インラインのコード・URL・パスは数えない（設計書 §1.2）
    const t = c.text.replace(/```[\s\S]*?```/g, '').replace(/`[^`\n]*`/g, '').replace(/https?:\/\/\S+/g, '').replace(/\S*\/\S*/g, '').replace(/\s+/g, '');
    const total = charLen(t);
    if (total < 20) return [];
    const jp = (t.match(/[　-〿぀-ヿ㐀-鿿＀-￯々〆ヶ]/g) || []).length;
    const ratio = param('JQ-HY-07', 'ja_ratio_min');
    return jp * 1000 < total * Math.round(ratio * 1000) ? [{ excerpt: `日本語の割合 ${Math.round((jp / total) * 100)}%`, index: 0, fix: '応答の本文は日本語で書き、技術語は最小限にします' }] : [];
  },
  'JQ-HY-09': (c) => {
    const min = param('JQ-HY-09', 'per_paragraph_min'); const out: Hit[] = []; let pos = 0;
    for (const para of c.text.split(/\n\s*\n/)) {
      const ms = allMatches(/(?<!お)(?:これ|それ)(?:[がをはにもの]|で(?!は|も)|ら)/, para);
      if (ms.length >= min) out.push({ excerpt: ms.map((m) => m[0]).join('・'), index: pos + ms[0].index, count: ms.length, fix: '「これ」「それ」が何を指すかを、名前で書きます' });
      pos += para.length + 2;
    }
    return out;
  },
  'JQ-HY-10': countRule('JQ-HY-10', new RegExp(alt(lex('JQ-HY-10').weak))),
  // 公用文・分かりやすさ
  'JQ-KY-01': (c) => {
    const max = c.opts.target === '応' ? param('JQ-KY-01', 'max_chars_response') : param('JQ-KY-01', 'max_chars');
    return c.sentences.filter((s) => sentenceLen(s.text) > max).map((s) => ({ excerpt: s.text.trim().slice(0, 40) + '…', index: s.start, sub: `${sentenceLen(s.text)}字`, fix: `一文を${max}字以内に分けます` }));
  },
  'JQ-KY-02': (c) => {
    const max = param('JQ-KY-02', 'max_ten');
    return c.sentences.filter((s) => (s.text.match(/[、，]/g) || []).length > max).map((s) => ({ excerpt: s.text.trim().slice(0, 40), index: s.start, fix: '読点が多い文は分けます' }));
  },
  'JQ-KY-03': (c) => {
    const max = param('JQ-KY-03', 'max_kanji_run'); const out: Hit[] = [];
    for (const m of allMatches(new RegExp(`[${KANJI}]{${max + 1},}`), c.text)) {
      let run = m[0];
      if (/(法|法律|令|規則|条例|告示|省令|政令|規程)$/.test(run)) continue;
      if (/[都道府県].*[市区町村郡]/.test(run)) continue;
      for (const pn of c.opts.properNouns || []) run = run.split(pn).join('・');
      if (!new RegExp(`[${KANJI}]{${max + 1},}`).test(run)) continue;
      out.push({ excerpt: m[0], index: m.index, fix: '漢字が続く語は、助詞を入れて分けます（例: 顧客管理業務一覧 → 顧客の管理業務の一覧）' });
    }
    return out;
  },
  'JQ-KY-04': (c) => hitsOf(new RegExp(alt(lex('JQ-KY-04').patterns)), c.text, () => '二重否定を使わず、肯定の形で書きます（例: …しないわけではない → …することもある）'),
  'JQ-KY-05': (c) => {
    const items: Array<{ w: string; r: string }> = lex('JQ-KY-05').stiff;
    return hitsOf(new RegExp(alt(items.map((x) => x.w))), c.text, (m) => { const it = items.find((x) => x.w === m[0]); return it ? `「${it.r}」と書きます` : undefined; });
  },
  'JQ-KY-08': (c) => (c.opts.audience === 'foreign' ? yasashiiHits(c) : []),
  // カタカナ語・用語
  'JQ-KT-01': (c) => {
    const allowKt = new Set<string>(lex('JQ-KT-01').allow || []);
    const words: Array<{ word: string; replace: string }> = (lex('JQ-KT-01').words as Array<{ word: string; replace: string }>).filter((w) => !allowKt.has(w.word));
    const norm = (w: string) => w.replace(/ー$/, '');
    const map = new Map(words.map((w) => [norm(w.word), w]));
    return allMatches(/[ァ-ヶー]+/, c.text).filter((m) => map.has(norm(m[0])))
      .map((m) => ({ excerpt: m[0], index: m.index, fix: `分かりやすい言葉に言い換えます（例: ${map.get(norm(m[0]))!.replace}）` }));
  },
  'JQ-KT-02': (c) => {
    const toks = allMatches(/[ァ-ヶー]+/, c.text);
    const set = new Set(toks.map((m) => m[0]));
    const seen = new Set<string>(); const out: Hit[] = [];
    for (const m of toks) {
      const w = m[0];
      if (w.endsWith('ー') || charLen(w) < 3 || seen.has(w)) continue;
      if (set.has(w + 'ー')) { seen.add(w); out.push({ excerpt: `${w}ー／${w}`, index: m.index, fix: `「${w}ー」か「${w}」のどちらかにそろえます` }); }
    }
    return out;
  },
  'JQ-KT-03': (c) => {
    const out: Hit[] = [];
    for (const g of lex('JQ-KT-03').synonym_groups as string[][]) {
      const present = g.filter((w) => c.text.includes(w));
      if (present.length >= 2) out.push({ excerpt: present.join('／'), index: c.text.indexOf(present[1]), fix: `同じものは同じ言葉（例: ${g[0]}）にそろえます` });
    }
    return out;
  },
  // 文字・数字の表記
  'JQ-HK-01': (c) => hitsOf(/[･-ﾟ]+/, c.text, (m) => `全角にします（${hankakuKanaToZenkaku(m[0])}）`),
  'JQ-HK-02': (c) => hitsOf(/[ぁ-ゖァ-ヺヽ-ヿ][゛゜゙゚]/, c.text, (m) => `濁点・半濁点を合わせた1文字にします（${m[0].normalize('NFKC').normalize('NFC')}）`),
  'JQ-HK-04': (c) => (/[0-9]/.test(c.text) && /[０-９]/.test(c.text) ? [{ excerpt: (c.text.match(/[０-９]+/) || [''])[0], index: c.text.search(/[０-９]/), fix: '数字は半角にそろえます' }] : []),
  'JQ-HK-05': (c) => {
    const out: Hit[] = [];
    if (c.text.includes('、') && c.text.includes('，')) out.push({ excerpt: '、と，', index: c.text.indexOf('，'), fix: '読点は「、」か「，」のどちらかにそろえます' });
    if (c.text.includes('。') && c.text.includes('．')) out.push({ excerpt: '。と．', index: c.text.indexOf('．'), fix: '句点は「。」にそろえます' });
    return out;
  },
  'JQ-HK-06': (c) => hitsOf(/(?<![0-9,，.万億兆])[0-9]{4,}(?=円)|[¥￥][0-9]{4,}(?![0-9,])/, toHalfDigitsKeepLen(c.text), (m) => `三桁ごとにコンマで区切ります（${Number(m[0].replace(/[^0-9]/g, '')).toLocaleString('ja-JP')}）`),
  'JQ-HK-08': (c) => allMatches(/(?<![0-9,])([0-9][0-9,]*)(万|億)/, c.text).filter((m) => Number(m[1].replace(/,/g, '')) >= 10000)
    .map((m) => ({ excerpt: m[0], index: m.index, fix: '万・億の前は4桁までにし、上の位は漢字にします（例: 12,000万円 → 1億2,000万円）' })),
  'JQ-HK-09': (c) => {
    const kinds = new Set<string>();
    if (/(?<![0-9A-Za-z\-])[-−－]\s?[¥￥]?[0-9][0-9,]*(?:\.[0-9]+)?\s?円|[¥￥]\s?[-−－][0-9]/.test(c.text)) kinds.add('-');
    if (/▲\s?[¥￥]?[0-9]/.test(c.text)) kinds.add('▲');
    if (/△\s?[¥￥]?[0-9]/.test(c.text)) kinds.add('△');
    return kinds.size >= 2 ? [{ excerpt: [...kinds].join('と'), index: 0, fix: '負の数の書き方を1つ（例: △）にそろえます' }] : [];
  },
  'JQ-HK-10': (c) => hitsOf(new RegExp(alt(lex('JQ-HK-10').words)), c.text, (m) => `語の一部の数は漢数字で書きます（${m[0].replace(/1/g, '一').replace(/2/g, '二').replace(/3/g, '三').replace(/7/g, '七')}）`),
  'JQ-HK-11': (c) => {
    if (c.opts.encoding !== 'shift_jis') return [];
    const set = sjisSet();
    if (!set) return [];
    const out: Hit[] = []; let i = 0;
    for (const ch of Array.from(c.text)) {
      if (!/[\s]/.test(ch) && ch.charCodeAt(0) > 0x7e && !set.has(ch)) out.push({ excerpt: ch, index: i, fix: 'Shift_JIS で書き出せない文字です。別の書き方（例: ㋿ → 令和）にします' });
      i += ch.length;
    }
    return out;
  },
  'JQ-HK-12': (c) => {
    const out: Hit[] = [];
    // 画面のソースは差し込み（{…}）で文字が分かれるため、開きと閉じの数は数えず、全角と半角の混在だけを見る
    if (c.opts.wbUnit !== 'unit') for (const [o, cl] of [['（', '）'], ['「', '」'], ['『', '』'], ['【', '】'], ['(', ')']]) {
      const a = c.text.split(o).length - 1; const b = c.text.split(cl).length - 1;
      if (a !== b) out.push({ excerpt: `${o}${a}個・${cl}${b}個`, index: Math.max(c.text.indexOf(o), 0), fix: '括弧の開きと閉じを対にします' });
    }
    if (/[（）]/.test(c.text) && /[()]/.test(c.text)) out.push({ excerpt: '（）と()', index: c.text.search(/[()]/), fix: '括弧は全角か半角のどちらかにそろえます' });
    return out;
  },
  'JQ-HK-13': (c) => (/[0-9０-９][0-9０-９,，]*円/.test(c.text) && /[¥￥]\s?[0-9０-９]/.test(c.text) ? [{ excerpt: '円と¥', index: c.text.search(/[¥￥]/), fix: '通貨の書き方を「円」か「¥」のどちらかにそろえます' }] : []),
  // 日付・暦
  'JQ-DT-01': (c) => {
    const out: Hit[] = []; const t = toHalfDigitsKeepLen(c.text); const W = '日月火水木金土';
    const check = (y: number, mo: number, d: number, wd: string, m: RegExpExecArray) => {
      const dt = new Date(Date.UTC(y, mo - 1, d));
      if (dt.getUTCMonth() !== mo - 1) return; // 実在しない日付は DT-04 の範囲
      const real = W[dt.getUTCDay()];
      if (real !== wd) out.push({ excerpt: m[0], index: m.index, fix: `曜日は「${real}」です` });
    };
    for (const m of allMatches(/(\d{4})年(\d{1,2})月(\d{1,2})日\s*[（(]([月火水木金土日])(?:曜日?)?[)）]/, t)) check(+m[1], +m[2], +m[3], m[4], m);
    for (const m of allMatches(/(\d{4})[/.\-](\d{1,2})[/.\-](\d{1,2})\s*[（(]([月火水木金土日])(?:曜日?)?[)）]/, t)) check(+m[1], +m[2], +m[3], m[4], m);
    for (const m of allMatches(/(令和|平成|昭和|大正|明治)(元|\d{1,2})年(\d{1,2})月(\d{1,2})日\s*[（(]([月火水木金土日])(?:曜日?)?[)）]/, t)) {
      const r: any = parseWareki(`${m[1]}${m[2]}年${m[3]}月${m[4]}日`);
      if (!r || !r.ok || !r.ymd) continue;
      const [y, mo, d] = String(r.ymd).split('-').map(Number);
      check(y, mo, d, m[5], m);
    }
    return out;
  },
  'JQ-DT-02': (c) => hitsOf(/(令和|平成|昭和|大正|明治)[1１](?![0-9０-９])\s*年/, c.text, (m) => `「${m[1]}元年」と書きます`),
  'JQ-DT-06': (c) => {
    const kinds = [/(?:19|20)\d{2}\/\d{1,2}\/\d{1,2}(?!\d)/, /\d{4}年\d{1,2}月\d{1,2}日/, /(?:19|20)\d{2}-\d{1,2}-\d{1,2}(?!\d)/].filter((re) => re.test(c.text));
    return kinds.length >= 2 ? [{ excerpt: '日付の書式が混在', index: 0, fix: '同じ画面では日付の書式を1つにそろえます' }] : [];
  },
  'JQ-DT-08': (c) => {
    const out: Hit[] = hitsOf(/午[前後]\s*(?:12|１２)\s*時/, c.text, () => '「正午」「午前0時」など、取り違えない書き方にします');
    if (/午[前後]/.test(c.text) && /(?<![0-9])(?:1[3-9]|2[0-3])(?::[0-5][0-9]|時)/.test(c.text)) out.push({ excerpt: '午前・午後と24時間表記', index: 0, fix: '12時間表記か24時間表記のどちらかにそろえます' });
    return out;
  },
  // 氏名・振り仮名・住所・電話・郵便
  'JQ-NM-07': (c) => {
    const out: Hit[] = [];
    for (const m of allMatches(/(?<![0-9\-‐－])0\d{0,4}[-‐－ー]\d{1,4}[-‐－ー]\d{3,5}(?![0-9\-‐－])/, toHalfDigitsKeepLen(c.text))) {
      const digits = m[0].replace(/[^0-9]/g, '');
      const a = analyzeJapanesePhone(digits);
      if (!a.ok) continue; // 部品が区切れない番号は判定しない
      if (a.formatted !== m[0].replace(/[‐－ー]/g, '-')) out.push({ excerpt: m[0], index: m.index, fix: `${a.formatted}（総務省の市外局番の一覧による区切り）` });
    }
    return out;
  },
  // 業種の言葉づかい
  'JQ-GY-01': (c) => (hasIndustry(c.opts, ['medical', 'hospital', 'clinic']) ? hitsOf(new RegExp(alt(lex('JQ-GY-01').medical.avoid)), c.text, () => lex('JQ-GY-01').medical.prefer) : []),
  'JQ-GY-02': (c) => {
    if (!hasIndustry(c.opts, ['care', 'nursing', 'medical', 'hospital', 'clinic'])) return [];
    const ex: string[] = lex('JQ-GY-02').exclude;
    return allMatches(/[一-龥ぁ-んァ-ヶ]{1,6}ちゃん/, c.text).filter((m) => !ex.some((w) => m[0].endsWith(w)) && c.text[m.index + m[0].length] !== 'と')
      .map((m) => ({ excerpt: m[0], index: m.index, fix: '利用者は「〇〇さん」「〇〇様」とお呼びします（事業所の規程を優先）' }));
  },
  'JQ-GY-03': (c) => (hasIndustry(c.opts, ['legal', 'tax', 'labor', 'professional', 'shigyo', 'accounting-firm']) ? hitsOf(new RegExp(alt(lex('JQ-GY-03').assertions)), c.text, () => '法律・税務の判断は断定せず、資格のある専門家の確認につなぎます') : []),
  'JQ-GY-04': (c) => hitsOf(new RegExp(alt(lex('JQ-GY-04').claims)), c.text, () => '効能や治療の結果を断定しません（薬機法・医療法の広告の規制）'),
  'JQ-GY-05': (c) => (/(税抜|税別)/.test(c.text) && !/税込/.test(c.text) ? [{ excerpt: (c.text.match(/[^\s、。]*(税抜|税別)[^\s、。]*/) || [''])[0], index: c.text.search(/税抜|税別/), fix: '消費者向けの価格は税込みの総額を表示します（消費税法第63条）' }] : []),
  'JQ-GY-06': (c) => {
    if (c.opts.audience !== 'foreign' || !hasIndustry(c.opts, ['construction', 'manufacturing', 'care', 'nursing'])) return [];
    if (!new RegExp(`[${KANJI}]`).test(c.text)) return [];
    const furi = /<ruby>|[一-龥々][(（][ぁ-ん]+[)）]/.test(c.text);
    return furi ? [] : [{ excerpt: c.text.slice(0, 30), index: 0, fix: '外国人向けの画面には、ふりがなを付けます' }];
  },
  // 文化・縁起・文書の作法
  'JQ-BK-01': (c) => (hasIndustry(c.opts, ['wedding', 'bridal']) ? hitsOf(new RegExp(alt(lex('JQ-BK-01').words)), c.text, () => '慶事の文面では避ける言葉です。言い換えます（例: 終わります → お開きといたします）') : []),
  'JQ-BK-02': (c) => (hasIndustry(c.opts, ['funeral']) ? hitsOf(new RegExp(alt(lex('JQ-BK-02').words)), c.text, () => '弔事の文面では重ね言葉や直接的な表現を避けます（例: 死亡 → ご逝去）') : []),
  'JQ-BK-04': (c) => {
    const pairs: Record<string, string[]> = lex('JQ-BK-04').pairs;
    const openRe = new RegExp(`^[\\s　]*(${Object.keys(pairs).join('|')})`, 'm');
    const o = c.text.match(openRe);
    if (!o) return [];
    const closings = [...new Set(Object.values(pairs).flat())];
    const cl = allMatches(new RegExp(closings.join('|')), c.text).pop();
    if (!cl) return [];
    return pairs[o[1]].includes(cl[0]) ? [] : [{ excerpt: `${o[1]}…${cl[0]}`, index: cl.index, fix: `「${o[1]}」には「${pairs[o[1]][0]}」を合わせます` }];
  },
};

/** 全角数字を半角にする（文字の位置は変えない） */
function toHalfDigitsKeepLen(s: string): string { return toHalfDigits(s); }

let SJIS: Set<string> | null | undefined;
/** WHATWG の shift_jis（Windows-31J 相当）で表せる文字の集合を、復号表から作る */
function sjisSet(): Set<string> | null {
  if (SJIS !== undefined) return SJIS;
  try {
    const dec = new TextDecoder('shift_jis', { fatal: true });
    const set = new Set<string>();
    for (let b = 0xa1; b <= 0xdf; b++) set.add(dec.decode(new Uint8Array([b])));
    for (let lead = 0x81; lead <= 0xfc; lead++) {
      if (lead > 0x9f && lead < 0xe0) continue;
      for (let tr = 0x40; tr <= 0xfc; tr++) {
        if (tr === 0x7f) continue;
        try { set.add(dec.decode(new Uint8Array([lead, tr]))); } catch { /* 未定義の符号 */ }
      }
    }
    SJIS = set;
  } catch { SJIS = null; }
  return SJIS;
}

// やさしい日本語（KY-08）の下位規則
function yasashiiHits(c: Ctx): Hit[] {
  const L = lex('JQ-KY-08');
  const out: Hit[] = [];
  const raw = c.text;
  // ふりがな: ruby は付いているものとして扱い、漢字の後ろの（よみ）を確かめる
  const noRuby = raw.replace(/<ruby>[\s\S]*?<\/ruby>/g, 'ル');
  const kanjiRuns = allMatches(/[一-龥々〆ヶ]+/, noRuby);
  const bare = kanjiRuns.filter((m) => !/^[(（][ぁ-ゖー]+[)）]/.test(noRuby.slice(m.index + m[0].length)));
  if (bare.length) out.push({ sub: 'ふりがな', excerpt: bare.slice(0, 3).map((m) => m[0]).join('・'), index: bare[0].index, count: bare.length, fix: 'すべての漢字にふりがなを付けます（例: 住民税(じゅうみんぜい)）' });
  // ここから先は読み（ふりがな）を外した文で見る
  const plain = raw.replace(/<ruby>([\s\S]*?)<rt>[\s\S]*?<\/rt><\/ruby>/g, '$1').replace(/<[^>]+>/g, '').replace(/([一-龥々〆ヶ])[(（][ぁ-ゖー]+[)）]/g, '$1');
  const resp = /いらっしゃ|おっしゃ|召し上が|ご覧|なさい|なさる|くださいませ|お越し|お[一-龥]{1,2}[ぁ-ん]?にな/;
  const humb = /伺|参り|参ります|申し(?!込)|いたし|拝見|拝読|存じ|承|お[一-龥]{1,2}[ぁ-ん]?いただ|ご[一-龥]{2}いただ/;
  const r1 = plain.match(resp); if (r1) out.push({ sub: '尊敬語', excerpt: r1[0], index: r1.index || 0, fix: '尊敬語を使わず、丁寧語（です・ます）だけにします' });
  const r2 = plain.match(humb); if (r2) out.push({ sub: '謙譲語', excerpt: r2[0], index: r2.index || 0, fix: '謙譲語を使わず、丁寧語（です・ます）だけにします' });
  const neg = plain.match(new RegExp(alt(lex('JQ-KY-04').patterns))); if (neg) out.push({ sub: '二重否定', excerpt: neg[0], index: neg.index || 0, fix: '二重否定を使いません' });
  const g = plain.match(new RegExp(alt(L.guess))); if (g) out.push({ sub: '推測', excerpt: g[0], index: g.index || 0, fix: '推測の言い方を避け、言い切ります' });
  const wave = plain.match(/[～〜]/); if (wave) out.push({ sub: '波線', excerpt: wave[0], index: wave.index || 0, fix: '「～」を使わず「から…まで」と書きます' });
  const sl = plain.match(/\d{1,4}\/\d{1,2}(?:\/\d{1,2})?/); if (sl) out.push({ sub: '斜線の日付', excerpt: sl[0], index: sl.index || 0, fix: '年月日に「/」を使わず「2026年6月4日」と書きます' });
  const era = plain.match(new RegExp(alt(L.era))); if (era) out.push({ sub: '元号', excerpt: era[0], index: era.index || 0, fix: '元号ではなく西暦で書きます' });
  const max = param('JQ-KY-08', 'max_chars');
  for (const s of splitSentences(plain)) if (sentenceLen(s.text) > max) { out.push({ sub: '文の長さ', excerpt: s.text.slice(0, 30) + '…', index: s.start, fix: `一文を短くします（${max}字以内・計画値）` }); break; }
  const allowKt = new Set<string>(lex('JQ-KT-01').allow || []);
  const words: Array<{ word: string; replace: string }> = (lex('JQ-KT-01').words as Array<{ word: string; replace: string }>).filter((w) => !allowKt.has(w.word));
  const wset = new Map(words.map((w) => [w.word.replace(/ー$/, ''), w]));
  const lw = allMatches(/[ァ-ヶー]+/, plain).find((m) => wset.has(m[0].replace(/ー$/, '')));
  if (lw) out.push({ sub: '外来語', excerpt: lw[0], index: lw.index, fix: `外来語を使わず言い換えます（例: ${wset.get(lw[0].replace(/ー$/, ''))!.replace}）` });
  const politeEnd = /(?:です|ます|ました|でした|ません|ましょう|ください|ませんか|ますか|ですか|ませんでした)$/;
  const bad = splitSentences(plain).find((s) => s.terminated && !politeEnd.test(bodyOf(s.text)));
  if (bad) out.push({ sub: '文末', excerpt: bad.text.trim(), index: bad.start, fix: '文末は「です」「ます」にそろえます' });
  return out;
}

// ---------------------------------------------------------------- 単位の検査
function toFinding(rid: string, h: Hit, target: JqTarget | '—'): JqFinding {
  const r = RULE_BY_ID.get(rid)!;
  const sev = (r.severity_by_target && target !== '—' && r.severity_by_target[target]) || r.severity_target;
  const what = r.content_ja.replace(/（[^）]*）/g, '').replace(/。.*$/, '');
  return {
    rule_id: rid, sub: h.sub, target, excerpt: h.excerpt, index: h.index,
    message_ja: `「${h.excerpt.slice(0, 40)}」— ${what}${h.count ? `（${h.count}回）` : ''}。${h.fix ? h.fix : ''}`.replace(/JQ-[A-Z]{2}-\d{2}/g, ''),
    why_ja: r.basis_ja, fix_ja: h.fix, auto_fix: AUTO_FIX.has(rid), severity_target: sev, stage: '観察', approx: !!r.approx,
  };
}
/** 自動で直してよい規則（意味が変わらない・設計書 §7.4） */
const AUTO_FIX = new Set(['JQ-HK-01', 'JQ-HK-02', 'JQ-NM-07', 'JQ-NM-09', 'JQ-HK-05', 'JQ-HK-06', 'JQ-MI-10']);

export function checkText(text: string, opts: JqOptions): JqResult {
  const t = String(text ?? '');
  const ctx: Ctx = { text: t, sentences: splitSentences(t), opts };
  const findings: JqFinding[] = [];
  const counts: Record<string, number> = {};
  for (const [rid, fn] of Object.entries(TEXT_RULES)) {
    const r = RULE_BY_ID.get(rid);
    if (!r || r.judge !== '機械' || !r.targets.includes(opts.target)) continue;
    const hs = fn(ctx);
    if (!hs.length) continue;
    counts[rid] = hs.length;
    for (const h of hs) findings.push(toFinding(rid, h, opts.target));
  }
  return { findings, counts };
}

/** AIの応答文の検査（設計書 §1.3 C・§8.2）。コードの塊・インラインのコード・URL・パスを除く。止めない */
export function checkResponse(text: string, opts: Partial<JqOptions> = {}): JqResult {
  const t0 = Date.now();
  const cleaned = String(text ?? '')
    .replace(/```[\s\S]*?```/g, '\n')
    .replace(/`[^`\n]*`/g, ' ')
    .replace(/https?:\/\/\S+/g, ' ')
    .replace(/(?:~|\.{1,2})?\/[\w.\-/@]+/g, ' ');
  const res = checkText(cleaned, { ...opts, target: '応' } as JqOptions);
  return { ...res, elapsed_ms: Date.now() - t0, block: false };
}

// ---------------------------------------------------------------- ソース
/** コメントを外し、文字列リテラルを取り出す（JS/TS/JSX 用の簡単な字句解析） */
export function scanSource(content: string): { code: string; strings: Array<{ value: string; index: number }> } {
  let code = ''; const strings: Array<{ value: string; index: number }> = [];
  let i = 0; const n = content.length;
  while (i < n) {
    const c = content[i]; const d = content[i + 1];
    if (c === '/' && d === '/') { while (i < n && content[i] !== '\n') i++; continue; }
    if (c === '/' && d === '*') { i += 2; while (i < n && !(content[i] === '*' && content[i + 1] === '/')) i++; i += 2; continue; }
    if (c === '<' && content.startsWith('<!--', i)) { const e = content.indexOf('-->', i); i = e < 0 ? n : e + 3; continue; }
    if (c === '"' || c === "'" || c === '`') {
      const q = c; let j = i + 1; let v = '';
      const ESC: Record<string, string> = { n: '\n', t: ' ', r: '', '0': '' };
      while (j < n && content[j] !== q) {
        if (content[j] === '\\' && j + 1 < n) { const e = content[j + 1]; v += e in ESC ? ESC[e] : e; j += 2; continue; }
        if (q !== '`' && content[j] === '\n') break;
        if (q === '`' && content[j] === '$' && content[j + 1] === '{') {
          // 差し込み（式）は中身を読まず ${…} にまとめる（入れ子の波括弧を数える）
          let depth = 1; j += 2;
          while (j < n && depth > 0) { if (content[j] === '{') depth++; else if (content[j] === '}') depth--; j++; }
          v += '${…}'; continue;
        }
        v += content[j]; j++;
      }
      strings.push({ value: v, index: i });
      code += q + v + q; i = j + 1; continue;
    }
    code += c; i++;
  }
  return { code, strings };
}
const JA = /[ぁ-ゖァ-ヺ一-龥々〆ヶ]/;
/** JSX の文字（タグとタグの間の文字） */
function jsxTexts(code: string): Array<{ value: string; index: number }> {
  // 直前が識別子の「<」は型引数（useRef<any>・Attributes<HTMLButtonElement>）なのでタグに数えない
  return allMatches(/(?<![\w$.])<\/?[A-Za-z][\w.:-]*(?:\s[^<>]*?)?\/?>([^<>{}]+)(?=<|\{)/, code)
    .map((m) => ({ value: m[1].replace(/\s+/g, ' ').trim(), index: m.index + m[0].length - m[1].length }))
    .filter((x) => x.value && /[A-Za-zぁ-ゖァ-ヺ一-龥]/.test(x.value))
    // 型引数（useRef<any>(null)）や属性の中の矢印関数をタグと取り違えた断片は、画面の文字ではないので外す
    .filter((x) => !/=>|[;=]|^\(|\.\w+\(|[A-Za-z_$][\w$]*\(/.test(x.value));
}
const ATTR_RE = /\b(?:placeholder|title|label|alt|aria-label|aria-description)\s*=\s*["']([^"']+)["']/;
const isMarkup = (path: string) => /\.(tsx|jsx|vue|html|svelte|astro)$/.test(path);
export function inferTarget(path: string): JqTarget {
  if (/(invoice|receipt|estimate|quotation|quote|delivery|print|pdf|report|seikyu|mitsumori|ryoshu|請求|見積|領収|納品|帳票|送付)/i.test(path)) return '帳';
  if (/(mail|email|メール|notification|notify|letter|reminder|tokusoku|督促)/i.test(path)) return 'メ';
  return '画';
}

type SourceRule = (path: string, code: string, raw: string, opts: Partial<JqOptions>) => Hit[];
const SOURCE_RULES: Record<string, SourceRule> = {
  'JQ-KT-04': (_p, code) => allMatches(/<(button|Button)\b[^>]*>([\s\S]*?)<\/\1>/, code)
    .filter((m) => /^(OK|ＯＫ|ok|はい|いいえ|Yes|No|YES|NO)$/.test(m[2].replace(/<[^>]+>|\{[^}]*\}/g, '').trim()))
    .map((m) => ({ excerpt: m[0].slice(0, 60), index: m.index, fix: '押すと何が起きるかが分かる名前にします（例: OK → 保存する）' })),
  'JQ-KT-05': (_p, code) => {
    const labels = allMatches(/<(button|Button)\b[^>]*>([\s\S]*?)<\/\1>/, code).map((m) => m[2].replace(/<[^>]+>|\{[^}]*\}/g, '').trim()).filter((s) => JA.test(s));
    const cls = new Set(labels.map((s) => (/(します|ます)$/.test(s) ? 'ます' : /[うくすつぬむるぐぶ]$/.test(s) ? '動詞' : '名詞')));
    return cls.size >= 2 ? [{ excerpt: labels.slice(0, 4).join('・'), index: 0, fix: 'ボタン名の語形をそろえます（例: 保存する・登録する）' }] : [];
  },
  'JQ-KT-03': () => [], // 文字列の規則（checkText）で見る
  'JQ-DT-07': (path, code, raw) => {
    const out: Hit[] = [];
    for (const m of allMatches(/\[([^\[\]]{0,4000})\]/, code)) {
      const dates = m[1].match(/["'`](?:\d{4}-)?\d{2}-\d{2}["'`]/g) || [];
      if (dates.length < 3) continue;
      const ctxText = path + code.slice(Math.max(0, m.index - 200), m.index) + raw.slice(Math.max(0, raw.indexOf(m[0].slice(0, 30)) - 200), Math.max(0, raw.indexOf(m[0].slice(0, 30))));
      if (/holiday|shukujitsu|syukujitsu|kyujitsu|祝日|休日/i.test(ctxText)) out.push({ excerpt: m[0].slice(0, 60), index: m.index, fix: '祝日は固定の表で持たず、内閣府の祝日CSVを元にした暦の部品を使います' });
    }
    return out;
  },
  'JQ-NM-03': (_p, code) => {
    const name = /name=["'](?:name|fullName|customerName|氏名)["']|placeholder=["'][^"']*(?:氏名|お名前|顧客名)/.test(code);
    const sort = /sort\(|orderBy|localeCompare|並べ替え|五十音|search|検索/.test(code);
    const kana = /kana|Kana|furigana|Furigana|yomi|ふりがな|フリガナ|カナ/.test(code);
    return name && sort && !kana ? [{ excerpt: '氏名の欄と並べ替え・検索', index: 0, fix: '読み順で並べ替えるため、振り仮名の欄を足します' }] : [];
  },
  'JQ-NM-04': (_p, code) => {
    const out: Hit[] = []; const min = param('JQ-NM-04', 'min_maxlength');
    for (const m of allMatches(/<(?:input|Input)\b[^>]*>/, code)) {
      const nm = (m[0].match(/name=["'{]+([^"'}]+)/) || [])[1] || '';
      const isName = /^(lastName|firstName|familyName|givenName|name|fullName|sei|mei|氏名|姓|名前)$/.test(nm);
      const ml = m[0].match(/maxLength=\{?["']?(\d+)/);
      if (isName && ml && Number(ml[1]) < min) out.push({ excerpt: m[0].slice(0, 60), index: m.index, fix: `氏名の欄の文字数の上限を${min}字以上にします` });
      if (/^(firstName|givenName|mei)$/.test(nm) && /\brequired\b/.test(m[0])) out.push({ excerpt: m[0].slice(0, 60), index: m.index, fix: '名の欄は必須にしません（名の無い方・外国人の氏名に配慮）' });
    }
    return out;
  },
  'JQ-NM-06': (_p, code) => {
    const out: Hit[] = [];
    const ph = code.match(/placeholder=["'](?:Taro|Hanako|Ichiro|Jiro|Saburo)\s+[A-Z][a-z]+["']/);
    if (ph) out.push({ excerpt: ph[0], index: ph.index || 0, fix: 'ローマ字は「姓→名」（例: YAMADA Taro）を既定にします（関係府省庁申合せ 令和元年10月25日）' });
    const f = code.search(/first(?:Name)?(?:Romaji|En|Roman|Alphabet)|given(?:Name)?(?:Romaji|En)/);
    const l = code.search(/last(?:Name)?(?:Romaji|En|Roman|Alphabet)|family(?:Name)?(?:Romaji|En)/);
    if (f >= 0 && l >= 0 && f < l) out.push({ excerpt: 'ローマ字の欄が名→姓の順', index: f, fix: 'ローマ字の欄は姓を先に置きます' });
    return out;
  },
  'JQ-NM-11': (_p, code) => {
    const addr = /name=["'](?:address|addr|address1|addressLine1|住所)["']|placeholder=["'][^"']*住所/.test(code);
    const bld = /building|address2|addressLine2|建物|部屋|マンション|room/i.test(code);
    return addr && !bld ? [{ excerpt: '住所の欄', index: 0, fix: '建物名・部屋番号の欄を足し、帳票の宛名に出せるようにします' }] : [];
  },
  'JQ-NM-12': (_p, code) => hitsOf(new RegExp(alt(lex('JQ-NM-12').external_hosts)), code, () => '郵便番号や住所を外部のサービスへ送らず、端末の中の住所データで引きます'),
  'JQ-OP-01': (_p, code) => {
    const out: Hit[] = [];
    for (const m of allMatches(/key\s*===?\s*["']Enter["']|keyCode\s*===?\s*13|which\s*===?\s*13/, code)) {
      const win = code.slice(Math.max(0, m.index - 400), m.index + 400);
      if (!/isComposing|keyCode\s*===?\s*229|which\s*===?\s*229|composition/i.test(win)) out.push({ excerpt: code.slice(Math.max(0, m.index - 20), m.index + 30), index: m.index, fix: '変換中（isComposing）のEnterでは送信しないようにします' });
    }
    return out;
  },
  'JQ-OP-04': (path, code, _raw, opts) => {
    if (!/(invoice|receipt|estimate|quotation|quote|delivery|print|report|seikyu|mitsumori|ryoshu|請求|見積|領収|納品|帳票|控え)/i.test(path)) return [];
    if (opts.projectHasPrintCss || /@media\s+print|\bprint:/.test(code)) return [];
    return [{ excerpt: path, index: 0, fix: '印刷用の体裁（@media print や print: の指定）を用意し、A4で崩れないようにします' }];
  },
  'JQ-MI-10': (_p, code) => allMatches(/<html\b([^>]*)>/, code).filter((m) => !/lang=\{?["']ja/.test(m[1]))
    .map((m) => ({ excerpt: m[0], index: m.index, fix: '<html lang="ja"> にします' })),
  'JQ-MI-12': (_p, code) => (/<table\b/i.test(code) && !/<th\b|<TableHead\b|role=["']columnheader/.test(code) ? [{ excerpt: '<table>', index: code.search(/<table\b/i), fix: '一覧の表に見出しのセル（th）を置きます' }] : []),
  'JQ-BK-03': (_p, code, _raw, opts) => {
    if ((opts.industry || []).some((t) => ['funeral', 'wedding', 'bridal', 'ceremony'].includes(t))) return [];
    if (!/(大安|仏滅|友引|先勝|先負|赤口|rokuyo|Rokuyo|六曜)/.test(code)) return [];
    const m = code.match(/(?:showRokuyo|rokuyo|Rokuyo|displayRokuyo|六曜表示)[^;\n]{0,40}?(?:true|useState\(\s*true)/);
    return m ? [{ excerpt: m[0].slice(0, 60), index: m.index || 0, fix: '六曜の表示は既定で「表示しない」にし、設定で選べるようにします' }] : [];
  },
};

export function checkSource(path: string, content: string, opts: Partial<JqOptions> = {}): JqResult {
  const { code, strings } = scanSource(String(content ?? ''));
  const target = (opts.target as JqTarget) || inferTarget(path);
  const findings: JqFinding[] = []; const counts: Record<string, number> = {};
  // ソースの規則
  for (const [rid, fn] of Object.entries(SOURCE_RULES)) {
    const r = RULE_BY_ID.get(rid);
    if (!r || r.judge !== '機械') continue;
    const hs = fn(path, code, String(content ?? ''), opts);
    if (!hs.length) continue;
    counts[rid] = (counts[rid] || 0) + hs.length;
    for (const h of hs) findings.push({ ...toFinding(rid, h, '—'), path });
  }
  // 画面の固定文言（日本語を含む文字列・JSX の文字・属性の文言）を取り出して文字列の規則へ
  const ui: string[] = [];
  const raw = String(content ?? '');
  for (const s of strings) {
    if (!JA.test(s.value)) continue;
    // 記録用の出力（console.log・logger）の文言は画面に出ないので外す
    if (/(?:console\.(?:log|error|warn|info|debug)|logger\.\w+)\s*\(\s*$/.test(raw.slice(Math.max(0, s.index - 60), s.index))) continue;
    ui.push(s.value.replace(/^\s*\[[^\]\n]{1,30}\]\s*/, ''));
  }
  if (isMarkup(path)) for (const t of jsxTexts(code)) ui.push(t.value);
  for (const m of allMatches(ATTR_RE, code)) if (!JA.test(m[1])) ui.push(m[1]);
  if (ui.length) {
    // 画面（tsx/jsx/vue/html）は1画面を1つの単位に、それ以外（.ts の文面の定義など）は文字列1つを1つの文書として調べる
    const units = isMarkup(path) ? [ui.join('\n')] : ui;
    for (const u of units) {
      // .ts などに置いた文面は、中身からメール・契約書の文面かを見分ける（ファイル名だけでは分からない）
      const t = isMarkup(path) || opts.target ? target : (/(件名|お世話になっております|拝啓|敬具|各位)/.test(u) ? 'メ' : /第[0-9０-９一二三四五六七八九十]+条/.test(u) ? '帳' : target);
      const res = checkText(u, { ...opts, target: t, wbUnit: isMarkup(path) ? 'unit' : 'line' } as JqOptions);
      for (const f of res.findings) findings.push({ ...f, path });
      for (const [k, v] of Object.entries(res.counts)) counts[k] = (counts[k] || 0) + v;
    }
  }
  return { findings, counts };
}

// ---------------------------------------------------------------- 部品検体（【検】）
export interface PartsInput {
  keigoFns?: Array<{ label: string; fn: (t: string) => string }>;
  honorificFns?: Array<{ label: string; fn: (name: string, kind: 'person' | 'org') => string }>;
  yenShortFns?: Array<{ label: string; fn: (n: number) => string }>;
  warekiFns?: Array<{ label: string; fn: (ymd: string) => { era: string; year: number } | undefined }>;
  warekiParseFns?: Array<{ label: string; fn: (s: string) => { ok: boolean } }>;
  normalizeFns?: Array<{ label: string; fn: (s: string) => string }>;
  rewriteFns?: Array<{ label: string; fn: (s: string) => string }>;
  phoneFns?: Array<{ label: string; fn: (s: string) => string }>;
}
export interface ProbeResult { rule_id: string; probe: string; label: string; ok: boolean | null; cases: number; failures: Array<{ input: string; got: string; expect: string }>; note_ja?: string }

type Case<I> = { input: I; check: (got: any) => boolean; expect: string };
function runCases<I>(rid: string, probe: string, fns: Array<{ label: string; fn: (x: any, y?: any) => any }> | undefined, cases: Case<I>[], call: (fn: any, i: I) => any): ProbeResult[] {
  if (!fns || !fns.length) return [{ rule_id: rid, probe, label: '—', ok: null, cases: 0, failures: [], note_ja: '部品が無いため未測定（合格ではありません）' }];
  return fns.map(({ label, fn }) => {
    const failures: ProbeResult['failures'] = [];
    for (const c of cases) {
      let got: any;
      try { got = call(fn, c.input); } catch (e: any) { got = `例外: ${String(e && e.message || e).slice(0, 80)}`; }
      let ok = false; try { ok = c.check(got); } catch { ok = false; }
      if (!ok) failures.push({ input: JSON.stringify(c.input), got: typeof got === 'string' ? got : JSON.stringify(got), expect: c.expect });
    }
    return { rule_id: rid, probe, label, ok: failures.length === 0, cases: cases.length, failures };
  });
}
const HONS = /(様|御中|殿|各位)$/;
export function runPartsProbes(parts: PartsInput): ProbeResult[] {
  const out: ProbeResult[] = [];
  // KG-12 敬語の部品が原文を壊さない（要件 REQ-JPO-FIX-006 の4例ほか）
  const broken = /ございますございます|いたすため|私がおっしゃ|存じます人|かしこまりましたです|ですです|ますます。$/;
  out.push(...runCases('JQ-KG-12', 'keigo', parts.keigoFns, [
    ...['ありがとうございます。', '資料を確認します。', 'お世話になっております。', 'かしこまりました。'].map((s) => ({ input: s, check: (g: string) => g === s, expect: '丁寧な文はそのまま返す' })),
    ...['確認するため連絡します。', '私が言う。', 'そう思う人がいます。'].map((s) => ({ input: s, check: (g: string) => typeof g === 'string' && g.length > 0 && !broken.test(g), expect: '原文を壊さない' })),
  ], (fn, i) => fn(i)));
  // AT-08 敬称を重ねない
  const tailCount = (s: string) => { let n = 0; let t = String(s).trim(); while (HONS.test(t)) { n++; t = t.replace(HONS, '').trim(); } return n; };
  out.push(...runCases('JQ-AT-08', 'atena', parts.honorificFns, [
    { input: ['山田様', 'person'] as [string, 'person' | 'org'], check: (g: string) => tailCount(g) === 1, expect: '敬称は1つ' },
    { input: ['山田 様', 'person'] as [string, 'person' | 'org'], check: (g: string) => tailCount(g) === 1, expect: '敬称は1つ' },
    { input: ['株式会社ABC御中', 'org'] as [string, 'person' | 'org'], check: (g: string) => tailCount(g) === 1, expect: '敬称は1つ' },
    { input: ['株式会社ABC 御中', 'org'] as [string, 'person' | 'org'], check: (g: string) => tailCount(g) === 1, expect: '敬称は1つ' },
    { input: ['関係者各位', 'person'] as [string, 'person' | 'org'], check: (g: string) => /各位$/.test(String(g).trim()) && tailCount(g) === 1, expect: '各位に敬称を足さない' },
    { input: ['山田太郎', 'person'] as [string, 'person' | 'org'], check: (g: string) => /様$/.test(String(g).trim()) && tailCount(g) === 1, expect: '個人は様' },
    { input: ['株式会社ABC', 'org'] as [string, 'person' | 'org'], check: (g: string) => /御中$/.test(String(g).trim()) && tailCount(g) === 1, expect: '会社は御中' },
  ], (fn, i) => fn(i[0], i[1])));
  // HK-07 万・億の短縮表示（要件 REQ-JPO-LNG-009 の例）
  out.push(...runCases('JQ-HK-07', 'yenShort', parts.yenShortFns, [
    { input: 15000, check: (g: string) => String(g).replace(/\s/g, '') === '1.5万円', expect: '1.5万円' },
    { input: 123456789, check: (g: string) => String(g).replace(/\s/g, '') === '1億2,346万円', expect: '1億2,346万円' },
  ], (fn, i) => fn(i)));
  // DT-03 改元の境目（元号を改める政令）
  out.push(...runCases('JQ-DT-03', 'wareki-boundary', parts.warekiFns, [
    { input: '2019-04-30', check: (g: any) => g && g.era === '平成' && g.year === 31, expect: '平成31年' },
    { input: '2019-05-01', check: (g: any) => g && g.era === '令和' && g.year === 1, expect: '令和元年' },
    { input: '1989-01-07', check: (g: any) => g && g.era === '昭和' && g.year === 64, expect: '昭和64年' },
    { input: '1989-01-08', check: (g: any) => g && g.era === '平成' && g.year === 1, expect: '平成元年' },
  ], (fn, i) => fn(i)));
  // DT-04 存在しない和暦の日付を受け付けない
  out.push(...runCases('JQ-DT-04', 'wareki-parse', parts.warekiParseFns, [
    { input: '令和元年4月1日', check: (g: any) => g && g.ok === false, expect: '受け付けない（令和は5月1日から）' },
    { input: '令和6年2月30日', check: (g: any) => g && g.ok === false, expect: '受け付けない（2月30日は無い）' },
    { input: '令和元年5月1日', check: (g: any) => g && g.ok === true, expect: '受け付ける' },
    { input: '平成31年4月30日', check: (g: any) => g && g.ok === true, expect: '受け付ける' },
  ], (fn, i) => fn(i)));
  // NM-05 外字・異体字を黙って置き換えない
  out.push(...runCases('JQ-NM-05', 'gaiji-roundtrip', parts.normalizeFns,
    ['髙橋', '山﨑', '𠮷野', '葛\u{E0100}城'].map((s) => ({ input: s, check: (g: string) => g === s, expect: 'そのまま' })), (fn, i) => fn(i)));
  // GY-07 現場用語を一般語に置き換えない
  out.push(...runCases('JQ-GY-07', 'site-terms', parts.rewriteFns,
    ['養生をお願いします。', '手元を呼んでください。', '墨出しをします。', '段取りを確認します。'].map((s) => ({ input: s, check: (g: string) => g === s, expect: 'そのまま' })), (fn, i) => fn(i)));
  // NM-07 電話番号の部品の区切り（総務省「市外局番の一覧」令和8年3月1日現在）
  out.push(...runCases('JQ-NM-07', 'phone', parts.phoneFns, [
    { input: '0312345678', check: (g: string) => g === '03-1234-5678', expect: '03-1234-5678（東京23区・市内局番4桁）' },
    { input: '0422123456', check: (g: string) => g === '0422-12-3456', expect: '0422-12-3456（武蔵野・市内局番2桁）' },
    { input: '0111234567', check: (g: string) => g === '011-123-4567', expect: '011-123-4567（札幌・市内局番3桁）' },
  ], (fn, i) => fn(i)));
  return out;
}

// ---------------------------------------------------------------- 集計
export function implementedRuleIds(): string[] {
  const probeIds = ['JQ-KG-12', 'JQ-AT-08', 'JQ-HK-07', 'JQ-DT-03', 'JQ-DT-04', 'JQ-NM-05', 'JQ-GY-07'];
  return [...new Set([...Object.keys(TEXT_RULES), ...Object.keys(SOURCE_RULES), ...probeIds])].sort();
}
export function ruleCatalog() {
  const machine = RULES.filter((r) => r.judge === '機械').length;
  const by: Record<string, number> = {};
  for (const r of RULES) if (r.judge === '人の確認') by[r.human_reason || '—'] = (by[r.human_reason || '—'] || 0) + 1;
  return {
    total: RULES.length, machine, human: RULES.length - machine, human_by_reason: by,
    machine_approx: RULES.filter((r) => r.judge === '機械' && r.approx).length,
    stage: '観察', note_ja: '機械で判定しない規則は「人の確認」として数える（画面実測・前提未整備・判断）。合否を機械で出したことにはしない',
  };
}
export const JQ_RULES = RULES;
