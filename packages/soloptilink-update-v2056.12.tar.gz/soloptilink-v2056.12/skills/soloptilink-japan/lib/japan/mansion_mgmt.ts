/**
 * mansion_mgmt.ts — Phase 25 マンション管理
 *
 * カバレッジ:
 *   - 区分所有法 (建物の区分所有等に関する法律)
 *   - マンション管理適正化法 (R2 改正: 管理計画認定制度)
 *   - マンション建替え円滑化法 (老朽化マンション特措)
 *   - 標準管理規約 (国土交通省)
 *   - 長期修繕計画 (30年/12年大規模修繕周期)
 *   - 修繕積立金 (専有面積×単価方式 ガイドライン R3)
 *   - 総会決議要件 (2026-04-01 改正: 出席者の多数決。普通決議=出席者の過半数/特別決議=定足数+出席者の4分の3/
 *     共用部分の変更の2/3特例/建替え5分の4・客観的事由で4分の3。2026-03-31 までに招集手続を開始した集会は改正前の規律)
 *   - 管理業務主任者 + マンション管理士
 *   - 滞納督促 (5年消滅時効/弁護士法72条 非弁行為)
 *
 * 主要 export:
 *   - RESOLUTION_THRESHOLDS / classifyResolutionType / canPassResolution
 *   - LONG_TERM_REPAIR_CYCLES / buildLongTermRepairPlan
 *   - REPAIR_FUND_GUIDE_R3 / calcRecommendedRepairFundJpyPerM2Month
 *   - MANAGEMENT_PLAN_CERT_CRITERIA / canCertifyManagementPlan
 *   - DELINQUENCY_PROCEDURES / nextDelinquencyAction
 *   - MANAGER_QUALIFICATIONS / requireManagerQualification
 *   - REBUILD_CONSENT_THRESHOLD / canRebuildAged
 */

import delinquencyLadder from './delinquency_ladder.json';

// ===== 区分所有法 — 決議要件 =====
//
// ★2026-10-04 e-Gov 法令API v2 で現行 (2026-04-01 施行・令和7年法律第47号) と改正前 (2025-05-30 版) の
//   17・18・31・39・47・58・61・62・64条の5〜8 と改正法附則2条2項の本文を取得して突合した (検体 jpo-T30-condo-egov)。
//   突合で足りなかった点を足した: 規約で定める割合 (17条1項の3/4を1/2超まで引下げ・定足数の引上げ・改正前17条1項ただし書の
//   区分所有者の定数の過半数までの引下げ) と、建物敷地売却 (64条の6)・建物取壊し敷地売却 (64条の7) の
//   「敷地利用権の持分の価格の各4/5」。
// 出典 (所管官庁の公表資料。2026-10-01 確認):
//   法務省民事局「区分所有法・被災区分所有法の改正について」(令和8年4月) https://www.moj.go.jp/content/001460460.pdf
//   改正法: 老朽化マンション等の管理及び再生の円滑化等を図るための建物の区分所有等に関する法律の一部を改正する法律
//           (令和7年法律第47号)。施行日 2026-04-01。
//   ・建替えなど区分所有権の処分を伴う決議を除き、決議は【出席者】の多数決 (17条1項・39条1項ほか)。
//     出席者には議決権行使書・委任状 (書面・代理人・電磁的方法) で議決権を行使した者を含む。
//   ・特別決議 (規約の設定・変更・廃止=31条1項、共用部分の変更=17条1項、管理組合法人の設立=47条、
//     使用禁止請求=58条2項 など) は、区分所有者と議決権の【各過半数が出席】(定足数) し、出席者とその議決権の各3/4以上。
//     定足数の「過半数」は半数ちょうどを含まない。
//   ・共用部分の変更は、設置・保存の瑕疵による権利侵害のおそれ、またはバリアフリー化のためなら各2/3以上 (17条5項)。
//     復旧決議も2/3 (61条5項)。共用部分の変更の割合は規約で過半数まで下げられる (改正後は人数・議決権とも)。
//   ・建替え (62条) は【全区分所有者 (裁判所が認定した所在等不明区分所有者を除く)】が母数で各4/5以上。
//     耐震性不足・火災安全性不足・外壁等の剥落・給排水管の腐食等・バリアフリー不適合のいずれかなら各3/4以上 (62条2項)。
//   ・経過措置 (改正法附則2条2項): 2026-03-31 までに【招集手続が開始された】集会は改正前の規律による
//     (改正前は全区分所有者が母数・普通決議は総数の過半数・特別決議は総数の3/4・建替えは4/5・2/3と3/4の特例なし)。
//   ★e-Gov 法令検索は確認時に保守中で条文本文を開けていない。附則の細部・規約で定める定足数の扱いは要一次確認。
//   ★個別の議案の決議区分の当てはめ (どの工事が17条5項に当たるか等) は、マンション管理士・弁護士の確認を推奨する。

/** 改正区分所有法の集会の規律が始まる日 (この日以後に招集手続を開始した集会に適用) */
export const KUBUN_AMENDMENT_EFFECTIVE_DATE = '2026-04-01';

export type ResolutionKind =
  | 'ordinary' // 普通決議 (出席者の各過半数)
  | 'special_3_4' // 特別決議 3/4 (定足数あり・出席者の各3/4)
  | 'common_change_2_3' // 共用部分の変更の2/3特例 (17条5項) / 復旧 (61条5項)
  | 'rebuild_4_5' // 建替え 4/5 (全区分所有者が母数)
  | 'rebuild_3_4' // 建替え 3/4 (62条2項の客観的事由)
  | 'demolition_4_5' // 建物の取壊し等の再生決議 4/5
  | 'demolition_3_4' // 同 客観的事由があるとき 3/4
  ;

/** 母数: 出席者 (書面・代理・電磁的方法を含む) か、全区分所有者 (所在等不明区分所有者を除く) か */
export type ResolutionDenominator = 'attendees' | 'all_owners_excluding_missing';

export interface ResolutionThreshold {
  kind: ResolutionKind;
  ownersThreshold: number; // 区分所有者数の比率 (表示用。判定は num/den の整数比較)
  votesThreshold: number; // 議決権の比率 (表示用)
  /** 割合の分子・分母 */
  num: number;
  den: number;
  /** true = 「過半数」(ちょうどの割合を含まない) / false = 「以上」 */
  strict: boolean;
  denominator: ResolutionDenominator;
  /** 定足数 (区分所有者と議決権の各過半数の出席) が要るか */
  quorum: boolean;
  basis: string;
  examples: string[];
}

const th = (
  kind: ResolutionKind, num: number, den: number, strict: boolean,
  denominator: ResolutionDenominator, quorum: boolean, basis: string, examples: string[],
): ResolutionThreshold => ({
  kind, ownersThreshold: num / den, votesThreshold: num / den, num, den, strict, denominator, quorum, basis, examples,
});

/** 改正後 (2026-04-01 以後に招集手続を開始した集会) の決議要件 */
export const RESOLUTION_THRESHOLDS: Record<ResolutionKind, ResolutionThreshold> = {
  ordinary: th('ordinary', 1, 2, true, 'attendees', false, '区分所有法39条1項 (出席者の各過半数。規約で別段の定め可)', ['通常の管理事項', '理事選任', '通常の修繕']),
  special_3_4: th('special_3_4', 3, 4, false, 'attendees', true, '区分所有法17条1項・31条1項・47条・58条2項 (各過半数の出席+出席者の各3/4以上)', ['規約の変更', '共用部分の変更 (形状・効用の著しい変更)', '管理組合法人の設立', '使用禁止請求']),
  common_change_2_3: th('common_change_2_3', 2, 3, false, 'attendees', true, '区分所有法17条5項 (瑕疵による権利侵害のおそれ・バリアフリー化) / 61条5項 (復旧)', ['倒壊のおそれのある立体駐車場の撤去', '階段しかない建物へのエレベーター設置', '大規模滅失の復旧']),
  rebuild_4_5: th('rebuild_4_5', 4, 5, false, 'all_owners_excluding_missing', false, '区分所有法62条1項 (全区分所有者 (所在等不明を除く) の各4/5以上)', ['マンション建替え (62条)']),
  rebuild_3_4: th('rebuild_3_4', 3, 4, false, 'all_owners_excluding_missing', false, '区分所有法62条2項 (耐震・火災・外壁剥落・給排水管・バリアフリーの客観的事由で各3/4以上)', ['耐震性不足の建物の建替え']),
  demolition_4_5: th('demolition_4_5', 4, 5, false, 'all_owners_excluding_missing', false, '改正区分所有法 建物の取壊し等の再生決議 (各4/5以上)', ['建物の取壊し', '建物敷地売却', '一棟リノベーション']),
  demolition_3_4: th('demolition_3_4', 3, 4, false, 'all_owners_excluding_missing', false, '改正区分所有法 再生決議 (客観的事由があるとき各3/4以上)', ['耐震性不足の建物の取壊し']),
};

/** 改正前 (2026-03-31 までに招集手続を開始した集会) の決議要件。母数は全区分所有者。2/3 と 3/4 の特例は無い */
export const RESOLUTION_THRESHOLDS_BEFORE_AMENDMENT: Record<'ordinary' | 'special_3_4' | 'rebuild_4_5', ResolutionThreshold> = {
  ordinary: th('ordinary', 1, 2, true, 'all_owners_excluding_missing', false, '改正前 区分所有法39条1項 (区分所有者及び議決権の各過半数)', ['通常の管理事項']),
  special_3_4: th('special_3_4', 3, 4, false, 'all_owners_excluding_missing', false, '改正前 区分所有法17条1項・31条1項ほか (区分所有者及び議決権の各3/4以上)', ['規約の変更']),
  rebuild_4_5: th('rebuild_4_5', 4, 5, false, 'all_owners_excluding_missing', false, '改正前 区分所有法62条1項 (各4/5以上)', ['建替え']),
};

export type ProposedResolution =
  | 'change_rule'
  | 'major_common_change'
  | 'common_change_barrier_free_or_defect' // 17条5項の事由がある共用部分の変更
  | 'restoration' // 大規模滅失の復旧 (61条5項)
  | 'establish_corporation'
  | 'use_prohibition_claim'
  | 'rebuild'
  | 'rebuild_objective_ground' // 62条2項の客観的事由がある建替え
  | 'demolish_aged'
  | 'demolish_objective_ground'
  | 'site_sale' // 建物敷地売却決議 (64条の6): 区分所有者・議決権・敷地利用権の持分の価格の各4/5
  | 'demolish_and_site_sale' // 建物取壊し敷地売却決議 (64条の7): 同上
  | 'site_sale_objective_ground' // 上の2つで62条2項の事由があるとき (64条の6第3項・64条の7第3項の準用で3/4)
  | 'normal_repair'
  | 'elect_director';

/** 招集手続の開始日が改正後の規律に当たるか (YYYY-MM-DD の文字列比較) */
export function isAmendedKubunRegime(convocationStartDate: string): boolean {
  return String(convocationStartDate).slice(0, 10) >= KUBUN_AMENDMENT_EFFECTIVE_DATE;
}

/** 議案を必要決議要件にマッピング (convocationStartDate を省くと改正後の規律で返す) */
export function classifyResolutionType(p: ProposedResolution, opts: { convocationStartDate?: string } = {}): ResolutionKind {
  const amended = opts.convocationStartDate ? isAmendedKubunRegime(opts.convocationStartDate) : true;
  switch (p) {
    case 'rebuild':
      return 'rebuild_4_5';
    case 'rebuild_objective_ground':
      return amended ? 'rebuild_3_4' : 'rebuild_4_5';
    case 'demolish_aged':
      return 'demolition_4_5';
    case 'demolish_objective_ground':
      return amended ? 'demolition_3_4' : 'demolition_4_5';
    case 'site_sale':
    case 'demolish_and_site_sale':
      return 'demolition_4_5';
    case 'site_sale_objective_ground':
      return amended ? 'demolition_3_4' : 'demolition_4_5';
    case 'common_change_barrier_free_or_defect':
    case 'restoration':
      return amended ? 'common_change_2_3' : 'special_3_4';
    case 'change_rule':
    case 'major_common_change':
    case 'establish_corporation':
    case 'use_prohibition_claim':
      return 'special_3_4';
    default:
      return 'ordinary';
  }
}

/** 割合の判定 (整数のかけ算で比べる。浮動小数の誤差を持ち込まない) */
function meetsRatio(forCount: number, base: number, t: ResolutionThreshold): boolean {
  if (!(base > 0)) return false;
  return t.strict ? forCount * t.den > base * t.num : forCount * t.den >= base * t.num;
}

export interface ResolutionJudgeInput {
  proposed: ProposedResolution;
  /** 集会の招集手続を開始した日 (YYYY-MM-DD)。これで改正前・改正後の規律を決める (改正法附則2条2項) */
  convocationStartDate: string;
  totalOwners: number;
  totalVotes: number;
  /** 裁判所が認定した所在等不明区分所有者 (38条の2)。改正後は全ての決議の母数から除く */
  missingOwners?: number;
  missingVotes?: number;
  /** 出席 (書面・代理人・電磁的方法による議決権行使を含む) */
  attendingOwners: number;
  attendingVotes: number;
  ownersFor: number;
  votesFor: number;
  /** 建物敷地売却・建物取壊し敷地売却 (64条の6・64条の7) で要る、敷地利用権の持分の価格 (所在等不明区分所有者の分を除く) の合計と賛成分 */
  landShareValueTotal?: number;
  landShareValueFor?: number;
  /** 規約の定め (区分所有法 17条1項・31条1項ほかの「規約で定めた場合」) */
  bylaw?: ResolutionBylaw;
}

/** 規約で定めた割合 */
export interface ResolutionBylaw {
  /** 改正後17条1項: 共用部分の変更の 3/4 を規約で下げた割合 (1/2 を超え 3/4 未満)。17条5項の事由があるときは 2/3 と比べて低い方 */
  commonChangeRatio?: { num: number; den: number };
  /** 改正後の特別決議の定足数を規約で上げた割合 (過半数を上回る割合。「その割合以上」の出席) */
  quorumRatio?: { num: number; den: number };
  /** 改正前17条1項ただし書: 共用部分の変更の区分所有者の定数を規約で過半数まで減じている */
  beforeAmendmentOwnersMajority?: boolean;
}

export interface ResolutionJudgeResult {
  /** 成立=true / 不成立=false / 判定できない=null */
  passed: boolean | null;
  regime: 'amended' | 'before_amendment' | 'unknown';
  required: ResolutionKind | null;
  quorumMet: boolean | null;
  reason: string;
  basis: string;
}

/** 改正前の区分所有法に決議の規定が無い議案 (取壊し・建物更新・敷地売却は 64条の5〜64条の8 で新設) */
const OLD_REGIME_NO_RESOLUTION_ROUTE: ProposedResolution[] = ['demolish_aged', 'demolish_objective_ground', 'site_sale', 'demolish_and_site_sale', 'site_sale_objective_ground'];
const OLD_REGIME_NO_ROUTE_REASON = '判定できません: 2026-03-31 までに招集手続を開始した集会には改正前の区分所有法が適用され、改正前には取壊し・建物更新・敷地売却の決議の規定がありません (区分所有者全員の合意、又はマンションの建替え等の円滑化に関する法律の手続を確認してください)';

/**
 * 集会の決議の成否を、人数と議決権の実数で判定する (区分所有法 2026-04-01 改正対応)。
 *   招集手続の開始日が無いときは、改正前・改正後のどちらの規律か決められないため判定しない (passed=null)。
 */
export function judgeResolution(p: ResolutionJudgeInput): ResolutionJudgeResult {
  if (!p || !p.convocationStartDate || !/^\d{4}-\d{2}-\d{2}/.test(String(p.convocationStartDate))) {
    return { passed: null, regime: 'unknown', required: null, quorumMet: null, reason: '招集手続の開始日が無いため、改正前・改正後のどちらの規律で判定するか決められません (2026-03-31 までに招集手続を開始した集会は改正前の規律)', basis: '改正法 (令和7年法律第47号) 附則2条2項' };
  }
  const amended = isAmendedKubunRegime(p.convocationStartDate);
  if (!amended && OLD_REGIME_NO_RESOLUTION_ROUTE.includes(p.proposed)) {
    return { passed: null, regime: 'before_amendment', required: null, quorumMet: null, reason: OLD_REGIME_NO_ROUTE_REASON, basis: '改正前 区分所有法 (取壊し・建物更新・敷地売却の決議は 2026-04-01 施行の64条の5〜64条の8で新設) / 改正法附則2条2項' };
  }
  const kind = classifyResolutionType(p.proposed, { convocationStartDate: p.convocationStartDate });
  const t: ResolutionThreshold = amended
    ? RESOLUTION_THRESHOLDS[kind]
    : RESOLUTION_THRESHOLDS_BEFORE_AMENDMENT[(kind === 'ordinary' ? 'ordinary' : kind.startsWith('rebuild') || kind.startsWith('demolition') ? 'rebuild_4_5' : 'special_3_4')];
  const regime = amended ? 'amended' : 'before_amendment';
  // 所在等不明区分所有者の除外は改正後の制度 (38条の2)
  const mo = amended ? Math.max(0, p.missingOwners ?? 0) : 0;
  const mv = amended ? Math.max(0, p.missingVotes ?? 0) : 0;
  const allOwners = p.totalOwners - mo;
  const allVotes = p.totalVotes - mv;
  const bl = p.bylaw ?? {};
  const isCommonChange = p.proposed === 'major_common_change' || p.proposed === 'common_change_barrier_free_or_defect';
  // 規約で定めた共用部分の変更の割合 (改正後17条1項。1/2 を超え 3/4 未満に限る)
  let tOwners: ResolutionThreshold = t;
  let tVotes: ResolutionThreshold = t;
  if (amended && isCommonChange && bl.commonChangeRatio) {
    const { num, den } = bl.commonChangeRatio;
    if (!(den > 0 && num * 2 > den && num * 4 < den * 3)) {
      return { passed: null, regime, required: t.kind, quorumMet: null, reason: '規約で定めた共用部分の変更の割合は 1/2 を超え 3/4 を下回る割合に限られます (17条1項括弧書)。規約の割合を確認してください', basis: '区分所有法17条1項' };
    }
    if (num * t.den < t.num * den) { // 規約の割合が法定 (3/4 又は 2/3) より低いときだけ使う
      tOwners = tVotes = { ...t, num, den, ownersThreshold: num / den, votesThreshold: num / den, basis: `${t.basis} / 規約で定めた割合 ${num}/${den}` };
    }
  }
  if (!amended && p.proposed === 'major_common_change' && bl.beforeAmendmentOwnersMajority) {
    // 改正前17条1項ただし書: 区分所有者の定数だけを規約で過半数まで減じられる (議決権は 3/4 のまま)
    tOwners = { ...t, num: 1, den: 2, strict: true, ownersThreshold: 0.5, basis: `${t.basis} / 規約で区分所有者の定数を過半数に減じている (改正前17条1項ただし書)` };
  }
  let quorumMet: boolean | null = null;
  if (t.quorum) {
    if (bl.quorumRatio) {
      const { num, den } = bl.quorumRatio;
      if (!(den > 0 && num * 2 > den && num <= den)) {
        return { passed: null, regime, required: t.kind, quorumMet: null, reason: '規約で定める定足数は過半数を上回る割合に限られます。規約の割合を確認してください', basis: t.basis };
      }
      quorumMet = p.attendingOwners * den >= allOwners * num && p.attendingVotes * den >= allVotes * num;
    } else {
      quorumMet = p.attendingOwners * 2 > allOwners && p.attendingVotes * 2 > allVotes;
    }
    if (!quorumMet) {
      return { passed: false, regime, required: t.kind, quorumMet, reason: `不成立: 定足数 (区分所有者 ${allOwners} と議決権 ${allVotes} の${bl.quorumRatio ? `各${bl.quorumRatio.num}/${bl.quorumRatio.den}以上` : '各過半数'}の出席) に届いていません`, basis: t.basis };
    }
  }
  const baseOwners = t.denominator === 'attendees' ? p.attendingOwners : allOwners;
  const baseVotes = t.denominator === 'attendees' ? p.attendingVotes : allVotes;
  const needsLandShare = amended && (p.proposed === 'site_sale' || p.proposed === 'demolish_and_site_sale' || p.proposed === 'site_sale_objective_ground');
  if (needsLandShare && !(typeof p.landShareValueTotal === 'number' && p.landShareValueTotal > 0 && typeof p.landShareValueFor === 'number')) {
    return { passed: null, regime, required: t.kind, quorumMet, reason: '建物敷地売却・建物取壊し敷地売却の決議は、敷地利用権の持分の価格の賛成割合も要件です。持分の価格の合計と賛成分を渡してください (64条の6・64条の7)', basis: '区分所有法64条の6第1項・64条の7第1項' };
  }
  const landOk = !needsLandShare || meetsRatio(p.landShareValueFor!, p.landShareValueTotal!, t);
  const ok = meetsRatio(p.ownersFor, baseOwners, tOwners) && meetsRatio(p.votesFor, baseVotes, tVotes) && landOk;
  const lbl = (x: ResolutionThreshold) => (x.strict ? '過半数' : `${x.num}/${x.den}以上`);
  const ratioLabel = lbl(tOwners) === lbl(tVotes) ? `各${lbl(tOwners)}` : `区分所有者の${lbl(tOwners)}・議決権の${lbl(tVotes)}`;
  const baseLabel = t.denominator === 'attendees' ? '出席者' : '全区分所有者 (所在等不明を除く)';
  return {
    passed: ok,
    regime,
    required: t.kind,
    quorumMet,
    reason: `${ok ? '成立' : '不成立'}: ${baseLabel} (区分所有者 ${baseOwners}・議決権 ${baseVotes}) の${ratioLabel}${needsLandShare ? '・敷地利用権の持分の価格の各' + lbl(t) : ''}が要件 / 賛成 区分所有者 ${p.ownersFor}・議決権 ${p.votesFor}`,
    basis: tOwners.basis === t.basis && tVotes.basis === t.basis ? t.basis : (tOwners.basis !== t.basis ? tOwners.basis : tVotes.basis),
  };
}

/**
 * 割合だけで判定する旧い口 (互換のため残す)。
 *   ownersForRatio / votesForRatio は「その決議の母数 (改正後の普通・特別決議は出席者、建替えは全区分所有者) に対する賛成の割合」。
 *   改正後の特別決議は定足数が要るため、出席の割合 (ownersAttendanceRatio / votesAttendanceRatio) が無ければ判定しない。
 *   「過半数」はちょうど半分を含まない。人数・議決権の実数があるときは judgeResolution を使うこと。
 */
export function canPassResolution(p: {
  proposed: ProposedResolution;
  ownersForRatio: number;
  votesForRatio: number;
  ownersAttendanceRatio?: number;
  votesAttendanceRatio?: number;
  convocationStartDate?: string;
}): { passed: boolean; required: ResolutionKind; reason: string } {
  const amended = p.convocationStartDate ? isAmendedKubunRegime(p.convocationStartDate) : true;
  const required = classifyResolutionType(p.proposed, { convocationStartDate: p.convocationStartDate });
  if (!amended && OLD_REGIME_NO_RESOLUTION_ROUTE.includes(p.proposed)) {
    return { passed: false, required, reason: OLD_REGIME_NO_ROUTE_REASON };
  }
  if (amended && (p.proposed === 'site_sale' || p.proposed === 'demolish_and_site_sale' || p.proposed === 'site_sale_objective_ground')) {
    return { passed: false, required, reason: '判定できません: 敷地売却の決議は敷地利用権の持分の価格の割合も要件です。judgeResolution に持分の価格を渡してください (64条の6・64条の7)' };
  }
  const t: ResolutionThreshold = amended
    ? RESOLUTION_THRESHOLDS[required]
    : RESOLUTION_THRESHOLDS_BEFORE_AMENDMENT[(required === 'ordinary' ? 'ordinary' : required.startsWith('rebuild') || required.startsWith('demolition') ? 'rebuild_4_5' : 'special_3_4')];
  if (t.quorum) {
    if (p.ownersAttendanceRatio === undefined || p.votesAttendanceRatio === undefined) {
      return { passed: false, required, reason: '判定できません: 特別決議には定足数 (区分所有者と議決権の各過半数の出席) が要るため、出席の割合を渡してください' };
    }
    if (!(p.ownersAttendanceRatio > 0.5 && p.votesAttendanceRatio > 0.5)) {
      return { passed: false, required, reason: '不成立: 定足数 (各過半数の出席) に届いていません' };
    }
  }
  const r = t.num / t.den;
  const passed = t.strict
    ? p.ownersForRatio > r && p.votesForRatio > r
    : p.ownersForRatio >= r - 1e-12 && p.votesForRatio >= r - 1e-12;
  const label = t.strict ? '過半数' : `${t.num}/${t.den}以上`;
  return {
    passed,
    required,
    reason: passed ? `成立 (要 区分所有者・議決権の各${label} / ${t.basis})` : `不成立 (要 区分所有者・議決権の各${label} / ${t.basis})`,
  };
}

// ===== 長期修繕計画 + 大規模修繕周期 =====

export const LONG_TERM_REPAIR_CYCLES = {
  /** 計画期間 (国交省ガイドライン): 30 年以上 */
  planHorizonYears: 30,
  /** 大規模修繕の標準的な周期 (年) */
  largeScaleRepairCycleYears: 12,
  /** 計画見直し周期: 5年程度 */
  reviewCycleYears: 5,
  /** 主要部位ごとの修繕周期 (年) — 標準ガイドライン */
  partsCycle: {
    '屋根防水': 12,
    '外壁塗装': 12,
    '鉄部塗装': 4,
    '給水管(更生)': 15,
    '給水管(更新)': 30,
    '排水管(更新)': 30,
    'エレベーター(更新)': 25,
    '機械式駐車場(更新)': 20,
    'インターホン(更新)': 15,
  } as Record<string, number>,
} as const;

export interface RepairPlanItem {
  part: string;
  /** 前回実施年 */
  lastYear: number;
  /** 1回あたり概算費用 (円) */
  estimatedCostJpy: number;
}

export interface LongTermRepairPlan {
  baseYear: number;
  horizonYears: number;
  schedule: { year: number; part: string; estimatedCostJpy: number }[];
  totalCostJpy: number;
}

export function buildLongTermRepairPlan(p: {
  baseYear: number;
  items: RepairPlanItem[];
  horizonYears?: number;
}): LongTermRepairPlan {
  const horizon = p.horizonYears ?? LONG_TERM_REPAIR_CYCLES.planHorizonYears;
  const cycles = LONG_TERM_REPAIR_CYCLES.partsCycle;
  const schedule: LongTermRepairPlan['schedule'] = [];
  let total = 0;
  for (const it of p.items) {
    const cycleYears = cycles[it.part] ?? LONG_TERM_REPAIR_CYCLES.largeScaleRepairCycleYears;
    let year = it.lastYear + cycleYears;
    while (year < p.baseYear + horizon) {
      schedule.push({ year, part: it.part, estimatedCostJpy: it.estimatedCostJpy });
      total += it.estimatedCostJpy;
      year += cycleYears;
    }
  }
  schedule.sort((a, b) => a.year - b.year);
  return { baseYear: p.baseYear, horizonYears: horizon, schedule, totalCostJpy: total };
}

// ===== 修繕積立金 (R3 ガイドライン) =====

/**
 * R3 国交省ガイドライン: 専有面積 1m2 月額 (単位: 円)。
 * 機械式駐車場ありは別途加算。
 *
 * 階数 / 延床面積 区分の代表値:
 */
export const REPAIR_FUND_GUIDE_R3 = {
  /** 15階未満 / 5,000m2未満: 235円/m2/月 (中央値) */
  low_rise_small: 235,
  /** 15階未満 / 5,000-10,000m2: 252円/m2/月 */
  low_rise_medium: 252,
  /** 15階未満 / 10,000-20,000m2: 271円/m2/月 */
  low_rise_large: 271,
  /** 15階未満 / 20,000m2以上: 255円/m2/月 */
  low_rise_xlarge: 255,
  /** 20階以上: 338円/m2/月 */
  high_rise: 338,
} as const;

export type BuildingProfile = 'low_rise_small' | 'low_rise_medium' | 'low_rise_large' | 'low_rise_xlarge' | 'high_rise';

export function calcRecommendedRepairFundJpyPerM2Month(p: {
  profile: BuildingProfile;
  /** 機械式駐車場の台数 (1台あたり加算 7,085 円/月の想定 ÷ 専有面積分配) */
  mechanicalParkingUnits?: number;
  /** 全体の専有面積合計 (m2) — 駐車場按分計算用 */
  totalPrivateAreaM2?: number;
}): number {
  const base = REPAIR_FUND_GUIDE_R3[p.profile];
  if (!p.mechanicalParkingUnits || !p.totalPrivateAreaM2) return base;
  const parkingMonthlyTotal = p.mechanicalParkingUnits * 7085;
  const perM2Add = parkingMonthlyTotal / p.totalPrivateAreaM2;
  return Math.round(base + perM2Add);
}

// ===== マンション管理計画認定制度 (R4.4 施行) =====

export const MANAGEMENT_PLAN_CERT_CRITERIA = [
  '管理組合の運営が適正に行われている (理事会開催/総会決議)',
  '管理規約が標準管理規約に概ね沿っている',
  '管理組合の経理が区分経理されている',
  '長期修繕計画が30年以上 + 5年以内に見直し',
  '修繕積立金が長期修繕計画に基づき積み立てられている',
  '組合員名簿/居住者名簿が適切に整備されている',
] as const;

export interface ManagementPlanProfile {
  hasRegularBoardMeeting: boolean;
  hasStandardRule: boolean;
  hasSeparatedAccounting: boolean;
  longTermPlanYears: number;
  longTermPlanReviewedWithinYears: number;
  monthlyRepairFundPerM2: number;
  recommendedRepairFundPerM2: number;
  hasMemberRegister: boolean;
  hasResidentRegister: boolean;
}

export function canCertifyManagementPlan(p: ManagementPlanProfile): {
  certifiable: boolean;
  failedCriteria: string[];
} {
  const f: string[] = [];
  if (!p.hasRegularBoardMeeting) f.push('理事会・総会の運営');
  if (!p.hasStandardRule) f.push('標準管理規約準拠');
  if (!p.hasSeparatedAccounting) f.push('区分経理');
  if (p.longTermPlanYears < 30) f.push('長期修繕計画 30年以上');
  if (p.longTermPlanReviewedWithinYears > 5) f.push('長期修繕計画 5年以内見直し');
  if (p.monthlyRepairFundPerM2 < p.recommendedRepairFundPerM2 * 0.7)
    f.push('修繕積立金がガイドライン下限を下回る');
  if (!p.hasMemberRegister || !p.hasResidentRegister) f.push('組合員/居住者名簿整備');
  return { certifiable: f.length === 0, failedCriteria: f };
}

// ===== 滞納督促 (区分所有費・修繕積立金) =====

/**
 * 督促の段階 (滞納月数)。値は単一の定義 lib/japan/delinquency_ladder.json の condo_fee から読む (ここに月数を書かない)。
 *   業種辞書 mansion-management.json の delinquency_stages も同じ定義を参照する。
 */
export const DELINQUENCY_PROCEDURES: readonly { stageMonths: number; action: string; code: string; actor: string }[] =
  delinquencyLadder.condo_fee.stages.map((s: { from: number; action_ja: string; code: string; actor_ja: string }) => ({ stageMonths: s.from, action: s.action_ja, code: s.code, actor: s.actor_ja }));

export function nextDelinquencyAction(monthsOverdue: number): string {
  for (let i = DELINQUENCY_PROCEDURES.length - 1; i >= 0; i--) {
    if (monthsOverdue >= DELINQUENCY_PROCEDURES[i].stageMonths) {
      return DELINQUENCY_PROCEDURES[i].action;
    }
  }
  return '当月催告 (新規滞納)';
}

/** 管理費・修繕積立金の消滅時効: 民法改正 (R2.4) 後 5 年。承認・督促で時効更新。 */
export const DELINQUENCY_PRESCRIPTION_YEARS = 5;

// ===== 管理業務主任者 + マンション管理士 =====

export type ManagerQualification = 'management_business_manager' | 'mansion_management_consultant';

export const MANAGER_QUALIFICATIONS: Record<ManagerQualification, {
  label: string;
  legalDuty: string;
}> = {
  management_business_manager: {
    label: '管理業務主任者',
    legalDuty: '管理委託契約の重要事項説明・記名押印 (適正化法72条)',
  },
  mansion_management_consultant: {
    label: 'マンション管理士',
    legalDuty: '管理組合からの相談助言 (国家資格 / 登録制)',
  },
};

/** マンション管理業者は管理組合 30 組合に1名以上の管理業務主任者を設置 */
export function requireManagerQualification(p: { managedAssociations: number }): {
  required: number;
  qualification: ManagerQualification;
} {
  const required = Math.max(1, Math.ceil(p.managedAssociations / 30));
  return { required, qualification: 'management_business_manager' };
}

// ===== 建替え (62条) + 取壊し決議 =====

/** 建替え決議の同意要件 (全区分所有者 (所在等不明を除く) の区分所有者数+議決権 各 4/5 以上。62条1項) */
export const REBUILD_CONSENT_THRESHOLD = { ownersRatio: 0.8, votesRatio: 0.8 };
/**
 * 客観的事由がある建物の建替え決議の同意要件 (各 3/4 以上。62条2項・2026-04-01 施行)。
 *   事由: 耐震性の不足 / 火災に対する安全性の不足 / 外壁等の剥落のおそれ / 給排水管等の腐食等 / バリアフリー基準への不適合。
 *   出典: 法務省民事局「区分所有法・被災区分所有法の改正について」(令和8年4月) p.10。
 *   2026-03-31 までに招集手続を開始した集会には適用しない (改正前は事由があっても 4/5)。
 */
export const REBUILD_CONSENT_THRESHOLD_OBJECTIVE_GROUND = { ownersRatio: 0.75, votesRatio: 0.75 };

export type RebuildObjectiveGround = 'earthquake' | 'fire' | 'exterior_wall' | 'pipes' | 'barrier_free';

export function canRebuildAged(p: {
  ownersForRatio: number;
  votesForRatio: number;
  /** 老朽化・違法建築の印。★老朽化それ自体は62条2項の事由ではない (事由は objectiveGround で渡す) */
  isAgedOrIllegal: boolean;
  /** 耐震性の不足 (62条2項の事由の一つ) */
  earthquakeRisk: boolean;
  objectiveGround?: RebuildObjectiveGround | null;
  /** 招集手続の開始日 (YYYY-MM-DD)。省くと改正後の規律で判定する */
  convocationStartDate?: string;
}): { passed: boolean; reason: string } {
  const eps = 1e-12;
  if (
    p.ownersForRatio >= REBUILD_CONSENT_THRESHOLD.ownersRatio - eps &&
    p.votesForRatio >= REBUILD_CONSENT_THRESHOLD.votesRatio - eps
  ) {
    return { passed: true, reason: '建替え決議 成立 (各4/5以上・62条1項)' };
  }
  const amended = p.convocationStartDate ? isAmendedKubunRegime(p.convocationStartDate) : true;
  const hasGround = p.earthquakeRisk === true || !!p.objectiveGround;
  if (amended && hasGround) {
    const ok = p.ownersForRatio >= REBUILD_CONSENT_THRESHOLD_OBJECTIVE_GROUND.ownersRatio - eps &&
      p.votesForRatio >= REBUILD_CONSENT_THRESHOLD_OBJECTIVE_GROUND.votesRatio - eps;
    return ok
      ? { passed: true, reason: '客観的事由がある建物の建替え決議 成立 (各3/4以上・62条2項)' }
      : { passed: false, reason: '客観的事由がある建物でも各3/4に届いていません — 同意取得を継続' };
  }
  if (!amended && hasGround) {
    return { passed: false, reason: '4/5 未達 — 2026-03-31 までに招集手続を開始した集会は改正前の規律で、3/4の特例はありません' };
  }
  return { passed: false, reason: '4/5 未達 — 同意取得を継続 (耐震性不足など62条2項の事由があれば各3/4)' };
}
