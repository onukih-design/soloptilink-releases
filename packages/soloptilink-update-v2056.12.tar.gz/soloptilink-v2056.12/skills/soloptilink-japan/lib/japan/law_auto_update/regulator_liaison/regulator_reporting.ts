/**
 * Phase 46-LU-7 / Regulator Liaison
 *
 * 規制当局 (個情委 / JPCERT/CC / 基幹インフラの所管大臣・内閣総理大臣 / 警察庁 / 金融庁 / 厚労省 / 公取委 etc.)
 * への報告書を自動生成する。
 *
 *  - 個情法第26条 漏えい等の報告 (個情委)
 *  - JPCERT/CC 早期警戒情報
 *  - サイバー対処能力強化法 第5条 特定侵害事象等の報告 (特別社会基盤事業所管大臣 及び 内閣総理大臣)
 *  - 重要インフラ事業者の情報連絡 (所管省庁 → 内閣官房 国家サイバー統括室 (旧 NISC))
 *  - 金融機関インシデント (金融庁)
 *
 * ★2026-10-10 是正: 従来「能動的サイバー防御庁 (ACDA)」が R7.4 に新設されたとして報告先に置いていたが、
 *   その名称の組織は一次資料 (e-Gov 法令・内閣官房) に存在しない。根拠法の成立は 2025-05-16 で R7.4 には未成立。
 *   実際に新設されたのは 国家サイバー統括室 (2025-07-01、NISC を改組) と、監督機関である
 *   サイバー通信情報監理委員会 (2026-04-01) で、後者は事業者の報告先ではない。
 *   関数名 generateAcdaReport と内部キー acda / nisc は、既存の呼び出し元のため据え置いている。
 *
 * 出力: 各規制当局の指定書式 (PDF/XML/JSON)
 */

import {
  INITIAL_REPORT_DEADLINE_DAYS,
  FULL_REPORT_DEADLINE_DAYS,
  FULL_REPORT_DEADLINE_DAYS_FOR_INTENTIONAL,
  breachReportDueDateTime,
} from '../../ppipa_r5';

export type RegulatoryAgency =
  | 'ppc'              // 個人情報保護委員会
  | 'jpcert_cc'        // JPCERT/CC
  | 'acda'             // 互換キー: サイバー対処能力強化法 第5条の報告先 (特別社会基盤事業所管大臣 及び 内閣総理大臣)
  | 'nisc'             // 互換キー: 内閣官房 国家サイバー統括室 (旧 NISC。2025-07-01 改組)
  | 'fsa'              // 金融庁
  | 'mhlw'             // 厚労省
  | 'jftc'             // 公正取引委員会
  | 'mlit'             // 国土交通省
  | 'pmda'             // 医薬品医療機器総合機構
  | 'police_cyber';    // 警察庁サイバー対策係

export interface RegulatoryReport {
  report_id: string;
  agency: RegulatoryAgency;
  category: string;
  /** 提出主体 */
  filer_organization: string;
  filer_contact: { name: string; title: string; email: string; phone: string };
  /** 事案 */
  incident_id?: string;
  incident_summary: string;
  /** 発生・覚知日時 */
  occurred_at: string;
  detected_at: string;
  /** 影響範囲 */
  affected_data_subjects?: number;
  affected_data_categories?: string[];
  /** 対応状況 */
  mitigation_taken: string[];
  /** 再発防止策 */
  preventive_measures: string[];
  /** 法的根拠 */
  legal_basis: string;
  /** 締切 */
  deadline_at: string;
  /** 締切の注記 (法令上「速やかに」で数値の期限が無い場合など) */
  deadline_note_ja?: string;
  status: 'draft' | 'submitted' | 'acknowledged';
  /** 添付ファイル */
  attachments?: Array<{ name: string; size_bytes: number }>;
  /** 提出書式 */
  output_format: 'pdf' | 'xml' | 'json' | 'web_form';
  generated_at: string;
}

const REPORTS = new Map<string, RegulatoryReport>();

/**
 * 個情法第26条 漏えい等の報告 (個情委向け。施行規則 第8条:
 * 速報は速やかに = ガイドライン通則編の目安で概ね3〜5日以内 /
 * 確報は30日以内、不正の目的によるもの (規則第7条第3号) は60日以内)
 *
 * ★2026-10-10 是正: 従来は速報の期限を GDPR 第33条と同じ72時間で計算し、確報は不正目的の事案でも一律30日、
 *   報告対象の判定は「1,000人以上」だった。72時間は GDPR 第33条の期限で日本の個情法には無い。
 *   日数と数え方 (知った日を1日目とする) は ppipa_r5.ts を唯一の出典とし、ここに数字を直書きしない。
 */
export function generatePpcLeakageReport(input: {
  filer_organization: string;
  filer_contact: RegulatoryReport['filer_contact'];
  incident_summary: string;
  occurred_at: string;
  detected_at: string;
  affected_data_subjects: number;
  affected_data_categories: string[];
  is_sensitive_data?: boolean;
  /** 不正の目的をもって行われたおそれがある行為 (不正アクセス・内部不正 等) による漏えい等 (規則第7条第3号) */
  is_intentional_act?: boolean;
  is_initial?: boolean; // 速報 (true) / 確報 (false)
}): RegulatoryReport {
  const isInitial = input.is_initial ?? true;
  const isIntentional = input.is_intentional_act === true;
  const deadlineDays = isInitial
    ? INITIAL_REPORT_DEADLINE_DAYS
    : isIntentional ? FULL_REPORT_DEADLINE_DAYS_FOR_INTENTIONAL : FULL_REPORT_DEADLINE_DAYS;
  const deadlineAt = breachReportDueDateTime(input.detected_at, deadlineDays);

  // 個情法26条 報告対象判定 (施行規則 第7条)
  const reportable =
    input.affected_data_subjects > 1000 // 4号: 本人の数が1,000人を超える
    || input.is_sensitive_data === true // 1号: 要配慮個人情報
    || isIntentional // 3号: 不正の目的
    || input.affected_data_categories.includes('クレジットカード番号') // 2号: 財産的被害のおそれ
    || input.affected_data_categories.includes('財産的被害');

  const report: RegulatoryReport = {
    report_id: `ppc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    agency: 'ppc',
    category: isInitial ? '速報 (個情法26条 R4改正)' : '確報 (個情法26条 R4改正)',
    filer_organization: input.filer_organization,
    filer_contact: input.filer_contact,
    incident_summary: input.incident_summary,
    occurred_at: input.occurred_at,
    detected_at: input.detected_at,
    affected_data_subjects: input.affected_data_subjects,
    affected_data_categories: input.affected_data_categories,
    mitigation_taken: ['影響範囲の特定', '不正アクセス経路の遮断', '影響本人への通知準備'],
    preventive_measures: ['アクセス制御の見直し', '監査ログの強化', '従業員教育'],
    legal_basis: `個人情報保護法第26条 / 同法施行規則 第7条・第8条${reportable ? ' (報告対象事案に該当)' : ' (任意報告)'}`,
    deadline_at: deadlineAt,
    deadline_note_ja: isInitial
      ? '速報は「速やかに」。締切はガイドライン通則編の目安 (概ね3〜5日以内) の上限を、知った日を1日目として数えたもの'
      : '確報は知った日を1日目として数える (土日・祝日を含む)。末日が土日・祝日・年末年始閉庁日なら翌日が期限だが、締切欄は繰り延べ前の日 (安全側) を示す',
    status: 'draft',
    output_format: 'web_form', // 個情委は PPC ポータル経由
    generated_at: new Date().toISOString(),
  };
  REPORTS.set(report.report_id, report);
  return report;
}

/**
 * JPCERT/CC 早期警戒情報報告
 */
export function generateJpcertReport(input: {
  filer_organization: string;
  filer_contact: RegulatoryReport['filer_contact'];
  incident_summary: string;
  occurred_at: string;
  detected_at: string;
  attack_vector: string;
  ioc_observed: string[];
}): RegulatoryReport {
  const deadline = new Date(input.detected_at);
  deadline.setHours(deadline.getHours() + 24);
  const report: RegulatoryReport = {
    report_id: `jpcert_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    agency: 'jpcert_cc',
    category: '早期警戒情報',
    filer_organization: input.filer_organization,
    filer_contact: input.filer_contact,
    incident_summary: `${input.incident_summary} / 攻撃ベクター: ${input.attack_vector}`,
    occurred_at: input.occurred_at,
    detected_at: input.detected_at,
    mitigation_taken: ['通信の遮断', '攻撃元のブロック', 'マルウェア駆除'],
    preventive_measures: ['IOC 共有', 'WAF ルール追加', 'EDR シグネチャ更新'],
    legal_basis: 'JPCERT/CC 早期警戒情報運用要綱',
    deadline_at: deadline.toISOString(),
    status: 'draft',
    output_format: 'json',
    attachments: input.ioc_observed.map((ioc) => ({ name: `ioc_${ioc.slice(0, 10)}.txt`, size_bytes: ioc.length })),
    generated_at: new Date().toISOString(),
  };
  REPORTS.set(report.report_id, report);
  return report;
}

/**
 * サイバー対処能力強化法 第5条 特定侵害事象等の報告 (2026-10-01 施行)
 *   (関数名は互換のため据え置き。旧来の「能動的サイバー防御庁 (ACDA)」宛ては実在しない報告先だった)
 *
 *   対象: 特別社会基盤事業者 (経済安全保障推進法の特定社会基盤事業者のうち特定重要電子計算機を使用するもの)
 *   報告先: 特別社会基盤事業所管大臣 及び 内閣総理大臣
 *   期限 (報告等に関する命令 第4条): 速報は認知後「速やかに」(時間の定めなし) /
 *         報告書は特定侵害事象等の発生を認知した日から30日以内
 *   ★従来の 6時間 / 48時間 には根拠が無かった。
 */
export function generateAcdaReport(input: {
  filer_organization: string;
  filer_contact: RegulatoryReport['filer_contact'];
  incident_summary: string;
  occurred_at: string;
  detected_at: string;
  /** 特別社会基盤事業者に当たるか (当たらなければ法第5条の報告義務は無い) */
  is_critical_infrastructure: boolean;
  affected_services: string[];
  /** 速報 (true) / 30日以内の報告書 (false) */
  is_initial?: boolean;
}): RegulatoryReport {
  const isInitial = input.is_initial ?? true;
  const deadline = new Date(input.detected_at);
  // 速報は「速やかに」で数値の期限が無いため、認知時点を期限として置き (=直ちに着手)、注記で明示する。
  // 報告書は認知した日から30日 (数え方は法令に明示が無いため、30日後を置く)。
  if (!isInitial) deadline.setDate(deadline.getDate() + 30);
  const report: RegulatoryReport = {
    report_id: `acda_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    agency: 'acda',
    category: isInitial
      ? '特定侵害事象等の報告 速報 (サイバー対処能力強化法 第5条)'
      : '特定侵害事象等の報告 報告書 (サイバー対処能力強化法 第5条)',
    filer_organization: input.filer_organization,
    filer_contact: input.filer_contact,
    incident_summary: input.incident_summary,
    occurred_at: input.occurred_at,
    detected_at: input.detected_at,
    affected_data_categories: input.affected_services,
    mitigation_taken: ['攻撃元の特定', '通信ログの保全', '所管省庁への連絡準備'],
    preventive_measures: ['脆弱性パッチ適用', 'NW セグメンテーション強化'],
    legal_basis: input.is_critical_infrastructure
      ? '重要電子計算機に対する不正な行為による被害の防止に関する法律 (令和7年法律第42号) 第5条 / 同法に基づく報告等に関する命令 第4条'
      : '特別社会基盤事業者に当たらないため、同法第5条の報告義務は無い (任意の情報提供。重要インフラ事業者なら行動計画に基づき所管省庁へ連絡)',
    deadline_at: deadline.toISOString(),
    deadline_note_ja: isInitial
      ? '速報の期限は法令上「速やかに」(時間の定めなし)。締切欄は認知時点 (直ちに着手) を示す'
      : '報告書は特定侵害事象等の発生を認知した日から30日以内',
    status: 'draft',
    output_format: 'xml',
    generated_at: new Date().toISOString(),
  };
  REPORTS.set(report.report_id, report);
  return report;
}

/**
 * 金融庁インシデント報告 (主要行/監督指針)
 */
export function generateFsaReport(input: {
  filer_organization: string;
  filer_contact: RegulatoryReport['filer_contact'];
  incident_summary: string;
  occurred_at: string;
  detected_at: string;
  customer_loss_jpy: number;
}): RegulatoryReport {
  const deadline = new Date(input.detected_at);
  deadline.setHours(deadline.getHours() + 24);
  const report: RegulatoryReport = {
    report_id: `fsa_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    agency: 'fsa',
    category: '金融機関インシデント報告 (主要行向け監督指針)',
    filer_organization: input.filer_organization,
    filer_contact: input.filer_contact,
    incident_summary: `${input.incident_summary} / 顧客損害推計: ¥${input.customer_loss_jpy.toLocaleString()}`,
    occurred_at: input.occurred_at,
    detected_at: input.detected_at,
    mitigation_taken: ['取引停止', '影響顧客への通知', 'システム復旧'],
    preventive_measures: ['FISC 安全対策基準準拠強化', '内部統制 (J-SOX) 強化'],
    legal_basis: '銀行法第26条 + 主要行向け監督指針 III-3 + FISC 安全対策基準',
    deadline_at: deadline.toISOString(),
    status: 'draft',
    output_format: 'pdf',
    generated_at: new Date().toISOString(),
  };
  REPORTS.set(report.report_id, report);
  return report;
}

/**
 * Markdown 形式の報告書出力
 */
export function renderReportMarkdown(report: RegulatoryReport): string {
  const lines: string[] = [];
  lines.push(`# 規制当局報告書: ${report.category}`);
  lines.push('');
  lines.push(`- 報告先: ${agencyName(report.agency)}`);
  lines.push(`- 報告者: ${report.filer_organization}`);
  lines.push(`- 担当: ${report.filer_contact.name} (${report.filer_contact.title}) — ${report.filer_contact.email}`);
  lines.push(`- 発生日時: ${report.occurred_at}`);
  lines.push(`- 覚知日時: ${report.detected_at}`);
  lines.push(`- 締切: ${report.deadline_at}`);
  if (report.deadline_note_ja) lines.push(`- 締切の注記: ${report.deadline_note_ja}`);
  lines.push(`- 法的根拠: ${report.legal_basis}`);
  lines.push('');
  lines.push('## 事案概要');
  lines.push(report.incident_summary);
  lines.push('');
  if (report.affected_data_subjects) {
    lines.push(`## 影響範囲`);
    lines.push(`- 影響人数: ${report.affected_data_subjects.toLocaleString()} 名`);
    if (report.affected_data_categories) {
      lines.push(`- 影響データ種別: ${report.affected_data_categories.join(' / ')}`);
    }
    lines.push('');
  }
  lines.push('## 実施済み対応');
  for (const m of report.mitigation_taken) lines.push(`- ${m}`);
  lines.push('');
  lines.push('## 再発防止策');
  for (const p of report.preventive_measures) lines.push(`- ${p}`);
  lines.push('');
  lines.push(`> 生成日時: ${report.generated_at}`);
  lines.push(`> 出力形式: ${report.output_format} / 状態: ${report.status}`);
  return lines.join('\n');
}

function agencyName(agency: RegulatoryAgency): string {
  const map: Record<RegulatoryAgency, string> = {
    ppc: '個人情報保護委員会',
    jpcert_cc: 'JPCERT/CC',
    acda: '特別社会基盤事業所管大臣 及び 内閣総理大臣 (サイバー対処能力強化法 第5条)',
    nisc: '内閣官房 国家サイバー統括室 (旧 NISC)',
    fsa: '金融庁',
    mhlw: '厚生労働省',
    jftc: '公正取引委員会',
    mlit: '国土交通省',
    pmda: '医薬品医療機器総合機構 (PMDA)',
    police_cyber: '警察庁サイバー対策係',
  };
  return map[agency];
}

export function submitReport(report_id: string): boolean {
  const r = REPORTS.get(report_id);
  if (!r) return false;
  r.status = 'submitted';
  return true;
}

export function countReports(): { total: number; by_agency: Record<string, number>; by_status: Record<string, number> } {
  const byAgency: Record<string, number> = {};
  const byStatus: Record<string, number> = {};
  for (const r of REPORTS.values()) {
    byAgency[r.agency] = (byAgency[r.agency] ?? 0) + 1;
    byStatus[r.status] = (byStatus[r.status] ?? 0) + 1;
  }
  return { total: REPORTS.size, by_agency: byAgency, by_status: byStatus };
}

export function _resetRegulatorReportsForTests(): void {
  REPORTS.clear();
}
