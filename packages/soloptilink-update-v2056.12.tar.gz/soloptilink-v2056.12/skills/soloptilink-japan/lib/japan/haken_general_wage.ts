/**
 * lib/japan/haken_general_wage.ts — 労使協定方式の一般賃金（年度の版で引く）
 *
 * 根拠: 労働者派遣法 第30条の4第1項第2号イ（同種の業務に従事する一般の労働者の平均的な賃金の額）
 * 値の出典（一次資料・厚生労働省職業安定局長通達とその別添の Excel 版。取得日 2026-10-03）:
 *   - 令和8年度（2026-04-01〜2027-03-31）: 職発0825第1号（令和7年8月25日）
 *       https://www.mhlw.go.jp/content/001547254.pdf（本文）／別添1 001546612.xlsx・別添2 001546613.xlsx・別添3 001546614.xlsx
 *   - 令和9年度（2027-04-01〜2028-03-31）: 職発0828第5号（令和8年8月28日）
 *       https://www.mhlw.go.jp/content/001743624.pdf（本文）／別添1 001743447.xlsx・別添2 001743448.xlsx・別添3 001743449.xlsx
 *   値表 haken-general-wage/fy2026.json・fy2027.json は別添の Excel 版から機械で書き起こした（生成手順は証跡の gen_general_wage.py）。
 *   値は値表の1か所にだけ置き、この部品・辞書・説明文は値表を読む。
 *
 * 算定（通達 第2の1(2)）: 一般基本給・賞与等 = 別添1又は別添2の数値（職種別の基準値×能力・経験調整指数）× 別添3の地域指数
 *   1円未満の端数は切り上げる。基準値（0年）に地域指数を乗じた額が地域別最低賃金（又は特定最低賃金）を下回るときは、
 *   最低賃金の額を基準値（0年）とした上で能力・経験調整指数を乗じる（この場合も切り上げ）。
 * 一般通勤手当（通達 第2の2）: 令和8年度 79円・令和9年度 67円（時間額）。
 * 一般退職金（通達 第2の3）: 一般基本給・賞与等 × 5%（両年度とも）。1円未満は切り上げ。
 *
 * ★値表に無い年度（令和7年度以前・令和10年度以降）は旧い値で計算し続けず「未対応」を返す。
 * ★能力・経験調整指数は通達の表にある勤続 0・1・2・3・5・10・20年だけを持つ。間の年数の扱いは労使協定で定める事項のため、
 *   この部品は補間しない（未対応を返す）。
 * ★労使協定書の作成そのものは社会保険労務士等の確認を要する（社労士法27条）。この部品は比較のための額の計算までに留める。
 */
import FY2026 from './haken-general-wage/fy2026.json';
import FY2027 from './haken-general-wage/fy2027.json';

export interface GeneralWageRow {
  code: string;
  name: string;
  /** 勤続 0,1,2,3,5,10,20 年の額（円）。統計の標本が足りない職種は null（通達の「-」） */
  yen: (number | null)[];
  max0: number | null;
}
export interface GeneralWageVersion {
  fiscal_year: string;
  wareki: string;
  notice: string;
  notice_date: string;
  apply_from: string;
  apply_to: string;
  commute_allowance_yen_per_hour: number;
  retirement_rate_percent: number;
  ability_experience_index: Record<string, number>;
  year_keys: string[];
  wage_census: GeneralWageRow[];
  job_stats: GeneralWageRow[];
  region_prefecture: Record<string, number>;
  region_hw: Record<string, { name: string; pref: string; index: number }>;
  sources: string[];
}

/** 年度の版の一覧（適用開始日の昇順）。値はここ以外に書かない */
export const GENERAL_WAGE_VERSIONS: GeneralWageVersion[] = [FY2026 as GeneralWageVersion, FY2027 as GeneralWageVersion];

const ymd = (d: string | Date): string =>
  typeof d === 'string'
    ? d.slice(0, 10)
    : `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

/** 基準日に適用される年度の版。値表に無い年度は null（旧い値で計算し続けない） */
export function getGeneralWageVersion(asOf: string | Date): GeneralWageVersion | null {
  const d = ymd(asOf);
  return GENERAL_WAGE_VERSIONS.find((v) => v.apply_from <= d && d <= v.apply_to) || null;
}

export type GeneralWageStatus = 'ok' | 'unsupported_fiscal_year' | 'unknown_occupation' | 'no_statistics' | 'unsupported_years' | 'unknown_region';

export interface GeneralWageResult {
  status: GeneralWageStatus;
  fiscalYear?: string;
  notice?: string;
  /** 一般基本給・賞与等（時給・円） */
  basicYen?: number;
  /** 一般通勤手当（時給・円） */
  commuteYen?: number;
  /** 一般退職金（前払い・退職金割合による額。時給・円） */
  retirementYen?: number;
  regionIndex?: number;
  minimumWageApplied?: boolean;
  message: string;
}

/** 地域指数は小数第1位まで。整数(×10)にして掛け、1円未満を切り上げる（浮動小数の誤差を出さない） */
const ceilByIndex = (yen: number, index: number) => Math.ceil((yen * Math.round(index * 10)) / 1000);

export function calcGeneralWage(input: {
  asOf: string | Date;
  /** wage_census=別添1（賃金構造基本統計調査）／job_stats=別添2（職業安定業務統計） */
  source: 'wage_census' | 'job_stats';
  occupationCode: string;
  /** 勤続年数（0・1・2・3・5・10・20 のいずれか） */
  years: number;
  /** 都道府県名（例: 東京）またはハローワークの番号（例: 1301） */
  prefecture?: string;
  hwCode?: string;
  /** 派遣就業場所の地域別最低賃金（又は特定最低賃金）の時間額。渡すと最低賃金の下回りを判定する */
  minimumWageYen?: number;
}): GeneralWageResult {
  const v = getGeneralWageVersion(input.asOf);
  if (!v) {
    return {
      status: 'unsupported_fiscal_year',
      message: `基準日 ${ymd(input.asOf)} に適用される一般賃金の通達は値表にありません（収録: ${GENERAL_WAGE_VERSIONS.map((x) => x.wareki).join('・')}）。最新の局長通達で確認してください。`,
    };
  }
  const row = v[input.source].find((r) => r.code === input.occupationCode);
  if (!row) return { status: 'unknown_occupation', fiscalYear: v.fiscal_year, message: `職種番号 ${input.occupationCode} は${v.wareki}の別添にありません` };
  const k = v.year_keys.indexOf(String(input.years));
  if (k < 0) {
    return { status: 'unsupported_years', fiscalYear: v.fiscal_year, message: `勤続${input.years}年は通達の表（${v.year_keys.join('・')}年）に無く、補間はしません。労使協定の定めに従ってください。` };
  }
  const base = row.yen[k];
  if (base === null || base === undefined) {
    return { status: 'no_statistics', fiscalYear: v.fiscal_year, message: `${row.name}は${v.wareki}の別添で「-」（標本不足）です。別の統計（別添1/別添2）か独自統計の協議が必要です。` };
  }
  let regionIndex: number | undefined;
  if (input.hwCode) regionIndex = v.region_hw[input.hwCode]?.index;
  else if (input.prefecture) regionIndex = v.region_prefecture[input.prefecture];
  if (regionIndex === undefined) return { status: 'unknown_region', fiscalYear: v.fiscal_year, message: '地域指数（都道府県名またはハローワーク番号）が見つかりません' };

  let basicYen = ceilByIndex(base, regionIndex);
  let minimumWageApplied = false;
  if (input.minimumWageYen !== undefined) {
    const base0 = row.yen[0];
    const base0Regional = base0 === null ? null : ceilByIndex(base0, regionIndex);
    if (base0Regional !== null && base0Regional < input.minimumWageYen) {
      // 最低賃金を基準値（0年）とし、能力・経験調整指数を乗じる（切り上げ）
      const idx = v.ability_experience_index[String(input.years)];
      basicYen = Math.ceil((input.minimumWageYen * Math.round(idx * 10)) / 1000);
      minimumWageApplied = true;
    }
  }
  const retirementYen = Math.ceil((basicYen * v.retirement_rate_percent) / 100);
  return {
    status: 'ok',
    fiscalYear: v.fiscal_year,
    notice: v.notice,
    basicYen,
    commuteYen: v.commute_allowance_yen_per_hour,
    retirementYen,
    regionIndex,
    minimumWageApplied,
    message: `${v.wareki}（${v.notice}）${row.name}・勤続${input.years}年・地域指数${regionIndex}`,
  };
}

/** 一般通勤手当（時給）。値表に無い年度は null */
export function getGeneralCommuteAllowance(asOf: string | Date): number | null {
  return getGeneralWageVersion(asOf)?.commute_allowance_yen_per_hour ?? null;
}
