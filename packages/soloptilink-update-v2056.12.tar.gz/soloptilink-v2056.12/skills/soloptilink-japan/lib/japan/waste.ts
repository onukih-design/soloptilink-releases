/**
 * lib/japan/waste.ts — 廃棄物処理・リサイクルDNA
 *
 * 法令カバレッジ:
 *  - 廃棄物処理法 (廃掃法 S45法律137) 一般廃棄物/産業廃棄物/特別管理
 *  - 産業廃棄物管理票 (マニフェスト) 制度 (廃掃法12条の3)
 *  - 電子マニフェスト (JWNET 公益財団法人日本産業廃棄物処理振興センター)
 *  - 容器包装リサイクル法 (H7法律112)
 *  - 家電リサイクル法 (家リ法 H10法律97 — エアコン/TV/冷蔵庫/洗濯機)
 *  - 自動車リサイクル法 (H14法律87)
 *  - 食品リサイクル法 (H12法律116)
 *  - 建設リサイクル法 (建リ法 H12法律104 — 80m²以上)
 *  - 小型家電リサイクル法 (H24法律57)
 *  - フロン排出抑制法 (H13法律64 / H27改正)
 *  - 資源有効利用促進法 (H3法律48)
 *
 * 参考: 環境省 環境再生・資源循環局, JWNET (sjc.or.jp), 産廃情報ネット
 *
 * 法定値 (フロンの点検周期・報告の閾値と期限、委託契約書の追加の記載の施行日) は
 * lib/japan/env_energy_legal_values.ts の値表 (出典・基準日・取得日つき) から読む (REQ-171)。
 */

import {
  requireEnvEnergyLegalNumber as legalNumber,
  requireEnvEnergyLegalString as legalString,
} from './env_energy_legal_values';

// ============================================================================
// 1. 廃棄物の分類 (廃掃法2条)
// ============================================================================

export type WasteCategory =
  | 'general_household' // 一般廃棄物 (家庭系)
  | 'general_business' // 一般廃棄物 (事業系)
  | 'industrial' // 産業廃棄物
  | 'industrial_special' // 特別管理産業廃棄物
  | 'general_special'; // 特別管理一般廃棄物

/** 産業廃棄物 20種 (廃掃法施行令2条) */
export const INDUSTRIAL_WASTE_TYPES = [
  '燃え殻', '汚泥', '廃油', '廃酸', '廃アルカリ',
  '廃プラスチック類', '紙くず', '木くず', '繊維くず', '動植物性残さ',
  '動物系固形不要物', 'ゴムくず', '金属くず', 'ガラスくず・コンクリートくず・陶磁器くず',
  '鉱さい', 'がれき類', '動物のふん尿', '動物の死体', 'ばいじん',
  '13号廃棄物', // 政令で定める産業廃棄物を処分するために処理したもの
] as const;

/** 特別管理産業廃棄物 (廃掃法2条の4) */
export const SPECIAL_INDUSTRIAL_WASTE = [
  '廃油 (引火点70℃未満)', '廃酸 (pH≤2.0)', '廃アルカリ (pH≥12.5)',
  '感染性産業廃棄物', '廃PCB等', 'PCB汚染物', 'PCB処理物',
  '廃水銀等', '指定下水汚泥', '鉱さい (有害物質基準超)',
  '廃石綿等', '燃え殻 (有害物質基準超)', 'ばいじん (有害物質基準超)',
] as const;

/** 廃棄物分類の自動判定 */
export function classifyWaste(input: {
  source: 'household' | 'business';
  contents: string[];
  hasInfectious?: boolean;
  hasPCB?: boolean;
  hasAsbestos?: boolean;
  oilFlashPointC?: number;
  pH?: number;
}): { category: WasteCategory; reason: string; needsManifest: boolean } {
  // 特別管理判定
  if (input.hasInfectious || input.hasPCB || input.hasAsbestos) {
    return {
      category: 'industrial_special',
      reason: `特別管理 (${input.hasInfectious ? '感染性' : input.hasPCB ? 'PCB' : '石綿'})`,
      needsManifest: true,
    };
  }
  if (input.oilFlashPointC !== undefined && input.oilFlashPointC < 70) {
    return { category: 'industrial_special', reason: '廃油 引火点70℃未満', needsManifest: true };
  }
  if (input.pH !== undefined && (input.pH <= 2.0 || input.pH >= 12.5)) {
    return { category: 'industrial_special', reason: 'pH 2.0以下 or 12.5以上 (廃酸/廃アルカリ)', needsManifest: true };
  }

  // 産業廃棄物判定
  const isIndustrial =
    input.source === 'business' &&
    input.contents.some((c) =>
      (INDUSTRIAL_WASTE_TYPES as readonly string[]).some((t) => c.includes(t.replace(/くず|類| 等/g, '')))
    );
  if (isIndustrial) {
    return { category: 'industrial', reason: '事業活動由来 + 政令20種該当', needsManifest: true };
  }

  // 一般廃棄物
  return {
    category: input.source === 'household' ? 'general_household' : 'general_business',
    reason: input.source === 'household' ? '家庭系一般廃棄物 (市町村処理責務)' : '事業系一般廃棄物',
    needsManifest: false,
  };
}

// ============================================================================
// 2. マニフェスト制度 (廃掃法12条の3 + JWNET 電子マニフェスト)
// ============================================================================

export type ManifestKind = 'paper' | 'electronic'; // 紙マニフェスト / 電子マニフェスト

export interface Manifest {
  kind: ManifestKind;
  manifestNumber: string; // 11桁 紙 / 12桁 電子
  issueDate: Date;
  exhauster: string; // 排出事業者
  collector: string; // 収集運搬業者
  disposer: string; // 処分業者
  finalDisposalSite: string;
  wasteType: string;
  weightKg: number;
  // フロー追跡
  a_collected?: Date; // A票: 排出事業者控
  b1_to_collector?: Date;
  b2_to_disposer?: Date;
  c1_to_disposer?: Date;
  c2_to_collector?: Date;
  d_to_exhauster?: Date; // D票: 処分終了 — 90日以内に返送必須
  e_final_disposal?: Date; // E票: 最終処分終了 — 180日以内
}

/** マニフェストの 90/180 日ルール検証 (廃掃法12条の3) */
export function validateManifestFlow(m: Manifest, today: Date = new Date()): {
  compliant: boolean;
  alerts: string[];
} {
  const alerts: string[] = [];
  const ms90 = 90 * 86400000;
  const ms180 = 180 * 86400000;
  const issuedMs = today.getTime() - m.issueDate.getTime();

  if (!m.d_to_exhauster && issuedMs > ms90) {
    alerts.push('D票 90日経過: 処分終了通知未受領 — 都道府県知事へ報告義務 (12条の3 第8項)');
  }
  if (!m.e_final_disposal && issuedMs > ms180) {
    alerts.push('E票 180日経過: 最終処分終了通知未受領 — 都道府県知事へ報告義務');
  }
  if (m.kind === 'paper') {
    alerts.push('紙マニフェスト: 5年間保存義務 (規則8条の26)');
  }
  return { compliant: alerts.length === 0, alerts };
}

/** 電子マニフェスト (JWNET) 義務化対象 (R2.4施行) */
export function isJwnetMandatory(annualSpecialWasteWeightTon: number): boolean {
  // 前々年度に特別管理産業廃棄物を 50t 以上発生させた多量排出事業者は電子マニフェスト義務化
  return annualSpecialWasteWeightTon >= 50;
}

// ============================================================================
// 3. 家電リサイクル法 (H10法律97)
// ============================================================================

/** 家電4品目 + リサイクル料金 (R6目安) */
export const HOME_APPLIANCE_RECYCLING_FEES = {
  air_conditioner: { ja: 'エアコン', feeJpy: 990, code: '01' },
  tv_crt: { ja: 'ブラウン管TV (15型以下)', feeJpy: 1320, code: '02' },
  tv_lcd_small: { ja: '液晶/プラズマTV (15型以下)', feeJpy: 1870, code: '02' },
  tv_lcd_large: { ja: '液晶/プラズマTV (16型以上)', feeJpy: 2970, code: '02' },
  refrigerator_small: { ja: '冷蔵庫 (170L以下)', feeJpy: 3740, code: '03' },
  refrigerator_large: { ja: '冷蔵庫 (171L以上)', feeJpy: 4730, code: '03' },
  washer_dryer: { ja: '洗濯機/衣類乾燥機', feeJpy: 2530, code: '04' },
} as const;

/**
 * 家電リサイクル料金の概算。料金は製造業者 (メーカー) ごと・品目の大きさごとに公表され改定されるため、
 * 上の表は一律の参考値 (令和6年の目安) で、請求額や見積額として使ってはならない (要一次確認: 製造業者の公表料金)。
 * 結果には isReferenceOnly=true を付け、画面・帳票では「参考値」と表示すること。
 */
export function calcApplianceRecyclingFee(
  items: { type: keyof typeof HOME_APPLIANCE_RECYCLING_FEES; qty: number }[]
): { totalJpy: number; breakdown: { item: string; subtotal: number }[]; isReferenceOnly: true; note: string } {
  const breakdown = items.map((i) => ({
    item: HOME_APPLIANCE_RECYCLING_FEES[i.type].ja,
    subtotal: HOME_APPLIANCE_RECYCLING_FEES[i.type].feeJpy * i.qty,
  }));
  return {
    totalJpy: breakdown.reduce((s, b) => s + b.subtotal, 0),
    breakdown,
    isReferenceOnly: true,
    note: '参考値です。家電リサイクル料金は製造業者ごとに公表され改定されます。実際の料金は各製造業者の公表料金 (家電リサイクル券センターの料金一覧) で確認してください',
  };
}

// ============================================================================
// 4. 建設リサイクル法 (H12法律104)
// ============================================================================

/** 建設リサイクル法 対象工事の判定 (建リ法9条) */
export function requiresConstructionRecyclingNotice(input: {
  workType: 'new_build' | 'demolition' | 'renovation' | 'civil';
  floorAreaM2?: number;
  contractValueJpy?: number;
}): { required: boolean; reason: string } {
  switch (input.workType) {
    case 'demolition':
      if ((input.floorAreaM2 ?? 0) >= 80) {
        return { required: true, reason: '解体工事 80m²以上 — 工事7日前までに知事届出' };
      }
      break;
    case 'new_build':
      if ((input.floorAreaM2 ?? 0) >= 500) {
        return { required: true, reason: '新築工事 500m²以上 — 知事届出' };
      }
      break;
    case 'renovation':
      if ((input.contractValueJpy ?? 0) >= 100_000_000) {
        return { required: true, reason: '修繕模様替 1億円以上 — 知事届出' };
      }
      break;
    case 'civil':
      if ((input.contractValueJpy ?? 0) >= 5_000_000) {
        return { required: true, reason: '土木工事 500万円以上 — 知事届出' };
      }
      break;
  }
  return { required: false, reason: '対象外規模' };
}

// ============================================================================
// 5. フロン排出抑制法 (H13法律64 + H27改正)
// ============================================================================

export type FluorocarbonEquipmentKind = 'commercial_ac' | 'commercial_refrigeration' | 'industrial_chiller';

/**
 * フロン排出抑制法 第一種特定製品の点検頻度 (値表)
 *   出典: 環境省・経済産業省「フロン排出抑制法の概要【機器ユーザー編】」https://www.env.go.jp/earth/furon/files/outline_02.pdf
 *         根拠は第一種特定製品の管理者の判断の基準となるべき事項 (平成26年経済産業省・環境省告示第13号)
 *   簡易点検: すべての機器 3か月に1回以上 (常時監視システムを用いる場合を除く)
 *   定期点検: 冷凍冷蔵機器 7.5kW以上 1年に1回以上 / エアコンディショナー 50kW以上 1年・7.5kW以上50kW未満 3年に1回以上
 *   kW は圧縮機の電動機の定格出力 (同じ冷媒系統は合算)。
 */
export const FLUOROCARBON_INSPECTION_RULES = {
  simpleInspectionMonths: legalNumber('fluoro.simple_inspection_months'),
  periodicThresholdKw: legalNumber('fluoro.periodic_threshold_kw'),
  acLargeThresholdKw: legalNumber('fluoro.ac_large_threshold_kw'),
  periodicMonths: {
    refrigeration: legalNumber('fluoro.periodic_months_refrigeration'),
    acLarge: legalNumber('fluoro.periodic_months_ac_large'),
    acMedium: legalNumber('fluoro.periodic_months_ac_medium'),
  },
} as const;

/** フロン排出抑制法 第一種特定製品の点検頻度 (簡易点検と定期点検を別々に返す) */
export function getFluorocarbonInspectionInterval(input: {
  kind: FluorocarbonEquipmentKind;
  ratedKw: number;
  /** industrial_chiller の用途。空調用はエアコンディショナー、冷凍冷蔵用は冷凍冷蔵機器の頻度。不明なら頻度の高い1年で扱う */
  use?: 'air_conditioning' | 'refrigeration';
}): { intervalMonths: number; simpleInspectionMonths: number; periodicInspectionMonths: number | null; reason: string } {
  const R = FLUOROCARBON_INSPECTION_RULES;
  const simple = R.simpleInspectionMonths;
  if (!(input.ratedKw >= R.periodicThresholdKw)) {
    return { intervalMonths: simple, simpleInspectionMonths: simple, periodicInspectionMonths: null, reason: `簡易点検 3か月に1回以上 (定格出力 ${R.periodicThresholdKw}kW 未満は定期点検の対象外)` };
  }
  const isAc = input.kind === 'commercial_ac' || (input.kind === 'industrial_chiller' && input.use === 'air_conditioning');
  const isRefrigeration = input.kind === 'commercial_refrigeration' || (input.kind === 'industrial_chiller' && input.use === 'refrigeration');
  let periodic: number;
  let reason: string;
  if (isAc) {
    if (input.ratedKw >= R.acLargeThresholdKw) { periodic = R.periodicMonths.acLarge; reason = 'エアコンディショナー 50kW以上: 定期点検 1年に1回以上 + 簡易点検 3か月に1回以上'; }
    else { periodic = R.periodicMonths.acMedium; reason = 'エアコンディショナー 7.5kW以上50kW未満: 定期点検 3年に1回以上 + 簡易点検 3か月に1回以上'; }
  } else if (isRefrigeration) {
    periodic = R.periodicMonths.refrigeration; reason = '冷凍冷蔵機器 7.5kW以上: 定期点検 1年に1回以上 + 簡易点検 3か月に1回以上';
  } else {
    periodic = R.periodicMonths.refrigeration; reason = 'チラーの用途 (空調用/冷凍冷蔵用) が不明のため、頻度の高い 1年に1回以上で扱う (用途を確認してください) + 簡易点検 3か月に1回以上';
  }
  return { intervalMonths: periodic, simpleInspectionMonths: simple, periodicInspectionMonths: periodic, reason };
}

/**
 * フロン算定漏えい量報告 (事業者単位で年度1000t-CO2以上で報告義務。閾値は値表 fluoro.report_threshold_t)
 *   フロン類算定漏えい量等の報告等に関する命令 3条 (特定漏えい者 = 全ての管理第一種特定製品の算定漏えい量の合計が千トン以上の者)
 *   ★旧版は「事業所からの」と書いていた。判定は事業者 (法人) 単位で、1,000t以上の事業所は報告書の内訳 (命令4条2項6号) に書く。
 */
export function requiresFluorocarbonLeakReport(annualLeakageTCO2: number): {
  required: boolean;
  reason: string;
} {
  if (annualLeakageTCO2 >= legalNumber('fluoro.report_threshold_t')) {
    return { required: true, reason: '事業者単位の年度の算定漏えい量が1,000t-CO2以上 — 翌年度7月末日までに事業所管大臣へ報告義務 (命令3条・4条)' };
  }
  return { required: false, reason: '報告閾値未満 (事業者単位で1,000t-CO2未満)' };
}

// ---- 日付の計算 (YYYY-MM-DD・暦日。月末は末日に丸める) ----
function ymdParts(ymd: string): [number, number, number] {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(ymd);
  if (!m) throw new Error(`日付は YYYY-MM-DD で渡してください: ${ymd}`);
  return [Number(m[1]), Number(m[2]), Number(m[3])];
}
function daysInMonthOf(y: number, m: number): number {
  return [31, (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1];
}
/** 月を足す (例: 2026-11-30 + 3か月 → 2027-02-28)。辞書 fluorocarbon-emission-control の「月末日補正」と同じ規則 */
export function addMonthsYmd(ymd: string, months: number): string {
  const [y, m, d] = ymdParts(ymd);
  const idx = y * 12 + (m - 1) + months;
  const ty = Math.floor(idx / 12);
  const tm = (idx % 12) + 1;
  const td = Math.min(d, daysInMonthOf(ty, tm));
  return `${ty}-${String(tm).padStart(2, '0')}-${String(td).padStart(2, '0')}`;
}

/**
 * 次回の簡易点検・定期点検の期日 (前回の点検日、点検が無ければ設置日 + 周期。月末は末日へ)。
 *   基準日を渡すと期日超過 (基準日が期日より後) を返す。期日当日は超過ではない。
 *   ★「3か月に1回以上」の期日の数え方 (当日を含むか) は告示に明記が無いため、辞書と同じ「基準日＋周期」とした (要確認)。
 */
export function getFluorocarbonNextDueDates(input: {
  kind: FluorocarbonEquipmentKind;
  ratedKw: number;
  use?: 'air_conditioning' | 'refrigeration';
  installedOn: string;
  lastSimpleOn?: string;
  lastPeriodicOn?: string;
  baseDate?: string;
}): { nextSimpleDue: string; nextPeriodicDue: string | null; simpleOverdue: boolean | null; periodicOverdue: boolean | null; reason: string } {
  const iv = getFluorocarbonInspectionInterval({ kind: input.kind, ratedKw: input.ratedKw, use: input.use });
  const nextSimpleDue = addMonthsYmd(input.lastSimpleOn ?? input.installedOn, iv.simpleInspectionMonths);
  const nextPeriodicDue = iv.periodicInspectionMonths === null ? null : addMonthsYmd(input.lastPeriodicOn ?? input.installedOn, iv.periodicInspectionMonths);
  const bd = input.baseDate;
  return {
    nextSimpleDue,
    nextPeriodicDue,
    simpleOverdue: bd ? bd > nextSimpleDue : null,
    periodicOverdue: bd ? (nextPeriodicDue === null ? false : bd > nextPeriodicDue) : null,
    reason: iv.reason,
  };
}

/**
 * フロン類算定漏えい量 (命令2条): フロン類の種類ごとに (整備時の充塡量 − 整備時の回収量) [kg] × 地球温暖化係数 ÷ 1000 [t-CO2] を合計。
 *   地球温暖化係数は告示値を部品が持っていない (値表 fluoro.gwp_table は未転記) ため、利用者が入力する。無い冷媒があれば計算しない。
 *   種類ごとの差が負になったときは 0 とし注記する (要確認)。設置時の充塡・廃棄時の回収は入力に含めないこと。
 */
export function calcFluorocarbonLeakage(records: { gas: string; chargedKg: number; recoveredKg: number; gwp?: number }[]): {
  status: 'ok' | 'unverified';
  byGas: { gas: string; netKg: number; gwp: number | null; tCo2: number | null }[];
  totalTCo2: number | null;
  notes: string[];
} {
  const notes: string[] = [];
  const map = new Map<string, { charged: number; recovered: number; gwp: number | null }>();
  for (const r of records) {
    const cur = map.get(r.gas) ?? { charged: 0, recovered: 0, gwp: null };
    cur.charged += r.chargedKg;
    cur.recovered += r.recoveredKg;
    if (typeof r.gwp === 'number' && r.gwp > 0) {
      if (cur.gwp !== null && cur.gwp !== r.gwp) notes.push(`${r.gas}: 地球温暖化係数が行ごとに違います (${cur.gwp} と ${r.gwp})`);
      cur.gwp = r.gwp;
    }
    map.set(r.gas, cur);
  }
  const byGas = [...map.entries()].map(([gas, v]) => {
    let netKg = v.charged - v.recovered;
    if (netKg < 0) { notes.push(`${gas}: 回収量が充塡量を上回るため 0 として扱いました (要確認)`); netKg = 0; }
    return { gas, netKg, gwp: v.gwp, tCo2: v.gwp === null ? null : (netKg * v.gwp) / 1000 };
  });
  const missing = byGas.filter((g) => g.gwp === null).map((g) => g.gas);
  if (missing.length) {
    notes.push(`地球温暖化係数が入力されていない冷媒があるため計算していません: ${missing.join('、')} (告示の値を確認して入力してください)`);
    return { status: 'unverified', byGas, totalTCo2: null, notes };
  }
  return { status: 'ok', byGas, totalTCo2: byGas.reduce((s, g) => s + (g.tCo2 as number), 0), notes };
}

/** 報告の要否と期限: 年度 (4/1〜3/31) の算定漏えい量が1,000t以上なら、翌年度の7月末日までに報告 (命令3条・4条1項) */
export function judgeFluorocarbonReport(p: { totalTCo2: number; dataFiscalYear: number }): { required: boolean; deadline: string | null; reason: string } {
  const required = p.totalTCo2 >= legalNumber('fluoro.report_threshold_t');
  const deadline = `${p.dataFiscalYear + 1}-${legalString('fluoro.report_due_mmdd')}`;
  return {
    required,
    deadline: required ? deadline : null,
    reason: required
      ? `${p.dataFiscalYear}年度の算定漏えい量 ${p.totalTCo2} t-CO2 ≥ 1,000t (事業者単位) → ${deadline} までに事業所管大臣へ報告`
      : `${p.dataFiscalYear}年度の算定漏えい量 ${p.totalTCo2} t-CO2 は1,000t未満 → 報告義務なし`,
  };
}

// ============================================================================
// 6. 容器包装リサイクル法 (H7法律112)
// ============================================================================

/** 特定事業者の再商品化義務 — 規模別 */
export function isPackagingRecyclingObligated(input: {
  industry: 'manufacturing' | 'commerce' | 'others';
  annualSalesJpy: number;
  employeeCount: number;
}): { obligated: boolean; reason: string } {
  // 小規模事業者除外: 製造業 売上2.4億以下 + 従業員20人以下 / 商業 売上7000万以下 + 5人以下
  if (input.industry === 'manufacturing') {
    if (input.annualSalesJpy <= 240_000_000 && input.employeeCount <= 20) {
      return { obligated: false, reason: '小規模事業者 (製造業 売上2.4億+従業員20人以下) 適用除外' };
    }
  } else {
    if (input.annualSalesJpy <= 70_000_000 && input.employeeCount <= 5) {
      return { obligated: false, reason: '小規模事業者 (商業 売上7000万+5人以下) 適用除外' };
    }
  }
  return { obligated: true, reason: '特定事業者 — 日本容器包装リサイクル協会経由で再商品化義務' };
}

// ============================================================================
// 7. 廃棄物処理業 許可
// ============================================================================

export interface DisposalLicense {
  kind: 'collection_transport' | 'intermediate' | 'final_disposal';
  prefecture: string; // 許可は都道府県/政令市単位
  validUntil: Date;
  scope: WasteCategory[];
}

/** 廃棄物処理業許可の有効期限チェック (廃掃法14条 — 5年更新) */
export function checkDisposalLicenseExpiry(license: DisposalLicense, today: Date = new Date()): {
  active: boolean;
  daysRemaining: number;
  warning: string | null;
} {
  const daysRemaining = Math.ceil((license.validUntil.getTime() - today.getTime()) / 86400000);
  return {
    active: daysRemaining > 0,
    daysRemaining,
    warning: daysRemaining < 90 ? `${license.kind} 許可の有効期限まで${daysRemaining}日 — 更新申請を` : null,
  };
}

// ============================================================================
// 8. 産業廃棄物の委託契約書の法定記載事項 (廃掃法施行令6条の2第4号・施行規則8条の4・8条の4の2)
// ============================================================================

/**
 * 委託契約書の条項の有無 (true = 条項がある / 書面が添付されている)。
 *   出典: e-Gov 廃棄物の処理及び清掃に関する法律施行令 6条の2 第4号・同法施行規則 8条の4・8条の4の2 (いずれも版 2026-09-16、2026-10-03 取得)
 */
export interface WasteConsignmentContractItems {
  /** 令6条の2第4号イ 種類及び数量 */
  wasteTypeAndQuantity?: boolean;
  /** 同ロ 運搬の最終目的地の所在地 (運搬の委託) */
  transportFinalDestination?: boolean;
  /** 同ハ 処分又は再生の場所の所在地・方法・施設の処理能力 (処分の委託) */
  disposalSiteMethodCapacity?: boolean;
  /** 同ニ 輸入された廃棄物である旨 */
  importedWasteStatement?: boolean;
  /** 同ホ 最終処分の場所の所在地・方法・処理能力 (中間処理の委託) */
  finalDisposalSiteMethodCapacity?: boolean;
  /** 規則8条の4の2 一 有効期間 */
  validityPeriod?: boolean;
  /** 二 料金 */
  fee?: boolean;
  /** 三 受託者の事業の範囲 (許可業者のとき) */
  licenseScope?: boolean;
  /** 四 積替え・保管の場所の所在地・保管できる種類・保管上限 (運搬で積替え保管を行うとき) */
  transshipmentSiteDetails?: boolean;
  /** 五 安定型産業廃棄物の混合の許否等 (四の場合で安定型のとき) */
  mixingPermission?: boolean;
  /** 六イ 性状及び荷姿 */
  infoPropertiesAndPacking?: boolean;
  /** 六ロ 通常の保管状況の下での性状の変化 */
  infoPropertyChange?: boolean;
  /** 六ハ 他の廃棄物との混合等により生ずる支障 */
  infoMixingHazard?: boolean;
  /** 六ニ JIS C0950 の含有マークの表示 (廃パソコン等7品目で表示があるとき) */
  infoContentMark?: boolean;
  /** 六ホ 石綿含有・水銀使用製品・水銀含有ばいじん等が含まれる旨 */
  infoAsbestosMercury?: boolean;
  /** 六ヘ 第一種指定化学物質が含まれ又は付着している旨・名称・量又は割合 (2026-01-01 追加) */
  infoPrtr?: boolean;
  /** 六ト その他取り扱う際に注意すべき事項 */
  infoOtherCautions?: boolean;
  /** 七 六の情報に変更があった場合の伝達方法 */
  infoChangeProcedure?: boolean;
  /** 八 受託業務終了時の報告 */
  completionReport?: boolean;
  /** 九 契約解除時の処理されない廃棄物の取扱い */
  terminationHandling?: boolean;
  /** 規則8条の4 許可証の写し等の添付 */
  licenseCopyAttached?: boolean;
}

export interface WasteConsignmentContract {
  /** transport = 収集運搬の委託 / disposal = 処分 (再生) の委託 */
  kind: 'transport' | 'disposal';
  /** 書面による契約か (令6条の2第4号) */
  inWriting: boolean;
  /** 締結日 (YYYY-MM-DD) */
  concludedOn: string;
  /** 最後に更新した日 (YYYY-MM-DD) */
  renewedOn?: string;
  facts?: {
    importedWaste?: boolean;
    /** 処分の委託のうち中間処理 (最終処分以外) */
    intermediateDisposal?: boolean;
    /** 受託者が許可業者 (省略時 true) */
    contractorLicensed?: boolean;
    /** 運搬の委託で積替え・保管を行う */
    transshipment?: boolean;
    stableTypeWaste?: boolean;
    /** 廃パソコン等7品目で含有マークの表示がある */
    contentMarkProduct?: boolean;
    /** 石綿含有・水銀使用製品・水銀含有ばいじん等を含む */
    asbestosOrMercury?: boolean;
    /** 委託者が化管法の第一種指定化学物質等取扱事業者 */
    prtrHandler?: boolean;
    /** 第一種指定化学物質 (化管法5条1項で把握する物質) が含まれ又は付着している */
    prtrSubstanceContained?: boolean;
  };
  items: WasteConsignmentContractItems;
}

/**
 * 委託契約書を法定記載事項で検査する。欠けている条項の番号を返す (missing) 。
 *   番号: written / rei-i〜rei-ho (令6条の2第4号) / ki-1〜ki-9・ki-6-i〜ki-6-to (規則8条の4の2) / attach (規則8条の4)
 *   第一種指定化学物質の記載 (ki-6-he) は 2026-01-01 から。2025-04-22 より前に締結し更新していない契約は、更新までは従前の例 (令和7年環境省令第15号 附則2条)。
 *   ★2025-04-22〜2025-12-31 に締結した契約は 2026-01-01 から必要と読んだ (安全側)。士業 (行政書士・弁護士) の確認を推奨。
 */
export function checkWasteConsignmentContract(c: WasteConsignmentContract, opts: { baseDate: string }): {
  ok: boolean;
  missing: string[];
  findings: { id: string; basis: string; label: string }[];
  notes: string[];
} {
  const f = { contractorLicensed: true, ...(c.facts ?? {}) };
  const it = c.items ?? {};
  const findings: { id: string; basis: string; label: string }[] = [];
  const notes: string[] = [];
  const need = (cond: boolean, present: boolean | undefined, id: string, basis: string, label: string) => {
    if (cond && present !== true) findings.push({ id, basis, label });
  };
  const R = '廃掃法施行令6条の2第4号';
  const K = '廃掃法施行規則8条の4の2';
  if (c.inWriting !== true) findings.push({ id: 'written', basis: R, label: '委託契約は書面で行う必要があります' });
  need(true, it.wasteTypeAndQuantity, 'rei-i', `${R}イ`, '委託する産業廃棄物の種類及び数量');
  need(c.kind === 'transport', it.transportFinalDestination, 'rei-ro', `${R}ロ`, '運搬の最終目的地の所在地');
  need(c.kind === 'disposal', it.disposalSiteMethodCapacity, 'rei-ha', `${R}ハ`, '処分又は再生の場所の所在地・方法・施設の処理能力');
  need(c.kind === 'disposal' && f.importedWaste === true, it.importedWasteStatement, 'rei-ni', `${R}ニ`, '輸入された廃棄物である旨');
  need(c.kind === 'disposal' && f.intermediateDisposal === true, it.finalDisposalSiteMethodCapacity, 'rei-ho', `${R}ホ`, '最終処分の場所の所在地・方法・施設の処理能力');
  need(true, it.validityPeriod, 'ki-1', `${K}第1号`, '委託契約の有効期間');
  need(true, it.fee, 'ki-2', `${K}第2号`, '委託者が受託者に支払う料金');
  need(f.contractorLicensed !== false, it.licenseScope, 'ki-3', `${K}第3号`, '受託者の許可の事業の範囲');
  need(c.kind === 'transport' && f.transshipment === true, it.transshipmentSiteDetails, 'ki-4', `${K}第4号`, '積替え・保管の場所の所在地・保管できる種類・保管上限');
  need(c.kind === 'transport' && f.transshipment === true && f.stableTypeWaste === true, it.mixingPermission, 'ki-5', `${K}第5号`, '積替え・保管の場所で他の廃棄物と混合することの許否等');
  need(true, it.infoPropertiesAndPacking, 'ki-6-i', `${K}第6号イ`, '性状及び荷姿に関する事項');
  need(true, it.infoPropertyChange, 'ki-6-ro', `${K}第6号ロ`, '通常の保管状況の下での腐敗・揮発等の性状の変化');
  need(true, it.infoMixingHazard, 'ki-6-ha', `${K}第6号ハ`, '他の廃棄物との混合等により生ずる支障');
  need(f.contentMarkProduct === true, it.infoContentMark, 'ki-6-ni', `${K}第6号ニ`, '含有マーク (JIS C0950) の表示に関する事項');
  need(f.asbestosOrMercury === true, it.infoAsbestosMercury, 'ki-6-ho', `${K}第6号ホ`, '石綿含有産業廃棄物・水銀使用製品産業廃棄物・水銀含有ばいじん等が含まれる旨');
  // 第6号ヘ (第一種指定化学物質) — 施行日と経過措置
  const effective = legalString('waste.contract_prtr_item_effective');
  const cutoff = legalString('waste.contract_prtr_transition_cutoff');
  const latest = c.renewedOn && c.renewedOn > c.concludedOn ? c.renewedOn : c.concludedOn;
  const prtrApplies = f.prtrHandler === true && f.prtrSubstanceContained === true;
  const prtrInForce = opts.baseDate >= effective && latest >= cutoff;
  if (prtrApplies && !prtrInForce) {
    notes.push(opts.baseDate < effective
      ? `第一種指定化学物質の記載 (第6号ヘ) は ${effective} から必要です (基準日 ${opts.baseDate} は施行前)`
      : `締結 (更新) 日 ${latest} は ${cutoff} より前のため、更新までは第6号ヘの記載は不要です (令和7年環境省令第15号 附則2条)。更新時に追記してください`);
  }
  need(prtrApplies && prtrInForce, it.infoPrtr, 'ki-6-he', `${K}第6号ヘ (令和8年1月1日施行)`, '第一種指定化学物質が含まれ又は付着している旨・物質の名称・量又は割合');
  need(true, it.infoOtherCautions, 'ki-6-to', `${K}第6号ト`, 'その他取り扱う際に注意すべき事項');
  need(true, it.infoChangeProcedure, 'ki-7', `${K}第7号`, '第6号の情報に変更があった場合の伝達方法');
  need(true, it.completionReport, 'ki-8', `${K}第8号`, '受託業務終了時の受託者の委託者への報告');
  need(true, it.terminationHandling, 'ki-9', `${K}第9号`, '契約を解除した場合の処理されない産業廃棄物の取扱い');
  need(true, it.licenseCopyAttached, 'attach', '廃掃法施行規則8条の4', '受託者の許可証の写し等の添付');
  return { ok: findings.length === 0, missing: findings.map((x) => x.id), findings, notes };
}
