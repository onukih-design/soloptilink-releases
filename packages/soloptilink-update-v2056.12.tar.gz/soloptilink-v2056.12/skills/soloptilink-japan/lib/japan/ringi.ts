/**
 * @fileoverview Phase 10 - 稟議システム DNA
 *
 * 日本企業特有の「稟議書 + 決裁権限規程 + 合議 + 代理決裁」を完全モデル化。
 * Claude Code は「Approval Flow を作りましょう」と一般論を返すだけだが、
 * 本モジュールは:
 *   1. 決裁権限規程 (職位 × 金額 × 案件種別) のテーブル化と判定エンジン
 *   2. 階層承認 (課長→部長→本部長→役員→社長) を職階組織図から自動生成
 *   3. 合議 (複数部門の同時承認) と並列/直列の混在フロー
 *   4. 代理決裁 (上長不在時の代決) と事後報告の自動化
 *   5. 緊急稟議 (先実行・後決裁) のリスク評価
 *   6. 差戻し・再稟議の履歴トレース
 *   7. 監査証跡 (J-SOX/内部統制対応)
 *
 * 全て Pure TypeScript。DB 連携は別レイヤ。
 *
 * ★承認の歯止め (JPO-FIX-016・判定は approval_guard.ts の1か所):
 *   起案者本人の承認・担当外の人の承認・担当者未設定の段の承認・段の省略・
 *   期間と範囲の外の代決 はすべて { ok:false, reason } で拒否し、段と文書の状態を変えない。
 *   代決した段には代決の記録 (proxyDecision) を残し、本人への後閲の依頼を
 *   doc.postReviewRequests に1件作る。
 */

import {
  checkNotApplicant,
  checkProxyGrant,
  findUsableGrant,
  makePostReviewRequest,
  type ProxyGrant,
  type ProxyDecisionRecord,
  type PostReviewRequest,
} from './approval_guard';
export type { ProxyGrant, ProxyDecisionRecord, PostReviewRequest } from './approval_guard';

// ============================================================================
// Types
// ============================================================================

/** 一般的な日本企業の職位階層 */
export type JobGrade =
  | 'staff'         // 一般社員
  | 'leader'        // 主任
  | 'subsection_chief' // 係長
  | 'manager'       // 課長
  | 'senior_manager' // 次長
  | 'general_manager' // 部長
  | 'division_head' // 本部長 / 事業部長
  | 'executive_officer' // 執行役員
  | 'director'      // 取締役
  | 'managing_director' // 常務
  | 'senior_managing_director' // 専務
  | 'vice_president' // 副社長
  | 'president'     // 社長
  | 'chairman';     // 会長

/** 案件種別 (決裁権限規程の代表分類) */
export type RingiCategory =
  | 'expense'         // 経費・接待
  | 'capital_invest'  // 設備投資
  | 'hire'            // 採用
  | 'salary_change'   // 給与改定
  | 'contract'        // 契約締結
  | 'system_invest'   // 情報システム投資
  | 'marketing'       // 広告宣伝
  | 'r_and_d'         // 研究開発
  | 'm_and_a'         // M&A
  | 'office_lease'    // オフィス賃借
  | 'travel_overseas' // 海外出張
  | 'donation'        // 寄付
  | 'pricing_change'  // 価格改定
  | 'product_launch'  // 新商品発売
  | 'other';

/** 決裁権限規程 1 行 */
export interface AuthorityRule {
  category: RingiCategory;
  /** 金額上限 (これ以下ならこの職位で決裁可) */
  maxAmountYen: number;
  /** この案件のこの金額帯までの最終決裁者 */
  finalApprover: JobGrade;
  /** 合議が必要な部門 */
  consultDepartments?: string[];
  /** 補足説明 */
  note?: string;
}

/** ステップ種別 */
export type StepKind = 'sequential' | 'parallel' | 'consult' | 'notify';

/** 承認ステップ */
export interface ApprovalStep {
  stepIndex: number;
  kind: StepKind;
  /** 承認者の職位 (組織から該当者を解決) */
  requiredGrade: JobGrade;
  /** 部門指定 (合議時など) */
  department?: string;
  /** 担当者 (実体の社員ID; 解決後に埋まる) */
  assigneeId?: string;
  status: 'pending' | 'approved' | 'rejected' | 'returned' | 'delegated' | 'skipped';
  decidedAt?: string; // ISO8601
  comment?: string;
  /** 代理決裁時の代理者ID */
  delegatedTo?: string;
  /** delegateStep で登録した代決の授権 (担当者 assigneeId は本人のまま残す) */
  proxyGrant?: ProxyGrant;
  /** 代決したときの記録 (本人・代決者・授権の番号・日時) */
  proxyDecision?: ProxyDecisionRecord;
}

/** 稟議書 */
export interface RingiDocument {
  ringiId: string;
  title: string;
  category: RingiCategory;
  applicantId: string;
  applicantGrade: JobGrade;
  department: string;
  /** 申請金額 (円) */
  amountYen: number;
  /** 起案理由 */
  rationale: string;
  /** 期待効果 */
  expectedEffect: string;
  /** リスクと対策 */
  risksAndMitigations: string;
  /** 添付資料 ID 配列 */
  attachmentIds: string[];
  /** 緊急稟議か */
  urgent: boolean;
  /** 緊急理由 (urgent=true 時必須) */
  urgentReason?: string;
  /** 起案日 ISO8601 */
  draftedAt: string;
  steps: ApprovalStep[];
  status: 'drafting' | 'in_review' | 'approved' | 'rejected' | 'returned' | 'cancelled';
  /** 完了日時 */
  completedAt?: string;
  /** 代決に伴う本人への後閲の依頼 (代決1回につき1件) */
  postReviewRequests?: PostReviewRequest[];
}

/** 組織ノード (簡易版・ツリー) */
export interface OrgNode {
  employeeId: string;
  name: string;
  grade: JobGrade;
  department: string;
  /** 上長 employeeId (社長は null) */
  reportsTo: string | null;
  /** 不在時の代理者 */
  proxyEmployeeId?: string;
}

// ============================================================================
// 決裁権限規程 標準テーブル (中堅企業典型例)
// ============================================================================

/**
 * 中堅企業 (社員 100-1000 名) の決裁権限規程の典型値。
 * 顧客企業ごとにカスタマイズして使う想定だが、デフォルト値として有用。
 */
export const STANDARD_AUTHORITY_RULES: AuthorityRule[] = [
  // 経費
  { category: 'expense', maxAmountYen: 50_000, finalApprover: 'manager', note: '5万円以下: 課長決裁' },
  { category: 'expense', maxAmountYen: 200_000, finalApprover: 'general_manager', note: '20万円以下: 部長決裁' },
  { category: 'expense', maxAmountYen: 1_000_000, finalApprover: 'executive_officer', note: '100万円以下: 執行役員決裁' },
  { category: 'expense', maxAmountYen: 5_000_000, finalApprover: 'director', note: '500万円以下: 取締役決裁' },
  { category: 'expense', maxAmountYen: Number.MAX_SAFE_INTEGER, finalApprover: 'president', note: '500万円超: 社長決裁' },

  // 設備投資
  { category: 'capital_invest', maxAmountYen: 1_000_000, finalApprover: 'general_manager' },
  { category: 'capital_invest', maxAmountYen: 10_000_000, finalApprover: 'executive_officer', consultDepartments: ['経理部', '経営企画部'] },
  { category: 'capital_invest', maxAmountYen: 50_000_000, finalApprover: 'director', consultDepartments: ['経理部', '経営企画部', '法務部'] },
  { category: 'capital_invest', maxAmountYen: Number.MAX_SAFE_INTEGER, finalApprover: 'chairman', consultDepartments: ['経理部', '経営企画部', '法務部', '監査室'], note: '取締役会付議' },

  // 採用
  { category: 'hire', maxAmountYen: 0, finalApprover: 'general_manager', note: '一般社員採用: 部長決裁' },
  { category: 'hire', maxAmountYen: 1, finalApprover: 'executive_officer', note: '管理職採用: 執行役員決裁' },
  { category: 'hire', maxAmountYen: 2, finalApprover: 'president', note: '役員採用: 社長決裁 + 取締役会承認' },

  // 契約
  { category: 'contract', maxAmountYen: 1_000_000, finalApprover: 'general_manager' },
  { category: 'contract', maxAmountYen: 10_000_000, finalApprover: 'executive_officer', consultDepartments: ['法務部'] },
  { category: 'contract', maxAmountYen: 100_000_000, finalApprover: 'director', consultDepartments: ['法務部', '経理部'] },
  { category: 'contract', maxAmountYen: Number.MAX_SAFE_INTEGER, finalApprover: 'president', consultDepartments: ['法務部', '経理部', '監査室'] },

  // 情報システム投資
  { category: 'system_invest', maxAmountYen: 500_000, finalApprover: 'general_manager' },
  { category: 'system_invest', maxAmountYen: 5_000_000, finalApprover: 'executive_officer', consultDepartments: ['情報システム部', 'セキュリティ部'] },
  { category: 'system_invest', maxAmountYen: Number.MAX_SAFE_INTEGER, finalApprover: 'director', consultDepartments: ['情報システム部', 'セキュリティ部', '経理部'] },

  // M&A
  { category: 'm_and_a', maxAmountYen: Number.MAX_SAFE_INTEGER, finalApprover: 'chairman', consultDepartments: ['経営企画部', '法務部', '経理部', '監査室'], note: 'M&Aは常に取締役会付議' },
];

// ============================================================================
// 決裁権限規程ルックアップ
// ============================================================================

/**
 * 案件 → 決裁権限の解決
 */
export function resolveAuthority(
  category: RingiCategory,
  amountYen: number,
  rules: AuthorityRule[] = STANDARD_AUTHORITY_RULES,
): AuthorityRule {
  const matches = rules
    .filter((r) => r.category === category)
    .sort((a, b) => a.maxAmountYen - b.maxAmountYen);

  for (const rule of matches) {
    if (amountYen <= rule.maxAmountYen) return rule;
  }
  // 最後のルール (上限なし)
  if (matches.length > 0) return matches[matches.length - 1];

  // フォールバック: 取締役決裁
  return {
    category,
    maxAmountYen: Number.MAX_SAFE_INTEGER,
    finalApprover: 'director',
    note: '該当規程なし (フォールバック)',
  };
}

// ============================================================================
// 承認ステップ自動生成 (起案者から最終決裁者まで)
// ============================================================================

const GRADE_RANK: Record<JobGrade, number> = {
  staff: 0,
  leader: 1,
  subsection_chief: 2,
  manager: 3,
  senior_manager: 4,
  general_manager: 5,
  division_head: 6,
  executive_officer: 7,
  director: 8,
  managing_director: 9,
  senior_managing_director: 10,
  vice_president: 11,
  president: 12,
  chairman: 13,
};

/**
 * 起案者の職位 → 最終決裁者の職位 までを 1 段ずつ階層承認。
 * + 合議部門は parallel で挿入。
 */
export function buildApprovalSteps(input: {
  applicantGrade: JobGrade;
  authority: AuthorityRule;
  /** 合議部門 (重複時は authority.consultDepartments を優先) */
  extraConsultDepartments?: string[];
}): ApprovalStep[] {
  const startRank = GRADE_RANK[input.applicantGrade];
  const endRank = GRADE_RANK[input.authority.finalApprover];
  const steps: ApprovalStep[] = [];
  let stepIndex = 0;

  // 階層承認 (起案者の 1 つ上から最終決裁者まで)
  for (let r = startRank + 1; r <= endRank; r++) {
    const grade = (Object.keys(GRADE_RANK) as JobGrade[]).find((g) => GRADE_RANK[g] === r);
    if (!grade) continue;
    steps.push({
      stepIndex: stepIndex++,
      kind: 'sequential',
      requiredGrade: grade,
      status: 'pending',
    });
  }

  // 合議 (parallel で挿入: 最終決裁の直前)
  const consults = [
    ...(input.authority.consultDepartments ?? []),
    ...(input.extraConsultDepartments ?? []),
  ];
  const dedup = Array.from(new Set(consults));
  if (dedup.length > 0) {
    // 最終決裁の直前に挿入
    const finalStep = steps.pop();
    for (const dept of dedup) {
      steps.push({
        stepIndex: stepIndex++,
        kind: 'consult',
        requiredGrade: 'general_manager',
        department: dept,
        status: 'pending',
      });
    }
    if (finalStep) {
      finalStep.stepIndex = stepIndex++;
      steps.push(finalStep);
    }
  }

  return steps;
}

// ============================================================================
// 承認・差戻し・代理決裁
// ============================================================================

/** 承認・差戻しの操作の追加情報 */
export interface StepActionOptions {
  /** 操作の日時 (ISO8601)。代決の期間の判定に使う。既定は実行時刻 */
  at?: string;
  /** 使ってよい代決の授権 (担当者本人以外が操作するときに必要) */
  proxyGrants?: ProxyGrant[];
}

/** 今の段 = 段の番号順で最初の「承認済みでない段」。pending 以外 (省略・差戻し等) なら先へ進ませない */
function currentStep(doc: RingiDocument): { step?: ApprovalStep; reason?: string } {
  if (doc.status !== 'in_review') {
    return { reason: `この稟議は審査中ではありません (状態: ${doc.status})。承認・差戻しはできません。` };
  }
  const ordered = [...doc.steps].sort((a, b) => a.stepIndex - b.stepIndex);
  const step = ordered.find((s) => s.status !== 'approved');
  if (!step) return { reason: '承認待ちの段がありません。' };
  if (step.status !== 'pending') {
    return { reason: `段${step.stepIndex + 1} が「${step.status}」のため、この段を飛ばして先へは進めません (段の省略)。` };
  }
  return { step };
}

/** 操作する人がこの段を扱えるか (担当者本人か、有効な代決の授権を持つ代決者か) */
function authorizeOnStep(
  doc: RingiDocument,
  step: ApprovalStep,
  actorId: string,
  at: string,
  grants: readonly ProxyGrant[] | undefined,
): { ok: boolean; reason?: string; grant?: ProxyGrant } {
  const self = checkNotApplicant(actorId, doc.applicantId);
  if (!self.ok) return self;
  if (!step.assigneeId) {
    return { ok: false, reason: `段${step.stepIndex + 1} の担当者が決まっていません。担当者を設定してから承認してください。` };
  }
  if (step.assigneeId === doc.applicantId) {
    return { ok: false, reason: `段${step.stepIndex + 1} の担当者が起案者本人です。別の担当者に付け替えてください (職務分掌)。` };
  }
  if (actorId === step.assigneeId) return { ok: true };
  const pool = [...(grants ?? []), ...(step.proxyGrant ? [step.proxyGrant] : [])];
  const found = findUsableGrant(pool, {
    principalId: step.assigneeId,
    proxyId: actorId,
    applicantId: doc.applicantId,
    at,
    category: doc.category,
    amountYen: doc.amountYen,
  });
  if (!found.grant) return { ok: false, reason: found.reason };
  return { ok: true, grant: found.grant };
}

export function approveStep(
  doc: RingiDocument,
  approverId: string,
  comment?: string,
  opts: StepActionOptions = {},
): {
  ok: boolean;
  reason?: string;
  nextStepIndex?: number;
  proxyRecord?: ProxyDecisionRecord;
  postReviewRequest?: PostReviewRequest;
} {
  const cur = currentStep(doc);
  if (!cur.step) return { ok: false, reason: cur.reason };
  const next = cur.step;
  const at = opts.at ?? new Date().toISOString();
  const auth = authorizeOnStep(doc, next, approverId, at, opts.proxyGrants);
  if (!auth.ok) return { ok: false, reason: auth.reason };

  next.status = 'approved';
  next.decidedAt = at;
  next.comment = comment;

  let proxyRecord: ProxyDecisionRecord | undefined;
  let postReviewRequest: PostReviewRequest | undefined;
  if (auth.grant) {
    // 代決: 記録を段に残し、本人への後閲の依頼を1件作る
    proxyRecord = {
      grantId: auth.grant.grantId,
      principalId: auth.grant.principalId,
      proxyId: auth.grant.proxyId,
      decidedAt: at,
      reason: auth.grant.reason,
    };
    next.proxyDecision = proxyRecord;
    next.delegatedTo = auth.grant.proxyId;
    next.comment = `代決 (本人 ${auth.grant.principalId} 不在・授権 ${auth.grant.grantId})${comment ? `: ${comment}` : ''}`;
    postReviewRequest = makePostReviewRequest({ documentId: doc.ringiId, stepIndex: next.stepIndex, grant: auth.grant, requestedAt: at });
    doc.postReviewRequests = [...(doc.postReviewRequests ?? []), postReviewRequest];
  }

  const remaining = [...doc.steps].sort((a, b) => a.stepIndex - b.stepIndex).find((s) => s.status !== 'approved');
  if (!remaining) {
    doc.status = 'approved';
    doc.completedAt = at;
    return { ok: true, proxyRecord, postReviewRequest };
  }
  return { ok: true, nextStepIndex: remaining.stepIndex, proxyRecord, postReviewRequest };
}

export function returnStep(
  doc: RingiDocument,
  approverId: string,
  reason: string,
  opts: StepActionOptions = {},
): { ok: boolean; reason?: string } {
  const cur = currentStep(doc);
  if (!cur.step) return { ok: false, reason: cur.reason };
  const next = cur.step;
  const at = opts.at ?? new Date().toISOString();
  const auth = authorizeOnStep(doc, next, approverId, at, opts.proxyGrants);
  if (!auth.ok) return { ok: false, reason: auth.reason };
  next.status = 'returned';
  next.decidedAt = at;
  next.comment = reason;
  doc.status = 'returned';
  return { ok: true };
}

/**
 * 代理決裁 (代決) の授権を今の段に登録する。担当者 (assigneeId) は本人のまま残し、
 * 代決者が承認したときに代決の記録と後閲の依頼を作る。授権 (期間・範囲つき) が無い付け替えは拒否する。
 */
export function delegateStep(
  doc: RingiDocument,
  fromEmployeeId: string,
  toEmployeeId: string,
  reason: string,
  grant?: ProxyGrant,
  opts: { at?: string } = {},
): { ok: boolean; reason?: string } {
  const cur = currentStep(doc);
  if (!cur.step) return { ok: false, reason: cur.reason };
  const next = cur.step;
  if (!next.assigneeId || next.assigneeId !== fromEmployeeId) {
    return { ok: false, reason: '代決を任せられるのは、この段の担当者本人だけです。' };
  }
  if (!grant) {
    return { ok: false, reason: '代決の授権 (期間と範囲) が無い付け替えはできません。授権を添えてください。' };
  }
  // 事前登録を認めるため、期間の開始前なら開始日で判定する (期間が過ぎた授権は登録できない)
  const today = opts.at ?? new Date().toISOString();
  const day = new Date(today).getTime() < new Date(`${grant.validFrom}T00:00:00+09:00`).getTime()
    ? grant.validFrom
    : today;
  const chk = checkProxyGrant({
    grant,
    principalId: fromEmployeeId,
    proxyId: toEmployeeId,
    applicantId: doc.applicantId,
    at: day,
    category: doc.category,
    amountYen: doc.amountYen,
  });
  if (!chk.ok) return { ok: false, reason: chk.reason };
  next.proxyGrant = grant;
  next.delegatedTo = toEmployeeId;
  next.comment = `代決の授権を登録: ${reason}`;
  return { ok: true };
}

// ============================================================================
// 緊急稟議 (先実行・後決裁) のリスク評価
// ============================================================================

/**
 * 緊急稟議のリスクスコア (0-100)。高いほど内部統制違反リスク大。
 *
 * 国税庁 / J-SOX 観点:
 *  - 金額が大きいほどリスク大
 *  - 取引先未審査ならリスク大
 *  - 同種の緊急稟議が頻発しているとリスク大 (慢性化 = 統制不全)
 */
export function evaluateUrgentRingiRisk(input: {
  amountYen: number;
  vendorPreScreened: boolean;
  recentUrgentCount30d: number; // 直近30日の緊急稟議件数 (この申請者)
  category: RingiCategory;
}): { score: number; level: 'low' | 'medium' | 'high' | 'critical'; reasons: string[] } {
  let score = 0;
  const reasons: string[] = [];

  if (input.amountYen >= 10_000_000) {
    score += 40;
    reasons.push('1000万円超: 金額面の統制リスク');
  } else if (input.amountYen >= 1_000_000) {
    score += 20;
    reasons.push('100万円超: 金額面の中リスク');
  } else if (input.amountYen >= 100_000) {
    score += 10;
  }

  if (!input.vendorPreScreened) {
    score += 25;
    reasons.push('取引先与信・反社チェック未実施');
  }

  if (input.recentUrgentCount30d >= 5) {
    score += 25;
    reasons.push(`緊急稟議が直近30日で ${input.recentUrgentCount30d} 件: 慢性化 = 統制不全の兆候`);
  } else if (input.recentUrgentCount30d >= 2) {
    score += 10;
  }

  if (['m_and_a', 'capital_invest', 'contract'].includes(input.category)) {
    score += 10;
    reasons.push(`案件種別 (${input.category}) は本来事前承認必須`);
  }

  let level: 'low' | 'medium' | 'high' | 'critical' = 'low';
  if (score >= 70) level = 'critical';
  else if (score >= 50) level = 'high';
  else if (score >= 30) level = 'medium';

  return { score: Math.min(100, score), level, reasons };
}

// ============================================================================
// 監査証跡 (J-SOX 内部統制対応)
// ============================================================================

export interface AuditEntry {
  ringiId: string;
  timestamp: string;
  actorId: string;
  actorGrade: JobGrade;
  action: 'draft' | 'submit' | 'approve' | 'reject' | 'return' | 'delegate' | 'cancel' | 'execute';
  stepIndex?: number;
  before?: unknown;
  after?: unknown;
  comment?: string;
  ipAddress?: string;
  userAgent?: string;
}

/**
 * 監査ログエントリ生成 (タンパープルーフのためハッシュチェーン推奨)
 */
export function createAuditEntry(input: Omit<AuditEntry, 'timestamp'>): AuditEntry {
  return { ...input, timestamp: new Date().toISOString() };
}

// ============================================================================
// 稟議書ヘッダ自動文言 (敬語・体裁)
// ============================================================================

/**
 * 稟議書の標準ヘッダ (社内文書の典型敬体)
 */
export function renderRingiHeader(input: {
  title: string;
  applicantName: string;
  applicantDepartment: string;
  applicantTitle: string;
  draftedAt: string; // ISO
}): string {
  return `稟議書\n\n表題：${input.title}\n起案部署：${input.applicantDepartment}\n起案者：${input.applicantTitle} ${input.applicantName}\n起案日：${formatJpDate(input.draftedAt)}\n\n下記の件、ご決裁を賜りたく稟議申し上げます。\n`;
}

function formatJpDate(iso: string): string {
  const d = new Date(iso);
  return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`;
}

// ============================================================================
// Default exports
// ============================================================================

export const RINGI_CATEGORY_LABELS: Record<RingiCategory, string> = {
  expense: '経費・接待',
  capital_invest: '設備投資',
  hire: '採用',
  salary_change: '給与改定',
  contract: '契約締結',
  system_invest: '情報システム投資',
  marketing: '広告宣伝',
  r_and_d: '研究開発',
  m_and_a: 'M&A',
  office_lease: 'オフィス賃借',
  travel_overseas: '海外出張',
  donation: '寄付',
  pricing_change: '価格改定',
  product_launch: '新商品発売',
  other: 'その他',
};

export const JOB_GRADE_LABELS: Record<JobGrade, string> = {
  staff: '一般社員',
  leader: '主任',
  subsection_chief: '係長',
  manager: '課長',
  senior_manager: '次長',
  general_manager: '部長',
  division_head: '本部長',
  executive_officer: '執行役員',
  director: '取締役',
  managing_director: '常務取締役',
  senior_managing_director: '専務取締役',
  vice_president: '副社長',
  president: '代表取締役社長',
  chairman: '取締役会長',
};
