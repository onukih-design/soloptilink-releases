/**
 * 労働保険 保険料率マスタ (令和8年度) — 厚生労働省 実マスタ
 *
 * 収録するもの:
 *   1. 労災保険率 (事業の種類別 54区分)               … 令和6年4月1日施行・令和8年度も同率
 *   2. 労務費率 (請負による建設事業)                   … 令和6年度〜・令和8年度も同率
 *   3. 第2種特別加入保険料率 (特1〜特26)              … 令和6年11月1日施行
 *   4. 第3種特別加入保険料率 (単一値)                  … 千分の3
 *   5. 非業務災害率 (単一値)                          … 千分の0.6
 *   6. 雇用保険料率 (一般 / 農林水産・清酒製造 / 建設)  … 令和8年4月1日〜令和9年3月31日
 *
 * ★このファイルの数値は、厚生労働省が公表した一次資料 (PDF) と e-Gov 法令検索の条文・別表の
 *   両方から機械抽出し、両者が完全一致することを確認したうえで転記している。
 *   ・労災保険率  : 率表PDF (54行) ⇔ 徴収則 別表第1 (53行) + 第16条第1項本文 (船舶所有者=千分の42)
 *   ・労務費率    : リーフレットPDF ⇔ 徴収則 別表第2
 *   ・第2種特別加入: リーフレットPDF・率表PDF ⇔ 徴収則 別表第5 (特1〜特26 全26件一致)
 *   ・第3種特別加入: リーフレットPDF ⇔ 徴収則 第23条の3 (千分の3)
 *   ・非業務災害率 : 徴収則 第16条第2項 (千分の0.6)
 *   ・雇用保険料率 : ハローワークリーフレットPDF (令和8年度・令和7年度の両方が原典に記載)
 *
 * 【出典 — 一次情報】
 *   厚生労働省「令和8年度の労災保険率について（令和7年度から変更ありません）」
 *   https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/rousai/rousaihoken06/rousai_hokenritsu_kaitei.html
 *   労災保険率表 (令和6年度〜)
 *   https://www.mhlw.go.jp/content/rousaihokenritu_r05.pdf
 *   令和8年度事業主向けリーフレット (労災保険率・労務費率・第2種特別加入保険料率)
 *   https://www.mhlw.go.jp/content/roumuhiritu_r05.pdf
 *   特別加入保険料率表 (令和6年11月1日〜)
 *   https://www.mhlw.go.jp/content/tokubetsukanyuuhokenryouritsu_R0504.pdf
 *   厚生労働省・ハローワーク「令和8(2026)年度 雇用保険料率のご案内」(LL080312保01)
 *   https://www.mhlw.go.jp/content/001692566.pdf
 *   e-Gov 法令検索 労働保険の保険料の徴収等に関する法律施行規則 (昭和47年労働省令第8号)
 *   https://laws.e-gov.go.jp/law/347M50002000008
 *   e-Gov 法令検索 労働保険の保険料の徴収等に関する法律 (昭和44年法律第84号)
 *   https://laws.e-gov.go.jp/law/344AC0000000084
 *
 * 【根拠法令 — 条番号は e-Gov の条文本文で実際に確認済み】
 *   労災保険率        : 徴収法施行規則 第16条第1項・別表第1
 *                       (船舶所有者の事業は別表第1に無く、第16条第1項本文に「千分の四十二」と直接規定)
 *   非業務災害率      : 徴収法施行規則 第16条第2項 (千分の0.6)
 *   労務費率          : 徴収法 第11条第3項 / 施行規則 第12条第1号 (賃金総額の特例)・第13条第1項・別表第2
 *   第2種特別加入料率 : 徴収法 第14条第1項 / 施行規則 第23条・別表第5
 *   第3種特別加入料率 : 徴収法 第14条の2第1項 / 施行規則 第23条の3
 *   雇用保険率        : 徴収法 第12条第1項第1号・第4項 (雇用保険率の構成)、第5項〜第11項 (弾力条項)
 *
 * 【取込日】2026-09-10
 *
 * ★★ 実装上の注意 ★★
 *   (1) 労災保険率と雇用保険率は改定周期が違う。労災は令和6年4月1日施行の率が令和7・8年度も据置き、
 *       雇用保険率は年度ごとに見直される (令和7年度→令和8年度で一般の事業は 14.5→13.5 に引下げ)。
 *       ひとつの「年度」定数でまとめて引かないこと。
 *   (2) 請負による建設事業で賃金総額を正確に把握できない場合のみ労務費率を使う (施行規則第12条第1号)。
 *       乗ずる請負金額は消費税等相当額を除いた額 (施行規則第13条第2項第1号の文言に明記)。
 *   (3) 保険料額そのものの端数処理 (円未満・被保険者負担分の銭未満) の規定は、今回取得した
 *       一次資料に記載が無いため本ファイルには実装していない。給与計算で端数処理が必要な場合は
 *       別途一次情報を取得すること (下記 UNRESOLVED_ITEMS 参照)。
 */

// ---------------------------------------------------------------------------
// 鮮度メタ
// ---------------------------------------------------------------------------

/** 労災保険率・労務費率・特別加入保険料率の鮮度メタ */
export const ROUSAI_INSURANCE_RATE_META = {
  master_ja: '労災保険率・労務費率・特別加入保険料率 (事業の種類別)',
  applied_year_ja: '令和8年度 (令和6年4月1日施行の率が令和7年度・令和8年度とも同率)',
  applied_fiscal_year: 'FY2026',
  /** 労災保険率・労務費率の施行日 */
  effective_from: '2024-04-01',
  /** 第2種特別加入保険料率表の施行日 (特12「特定フリーランス事業」追加により番号が繰り下がった版) */
  effective_from_tokubetsu: '2024-11-01',
  source_url: 'https://www.mhlw.go.jp/content/rousaihokenritu_r05.pdf',
  source_leaflet_url: 'https://www.mhlw.go.jp/content/roumuhiritu_r05.pdf',
  source_tokubetsu_url:
    'https://www.mhlw.go.jp/content/tokubetsukanyuuhokenryouritsu_R0504.pdf',
  source_index_url:
    'https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/rousai/rousaihoken06/rousai_hokenritsu_kaitei.html',
  source_law_url: 'https://laws.e-gov.go.jp/law/347M50002000008',
  legal_basis_ja:
    '労働保険の保険料の徴収等に関する法律施行規則 第16条第1項・別表第1 (労災保険率) / 第16条第2項 (非業務災害率) / 第13条第1項・別表第2 (労務費率) / 第23条・別表第5 (第2種特別加入保険料率) / 第23条の3 (第3種特別加入保険料率)',
  ingested_at: '2026-09-10',
  method: 'official-table' as const,
  /**
   * 改定周期。
   * ★「◯年ごとに改定」という周期は今回取得した一次資料に明記が無いため断定しない (要検証)。
   *   確認できた事実は「令和6年4月1日施行の率が令和7年度・令和8年度も据置きである」ことのみ。
   *   改定があれば source_index_url のページで告知される。
   */
  amendment_cycle_ja:
    '不定期改定。直近改定は令和6年4月1日施行。令和7年度・令和8年度は据置き (厚労省ページで確認)。改定周期の明文は原典に記載なし=要検証',
  /** 当方の運用上の再確認期日 (公式の告知日ではない)。令和9年度率の公表を確認する時期 */
  next_review_due: '2027-03-01',
} as const;

/** 雇用保険料率の鮮度メタ (労災とは改定周期が違うため別立て) */
export const KOYOU_INSURANCE_RATE_META = {
  master_ja: '雇用保険料率 (事業の種類3区分・労働者負担/事業主負担)',
  applied_year_ja: '令和8年度',
  applied_fiscal_year: 'FY2026',
  effective_from: '2026-04-01',
  effective_to: '2027-03-31',
  source_url: 'https://www.mhlw.go.jp/content/001692566.pdf',
  source_law_url: 'https://laws.e-gov.go.jp/law/344AC0000000084',
  legal_basis_ja:
    '労働保険の保険料の徴収等に関する法律 第12条第1項第1号・第4項 (雇用保険率の構成: 失業等給付費等充当徴収保険率＋育児休業給付費充当徴収保険率＋二事業費充当徴収保険率)、第5項〜第11項 (弾力条項)',
  ingested_at: '2026-09-10',
  method: 'official-table' as const,
  amendment_cycle_ja:
    '年度単位で見直し (原典が令和7年度と令和8年度を併記。令和8年度は一般の事業で 14.5/1,000→13.5/1,000 に引下げ)',
  /** 当方の運用上の再確認期日。令和9年度率は例年2〜3月に公表される */
  next_review_due: '2027-03-01',
} as const;

// ---------------------------------------------------------------------------
// 1. 労災保険率 (54区分)
// ---------------------------------------------------------------------------

/** 労災保険率表の「事業の種類の分類」 */
export type RousaiBusinessCategory =
  | '林業'
  | '漁業'
  | '鉱業'
  | '建設事業'
  | '製造業'
  | '運輸業'
  | '電気、ガス、水道又は熱供給の事業'
  | 'その他の事業'
  | '船舶所有者の事業';

export interface RousaiInsuranceRateEntry {
  /** 事業の種類の分類 */
  readonly category: RousaiBusinessCategory;
  /** 業種番号 (原典の表記。林業のみ「02・03」の2番号を持つ) */
  readonly code: string;
  /** 照合用に分解した業種番号。重複検査もこれで行う */
  readonly codes: readonly string[];
  /** 事業の種類 (原典の表記そのまま。法令表記のため「めつき」は小書きにしない) */
  readonly businessType: string;
  /** 労災保険率 [1/1,000] */
  readonly ratePerMille: number;
  /**
   * 徴収法施行規則 別表第1 に掲げられているか。
   * 船舶所有者の事業 (業種番号90) のみ別表に無く、第16条第1項本文に千分の42と直接規定されている。
   */
  readonly inAppendix1: boolean;
}

/**
 * 労災保険率表 (令和6年4月1日施行 / 令和8年度も同率)。
 * 原典 (労災保険率表PDF) の掲載順をそのまま保持している。番号順ではないので並べ替えないこと。
 */
export const ROUSAI_INSURANCE_RATE_TABLE: readonly RousaiInsuranceRateEntry[] = [
  // 林業
  { category: '林業', code: '02・03', codes: ['02', '03'], businessType: '林業', ratePerMille: 52, inAppendix1: true },
  // 漁業
  { category: '漁業', code: '11', codes: ['11'], businessType: '海面漁業（定置網漁業又は海面魚類養殖業を除く。）', ratePerMille: 18, inAppendix1: true },
  { category: '漁業', code: '12', codes: ['12'], businessType: '定置網漁業又は海面魚類養殖業', ratePerMille: 37, inAppendix1: true },
  // 鉱業
  { category: '鉱業', code: '21', codes: ['21'], businessType: '金属鉱業、非金属鉱業（石灰石鉱業又はドロマイト鉱業を除く。）又は石炭鉱業', ratePerMille: 88, inAppendix1: true },
  { category: '鉱業', code: '23', codes: ['23'], businessType: '石灰石鉱業又はドロマイト鉱業', ratePerMille: 13, inAppendix1: true },
  { category: '鉱業', code: '24', codes: ['24'], businessType: '原油又は天然ガス鉱業', ratePerMille: 2.5, inAppendix1: true },
  { category: '鉱業', code: '25', codes: ['25'], businessType: '採石業', ratePerMille: 37, inAppendix1: true },
  { category: '鉱業', code: '26', codes: ['26'], businessType: 'その他の鉱業', ratePerMille: 26, inAppendix1: true },
  // 建設事業
  { category: '建設事業', code: '31', codes: ['31'], businessType: '水力発電施設、ずい道等新設事業', ratePerMille: 34, inAppendix1: true },
  { category: '建設事業', code: '32', codes: ['32'], businessType: '道路新設事業', ratePerMille: 11, inAppendix1: true },
  { category: '建設事業', code: '33', codes: ['33'], businessType: '舗装工事業', ratePerMille: 9, inAppendix1: true },
  { category: '建設事業', code: '34', codes: ['34'], businessType: '鉄道又は軌道新設事業', ratePerMille: 9, inAppendix1: true },
  { category: '建設事業', code: '35', codes: ['35'], businessType: '建築事業（既設建築物設備工事業を除く。）', ratePerMille: 9.5, inAppendix1: true },
  { category: '建設事業', code: '38', codes: ['38'], businessType: '既設建築物設備工事業', ratePerMille: 12, inAppendix1: true },
  { category: '建設事業', code: '36', codes: ['36'], businessType: '機械装置の組立て又は据付けの事業', ratePerMille: 6, inAppendix1: true },
  { category: '建設事業', code: '37', codes: ['37'], businessType: 'その他の建設事業', ratePerMille: 15, inAppendix1: true },
  // 製造業
  { category: '製造業', code: '41', codes: ['41'], businessType: '食料品製造業', ratePerMille: 5.5, inAppendix1: true },
  { category: '製造業', code: '42', codes: ['42'], businessType: '繊維工業又は繊維製品製造業', ratePerMille: 4, inAppendix1: true },
  { category: '製造業', code: '44', codes: ['44'], businessType: '木材又は木製品製造業', ratePerMille: 13, inAppendix1: true },
  { category: '製造業', code: '45', codes: ['45'], businessType: 'パルプ又は紙製造業', ratePerMille: 7, inAppendix1: true },
  { category: '製造業', code: '46', codes: ['46'], businessType: '印刷又は製本業', ratePerMille: 3.5, inAppendix1: true },
  { category: '製造業', code: '47', codes: ['47'], businessType: '化学工業', ratePerMille: 4.5, inAppendix1: true },
  { category: '製造業', code: '48', codes: ['48'], businessType: 'ガラス又はセメント製造業', ratePerMille: 6, inAppendix1: true },
  { category: '製造業', code: '66', codes: ['66'], businessType: 'コンクリート製造業', ratePerMille: 13, inAppendix1: true },
  { category: '製造業', code: '62', codes: ['62'], businessType: '陶磁器製品製造業', ratePerMille: 17, inAppendix1: true },
  { category: '製造業', code: '49', codes: ['49'], businessType: 'その他の窯業又は土石製品製造業', ratePerMille: 23, inAppendix1: true },
  { category: '製造業', code: '50', codes: ['50'], businessType: '金属精錬業（非鉄金属精錬業を除く。）', ratePerMille: 6.5, inAppendix1: true },
  { category: '製造業', code: '51', codes: ['51'], businessType: '非鉄金属精錬業', ratePerMille: 7, inAppendix1: true },
  { category: '製造業', code: '52', codes: ['52'], businessType: '金属材料品製造業（鋳物業を除く。）', ratePerMille: 5, inAppendix1: true },
  { category: '製造業', code: '53', codes: ['53'], businessType: '鋳物業', ratePerMille: 16, inAppendix1: true },
  { category: '製造業', code: '54', codes: ['54'], businessType: '金属製品製造業又は金属加工業（洋食器、刃物、手工具又は一般金物製造業及びめつき業を除く。）', ratePerMille: 9, inAppendix1: true },
  { category: '製造業', code: '63', codes: ['63'], businessType: '洋食器、刃物、手工具又は一般金物製造業（めつき業を除く。）', ratePerMille: 6.5, inAppendix1: true },
  { category: '製造業', code: '55', codes: ['55'], businessType: 'めつき業', ratePerMille: 6.5, inAppendix1: true },
  { category: '製造業', code: '56', codes: ['56'], businessType: '機械器具製造業（電気機械器具製造業、輸送用機械器具製造業、船舶製造又は修理業及び計量器、光学機械、時計等製造業を除く。）', ratePerMille: 5, inAppendix1: true },
  { category: '製造業', code: '57', codes: ['57'], businessType: '電気機械器具製造業', ratePerMille: 3, inAppendix1: true },
  { category: '製造業', code: '58', codes: ['58'], businessType: '輸送用機械器具製造業（船舶製造又は修理業を除く。）', ratePerMille: 4, inAppendix1: true },
  { category: '製造業', code: '59', codes: ['59'], businessType: '船舶製造又は修理業', ratePerMille: 23, inAppendix1: true },
  { category: '製造業', code: '60', codes: ['60'], businessType: '計量器、光学機械、時計等製造業（電気機械器具製造業を除く。）', ratePerMille: 2.5, inAppendix1: true },
  { category: '製造業', code: '64', codes: ['64'], businessType: '貴金属製品、装身具、皮革製品等製造業', ratePerMille: 3.5, inAppendix1: true },
  { category: '製造業', code: '61', codes: ['61'], businessType: 'その他の製造業', ratePerMille: 6, inAppendix1: true },
  // 運輸業
  { category: '運輸業', code: '71', codes: ['71'], businessType: '交通運輸事業', ratePerMille: 4, inAppendix1: true },
  { category: '運輸業', code: '72', codes: ['72'], businessType: '貨物取扱事業（港湾貨物取扱事業及び港湾荷役業を除く。）', ratePerMille: 8.5, inAppendix1: true },
  { category: '運輸業', code: '73', codes: ['73'], businessType: '港湾貨物取扱事業（港湾荷役業を除く。）', ratePerMille: 9, inAppendix1: true },
  { category: '運輸業', code: '74', codes: ['74'], businessType: '港湾荷役業', ratePerMille: 12, inAppendix1: true },
  // 電気、ガス、水道又は熱供給の事業
  { category: '電気、ガス、水道又は熱供給の事業', code: '81', codes: ['81'], businessType: '電気、ガス、水道又は熱供給の事業', ratePerMille: 3, inAppendix1: true },
  // その他の事業
  { category: 'その他の事業', code: '95', codes: ['95'], businessType: '農業又は海面漁業以外の漁業', ratePerMille: 13, inAppendix1: true },
  { category: 'その他の事業', code: '91', codes: ['91'], businessType: '清掃、火葬又はと畜の事業', ratePerMille: 13, inAppendix1: true },
  { category: 'その他の事業', code: '93', codes: ['93'], businessType: 'ビルメンテナンス業', ratePerMille: 6, inAppendix1: true },
  { category: 'その他の事業', code: '96', codes: ['96'], businessType: '倉庫業、警備業、消毒又は害虫駆除の事業又はゴルフ場の事業', ratePerMille: 6.5, inAppendix1: true },
  { category: 'その他の事業', code: '97', codes: ['97'], businessType: '通信業、放送業、新聞業又は出版業', ratePerMille: 2.5, inAppendix1: true },
  { category: 'その他の事業', code: '98', codes: ['98'], businessType: '卸売業・小売業、飲食店又は宿泊業', ratePerMille: 3, inAppendix1: true },
  { category: 'その他の事業', code: '99', codes: ['99'], businessType: '金融業、保険業又は不動産業', ratePerMille: 2.5, inAppendix1: true },
  { category: 'その他の事業', code: '94', codes: ['94'], businessType: 'その他の各種事業', ratePerMille: 3, inAppendix1: true },
  // 船舶所有者の事業 (別表第1ではなく施行規則第16条第1項本文に規定)
  { category: '船舶所有者の事業', code: '90', codes: ['90'], businessType: '船舶所有者の事業', ratePerMille: 42, inAppendix1: false },
] as const;

/**
 * 原典から独立に算出した照合値 (チェックサム)。
 *
 * ★件数だけを数える検査は、1件の数値を打ち間違えても合格してしまう (fail-open)。
 *   そこで「合計値」と「分類ごとの件数」を、本ファイルの配列ではなく原典側から先に算出して
 *   固定値として持ち、配列と突き合わせる。1つでも値を書き換えれば合計が動いて検出される。
 *
 * 【算出の出所 — 2系統が独立に一致することを確認済み】
 *   系統A: 労災保険率表PDF (https://www.mhlw.go.jp/content/rousaihokenritu_r05.pdf) の
 *          テキスト抽出 … 53件の合計 655.0 + 林業52 = 707.0
 *   系統B: e-Gov 徴収法施行規則 別表第1 (53件) の合計 665.0 + 船舶所有者の事業42 = 707.0
 *   → 両系統とも 707.0 で一致
 */
export const ROUSAI_RATE_CHECKSUM = {
  /** 労災保険率54区分の料率合計 [1/1,000] */
  totalRatePerMille: 707,
  /** 徴収則別表第1に載る53区分の合計 (=707 − 船舶所有者42) */
  appendix1TotalPerMille: 665,
  /** 事業の種類の分類ごとの件数 */
  countByCategory: {
    林業: 1,
    漁業: 2,
    鉱業: 5,
    建設事業: 8,
    製造業: 24,
    運輸業: 4,
    '電気、ガス、水道又は熱供給の事業': 1,
    その他の事業: 8,
    船舶所有者の事業: 1,
  } as Readonly<Record<RousaiBusinessCategory, number>>,
  /** 労務費率9件の合計 [%] (出所: e-Gov 徴収法施行規則 別表第2) */
  roumuhiritsuTotalPercent: 202,
  /** 第2種特別加入保険料率 特1〜特26 の合計 [1/1,000] (出所: e-Gov 徴収法施行規則 別表第5) */
  tokubetsuType2TotalPerMille: 300,
} as const;

/**
 * 非業務災害率 [1/1,000]。
 * 徴収法施行規則 第16条第2項「法第十二条第三項の非業務災害率は、千分の〇・六とする。」
 * メリット制の増減対象から外れる部分であり、労災保険率のうちこの分は事業ごとの災害率に連動しない。
 */
export const NON_WORK_ACCIDENT_RATE_PER_MILLE = 0.6;

// ---------------------------------------------------------------------------
// 2. 労務費率 (請負による建設事業)
// ---------------------------------------------------------------------------

export interface RoumuhiritsuEntry {
  /** 業種番号 */
  readonly code: string;
  /** 事業の種類 */
  readonly businessType: string;
  /** 細目 (業種番号36のみ2区分。他は null) */
  readonly subType: string | null;
  /** 請負金額に乗ずる率 [%] */
  readonly ratePercent: number;
}

/**
 * 労務費率表 (令和6年度〜 / 令和8年度も同率)。
 * 請負による建設事業で賃金総額を正確に把握することが困難な場合に、
 * 「請負金額 (消費税等相当額を除く) × 労務費率 = 賃金総額」として保険料を算定する。
 * 全区分が建設事業 (業種番号31〜38)。
 */
export const ROUMUHIRITSU_TABLE: readonly RoumuhiritsuEntry[] = [
  { code: '31', businessType: '水力発電施設、ずい道等新設事業', subType: null, ratePercent: 19 },
  { code: '32', businessType: '道路新設事業', subType: null, ratePercent: 19 },
  { code: '33', businessType: '舗装工事業', subType: null, ratePercent: 17 },
  { code: '34', businessType: '鉄道又は軌道新設事業', subType: null, ratePercent: 19 },
  { code: '35', businessType: '建築事業（既設建築物設備工事業を除く。）', subType: null, ratePercent: 23 },
  { code: '38', businessType: '既設建築物設備工事業', subType: null, ratePercent: 23 },
  { code: '36', businessType: '機械装置の組立て又は据付けの事業', subType: '組立て又は取付けに関するもの', ratePercent: 38 },
  { code: '36', businessType: '機械装置の組立て又は据付けの事業', subType: 'その他のもの', ratePercent: 21 },
  { code: '37', businessType: 'その他の建設事業', subType: null, ratePercent: 23 },
] as const;

// ---------------------------------------------------------------------------
// 3. 第2種特別加入保険料率 (特1〜特26)
// ---------------------------------------------------------------------------

export interface TokubetsuKanyuType2Entry {
  /** 事業又は作業の種類の番号 ('特1'〜'特26') */
  readonly code: string;
  /** 根拠となる労災保険法施行規則の号 */
  readonly legalRef: string;
  /** 事業又は作業の種類 (原典の括弧書き) */
  readonly description: string;
  /** 第2種特別加入保険料率 [1/1,000] */
  readonly ratePerMille: number;
}

/**
 * 第2種特別加入保険料率表 (令和6年11月1日施行)。
 * ★令和6年11月1日にフリーランス法改正に伴い「特12 特定フリーランス事業」が追加され、
 *   それ以降の既存区分の番号が繰り下がっている。旧番号で保存されたデータを読むときは注意すること。
 *   ただし既存区分の料率自体は令和6年4月1日から変更されていない (厚労省ページの注記)。
 */
export const TOKUBETSU_KANYU_TYPE2_TABLE: readonly TokubetsuKanyuType2Entry[] = [
  { code: '特1', legalRef: '労災保険法施行規則 第46条の17第1号の事業', description: '個人タクシー、個人貨物運送業者、原動機付自転車又は自転車を使用して行う貨物の運送の事業', ratePerMille: 11 },
  { code: '特2', legalRef: '労災保険法施行規則 第46条の17第2号の事業', description: '建設業の一人親方', ratePerMille: 17 },
  { code: '特3', legalRef: '労災保険法施行規則 第46条の17第3号の事業', description: '漁船による自営業者', ratePerMille: 45 },
  { code: '特4', legalRef: '労災保険法施行規則 第46条の17第4号の事業', description: '林業の一人親方', ratePerMille: 52 },
  { code: '特5', legalRef: '労災保険法施行規則 第46条の17第5号の事業', description: '医薬品の配置販売業者', ratePerMille: 6 },
  { code: '特6', legalRef: '労災保険法施行規則 第46条の17第6号の事業', description: '再生資源取扱業者', ratePerMille: 14 },
  { code: '特7', legalRef: '労災保険法施行規則 第46条の17第7号の事業', description: '船員法第1条に規定する船員が行う事業', ratePerMille: 48 },
  { code: '特8', legalRef: '労災保険法施行規則 第46条の17第8号の事業', description: '柔道整復師', ratePerMille: 3 },
  { code: '特9', legalRef: '労災保険法施行規則 第46条の17第9号の事業', description: '創業支援等措置に基づく事業を行う高年齢者', ratePerMille: 3 },
  { code: '特10', legalRef: '労災保険法施行規則 第46条の17第10号の事業', description: 'あん摩マツサージ指圧師、はり師又はきゆう師', ratePerMille: 3 },
  { code: '特11', legalRef: '労災保険法施行規則 第46条の17第11号の事業', description: '歯科技工士', ratePerMille: 3 },
  { code: '特12', legalRef: '労災保険法施行規則 第46条の17第12号の事業', description: '特定フリーランス事業', ratePerMille: 3 },
  { code: '特13', legalRef: '労災保険法施行規則 第46条の18第1号ロの作業', description: '指定農業機械作業従事者', ratePerMille: 3 },
  { code: '特14', legalRef: '労災保険法施行規則 第46条の18第2号イの作業', description: '職場適応訓練受講者', ratePerMille: 3 },
  { code: '特15', legalRef: '労災保険法施行規則 第46条の18第3号イ又はロの作業', description: '金属等の加工、洋食器加工作業', ratePerMille: 14 },
  { code: '特16', legalRef: '労災保険法施行規則 第46条の18第3号ハの作業', description: '履物等の加工の作業', ratePerMille: 5 },
  { code: '特17', legalRef: '労災保険法施行規則 第46条の18第3号ニの作業', description: '陶磁器製造の作業', ratePerMille: 17 },
  { code: '特18', legalRef: '労災保険法施行規則 第46条の18第3号ホの作業', description: '動力機械による作業', ratePerMille: 3 },
  { code: '特19', legalRef: '労災保険法施行規則 第46条の18第3号ヘの作業', description: '仏壇、食器の加工の作業', ratePerMille: 18 },
  { code: '特20', legalRef: '労災保険法施行規則 第46条の18第2号ロの作業', description: '事業主団体等委託訓練従事者', ratePerMille: 3 },
  { code: '特21', legalRef: '労災保険法施行規則 第46条の18第1号イの作業', description: '特定農作業従事者', ratePerMille: 9 },
  { code: '特22', legalRef: '労災保険法施行規則 第46条の18第4号の作業', description: '労働組合等常勤役員', ratePerMille: 3 },
  { code: '特23', legalRef: '労災保険法施行規則 第46条の18第5号の作業', description: '介護作業従事者及び家事支援従事者', ratePerMille: 5 },
  { code: '特24', legalRef: '労災保険法施行規則 第46条の18第6号の作業', description: '芸能関係作業従事者', ratePerMille: 3 },
  { code: '特25', legalRef: '労災保険法施行規則 第46条の18第7号の作業', description: 'アニメーション制作作業従事者', ratePerMille: 3 },
  { code: '特26', legalRef: '労災保険法施行規則 第46条の18第8号の作業', description: '情報処理システムの設計等の情報処理に係る作業従事者', ratePerMille: 3 },
] as const;

/**
 * 第1種特別加入保険料率。
 * 「当該事業に適用される労災保険率と同一の率である」(特別加入保険料率表 冒頭)。
 * 単一の数値は存在しないため、ROUSAI_INSURANCE_RATE_TABLE を引いて使うこと。
 */
export const TOKUBETSU_KANYU_TYPE1_RULE_JA =
  '第1種特別加入保険料率は、当該事業に適用される労災保険率と同一の率である';

/**
 * 第3種特別加入保険料率 [1/1,000]。
 * 海外で行われる事業に派遣される労働者等。徴収法施行規則 第23条の3「千分の三とする」。
 */
export const TOKUBETSU_KANYU_TYPE3_RATE_PER_MILLE = 3;

// ---------------------------------------------------------------------------
// 4. 雇用保険料率 (令和8年度)
// ---------------------------------------------------------------------------

/** 雇用保険料率の事業区分 */
export type KoyouBusinessKind = '一般の事業' | '農林水産・清酒製造の事業' | '建設の事業';

export interface KoyouInsuranceRateEntry {
  readonly kind: KoyouBusinessKind;
  /** ①労働者負担 (失業等給付・育児休業給付の保険料率のみ) [1/1,000] */
  readonly employeeRatePerMille: number;
  /** ②事業主負担 合計 [1/1,000] */
  readonly employerRatePerMille: number;
  /** ②の内訳: 失業等給付・育児休業給付の保険料率 [1/1,000] */
  readonly employerUnemploymentPerMille: number;
  /** ②の内訳: 雇用保険二事業の保険料率 (事業主のみ負担) [1/1,000] */
  readonly employerTwoBusinessPerMille: number;
  /** ①+② 雇用保険料率 [1/1,000] */
  readonly totalRatePerMille: number;
}

/**
 * 令和8年度 (2026年4月1日〜2027年3月31日) の雇用保険料率。
 * ※「農林水産・清酒製造の事業」でも、園芸サービス、牛馬の育成、酪農、養鶏、養豚、内水面養殖
 *   および特定の船員を雇用する事業については「一般の事業」の率が適用される (原典の注記)。
 */
export const KOYOU_INSURANCE_RATE_TABLE_FY2026: readonly KoyouInsuranceRateEntry[] = [
  { kind: '一般の事業', employeeRatePerMille: 5, employerRatePerMille: 8.5, employerUnemploymentPerMille: 5, employerTwoBusinessPerMille: 3.5, totalRatePerMille: 13.5 },
  { kind: '農林水産・清酒製造の事業', employeeRatePerMille: 6, employerRatePerMille: 9.5, employerUnemploymentPerMille: 6, employerTwoBusinessPerMille: 3.5, totalRatePerMille: 15.5 },
  { kind: '建設の事業', employeeRatePerMille: 6, employerRatePerMille: 10.5, employerUnemploymentPerMille: 6, employerTwoBusinessPerMille: 4.5, totalRatePerMille: 16.5 },
] as const;

/**
 * 令和7年度 (2025年4月1日〜2026年3月31日) の雇用保険料率。
 * 原典 (令和8年度リーフレット) の各枠内下段に併記されているため、年度またぎの精算・訂正用に保持する。
 */
export const KOYOU_INSURANCE_RATE_TABLE_FY2025: readonly KoyouInsuranceRateEntry[] = [
  { kind: '一般の事業', employeeRatePerMille: 5.5, employerRatePerMille: 9, employerUnemploymentPerMille: 5.5, employerTwoBusinessPerMille: 3.5, totalRatePerMille: 14.5 },
  { kind: '農林水産・清酒製造の事業', employeeRatePerMille: 6.5, employerRatePerMille: 10, employerUnemploymentPerMille: 6.5, employerTwoBusinessPerMille: 3.5, totalRatePerMille: 16.5 },
  { kind: '建設の事業', employeeRatePerMille: 6.5, employerRatePerMille: 11, employerUnemploymentPerMille: 6.5, employerTwoBusinessPerMille: 4.5, totalRatePerMille: 17.5 },
] as const;

/** 一般の事業の率が適用される「農林水産の事業」の例外 (原典の※注記) */
export const KOYOU_AGRI_EXCEPTION_JA =
  '園芸サービス、牛馬の育成、酪農、養鶏、養豚、内水面養殖および特定の船員を雇用する事業については、一般の事業の率が適用される';

// ---------------------------------------------------------------------------
// 未取得項目 (推測で埋めていないことを明示する)
// ---------------------------------------------------------------------------

/**
 * 今回の一次情報取得では確定できなかった項目。
 * ★ここに挙げた項目を実装で必要とする場合は、必ず新たに一次情報を取得すること。
 *   推測値・概算値でこの配列を埋めてはならない。
 */
export const UNRESOLVED_ITEMS: readonly { readonly item: string; readonly reason: string }[] = [
  {
    item: '保険料額の端数処理 (円未満の切捨て、被保険者負担分の銭未満の取扱い)',
    reason:
      '取得した4つの一次資料 (労災保険率表・リーフレット・特別加入率表・雇用保険料率リーフレット) のいずれにも記載が無い。雇用保険料率リーフレットは全1ページで、端数処理の記載欄自体が存在しない',
  },
  {
    item: '労災保険率の改定周期 (何年ごとに見直すか)',
    reason:
      '厚労省の該当ページ・リーフレット・徴収法施行規則の条文いずれにも周期の明文が無い。確認できたのは「令和6年4月1日施行の率が令和7・8年度も据置き」という事実のみ',
  },
  {
    item: '令和9年度 (2027年度) の各料率',
    reason: '取込日 (2026-09-10) 時点で未公表。厚労省の告知を待つ',
  },
  {
    item: 'メリット制による労災保険率の増減 (最大±40%等) の具体的適用条件',
    reason: '今回の取得対象外。徴収法第12条第3項・施行規則第17条以下を別途取得すること',
  },
  {
    item: '雇用保険率の内訳のうち「育児休業給付費充当徴収保険率」単独の値',
    reason:
      'リーフレットは労働者負担欄を「失業等給付・育児休業給付の保険料率」として合算表示しており、育休分単独の率が原典に分離記載されていない',
  },
] as const;

// ---------------------------------------------------------------------------
// 引く関数
// ---------------------------------------------------------------------------

/** 全角数字・記号のゆれを吸収して比較用に正規化する */
function normalizeKey(input: string): string {
  return input
    .trim()
    .replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0))
    .replace(/[（）]/g, (c) => (c === '（' ? '(' : ')'))
    .replace(/[\s　]/g, '')
    .replace(/めっき/g, 'めつき') // 法令表記は「めつき」。リーフレット表記「めっき」も引けるようにする
    .replace(/マッサージ/g, 'マツサージ')
    .replace(/きゅう師/g, 'きゆう師');
}

/**
 * 業種番号または事業の種類名から労災保険率を引く。
 *
 * @param codeOrName 業種番号 ('35'、'02'、'03'、'02・03' 等) または事業の種類名
 * @returns 一致したレコード
 * @throws 特定できない場合 (推測で近い区分を返すことはしない)
 */
export function getRousaiInsuranceRate(codeOrName: string): RousaiInsuranceRateEntry {
  const key = normalizeKey(codeOrName);

  // 1. 業種番号の完全一致 (林業の '02'/'03'/'02・03' も拾う)
  const byCode = ROUSAI_INSURANCE_RATE_TABLE.find(
    (r) => normalizeKey(r.code) === key || r.codes.some((c) => normalizeKey(c) === key),
  );
  if (byCode) return byCode;

  // 2. 事業の種類名の完全一致
  const byName = ROUSAI_INSURANCE_RATE_TABLE.find((r) => normalizeKey(r.businessType) === key);
  if (byName) return byName;

  // 3. 事業の種類名の部分一致 (ただし一意に定まる場合のみ採用する)
  const partial = ROUSAI_INSURANCE_RATE_TABLE.filter((r) => normalizeKey(r.businessType).includes(key));
  if (partial.length === 1) return partial[0]!;
  if (partial.length > 1) {
    throw new Error(
      `労災保険率: 「${codeOrName}」に該当する事業の種類が複数あります (${partial
        .map((r) => `${r.code}:${r.businessType}`)
        .join(' / ')})。業種番号で指定してください。`,
    );
  }
  throw new Error(
    `労災保険率: 「${codeOrName}」に該当する事業の種類が見つかりません。業種番号 (02・03、11〜99) または労災保険率表の事業の種類名で指定してください。事業の種類の決定は「労災保険率適用事業細目表」(昭和47年労働省告示第16号) によります。`,
  );
}

/** 事業の種類名の部分一致で候補を列挙する (画面の検索補助用。料率の決定には使わないこと) */
export function searchRousaiInsuranceRates(keyword: string): readonly RousaiInsuranceRateEntry[] {
  const key = normalizeKey(keyword);
  if (key === '') return [];
  return ROUSAI_INSURANCE_RATE_TABLE.filter(
    (r) => normalizeKey(r.businessType).includes(key) || normalizeKey(r.category).includes(key),
  );
}

/** 事業の種類の分類ごとに労災保険率を取り出す */
export function getRousaiRatesByCategory(
  category: RousaiBusinessCategory,
): readonly RousaiInsuranceRateEntry[] {
  return ROUSAI_INSURANCE_RATE_TABLE.filter((r) => r.category === category);
}

/**
 * 労務費率を引く。
 *
 * @param code 業種番号 ('31'〜'38')
 * @param subType 業種番号36のときのみ必須 ('組立て又は取付けに関するもの' | 'その他のもの')
 */
export function getRoumuhiritsu(code: string, subType?: string): RoumuhiritsuEntry {
  const key = normalizeKey(code);
  const candidates = ROUMUHIRITSU_TABLE.filter((r) => normalizeKey(r.code) === key);
  if (candidates.length === 0) {
    throw new Error(
      `労務費率: 業種番号「${code}」は労務費率表にありません。労務費率が定められているのは請負による建設事業 (31・32・33・34・35・36・37・38) のみです。`,
    );
  }
  if (candidates.length === 1) return candidates[0]!;

  // 業種番号36は細目が2つあるため、細目の指定が無ければ推測せずエラーにする
  if (subType === undefined) {
    throw new Error(
      `労務費率: 業種番号「${code}」(機械装置の組立て又は据付けの事業) は細目により率が異なります。「${candidates
        .map((c) => `${c.subType}=${c.ratePercent}%`)
        .join('」「')}」のいずれかを subType で指定してください。`,
    );
  }
  const sub = normalizeKey(subType);
  const hit = candidates.find((c) => c.subType !== null && normalizeKey(c.subType).includes(sub));
  if (!hit) {
    throw new Error(
      `労務費率: 業種番号「${code}」に細目「${subType}」はありません。指定可能なのは ${candidates
        .map((c) => c.subType)
        .join(' / ')} です。`,
    );
  }
  return hit;
}

/**
 * 請負による建設事業の賃金総額を労務費率から算定する。
 *
 * ★この算定は「賃金総額を正確に把握することが困難な場合」に限られる (徴収法施行規則 第12条第1号)。
 * ★請負金額は消費税等相当額を除いた額を渡すこと (同 第13条第2項第1号)。
 *
 * @param contractAmountExclTax 請負金額 (消費税等相当額を除く) [円]
 * @param code 業種番号 ('31'〜'38')
 * @param subType 業種番号36のときのみ必須
 * @returns 賃金総額 [円] (端数処理は行わない。端数処理が必要な場合は呼び出し側の責任で行うこと)
 */
export function calcConstructionWageTotal(
  contractAmountExclTax: number,
  code: string,
  subType?: string,
): { wageTotal: number; ratePercent: number; basisJa: string } {
  if (!Number.isFinite(contractAmountExclTax) || contractAmountExclTax < 0) {
    throw new Error('労務費率: 請負金額は0以上の数値で指定してください。');
  }
  const row = getRoumuhiritsu(code, subType);
  return {
    wageTotal: (contractAmountExclTax * row.ratePercent) / 100,
    ratePercent: row.ratePercent,
    basisJa: `徴収法施行規則 第13条第1項・別表第2 / 業種番号${row.code} ${row.businessType}${
      row.subType ? `（${row.subType}）` : ''
    } 労務費率${row.ratePercent}%`,
  };
}

/** 第2種特別加入保険料率を引く ('特2'、'特12'、'2'、'12' のいずれでも可) */
export function getTokubetsuKanyuType2Rate(code: string): TokubetsuKanyuType2Entry {
  const raw = normalizeKey(code);
  const key = raw.startsWith('特') ? raw : `特${raw}`;
  const hit = TOKUBETSU_KANYU_TYPE2_TABLE.find((r) => normalizeKey(r.code) === key);
  if (!hit) {
    throw new Error(
      `第2種特別加入保険料率: 「${code}」は特1〜特26に該当しません。令和6年11月1日に特12 (特定フリーランス事業) が追加され、以降の番号が繰り下がっていることに注意してください。`,
    );
  }
  return hit;
}

/**
 * 指定日時点の雇用保険料率を引く。
 *
 * ★年度で切り替わるため、必ず賃金の支払対象日を渡すこと。
 *   令和8年4月1日を境に一般の事業で 14.5/1,000 → 13.5/1,000 に変わる。
 *
 * @param kind 事業の種類 (3区分)
 * @param onDate 支払対象日 (Date または 'YYYY-MM-DD')。既定は実行日
 * @throws 令和7年度より前の日付を指定した場合 (本マスタに収載していないため推測しない)
 */
export function getKoyouInsuranceRate(
  kind: KoyouBusinessKind,
  onDate: Date | string = new Date(),
): KoyouInsuranceRateEntry & { fiscalYear: 'FY2025' | 'FY2026'; fiscalYearJa: string } {
  const d = typeof onDate === 'string' ? new Date(`${onDate}T00:00:00+09:00`) : onDate;
  if (Number.isNaN(d.getTime())) {
    throw new Error(`雇用保険料率: 日付「${String(onDate)}」を解釈できません。'YYYY-MM-DD' で指定してください。`);
  }
  const fy2026Start = new Date('2026-04-01T00:00:00+09:00').getTime();
  const fy2025Start = new Date('2025-04-01T00:00:00+09:00').getTime();
  const fy2027Start = new Date('2027-04-01T00:00:00+09:00').getTime();

  if (d.getTime() < fy2025Start) {
    throw new Error(
      '雇用保険料率: 令和7年度 (2025年4月1日) より前の料率は本マスタに収載していません。該当年度の一次情報を取得してください。',
    );
  }
  if (d.getTime() >= fy2027Start) {
    throw new Error(
      '雇用保険料率: 令和9年度 (2027年4月1日) 以降の料率は未公表のため収載していません。厚生労働省の告知を確認してください。',
    );
  }
  const isFy2026 = d.getTime() >= fy2026Start;
  const table = isFy2026 ? KOYOU_INSURANCE_RATE_TABLE_FY2026 : KOYOU_INSURANCE_RATE_TABLE_FY2025;
  const row = table.find((r) => r.kind === kind);
  if (!row) {
    throw new Error(
      `雇用保険料率: 事業の種類「${kind}」が特定できません。'一般の事業' / '農林水産・清酒製造の事業' / '建設の事業' のいずれかを指定してください。`,
    );
  }
  return {
    ...row,
    fiscalYear: isFy2026 ? 'FY2026' : 'FY2025',
    fiscalYearJa: isFy2026 ? '令和8年度' : '令和7年度',
  };
}

/**
 * 二元適用事業の判定。
 *
 * 徴収法 第39条第1項「…厚生労働省令で定める事業については、当該事業を労災保険に係る保険関係
 * 及び雇用保険に係る保険関係ごとに別個の事業とみなしてこの法律を適用する。」
 * 施行規則 第70条 が定める事業は次の4つ:
 *   一 都道府県に準ずるもの及び市町村に準ずるものの行う事業
 *   二 港湾労働法第2条第2号の港湾運送の行為を行う事業
 *   三 雇用保険法附則第2条第1項各号に掲げる事業
 *   四 建設の事業
 *
 * ★二元適用事業では労災保険と雇用保険の保険関係が別個に成立するため、
 *   同じ賃金総額に両方の率を掛けてはならない (労災側は元請が請負金額から算定する等、算定基礎が別)。
 *
 * 判定の確度:
 *   'yes'         … 建設の事業 (第70条第4号に明記)
 *   'needs-check' … 港湾関係・農林水産関係。第70条第2号/第3号の該当は、労災の業種番号や
 *                   雇用保険の事業区分だけでは決まらないため断定しない (要検証)
 *   'no'          … 上記に当たらない
 */
export function judgeDualApplication(
  rousaiEntry: RousaiInsuranceRateEntry,
  koyouKind: KoyouBusinessKind,
): { level: 'yes' | 'needs-check' | 'no'; reasonJa: string } {
  if (rousaiEntry.category === '建設事業' || koyouKind === '建設の事業') {
    return {
      level: 'yes',
      reasonJa: '建設の事業は二元適用事業 (徴収法第39条第1項・施行規則第70条第4号)',
    };
  }
  if (rousaiEntry.code === '73' || rousaiEntry.code === '74') {
    return {
      level: 'needs-check',
      reasonJa:
        '港湾貨物取扱事業・港湾荷役業は、港湾労働法第2条第2号の港湾運送の行為を行う事業に当たれば二元適用事業となる (徴収法施行規則第70条第2号)。労災の業種番号だけでは決まらないため要検証',
    };
  }
  if (koyouKind === '農林水産・清酒製造の事業' || rousaiEntry.category === '林業' || rousaiEntry.category === '漁業') {
    return {
      level: 'needs-check',
      reasonJa:
        '雇用保険法附則第2条第1項各号に掲げる事業に当たれば二元適用事業となる (徴収法施行規則第70条第3号)。該当有無は本マスタでは判定できないため要検証',
    };
  }
  return { level: 'no', reasonJa: '一元適用事業として扱う (徴収法施行規則第70条のいずれにも当たらない)' };
}

/**
 * 労働保険料 (労災保険料 + 雇用保険料) の概算を出す。
 *
 * ★端数処理は行わない。円未満・銭未満の取扱いは今回の一次資料に記載が無く、
 *   推測で実装しないため (UNRESOLVED_ITEMS 参照)。切上げ・切捨ては呼び出し側の責任で行うこと。
 *
 * ★二元適用事業 (建設の事業など) では労災と雇用の算定基礎が別になる。
 *   koyouWageTotal を省略したまま建設の事業を計算しようとすると、誤った金額を返さずに例外を投げる。
 *
 * @param rousaiWageTotal 労災保険料の算定基礎となる賃金総額 [円]
 *                        (請負による建設事業で賃金総額の把握が困難な場合は
 *                         calcConstructionWageTotal() の結果を渡す)
 * @param rousaiCodeOrName 労災保険率を引くための業種番号または事業の種類名
 * @param koyouKind 雇用保険の事業区分
 * @param onDate 支払対象日 (雇用保険料率の年度判定に使う)
 * @param koyouWageTotal 雇用保険料の算定基礎となる賃金総額 [円]。
 *                       省略時は一元適用事業とみなして rousaiWageTotal を使う
 */
export function calcLabourInsurancePremium(
  rousaiWageTotal: number,
  rousaiCodeOrName: string,
  koyouKind: KoyouBusinessKind,
  onDate: Date | string = new Date(),
  koyouWageTotal?: number,
): {
  rousaiPremium: number;
  koyouEmployeePremium: number;
  koyouEmployerPremium: number;
  employerTotal: number;
  grandTotal: number;
  dualApplication: 'yes' | 'needs-check' | 'no';
  basisJa: string;
  roundingNoteJa: string;
  cautionJa: string | null;
} {
  if (!Number.isFinite(rousaiWageTotal) || rousaiWageTotal < 0) {
    throw new Error('労働保険料: 労災の賃金総額は0以上の数値で指定してください。');
  }
  if (koyouWageTotal !== undefined && (!Number.isFinite(koyouWageTotal) || koyouWageTotal < 0)) {
    throw new Error('労働保険料: 雇用保険の賃金総額は0以上の数値で指定してください。');
  }
  const rousai = getRousaiInsuranceRate(rousaiCodeOrName);
  const koyou = getKoyouInsuranceRate(koyouKind, onDate);
  const dual = judgeDualApplication(rousai, koyouKind);

  // 二元適用事業と確定するものは、同じ賃金総額を使い回した誤った金額を返さない
  if (dual.level === 'yes' && koyouWageTotal === undefined) {
    throw new Error(
      `労働保険料: ${dual.reasonJa}。労災保険と雇用保険で算定基礎が異なるため、雇用保険用の賃金総額を koyouWageTotal に別途指定してください。同じ賃金総額に両方の率を掛けると誤った保険料になります。`,
    );
  }

  const koyouBase = koyouWageTotal ?? rousaiWageTotal;
  const rousaiPremium = (rousaiWageTotal * rousai.ratePerMille) / 1000;
  const koyouEmployeePremium = (koyouBase * koyou.employeeRatePerMille) / 1000;
  const koyouEmployerPremium = (koyouBase * koyou.employerRatePerMille) / 1000;

  return {
    rousaiPremium,
    koyouEmployeePremium,
    koyouEmployerPremium,
    // 労災保険料は全額事業主負担
    employerTotal: rousaiPremium + koyouEmployerPremium,
    grandTotal: rousaiPremium + koyouEmployeePremium + koyouEmployerPremium,
    dualApplication: dual.level,
    basisJa: `労災: ${rousai.code} ${rousai.businessType} ${rousai.ratePerMille}/1,000 (令和6年4月1日施行・令和8年度同率) / 雇用: ${koyou.kind} 労働者${koyou.employeeRatePerMille}・事業主${koyou.employerRatePerMille} 計${koyou.totalRatePerMille}/1,000 (${koyou.fiscalYearJa})`,
    roundingNoteJa:
      '端数処理は未適用。円未満・銭未満の取扱いは本マスタの一次資料に記載が無いため実装していない',
    cautionJa:
      dual.level === 'needs-check'
        ? `${dual.reasonJa}。二元適用事業に当たる場合は労災と雇用で算定基礎が別になるため、koyouWageTotal を明示してください。`
        : null,
  };
}

// ---------------------------------------------------------------------------
// 自己検算
// ---------------------------------------------------------------------------

/**
 * マスタの自己検算。
 * 取り込み時・改定時に必ず実行し、ok=false が返ったら数値を疑うこと。
 *
 * 検査項目:
 *   - 件数 (労災54 / 労務費率9 / 第2種特別加入26 / 雇用保険3×2年度)
 *   - 料率の範囲が原典の最小値・最大値と一致すること
 *   - 業種番号・特別加入番号に重複が無いこと
 *   - 別表第1に載る区分が53件・船舶所有者のみ別扱いであること
 *   - 雇用保険料率の内訳の足し算が原典と合うこと
 *   - 労務費率表の業種番号が労災保険率表の建設事業と1対1で対応すること
 */
export function verifyRousaiInsuranceRateTable(): { ok: boolean; errors: string[] } {
  const errors: string[] = [];

  // --- 1. 労災保険率 -------------------------------------------------------
  if (ROUSAI_INSURANCE_RATE_TABLE.length !== 54) {
    errors.push(`労災保険率: 件数が54ではありません: ${ROUSAI_INSURANCE_RATE_TABLE.length}`);
  }
  const inAppendix = ROUSAI_INSURANCE_RATE_TABLE.filter((r) => r.inAppendix1);
  if (inAppendix.length !== 53) {
    errors.push(
      `労災保険率: 徴収則別表第1に掲げられる区分は53件のはずです (船舶所有者の事業は第16条第1項本文): ${inAppendix.length}`,
    );
  }
  const shipOwner = ROUSAI_INSURANCE_RATE_TABLE.find((r) => r.code === '90');
  if (!shipOwner) {
    errors.push('労災保険率: 業種番号90 (船舶所有者の事業) がありません');
  } else {
    if (shipOwner.ratePerMille !== 42) {
      errors.push(
        `労災保険率: 船舶所有者の事業は施行規則第16条第1項本文で千分の42と定められています: ${shipOwner.ratePerMille}`,
      );
    }
    if (shipOwner.inAppendix1) {
      errors.push('労災保険率: 船舶所有者の事業は別表第1に掲げられていません (inAppendix1=false であるべき)');
    }
  }

  // 業種番号の重複なし (林業の 02/03 は分解して検査)
  const flatCodes = ROUSAI_INSURANCE_RATE_TABLE.flatMap((r) => r.codes);
  const dupCodes = flatCodes.filter((c, i) => flatCodes.indexOf(c) !== i);
  if (dupCodes.length > 0) {
    errors.push(`労災保険率: 業種番号が重複しています: ${[...new Set(dupCodes)].join(', ')}`);
  }
  if (flatCodes.length !== 55) {
    // 54区分。ただし林業だけ番号を2つ持つので、番号の総数は55
    errors.push(`労災保険率: 業種番号の総数が55ではありません (林業のみ02・03の2番号): ${flatCodes.length}`);
  }
  ROUSAI_INSURANCE_RATE_TABLE.forEach((r) => {
    if (!(r.ratePerMille > 0)) errors.push(`労災保険率: ${r.code} の料率が正の数ではありません`);
    if (r.codes.length === 0) errors.push(`労災保険率: ${r.businessType} に業種番号がありません`);
    r.codes.forEach((c) => {
      if (!/^[0-9]{2}$/.test(c)) errors.push(`労災保険率: 業種番号「${c}」が2桁の数字ではありません`);
    });
  });
  const rousaiRates = ROUSAI_INSURANCE_RATE_TABLE.map((r) => r.ratePerMille);
  const rousaiMin = Math.min(...rousaiRates);
  const rousaiMax = Math.max(...rousaiRates);
  // 原典: 最小 2.5 (24 原油又は天然ガス鉱業 / 60 計量器等 / 97 通信業等 / 99 金融業等)、最大 88 (21 金属鉱業等)
  if (rousaiMin !== 2.5 || rousaiMax !== 88) {
    errors.push(`労災保険率: 料率の範囲が原典 (2.5〜88) と一致しません: ${rousaiMin}〜${rousaiMax}`);
  }
  // 料率は1/1,000単位で0.5刻み (原典の全値が 0.5 の倍数)
  ROUSAI_INSURANCE_RATE_TABLE.forEach((r) => {
    if (Math.round(r.ratePerMille * 2) !== r.ratePerMille * 2) {
      errors.push(`労災保険率: ${r.code} の料率が0.5刻みではありません: ${r.ratePerMille}`);
    }
  });
  // 値そのものの照合 (件数だけでは1件の打ち間違いを見逃すため、原典から独立に出した合計と突き合わせる)
  const rousaiSum = rousaiRates.reduce((a, b) => a + b, 0);
  if (Math.abs(rousaiSum - ROUSAI_RATE_CHECKSUM.totalRatePerMille) > 1e-9) {
    errors.push(
      `労災保険率: 54区分の料率合計が原典の ${ROUSAI_RATE_CHECKSUM.totalRatePerMille} と一致しません: ${rousaiSum}`,
    );
  }
  const appendix1Sum = inAppendix.reduce((a, r) => a + r.ratePerMille, 0);
  if (Math.abs(appendix1Sum - ROUSAI_RATE_CHECKSUM.appendix1TotalPerMille) > 1e-9) {
    errors.push(
      `労災保険率: 別表第1の53区分の合計が原典の ${ROUSAI_RATE_CHECKSUM.appendix1TotalPerMille} と一致しません: ${appendix1Sum}`,
    );
  }
  // 分類ごとの件数
  (Object.keys(ROUSAI_RATE_CHECKSUM.countByCategory) as RousaiBusinessCategory[]).forEach((cat) => {
    const expected = ROUSAI_RATE_CHECKSUM.countByCategory[cat];
    const actual = ROUSAI_INSURANCE_RATE_TABLE.filter((r) => r.category === cat).length;
    if (actual !== expected) {
      errors.push(`労災保険率: 分類「${cat}」の件数が原典の${expected}件と一致しません: ${actual}件`);
    }
  });

  // 非業務災害率はすべての労災保険率より小さいはず (率の一部を構成するため)
  if (!(NON_WORK_ACCIDENT_RATE_PER_MILLE < rousaiMin)) {
    errors.push(
      `非業務災害率 ${NON_WORK_ACCIDENT_RATE_PER_MILLE} が最小の労災保険率 ${rousaiMin} を下回っていません`,
    );
  }

  // --- 2. 労務費率 ---------------------------------------------------------
  if (ROUMUHIRITSU_TABLE.length !== 9) {
    errors.push(`労務費率: 件数が9ではありません (8業種・うち36が2細目): ${ROUMUHIRITSU_TABLE.length}`);
  }
  const roumuRates = ROUMUHIRITSU_TABLE.map((r) => r.ratePercent);
  const roumuMin = Math.min(...roumuRates);
  const roumuMax = Math.max(...roumuRates);
  if (roumuMin !== 17 || roumuMax !== 38) {
    errors.push(`労務費率: 率の範囲が原典 (17%〜38%) と一致しません: ${roumuMin}%〜${roumuMax}%`);
  }
  const roumuSum = roumuRates.reduce((a, b) => a + b, 0);
  if (Math.abs(roumuSum - ROUSAI_RATE_CHECKSUM.roumuhiritsuTotalPercent) > 1e-9) {
    errors.push(
      `労務費率: 9件の合計が原典 (別表第2) の ${ROUSAI_RATE_CHECKSUM.roumuhiritsuTotalPercent}% と一致しません: ${roumuSum}%`,
    );
  }
  // 労務費率の業種番号は労災保険率表の建設事業 (8区分) と1対1で対応する
  const constructionCodes = getRousaiRatesByCategory('建設事業')
    .map((r) => r.code)
    .sort();
  const roumuCodes = [...new Set(ROUMUHIRITSU_TABLE.map((r) => r.code))].sort();
  if (constructionCodes.join(',') !== roumuCodes.join(',')) {
    errors.push(
      `労務費率: 業種番号が労災保険率表の建設事業と一致しません (労災: ${constructionCodes.join('/')} / 労務費率: ${roumuCodes.join('/')})`,
    );
  }
  // 細目を持つのは36のみ
  const withSub = ROUMUHIRITSU_TABLE.filter((r) => r.subType !== null);
  if (withSub.length !== 2 || withSub.some((r) => r.code !== '36')) {
    errors.push('労務費率: 細目を持つのは業種番号36の2件のみのはずです');
  }

  // --- 3. 第2種特別加入保険料率 -------------------------------------------
  if (TOKUBETSU_KANYU_TYPE2_TABLE.length !== 26) {
    errors.push(`第2種特別加入保険料率: 件数が26ではありません: ${TOKUBETSU_KANYU_TYPE2_TABLE.length}`);
  }
  const tokuCodes = TOKUBETSU_KANYU_TYPE2_TABLE.map((r) => r.code);
  const dupToku = tokuCodes.filter((c, i) => tokuCodes.indexOf(c) !== i);
  if (dupToku.length > 0) {
    errors.push(`第2種特別加入保険料率: 番号が重複しています: ${[...new Set(dupToku)].join(', ')}`);
  }
  // 特1〜特26 が欠番なく揃っていること
  for (let i = 1; i <= 26; i++) {
    if (!tokuCodes.includes(`特${i}`)) errors.push(`第2種特別加入保険料率: 特${i} がありません`);
  }
  const tokuRates = TOKUBETSU_KANYU_TYPE2_TABLE.map((r) => r.ratePerMille);
  const tokuMin = Math.min(...tokuRates);
  const tokuMax = Math.max(...tokuRates);
  if (tokuMin !== 3 || tokuMax !== 52) {
    errors.push(`第2種特別加入保険料率: 料率の範囲が原典 (3〜52) と一致しません: ${tokuMin}〜${tokuMax}`);
  }
  const tokuSum = tokuRates.reduce((a, b) => a + b, 0);
  if (Math.abs(tokuSum - ROUSAI_RATE_CHECKSUM.tokubetsuType2TotalPerMille) > 1e-9) {
    errors.push(
      `第2種特別加入保険料率: 26件の合計が原典 (別表第5) の ${ROUSAI_RATE_CHECKSUM.tokubetsuType2TotalPerMille} と一致しません: ${tokuSum}`,
    );
  }
  // 特4 (林業の一人親方) は林業の労災保険率と同じ52であることが原典で確認できる
  const toku4 = TOKUBETSU_KANYU_TYPE2_TABLE.find((r) => r.code === '特4');
  const ringyo = ROUSAI_INSURANCE_RATE_TABLE.find((r) => r.code === '02・03');
  if (toku4 && ringyo && toku4.ratePerMille !== ringyo.ratePerMille) {
    errors.push(
      `第2種特別加入保険料率: 特4 (林業の一人親方) ${toku4.ratePerMille} が林業の労災保険率 ${ringyo.ratePerMille} と一致しません`,
    );
  }
  if (TOKUBETSU_KANYU_TYPE3_RATE_PER_MILLE !== 3) {
    errors.push('第3種特別加入保険料率: 施行規則第23条の3の千分の3と一致しません');
  }

  // --- 4. 雇用保険料率 -----------------------------------------------------
  const koyouTables: readonly (readonly [string, readonly KoyouInsuranceRateEntry[]])[] = [
    ['令和8年度', KOYOU_INSURANCE_RATE_TABLE_FY2026],
    ['令和7年度', KOYOU_INSURANCE_RATE_TABLE_FY2025],
  ];
  koyouTables.forEach(([fyJa, table]) => {
    if (table.length !== 3) {
      errors.push(`雇用保険料率(${fyJa}): 件数が3ではありません: ${table.length}`);
    }
    const kinds = table.map((r) => r.kind);
    if (new Set(kinds).size !== kinds.length) {
      errors.push(`雇用保険料率(${fyJa}): 事業の種類が重複しています`);
    }
    table.forEach((r) => {
      // ①+② = 合計
      if (Math.abs(r.employeeRatePerMille + r.employerRatePerMille - r.totalRatePerMille) > 1e-9) {
        errors.push(
          `雇用保険料率(${fyJa}) ${r.kind}: 労働者${r.employeeRatePerMille} + 事業主${r.employerRatePerMille} が合計${r.totalRatePerMille} と一致しません`,
        );
      }
      // ②の内訳の足し算
      if (
        Math.abs(
          r.employerUnemploymentPerMille + r.employerTwoBusinessPerMille - r.employerRatePerMille,
        ) > 1e-9
      ) {
        errors.push(
          `雇用保険料率(${fyJa}) ${r.kind}: 事業主負担の内訳 (失業等給付${r.employerUnemploymentPerMille} + 二事業${r.employerTwoBusinessPerMille}) が事業主負担${r.employerRatePerMille} と一致しません`,
        );
      }
      // 失業等給付分は労使折半 (原典で労働者負担=事業主負担の失業等給付分)
      if (Math.abs(r.employeeRatePerMille - r.employerUnemploymentPerMille) > 1e-9) {
        errors.push(
          `雇用保険料率(${fyJa}) ${r.kind}: 失業等給付等の分は労使同率のはずです (労働者${r.employeeRatePerMille} / 事業主${r.employerUnemploymentPerMille})`,
        );
      }
      // 二事業率は 3.5 (建設のみ 4.5)。徴収法第12条第10項の文言と一致する
      const expectedTwoBusiness = r.kind === '建設の事業' ? 4.5 : 3.5;
      if (r.employerTwoBusinessPerMille !== expectedTwoBusiness) {
        errors.push(
          `雇用保険料率(${fyJa}) ${r.kind}: 雇用保険二事業の率は${expectedTwoBusiness}のはずです: ${r.employerTwoBusinessPerMille}`,
        );
      }
    });
  });
  // 令和8年度は令和7年度より1.0/1,000 低い (原典: 失業等給付分が労使とも0.5ずつ引下げ)
  KOYOU_INSURANCE_RATE_TABLE_FY2026.forEach((now) => {
    const prev = KOYOU_INSURANCE_RATE_TABLE_FY2025.find((p) => p.kind === now.kind);
    if (!prev) {
      errors.push(`雇用保険料率: 令和7年度に「${now.kind}」がありません`);
      return;
    }
    if (Math.abs(prev.totalRatePerMille - now.totalRatePerMille - 1) > 1e-9) {
      errors.push(
        `雇用保険料率: ${now.kind} の令和7年度→令和8年度の引下げ幅が1.0/1,000ではありません (${prev.totalRatePerMille}→${now.totalRatePerMille})`,
      );
    }
  });

  // --- 5. メタの整合 -------------------------------------------------------
  if (ROUSAI_INSURANCE_RATE_META.effective_from !== '2024-04-01') {
    errors.push('メタ: 労災保険率の施行日は令和6年4月1日 (2024-04-01) です');
  }
  if (KOYOU_INSURANCE_RATE_META.effective_from !== '2026-04-01') {
    errors.push('メタ: 令和8年度の雇用保険料率の適用開始日は2026-04-01です');
  }

  return { ok: errors.length === 0, errors };
}
