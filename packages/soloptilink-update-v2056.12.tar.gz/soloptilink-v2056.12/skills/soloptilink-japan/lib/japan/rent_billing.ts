/**
 * rent_billing.ts — 家賃の請求 (日割り・消費税の課税区分・適格請求書・端数処理の必須化)
 *
 * 【出典 — 一次情報】
 *   消費税法 別表第二第十三号 (住宅の貸付けは非課税)・同第一号 (土地の貸付けは非課税)・57条の4第1項 (適格請求書の記載事項)
 *   消費税法施行令 16条の2 (貸付期間が1月に満たない場合・旅館業の施設の貸付けは住宅の貸付けから除く)・
 *     70条の10 (適格請求書の消費税額等は税率ごとに合計した額に税率を乗じ、1円未満の端数を処理する) — e-Gov 法令API v2 で 2026-10-03 取得
 *   国税庁 タックスアンサー No.6226「住宅の貸付け」・No.6213「駐車場の使用料など」(令和8年4月1日現在法令等。2026-10-03 取得)
 *     ・共益費は家賃に含まれ非課税。家賃と別に収受する専有部分の電気・ガス・水道の利用料は非課税の家賃に含まれない
 *     ・駐車場は「1戸あたり1台分以上が確保され、自動車の保有の有無にかかわらず割り当てられている等」かつ「家賃と別に使用料等を収受していない」場合だけ非課税
 *     ・駐車場など施設の利用に伴う土地の使用 (区画・舗装・フェンス等の整備) は課税。整備の無い土地の貸付けは非課税 (1月未満は課税)
 *     ・家具等を別の賃貸借の目的物として賃料を別に定めている場合は課税
 *     ・事業用 (住宅以外) の建物の貸付けは課税
 *
 * ★端数処理 (切捨て・切上げ・四捨五入) は契約・社内規程で決める事項のため、契約に設定が無ければ請求を作らない。
 * ★日割りの計算は既定で「月額 × 在室日数 ÷ 当月の日数」(業種辞書の手順)。契約で30日割りと定めた場合は prorationBasis='thirty_days'。
 * ★課税区分の当てはめ (居住用か・一体貸付けか) の最終判断は税理士の確認を推奨する (要確認)。
 */

export type RentRounding = 'floor' | 'ceil' | 'round_half_up';
export type RentLineKind = 'rent' | 'common_fee' | 'parking' | 'utility' | 'furniture' | 'renewal_fee' | 'other';
export type TaxCategory = 'non_taxable' | 'taxable_10';

export interface RentContractSettings {
  /** 用途: residential=契約で居住用と明らか / commercial=事業用 */
  use: 'residential' | 'commercial';
  /** 貸付期間が1か月未満か (施行令16条の2) */
  shortTermUnderOneMonth?: boolean;
  /** 旅館業 (民泊・ウィークリーマンション等) の施設の貸付けか (施行令16条の2) */
  ryokanOrMinpaku?: boolean;
  /** 端数処理 (必須)。無いと請求を作らない */
  rounding?: RentRounding;
  /** 日割りの基準 (既定: 当月の実日数) */
  prorationBasis?: 'actual_days' | 'thirty_days';
  /** 駐車場の条件 */
  parking?: {
    /** 区画・舗装・フェンス・管理など駐車場としての施設があるか */
    hasFacilities: boolean;
    /** 1戸あたり1台分以上が確保され、自動車の保有の有無にかかわらず割り当てられている */
    allottedToEveryUnit: boolean;
    /** 家賃と別に駐車場使用料を収受しているか */
    separateFee: boolean;
  };
  /** 請求する側 (適格請求書発行事業者なら登録番号 T+13桁) */
  issuer?: { name: string; registrationNo?: string };
  /** 請求を受ける側の氏名・名称 */
  customerName?: string;
}

export interface RentLine { kind: RentLineKind; label?: string; amountJpy: number }

/** 1行の課税区分を返す (国税庁 No.6226・No.6213) */
export function classifyRentLineTax(line: RentLine, c: RentContractSettings): { category: TaxCategory; reason: string } {
  const residentialExempt = c.use === 'residential' && !c.shortTermUnderOneMonth && !c.ryokanOrMinpaku;
  switch (line.kind) {
    case 'rent':
    case 'common_fee':
    case 'renewal_fee':
      if (residentialExempt) return { category: 'non_taxable', reason: '住宅の貸付け (共益費・更新料等も家賃に含む) は非課税 (消費税法別表第二第十三号)' };
      if (c.use === 'residential') return { category: 'taxable_10', reason: '貸付期間が1か月未満、又は旅館業の施設の貸付けのため住宅の貸付けから除かれます (施行令16条の2)' };
      return { category: 'taxable_10', reason: '住宅以外 (事業用) の建物の貸付けは課税' };
    case 'parking': {
      const p = c.parking;
      if (!p) return { category: 'taxable_10', reason: '駐車場の条件が設定されていないため、課税として扱います (安全側。設定してください)' };
      if (c.use === 'residential' && residentialExempt && p.allottedToEveryUnit && !p.separateFee) return { category: 'non_taxable', reason: '1戸1台以上の割当てがあり家賃と別に使用料を取らない駐車場は住宅の貸付けに含まれ非課税 (No.6226)' };
      if (!p.hasFacilities && !c.shortTermUnderOneMonth) return { category: 'non_taxable', reason: '駐車場としての施設の無い土地の貸付けは非課税 (別表第二第一号・No.6213)' };
      return { category: 'taxable_10', reason: '駐車場としての施設の利用に伴う土地の使用は課税 (No.6213)' };
    }
    case 'utility':
      return { category: 'taxable_10', reason: '家賃と別に収受する専有部分の電気・ガス・水道の利用料は非課税の家賃に含まれません (No.6226)' };
    case 'furniture':
      return { category: 'taxable_10', reason: '家具等を別の賃貸借の目的物として賃料を別に定めている場合は課税 (No.6226)' };
    default:
      return { category: 'taxable_10', reason: '課税区分を決める情報が無いため課税として扱います (安全側・要確認)' };
  }
}

function roundBy(x: number, mode: RentRounding): number {
  // 浮動小数の誤差を避けるため、小数第6位で丸めてから端数処理する
  const v = Math.round(x * 1e6) / 1e6;
  if (mode === 'floor') return Math.floor(v);
  if (mode === 'ceil') return Math.ceil(v);
  return Math.floor(v + 0.5);
}

const daysInMonth = (ym: string) => { const [y, m] = ym.split('-').map(Number); return new Date(Date.UTC(y, m, 0)).getUTCDate(); };

/**
 * 月の途中の入居・退去の日割り額を返す。fromDay・toDay は当月の日 (両端を含む)。
 *   端数処理が無いときは例外 (請求を作らない)。
 */
export function prorateRent(monthlyJpy: number, billingMonth: string, fromDay: number, toDay: number, c: Pick<RentContractSettings, 'rounding' | 'prorationBasis'>): { amountJpy: number; days: number; denominator: number } {
  if (!c.rounding) throw new Error('端数処理 (切捨て・切上げ・四捨五入) が契約に設定されていないため、日割りの額を出せません');
  const dim = daysInMonth(billingMonth);
  if (!(fromDay >= 1 && toDay <= dim && fromDay <= toDay)) throw new Error(`日割りの期間が当月 (${billingMonth}・${dim}日) の範囲にありません`);
  const days = toDay - fromDay + 1;
  const denominator = c.prorationBasis === 'thirty_days' ? 30 : dim;
  if (days >= dim) return { amountJpy: monthlyJpy, days, denominator };
  return { amountJpy: roundBy((monthlyJpy * Math.min(days, denominator)) / denominator, c.rounding), days, denominator };
}

export interface RentInvoiceResult {
  ok: boolean;
  code?: 'ROUNDING_NOT_SET' | 'INVALID_LINE';
  message: string;
  lines?: (RentLine & { category: TaxCategory; reason: string })[];
  nonTaxableTotalJpy?: number;
  taxableTotalExclTaxJpy?: number;
  consumptionTaxJpy?: number;
  totalJpy?: number;
  /** 適格請求書としての記載事項がそろっているか */
  qualifiedInvoice?: { qualified: boolean; missing: string[] };
}

/**
 * 家賃の請求書を作る。
 *   - 契約に端数処理の設定が無ければ作らない (code=ROUNDING_NOT_SET)
 *   - 行ごとに課税区分を決め、課税分は税率ごとに合計してから10%を乗じ、1円未満を契約の端数処理で処理する (施行令70条の10第1号)
 *   - 課税分があるときは適格請求書の記載事項 (消費税法57条の4第1項) を点検する
 */
export function buildRentInvoice(c: RentContractSettings, billingMonth: string, lines: RentLine[]): RentInvoiceResult {
  if (!c || !c.rounding) return { ok: false, code: 'ROUNDING_NOT_SET', message: '契約に端数処理 (切捨て・切上げ・四捨五入) が設定されていないため、請求を作れません。契約の設定で端数処理を選んでください' };
  for (const l of lines) if (!(typeof l.amountJpy === 'number' && Number.isFinite(l.amountJpy) && l.amountJpy >= 0 && Number.isInteger(l.amountJpy))) return { ok: false, code: 'INVALID_LINE', message: `金額が正しくない行があります (${l.label ?? l.kind})` };
  const classified = lines.map((l) => ({ ...l, ...classifyRentLineTax(l, c) }));
  const nonTaxable = classified.filter((l) => l.category === 'non_taxable').reduce((s, l) => s + l.amountJpy, 0);
  const taxable = classified.filter((l) => l.category === 'taxable_10').reduce((s, l) => s + l.amountJpy, 0);
  const tax = roundBy((taxable * 10) / 100, c.rounding);
  let qualifiedInvoice: RentInvoiceResult['qualifiedInvoice'];
  if (taxable > 0) {
    const missing: string[] = [];
    if (!c.issuer?.name) missing.push('適格請求書発行事業者の氏名又は名称');
    if (!(c.issuer?.registrationNo && /^T\d{13}$/.test(c.issuer.registrationNo))) missing.push('登録番号 (T+13桁)');
    if (!/^\d{4}-\d{2}$/.test(billingMonth)) missing.push('取引の年月日 (対象期間)');
    if (!c.customerName) missing.push('交付を受ける者の氏名又は名称');
    qualifiedInvoice = { qualified: missing.length === 0, missing };
  }
  return {
    ok: true,
    message: taxable > 0 && qualifiedInvoice && !qualifiedInvoice.qualified ? `請求を作りました。ただし適格請求書の記載事項が足りません: ${qualifiedInvoice.missing.join('・')}` : '請求を作りました',
    lines: classified,
    nonTaxableTotalJpy: nonTaxable,
    taxableTotalExclTaxJpy: taxable,
    consumptionTaxJpy: tax,
    totalJpy: nonTaxable + taxable + tax,
    qualifiedInvoice,
  };
}
