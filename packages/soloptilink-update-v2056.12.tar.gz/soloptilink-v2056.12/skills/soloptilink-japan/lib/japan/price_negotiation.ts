/**
 * 価格協議の記録 (申入れ・応答・説明・結論) と、協議のない一方的な単価の決定・据置きの警告
 *
 * ★2026-10-03 新設 (REQ-JPO-MNY-017・T08)。
 *
 * 【出典 — 一次情報 (2026-10-03 に本文を開いて確認)】
 *   - 取適法 (e-Gov 331AC0000000120) 第5条2項4号: 中小受託事業者の給付に関する費用の変動その他の事情が生じた場合において、
 *       中小受託事業者が代金の額に関する協議を求めたにもかかわらず、協議に応じず、又は協議において必要な説明若しくは
 *       情報の提供をせず、一方的に代金の額を決定すること (によって中小受託事業者の利益を不当に害すること) の禁止
 *   - 公取委 取適法Q&A https://www.jftc.go.jp/toriteki/toriteki_qa.html
 *       Q134: 要請額を受け入れられない場合は、その理由や考え方の根拠を十分に説明することが必要
 *       Q135: 協議に応じずにコスト上昇分を踏まえて決めても、申入れ額を下回るなら該当するおそれ
 *       Q137: 協議の求めと経過は、書面・電子メール等の形に残る方法で記録化することが望ましい
 *
 * 【決めごと】
 *   - 法令に「何日以内に回答」という日数の定めは無い。回答期限は会社が設定する値 (responsePeriodDays) で、未設定なら
 *     日数を作らず「未設定」を返す。期限超過の一覧には「法律で定められた日数ではない」旨の表示を必ず付ける。
 *   - 警告は「おそれ」「確認してください」の言い方にとどめ、違反と断定しない (違反かどうかは個別の事情で決まるため)。
 */
import { toYmd, addDaysYmd, type Ymd } from './toriteki';

export type NegotiationStage = 'requested' | 'responded' | 'concluded';
export type NegotiationConclusion = 'accepted' | 'partially_accepted' | 'not_accepted' | 'continuing';

export interface PriceNegotiationRecord {
  counterparty?: string;
  subject?: string;
  requested_at?: string | Date | null;
  requested_by?: 'contractor' | 'consignor' | string;
  request_content?: string;
  /** 求めた単価 (数値で持てる場合) */
  requested_unit_price?: number | null;
  request_reason?: string;
  response_at?: string | Date | null;
  explanation?: string;
  conclusion?: NegotiationConclusion | string;
  concluded_at?: string | Date | null;
  decided_unit_price?: number | null;
  recorded_by?: string;
  [k: string]: unknown;
}

/** 交渉記録の項目と、どの段から必須か */
export const PRICE_NEGOTIATION_RECORD_FIELDS: ReadonlyArray<{ key: string; label_ja: string; requiredFrom: NegotiationStage }> = [
  { key: 'counterparty', label_ja: '取引先', requiredFrom: 'requested' },
  { key: 'subject', label_ja: '対象の品目・役務', requiredFrom: 'requested' },
  { key: 'requested_at', label_ja: '申入れの日', requiredFrom: 'requested' },
  { key: 'requested_by', label_ja: '申入れた側 (受託側・委託側)', requiredFrom: 'requested' },
  { key: 'request_content', label_ja: '申入れの内容 (求めた額・率)', requiredFrom: 'requested' },
  { key: 'request_reason', label_ja: '申入れの理由 (費用の変動その他の事情)', requiredFrom: 'requested' },
  { key: 'recorded_by', label_ja: '記録した人', requiredFrom: 'requested' },
  { key: 'response_at', label_ja: '応答の日', requiredFrom: 'responded' },
  { key: 'explanation', label_ja: '説明・情報提供の内容 (受け入れない場合はその理由と根拠)', requiredFrom: 'concluded' },
  { key: 'conclusion', label_ja: '結論 (受入れ・一部受入れ・受け入れない・協議継続)', requiredFrom: 'concluded' },
  { key: 'concluded_at', label_ja: '結論の日', requiredFrom: 'concluded' },
  { key: 'decided_unit_price', label_ja: '決定した単価', requiredFrom: 'concluded' },
];
const STAGE_ORDER: Record<NegotiationStage, number> = { requested: 0, responded: 1, concluded: 2 };
const filled = (v: unknown) => v !== undefined && v !== null && String(v).trim() !== '';

/** その段で必須の項目を満たしているか (満たさない記録は保存させない) */
export function validateNegotiationRecord(rec: PriceNegotiationRecord, stage: NegotiationStage = 'concluded'): { ok: boolean; missing: string[]; labels: string[] } {
  const need = PRICE_NEGOTIATION_RECORD_FIELDS.filter((f) => STAGE_ORDER[f.requiredFrom] <= STAGE_ORDER[stage]);
  const miss = need.filter((f) => !filled(rec[f.key]));
  return { ok: miss.length === 0, missing: miss.map((f) => f.key), labels: miss.map((f) => f.label_ja) };
}

/** 記録の段 (結論・応答の有無から決める) */
export function negotiationStageOf(rec: PriceNegotiationRecord): NegotiationStage {
  if (filled(rec.conclusion) && filled(rec.concluded_at)) return 'concluded';
  if (filled(rec.response_at)) return 'responded';
  return 'requested';
}

/** 交渉記録の必須項目の充足 (結論済みの記録は結論の段まで、それ以外は今の段まで) */
export function negotiationRecordCompleteness(records: PriceNegotiationRecord[]): {
  totalRecords: number; completeRecords: number; ratePercent: number;
  incomplete: Array<{ counterparty: string; missing: string[] }>;
} {
  const incomplete: Array<{ counterparty: string; missing: string[] }> = [];
  for (const r of records) {
    const stage: NegotiationStage = filled(r.conclusion) || filled(r.decided_unit_price) ? 'concluded' : negotiationStageOf(r);
    const v = validateNegotiationRecord(r, stage);
    if (!v.ok) incomplete.push({ counterparty: String(r.counterparty ?? '(取引先未記入)'), missing: v.missing });
  }
  const total = records.length;
  const complete = total - incomplete.length;
  return { totalRecords: total, completeRecords: complete, ratePercent: total === 0 ? 100 : Math.floor((complete * 100) / total), incomplete };
}

const BASIS = '取適法 第5条第2項第4号 (協議に応じない一方的な代金決定)';

/**
 * 単価を確定する前の検査。申入れ (requested_at) があるのに応答日 (response_at) が空なら必ず警告する。
 * 応答があっても、説明が空のまま申入れどおりでない結論にした場合は警告する (Q134)。
 */
export function checkUnitPriceDecision(input: {
  negotiation?: PriceNegotiationRecord | null;
  decidedUnitPrice: number;
  previousUnitPrice?: number;
  decidedAt?: Date | string;
}): { level: 'warning' | 'none'; warnings: string[]; basis: string } {
  const n = input.negotiation;
  const warnings: string[] = [];
  if (!n || !filled(n.requested_at)) return { level: 'none', warnings, basis: BASIS };
  const who = n.counterparty ? `${n.counterparty} からの` : '';
  const stay = input.previousUnitPrice !== undefined && input.decidedUnitPrice === input.previousUnitPrice;
  const kind = stay ? '据置き' : input.previousUnitPrice !== undefined && input.decidedUnitPrice < input.previousUnitPrice ? '引下げ' : '決定';
  if (!filled(n.response_at)) {
    warnings.push(
      `${who}価格協議の申入れ (${toYmd(n.requested_at as string | Date)}) に応答した日が記録されていないまま、単価の${kind}を確定しようとしています。` +
      `協議に応じない一方的な代金決定 (${BASIS}) に当たるおそれがあります。協議して応答日・説明・結論を記録してから確定してください。`,
    );
  } else {
    const fullyAccepted = n.conclusion === 'accepted'
      || (typeof n.requested_unit_price === 'number' && input.decidedUnitPrice >= n.requested_unit_price);
    if (!fullyAccepted && !filled(n.explanation)) {
      warnings.push(
        `${who}申入れを全部は受け入れない単価の${kind}ですが、受け入れない理由や根拠の説明が記録されていません。` +
        `必要な説明をしないままの決定は ${BASIS} に当たるおそれがあります (公取委Q&A Q134)。説明の内容を記録してください。`,
      );
    }
  }
  return { level: warnings.length ? 'warning' : 'none', warnings, basis: BASIS };
}

/**
 * 会社が設定した回答期限を過ぎても応答していない申入れを全件出す。
 * 期限 = 申入れ日 + responsePeriodDays 日。その翌日から期限超過。
 */
export function checkUnansweredRequests(records: PriceNegotiationRecord[], opts: { responsePeriodDays?: number; asOf: Date | string }): {
  configured: boolean; responsePeriodDays: number | null; overdue: Array<{ counterparty: string; requested_at: Ymd; due: Ymd; message_ja: string }>; notice_ja: string;
} {
  const N = opts.responsePeriodDays;
  if (N === undefined || N === null || !Number.isInteger(N) || N < 0) {
    return { configured: false, responsePeriodDays: null, overdue: [],
      notice_ja: '価格協議の回答期限が設定されていません。法律に回答までの日数の定めは無いため、会社で回答期限 (日数) を設定してください。設定するまで期限超過の判定はしません。' };
  }
  const asOf = toYmd(opts.asOf);
  const overdue: Array<{ counterparty: string; requested_at: Ymd; due: Ymd; message_ja: string }> = [];
  for (const r of records) {
    if (!filled(r.requested_at) || filled(r.response_at)) continue;
    const req = toYmd(r.requested_at as string | Date);
    const due = addDaysYmd(req, N);
    if (asOf > due) {
      const cp = String(r.counterparty ?? '(取引先未記入)');
      overdue.push({ counterparty: cp, requested_at: req, due,
        message_ja: `${cp} からの価格協議の申入れ (${req}) に、会社の回答期限 (${due}) を過ぎても応答が記録されていません。協議に応じてください (${BASIS} に当たるおそれ)。` });
    }
  }
  return { configured: true, responsePeriodDays: N, overdue,
    notice_ja: `回答期限は会社が設定した日数 (${N}日) で、法律で定められた日数ではありません。期限内であっても、協議を求められたら速やかに応じてください。` };
}
