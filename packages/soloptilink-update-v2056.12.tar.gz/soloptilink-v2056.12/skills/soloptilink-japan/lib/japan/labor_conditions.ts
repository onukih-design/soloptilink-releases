/**
 * lib/japan/labor_conditions.ts — 労働条件通知書の明示事項・無期転換・年次有給休暇（期日で管理する）
 *
 * 根拠（e-Gov 法令API v2・取得日 2026-10-03。写しは ~/jpo-run/証跡/A1_実装/T12_一次資料/）:
 *   - 労働基準法 第15条第1項・同施行規則 第5条（asof=2024-03-31 と 2026-10-01 を比較）
 *       第1項第1号〜第11号。令和5年厚生労働省令第39号（2024-04-01 施行）で
 *       第1号の2 に「通算契約期間又は有期労働契約の更新回数に上限の定めがある場合には当該上限」、
 *       第1号の3 に「就業の場所及び従事すべき業務の変更の範囲」、第5項・第6項に「無期転換申込みに関する事項」と
 *       「当該申込みに係る期間の定めのない労働契約の内容である労働条件」が加わった。
 *       第3項・第4項: 書面（本人が希望すればファクシミリ・電子メール等）で明示する事項は第1号〜第4号（昇給を除く）と、該当時の無期転換の事項。
 *   - 短時間労働者及び有期雇用労働者の雇用管理の改善等に関する法律 第6条第1項・同施行規則 第2条第1項
 *       （asof=2026-09-30 と 2026-10-01 を比較。令和8年厚生労働省令第87号で第4号「法第十四条第二項の規定による説明を求めることができる旨」を追加、
 *       相談窓口は第5号へ）
 *   - 労働基準法 第39条第1項〜第3項・第7項、同施行規則 第24条の3（比例付与の表）・第24条の5・第24条の7（年次有給休暇管理簿）
 *   - 労働契約法 第18条、同条第1項の通算契約期間に関する基準を定める省令（平成24年厚生労働省令第148号）第1条・第2条
 *
 * ★この部品は「期日・明示事項の網羅」の計算と点検に留める。就業規則・労働条件通知書の作成そのものは社会保険労務士の業務（社労士法27条）にかかるため、
 *   文面の作成は行わない。期間の満了日の数え方など解釈の余地があるものは needsReview を返す。
 */

const DAY_MS = 86400000;
const parse = (s: string): [number, number, number] => {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(s));
  if (!m) throw new Error(`日付は YYYY-MM-DD で渡してください: ${s}`);
  return [Number(m[1]), Number(m[2]), Number(m[3])];
};
const dim = (y: number, m: number) => new Date(Date.UTC(y, m, 0)).getUTCDate();
const fmt = (y: number, m: number, d: number) => `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
const dayNo = (s: string) => { const [y, m, d] = parse(s); return Date.UTC(y, m - 1, d) / DAY_MS; };
const fromDayNo = (n: number) => { const t = new Date(n * DAY_MS); return fmt(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate()); };
const addDays = (s: string, n: number) => fromDayNo(dayNo(s) + n);
/** 暦で months か月後の応当日（応当日が無い月は翌月1日＝その月の末日の翌日） */
function addMonthsNextDayRule(s: string, months: number): string {
  const [y, m, d] = parse(s);
  const t = (m - 1) + months;
  const ty = y + Math.floor(t / 12);
  const tm = (t % 12) + 1;
  if (d > dim(ty, tm)) return addDays(fmt(ty, tm, dim(ty, tm)), 1);
  return fmt(ty, tm, d);
}
/** 民法143条2項: 起算日 start から years 年の期間の満了日 */
function periodEndYears(start: string, years: number): string {
  const [y, m, d] = parse(start);
  const ty = y + years;
  if (d > dim(ty, m)) return fmt(ty, m, dim(ty, m));
  return addDays(fmt(ty, m, d), -1);
}

/* ============================================================================
 * 1. 労働条件通知書の明示事項（版: 2024-04-01・2026-10-01）
 * ========================================================================== */

export const LABOR_NOTICE_VERSIONS = [
  { id: 'v2019', from: '2019-04-01', label: '2024-03-31 以前' },
  { id: 'v2024', from: '2024-04-01', label: '2024-04-01〜（令和5年厚生労働省令第39号: 更新上限・変更の範囲・無期転換の明示）' },
  { id: 'v2026', from: '2026-10-01', label: '2026-10-01〜（令和8年厚生労働省令第87号: 短時間・有期の「説明を求めることができる旨」）' },
] as const;
export const LABOR_NOTICE_2024_FROM = '2024-04-01';
export const PART_TIME_EXPLANATION_FROM = '2026-10-01';

export interface LaborNoticeItem {
  key: string;
  label: string;
  basis: string;
  /** 書面（又は本人希望の電子的方法）での明示が必要（労基則5条3項・4項・6項） */
  writtenRequired: boolean;
}
const LI = (key: string, label: string, basis: string, writtenRequired: boolean): LaborNoticeItem => ({ key, label, basis, writtenRequired });

/** 定めをする場合にだけ明示が必要な事項（労基則5条1項ただし書: 第4号の2〜第11号） */
export const LABOR_NOTICE_OPTIONAL_ITEMS: LaborNoticeItem[] = [
  LI('rule5_1_4_2', '退職手当の定めが適用される労働者の範囲・決定・計算・支払の方法・支払の時期', '労基則5条1項4号の2', false),
  LI('rule5_1_5', '臨時に支払われる賃金・賞与等・最低賃金額', '労基則5条1項5号', false),
  LI('rule5_1_6', '労働者に負担させる食費・作業用品その他', '労基則5条1項6号', false),
  LI('rule5_1_7', '安全及び衛生', '労基則5条1項7号', false),
  LI('rule5_1_8', '職業訓練', '労基則5条1項8号', false),
  LI('rule5_1_9', '災害補償及び業務外の傷病扶助', '労基則5条1項9号', false),
  LI('rule5_1_10', '表彰及び制裁', '労基則5条1項10号', false),
  LI('rule5_1_11', '休職', '労基則5条1項11号', false),
];

export interface LaborNoticeContext {
  /** 明示（労働契約の締結）の日 */
  asOf: string;
  /** 有期労働契約 */
  fixedTerm: boolean;
  /** 契約期間の満了後に更新する場合がある */
  renewable?: boolean;
  /** 通算契約期間又は更新回数の上限の定めがある */
  renewalCap?: boolean;
  /** その契約期間内に無期転換申込権が生じる有期労働契約 */
  mukiEligible?: boolean;
  /** 短時間労働者（パートタイム・有期雇用労働法の対象） */
  partTime?: boolean;
  /** 定めをする事項（rule5_1_4_2〜rule5_1_11 のキーを真にする） */
  defines?: Record<string, boolean>;
}

/** 明示の日と条件から、労働条件通知書に必要な事項を返す */
export function getLaborNoticeRequiredItems(ctx: LaborNoticeContext): LaborNoticeItem[] {
  const d = String(ctx.asOf).slice(0, 10);
  const v2024 = d >= LABOR_NOTICE_2024_FROM;
  const items: LaborNoticeItem[] = [LI('rule5_1_1', '労働契約の期間', '労基則5条1項1号', true)];
  if (ctx.fixedTerm && ctx.renewable) {
    items.push(LI('rule5_1_1_2', '期間の定めのある労働契約を更新する場合の基準', '労基則5条1項1号の2', true));
    if (v2024 && ctx.renewalCap) items.push(LI('rule5_1_1_2_cap', '通算契約期間又は更新回数の上限', '労基則5条1項1号の2（2024-04-01〜）', true));
  }
  items.push(LI('rule5_1_1_3', '就業の場所及び従事すべき業務', '労基則5条1項1号の3', true));
  if (v2024) items.push(LI('rule5_1_1_3_scope', '就業の場所及び従事すべき業務の変更の範囲', '労基則5条1項1号の3（2024-04-01〜）', true));
  items.push(LI('rule5_1_2', '始業・終業の時刻、所定労働時間を超える労働の有無、休憩時間、休日、休暇、交替制の就業時転換', '労基則5条1項2号', true));
  items.push(LI('rule5_1_3', '賃金の決定・計算・支払の方法、締切り・支払の時期、昇給（昇給は書面明示の対象外）', '労基則5条1項3号', true));
  items.push(LI('rule5_1_4', '退職に関する事項（解雇の事由を含む）', '労基則5条1項4号', true));
  for (const o of LABOR_NOTICE_OPTIONAL_ITEMS) if (ctx.defines && ctx.defines[o.key]) items.push(o);
  if (v2024 && ctx.fixedTerm && ctx.mukiEligible) {
    items.push(LI('rule5_5_muki', '無期転換申込みに関する事項（申込みができる旨）', '労基則5条5項・6項（2024-04-01〜）', true));
    items.push(LI('rule5_5_muki_conditions', '無期転換後の労働条件', '労基則5条5項・6項（2024-04-01〜）', true));
  }
  if (ctx.partTime || ctx.fixedTerm) {
    items.push(LI('part2_1', '昇給の有無', 'パート・有期法6条1項・同規則2条1項1号', true));
    items.push(LI('part2_2', '退職手当の有無', '同規則2条1項2号', true));
    items.push(LI('part2_3', '賞与の有無', '同規則2条1項3号', true));
    if (d >= PART_TIME_EXPLANATION_FROM) items.push(LI('part2_4', '待遇の相違の内容及び理由等について説明を求めることができる旨（法14条2項）', '同規則2条1項4号（2026-10-01〜）', true));
    items.push(LI('part2_consult', '雇用管理の改善等に関する事項に係る相談窓口', d >= PART_TIME_EXPLANATION_FROM ? '同規則2条1項5号' : '同規則2条1項4号', true));
  }
  return items;
}

/** 労働条件通知書の欠落を調べる（空文字・空白だけは記載なし） */
export function checkLaborConditionNotice(doc: Record<string, unknown>, ctx: LaborNoticeContext): { ok: boolean; version: string; missing: string[]; missingLabels: string[] } {
  const items = getLaborNoticeRequiredItems(ctx);
  const has = (v: unknown) => v !== undefined && v !== null && v !== false && !(typeof v === 'string' && v.trim() === '');
  const miss = items.filter((i) => !has(doc[i.key]));
  const d = String(ctx.asOf).slice(0, 10);
  const version = [...LABOR_NOTICE_VERSIONS].reverse().find((v) => d >= v.from)?.id || 'v2019';
  return { ok: miss.length === 0, version, missing: miss.map((i) => i.key), missingLabels: miss.map((i) => i.label) };
}

/* ============================================================================
 * 2. 年次有給休暇（労基法39条・労基則24条の3）
 * ========================================================================== */

const FULL_DAYS = [10, 11, 12, 14, 16, 18, 20];
/** 比例付与（労基則24条の3の表）: 週所定労働日数 → 6か月・1年6か月…6年6か月以上 */
const PROPORTIONAL: Record<number, number[]> = {
  4: [7, 8, 9, 10, 12, 13, 15],
  3: [5, 6, 6, 8, 9, 10, 11],
  2: [3, 4, 4, 5, 6, 6, 7],
  1: [1, 2, 2, 2, 3, 3, 3],
};

/**
 * 付与日と日数の予定（全労働日の8割以上出勤した前提。出勤率の判定は呼び出し側）
 *   6か月経過日 = 雇入れの日から起算して6か月を超えて継続勤務する日（雇入れ日の6か月後の応当日。応当日が無い月は翌月1日）
 *   週30時間以上 又は 週5日以上（年217日以上）は通常の日数、それ以外は比例付与の表。
 */
export function calcAnnualLeaveGrants(input: { hireDate: string; weeklyDays: number; weeklyHours: number; count?: number }): { grantDate: string; days: number; serviceLabel: string }[] {
  const n = Math.max(1, input.count ?? 7);
  const proportional = input.weeklyHours < 30 && input.weeklyDays <= 4;
  const table = proportional ? PROPORTIONAL[Math.max(1, Math.min(4, Math.floor(input.weeklyDays)))] : FULL_DAYS;
  const out: { grantDate: string; days: number; serviceLabel: string }[] = [];
  for (let i = 0; i < n; i++) {
    out.push({ grantDate: addMonthsNextDayRule(input.hireDate, 6 + 12 * i), days: table[Math.min(i, table.length - 1)], serviceLabel: i === 0 ? '6か月' : `${i}年6か月` });
  }
  return out;
}

/** 年5日の時季指定の期限（基準日から1年以内 = 基準日の1年後の応当日の前日。労基法39条7項） */
export function calcFiveDayObligationDeadline(grantDate: string): string {
  return periodEndYears(grantDate, 1);
}

/* ============================================================================
 * 3. 無期転換（労働契約法18条・平成24年厚生労働省令第148号）
 * ========================================================================== */

/** 契約期間を「月数＋端数日」で数え、端数日は30日を1月とする（省令1条2項） */
function contractMonths(start: string, end: string): { months: number; days: number } {
  const [sy, sm, sd] = parse(start);
  let months = 0;
  let cursor = start;
  // start から1か月ずつ進め、end の翌日を超えない範囲で数える
  const endNext = addDays(end, 1);
  for (;;) {
    const next = addMonthsNextDayRule(fmt(sy, sm, sd), months + 1);
    if (dayNo(next) > dayNo(endNext)) break;
    months += 1;
    cursor = next;
  }
  return { months, days: dayNo(endNext) - dayNo(cursor) };
}
const totalMonthsOf = (parts: { months: number; days: number }[]) => {
  const m = parts.reduce((a, p) => a + p.months, 0);
  const d = parts.reduce((a, p) => a + p.days, 0);
  return m + Math.floor(d / 30) + (d % 30) / 30;
};

/**
 * 無期転換申込権が生じる日（通算契約期間が5年を超えることとなる有期労働契約の初日）
 *   空白期間（無契約期間）が、直前の契約期間の通算（1年以上なら6月、1年未満ならその2分の1・1月未満の端数は1月）以上なら通算をリセットする。
 */
export function calcMukiTenkanRight(contracts: { start: string; end: string }[]): {
  arisesOn: string | null; applicableContract: { start: string; end: string } | null; totalMonths: number; resetByCooling: boolean; basis: string;
} {
  const sorted = [...contracts].sort((a, b) => dayNo(a.start) - dayNo(b.start));
  let parts: { months: number; days: number }[] = [];
  let resetByCooling = false;
  for (let i = 0; i < sorted.length; i++) {
    const c = sorted[i];
    if (i > 0) {
      const prevEnd = sorted[i - 1].end;
      const gapStart = addDays(prevEnd, 1);
      if (dayNo(c.start) > dayNo(gapStart)) {
        const prior = totalMonthsOf(parts);
        const threshold = prior >= 12 ? 6 : Math.min(6, Math.ceil(prior / 2));
        const gap = contractMonths(gapStart, addDays(c.start, -1));
        const gapMonths = gap.months + gap.days / 31; // 端数日は1月未満として扱う（6月に1日でも足りなければ未満）
        if (gapMonths >= threshold) { parts = []; resetByCooling = true; }
      }
    }
    parts.push(contractMonths(c.start, c.end));
    const total = totalMonthsOf(parts);
    if (total > 60) {
      return { arisesOn: c.start, applicableContract: c, totalMonths: total, resetByCooling, basis: '労働契約法18条1項（通算契約期間が5年を超える有期労働契約の契約期間中に申込みができる）' };
    }
  }
  return { arisesOn: null, applicableContract: null, totalMonths: totalMonthsOf(parts), resetByCooling, basis: '通算契約期間が5年を超えていない（労働契約法18条1項）' };
}
