/**
 * 協会けんぽ 都道府県支部別 健康保険料率マスタ (令和7年度 / 令和8年度) — 全国健康保険協会 実マスタ
 *
 * ★このファイルが存在する理由 (2026-09-10 実測):
 *   lib/japan/hr_payroll.ts は、介護保険料率・子ども子育て支援金率・雇用保険料率・厚生年金保険料率・
 *   標準報酬月額の等級表 (健保50等級 / 厚年32等級)・標準賞与額の上限を【すべて実数値で保持している】。
 *   欠けていたのは【健康保険料率だけ】であった。健康保険料率は協会けんぽの都道府県支部ごとに異なり
 *   全国一律の法定値が存在しないため、同ファイルは全国平均の概算 (RATES.HEALTH_EMPLOYEE = 0.0498)
 *   へフォールバックする実装になっている。本ファイルはその欠落を埋める 47 支部の実料率表である。
 *
 * ★★ 重複を作らないための宣言 (最重要) ★★
 *   本ファイルは【健康保険料率だけ】を持つ。以下は hr_payroll.ts に既に実データがあるため
 *   ここには一切書かない。数値を2か所に置くと、改定時に片方だけ更新されて食い違う事故が起きる。
 *     - 介護保険料率            → hr_payroll.ts LONG_TERM_CARE_RATES        (全国一律・年度表あり)
 *     - 子ども・子育て支援金率  → hr_payroll.ts CHILD_CARE_SUPPORT_RATES    (全国一律・年度表あり)
 *     - 雇用保険料率            → hr_payroll.ts EMPLOYMENT_INSURANCE_RATES  (事業の種類別・年度表あり)
 *     - 厚生年金保険料率        → hr_payroll.ts RATES.PENSION_EMPLOYEE      (18.300%・法定全国一律)
 *     - 標準報酬月額 等級表     → hr_payroll.ts HEALTH_INSURANCE_GRADES / PENSION_INSURANCE_GRADES
 *     - 標準賞与額の上限        → hr_payroll.ts STANDARD_BONUS_CAPS
 *     - 保険料の端数処理        → hr_payroll.ts roundEmployeeShare
 *   保険料の【計算】も hr_payroll.ts の役目である。本ファイルは料率を供給するだけで計算は持たない
 *   (計算経路が2本になると、同じ従業員の保険料が呼び出し元によって変わる)。
 *
 * ★東京支部の料率のみ lib/japan/legal-values/payroll.legal.json の
 *   fiscal_years.FY2026.health.tokyo_total_rate (0.0985) にも【検査用の期待値】として存在する。
 *   これは実装が引く値ではなく検査側の独立 SoT であり、本表と一致することを確かめる用途のものだが、
 *   改定時は本表と同 JSON の両方を更新すること (verifyHealthInsuranceRateTable は本表内の整合しか見ない)。
 *
 * 【出典 — 一次情報】
 *   全国健康保険協会「令和8年度保険料率」(都道府県別一覧)
 *   https://www.kyoukaikenpo.or.jp/g7/cat330/sb3130/r08/
 *   全国健康保険協会「令和7年度保険料率」(都道府県別一覧)
 *   https://www.kyoukaikenpo.or.jp/g7/cat330/sb3130/r07/
 *   全国健康保険協会「令和8年3月分(4月納付分)からの健康保険・厚生年金保険の保険料額表」47支部PDF
 *   https://www.kyoukaikenpo.or.jp/g7/cat330/sb3150/r08/r8ryougakuhyou3gatukara/
 *     (支部別PDFの URL 形式: https://www.kyoukaikenpo.or.jp/assets/R8_{JISコード2桁}{ローマ字}.pdf
 *      ★高知は R8_39kouchi.pdf、熊本は R8_43kumamotoi.pdf であり、単純なローマ字綴りでは 404 になる)
 *
 * 【根拠法令 — e-Gov 法令検索で条文を実確認 (法令ID 211AC0000000070)】
 *   健康保険法 第160条第1項
 *     「協会が管掌する健康保険の被保険者に関する一般保険料率は、千分の三十から千分の百三十までの
 *       範囲内において、支部被保険者…を単位として協会が決定するものとする。」
 *     同第2項「前項の規定により支部被保険者を単位として決定する一般保険料率(以下「都道府県単位保険料率」
 *       という。)は、当該支部被保険者に適用する。」
 *     → 支部ごとに料率が違うことは法律の建て付けそのものであり、全国一律の正解値は存在しない。
 *   健康保険法 第161条第1項
 *     「被保険者及び被保険者を使用する事業主は、それぞれ保険料額の二分の一を負担する。
 *       ただし、任意継続被保険者は、その全額を負担する。」
 *     → ★在職者は労使折半だが【任意継続被保険者は全額自己負担】である。本表の料率は
 *       いずれも【折半前の全体料率】であり、折半するかどうかは被保険者の区分で変わる。
 *
 * 【この表の検証経路 (2026-09-10 実施)】
 *   1. 令和8年度率 … 公式一覧ページ (HTML) と 47支部の保険料額表 PDF の【2経路】で全47件が一致。
 *   2. 令和8年度率 … 各支部PDFの第1級 (標準報酬月額58,000円) の保険料額と
 *      「58,000 × 料率」が全47件で一致することを機械照合 (一致47件 / 不一致0件)。
 *   3. 令和7年度率 … 令和8年度ページの前年度比較欄と令和7年度ページの【2経路】で全47件が一致。
 *   4. 副次確認 … 令和7年度ページ記載の介護保険料率 1.59% / 令和8年度PDF記載の 1.62%・
 *      子ども子育て支援金率 0.23%・厚生年金保険料率 18.300% が、いずれも hr_payroll.ts の
 *      既存値と一致することを確認した (=既存値の再取得は不要と判断した根拠)。
 *
 * 【取得できなかったもの — 推測で埋めていない】
 *   - 協会けんぽの全国平均保険料率 (令和8年度) … 上記一覧ページに記載が無く取得できなかった。
 *     平均料率は支部の加入者数による【加重平均】であり、47件の単純平均とは一致しないため、
 *     本表から自前で平均を計算して代用してはならない (単純平均を平均料率と称すると誤りになる)。
 *     このため本ファイルは全国平均値を持たない。必要になったら協会けんぽの公表資料から転記すること。
 *   - 令和6年度以前の支部別料率 … 今回は取得していない (令和7年度ページに前年度欄が無いため)。
 *     令和7年3月分より前の月の遡及計算はできない。getHealthInsuranceRate は黙って別年度の率を
 *     返さず、範囲外として例外を投げる。
 */

/** マスタの鮮度メタ (機械可読・数表は必ずこの形を持つ) */
export const HEALTH_INSURANCE_RATE_META = {
  master_ja: '健康保険料率 (協会けんぽ・都道府県支部別・折半前の全体料率)',
  applied_year_ja: '令和7年度 (令和7年3月分〜) / 令和8年度 (令和8年3月分〜・現行)',
  applied_fiscal_year: 'FY2025 / FY2026',
  source_url: 'https://www.kyoukaikenpo.or.jp/g7/cat330/sb3130/r08/',
  source_prev_year_url: 'https://www.kyoukaikenpo.or.jp/g7/cat330/sb3130/r07/',
  source_ryogakuhyo_index_url:
    'https://www.kyoukaikenpo.or.jp/g7/cat330/sb3150/r08/r8ryougakuhyou3gatukara/',
  legal_basis_ja: '健康保険法 第160条第1項・第2項 (都道府県単位保険料率) / 第161条第1項 (負担割合)',
  legal_source_url: 'https://laws.e-gov.go.jp/law/211AC0000000070',
  ingested_at: '2026-09-10',
  method: 'official-table' as const,
  /** 検証経路 (何をどう突き合わせて確かめたか。「確認した」とだけ書かない) */
  verification_ja:
    '令和8年度: 公式一覧ページと47支部の保険料額表PDFの2経路で全47件一致。さらに各PDFの第1級' +
    '(標準報酬月額58,000円)の保険料額と「58,000×料率」を機械照合し47件一致・0件不一致。' +
    '令和7年度: 令和8年度ページの前年度欄と令和7年度ページの2経路で全47件一致。',
  amendment_cycle_ja: '毎年度改定 (協会けんぽ運営委員会の議決を経て例年1〜2月に公表、3月分から適用)',
  next_review_due: '2027-02-01',
  /** 料率の適用は「保険料の対象月」で決まる。給与の支払月ではない (下の注意を必ず読むこと) */
  applies_from_ja: {
    FY2025: '令和7年3月分 (4月納付分) から (任意継続被保険者等は令和7年4月分から)',
    FY2026: '令和8年3月分 (4月納付分) から (任意継続被保険者等は令和8年4月分から)',
  },
  /** 全国平均料率は原典から取得できなかったため保持していない (理由はファイル冒頭を参照) */
  national_average_rate_bp: null as number | null,
  national_average_unavailable_reason_ja:
    '協会けんぽの平均保険料率は加入者数による加重平均であり、公式一覧ページに数値の記載が無かった。' +
    '47支部の単純平均で代用すると誤った値になるため、あえて空欄にしている。',
} as const;

/**
 * 料率は【1万分率の整数】(bp = 1/10,000) で保持する。
 *
 * ★なぜ小数 (0.0985) で持たないか — 2026-09-10 に全数実測した結果:
 *   料率を小数へ変換してから掛けると、2進浮動小数点の誤差で保険料額表と食い違う。
 *   47支部 × 健康保険50等級 = 2,350通りを実際に計算して比べたところ、
 *     ・全額が食い違う組み合わせ            187通り
 *     ・被保険者の控除額が【1円ずれる】組み合わせ  19通り
 *   が実在した (福井3件・岡山3件・山口10件・高知3件)。
 *   実例: 山口支部 10.15% × 標準報酬月額530,000円
 *     整数演算 530,000 × 1015 / 10,000 = 53,795   → 折半 26,897.5 → 50銭ちょうどは切捨てで 26,897円
 *     小数演算 530,000 × 0.1015        = 53,795.00000000001
 *                                       → 折半 26,897.500000000004 → 切上げられて 26,898円
 *   協会けんぽ山口支部の令和8年度保険料額表には「53,795.0 / 26,897.5」と明記されており、
 *   正しい控除額は 26,897円 である。小数経由では1円の過大徴収になる。
 *   ★hr_payroll.ts の roundEmployeeShare は「50銭ちょうどは切捨て」という法定ルールを
 *     正しく実装しているが、渡される金額が誤差を含むとその防御が破られる。
 *     整数のまま `標準報酬月額 × bp / 10000` の順で計算すれば誤差は生じない。
 *   例: 58,000 × 985 / 10,000 = 5,713 (協会けんぽ東京支部の保険料額表と一致)
 */
export interface HealthInsuranceRateEntry {
  /** JIS 都道府県コード (1〜47) */
  readonly code: number;
  /** 支部名 (協会けんぽの支部は都道府県単位。表記は「東京」「大阪」等の県名部分のみ) */
  readonly pref: string;
  /** 令和7年度 健康保険料率 [1万分率] 例: 9.91% → 991 */
  readonly fy2025Bp: number;
  /** 令和8年度 健康保険料率 [1万分率] 例: 9.85% → 985 */
  readonly fy2026Bp: number;
  /** 改定幅 [1万分率] (fy2026Bp - fy2025Bp)。0 は据え置き、負は引下げ */
  readonly changeBp: number;
}

/**
 * 47支部マスタ。原典の表順 (北海道→沖縄 / JISコード順) をそのまま保持している。
 * ★令和8年度は【全47支部が引下げまたは据え置き】であり、引上げの支部は1つも無い
 *   (引下げ40支部 / 据え置き7支部 / 引上げ0支部)。この件数は自己検算で毎回突き合わせる。
 */
export const HEALTH_INSURANCE_RATE_TABLE: readonly HealthInsuranceRateEntry[] = [
  { code: 1, pref: '北海道', fy2025Bp: 1031, fy2026Bp: 1028, changeBp: -3 },
  { code: 2, pref: '青森', fy2025Bp: 985, fy2026Bp: 985, changeBp: 0 },
  { code: 3, pref: '岩手', fy2025Bp: 962, fy2026Bp: 951, changeBp: -11 },
  { code: 4, pref: '宮城', fy2025Bp: 1011, fy2026Bp: 1010, changeBp: -1 },
  { code: 5, pref: '秋田', fy2025Bp: 1001, fy2026Bp: 1001, changeBp: 0 },
  { code: 6, pref: '山形', fy2025Bp: 975, fy2026Bp: 975, changeBp: 0 },
  { code: 7, pref: '福島', fy2025Bp: 962, fy2026Bp: 950, changeBp: -12 },
  { code: 8, pref: '茨城', fy2025Bp: 967, fy2026Bp: 952, changeBp: -15 },
  { code: 9, pref: '栃木', fy2025Bp: 982, fy2026Bp: 982, changeBp: 0 },
  { code: 10, pref: '群馬', fy2025Bp: 977, fy2026Bp: 968, changeBp: -9 },
  { code: 11, pref: '埼玉', fy2025Bp: 976, fy2026Bp: 967, changeBp: -9 },
  { code: 12, pref: '千葉', fy2025Bp: 979, fy2026Bp: 973, changeBp: -6 },
  { code: 13, pref: '東京', fy2025Bp: 991, fy2026Bp: 985, changeBp: -6 },
  { code: 14, pref: '神奈川', fy2025Bp: 992, fy2026Bp: 992, changeBp: 0 },
  { code: 15, pref: '新潟', fy2025Bp: 955, fy2026Bp: 921, changeBp: -34 },
  { code: 16, pref: '富山', fy2025Bp: 965, fy2026Bp: 959, changeBp: -6 },
  { code: 17, pref: '石川', fy2025Bp: 988, fy2026Bp: 970, changeBp: -18 },
  { code: 18, pref: '福井', fy2025Bp: 994, fy2026Bp: 971, changeBp: -23 },
  { code: 19, pref: '山梨', fy2025Bp: 989, fy2026Bp: 955, changeBp: -34 },
  { code: 20, pref: '長野', fy2025Bp: 969, fy2026Bp: 963, changeBp: -6 },
  { code: 21, pref: '岐阜', fy2025Bp: 993, fy2026Bp: 980, changeBp: -13 },
  { code: 22, pref: '静岡', fy2025Bp: 980, fy2026Bp: 961, changeBp: -19 },
  { code: 23, pref: '愛知', fy2025Bp: 1003, fy2026Bp: 993, changeBp: -10 },
  { code: 24, pref: '三重', fy2025Bp: 999, fy2026Bp: 977, changeBp: -22 },
  { code: 25, pref: '滋賀', fy2025Bp: 997, fy2026Bp: 988, changeBp: -9 },
  { code: 26, pref: '京都', fy2025Bp: 1003, fy2026Bp: 989, changeBp: -14 },
  { code: 27, pref: '大阪', fy2025Bp: 1024, fy2026Bp: 1013, changeBp: -11 },
  { code: 28, pref: '兵庫', fy2025Bp: 1016, fy2026Bp: 1012, changeBp: -4 },
  { code: 29, pref: '奈良', fy2025Bp: 1002, fy2026Bp: 991, changeBp: -11 },
  { code: 30, pref: '和歌山', fy2025Bp: 1019, fy2026Bp: 1006, changeBp: -13 },
  { code: 31, pref: '鳥取', fy2025Bp: 993, fy2026Bp: 986, changeBp: -7 },
  { code: 32, pref: '島根', fy2025Bp: 994, fy2026Bp: 994, changeBp: 0 },
  { code: 33, pref: '岡山', fy2025Bp: 1017, fy2026Bp: 1005, changeBp: -12 },
  { code: 34, pref: '広島', fy2025Bp: 997, fy2026Bp: 978, changeBp: -19 },
  { code: 35, pref: '山口', fy2025Bp: 1036, fy2026Bp: 1015, changeBp: -21 },
  { code: 36, pref: '徳島', fy2025Bp: 1047, fy2026Bp: 1024, changeBp: -23 },
  { code: 37, pref: '香川', fy2025Bp: 1021, fy2026Bp: 1002, changeBp: -19 },
  { code: 38, pref: '愛媛', fy2025Bp: 1018, fy2026Bp: 998, changeBp: -20 },
  { code: 39, pref: '高知', fy2025Bp: 1013, fy2026Bp: 1005, changeBp: -8 },
  { code: 40, pref: '福岡', fy2025Bp: 1031, fy2026Bp: 1011, changeBp: -20 },
  { code: 41, pref: '佐賀', fy2025Bp: 1078, fy2026Bp: 1055, changeBp: -23 },
  { code: 42, pref: '長崎', fy2025Bp: 1041, fy2026Bp: 1006, changeBp: -35 },
  { code: 43, pref: '熊本', fy2025Bp: 1012, fy2026Bp: 1008, changeBp: -4 },
  { code: 44, pref: '大分', fy2025Bp: 1025, fy2026Bp: 1008, changeBp: -17 },
  { code: 45, pref: '宮崎', fy2025Bp: 1009, fy2026Bp: 977, changeBp: -32 },
  { code: 46, pref: '鹿児島', fy2025Bp: 1031, fy2026Bp: 1013, changeBp: -18 },
  { code: 47, pref: '沖縄', fy2025Bp: 944, fy2026Bp: 944, changeBp: 0 },
] as const;

/**
 * 原典に明記されている特徴値 (転記ミスを検出するための照合基準)。
 * ★自前で表から算出した値ではなく、原典の一覧表の増減記号・最高値・最低値を数えたものである。
 */
export const HEALTH_INSURANCE_RATE_FACTS = {
  /** 令和8年度に引下げとなった支部数 (原典の「↓」の数) */
  fy2026_decreased_count: 40,
  /** 令和8年度に据え置きとなった支部数 (原典の「→」の数) */
  fy2026_unchanged_count: 7,
  /** 令和8年度に引上げとなった支部数 (原典の「↑」の数。令和8年度は0) */
  fy2026_increased_count: 0,
  /** 令和8年度の最高料率 (佐賀 10.55%) */
  fy2026_max: { pref: '佐賀', bp: 1055 },
  /** 令和8年度の最低料率 (新潟 9.21%) */
  fy2026_min: { pref: '新潟', bp: 921 },
  /** 令和7年度の最高料率 (佐賀 10.78%) */
  fy2025_max: { pref: '佐賀', bp: 1078 },
  /** 令和7年度の最低料率 (沖縄 9.44%) */
  fy2025_min: { pref: '沖縄', bp: 944 },
  /** 健康保険法第160条第1項が定める一般保険料率の下限 (千分の30 = 300bp) */
  statutory_min_bp: 300,
  /** 健康保険法第160条第1項が定める一般保険料率の上限 (千分の130 = 1300bp) */
  statutory_max_bp: 1300,
} as const;

/**
 * 令和8年度 保険料額表の第1級 (標準報酬月額58,000円・介護保険第2号被保険者に該当しない場合) の
 * 健康保険料【全額】。単位は 0.1円 (表は 6,119.0 のように小数第1位まで載る)。
 *
 * ★これは保険料計算に使う値ではなく、料率の転記ミスを実額側から検出するための【照合基準】である。
 *   3支部だけを持つのは、47件すべてを持つと保守対象が二重になり、改定時に片方だけ更新される
 *   事故を招くため。最高 (佐賀)・最低 (新潟)・最多利用 (東京) の3点を押さえれば桁ずれと
 *   小数点位置の誤りは検出できる。
 * 【出典】各支部の令和8年3月分からの保険料額表PDF (本ファイル冒頭のURL形式を参照)
 */
export const GRADE1_PREMIUM_ANCHORS_FY2026: readonly {
  readonly pref: string;
  readonly standardRemuneration: number;
  /** 保険料額表に記載された全額 × 10 (0.1円単位の整数) */
  readonly fullPremiumX10: number;
}[] = [
  { pref: '東京', standardRemuneration: 58_000, fullPremiumX10: 57_130 }, // 表記 5,713.0円
  { pref: '新潟', standardRemuneration: 58_000, fullPremiumX10: 53_418 }, // 表記 5,341.8円
  { pref: '佐賀', standardRemuneration: 58_000, fullPremiumX10: 61_190 }, // 表記 6,119.0円
] as const;

/** 本表が扱える保険料の対象月の範囲 (これより前・後は例外にする) */
const COVERAGE = {
  /** 令和7年度料率の開始月 (令和7年3月分) */
  fy2025_from: '2025-03',
  /** 令和8年度料率の開始月 (令和8年3月分) */
  fy2026_from: '2026-03',
  /** 本表が扱える最終月 (令和9年2月分。令和9年度の改定は未取込) */
  until: '2027-02',
  /** 任意継続被保険者は1ヶ月遅れて4月分から新料率になる */
  voluntary_offset_months: 1,
} as const;

/** 都道府県名の表記ゆれ吸収 (「東京都」「大阪府」「北海道」いずれでも引けるようにする) */
function normalizePref(input: string): string {
  return input
    .trim()
    .replace(/[都府県]$/, '')
    .replace(/^北海$/, '北海道'); // 「北海道」から「道」は落とさない
}

/** 'YYYY-MM' / Date を 'YYYY-MM' へ正規化する */
function toMonthKey(v: string | Date): string {
  if (v instanceof Date) {
    const y = v.getFullYear();
    const m = String(v.getMonth() + 1).padStart(2, '0');
    return `${y}-${m}`;
  }
  const s = v.trim();
  if (!/^\d{4}-\d{2}$/.test(s)) {
    throw new Error(
      `健康保険料率: 保険料の対象月は「YYYY-MM」の形式で指定してください (受け取った値: ${v})。`,
    );
  }
  return s;
}

/** 対象月に1ヶ月足した 'YYYY-MM' を返す (任意継続被保険者の適用開始をずらすために使う) */
function addMonth(key: string): string {
  const y = Number(key.slice(0, 4));
  const m = Number(key.slice(5, 7));
  const ny = m === 12 ? y + 1 : y;
  const nm = m === 12 ? 1 : m + 1;
  return `${ny}-${String(nm).padStart(2, '0')}`;
}

export interface HealthInsuranceRateResult {
  /** 支部名 */
  pref: string;
  /** JIS 都道府県コード */
  code: number;
  /** 適用料率 [1万分率の整数]。保険料計算はこの整数のまま行うこと (浮動小数点誤差を避ける) */
  rateBp: number;
  /** 適用料率 [%] 画面表示用 (例: 9.85) */
  ratePercent: number;
  /**
   * 適用料率 [小数・折半前の全体料率] (例: 0.0985)。
   * ★hr_payroll.ts の Employee.health_insurance_rate はこの「折半前の全体料率」を受け取る仕様なので、
   *   この値をそのまま渡せる (同ファイルが内部で 1/2 にする)。折半済みの値を渡すと保険料が半額になる。
   *
   * ★ただし既知の限界がある (2026-09-10 実測):
   *   hr_payroll.ts は「標準報酬月額 × 小数の料率」で計算するため、上記 rateBp の説明にある
   *   19通りの組み合わせ (福井・岡山・山口・高知の特定等級) で被保険者の控除額が
   *   保険料額表より1円多くなる。実際に山口支部10.15%・標準報酬月額530,000円で再現し、
   *   保険料額表の 26,897円 に対し 26,898円 が出ることを確認した。
   *   厳密な額が要る場面 (実際の振込・納入告知額との突合・賞与支払届) では rateBp を使い、
   *   整数演算 `標準報酬月額 × rateBp / 10000` で全額を出してから折半・端数処理を行うこと。
   */
  rateTotal: number;
  /** 適用年度キー */
  fiscalYear: 'FY2025' | 'FY2026';
  /** 適用年度の和暦表示 */
  fiscalYearJa: string;
  /** 適用開始時期の日本語表示 (画面にそのまま出す) */
  appliesFromJa: string;
  /** 任意継続被保険者として引いたか */
  isVoluntaryContinuation: boolean;
  /** 負担割合の注意 (健康保険法第161条第1項)。画面・明細にそのまま出す */
  burdenNoteJa: string;
  /** 一次情報の出典 URL */
  sourceUrl: string;
}

/**
 * 指定した【保険料の対象月】に適用される協会けんぽ支部の健康保険料率 (折半前の全体料率) を返す。
 *
 * ★★ 実装上もっとも間違えやすい一点 ★★
 *   健康保険料率の改定は「令和8年【3月分】(4月納付分)から」である。
 *   多くの会社は当月分の保険料を翌月支払の給与から控除するため、
 *   【令和8年4月に支払う給与】から新料率になる。給与の支払月をそのまま渡すと1ヶ月早く
 *   新料率を当ててしまい、3月支払給与が過大 (または過少) になる。
 *   この関数には必ず「保険料の対象月 (何月分か)」を渡すこと。支払月ではない。
 *
 * ★年度で引かず対象月で引く理由: 社会保険の年度は4月始まりだが、健康保険料率の切替は
 *   【3月分】である。年度 (4月〜) で引くと3月分だけ必ず旧料率になる。
 *
 * @param pref     都道府県名 (「東京」「東京都」いずれも可)
 * @param forMonth 保険料の対象月 'YYYY-MM' (給与の支払月ではない)
 * @param opts.isVoluntaryContinuation 任意継続被保険者として引く (適用開始が1ヶ月遅く、負担は全額)
 * @throws 都道府県名が特定できない場合 / 対象月が本表の範囲外の場合
 */
export function getHealthInsuranceRate(
  pref: string,
  forMonth: string | Date,
  opts: { isVoluntaryContinuation?: boolean } = {},
): HealthInsuranceRateResult {
  const key = normalizePref(pref);
  const row = HEALTH_INSURANCE_RATE_TABLE.find((r) => normalizePref(r.pref) === key);
  if (!row) {
    throw new Error(
      `健康保険料率: 都道府県「${pref}」が特定できません。` +
      `協会けんぽの支部は47都道府県単位です。いずれかを指定してください。`,
    );
  }

  const month = toMonthKey(forMonth);
  const voluntary = opts.isVoluntaryContinuation === true;
  const offset = voluntary ? COVERAGE.voluntary_offset_months : 0;
  const fy2026From = offset === 0 ? COVERAGE.fy2026_from : addMonth(COVERAGE.fy2026_from);
  const fy2025From = offset === 0 ? COVERAGE.fy2025_from : addMonth(COVERAGE.fy2025_from);
  const until = offset === 0 ? COVERAGE.until : addMonth(COVERAGE.until);

  if (month < fy2025From) {
    throw new Error(
      `健康保険料率: ${month}分の料率は本マスタに収録されていません ` +
      `(収録範囲は ${fy2025From}分〜${until}分)。` +
      `協会けんぽの過年度の保険料額表から当時の支部別料率を取得してください。` +
      `別の年度の料率で代用すると、遡及計算の保険料が当時の実額と食い違います。`,
    );
  }
  if (month > until) {
    throw new Error(
      `健康保険料率: ${month}分の料率は未取込です (本マスタの収録は ${until}分まで)。` +
      `協会けんぽが公表する次年度の保険料率を取り込んでください。` +
      `古い年度の料率のまま計算すると、保険料が実額と食い違います。`,
    );
  }

  const isFy2026 = month >= fy2026From;
  const bp = isFy2026 ? row.fy2026Bp : row.fy2025Bp;
  return {
    pref: row.pref,
    code: row.code,
    rateBp: bp,
    ratePercent: bp / 100,
    rateTotal: bp / 10_000,
    fiscalYear: isFy2026 ? 'FY2026' : 'FY2025',
    fiscalYearJa: isFy2026 ? '令和8年度' : '令和7年度',
    appliesFromJa: isFy2026
      ? HEALTH_INSURANCE_RATE_META.applies_from_ja.FY2026
      : HEALTH_INSURANCE_RATE_META.applies_from_ja.FY2025,
    isVoluntaryContinuation: voluntary,
    burdenNoteJa: voluntary
      ? '任意継続被保険者は保険料の全額を自己負担します (健康保険法第161条第1項ただし書き)。' +
        'この料率を労使折半して控除額を出すと、実際の納付額の半分にしかなりません。'
      : '被保険者と事業主がそれぞれ保険料額の2分の1を負担します (健康保険法第161条第1項)。' +
        'この料率は折半前の全体料率です。',
    sourceUrl: HEALTH_INSURANCE_RATE_META.source_url,
  };
}

/**
 * 指定した対象月に適用される47支部の料率を一覧で返す (料率比較・支部設定画面の選択肢に使う)。
 * @param forMonth 保険料の対象月 'YYYY-MM'
 */
export function listHealthInsuranceRates(
  forMonth: string | Date,
): { pref: string; code: number; rateBp: number; ratePercent: number; rateTotal: number }[] {
  return HEALTH_INSURANCE_RATE_TABLE.map((r) => {
    const hit = getHealthInsuranceRate(r.pref, forMonth);
    return {
      pref: hit.pref,
      code: hit.code,
      rateBp: hit.rateBp,
      ratePercent: hit.ratePercent,
      rateTotal: hit.rateTotal,
    };
  });
}

/**
 * マスタの自己検算。
 * 取り込み時・改定時に必ず実行し、false が返ったら数値を疑うこと。
 *
 * 検査項目:
 *  1. 件数47 / JISコードの連番 / 支部名の重複なし
 *  2. 料率が整数の1万分率であること (小数を書き込むと整数演算が壊れる)
 *  3. 全料率が健康保険法第160条第1項の法定範囲 (千分の30〜千分の130) 内であること
 *  4. changeBp が fy2026Bp − fy2025Bp と一致すること
 *  5. 引下げ40 / 据え置き7 / 引上げ0 が原典の増減記号の件数と一致すること
 *  6. 最高・最低の支部と値が原典と一致すること (令和7年度・令和8年度の両方)
 *  7. 保険料額表の第1級 (58,000円) の実額と「58,000 × 料率」が一致すること (整数演算で照合)
 */
export function verifyHealthInsuranceRateTable(): { ok: boolean; errors: string[] } {
  const errors: string[] = [];
  const F = HEALTH_INSURANCE_RATE_FACTS;

  // 1. 件数・連番・重複
  if (HEALTH_INSURANCE_RATE_TABLE.length !== 47) {
    errors.push(`件数が47ではありません: ${HEALTH_INSURANCE_RATE_TABLE.length}`);
  }
  const seen = new Set<string>();
  HEALTH_INSURANCE_RATE_TABLE.forEach((r, i) => {
    if (r.code !== i + 1) errors.push(`${r.pref}: 都道府県コードが連番ではありません (${r.code})`);
    if (seen.has(r.pref)) errors.push(`${r.pref}: 支部名が重複しています`);
    seen.add(r.pref);

    // 2. 整数であること
    if (!Number.isInteger(r.fy2025Bp) || !Number.isInteger(r.fy2026Bp)) {
      errors.push(
        `${r.pref}: 料率が1万分率の整数ではありません (令和7年度 ${r.fy2025Bp} / 令和8年度 ${r.fy2026Bp})。` +
        `9.85% は 985 と書きます (0.0985 と書くと保険料が1万分の1になります)。`,
      );
    }

    // 3. 法定範囲 (健康保険法第160条第1項)
    for (const [label, bp] of [['令和7年度', r.fy2025Bp], ['令和8年度', r.fy2026Bp]] as const) {
      if (bp < F.statutory_min_bp || bp > F.statutory_max_bp) {
        errors.push(
          `${r.pref}: ${label}の料率 ${bp / 100}% が健康保険法第160条第1項の範囲` +
          `(千分の30〜千分の130 = 3.0%〜13.0%)を外れています`,
        );
      }
    }

    // 4. 改定幅の整合
    if (r.fy2026Bp - r.fy2025Bp !== r.changeBp) {
      errors.push(
        `${r.pref}: 令和8年度 ${r.fy2026Bp} − 令和7年度 ${r.fy2025Bp} が改定幅 ${r.changeBp} と一致しません`,
      );
    }
  });

  // 5. 増減の件数 (原典の ↓ → ↑ の数)
  const dec = HEALTH_INSURANCE_RATE_TABLE.filter((r) => r.changeBp < 0).length;
  const same = HEALTH_INSURANCE_RATE_TABLE.filter((r) => r.changeBp === 0).length;
  const inc = HEALTH_INSURANCE_RATE_TABLE.filter((r) => r.changeBp > 0).length;
  if (dec !== F.fy2026_decreased_count) {
    errors.push(`引下げの支部数が原典 (${F.fy2026_decreased_count}) と一致しません: ${dec}`);
  }
  if (same !== F.fy2026_unchanged_count) {
    errors.push(`据え置きの支部数が原典 (${F.fy2026_unchanged_count}) と一致しません: ${same}`);
  }
  if (inc !== F.fy2026_increased_count) {
    errors.push(`引上げの支部数が原典 (${F.fy2026_increased_count}) と一致しません: ${inc}`);
  }

  // 6. 最高・最低
  const checkExtreme = (
    label: string,
    pick: (r: HealthInsuranceRateEntry) => number,
    kind: 'max' | 'min',
    expected: { pref: string; bp: number },
  ) => {
    const values = HEALTH_INSURANCE_RATE_TABLE.map(pick);
    const target = kind === 'max' ? Math.max(...values) : Math.min(...values);
    const hits = HEALTH_INSURANCE_RATE_TABLE.filter((r) => pick(r) === target);
    if (target !== expected.bp || !hits.some((h) => h.pref === expected.pref)) {
      errors.push(
        `${label}が原典 (${expected.pref} ${expected.bp / 100}%) と一致しません: ` +
        `${hits.map((h) => h.pref).join('・')} ${target / 100}%`,
      );
    }
  };
  checkExtreme('令和8年度の最高料率', (r) => r.fy2026Bp, 'max', F.fy2026_max);
  checkExtreme('令和8年度の最低料率', (r) => r.fy2026Bp, 'min', F.fy2026_min);
  checkExtreme('令和7年度の最高料率', (r) => r.fy2025Bp, 'max', F.fy2025_max);
  checkExtreme('令和7年度の最低料率', (r) => r.fy2025Bp, 'min', F.fy2025_min);

  // 7. 保険料額表の実額との照合 (整数演算のみ。小数を経由しない)
  for (const a of GRADE1_PREMIUM_ANCHORS_FY2026) {
    const row = HEALTH_INSURANCE_RATE_TABLE.find((r) => r.pref === a.pref);
    if (!row) {
      errors.push(`照合基準の支部「${a.pref}」が本表にありません`);
      continue;
    }
    // 標準報酬月額 × 1万分率 / 1000 = 全額 × 10 (0.1円単位)
    const calcX10 = (a.standardRemuneration * row.fy2026Bp) / 1000;
    if (calcX10 !== a.fullPremiumX10) {
      errors.push(
        `${a.pref}: 保険料額表の第1級 (${a.standardRemuneration.toLocaleString('ja-JP')}円) の全額 ` +
        `${(a.fullPremiumX10 / 10).toFixed(1)}円 に対し、料率 ${row.fy2026Bp / 100}% からの計算値は ` +
        `${(calcX10 / 10).toFixed(1)}円 です。料率の転記を確認してください。`,
      );
    }
  }

  return { ok: errors.length === 0, errors };
}
