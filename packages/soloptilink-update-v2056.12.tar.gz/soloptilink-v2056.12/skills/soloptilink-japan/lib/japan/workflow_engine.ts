/**
 * lib/japan/workflow_engine.ts — 業務フローエンジン (v2.0 Phase 5)
 *
 * 柱4 COMPLIANCE-AS-CODE の関連機能。
 * 日本企業の稟議・承認経路・帳票連鎖を型安全に実装するエンジン。
 *
 * なぜClaude Codeに作れないか:
 *   Claude Codeは「GitHubのPR承認」を汎用的に扱えるが、日本の稟議文化
 *   (課長→部長→本部長→社長、金額別分岐、代理承認、差戻し)のパターンは
 *   業種・企業規模・役員構成で激変する。これは「汎用モデル」では収まらない
 *   ドメイン知識の塊。本エンジンで「日本の8割の企業で即使える」形に凝縮する。
 *
 * ★承認の歯止め (JPO-FIX-016・判定は approval_guard.ts の1か所):
 *   ノードの担当者は initiateApproval の opts.assignees (ノード番号 → 社員ID) で決める。
 *   起案者本人・担当外の人・担当者未設定のノード・別ルートの持ち込み・「代理」によるノード飛ばし・
 *   期間と範囲の外の代決・審査中でない稟議への操作 は applyAction が ApprovalDeniedError で拒否する
 *   (例外を投げたくない画面は tryApplyAction を使う)。
 *   代決した承認は履歴に onBehalfOf (本人) と proxyGrantId を残し、本人への後閲の依頼を
 *   request.postReviewRequests に1件作る。
 */

import {
  checkNotApplicant,
  findUsableGrant,
  makePostReviewRequest,
  type ProxyGrant,
  type PostReviewRequest,
} from "./approval_guard";
export type { ProxyGrant, PostReviewRequest } from "./approval_guard";

// ───────────────────────────────────────────────
// 型定義
// ───────────────────────────────────────────────

/** 役職レベル (階層数値) */
export type PositionLevel =
  | "staff" // 一般
  | "leader" // リーダー・係長
  | "manager" // 課長・マネージャー
  | "gm" // 部長・ゼネラルマネージャー
  | "division_head" // 本部長
  | "executive" // 役員・執行役員
  | "president" // 代表取締役・社長
  | "board" // 取締役会
  | "auditor" // 監査役
  ;

/** 承認ノード */
export interface ApprovalNode {
  id: string;
  label: string; // 例: "営業課長承認"
  position: PositionLevel;
  required: boolean;
  parallel?: boolean; // 並列承認可
  escalationDays?: number; // 未承認時エスカレーション日数
  delegatable?: boolean; // 代理承認可
}

/** 承認ルート */
export interface ApprovalRoute {
  routeId: string;
  name: string; // 例: "10万円未満支払稟議"
  description?: string;
  trigger: RouteTrigger;
  nodes: ApprovalNode[];
  onReject: "return_to_requester" | "escalate" | "cancel";
  onEscalate?: { after: number; to: PositionLevel };
}

/** ルート起動条件 */
export interface RouteTrigger {
  amountMin?: number;
  amountMax?: number;
  category?: string;
  department?: string;
  keywords?: string[];
}

/** 稟議要求 */
export interface ApprovalRequest {
  requestId: string;
  requesterId: string;
  requesterName: string;
  routeId: string;
  subject: string;
  amount?: number;
  attachments: string[];
  submittedAt: string;
  currentNodeIndex: number;
  status: "draft" | "in_review" | "approved" | "rejected" | "returned";
  history: ApprovalAction[];
  /** ノード番号 → 担当者の社員ID (担当者の無いノードは誰も承認できない) */
  assignees?: Record<string, string>;
  /** 案件種別 (ルートの category と同じ語) */
  category?: string;
  /** 代決に伴う本人への後閲の依頼 (代決1回につき1件) */
  postReviewRequests?: PostReviewRequest[];
}

/** 承認アクション */
export interface ApprovalAction {
  nodeId: string;
  actorId: string;
  actorName: string;
  action: "approve" | "reject" | "return" | "delegate";
  comment?: string;
  actedAt: string;
  /** 代決したときの本人 (担当者) の社員ID */
  onBehalfOf?: string;
  /** 代決に使った授権の番号 */
  proxyGrantId?: string;
}

/** 帳票連鎖定義 (業務フロー) */
export interface DocumentChain {
  chainId: string;
  name: string; // 例: "見積→受注→請求→入金"
  steps: ChainStep[];
}

export interface ChainStep {
  stepId: string;
  documentType:
    | "Estimate"
    | "PurchaseOrder"
    | "DeliveryNote"
    | "Invoice"
    | "Receipt"
    | "InspectionReport"
    | "PaymentNotice"
    | "WithholdingSlip"
    | "ApprovalRoute"
    | "ComplianceCertificate";
  precondition?: string; // 前工程の完了条件
  carryFields: string[]; // 前ステップから引き継ぐフィールド
  generateRoute?: string; // 承認ルートID (必要な場合)
}

// ───────────────────────────────────────────────
// 標準ルートテンプレート (日本企業8割で通用する既定値)
// ───────────────────────────────────────────────

/** 標準稟議ルート (金額別に自動選択) */
export const STANDARD_ROUTES: ApprovalRoute[] = [
  {
    routeId: "purchase_small",
    name: "10万円未満支払稟議",
    trigger: { amountMax: 100_000 },
    nodes: [
      { id: "n1", label: "直属上長 (係長)", position: "leader", required: true },
      { id: "n2", label: "経理部担当", position: "staff", required: true },
    ],
    onReject: "return_to_requester",
  },
  {
    routeId: "purchase_medium",
    name: "10〜100万円支払稟議",
    trigger: { amountMin: 100_000, amountMax: 1_000_000 },
    nodes: [
      { id: "n1", label: "直属上長 (係長)", position: "leader", required: true },
      { id: "n2", label: "課長", position: "manager", required: true, escalationDays: 3 },
      { id: "n3", label: "経理部長", position: "gm", required: true },
    ],
    onReject: "return_to_requester",
    onEscalate: { after: 5, to: "gm" },
  },
  {
    routeId: "purchase_large",
    name: "100〜1000万円支払稟議",
    trigger: { amountMin: 1_000_000, amountMax: 10_000_000 },
    nodes: [
      { id: "n1", label: "課長", position: "manager", required: true },
      { id: "n2", label: "部長", position: "gm", required: true, escalationDays: 5 },
      { id: "n3", label: "本部長", position: "division_head", required: true },
      { id: "n4", label: "経理部長", position: "gm", required: true, parallel: true },
    ],
    onReject: "return_to_requester",
    onEscalate: { after: 7, to: "executive" },
  },
  {
    routeId: "purchase_xlarge",
    name: "1000万円以上 (役員承認要)",
    trigger: { amountMin: 10_000_000 },
    nodes: [
      { id: "n1", label: "部長", position: "gm", required: true },
      { id: "n2", label: "本部長", position: "division_head", required: true },
      { id: "n3", label: "担当役員", position: "executive", required: true },
      { id: "n4", label: "社長決裁", position: "president", required: true },
    ],
    onReject: "return_to_requester",
    onEscalate: { after: 14, to: "president" },
  },
  {
    routeId: "hr_transfer",
    name: "人事異動承認",
    trigger: { category: "hr_transfer" },
    nodes: [
      { id: "n1", label: "直属上長", position: "manager", required: true },
      { id: "n2", label: "異動先上長", position: "manager", required: true, parallel: true },
      { id: "n3", label: "人事部長", position: "gm", required: true },
      { id: "n4", label: "担当役員", position: "executive", required: true },
    ],
    onReject: "return_to_requester",
  },
  {
    routeId: "retirement",
    name: "退職手続き",
    trigger: { category: "retirement" },
    nodes: [
      { id: "n1", label: "直属上長", position: "manager", required: true },
      { id: "n2", label: "人事部", position: "staff", required: true },
      { id: "n3", label: "役員", position: "executive", required: true },
    ],
    onReject: "escalate",
  },
  {
    routeId: "business_trip_domestic",
    name: "国内出張稟議",
    trigger: { category: "business_trip", amountMax: 500_000 },
    nodes: [
      { id: "n1", label: "課長", position: "manager", required: true },
      { id: "n2", label: "部長", position: "gm", required: true, delegatable: true },
    ],
    onReject: "return_to_requester",
  },
  {
    routeId: "business_trip_overseas",
    name: "海外出張稟議",
    trigger: { category: "business_trip", keywords: ["海外", "overseas", "出張"] },
    nodes: [
      { id: "n1", label: "課長", position: "manager", required: true },
      { id: "n2", label: "部長", position: "gm", required: true },
      { id: "n3", label: "担当役員", position: "executive", required: true },
    ],
    onReject: "return_to_requester",
  },
  {
    routeId: "compliance_incident",
    name: "コンプライアンス違反報告",
    trigger: { category: "compliance", keywords: ["違反", "インシデント"] },
    nodes: [
      { id: "n1", label: "法務部門", position: "gm", required: true },
      { id: "n2", label: "監査役", position: "auditor", required: true },
      { id: "n3", label: "社長", position: "president", required: true },
    ],
    onReject: "escalate",
  },
];

/** 標準帳票連鎖 (売上・支払の両フロー) */
export const STANDARD_CHAINS: DocumentChain[] = [
  {
    chainId: "sales_flow",
    name: "売上フロー: 見積→受注→納品→検収→請求→入金",
    steps: [
      { stepId: "s1", documentType: "Estimate", carryFields: ["customer", "items"] },
      {
        stepId: "s2",
        documentType: "PurchaseOrder",
        precondition: "Estimate承認済",
        carryFields: ["customer", "items", "estimate_id"],
      },
      {
        stepId: "s3",
        documentType: "DeliveryNote",
        precondition: "PurchaseOrder受領",
        carryFields: ["customer", "items", "order_id"],
      },
      {
        stepId: "s4",
        documentType: "InspectionReport",
        precondition: "DeliveryNote完了",
        carryFields: ["customer", "items", "delivery_id"],
      },
      {
        stepId: "s5",
        documentType: "Invoice",
        precondition: "InspectionReport承認",
        carryFields: ["customer", "items", "inspection_id", "amount"],
        generateRoute: "purchase_medium",
      },
      {
        stepId: "s6",
        documentType: "Receipt",
        precondition: "入金確認",
        carryFields: ["customer", "amount", "invoice_id"],
      },
    ],
  },
  {
    chainId: "procurement_flow",
    name: "調達フロー: 稟議→発注→受領→検収→支払通知",
    steps: [
      {
        stepId: "p1",
        documentType: "ApprovalRoute",
        carryFields: ["subject", "amount"],
        generateRoute: "purchase_medium",
      },
      {
        stepId: "p2",
        documentType: "PurchaseOrder",
        precondition: "ApprovalRoute承認",
        carryFields: ["supplier", "items", "approval_id"],
      },
      {
        stepId: "p3",
        documentType: "DeliveryNote",
        precondition: "納品完了",
        carryFields: ["supplier", "items", "order_id"],
      },
      {
        stepId: "p4",
        documentType: "InspectionReport",
        precondition: "検収完了",
        carryFields: ["supplier", "items", "delivery_id"],
      },
      {
        stepId: "p5",
        documentType: "PaymentNotice",
        precondition: "InspectionReport承認",
        carryFields: ["supplier", "amount", "inspection_id"],
      },
    ],
  },
  {
    chainId: "hr_payroll_flow",
    name: "給与支払フロー: 勤怠→給与計算→源泉→支払通知",
    steps: [
      {
        stepId: "h1",
        documentType: "Report",
        carryFields: ["employee", "work_hours"],
      },
      {
        stepId: "h2",
        documentType: "WithholdingSlip",
        precondition: "年末調整",
        carryFields: ["employee", "annual_income", "tax_amount"],
      },
      {
        stepId: "h3",
        documentType: "PaymentNotice",
        precondition: "WithholdingSlip確定",
        carryFields: ["employee", "net_pay"],
      },
    ],
  },
] as any;

// ───────────────────────────────────────────────
// ルート選択ロジック
// ───────────────────────────────────────────────

/** 要求に最も適合するルートを選択 */
export function selectRoute(
  request: Partial<ApprovalRequest> & { amount?: number; category?: string; keywords?: string[] },
  routes: ApprovalRoute[] = STANDARD_ROUTES,
): ApprovalRoute | null {
  const candidates = routes.filter((r) => matchesTrigger(r.trigger, request));
  if (candidates.length === 0) return null;
  // 最も制約が厳しい (金額範囲が狭い) ものを選ぶ
  return candidates.sort((a, b) => routeSpecificity(b.trigger) - routeSpecificity(a.trigger))[0];
}

function matchesTrigger(
  trigger: RouteTrigger,
  req: Partial<ApprovalRequest> & { amount?: number; category?: string; keywords?: string[] },
): boolean {
  if (trigger.amountMin !== undefined && (req.amount ?? 0) < trigger.amountMin) return false;
  if (trigger.amountMax !== undefined && (req.amount ?? 0) >= trigger.amountMax) return false;
  if (trigger.category && req.category && trigger.category !== req.category) return false;
  if (trigger.keywords && trigger.keywords.length > 0) {
    const hit = trigger.keywords.some(
      (kw) =>
        req.keywords?.includes(kw) ||
        (req.subject && req.subject.includes(kw)) ||
        false,
    );
    if (!hit) return false;
  }
  return true;
}

function routeSpecificity(trigger: RouteTrigger): number {
  let score = 0;
  if (trigger.amountMin !== undefined) score += 2;
  if (trigger.amountMax !== undefined) score += 2;
  if (trigger.category) score += 3;
  if (trigger.keywords && trigger.keywords.length > 0) score += 2;
  return score;
}

// ───────────────────────────────────────────────
// 承認処理
// ───────────────────────────────────────────────

/** 新規稟議を開始 */
export function initiateApproval(
  requesterId: string,
  requesterName: string,
  subject: string,
  route: ApprovalRoute,
  amount?: number,
  attachments: string[] = [],
  opts: {
    /** ノード番号 → 担当者の社員ID。担当者の無いノードは誰も承認できない */
    assignees?: Record<string, string>;
    /** 案件種別 (代決の範囲の判定に使う) */
    category?: string;
    /** 起票日時 (ISO8601)。既定は実行時刻 */
    at?: string;
  } = {},
): ApprovalRequest {
  return {
    requestId: cryptoRandomId(),
    requesterId,
    requesterName,
    routeId: route.routeId,
    subject,
    amount,
    attachments,
    submittedAt: opts.at ?? new Date().toISOString(),
    currentNodeIndex: 0,
    status: "in_review",
    history: [],
    ...(opts.assignees ? { assignees: { ...opts.assignees } } : {}),
    ...(opts.category ? { category: opts.category } : {}),
  };
}

/** 承認の操作を拒否したときの例外 (理由は日本語で message に入る) */
export class ApprovalDeniedError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ApprovalDeniedError";
  }
}

/** 承認の操作の追加情報 */
export interface ApplyActionOptions {
  /** 操作の日時 (ISO8601)。代決の期間の判定に使う。既定は実行時刻 */
  at?: string;
  /** 使ってよい代決の授権 (担当者本人以外が操作するときに必要) */
  proxyGrants?: ProxyGrant[];
}

/** 操作が許されるかを判定する (許されない理由を日本語で返す) */
function guardAction(
  request: ApprovalRequest,
  route: ApprovalRoute,
  actorId: string,
  action: ApprovalAction["action"],
  at: string,
  proxyGrants: readonly ProxyGrant[] | undefined,
): { ok: boolean; reason?: string; grant?: ProxyGrant; assignee?: string } {
  if (route.routeId !== request.routeId) {
    return { ok: false, reason: `この稟議のルート (${request.routeId}) と違うルート (${route.routeId}) では操作できません (段の省略の防止)。` };
  }
  if (request.status !== "in_review") {
    return { ok: false, reason: `この稟議は審査中ではありません (状態: ${request.status})。` };
  }
  const node = route.nodes[request.currentNodeIndex];
  if (!node) return { ok: false, reason: "承認待ちのノードがありません。" };
  if (action === "delegate") {
    return {
      ok: false,
      reason: "「代理」でノードを先へ進めることはできません (段の省略)。代決は、代決の授権 (期間と範囲) を添えて代決者が承認してください。",
    };
  }
  const self = checkNotApplicant(actorId, request.requesterId);
  if (!self.ok) return self;
  const assignee = request.assignees?.[node.id];
  if (!assignee) {
    return { ok: false, reason: `「${node.label}」の担当者が決まっていません。担当者を設定してから操作してください。` };
  }
  if (assignee === request.requesterId) {
    return { ok: false, reason: `「${node.label}」の担当者が起案者本人です。別の担当者に付け替えてください (職務分掌)。` };
  }
  if (actorId === assignee) return { ok: true, assignee };
  if (node.delegatable === false) {
    return { ok: false, reason: `「${node.label}」は代決を認めないノードです。担当者本人が操作してください。` };
  }
  const found = findUsableGrant(proxyGrants, {
    principalId: assignee,
    proxyId: actorId,
    applicantId: request.requesterId,
    at,
    category: request.category,
    routeId: route.routeId,
    amountYen: request.amount,
  });
  if (!found.grant) return { ok: false, reason: found.reason };
  return { ok: true, grant: found.grant, assignee };
}

/** 承認の操作を適用する。拒否するときは例外を投げずに { ok:false, reason } を返す */
export function tryApplyAction(
  request: ApprovalRequest,
  route: ApprovalRoute,
  actorId: string,
  actorName: string,
  action: ApprovalAction["action"],
  comment?: string,
  opts: ApplyActionOptions = {},
): { ok: boolean; reason?: string; request: ApprovalRequest } {
  try {
    return { ok: true, request: applyAction(request, route, actorId, actorName, action, comment, opts) };
  } catch (e) {
    if (e instanceof ApprovalDeniedError) return { ok: false, reason: e.message, request };
    throw e;
  }
}

/** 承認アクションを適用 (拒否するときは ApprovalDeniedError を投げ、元の稟議は変えない) */
export function applyAction(
  request: ApprovalRequest,
  route: ApprovalRoute,
  actorId: string,
  actorName: string,
  action: ApprovalAction["action"],
  comment?: string,
  opts: ApplyActionOptions = {},
): ApprovalRequest {
  const at = opts.at ?? new Date().toISOString();
  const g = guardAction(request, route, actorId, action, at, opts.proxyGrants);
  if (!g.ok) throw new ApprovalDeniedError(g.reason ?? "この操作は許されていません。");
  const next = structuredClone(request);
  const node = route.nodes[next.currentNodeIndex];
  next.history.push({
    nodeId: node.id,
    actorId,
    actorName,
    action,
    comment,
    actedAt: at,
    ...(g.grant ? { onBehalfOf: g.grant.principalId, proxyGrantId: g.grant.grantId } : {}),
  });
  if (g.grant && action === "approve") {
    // 代決: 本人への後閲の依頼を1件作る
    next.postReviewRequests = [
      ...(next.postReviewRequests ?? []),
      makePostReviewRequest({ documentId: next.requestId, nodeId: node.id, grant: g.grant, requestedAt: at }),
    ];
  }
  if (action === "approve") {
    if (next.currentNodeIndex === route.nodes.length - 1) {
      next.status = "approved";
    } else {
      next.currentNodeIndex += 1;
    }
  } else if (action === "reject") {
    next.status = route.onReject === "cancel" ? "rejected" : "returned";
  } else if (action === "return") {
    next.status = "returned";
  }
  // action === "delegate" は guardAction で拒否済み (以前は次ノードへ進めており、段の省略になっていた)
  return next;
}

// ───────────────────────────────────────────────
// 帳票連鎖
// ───────────────────────────────────────────────

/** 連鎖定義を元に、業務フロー(状態機械)をMarkdownで出力 */
export function chainToMarkdown(chain: DocumentChain): string {
  let md = `# 業務フロー: ${chain.name}\n\n`;
  md += `| # | 帳票 | 前工程条件 | 引き継ぎフィールド | 承認ルート |\n`;
  md += `|---|------|-----------|-------------------|-----------|\n`;
  chain.steps.forEach((s, i) => {
    md += `| ${i + 1} | ${s.documentType} | ${s.precondition ?? "-"} | ${s.carryFields.join(", ")} | ${s.generateRoute ?? "-"} |\n`;
  });
  return md;
}

/** 連鎖定義を Mermaid フロー図に変換 */
export function chainToMermaid(chain: DocumentChain): string {
  const lines: string[] = ["flowchart LR"];
  chain.steps.forEach((s, i) => {
    lines.push(`  ${s.stepId}["${s.documentType}"]`);
    if (i > 0) {
      const prev = chain.steps[i - 1];
      lines.push(`  ${prev.stepId} --> ${s.stepId}`);
    }
    if (s.generateRoute) {
      lines.push(`  ${s.stepId} -.承認.-> R_${s.stepId}["${s.generateRoute}"]`);
    }
  });
  return lines.join("\n");
}

// ───────────────────────────────────────────────
// ユーティリティ
// ───────────────────────────────────────────────

function cryptoRandomId(): string {
  // 実運用では crypto.randomUUID() を使うが、Node 18 未満互換のため簡易実装
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let id = "";
  for (let i = 0; i < 12; i++) id += chars[Math.floor(Math.random() * chars.length)];
  return id;
}

/** BOOST から呼び出される便利関数: 業種辞書の承認パターンから標準ルートを選ぶ */
export function routesForIndustry(industry: string): ApprovalRoute[] {
  // 建設業は工事稟議、金融は与信稟議、医療は院内倫理委員会等、業種で追加可
  switch (industry) {
    case "construction":
      return [
        ...STANDARD_ROUTES,
        {
          routeId: "construction_contract",
          name: "工事請負契約稟議 (建設業法)",
          trigger: { category: "construction_contract" },
          nodes: [
            { id: "n1", label: "現場監督", position: "manager", required: true },
            { id: "n2", label: "営業所長", position: "gm", required: true },
            { id: "n3", label: "主任技術者", position: "gm", required: true, parallel: true },
            { id: "n4", label: "担当役員", position: "executive", required: true },
          ],
          onReject: "return_to_requester",
        },
      ];
    case "finance":
      return [
        ...STANDARD_ROUTES,
        {
          routeId: "credit_extension",
          name: "与信稟議 (融資承認)",
          trigger: { category: "credit", amountMin: 10_000_000 },
          nodes: [
            { id: "n1", label: "営業担当", position: "staff", required: true },
            { id: "n2", label: "支店長", position: "gm", required: true },
            { id: "n3", label: "審査部", position: "gm", required: true, parallel: true },
            { id: "n4", label: "役員審査会", position: "executive", required: true },
          ],
          onReject: "cancel",
        },
      ];
    default:
      return STANDARD_ROUTES;
  }
}
