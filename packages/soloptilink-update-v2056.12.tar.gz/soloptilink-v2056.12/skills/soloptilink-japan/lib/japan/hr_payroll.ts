/**
 * SoloptiLinkAI Phase 16 — HR & Payroll (Japan)
 *
 * 日本の人事労務・給与計算・社会保険・年末調整・労働基準法に関する
 * 計算ロジックと帳票生成補助。
 *
 * カバー範囲:
 *  - 給与計算 (基本給+手当-控除)
 *  - 社会保険 (健康保険/厚生年金/雇用保険/介護保険)
 *  - 源泉徴収 (給与所得の源泉徴収税額表 月額表)
 *  - 算定基礎届 (4-6月平均)
 *  - 賞与支払届
 *  - 36協定 (時間外労働の上限)
 *  - 有給休暇 5日付与義務
 *  - 育児介護休業
 *
 * 出典 (一次情報):
 *  - 厚生年金保険法 第20条 (標準報酬月額) / 第24条の4 (標準賞与額)
 *    日本年金機構「厚生年金保険料額表 (令和8年度版)」
 *    https://www.nenkin.go.jp/service/kounen/hokenryo/ryogaku/ryogakuhyo/20200825.html
 *  - 健康保険法 第40条 (標準報酬月額) / 第45条 (標準賞与額)
 *    全国健康保険協会「令和8年3月分からの健康保険・厚生年金保険の保険料額表」
 *    https://www.kyoukaikenpo.or.jp/assets/R8_13tokyo.pdf
 *  - 労働基準法 第36条 (時間外・休日労働) / 第39条第7項 (年5日の年次有給休暇)
 *  - 子ども・子育て支援法等の一部を改正する法律 (令和6年法律第47号・令和8年4月1日施行)
 *    健康保険法 第155条第1項 (子ども・子育て支援納付金に要する費用に充てる保険料の徴収)
 *    全国健康保険協会「協会けんぽの子ども・子育て支援金率について」
 *    https://www.kyoukaikenpo.or.jp/about/business/insurance_rate/003/index.html
 *  - 厚生労働省「令和8(2026)年度 雇用保険料率のご案内」
 *    https://www.mhlw.go.jp/content/001692566.pdf
 *
 * 注意:
 *  - 厚生年金保険料率 18.300% (折半 9.150%) は法定・全国一律で固定
 *  - 健康保険料率は協会けんぽ支部 (都道府県) ごとに異なる。
 *    本モジュールの値は全国平均の概算であり、実運用では支部別の率で上書きすること
 *    (一次情報で確定できる例: 令和8年度 東京支部 9.85%)
 *  - 介護保険料率 (1.62%) と子ども・子育て支援金率 (0.23%) は【全国一律】で支部別ではない
 *  - 年度改定される項目は必ず年度表として持つこと。単一の定数に焼き込むと改定に追随できない。
 *    本モジュールの年度表: LONG_TERM_CARE_RATES / CHILD_CARE_SUPPORT_RATES /
 *    EMPLOYMENT_INSURANCE_RATES。法定値の SoT は lib/japan/legal-values/payroll.legal.json。
 *  - 適用開始時期が項目ごとに違う:
 *      健康保険料率・介護保険料率  … 令和8年3月分 (4月納付分) 〜
 *      子ども・子育て支援金率      … 令和8年4月分 (5月納付分) 〜  ★1ヶ月ずれる
 *      雇用保険料率                … 令和8年4月1日 〜 令和9年3月31日
 *  - 都道府県・業種で異なる場合は社労士に確認すること
 */

// 源泉徴収税額表 (令和8年分・月額表) — 国税庁 Excel 実データから機械生成した実マスタ。
// 2026-08-06 に簡易近似式を廃止し実表へ差し替えた (T-250)。
import {
  WITHHOLDING_TAX_TABLE_META,
  GENSEN_MONTHLY_BRACKETS_R8,
  GENSEN_MONTHLY_BOUNDARIES_R8,
  GENSEN_KOU_SEGMENTS_R8,
  GENSEN_OTSU_SEGMENTS_R8,
  GENSEN_UNDER_THRESHOLD_R8,
  GENSEN_OTSU_UNDER_RATE_R8,
  GENSEN_EXTRA_DEPENDENT_DEDUCTION_R8,
} from "./gensen_tax_table_r8";
// 賞与に対する源泉徴収税額の算出率の表 (令和8年分・国税庁実マスタ)。
// ★月額表とは別の告示別表 (別表第三) であり、賞与の源泉徴収は月額表では引けない。
import {
  BONUS_RATE_TABLE_META,
  calcBonusWithholdingTax,
  type BonusWithholdingResult,
} from "./gensen_bonus_rate_r8";

export {
  BONUS_RATE_TABLE_META,
  calcBonusWithholdingTax,
  BONUS_RATE_KOU_R8,
  BONUS_RATE_OTSU_R8,
} from "./gensen_bonus_rate_r8";
export type { BonusWithholdingResult, BonusRateBand } from "./gensen_bonus_rate_r8";

// 税額表マスタ一式を再エクスポート (検査軸・生成物からメタと実表を参照できるようにする)
export * from "./gensen_tax_table_r8";
// 令和9年分の月額表と、支払日の年分の表を引く部品・電算機計算の特例 (2026-10-03 T07 / REQ-186)。
// ★どの年分の表を使うかは支払日で決まる (2026-12-31 支払は令和8年分 / 2027-01-01 支払は令和9年分)。
import {
  MONTHLY_WITHHOLDING_TABLES,
  SUPPORTED_WITHHOLDING_YEARS,
  calcWithholdingTaxByPayYear,
} from "./gensen_withholding_by_year";
export * from "./gensen_tax_table_r9";
export * from "./gensen_withholding_by_year";
// 年5日の時季指定の期限は労働条件の部品の暦計算を使う (2026-10-04 T12 / REQ-127)
import { calcFiveDayObligationDeadline } from "./labor_conditions";

// 年末調整 (令和8年分) — 経営判断 S1 (2026-10-03 B3)。給与レーンの生成物に既定で載せる。
// 本線は「取込み (年末調整ソフト・給与ソフト・手計算の結果) ＋過不足の精算＋源泉徴収票の欄」、
// 年税額の計算 (calcYeaReferenceR8) は参考値として並べて表示するだけ。値は tax-values/year-end-adjustment-r8.json。
export {
  YEAR_END_ADJUSTMENT_DEFAULT_R8,
  YEA_TAX_YEAR_R8,
  YearEndAdjustmentUnsupportedError,
  runYearEndAdjustmentR8,
  validateYeaImport,
  settleYearEndAdjustment,
  buildWithholdingSlipR8,
  calcYeaReferenceR8,
  kyuyoShotokuKojoGoR8,
  nenchoKyuyoGakuR8,
  incomeAdjustmentDeductionR8,
  basicDeductionForYeaR8,
  sansyutsuShotokuzeiR8,
  roundTaxableR8,
  nenchoNenzeiR8,
} from "./tax-engine/year-end-adjustment";
export type { YeaImportRecord, YeaSettlementInput, YeaReferenceInput } from "./tax-engine/year-end-adjustment";

// ---------------------------------------------------------------------------
// 料率表と判定の部品 (2026-10-18 U-02・v2056.10 で結線)
//   次の3本は一次資料と照合済みの実マスタ・判定部品として本体に在ったが、給与レーン (本ファイルが入口)
//   から1度も読まれず、生成物へ1行も届いていなかった。値は各ファイルのまま (ここで書き写さない)。
//     - shakai_hoken_rate_table.ts : 協会けんぽ 47支部の健康保険料率 (令和7・8年度)
//     - rousai_insurance_rate.ts   : 労災保険率 54区分・労務費率・特別加入・雇用保険料率 (令和8年度)
//     - payroll_judgments.ts       : 源泉徴収 (支払日で年分切替)・短時間労働者の加入・被扶養者・
//                                    納付額・住民税の月割・定時決定・随時改定・士業報酬の判定
//   ★名前のぶつかりを避けるため「まとまり (名前空間)」で出す。
//   ★payroll_judgments.ts は本ファイルを読み込む (循環)。同ファイルは本ファイルの値を関数の中でしか
//     使わないため、読み込みの順で壊れない (2026-10-18 に読み込み時の使用0件を確かめた)。
//     判定部品の読み込み時 (関数の外) で本ファイルの値を使うように変えると、束ねた生成物で壊れる。
import { getHealthInsuranceRate, verifyHealthInsuranceRateTable } from "./shakai_hoken_rate_table";
import { KOYOU_INSURANCE_RATE_TABLE_FY2025, KOYOU_INSURANCE_RATE_TABLE_FY2026, verifyRousaiInsuranceRateTable } from "./rousai_insurance_rate";
export * as healthInsuranceRateTable from "./shakai_hoken_rate_table";
export * as labourInsuranceRates from "./rousai_insurance_rate";
export * as payrollJudgments from "./payroll_judgments";
export { getHealthInsuranceRate, listHealthInsuranceRates } from "./shakai_hoken_rate_table";
export {
  getRousaiInsuranceRate, searchRousaiInsuranceRates, getRoumuhiritsu, calcConstructionWageTotal,
  getTokubetsuKanyuType2Rate, getKoyouInsuranceRate, judgeDualApplication, calcLabourInsurancePremium,
} from "./rousai_insurance_rate";

export type Gender = "male" | "female";

export interface Employee {
  id: string;
  name: string;
  birth_date: string; // YYYY-MM-DD
  gender: Gender;
  hire_date: string;
  base_salary: number; // 月額基本給
  allowances?: { type: string; amount: number }[];
  has_dependents?: boolean;
  num_dependents?: number; // 扶養親族等の数
  is_director?: boolean; // 役員
  /** 勤務先の適用事業所がある都道府県 (協会けんぽの支部)。健康保険料率の確認先の特定に使う。 */
  prefecture?: string;
  /**
   * 健康保険料率 (協会けんぽ支部の料率・【折半前】の全体料率)。
   * 例: 令和8年度 東京支部 = 0.0985 (9.85%)。被保険者負担はこの1/2 (健康保険法 第161条第1項)。
   *
   * ★健康保険料率は協会けんぽの都道府県支部ごとに異なり、全国一律の法定値が存在しない。
   *   したがってシステム側で正しい値を決めることができず、必ず入力が必要になる。
   *   未設定のときは全国平均の概算 (RATES.HEALTH_EMPLOYEE) にフォールバックするが、
   *   その場合は「概算である」ことを warnings / breakdown / notes に必ず明示する
   *   (黙って概算を使うと、実額と違う保険料が正しい額として給与明細に載る)。
   *   概算を許さず未設定を弾きたい場合は PayrollInput.require_health_insurance_rate = true にする。
   *
   * 【確認先 — 一次情報】全国健康保険協会「都道府県毎の保険料額表」
   *   https://www.kyoukaikenpo.or.jp/g7/cat330/sb3130/
   */
  health_insurance_rate?: number;
  /**
   * 雇用保険の事業の種類。料率が3区分で異なる (一般 0.5% / 農林水産・清酒製造 0.6% / 建設 0.6%)。
   * 省略時は「一般の事業」。
   */
  employment_insurance_business_type?: EmploymentInsuranceBusinessType;
}

export interface PayrollInput {
  employee: Employee;
  year_month: string; // YYYY-MM
  worked_days?: number;
  overtime_hours?: number;
  late_night_hours?: number;
  holiday_hours?: number;
  bonus?: number; // 賞与の場合
  /**
   * 住民税 (特別徴収) のその月の控除額。
   * 市区町村から事業主へ届く「特別徴収税額の決定通知書」に記載された月割額をそのまま入れる。
   *
   * ★住民税は前年の所得を基に【市区町村が個人別に決定】するため、システム側では計算できない。
   *   未入力 (undefined / null) のときは 0 を書かず null のままにし、控除合計・差引支給額に
   *   含めない。含めていないことを breakdown の「住民税 (未設定)」行と warnings で明示する。
   *   ここで 0 を既定値にすると、住民税が引かれていない給与明細が正常出力され、
   *   実際の手取りより多い額をそのまま振込に使って過払いになる。
   */
  resident_tax?: number | null;
  /**
   * true にすると、健康保険料率 (Employee.health_insurance_rate) が未設定のときに
   * 全国平均の概算へフォールバックせず例外を投げる (fail-closed)。
   * 実際の振込額を確定させる本番運用ではこちらを推奨する。省略時は false (概算+警告)。
   */
  require_health_insurance_rate?: boolean;
  /**
   * 給与の支払日 (YYYY-MM-DD)。源泉徴収税額表の年分はこれで決まる (2026-12-31 支払 → 令和8年分 /
   * 2027-01-01 支払 → 令和9年分)。省略時は year_month の年で代用し、その旨を warnings に出す。
   * pay_date も year_month も無いときは従来どおり令和8年分の表で計算する (後方互換)。
   * 取り込んでいない年分 (令和10年分以後など) は旧い表で計算せず例外を投げる。
   */
  pay_date?: string;
  /**
   * 社会保険料の対象月 (YYYY-MM)。保険料は原則として前月分を当月の給与から控除するため、
   * 給与の年月 (year_month) とは1か月ずれることが多い。指定すると、子ども・子育て支援金は
   * 令和8年4月分から、料率を取り込んでいない令和9年3月分以降は計算を止める (REQ-190)。
   */
  insurance_month?: string;
}

export interface PayrollResult {
  gross: number;
  deductions: PayrollDeductions;
  net: number;
  breakdown: { label: string; amount: number }[];
  warnings: string[];
  /** 料率マスタの適用年度表示 (例: 令和8年度適用)。給与明細画面にそのまま表示する (T-250) */
  applied_fiscal_year_ja?: string;
  /**
   * 差引支給額 (net) が住民税を差し引いた後の額かどうか。
   * false のときの net は【住民税を引く前の額】であり、そのまま振込額に使うと過払いになる。
   */
  resident_tax_included: boolean;
  /**
   * 健康保険料が全国平均の概算料率で計算されているか。
   * true のときの健康保険料は実額ではない (支部別の料率が未設定)。
   */
  health_rate_is_estimate: boolean;
  /** 健康保険料率をどこから引いたか (協会けんぽの支部の料率表から引いたときだけ入る・2026-10-18 U-02) */
  health_rate_source_ja?: string;
}

export interface PayrollDeductions {
  health_insurance: number;
  pension: number;
  long_term_care: number;
  /** 子ども・子育て支援金 (令和8年4月分〜新設・健康保険料の一部として徴収) */
  child_care_support: number;
  employment_insurance: number;
  income_tax: number;
  /**
   * 住民税 (特別徴収)。
   * ★null = 未設定 (金額が分からない) であり、0円 (住民税が課されない) とは意味が違う。
   *   null のとき total には含めない。0 を既定値にすると「住民税0円」の給与明細が
   *   正常出力され、手取りが実際より多く出る。
   */
  resident_tax: number | null;
  total: number;
}

/**
 * 被保険者負担分の端数処理の方法。
 *  - 'payroll_deduction' (既定): 給与から控除する場合。50銭以下切捨て・50銭1厘以上切上げ。
 *  - 'cash': 被保険者が現金で支払う場合。50銭未満切捨て・50銭以上切上げ (通貨の単位及び貨幣の発行等に関する法律 第3条)。
 *  - 'truncate': 労使の慣習的な特約で従来から切捨てとしている場合 (厚労省の説明で差し支えないとされる扱い)。
 *
 * 【出典 — 一次情報】厚生労働省「労働保険料の申告・納付」内「雇用保険の被保険者負担額と端数処理について」
 *   https://www.mhlw.go.jp/www2/topics/seido/daijin/hoken/980916_3.htm
 */
export type EmployeeShareRounding = 'payroll_deduction' | 'cash' | 'truncate';

/**
 * 被保険者負担分の円未満端数処理 (給与から控除する場合)。
 *
 * 【出典 — 一次情報】全国健康保険協会「令和8年3月分(4月納付分)からの健康保険・厚生年金保険の
 *   保険料額表」備考「○被保険者負担分(表の折半額の欄)に円未満の端数がある場合」
 *   https://www.kyoukaikenpo.or.jp/assets/R8_13tokyo.pdf
 *   「①事業主が、給与から被保険者負担分を控除する場合、被保険者負担分の端数が50銭以下の場合は
 *     切り捨て、50銭を超える場合は切り上げて1円となります。」
 *
 * ★JavaScript の Math.round は .5 を必ず切り上げるため、法定ルール (50銭ちょうどは切捨て) と
 *   『ちょうど50銭』のケースだけ1円ずれる。折半で 1/2 の刻みを生む料率
 *   (子ども・子育て支援金 0.115% / 厚生年金 9.15% など) では現実に発生する。
 *   例: 標準報酬月額650,000円の子ども・子育て支援金の折半額は 747.5円。
 *       法定では747円だが Math.round では748円となり1円の過大徴収になる。
 *
 * ★被保険者が現金で事業主へ支払う場合は「50銭未満切捨て・50銭以上切上げ」と
 *   『ちょうど50銭』の扱いが逆になる (同備考②)。既定は給与控除 (①) の規定で、
 *   現金払い (②) と労使の特約 (切捨て) は第2引数 method で選ぶ (REQ-JPO-MNY-010)。
 */
export function roundEmployeeShare(rawAmount: number, method: EmployeeShareRounding = 'payroll_deduction'): number {
  // ★2026-09-30 是正 (REQ-JPO-FIX-015): 銭単位へ先に丸めていたため「厘」の端数が消え、
  //   雇用保険 (千分率) で 50銭を少し超える額を切り捨てていた。
  //   例) 建設の事業 6/1000 × 賃金100,084円 = 600.504円 → 法定 601円 / 是正前 600円 (1円の控除不足)
  //   実測: 賃金10万〜40万円の全整数で、6/1000 (建設・農林水産) の各1,200通りが1円少なかった。
  //   是正後は 1e-6 円 (マイクロ円) の整数へ整えてから判定する。料率は最大でも小数第5位まで
  //   (例 0.04925・0.00115) で、円×料率の正当な端数は 1e-6 円の格子に必ず乗るため失われない。
  //   除去されるのは浮動小数の計算誤差 (1e-9 円規模) だけで、9/10 の是正
  //   (山口支部 10.15%×530,000円 → 26,897円) の結果は変わらない。
  const micro = Math.round(rawAmount * 1_000_000);
  const yen = Math.floor(micro / 1_000_000);
  const frac = micro - yen * 1_000_000; // 0 〜 999,999 マイクロ円
  if (method === 'truncate') return yen;
  if (method === 'cash') return frac >= 500_000 ? yen + 1 : yen;
  return frac > 500_000 ? yen + 1 : yen;
}

// ★経緯 (2026-09-10 是正): 浮動小数の誤差で「ちょうど50銭」が「50銭超」と判定され1円多く控除されていた
//   (山口支部 10.15%×530,000円 の折半 26897.500000000004 → 26,898円)。当時は銭単位へ丸めて是正したが、
//   それが雇用保険の厘の端数を消していたため、2026-09-30 にマイクロ円の整数判定へ置き換えた (上の関数)。

/**
 * 子ども・子育て支援金率 (協会けんぽ) の年度表。
 *
 * 【出典 — 一次情報】
 *   全国健康保険協会「協会けんぽの子ども・子育て支援金率について」
 *   https://www.kyoukaikenpo.or.jp/about/business/insurance_rate/003/index.html
 *   同「令和8年3月分(4月納付分)からの健康保険・厚生年金保険の保険料額表」(東京支部)
 *   https://www.kyoukaikenpo.or.jp/assets/R8_13tokyo.pdf
 *     表頭「・子ども・子育て支援金率：令和8年4月分（5月納付分）～適用」「0.23%」
 *     備考「介護保険第２号被保険者は、40歳から64歳までの方であり、健康保険料率（9.85%）と
 *           子ども・子育て支援金率（0.23%）に介護保険料率（1.62%）が加わります。」
 *   こども家庭庁「子ども・子育て支援金制度について」
 *   https://www.cfa.go.jp/policies/kodomokosodateshienkinseido
 *   根拠法: 子ども・子育て支援法等の一部を改正する法律 (令和6年法律第47号・令和8年4月1日施行)。
 *     支援金は独立した新税ではなく、健康保険法第155条第1項に基づき保険者が徴収する
 *     【保険料の一部】であるため、労使折半 (健康保険法第161条第1項) が適用され、
 *     被保険者負担分は所得税の社会保険料控除の対象となる。
 *
 * ★全国一律であり支部別ではない (健康保険料率とは異なる)。
 * ★適用開始は【令和8年4月分 (5月納付分)】。健康保険料率・介護保険料率の改定時期
 *   (令和8年3月分・4月納付分〜) とは1ヶ月ずれる。
 * ★保険料額表では介護保険第2号被保険者の該当/非該当の区分の【外側】に独立列として置かれており、
 *   健康保険の被保険者【全員】が対象である。介護保険と同じ40〜64歳の条件を付けて実装すると、
 *   39歳以下と65歳以上から取り漏らす。
 */
export const CHILD_CARE_SUPPORT_RATES = {
  /** 令和8年度 (令和8年4月分〜) — 新設・現行 */
  FY2026: { total: 0.0023, employee: 0.00115 },
} as const;

/** 現在適用中の子ども・子育て支援金率の年度キー。改定を取り込んだら必ずここを進めること。 */
export const CHILD_CARE_SUPPORT_CURRENT_FY = 'FY2026' as const;

/**
 * 雇用保険料率 (被保険者負担) の年度表 — 事業の種類別。
 *
 * 【出典 — 一次情報】厚生労働省「令和8(2026)年度 雇用保険料率のご案内」
 *   https://www.mhlw.go.jp/content/001692566.pdf
 *   「令和8(2026)年4月1日から令和9(2027)年3月31日までの雇用保険料率は以下のとおりです。」
 *     一般の事業           労働者負担 5/1,000   事業主負担 8.5/1,000   合計 13.5/1,000
 *     農林水産・清酒製造   労働者負担 6/1,000   事業主負担 9.5/1,000   合計 15.5/1,000
 *     建設の事業           労働者負担 6/1,000   事業主負担 10.5/1,000  合計 16.5/1,000
 *
 * ★毎年度改定される。0.6% は令和6年度まで、0.55% は令和7年度の値であり現行値ではない。
 * ★標準報酬月額ではなく実際に支払われた賃金総額に乗じる (労働保険徴収法第31条)。
 */
export const EMPLOYMENT_INSURANCE_RATES = {
  FY2024: { general: 0.006, agriculture: 0.007, construction: 0.007 },
  FY2025: { general: 0.0055, agriculture: 0.0065, construction: 0.0065 },
  /** 令和8年度 (令和8年4月1日〜令和9年3月31日) — 現行 */
  FY2026: { general: 0.005, agriculture: 0.006, construction: 0.006 },
} as const;

/** 現在適用中の雇用保険料率の年度キー。改定を取り込んだら必ずここを進めること。 */
export const EMPLOYMENT_INSURANCE_CURRENT_FY = 'FY2026' as const;

/** 雇用保険の事業の種類 (料率が3区分で異なる) */
export type EmploymentInsuranceBusinessType = 'general' | 'agriculture' | 'construction';

/**
 * 介護保険料率 (協会けんぽ・第2号被保険者) の年度表。
 *
 * 【出典 — 一次情報】全国健康保険協会「協会けんぽの介護保険料率について」
 *   https://www.kyoukaikenpo.or.jp/about/business/insurance_rate/002/index.html
 *   令和8年度の料率は保険料額表本文でも実確認:
 *   https://www.kyoukaikenpo.or.jp/assets/R8_13tokyo.pdf
 *   「介護保険第2号被保険者は、40歳から64歳までの方であり、健康保険料率(9.85%)と
 *     子ども・子育て支援金率(0.23%)に介護保険料率(1.62%)が加わります」
 *   労使折半の根拠: 健康保険法 第161条第1項 (被保険者・事業主がそれぞれ2分の1を負担)。
 *
 * ★介護保険料率は健康保険料率と違い【支部別ではなく全国一律】であり、【毎年度改定される】。
 *   単一の定数に焼き込むと改定に追随できず、その年度の給与計算が一律に誤る。
 *   法定値の SoT は lib/japan/legal-values/payroll.legal.json であり、
 *   改定時は同 JSON の long_term_care.rate_history と本表の両方へ追記すること。
 *
 * ★適用開始は「3月分 (4月納付分)」であって4月分ではない。年度末の1ヶ月ずれに注意。
 */
export const LONG_TERM_CARE_RATES = {
  /** 令和6年度 (令和6年3月分〜) */
  FY2024: { total: 0.016, employee: 0.008 },
  /** 令和7年度 (令和7年3月分〜) */
  FY2025: { total: 0.0159, employee: 0.00795 },
  /** 令和8年度 (令和8年3月分〜) — 現行 */
  FY2026: { total: 0.0162, employee: 0.0081 },
} as const;

/** 現在適用中の介護保険料率の年度キー。改定を取り込んだら必ずここを進めること。 */
export const LONG_TERM_CARE_CURRENT_FY = 'FY2026' as const;

// 協会けんぽ 令和8年度 (折半後)
//
// 【出典 — 一次情報】
//   - 厚生年金保険料率 18.300% (平成29年9月分〜固定・折半 9.150%)
//     日本年金機構「厚生年金保険の保険料」
//     https://www.nenkin.go.jp/service/kounen/hokenryo/hoshu/20150515-01.html
//   - 健康保険料率は都道府県支部ごとに異なる (協会けんぽ)。
//     参考: 令和8年度 東京支部 健康保険 9.85%
//     https://www.kyoukaikenpo.or.jp/assets/R8_13tokyo.pdf
//   - 介護保険料率は全国一律。令和8年度 1.62% / 折半 0.81% (上の年度表を参照)。
//   ★健保の料率は全国平均の概算値。実運用では支部別の率で上書きすること。
//     厚生年金の 18.300% のみ法律で全国一律に固定されている。
const RATES = {
  HEALTH_EMPLOYEE: 0.0498, // 健康保険料率/2 (全国平均10.0%程度の概算)
  PENSION_EMPLOYEE: 0.0915, // 厚生年金保険料率/2 (18.300% / 2 = 9.150% — 法定・全国一律)
  // 介護保険 40-64歳。年度表から引く (単独の数値をここへ焼き込まないこと)。
  LONG_TERM_CARE_EMPLOYEE: LONG_TERM_CARE_RATES[LONG_TERM_CARE_CURRENT_FY].employee,
  // 子ども・子育て支援金 (令和8年4月分〜新設・全国一律・健康保険の被保険者全員が対象)。
  // 年度表から引く (単独の数値をここへ焼き込まないこと)。
  CHILD_CARE_SUPPORT_EMPLOYEE: CHILD_CARE_SUPPORT_RATES[CHILD_CARE_SUPPORT_CURRENT_FY].employee,
  // 雇用保険 一般の事業。年度表から引く (単独の数値をここへ焼き込まないこと)。
  EMPLOYMENT_INSURANCE_EMPLOYEE: EMPLOYMENT_INSURANCE_RATES[EMPLOYMENT_INSURANCE_CURRENT_FY].general,
};

/** 雇用保険の被保険者負担率を事業の種類から引く (省略時は一般の事業) */
export function employmentInsuranceEmployeeRate(
  businessType: EmploymentInsuranceBusinessType = 'general',
): number {
  return EMPLOYMENT_INSURANCE_RATES[EMPLOYMENT_INSURANCE_CURRENT_FY][businessType];
}

/**
 * 標準報酬月額の等級 1件。
 *  lower_bound = 報酬月額の「◯◯円以上」。第1級は下限なし (null)。
 *  上限は次の等級の lower_bound (未満) となる。最高等級に上限はない。
 */
export interface StandardRemunerationGrade {
  /** 等級 (第◯級) */
  grade: number;
  /** 標準報酬月額 */
  standard: number;
  /** 報酬月額の下限 (この額「以上」でこの等級。第1級は null) */
  lower_bound: number | null;
}

/**
 * 健康保険 標準報酬月額 等級表 (全50等級) — 健康保険法 第40条 別表第一
 *
 * 【出典 — 一次情報】全国健康保険協会
 *   「令和8年3月分(4月納付分)からの健康保険・厚生年金保険の保険料額表」
 *   https://www.kyoukaikenpo.or.jp/assets/R8_13tokyo.pdf
 *   第1級 58,000円 (63,000円未満) 〜 第50級 1,390,000円 (1,355,000円以上)
 *
 * ★等級の境界は単純な中間値ではない (例: 第49級/第50級の境界は 1,355,000円で、
 *   1,330,000と1,390,000の中間値 1,360,000 ではない)。必ず告示の表を転記すること。
 */
export const HEALTH_INSURANCE_GRADES: StandardRemunerationGrade[] = [
  { grade: 1, standard: 58_000, lower_bound: null },
  { grade: 2, standard: 68_000, lower_bound: 63_000 },
  { grade: 3, standard: 78_000, lower_bound: 73_000 },
  { grade: 4, standard: 88_000, lower_bound: 83_000 },
  { grade: 5, standard: 98_000, lower_bound: 93_000 },
  { grade: 6, standard: 104_000, lower_bound: 101_000 },
  { grade: 7, standard: 110_000, lower_bound: 107_000 },
  { grade: 8, standard: 118_000, lower_bound: 114_000 },
  { grade: 9, standard: 126_000, lower_bound: 122_000 },
  { grade: 10, standard: 134_000, lower_bound: 130_000 },
  { grade: 11, standard: 142_000, lower_bound: 138_000 },
  { grade: 12, standard: 150_000, lower_bound: 146_000 },
  { grade: 13, standard: 160_000, lower_bound: 155_000 },
  { grade: 14, standard: 170_000, lower_bound: 165_000 },
  { grade: 15, standard: 180_000, lower_bound: 175_000 },
  { grade: 16, standard: 190_000, lower_bound: 185_000 },
  { grade: 17, standard: 200_000, lower_bound: 195_000 },
  { grade: 18, standard: 220_000, lower_bound: 210_000 },
  { grade: 19, standard: 240_000, lower_bound: 230_000 },
  { grade: 20, standard: 260_000, lower_bound: 250_000 },
  { grade: 21, standard: 280_000, lower_bound: 270_000 },
  { grade: 22, standard: 300_000, lower_bound: 290_000 },
  { grade: 23, standard: 320_000, lower_bound: 310_000 },
  { grade: 24, standard: 340_000, lower_bound: 330_000 },
  { grade: 25, standard: 360_000, lower_bound: 350_000 },
  { grade: 26, standard: 380_000, lower_bound: 370_000 },
  { grade: 27, standard: 410_000, lower_bound: 395_000 },
  { grade: 28, standard: 440_000, lower_bound: 425_000 },
  { grade: 29, standard: 470_000, lower_bound: 455_000 },
  { grade: 30, standard: 500_000, lower_bound: 485_000 },
  { grade: 31, standard: 530_000, lower_bound: 515_000 },
  { grade: 32, standard: 560_000, lower_bound: 545_000 },
  { grade: 33, standard: 590_000, lower_bound: 575_000 },
  { grade: 34, standard: 620_000, lower_bound: 605_000 },
  { grade: 35, standard: 650_000, lower_bound: 635_000 },
  { grade: 36, standard: 680_000, lower_bound: 665_000 },
  { grade: 37, standard: 710_000, lower_bound: 695_000 },
  { grade: 38, standard: 750_000, lower_bound: 730_000 },
  { grade: 39, standard: 790_000, lower_bound: 770_000 },
  { grade: 40, standard: 830_000, lower_bound: 810_000 },
  { grade: 41, standard: 880_000, lower_bound: 855_000 },
  { grade: 42, standard: 930_000, lower_bound: 905_000 },
  { grade: 43, standard: 980_000, lower_bound: 955_000 },
  { grade: 44, standard: 1_030_000, lower_bound: 1_005_000 },
  { grade: 45, standard: 1_090_000, lower_bound: 1_055_000 },
  { grade: 46, standard: 1_150_000, lower_bound: 1_115_000 },
  { grade: 47, standard: 1_210_000, lower_bound: 1_175_000 },
  { grade: 48, standard: 1_270_000, lower_bound: 1_235_000 },
  { grade: 49, standard: 1_330_000, lower_bound: 1_295_000 },
  { grade: 50, standard: 1_390_000, lower_bound: 1_355_000 },
];

/**
 * 厚生年金保険 標準報酬月額 等級表 (全32等級) — 厚生年金保険法 第20条
 *
 * 【出典 — 一次情報】日本年金機構
 *   「令和2年9月分(10月納付分)からの厚生年金保険料額表 (令和8年度版)」
 *   https://www.nenkin.go.jp/service/kounen/hokenryo/ryogaku/ryogakuhyo/20200825.html
 *   第1級 88,000円 (93,000円未満) 〜 第32級 650,000円 (635,000円以上)
 *   第32級 (650,000円) の折半額は 59,475円 と保険料額表に明記されている。
 *
 * ★健康保険 (全50等級・上限1,390,000円) とは別の表である。
 *   健保の表を厚生年金に流用すると、高額報酬者の保険料が最大で 2倍以上 過大になる。
 *   (例: 月給140万円 → 誤 127,185円 / 正 59,475円 — 67,710円の過大徴収)
 *
 * ★将来改正の予告: 令和9年(2027年)9月から標準報酬月額の上限が段階的に引き上げられる
 *   予定 (最終的に75万円)。適用開始日以降はこの表を差し替えること。
 */
export const PENSION_INSURANCE_GRADES: StandardRemunerationGrade[] = [
  { grade: 1, standard: 88_000, lower_bound: null },
  { grade: 2, standard: 98_000, lower_bound: 93_000 },
  { grade: 3, standard: 104_000, lower_bound: 101_000 },
  { grade: 4, standard: 110_000, lower_bound: 107_000 },
  { grade: 5, standard: 118_000, lower_bound: 114_000 },
  { grade: 6, standard: 126_000, lower_bound: 122_000 },
  { grade: 7, standard: 134_000, lower_bound: 130_000 },
  { grade: 8, standard: 142_000, lower_bound: 138_000 },
  { grade: 9, standard: 150_000, lower_bound: 146_000 },
  { grade: 10, standard: 160_000, lower_bound: 155_000 },
  { grade: 11, standard: 170_000, lower_bound: 165_000 },
  { grade: 12, standard: 180_000, lower_bound: 175_000 },
  { grade: 13, standard: 190_000, lower_bound: 185_000 },
  { grade: 14, standard: 200_000, lower_bound: 195_000 },
  { grade: 15, standard: 220_000, lower_bound: 210_000 },
  { grade: 16, standard: 240_000, lower_bound: 230_000 },
  { grade: 17, standard: 260_000, lower_bound: 250_000 },
  { grade: 18, standard: 280_000, lower_bound: 270_000 },
  { grade: 19, standard: 300_000, lower_bound: 290_000 },
  { grade: 20, standard: 320_000, lower_bound: 310_000 },
  { grade: 21, standard: 340_000, lower_bound: 330_000 },
  { grade: 22, standard: 360_000, lower_bound: 350_000 },
  { grade: 23, standard: 380_000, lower_bound: 370_000 },
  { grade: 24, standard: 410_000, lower_bound: 395_000 },
  { grade: 25, standard: 440_000, lower_bound: 425_000 },
  { grade: 26, standard: 470_000, lower_bound: 455_000 },
  { grade: 27, standard: 500_000, lower_bound: 485_000 },
  { grade: 28, standard: 530_000, lower_bound: 515_000 },
  { grade: 29, standard: 560_000, lower_bound: 545_000 },
  { grade: 30, standard: 590_000, lower_bound: 575_000 },
  { grade: 31, standard: 620_000, lower_bound: 605_000 },
  { grade: 32, standard: 650_000, lower_bound: 635_000 },
];

/** 標準賞与額の上限 — 健康保険法 第45条 / 厚生年金保険法 第24条の4 */
export const STANDARD_BONUS_CAPS = {
  /**
   * 厚生年金保険: 支給1回 (同じ月に2回以上支給されたときは合算) につき 150万円。
   * 出典: 日本年金機構「厚生年金保険の保険料」/ 保険料額表 備考
   */
  pension_per_month_jpy: 1_500_000,
  /**
   * 健康保険・介護保険: 年度 (毎年4月1日〜翌年3月31日) の累計額 573万円。
   * 出典: 全国健康保険協会 保険料額表 備考 /
   *       日本年金機構「年間の標準賞与額の累計額が573万円を超えたとき」
   *       https://www.nenkin.go.jp/shinsei/kounen/tekiyo/shoyo/20120314-01.html
   */
  health_fiscal_year_jpy: 5_730_000,
  /** 標準賞与額は賞与額から1,000円未満の端数を切り捨てて算出する */
  rounding_unit_jpy: 1_000,
} as const;

/** 料率・税額表マスタ1件ぶんの鮮度メタ (T-250 で必須化した機械可読メタ) */
export interface RateMasterMeta {
  /** マスタの日本語名 */
  master_ja: string;
  /** 適用年度キー (社保系は年度 FY / 税額表は暦年ベースだが同じ FY 表記で持つ) */
  applied_fiscal_year: string;
  /** 適用年度の和暦表示 (例: 令和8年度 / 令和8年分) */
  applied_year_ja: string;
  /** 一次情報の出典 URL */
  source_url: string;
  /** 取込日 (一次情報を実確認して本マスタへ反映した日 YYYY-MM-DD) */
  ingested_at: string;
}

/**
 * 全料率・税額表マスタの鮮度メタ (機械可読・T-250)。
 *
 * ★従来は出典が JSDoc コメントに散在し「どの年度の値をいつ取り込んだか」を機械が
 *   読めなかった。本メタを SoT とし、改定を取り込んだら必ず applied_fiscal_year /
 *   ingested_at を更新すること。メタの無いマスタは生成時 (domain-lane-injector) に
 *   日本語警告が出る。
 * ★ingested_at は「一次情報を実確認した日」。2026-08-01 は legal-values/payroll.legal.json
 *   の primary_sources[].verified と同日 (同じ実確認作業に由来する)。
 */
export const PAYROLL_MASTER_META: Record<string, RateMasterMeta> = {
  child_care_support: {
    master_ja: "子ども・子育て支援金率 (協会けんぽ・全国一律)",
    applied_fiscal_year: "FY2026",
    applied_year_ja: "令和8年度",
    source_url: "https://www.kyoukaikenpo.or.jp/about/business/insurance_rate/003/index.html",
    ingested_at: "2026-08-01",
  },
  employment_insurance: {
    master_ja: "雇用保険料率 (厚生労働省・事業の種類別)",
    applied_fiscal_year: "FY2026",
    applied_year_ja: "令和8年度",
    source_url: "https://www.mhlw.go.jp/content/001692566.pdf",
    ingested_at: "2026-08-01",
  },
  long_term_care: {
    master_ja: "介護保険料率 (協会けんぽ・全国一律)",
    applied_fiscal_year: "FY2026",
    applied_year_ja: "令和8年度",
    source_url: "https://www.kyoukaikenpo.or.jp/about/business/insurance_rate/002/index.html",
    ingested_at: "2026-08-01",
  },
  health_insurance_grades: {
    master_ja: "健康保険 標準報酬月額 等級表 (全50等級)",
    applied_fiscal_year: "FY2026",
    applied_year_ja: "令和8年度",
    source_url: "https://www.kyoukaikenpo.or.jp/assets/R8_13tokyo.pdf",
    ingested_at: "2026-08-01",
  },
  pension_insurance_grades: {
    master_ja: "厚生年金保険 標準報酬月額 等級表 (全32等級)",
    applied_fiscal_year: "FY2026",
    applied_year_ja: "令和8年度",
    source_url: "https://www.nenkin.go.jp/service/kounen/hokenryo/ryogaku/ryogakuhyo/20200825.html",
    ingested_at: "2026-08-01",
  },
  withholding_tax_table: {
    master_ja: WITHHOLDING_TAX_TABLE_META.master_ja,
    applied_fiscal_year: WITHHOLDING_TAX_TABLE_META.applied_fiscal_year,
    applied_year_ja: WITHHOLDING_TAX_TABLE_META.applied_year_ja,
    source_url: WITHHOLDING_TAX_TABLE_META.source_url,
    ingested_at: WITHHOLDING_TAX_TABLE_META.ingested_at,
  },
  bonus_withholding_rate: {
    master_ja: BONUS_RATE_TABLE_META.master_ja,
    applied_fiscal_year: BONUS_RATE_TABLE_META.applied_fiscal_year,
    applied_year_ja: BONUS_RATE_TABLE_META.applied_year_ja,
    source_url: BONUS_RATE_TABLE_META.source_url,
    ingested_at: BONUS_RATE_TABLE_META.ingested_at,
  },
};

/** メタ必須のマスタ名 (検査軸・生成時警告の照合先) */
export const REQUIRED_MASTER_META_KEYS = [
  "child_care_support",
  "employment_insurance",
  "long_term_care",
  "health_insurance_grades",
  "pension_insurance_grades",
  "withholding_tax_table",
  "bonus_withholding_rate",
] as const;

/**
 * 料率マスタ1件が、どの一次情報の監視経路で改定を検知されるか。
 *
 * ★なぜ必要か (2026-08-07 実測):
 *   料率マスタは6本あるのに、一次情報の監視経路と実際に結びついていたのは2本だけだった。
 *   厚生年金の等級表・子ども子育て支援金率・雇用保険料率は、改定されても誰も気づけない状態
 *   (経路が「無い」のか「あるが繋いでいない」のかも判別できなかった)。
 *   そこで対応関係そのものを機械可読の SoT として持ち、監視できないものは
 *   【監視できない】と理由付きで申告する。ゼロで埋めない。
 *
 * ★watch_source_id は lib/japan/primary-source-ingest/sources/*.json の source id。
 *   実在しない id を書いていないかは検証軸が毎回突合する (書いただけで監視した気にならないため)。
 */
export interface RateMasterWatchLink {
  /** 監視経路の source id。監視経路が無い場合は null */
  watch_source_id: string | null;
  /** 監視経路が属するドメイン定義 (sources/<domain>.json) */
  watch_domain: string | null;
  /**
   * 一次情報から【値そのもの】を機械で取り込めるか。
   * false = 改定の検知までが自動で、値の採用は人が一次情報を実確認して行う。
   */
  value_extraction_automated: boolean;
  /** 監視経路が無い場合の理由 (日本語)。ある場合は null */
  unwatchable_reason_ja: string | null;
}

/** 料率マスタ → 一次情報の監視経路 の対応 (SoT) */
export const PAYROLL_MASTER_WATCH: Record<string, RateMasterWatchLink> = {
  child_care_support: {
    watch_source_id: "kyoukaikenpo-kodomo-kosodate-rate",
    watch_domain: "payroll",
    value_extraction_automated: false,
    unwatchable_reason_ja: null,
  },
  employment_insurance: {
    watch_source_id: "mhlw-koyou-hokenryoritsu",
    watch_domain: "payroll",
    // 厚労省は雇用保険料率を PDF 1枚でしか公開していない (HTML 掲載ページは実測で 404)。
    // PDF 本体のバイト列ハッシュで「改定されたこと」は検知できるが、値は読み取れない。
    value_extraction_automated: false,
    unwatchable_reason_ja: null,
  },
  long_term_care: {
    watch_source_id: "kyoukaikenpo-kaigo-rate-kaitei",
    watch_domain: "payroll",
    value_extraction_automated: false,
    unwatchable_reason_ja: null,
  },
  health_insurance_grades: {
    watch_source_id: "kyoukaikenpo-hokenryogaku-r08",
    watch_domain: "payroll",
    // 47支部の保険料額表 PDF 本文の自動抽出は未実装。
    value_extraction_automated: false,
    unwatchable_reason_ja: null,
  },
  pension_insurance_grades: {
    watch_source_id: "nenkin-kounen-hokenryogaku-hyo",
    watch_domain: "payroll",
    value_extraction_automated: false,
    unwatchable_reason_ja: null,
  },
  withholding_tax_table: {
    watch_source_id: "nta-gensen-zeigakuhyo",
    watch_domain: "payroll",
    // 月額表 Excel は機械変換で取り込み済み (gensen_tax_table_r8.ts)。
    value_extraction_automated: true,
    unwatchable_reason_ja: null,
  },
  bonus_withholding_rate: {
    // 算出率の表は月額表と同じ国税庁の税額表ページで配布される (同一経路で改定を検知する)。
    watch_source_id: "nta-gensen-zeigakuhyo",
    watch_domain: "payroll",
    // 算出率表 Excel は機械変換で取り込み済み (gensen_bonus_rate_r8.ts)。
    value_extraction_automated: true,
    unwatchable_reason_ja: null,
  },
};

/** 監視カバレッジの集計結果 */
export interface MasterWatchCoverage {
  /** 料率マスタの総数 */
  total: number;
  /** 監視経路が結びついているマスタ数 */
  watched: number;
  /** 監視経路が無いマスタ数 (★ゼロで埋めず必ず開示する) */
  unwatched: number;
  /** 値そのものまで機械で取り込めているマスタ数 */
  value_automated: number;
  /** 改定の検知は自動だが値の採用は人手のマスタ数 */
  detection_only: number;
  /** マスタ1件ごとの明細 (画面・報告での開示用) */
  rows: Array<{
    key: string;
    master_ja: string;
    watch_source_id: string | null;
    watched: boolean;
    value_extraction_automated: boolean;
    note_ja: string;
  }>;
  /** 開示用の日本語サマリ (未監視が0件でも「0件」と明示する) */
  summary_ja: string;
}

/**
 * 料率マスタの監視カバレッジを集計する。
 * ★未監視を隠さない: 対応表そのものが無いマスタは unwatched に数える (黙って除外しない)。
 */
export function summarizeMasterWatchCoverage(): MasterWatchCoverage {
  const rows: MasterWatchCoverage["rows"] = [];
  for (const key of REQUIRED_MASTER_META_KEYS) {
    const meta = PAYROLL_MASTER_META[key];
    const link = PAYROLL_MASTER_WATCH[key];
    const watched = Boolean(link?.watch_source_id);
    const auto = Boolean(link?.value_extraction_automated);
    let note: string;
    if (!link) {
      note = "監視経路の対応が定義されていません（改定されても気づけません）";
    } else if (!watched) {
      note = link.unwatchable_reason_ja ?? "監視経路がありません（理由も未記載）";
    } else if (auto) {
      note = "改定の検知と値の取込のどちらも機械で行えます";
    } else {
      note = "改定の検知までが自動です。値の採用は一次情報を実確認して行います";
    }
    rows.push({
      key,
      master_ja: meta?.master_ja ?? key,
      watch_source_id: link?.watch_source_id ?? null,
      watched,
      value_extraction_automated: auto,
      note_ja: note,
    });
  }
  const total = rows.length;
  const watched = rows.filter((r) => r.watched).length;
  const valueAuto = rows.filter((r) => r.watched && r.value_extraction_automated).length;
  const unwatched = total - watched;
  const summary =
    `料率マスタ ${total} 件のうち、改定を監視できているのは ${watched} 件です` +
    `（うち値の取込まで自動 ${valueAuto} 件 / 改定の検知のみ ${watched - valueAuto} 件）。` +
    `監視できていないマスタは ${unwatched} 件です。`;
  return {
    total,
    watched,
    unwatched,
    value_automated: valueAuto,
    detection_only: watched - valueAuto,
    rows,
    summary_ja: summary,
  };
}

/** 鮮度メタの欠落を日本語で列挙する (欠落なしなら空配列)。生成時警告と検査軸が使う。 */
export function listMasterMetaGaps(): string[] {
  const gaps: string[] = [];
  for (const key of REQUIRED_MASTER_META_KEYS) {
    const m = PAYROLL_MASTER_META[key];
    if (!m) { gaps.push(`${key}: メタ定義そのものが無い`); continue; }
    if (!m.applied_fiscal_year) gaps.push(`${key}: 適用年度 (applied_fiscal_year) が無い`);
    if (!m.source_url) gaps.push(`${key}: 出典 URL (source_url) が無い`);
    if (!m.ingested_at) gaps.push(`${key}: 取込日 (ingested_at) が無い`);
  }
  return gaps;
}

/**
 * 給与レーンが読む料率表どうしの食い違いを返す (空配列 = 食い違いなし)。2026-10-18 U-02。
 *
 * ★雇用保険料率は本ファイルの EMPLOYMENT_INSURANCE_RATES と rousai_insurance_rate.ts の
 *   KOYOU_INSURANCE_RATE_TABLE_FY20xx の2か所に在る (どちらも一次資料から転記)。改定時に片方だけ
 *   直すと、月次の控除と労働保険料の申告で料率が食い違うため、ここで突き合わせる。値は書き写さない。
 * ★あわせて健康保険料率表・労災保険率表の自己検算 (各ファイルの verify 関数) を呼ぶ。
 *   注入部品 (domain-lane-injector.sh) が生成のたびに呼び、食い違いがあれば日本語で警告する。
 */
export function verifyPayrollRateSources(): string[] {
  const errors: string[] = [];
  const KIND: Record<EmploymentInsuranceBusinessType, string> = {
    general: '一般の事業', agriculture: '農林水産・清酒製造の事業', construction: '建設の事業',
  };
  const pairs: Array<[keyof typeof EMPLOYMENT_INSURANCE_RATES, readonly { kind: string; employeeRatePerMille: number }[]]> = [
    ['FY2025', KOYOU_INSURANCE_RATE_TABLE_FY2025],
    ['FY2026', KOYOU_INSURANCE_RATE_TABLE_FY2026],
  ];
  for (const [fy, table] of pairs) {
    for (const bt of Object.keys(KIND) as EmploymentInsuranceBusinessType[]) {
      const here = EMPLOYMENT_INSURANCE_RATES[fy][bt];
      const row = table.find((r) => r.kind === KIND[bt]);
      if (!row) { errors.push(`雇用保険料率 ${fy} ${KIND[bt]}: 労働保険料率の表に行が無い`); continue; }
      // 1000分率 → 比。整数1万分率で比べて浮動小数点の差を拾わない
      if (Math.round(here * 10_000) !== Math.round(row.employeeRatePerMille * 10)) {
        errors.push(`雇用保険料率 ${fy} ${KIND[bt]}: 給与の表 ${here} と労働保険料率の表 ${row.employeeRatePerMille}/1000 が食い違う`);
      }
    }
  }
  for (const [label, r] of [
    ['健康保険料率表 (協会けんぽ47支部)', verifyHealthInsuranceRateTable()],
    ['労災保険率表', verifyRousaiInsuranceRateTable()],
  ] as const) {
    if (!r.ok) errors.push(`${label}の自己検算が不合格: ${r.errors.slice(0, 3).join(' / ')}`);
  }
  return errors;
}

/** 本モジュールの料率マスタが適用している年度 (改定取込時はここも進める) */
export const PAYROLL_APPLIED_FISCAL_YEAR = "FY2026" as const;

/**
 * 適用年度の表示情報を返す (T-250: 生成物の給与明細/源泉画面に「令和N年度適用」を出すための関数)。
 *
 * ★日本の年度 (4月1日〜翌3月31日) で判定する。FY2026 = 令和8年度 = 2026-04-01〜2027-03-31。
 * ★マスタの適用年度が現在の年度と一致しない場合は is_current=false になり、
 *   warnings_ja に日本語の注意喚起が入る。画面側は必ず warnings_ja を表示すること
 *   (古い料率のまま黙って計算する状態を作らないため)。
 */
export function getAppliedFiscalYear(asOf: Date = new Date()): {
  /** マスタの適用年度キー (例: FY2026) */
  fiscal_year: string;
  /** 和暦の年度表示 (例: 令和8年度) */
  wareki_ja: string;
  /** 画面表示用 (例: 令和8年度適用) */
  display_ja: string;
  /** 源泉徴収税額表の適用年分 (例: 令和8年分 — 税額表は暦年単位) */
  withholding_year_ja: string;
  /** マスタの適用年度が現在の年度と一致しているか */
  is_current: boolean;
  /** 年度ずれ等の日本語注意喚起 (無ければ空配列) */
  warnings_ja: string[];
} {
  const appliedYear = Number(PAYROLL_APPLIED_FISCAL_YEAR.replace("FY", ""));
  const warekiN = appliedYear - 2018; // 令和N年 = 西暦-2018
  const wareki = `令和${warekiN}年度`;
  const warnings: string[] = [];

  // 日本の年度: 4月始まり。1〜3月は前年の年度に属する。
  const currentFyYear = asOf.getMonth() + 1 >= 4 ? asOf.getFullYear() : asOf.getFullYear() - 1;
  const isCurrent = currentFyYear === appliedYear;
  if (!isCurrent) {
    warnings.push(
      `社会保険の料率マスタは${wareki} (FY${appliedYear}) 適用のままです。` +
      `現在は令和${currentFyYear - 2018}年度 (FY${currentFyYear}) のため、料率改定の取込を確認してください。`,
    );
  }

  // 源泉徴収税額表は暦年単位で、支払日の年分の表を使う (令和8年分・令和9年分を取り込み済み — 2026-10-03 T07)。
  const asOfYear = asOf.getFullYear();
  const latestWithholdingYear = SUPPORTED_WITHHOLDING_YEARS[SUPPORTED_WITHHOLDING_YEARS.length - 1];
  const withholdingTable = MONTHLY_WITHHOLDING_TABLES[asOfYear];
  if (!withholdingTable) {
    const latest = MONTHLY_WITHHOLDING_TABLES[latestWithholdingYear];
    warnings.push(
      `源泉徴収税額表は${SUPPORTED_WITHHOLDING_YEARS.map((y) => MONTHLY_WITHHOLDING_TABLES[y].year_ja).join("・")}を取り込んでいます。` +
      `${asOfYear}年の給与には使用できません。国税庁の令和${asOfYear - 2018}年分の税額表を取り込んでください` +
      `(最新の取込は${latest.year_ja})。`,
    );
  }

  return {
    fiscal_year: PAYROLL_APPLIED_FISCAL_YEAR,
    wareki_ja: wareki,
    display_ja: `${wareki}適用`,
    withholding_year_ja: withholdingTable ? withholdingTable.year_ja : WITHHOLDING_TAX_TABLE_META.applied_year_ja,
    is_current: isCurrent,
    warnings_ja: warnings,
  };
}

/** 給与明細・源泉徴収の画面ヘッダに実際に描画する開示情報 (1行ぶん) */
export interface RateDisclosureRow {
  /** マスタ名 (日本語・画面にそのまま出す) */
  master_ja: string;
  /** 適用年度・年分の和暦表示 (例: 令和8年度 / 令和8年分) */
  applied_year_ja: string;
  /** 一次情報の出典 URL (画面にリンクとして出す) */
  source_url: string;
  /** 一次情報を実確認した日 (YYYY-MM-DD) */
  ingested_at: string;
  /** 改定の監視経路 (無ければ null) */
  watch_source_id: string | null;
  /** 監視状況の日本語説明 (画面にそのまま出す) */
  watch_note_ja: string;
}

/** 画面へ渡す料率の鮮度開示のひとまとまり */
export interface RateFreshnessDisclosure {
  /** 見出しに出す適用年度 (例: 令和8年度適用) */
  display_ja: string;
  /** 源泉徴収税額表の適用年分 (例: 令和8年分) */
  withholding_year_ja: string;
  /** 料率マスタが現在の年度と一致しているか */
  is_current: boolean;
  /** 古い年度のままである等の日本語注意喚起 (空なら注意なし) */
  warnings_ja: string[];
  /** マスタ1件ごとの出典・確認日・監視状況 */
  rows: RateDisclosureRow[];
  /** 監視カバレッジの開示文 (未監視0件でも件数を明示する) */
  watch_summary_ja: string;
  /** 監視できていないマスタ数 (★画面で必ず開示する。ゼロで埋めない) */
  unwatched_count: number;
  /** この開示を組み立てた時刻 (ISO8601) */
  generated_at: string;
  /**
   * 社会保険の料率マスタが古くなる日 (この日以降は適用年度がずれる。ISO8601)。
   * ★画面側はこの1点と現在時刻を比べるだけで鮮度を判定できる。
   *   年度の数え方を画面側で実装し直すと本体とずれるため、境界日は本体が計算して渡す。
   */
  stale_after_iso: string;
  /** 源泉徴収税額表が古くなる日 (税額表は暦年単位。ISO8601) */
  withholding_stale_after_iso: string;
  /** 料率が古くなっているときに画面へ出す日本語の警告文 (古くなければ null) */
  stale_warning_ja: string | null;
}

/**
 * 給与明細・源泉徴収の画面に【実際に描画する】ための開示情報を組み立てる。
 *
 * ★なぜ関数にするか (2026-08-07 実測):
 *   従来は「画面に表示すること」という【コメントの指示】しか無く、適用年度も出典も
 *   確認日も、実際には1文字も画面に出ていなかった。指示ではなく描画できるデータを
 *   1関数で返し、画面部品がそれをそのまま出す形にする。
 */
export function getRateFreshnessDisclosure(asOf: Date = new Date()): RateFreshnessDisclosure {
  const fy = getAppliedFiscalYear(asOf);
  const cov = summarizeMasterWatchCoverage();
  const rows: RateDisclosureRow[] = cov.rows.map((r) => {
    const meta = PAYROLL_MASTER_META[r.key];
    return {
      master_ja: r.master_ja,
      applied_year_ja: meta?.applied_year_ja ?? "(適用年度が未登録)",
      source_url: meta?.source_url ?? "",
      ingested_at: meta?.ingested_at ?? "(確認日が未登録)",
      watch_source_id: r.watch_source_id,
      watch_note_ja: r.note_ja,
    };
  });
  // 社会保険の年度は4月始まり。FY2026 のマスタは 2027-04-01 以降は古い。
  const appliedYear = Number(PAYROLL_APPLIED_FISCAL_YEAR.replace("FY", ""));
  const staleAfter = new Date(Date.UTC(appliedYear + 1, 3, 1)); // 4月 = month index 3
  // 源泉徴収税額表は暦年単位。取り込み済みの最新の年分の翌年1月1日以降は使えない
  // (令和9年分まで取り込み済みなので 2028-01-01。2026-10-03 T07 で令和9年分を追加)。
  const withholdingYear = SUPPORTED_WITHHOLDING_YEARS[SUPPORTED_WITHHOLDING_YEARS.length - 1];
  const withholdingStaleAfter = new Date(Date.UTC(withholdingYear + 1, 0, 1));

  return {
    display_ja: fy.display_ja,
    withholding_year_ja: fy.withholding_year_ja,
    is_current: fy.is_current,
    warnings_ja: fy.warnings_ja,
    rows,
    watch_summary_ja: cov.summary_ja,
    unwatched_count: cov.unwatched,
    generated_at: asOf.toISOString(),
    stale_after_iso: staleAfter.toISOString(),
    withholding_stale_after_iso: withholdingStaleAfter.toISOString(),
    stale_warning_ja: fy.warnings_ja.length > 0 ? fy.warnings_ja.join(" ") : null,
  };
}

/** 等級表から標準報酬月額を引く共通ロジック (報酬月額の「◯◯円以上」で判定する) */
function lookupStandardRemuneration(
  monthly: number,
  grades: StandardRemunerationGrade[],
): number {
  if (!(monthly > 0)) return grades[0].standard;
  // 上位等級から順に「下限以上か」を見る。どこにも当たらなければ第1級。
  for (let i = grades.length - 1; i >= 0; i--) {
    const g = grades[i];
    if (g.lower_bound === null || monthly >= g.lower_bound) return g.standard;
  }
  return grades[0].standard;
}

/**
 * 健康保険 (・介護保険) の標準報酬月額を求める (全50等級)。
 *
 * ★旧実装は `monthly <= 等級値` で判定していたため、告示の等級境界と一致していなかった。
 *   例: 報酬月額 305,000円 → 正 300,000円 (第22級 290,000以上310,000未満) だが 320,000円を返していた。
 */
export function calcStandardRemuneration(monthly: number): number {
  return lookupStandardRemuneration(monthly, HEALTH_INSURANCE_GRADES);
}

/**
 * 厚生年金保険の標準報酬月額を求める (全32等級・上限 650,000円)。
 * 健康保険とは等級表が異なるため、必ず本関数を使うこと。
 */
export function calcPensionStandardRemuneration(monthly: number): number {
  return lookupStandardRemuneration(monthly, PENSION_INSURANCE_GRADES);
}

export function calcAge(birthDate: string, asOf: Date = new Date()): number {
  const birth = new Date(birthDate);
  let age = asOf.getFullYear() - birth.getFullYear();
  const m = asOf.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && asOf.getDate() < birth.getDate())) age -= 1;
  return age;
}

export function isLongTermCareTarget(birthDate: string, asOf: Date = new Date()): boolean {
  const age = calcAge(birthDate, asOf);
  return age >= 40 && age < 65;
}

export interface SocialInsuranceResult {
  health: number;
  pension: number;
  long_term_care: number;
  /**
   * 子ども・子育て支援金 (被保険者負担分)。
   * 令和8年4月分 (5月納付分) から新設。健康保険の被保険者【全員】が対象であり、
   * 介護保険料のような年齢要件は無い。基礎は健康保険の標準報酬月額。
   */
  child_care_support: number;
  employment: number;
  /** 健康保険・介護保険に適用した標準報酬月額 (全50等級) */
  standard_remuneration_health: number;
  /** 厚生年金に適用した標準報酬月額 (全32等級・上限650,000円) */
  standard_remuneration_pension: number;
  /** 実際に適用した健康保険料率 (被保険者負担・折半後) */
  health_rate_employee_applied: number;
  /**
   * 健康保険料率が全国平均の概算 (支部別の実料率ではない) かどうか。
   * true の場合、health は実額ではないので、そのまま振込・納付に使ってはならない。
   */
  health_rate_is_estimate: boolean;
  /** 健康保険料率に関する日本語の注意 (概算利用時のみ。実料率が設定されていれば空配列) */
  health_rate_notes: string[];
  /**
   * 健康保険料率をどこから引いたか (日本語・画面にそのまま出せる)。
   * 協会けんぽの支部の料率表から引いたときだけ入る (2026-10-18 U-02)。
   */
  health_rate_source_ja?: string;
}

/** 健康保険料率が未設定のときに表示・記録する日本語メッセージ (fail-closed 時の例外文にも使う) */
export const HEALTH_INSURANCE_RATE_UNSET_MESSAGE =
  "健康保険料率が未設定のため保険料を計算できません。" +
  "協会けんぽの保険料額表からお勤め先の支部 (都道府県) の健康保険料率を設定してください。";

/**
 * 適用する健康保険料率 (被保険者負担・折半後) を決める。
 *
 * ★健康保険料率は協会けんぽの都道府県支部ごとに異なるため、全国一律の法定値が存在しない。
 *   一次情報から単一の正しい値を決められない以上、システムが勝手に「正しい料率」を作ってはならない。
 *   - Employee.health_insurance_rate (支部の実料率・折半前) があればそれを折半して使う。
 *   - 無い場合は、既定では全国平均の【概算】へフォールバックし、概算である旨を必ず持ち回る。
 *   - strict = true なら概算を使わず例外を投げる (振込額を確定させる本番運用向け)。
 *
 * 【確認先 — 一次情報】全国健康保険協会「都道府県毎の保険料額表」
 *   https://www.kyoukaikenpo.or.jp/g7/cat330/sb3130/
 */
export function resolveHealthEmployeeRate(
  employee: Employee,
  opts: { strict?: boolean; insurance_month?: string } = {},
): { rate: number; is_estimate: boolean; notes: string[]; rate_bp_total?: number; source_ja?: string } {
  const raw = employee.health_insurance_rate;
  if (typeof raw === "number" && Number.isFinite(raw) && raw > 0) {
    // 入力は折半前の全体料率。被保険者負担は 1/2 (健康保険法 第161条第1項)。
    return { rate: raw / 2, is_estimate: false, notes: [] };
  }
  // ★2026-10-18 (U-02): 料率の入力が無くても、支部 (都道府県) と保険料の対象月が分かれば
  //   協会けんぽ 47支部の実料率表 (shakai_hoken_rate_table.ts) から引く。表の値は書き写さない。
  //   対象月が無いときは引かない (健康保険料率は3月分で切り替わるため、月が分からないと年度を誤る)。
  //   表に無い月・特定できない都道府県は、表の側の日本語の理由を注記に添えて従来どおり概算へ落とす。
  let tableMiss = "";
  if (employee.prefecture && opts.insurance_month) {
    try {
      const hit = getHealthInsuranceRate(employee.prefecture, opts.insurance_month);
      return {
        rate: hit.rateTotal / 2,
        is_estimate: false,
        notes: [],
        // 保険料は「標準報酬月額 × 1万分率の整数」で全額を出してから折半する (表の rateTotal の注記)。
        rate_bp_total: hit.rateBp,
        source_ja:
          `協会けんぽ ${hit.pref}支部 ${hit.fiscalYearJa}の健康保険料率 ${hit.ratePercent}% ` +
          `(保険料の対象月 ${opts.insurance_month}分・${hit.appliesFromJa})。` +
          `健康保険組合の加入者は組合の料率を health_insurance_rate に設定してください。出典: ${hit.sourceUrl}`,
      };
    } catch (e) {
      tableMiss = e instanceof Error ? e.message : String(e);
    }
  }
  const where = employee.prefecture ? `${employee.prefecture}支部` : "お勤め先の支部 (都道府県)";
  if (tableMiss && opts.strict) {
    throw new Error(`健康保険料率が未設定で、支部の料率表からも引けませんでした: ${tableMiss}`);
  }
  if (opts.strict) {
    throw new Error(
      `健康保険料率が未設定のため保険料を計算できません。` +
      `協会けんぽの保険料額表から${where}の健康保険料率を設定してください。`,
    );
  }
  return {
    rate: RATES.HEALTH_EMPLOYEE,
    is_estimate: true,
    notes: [
      `健康保険料率が未設定のため、全国平均の【概算】(${(RATES.HEALTH_EMPLOYEE * 2 * 100).toFixed(2)}%) で計算しています。` +
      `この健康保険料は実額ではありません。協会けんぽの保険料額表から${where}の健康保険料率を設定してください` +
      `(健康保険料率は都道府県支部ごとに異なるため、システムでは確定できません)。`,
      ...(tableMiss ? [`支部の料率表から引けなかった理由: ${tableMiss}`] : []),
    ],
  };
}

/**
 * 月次の社会保険料 (被保険者負担分) を算出する。
 *
 * ★健康保険と厚生年金は標準報酬月額の等級表が別である (健保50等級 / 厚年32等級)。
 *   旧実装は厚生年金にも健保の50等級表を流用していたため、
 *   高額報酬者の厚生年金保険料が上限を大きく超えていた。
 *
 * @param opts.require_health_insurance_rate true で健康保険料率の未設定を例外にする (概算を使わない)
 */
export function calcSocialInsurance(
  employee: Employee,
  monthlyGross: number,
  opts: { require_health_insurance_rate?: boolean; insurance_month?: string } = {},
): SocialInsuranceResult {
  // 保険料の対象月が指定されたときだけ、料率の適用期間を確かめる (未指定は従来どおり)。
  const ccsApplies = assertInsuranceMonthSupported(opts.insurance_month);
  const standardHealth = calcStandardRemuneration(monthlyGross);
  const standardPension = calcPensionStandardRemuneration(monthlyGross);
  const ltcTarget = isLongTermCareTarget(employee.birth_date);
  const empRate = employmentInsuranceEmployeeRate(employee.employment_insurance_business_type);
  const healthRate = resolveHealthEmployeeRate(employee, {
    strict: opts.require_health_insurance_rate === true,
    insurance_month: opts.insurance_month,
  });
  const result: SocialInsuranceResult = {
    // 支部の料率表から引いたときは「標準報酬月額 × 1万分率の整数」で全額を出してから折半する
    //   (小数の料率を掛けると、保険料額表より1円多くなる組み合わせがある: 表の rateTotal の注記)。
    health: healthRate.rate_bp_total !== undefined
      ? roundEmployeeShare((standardHealth * healthRate.rate_bp_total) / 20_000)
      : roundEmployeeShare(standardHealth * healthRate.rate),
    pension: roundEmployeeShare(standardPension * RATES.PENSION_EMPLOYEE),
    long_term_care: ltcTarget ? roundEmployeeShare(standardHealth * RATES.LONG_TERM_CARE_EMPLOYEE) : 0,
    // 子ども・子育て支援金は介護保険と違い年齢要件が無く、健康保険の被保険者全員から徴収する。
    // 基礎は健康保険と同じ標準報酬月額 (厚生年金の32等級表ではない)。
    child_care_support: roundEmployeeShare(standardHealth * RATES.CHILD_CARE_SUPPORT_EMPLOYEE),
    // 雇用保険は標準報酬月額ではなく実際の賃金総額に料率を乗じる (雇用保険法 第68条)
    employment: roundEmployeeShare(monthlyGross * empRate),
    standard_remuneration_health: standardHealth,
    standard_remuneration_pension: standardPension,
    health_rate_employee_applied: healthRate.rate,
    health_rate_is_estimate: healthRate.is_estimate,
    health_rate_notes: healthRate.notes,
    ...(healthRate.source_ja ? { health_rate_source_ja: healthRate.source_ja } : {}),
  };
  // 子ども・子育て支援金は令和8年4月分 (5月納付分) から。対象月が3月分以前なら徴収しない。
  if (!ccsApplies) result.child_care_support = 0;
  return result;
}

/** 子ども・子育て支援金の適用開始月 (保険料の対象月) — 協会けんぽ保険料額表「令和8年4月分（5月納付分）～適用」 */
export const CHILD_CARE_SUPPORT_START_MONTH = "2026-04" as const;
/** 本モジュールの料率マスタで計算できる保険料の対象月の範囲 (健康保険・介護保険の令和8年度料率は3月分から) */
export const INSURANCE_MONTH_SUPPORTED_RANGE = { from: "2026-03", until: "2027-02" } as const;

/**
 * 保険料の対象月 (YYYY-MM) が料率マスタの範囲内かを確かめ、子ども・子育て支援金がかかる月かを返す。
 * 未指定なら従来どおり (支援金あり) を返す。範囲外は旧い料率で計算せず例外を投げる。
 */
function assertInsuranceMonthSupported(insuranceMonth: string | undefined): boolean {
  if (insuranceMonth === undefined || insuranceMonth === null) return true;
  if (!/^\d{4}-\d{2}$/.test(String(insuranceMonth))) {
    throw new Error(`保険料の対象月は YYYY-MM の形で指定してください (受け取った値: ${JSON.stringify(insuranceMonth)})。`);
  }
  const R = INSURANCE_MONTH_SUPPORTED_RANGE;
  if (insuranceMonth < R.from || insuranceMonth > R.until) {
    throw new Error(
      `保険料の対象月 ${insuranceMonth} の料率は未取込のため計算できません。` +
      `本モジュールの料率は令和8年度 (健康保険・介護保険は令和8年3月分〜令和9年2月分、子ども・子育て支援金は令和8年4月分〜) のものです。` +
      `協会けんぽ・日本年金機構の該当年度の保険料額表を取り込んでから計算してください。`,
    );
  }
  return insuranceMonth >= CHILD_CARE_SUPPORT_START_MONTH;
}

/**
 * 給与所得の源泉徴収税額 (月額表・令和8年分) — 国税庁の実表による算出。
 *
 * ★2026-08-06 更新 (T-250): 従来の簡易近似式 (5段階の係数式) を廃止し、国税庁公表の
 *   「令和8年分 源泉徴収税額表」(月額表) の実データへ差し替えた。
 *   税額表 Excel を実取得して機械生成したマスタ (gensen_tax_table_r8.ts) を引く。
 *
 * 【出典 — 一次情報】国税庁「令和8年分 源泉徴収税額表」
 *   https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2026/01.htm
 *   根拠告示: 平成24年3月31日財務省告示第115号 別表第一 (令和7年4月30日財務省告示第122号改正)
 *
 * 算出規則 (表の備考・「税額の求め方」より):
 *  - 105,000円未満: 甲欄は0円 / 乙欄は 3.063% (1円未満切捨て)
 *  - 105,000〜740,000円未満: 表の該当区間の額をそのまま使う (231区間)
 *  - 740,000円超: 境界金額ちょうどの税額 + 超過分×率 (1円未満切捨て)
 *  - 扶養親族等が7人を超える場合: 7人の税額から1人につき1,610円を控除 (甲欄)
 *
 * @param monthlyTaxable その月の社会保険料等控除後の給与等の金額
 * @param numDependents  扶養親族等の数 (甲欄で使用。乙欄では使用しない)
 * @param opts.column    'kou' = 甲欄 (扶養控除等申告書の提出あり・既定) /
 *                       'otsu' = 乙欄 (提出なし — 副業先の給与など)
 */
export function calcWithholdingTax(
  monthlyTaxable: number,
  numDependents: number = 0,
  opts: { column?: "kou" | "otsu" } = {},
): number {
  const column = opts.column ?? "kou";
  const x = Math.floor(monthlyTaxable);
  if (!(x > 0)) return 0;

  // 扶養7人超: 「扶養親族等の数が7人の場合の税額から、7人を超える1人ごとに1,610円を控除」(表の備考)
  const dep = Math.max(0, Math.floor(numDependents));
  const depIdx = Math.min(dep, 7);
  const extraDeduction =
    column === "kou" && dep > 7 ? (dep - 7) * GENSEN_EXTRA_DEPENDENT_DEDUCTION_R8 : 0;
  const finish = (tax: number) => Math.max(0, tax - extraDeduction);

  // 105,000円未満 (令和8年分から。旧表の88,000円とは異なる)
  if (x < GENSEN_UNDER_THRESHOLD_R8) {
    return column === "kou" ? 0 : Math.floor(x * GENSEN_OTSU_UNDER_RATE_R8);
  }

  // 数値ブラケット (105,000円以上 740,000円未満・231区間)
  for (const [lo, hi, kou, otsu] of GENSEN_MONTHLY_BRACKETS_R8) {
    if (x >= lo && x < hi) return finish(column === "kou" ? kou[depIdx] : otsu);
  }

  // 境界金額ちょうど (740,000円 / 790,000円 / … / 3,500,000円) は表に明示された税額を使う
  const boundary = GENSEN_MONTHLY_BOUNDARIES_R8.find((b) => b.amount === x);
  if (boundary) {
    if (column === "kou") return finish(boundary.kou[depIdx]);
    if (boundary.otsu !== null) return finish(boundary.otsu);
    // 乙欄の額が表に無い境界 (790,000円など) は下の数式帯で求める
  }

  // 数式帯: 「下端ちょうどの場合の税額に、超過分の◯％に相当する金額を加算した金額」
  // 率を乗じた金額は1円未満切捨て (国税庁「税額の求め方」の端数処理)
  const segments = column === "kou" ? GENSEN_KOU_SEGMENTS_R8 : GENSEN_OTSU_SEGMENTS_R8;
  for (const seg of segments) {
    if (x > seg.over && (seg.until === null || x < seg.until)) {
      const base = GENSEN_MONTHLY_BOUNDARIES_R8.find((b) => b.amount === seg.over);
      const baseTax = column === "kou" ? base?.kou[depIdx] : base?.otsu;
      if (baseTax == null) break; // マスタ欠損 — 下の防御へ
      return finish(baseTax + Math.floor((x - seg.over) * seg.rate));
    }
  }

  // ここへ来るのはマスタが壊れている場合のみ。黙って0円にせず例外で顕在化させる
  // (源泉徴収0円の給与明細が正常出力される事故を防ぐ)。
  throw new Error(
    `源泉徴収税額表マスタから税額を求められませんでした (対象額 ${x.toLocaleString("ja-JP")}円)。` +
    "マスタ (gensen_tax_table_r8.ts) の破損が疑われます。",
  );
}

export function calcPayroll(input: PayrollInput): PayrollResult {
  const { employee } = input;
  const allowances = employee.allowances ?? [];
  const allowanceSum = allowances.reduce((a, b) => a + b.amount, 0);
  const overtime =
    (input.overtime_hours ?? 0) * (employee.base_salary / 160) * 1.25 +
    (input.late_night_hours ?? 0) * (employee.base_salary / 160) * 0.25 +
    (input.holiday_hours ?? 0) * (employee.base_salary / 160) * 1.35;

  const gross = Math.round(employee.base_salary + allowanceSum + overtime);
  const si = calcSocialInsurance(employee, gross, {
    require_health_insurance_rate: input.require_health_insurance_rate === true,
    insurance_month: input.insurance_month,
  });
  // 子ども・子育て支援金は健康保険法第155条第1項の保険料の一部として徴収されるため、
  // 社会保険料控除の対象となる。源泉所得税の課税対象額から差し引く。
  const taxableForIncomeTax =
    gross - si.health - si.pension - si.long_term_care - si.child_care_support - si.employment;
  // 源泉徴収税額表の年分は支払日で決まる (2026-10-03 是正 T07 / REQ-186)。
  //   旧実装は支払日にかかわらず令和8年分の表を引いていたため、2027年1月支払の給与でも令和8年分の
  //   税額になっていた (実測: 課税対象280,104円・扶養1人で 5,560円 / 正しくは令和9年分 5,390円)。
  const payYear = resolveWithholdingPayYear(input);
  const incomeTax =
    payYear.year === null || payYear.year === 2026
      ? calcWithholdingTax(taxableForIncomeTax, employee.num_dependents ?? 0)
      : calcWithholdingTaxByPayYear(payYear.year, taxableForIncomeTax, employee.num_dependents ?? 0);

  // --- 住民税 (特別徴収) ---
  // 前年所得を基に市区町村が個人別に決定するため、システムでは計算できない。
  // 未入力なら 0 を書かず null のままにし、控除合計にも差引支給額にも含めない。
  const residentTaxRaw = input.resident_tax;
  const residentTax =
    typeof residentTaxRaw === "number" && Number.isFinite(residentTaxRaw)
      ? Math.max(0, Math.floor(residentTaxRaw))
      : null;

  // 社会保険料 (被保険者負担分) の控除合計
  const socialInsuranceTotal =
    si.health + si.pension + si.long_term_care + si.child_care_support + si.employment;

  const deductions: PayrollDeductions = {
    health_insurance: si.health,
    pension: si.pension,
    long_term_care: si.long_term_care,
    child_care_support: si.child_care_support,
    employment_insurance: si.employment,
    income_tax: incomeTax,
    resident_tax: residentTax,
    // 住民税は入力があったときだけ控除合計に含める (未設定を 0 として黙って足し込まない)。
    total: socialInsuranceTotal + incomeTax + (residentTax ?? 0),
  };

  const breakdown = [
    { label: "基本給", amount: employee.base_salary },
    ...allowances.map((a) => ({ label: a.type, amount: a.amount })),
    { label: "残業手当", amount: Math.round(overtime) },
    {
      // 概算料率で計算した健康保険料は、実額と区別が付くようにラベルへ明示する。
      label: si.health_rate_is_estimate ? "健康保険料 (全国平均の概算)" : "健康保険料",
      amount: -si.health,
    },
    { label: "厚生年金保険料", amount: -si.pension },
    ...(si.long_term_care > 0 ? [{ label: "介護保険料", amount: -si.long_term_care }] : []),
    { label: "子ども・子育て支援金", amount: -si.child_care_support },
    { label: "雇用保険料", amount: -si.employment },
    { label: "源泉所得税", amount: -incomeTax },
    // 住民税は未設定でも必ず行を出す。行ごと消すと「住民税を引き忘れている」ことが
    // 明細から分からなくなり、差引支給額をそのまま振込に使って過払いになる。
    residentTax === null
      ? { label: "住民税 (未設定 — 差引支給額に含まれていません)", amount: 0 }
      : { label: "住民税", amount: -residentTax },
  ];

  const warnings: string[] = [];
  if ((input.overtime_hours ?? 0) > 45) {
    warnings.push("月45時間超の時間外労働: 36協定特別条項の確認が必要");
  }
  if ((input.overtime_hours ?? 0) > 80) {
    warnings.push("月80時間超: 過労死ライン (脳・心臓疾患の労災認定基準)");
  }
  if (residentTax === null) {
    warnings.push(
      "住民税額が未設定です。市区町村から届く特別徴収税額の決定通知書の月額を入力してください" +
      "(住民税は前年所得を基に市区町村が個人別に決定するため、システムでは計算できません)。" +
      "この給与明細の差引支給額には住民税が含まれておらず、実際の手取りより多い額になっています。",
    );
  }
  // 健康保険料率が概算のときは、健康保険料が実額でない旨を明細の警告に必ず出す。
  warnings.push(...si.health_rate_notes);

  // 適用年度表示 (T-250): 給与明細画面に「令和N年度適用」を出すための値。
  // マスタが古い年度のままの場合は warnings に日本語の注意喚起を積む。
  const fy = getAppliedFiscalYear();
  warnings.push(...fy.warnings_ja);
  if (payYear.note_ja) warnings.push(payYear.note_ja);

  return {
    gross,
    deductions,
    net: gross - deductions.total,
    breakdown,
    warnings,
    applied_fiscal_year_ja: fy.display_ja,
    resident_tax_included: residentTax !== null,
    health_rate_is_estimate: si.health_rate_is_estimate,
    ...(si.health_rate_source_ja ? { health_rate_source_ja: si.health_rate_source_ja } : {}),
  };
}

/**
 * 給与計算で使う源泉徴収税額表の年分を決める。
 *  - pay_date (支払日) があればその年 (正)
 *  - 無ければ year_month の年で代用し、支払日で決まる旨の注意を返す
 *  - どちらも無ければ null (従来どおり令和8年分の表 — 後方互換)
 */
function resolveWithholdingPayYear(input: PayrollInput): { year: number | null; note_ja: string | null } {
  if (typeof input.pay_date === "string" && input.pay_date) {
    const m = /^(\d{4})-\d{2}-\d{2}$/.exec(input.pay_date);
    if (!m) throw new Error(`支払日は YYYY-MM-DD の形で指定してください (受け取った値: ${JSON.stringify(input.pay_date)})。`);
    return { year: Number(m[1]), note_ja: null };
  }
  const ym = typeof input.year_month === "string" ? /^(\d{4})-\d{2}$/.exec(input.year_month) : null;
  if (ym) {
    return {
      year: Number(ym[1]),
      note_ja:
        `源泉徴収税額表の年分を給与の年月 (${input.year_month}) から決めています。年分は給与の支払日で決まるため、` +
        `支払日 (pay_date) を入れてください (例: 12月分の給与を翌年1月に支払う場合は翌年分の表になります)。`,
    };
  }
  return { year: null, note_ja: null };
}

// 算定基礎届 (4-6月平均で標準報酬月額を改定)
// ★健康保険と厚生年金では等級表が異なるため、同じ平均額でも標準報酬月額が別になる。
//   standard_remuneration は後方互換のため健康保険の値を返す。
export function calcSantei(months: { april: number; may: number; june: number }): {
  average: number;
  standard_remuneration: number;
  standard_remuneration_health: number;
  standard_remuneration_pension: number;
} {
  const avg = (months.april + months.may + months.june) / 3;
  const health = calcStandardRemuneration(avg);
  return {
    average: Math.round(avg),
    standard_remuneration: health,
    standard_remuneration_health: health,
    standard_remuneration_pension: calcPensionStandardRemuneration(avg),
  };
}

export interface BonusInsuranceOptions {
  /**
   * 当該年度 (4月1日〜翌年3月31日) において、この賞与より前に決定済みの標準賞与額の累計。
   * 健康保険・介護保険の年度累計上限 573万円の判定に使う。省略時は 0 とみなす。
   */
  fiscal_ytd_standard_bonus?: number;
  /**
   * 同じ月に既に支給済みの標準賞与額。厚生年金の「1か月あたり150万円」は
   * 同月内の複数回支給を合算して判定するため、2回目以降はここに前回分を渡す。
   */
  same_month_standard_bonus?: number;
  /**
   * 賞与を支給した月 (保険料の対象月・YYYY-MM)。指定すると子ども・子育て支援金は令和8年4月分から、
   * 料率を取り込んでいない月は計算を止める (月次の calcSocialInsurance と同じ扱い)。
   */
  insurance_month?: string;
  /**
   * true にすると、健康保険料率 (Employee.health_insurance_rate) が未設定のときに
   * 全国平均の概算へフォールバックせず例外を投げる (fail-closed)。省略時は false (概算+注記)。
   */
  require_health_insurance_rate?: boolean;
}

export interface BonusInsuranceResult {
  health: number;
  pension: number;
  long_term_care: number;
  /**
   * 賞与に係る子ども・子育て支援金 (被保険者負担分)。
   * 上限は健康保険・介護保険と同じ【年度累計573万円】であり、厚生年金の月間150万円ではない。
   */
  child_care_support: number;
  employment: number;
  /** 厚生年金の保険料計算に用いた標準賞与額 (1か月150万円で頭打ち) */
  standard_bonus_pension: number;
  /** 健康保険・介護保険の保険料計算に用いた標準賞与額 (年度累計573万円で頭打ち) */
  standard_bonus_health: number;
  /** 上限で切られたか・健康保険料率が概算か等の日本語注記 */
  notes: string[];
  /** 健康保険料率が全国平均の概算 (支部別の実料率ではない) かどうか */
  health_rate_is_estimate: boolean;
}

/**
 * 賞与支払届に基づく賞与の社会保険料 (被保険者負担分) を算出する。
 *
 * 【出典 — 一次情報】
 *   - 標準賞与額は賞与額から1,000円未満の端数を切り捨てた額
 *   - 厚生年金保険: 支給1回 (同じ月に2回以上支給されたときは合算) につき 150万円が上限
 *   - 健康保険・介護保険: 年度 (毎年4月1日〜翌年3月31日) の累計額 573万円が上限
 *   全国健康保険協会 保険料額表 備考「賞与に係る保険料額」
 *   https://www.kyoukaikenpo.or.jp/assets/R8_13tokyo.pdf
 *   日本年金機構「年間の標準賞与額の累計額が573万円を超えたとき」
 *   https://www.nenkin.go.jp/shinsei/kounen/tekiyo/shoyo/20120314-01.html
 *
 * ★旧実装は健保・厚年ともに一律 150万円/回 を上限としていたため、
 *   健康保険料が過少 (年度累計573万円まで対象なのに150万円で打ち切っていた) になっていた。
 */
export function calcBonusInsurance(
  employee: Employee,
  bonus: number,
  opts: BonusInsuranceOptions = {},
): BonusInsuranceResult {
  const C = STANDARD_BONUS_CAPS;
  const notes: string[] = [];
  // 標準賞与額: 1,000円未満切り捨て
  const standardBonus = Math.max(0, Math.floor(bonus / C.rounding_unit_jpy) * C.rounding_unit_jpy);

  // --- 厚生年金: 同月内合算で 1か月あたり 150万円が上限 ---
  const sameMonthBefore = Math.max(0, opts.same_month_standard_bonus ?? 0);
  const pensionRoom = Math.max(0, C.pension_per_month_jpy - sameMonthBefore);
  const standardBonusPension = Math.min(standardBonus, pensionRoom);
  if (standardBonusPension < standardBonus) {
    notes.push(
      `厚生年金保険の標準賞与額は1か月あたり150万円が上限のため、` +
      `${standardBonus.toLocaleString('ja-JP')}円のうち ${standardBonusPension.toLocaleString('ja-JP')}円 を対象としました。`,
    );
  }

  // --- 健康保険・介護保険: 年度累計 573万円が上限 ---
  const ytdBefore = Math.max(0, opts.fiscal_ytd_standard_bonus ?? 0);
  const healthRoom = Math.max(0, C.health_fiscal_year_jpy - ytdBefore);
  const standardBonusHealth = Math.min(standardBonus, healthRoom);
  if (standardBonusHealth < standardBonus) {
    notes.push(
      `健康保険・介護保険の標準賞与額は年度 (4月1日〜翌年3月31日) の累計573万円が上限のため、` +
      `${standardBonus.toLocaleString('ja-JP')}円のうち ${standardBonusHealth.toLocaleString('ja-JP')}円 を対象としました。`,
    );
  }

  const ltcTarget = isLongTermCareTarget(employee.birth_date);
  const empRate = employmentInsuranceEmployeeRate(employee.employment_insurance_business_type);
  // 賞与の健康保険料も月次と同じ支部別料率で計算する。未設定なら概算 + 注記 (黙って概算を使わない)。
  const healthRate = resolveHealthEmployeeRate(employee, {
    strict: opts.require_health_insurance_rate === true,
    insurance_month: opts.insurance_month,
  });
  notes.push(...healthRate.notes);
  if (healthRate.source_ja) notes.push(`健康保険料率: ${healthRate.source_ja}`);
  // 賞与を支給した月が指定されたときだけ料率の適用期間を確かめる (支援金は令和8年4月分から)。
  const bonusCcsApplies = assertInsuranceMonthSupported(opts.insurance_month);
  if (!bonusCcsApplies) notes.push("令和8年3月分以前の賞与のため、子ども・子育て支援金はかかりません (令和8年4月分から)。");
  const bonusResult: BonusInsuranceResult = {
    health: healthRate.rate_bp_total !== undefined
      ? roundEmployeeShare((standardBonusHealth * healthRate.rate_bp_total) / 20_000)
      : roundEmployeeShare(standardBonusHealth * healthRate.rate),
    pension: roundEmployeeShare(standardBonusPension * RATES.PENSION_EMPLOYEE),
    long_term_care: ltcTarget ? roundEmployeeShare(standardBonusHealth * RATES.LONG_TERM_CARE_EMPLOYEE) : 0,
    // 子ども・子育て支援金の標準賞与額の上限は健康保険・介護保険と同じ【年度累計573万円】。
    // 出典: 保険料額表 備考「標準賞与額の上限は、健康保険、介護保険及び子ども・子育て支援金は
    //       年間573万円(毎年4月1日から翌年3月31日までの累計額。)となり、
    //       厚生年金保険と子ども・子育て拠出金は月間150万円となります。」
    child_care_support: roundEmployeeShare(standardBonusHealth * RATES.CHILD_CARE_SUPPORT_EMPLOYEE),
    // 雇用保険は標準賞与額ではなく実際の賞与額 (端数処理・上限なし) に料率を乗じる
    employment: roundEmployeeShare(bonus * empRate),
    standard_bonus_pension: standardBonusPension,
    standard_bonus_health: standardBonusHealth,
    notes,
    health_rate_is_estimate: healthRate.is_estimate,
  };
  if (!bonusCcsApplies) bonusResult.child_care_support = 0;
  return bonusResult;
}

// 36協定 上限チェック (一般則: 月45h/年360h、特別条項: 月100h未満/2-6月平均80h/年720h)
export interface OvertimeRecord {
  year_month: string; // YYYY-MM
  hours: number;
}
export interface OvertimeViolation {
  rule: string;
  detail: string;
  severity: "warning" | "violation";
}
export function checkOvertimeLimits(
  records: OvertimeRecord[],
  hasSpecialClause: boolean = false,
): OvertimeViolation[] {
  const violations: OvertimeViolation[] = [];
  const monthlyLimit = 45;
  const annualLimit = hasSpecialClause ? 720 : 360;
  const specialMonthlyHardLimit = 100; // 特別条項でも100h未満
  const specialAvgLimit = 80; // 2-6月平均

  for (const r of records) {
    if (!hasSpecialClause && r.hours > monthlyLimit) {
      violations.push({
        rule: "一般則 月45時間",
        detail: `${r.year_month}: ${r.hours}h (上限 ${monthlyLimit}h)`,
        severity: "violation",
      });
    }
    if (hasSpecialClause && r.hours >= specialMonthlyHardLimit) {
      violations.push({
        rule: "特別条項 月100時間未満",
        detail: `${r.year_month}: ${r.hours}h`,
        severity: "violation",
      });
    }
  }

  const annual = records.reduce((a, b) => a + b.hours, 0);
  if (annual > annualLimit) {
    violations.push({
      rule: hasSpecialClause ? "特別条項 年720時間" : "一般則 年360時間",
      detail: `年合計 ${annual}h (上限 ${annualLimit}h)`,
      severity: "violation",
    });
  }

  if (hasSpecialClause && records.length >= 2) {
    for (let i = 1; i < records.length; i++) {
      const window = records.slice(Math.max(0, i - 5), i + 1);
      const avg = window.reduce((a, b) => a + b.hours, 0) / window.length;
      if (avg > specialAvgLimit) {
        violations.push({
          rule: "特別条項 2-6月平均80時間",
          detail: `${records[i].year_month} 時点 平均 ${avg.toFixed(1)}h`,
          severity: "warning",
        });
        break;
      }
    }
  }
  return violations;
}

// 有給休暇 5日付与義務 (2019年4月施行)
export interface LeaveRecord {
  granted_date: string;
  granted_days: number;
  used_days: number;
}
export function checkAnnualLeaveCompliance(
  employee: Employee,
  leave: LeaveRecord,
  asOf: Date = new Date(),
): { compliant: boolean; remaining_required: number; deadline: string } {
  // 2026-10-04 是正 (T12): 年5日は「基準日から一年以内の期間」に与える (労基法39条7項)。
  //   期限は基準日の1年後の応当日の前日 (民法143条2項。応当日が無い月はその月の末日)。旧版は応当日 (1日遅い) を期限にしていた。
  //   日付は YYYY-MM-DD の暦で比べる (時刻・時差に左右されない)。期限の日は終日、期限内として扱う。
  const deadline = calcFiveDayObligationDeadline(String(leave.granted_date).slice(0, 10));
  const asOfYmd = `${asOf.getFullYear()}-${String(asOf.getMonth() + 1).padStart(2, '0')}-${String(asOf.getDate()).padStart(2, '0')}`;
  const required = leave.granted_days >= 10 ? 5 : 0;
  const remaining = Math.max(0, required - leave.used_days);
  return {
    compliant: remaining === 0 || asOfYmd <= deadline,
    remaining_required: remaining,
    deadline,
  };
}

// 育児介護休業: 取得可能期間と賃金支給判定
export function eligibleForChildcareLeave(employee: Employee, child_birth_date: string): {
  eligible: boolean;
  reason: string;
} {
  const child = new Date(child_birth_date);
  const oneYearLater = new Date(child);
  oneYearLater.setFullYear(oneYearLater.getFullYear() + 1);
  const now = new Date();
  if (now > oneYearLater) {
    return { eligible: false, reason: "原則 子が1歳に達するまで (延長事由がない場合)" };
  }
  const tenure = (now.getTime() - new Date(employee.hire_date).getTime()) / (365 * 24 * 60 * 60 * 1000);
  if (tenure < 1) {
    return { eligible: false, reason: "労使協定で除外可能: 入社1年未満" };
  }
  return { eligible: true, reason: "育児・介護休業法 5条 (子の養育のための休業)" };
}
