// @ts-check
/**
 * 不動産業 DNA (Phase 18)
 *
 * Claude Code がカバーしない日本の不動産業を完全カバー。
 *
 *  - 宅地建物取引業法 (宅建業法)
 *  - 重要事項説明書 (35条書面) - 21 必須記載項目
 *  - 契約書 (37条書面)
 *  - 媒介契約 (一般 / 専任 / 専属専任) と業務報告義務
 *  - レインズ (REINS - 指定流通機構) 登録義務日数
 *  - 報酬規程 (報酬告示) - 売買仲介 5%/4%+2万/3%+6万 / 賃貸 1ヶ月分上限
 *  - 物件種別と用途
 *  - 重要事項説明 IT重説 (オンライン化)
 *  - 心理的瑕疵 / 物理的瑕疵 / 法的瑕疵
 *  - インスペクション (建物状況調査) - 媒介契約時の説明義務
 *
 * 出典 (一次情報):
 *   - 宅地建物取引業法 https://laws.e-gov.go.jp/law/327AC1000000176
 *   - 昭和45年建設省告示第1552号 (報酬告示)
 *     最終改正 令和6年国土交通省告示第949号 / 令和6年7月1日施行
 *   - 国土交通省「宅地建物取引業法の解釈・運用の考え方」改正 (令和6年7月1日施行)
 *     https://www.mlit.go.jp/tochi_fudousan_kensetsugyo/const/content/001750144.pdf
 *   - 重要事項の説明 (国交省) https://www.mlit.go.jp/totikensangyo/const/sosei_const_tk2_000061.html
 */

// =============================================================================
// 物件種別
// =============================================================================

export type PropertyKind =
  | 'land' // 土地
  | 'detached_house' // 戸建住宅
  | 'condominium' // 区分所有マンション
  | 'apartment_building' // 一棟アパート/マンション
  | 'office' // 事務所
  | 'retail_shop' // 店舗
  | 'warehouse' // 倉庫
  | 'factory' // 工場
  | 'parking_lot'; // 駐車場

export type TransactionType =
  | 'sale' // 売買
  | 'lease_residential' // 居住用賃貸
  | 'lease_commercial'; // 事業用賃貸

// =============================================================================
// 媒介契約
// =============================================================================

export type MediationContractKind =
  | 'general' // 一般媒介契約: 他社にも依頼可、レインズ登録任意、業務報告任意
  | 'exclusive' // 専任媒介契約: 他社禁止 (自己発見可), レインズ7日以内, 報告2週に1回以上
  | 'exclusive_right_to_sell'; // 専属専任媒介: 他社禁止 (自己発見も禁止), レインズ5日以内, 報告1週に1回以上

export interface MediationContract {
  kind: MediationContractKind;
  /** 契約日 */
  contracted_at: string;
  /** 有効期限 (専任系は 3 ヶ月以内) */
  expires_at: string;
  /** 報酬 (上限) */
  fee_jpy: number;
  /** レインズ登録予定日 */
  reins_registration_due?: string;
  /** 報告義務 */
  report_interval_days?: number;
}

/**
 * 媒介契約の業務義務を取得
 */
export function getMediationObligations(kind: MediationContractKind): {
  reins_within_days: number | null;
  report_interval_days: number | null;
  contract_max_months: number | null;
} {
  switch (kind) {
    case 'general':
      return { reins_within_days: null, report_interval_days: null, contract_max_months: null };
    case 'exclusive':
      return { reins_within_days: 7, report_interval_days: 14, contract_max_months: 3 };
    case 'exclusive_right_to_sell':
      return { reins_within_days: 5, report_interval_days: 7, contract_max_months: 3 };
  }
}

/**
 * 媒介契約有効期限の妥当性 (専任系は契約日から 3 ヶ月以内)
 */
export function isValidMediationExpiry(c: MediationContract): boolean {
  const obl = getMediationObligations(c.kind);
  if (obl.contract_max_months === null) return true;
  const start = new Date(c.contracted_at);
  const limit = new Date(start);
  limit.setMonth(limit.getMonth() + obl.contract_max_months);
  return new Date(c.expires_at) <= limit;
}

// =============================================================================
// 報酬規程 (宅地建物取引業法 第46条 / 報酬告示)
//
// 【出典 — 一次情報】
//   - 宅地建物取引業法 第46条 (報酬)
//     https://laws.e-gov.go.jp/law/327AC1000000176
//   - 昭和45年10月23日建設省告示第1552号
//     「宅地建物取引業者が宅地又は建物の売買等に関して受けることができる報酬の額」
//     最終改正: 令和6年6月21日 国土交通省告示第949号 (令和6年7月1日施行)
//   - 国土交通省「宅地建物取引業法の解釈・運用の考え方」改正 (令和6年7月1日施行)
//     https://www.mlit.go.jp/tochi_fudousan_kensetsugyo/const/content/001750144.pdf
//   - 東京都住宅政策本部「宅地建物取引業法等の改正について (空き家対策推進のための報酬告示改正等)」
//     https://www.juutakuseisaku.metro.tokyo.lg.jp/juutaku_seisaku/pdf/tokyo_douga_2410_04.pdf
// =============================================================================

/** 報酬告示 第二 (売買・交換の媒介) の速算式区分。取引価額 (税抜) の境界。 */
export const SALES_COMMISSION_BRACKETS = {
  /** 200万円以下: 取引価額の 5% (税込 5.5%) */
  tier1_upto_jpy: 2_000_000,
  tier1_rate: 0.05,
  /** 200万円超 400万円以下: 取引価額の 4% + 2万円 (税込 4.4%) */
  tier2_upto_jpy: 4_000_000,
  tier2_rate: 0.04,
  tier2_add_jpy: 20_000,
  /** 400万円超: 取引価額の 3% + 6万円 (税込 3.3%) */
  tier3_rate: 0.03,
  tier3_add_jpy: 60_000,
  /** 低廉な空家等の特例 (R6.7.1施行): 価格 800万円以下の宅地建物が対象。使用の状態は不問。 */
  low_value_special_price_ceiling_jpy: 8_000_000,
  /** 特例の報酬上限 (税抜)。税込では 30万円 × 1.1 = 33万円。 */
  low_value_special_commission_jpy: 300_000,
  /** 消費税率 (10%) */
  consumption_tax_rate: 0.1,
} as const;

export interface SalesCommissionOptions {
  /**
   * 低廉な空家等の特例について、媒介・代理契約の締結に際し「あらかじめ」
   * 依頼者に報酬額を説明し、**合意を得ている**か。
   *
   * ★宅地建物取引業法第46条第1項関係。国交省「解釈・運用の考え方」は
   *   「媒介・代理契約の締結に際し、あらかじめ、特例で定める上限の範囲内で、
   *     報酬額について依頼者に説明し、合意する必要があることに特に留意」
   *   と明記している。合意がないまま特例額を請求すると報酬額制限違反となるため、
   *   既定値は false (= 原則計算) とし、合意があるときだけ引き上げる。
   */
  low_value_special_agreed?: boolean;
}

export interface SalesCommissionResult {
  /** 報酬額の上限 (税抜) */
  commission: number;
  /** 消費税額 */
  tax: number;
  /** 税込の報酬額上限 */
  total: number;
  /** 適用した区分 */
  rule:
    | 'no_transaction'
    | 'standard_5pct'
    | 'standard_4pct'
    | 'standard_3pct'
    | 'r6_low_value_30man_special';
  /** 原則計算 (特例を使わない場合) の報酬額 (税抜) */
  standard_commission: number;
  /** 低廉な空家等の特例を使える価格帯か (800万円以下) */
  low_value_special_applicable: boolean;
  /** 実際に特例を適用したか (適用余地があり、かつ依頼者との事前合意がある場合のみ true) */
  low_value_special_applied: boolean;
  /** 画面・書面にそのまま出せる日本語の注意書き */
  notes: string[];
}

/**
 * 売買・交換の媒介における報酬額の上限を算出する (依頼者の一方から受領できる額)。
 *
 * 【原則 — 報酬告示 第二】(取引価額は税抜)
 *   - 200万円以下          : 取引価額 × 5%
 *   - 200万円超 400万円以下 : 取引価額 × 4% + 2万円
 *   - 400万円超            : 取引価額 × 3% + 6万円
 *
 * 【低廉な空家等の媒介の特例 — 令和6年7月1日施行】
 *   価格 800万円以下の宅地建物については、当該媒介に要する費用を勘案して、
 *   原則による上限を超えて報酬を受領できる (30万円の1.1倍 = 税込33万円 が上限)。
 *   ★要件: 媒介・代理契約の締結に際し、あらかじめ依頼者に説明し合意すること。
 *
 * ★注意: 代理の場合は媒介の2倍が上限 (報酬告示 第三)。本関数は媒介を返す。
 * ★注意: 特例の上限はあくまで「上限」であり、実際に請求できるのは
 *         当該媒介に要する費用を勘案した額。上限を機械的に請求してよい意味ではない。
 */
export function calcSalesCommissionMax(
  price_jpy: number,
  opts: SalesCommissionOptions = {},
): SalesCommissionResult {
  const B = SALES_COMMISSION_BRACKETS;
  if (price_jpy <= 0) {
    return {
      commission: 0, tax: 0, total: 0, rule: 'no_transaction',
      standard_commission: 0,
      low_value_special_applicable: false,
      low_value_special_applied: false,
      notes: ['取引価額が0円以下のため報酬は発生しません。'],
    };
  }

  // --- 原則計算 (速算式) ---
  // ★分岐は必ず「小さい額から」判定する。旧実装は 800万円以下を先に判定していたため
  //   200万円以下 5% / 400万円以下 4%+2万 の分岐が到達不能になり、
  //   100万円の物件に 30万円 (法定 5万円の6倍) を返していた。
  let standard: number;
  let rule: SalesCommissionResult['rule'];
  if (price_jpy <= B.tier1_upto_jpy) {
    standard = price_jpy * B.tier1_rate;
    rule = 'standard_5pct';
  } else if (price_jpy <= B.tier2_upto_jpy) {
    standard = price_jpy * B.tier2_rate + B.tier2_add_jpy;
    rule = 'standard_4pct';
  } else {
    standard = price_jpy * B.tier3_rate + B.tier3_add_jpy;
    rule = 'standard_3pct';
  }
  standard = Math.floor(standard);

  // --- 低廉な空家等の特例 ---
  const applicable = price_jpy <= B.low_value_special_price_ceiling_jpy;
  const agreed = opts.low_value_special_agreed === true;
  // 特例は原則の上限を「超えて」受領できる制度。原則額のほうが大きい場合は引き上げが起きない。
  const uplift = applicable && agreed && B.low_value_special_commission_jpy > standard;

  let commission = standard;
  const notes: string[] = [];
  if (uplift) {
    commission = B.low_value_special_commission_jpy;
    rule = 'r6_low_value_30man_special';
    notes.push(
      '低廉な空家等の媒介の特例 (令和6年7月1日施行) を適用しています。' +
      '上限は30万円 (税込33万円) です。実際の請求額は当該媒介に要する費用を勘案して決めてください。',
    );
  } else if (applicable && !agreed) {
    notes.push(
      '価格800万円以下のため低廉な空家等の特例を使える余地がありますが、' +
      '依頼者との事前の説明・合意が確認できないため原則の上限で計算しています ' +
      '(宅地建物取引業法第46条第1項関係)。',
    );
  }
  notes.push('この額は依頼者の一方から受領できる上限です。代理の場合は媒介の2倍が上限となります (報酬告示 第三)。');

  const tax = Math.floor(commission * B.consumption_tax_rate);
  return {
    commission,
    tax,
    total: commission + tax,
    rule,
    standard_commission: standard,
    low_value_special_applicable: applicable,
    low_value_special_applied: uplift,
    notes,
  };
}

/**
 * 賃貸借の媒介における報酬額の上限 (報酬告示 第四)
 *
 * 【出典 — 一次情報】報酬告示 第四 / 国交省「解釈・運用の考え方」(R6.7.1施行)
 *  - 原則: 依頼者の双方から受けられる報酬の額の合計額は、1ヶ月分の借賃に 1.1 を乗じた金額以内
 *  - 居住用建物の場合、依頼者の一方からは 1ヶ月分の借賃に 0.55 を乗じた金額以内
 *    (媒介の依頼を受けるに当たって依頼者の承諾を得ている場合を除く)
 *
 * ★承諾は「媒介の依頼を受けるに当たって」得ている必要がある (事後承諾は不可)。
 * ★長期の空家等の媒介の特例 (R6.7.1施行): 現に長期間使用されておらず、又は将来にわたり
 *   使用の見込みがない宅地建物については、貸主である依頼者から 1ヶ月分の 2.2 倍を上限として
 *   受領できる。本関数は原則のみを返す (特例は個別要件の確認が必要なため)。
 */
export function calcLeaseCommissionMax(
  monthly_rent: number,
  txnType: 'lease_residential' | 'lease_commercial',
  client_consent: boolean,
): { commission: number; tax: number; total: number; rule: string } {
  let commission: number;
  let rule: string;
  if (txnType === 'lease_residential') {
    if (client_consent) {
      commission = monthly_rent;
      rule = 'residential_1month_with_consent';
    } else {
      commission = monthly_rent * 0.5;
      rule = 'residential_half_month';
    }
  } else {
    commission = monthly_rent;
    rule = 'commercial_1month';
  }
  const tax = Math.floor(commission * 0.1);
  return { commission: Math.floor(commission), tax, total: Math.floor(commission) + tax, rule };
}

// =============================================================================
// 重要事項説明書 (35条書面) - 21 必須記載項目
// =============================================================================

export interface ImportantMattersExplanation {
  property_id: string;
  /** 取引の対象 */
  property_kind: PropertyKind;
  txn_type: TransactionType;
  /** 取引主任者 */
  takken_holder: { name: string; license_no: string };
  /** 説明の方法 */
  explanation_method: 'in_person' | 'it_juusetsu'; // IT重説可
  /** 説明実施日時 */
  explained_at: string;
  /** 21項目チェック */
  items: ImportantMatterItem[];
  /** 顧客署名/記名押印 */
  customer_signed: boolean;
}

/**
 * 35 条書面 必須記載 21 項目 (居住用売買の場合の代表例)
 */
export const REQUIRED_35_ITEMS: { id: number; label: string; required_for: TransactionType[] }[] = [
  { id: 1, label: '登記簿に記載された事項 (所有権/抵当権/賃借権)', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 2, label: '都市計画法・建築基準法等の制限の概要', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 3, label: '私道に関する負担', required_for: ['sale'] },
  { id: 4, label: '飲用水・電気・ガスの供給施設', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 5, label: '宅地造成又は建築の工事完了時の形状・構造', required_for: ['sale'] },
  { id: 6, label: '区分所有建物の場合の規約等', required_for: ['sale'] },
  { id: 7, label: '代金以外に授受される金銭', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 8, label: '契約解除に関する事項', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 9, label: '損害賠償額の予定・違約金に関する事項', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 10, label: '手付金等の保全措置の概要 (売主が宅建業者の場合)', required_for: ['sale'] },
  { id: 11, label: '支払金等の保全措置 (50万円以上)', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 12, label: '金銭の貸借のあっせん (ローン特約)', required_for: ['sale'] },
  { id: 13, label: '契約不適合責任 (担保責任) の履行に関する措置 (保証保険契約の締結等。新築住宅は住宅瑕疵担保履行法の資力確保)', required_for: ['sale'] },
  { id: 14, label: '割賦販売の場合の現金販売価格', required_for: ['sale'] },
  { id: 15, label: '建物の構造耐力上主要部分等の状況 (インスペクション結果)', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 16, label: '台帳記載の事項 (建築物の検査済証)', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 17, label: '津波災害警戒区域内か', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 18, label: '土砂災害警戒区域内か', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 19, label: '石綿 (アスベスト) 使用の有無', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 20, label: '耐震診断の内容 (S56年5月以前建築の場合)', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 21, label: '住宅性能評価を受けた新築住宅であるか', required_for: ['sale'] },
  /**
   * 水防法の水害ハザードマップ (洪水・雨水出水・高潮) における対象物件の位置。売買・貸借とも必須 (宅建業法35条・施行規則16条の4の3。2020-08-28 施行)。
   *   ★施行規則の号番号は e-Gov で要一次確認 (2026-10-01 の作業時は保守中で開けなかった)。
   */
  { id: 22, label: '水防法に基づく水害ハザードマップにおける対象物件の所在地 (洪水・雨水出水・高潮)', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
];

export interface ImportantMatterItem {
  id: number;
  explained: boolean;
  remarks?: string;
}

/**
 * 35条書面の不備チェック (旧い簡易版。取引種別しか見ないため、宅地/建物・区分所有・既存建物の別と
 * 2026-04-01 の追加項目・宅地建物取引士の記名を判定できない。交付の可否は canIssue35Document を使うこと)
 */
export function validate35Items(
  items: ImportantMatterItem[],
  txnType: TransactionType,
): { ok: boolean; missing: number[] } {
  const required = REQUIRED_35_ITEMS.filter((r) => r.required_for.includes(txnType)).map((r) => r.id);
  const explainedIds = new Set(items.filter((i) => i.explained).map((i) => i.id));
  const missing = required.filter((id) => !explainedIds.has(id));
  return { ok: missing.length === 0, missing };
}

// =============================================================================
// 心理的瑕疵 / 物理的瑕疵
// =============================================================================

export type DefectKind =
  | 'physical' // 物理的瑕疵 (雨漏り/シロアリ/傾き)
  | 'legal' // 法的瑕疵 (建ぺい率違反/接道不良)
  | 'environmental' // 環境瑕疵 (騒音/悪臭/嫌悪施設)
  | 'psychological'; // 心理的瑕疵 (殺人/自殺/孤独死)

export interface PropertyDefect {
  kind: DefectKind;
  description: string;
  /** 発覚日 */
  discovered_at: string;
  /** 説明義務の有無 (心理的瑕疵以外、及びガイドラインの対象外の事業用賃貸ではこの値を使う) */
  must_disclose: boolean;
  /** 人の死の種類: natural=自然死 / accidental_daily=日常生活の中での不慮の死 (転倒・誤嚥等) / other=それ以外。未指定は other として扱う (安全側) */
  death_kind?: 'natural' | 'accidental_daily' | 'other';
  /** 事案の発生日 (YYYY-MM-DD)。特殊清掃等が行われた自然死等は発覚日 (discovered_at) を起算に使う */
  occurred_at?: string;
  /** 特殊清掃・大規模リフォーム等が行われた */
  special_cleaning?: boolean;
  /** 事件性・周知性・社会に与えた影響等が特に高い事案 */
  high_social_impact?: boolean;
  /** 買主・借主から事案の有無を問われた (又は把握しておくべき特段の事情があると認識した) */
  asked_by_counterparty?: boolean;
  /** 発生場所: target=取引対象の不動産 / common_used=日常生活で通常使用する共用部分 / adjacent=隣接住戸 / common_unused=通常使用しない共用部分。未指定は target */
  location?: 'target' | 'common_used' | 'adjacent' | 'common_unused';
}

/** YYYY-MM-DD の n 年後の応当日 (2/29 起算でうるう年でない年は 2/28)。暦で数える */
function addYearsYmd(ymd: string, n: number): string {
  const [y, m, d] = ymd.slice(0, 10).split('-').map(Number);
  const ty = y + n;
  const leap = (ty % 4 === 0 && ty % 100 !== 0) || ty % 400 === 0;
  const dd = m === 2 && d === 29 && !leap ? 28 : d;
  return `${ty}-${String(m).padStart(2, '0')}-${String(dd).padStart(2, '0')}`;
}

/**
 * 人の死に関する告知の判定 (国土交通省「宅地建物取引業者による人の死の告知に関するガイドライン」令和3年10月)
 *   出典: https://www.mlit.go.jp/report/press/content/001426603.pdf
 *  (3) 買主・借主から問われた場合・把握しておくべき特段の事情がある場合 → 経過期間・死因に関わらず告げる
 *  (1)① 自然死・日常生活の中での不慮の死 → 売買・賃貸とも原則告げなくてよい (特殊清掃等が行われた場合を除く)
 *  (1)③ 隣接住戸・通常使用しない共用部分 → 原則告げなくてよい (事件性・周知性・社会的影響が特に高い事案を除く)
 *  (1)② 賃貸: ①以外の死 (又は特殊清掃等の行われた①の死) は発生 (特殊清掃等は発覚) から概ね3年経過後は原則告げなくてよい
 *       (事件性・周知性・社会的影響が特に高い事案を除く)
 *  (2) それ以外 (売買の①以外の死など) → 取引の相手方等の判断に重要な影響を及ぼすと考えられるので告げる
 *  ★「概ね3年」は3年目の応当日で区切る (応当日の前日までは告げる)。概ねの幅と「特に高い」の評価は宅建業者が個別に判断する
 *    (要確認: 宅地建物取引士・弁護士)。ガイドラインは居住用不動産が対象のため、事業用賃貸は must_disclose を返す。
 * @param asOf 判定の基準日 (YYYY-MM-DD)。省略時は今日
 */
export function shouldDiscloseSinriKashi(d: PropertyDefect, txnType: TransactionType, asOf?: string): boolean {
  if (d.kind !== 'psychological') return d.must_disclose;
  if (txnType === 'lease_commercial') return d.must_disclose;
  if (d.asked_by_counterparty) return true;
  const kind = d.death_kind ?? 'other';
  const ordinary = (kind === 'natural' || kind === 'accidental_daily') && !d.special_cleaning;
  if (ordinary) return false;
  const loc = d.location ?? 'target';
  if (loc === 'adjacent' || loc === 'common_unused') return d.high_social_impact === true;
  if (txnType === 'sale') return true;
  // 居住用賃貸: 概ね3年
  if (d.high_social_impact) return true;
  const start = kind === 'other' ? d.occurred_at ?? d.discovered_at : d.discovered_at;
  const today = asOf ?? new Date().toISOString().slice(0, 10);
  return today < addYearsYmd(start, 3);
}

// =============================================================================
// インスペクション (既存住宅状況調査)
// =============================================================================

export interface BuildingInspectionReport {
  property_id: string;
  /** 既存住宅状況調査技術者 (建築士+講習修了) */
  inspector_name: string;
  inspector_license_no: string;
  inspected_at: string;
  /** 主要構造部 */
  structure_findings: string;
  /** 雨水浸入防止部分 */
  waterproof_findings: string;
  /** 給排水管 */
  plumbing_findings: string;
  /** 過去 5 年以内の有効性 */
  valid_until: string;
}

// =============================================================================
// レインズ (指定流通機構) 登録
// =============================================================================

export interface ReinsRegistration {
  property_id: string;
  contract_id: string;
  registered_at: string;
  /** REINS 登録番号 */
  reins_no: string;
  /** 社内の進行状態 (旧来の区分。法定の「取引状況」とは別物) */
  status: 'registered' | 'business_negotiating' | 'sold' | 'withdrawn';
  /**
   * レインズに登録する「取引の申込みの受付に関する状況」(施行規則15条の11第2号・2025-01-01 施行)。
   *   'open' = 公開中 / 'written_purchase_application' = 書面による購入申込みあり /
   *   'suspended_by_seller' = 売主都合で一時紹介停止中 (国交省 リーフレット 2024-12-24 の3区分)。
   */
  transaction_status?: ReinsTransactionStatus;
}

/** レインズの取引状況 (ステータス) の3区分。出典: 国土交通省 不動産業課「レインズの機能強化について」2024-12-24 */
export type ReinsTransactionStatus = 'open' | 'written_purchase_application' | 'suspended_by_seller';
export const REINS_TRANSACTION_STATUS_LABELS: Record<ReinsTransactionStatus, string> = {
  open: '公開中',
  written_purchase_application: '書面による購入申込みあり',
  suspended_by_seller: '売主都合で一時紹介停止中',
};
/** 取引状況の登録が義務になった日 (宅地建物取引業法施行規則15条の11第2号。令和6年国交省令第70号附則ただし書) */
export const REINS_STATUS_DUTY_EFFECTIVE_DATE = '2025-01-01';

/**
 * 媒介契約成立日からレインズ登録までの日数を判定 (宅建業法34条の2第5項・施行規則15条の10)
 *   専任媒介は契約の【翌日から】宅建業者の休業日を除いて7日以内、専属専任媒介は5日以内。
 *   休業日は closedDates (YYYY-MM-DD) と closedWeekdays (0=日〜6=土) で渡す。
 *   ★休業日を渡さないときは休業日なしとして数える (期限を長く見積もらない安全側)。旧版の「+2日」の近似は使わない。
 */
export function isReinsRegistrationOnTime(
  contract: MediationContract,
  registration: ReinsRegistration,
  opts: { closedDates?: string[]; closedWeekdays?: number[] } = {},
): boolean {
  const due = reinsRegistrationDeadline(contract.kind, contract.contracted_at, opts);
  if (due === null) return true; // 一般媒介は登録義務なし
  return String(registration.registered_at).slice(0, 10) <= due;
}

/**
 * レインズ (指定流通機構) への登録期限日を返す (宅建業法34条の2第5項・施行規則15条の10)。
 *   「専任媒介契約の締結の日から七日 (専属専任は五日)」「休業日数は算入しない」(15条の10第1項・第2項)。
 *   初日は算入しない (民法140条。契約は午前零時に始まらないため)。よって契約の翌日から休業日を除いて数え、
 *   7営業日目 (専属専任は5営業日目) が期限日。期限が休業日に当たることは定義上ない。
 *   ★休業日を渡さないときは休業日なしで数える (期限を長く見積もらない安全側)。
 * @returns 'YYYY-MM-DD'。一般媒介 (登録義務なし) は null。
 */
export function reinsRegistrationDeadline(
  kind: MediationContractKind,
  contractedAt: string,
  opts: { closedDates?: string[]; closedWeekdays?: number[] } = {},
): string | null {
  const obl = getMediationObligations(kind);
  if (obl.reins_within_days === null) return null;
  const ymd = (s: string) => String(s).slice(0, 10);
  const closed = new Set((opts.closedDates ?? []).map(ymd));
  const closedWd = new Set(opts.closedWeekdays ?? []);
  if (closedWd.size >= 7) throw new Error('すべての曜日が休業日になっているため、登録期限を数えられません');
  const [y, m, d] = ymd(contractedAt).split('-').map(Number);
  const cur = new Date(Date.UTC(y, m - 1, d));
  let businessDays = 0;
  for (let i = 0; i < 4000; i++) {
    cur.setUTCDate(cur.getUTCDate() + 1);
    const key = cur.toISOString().slice(0, 10);
    if (closed.has(key) || closedWd.has(cur.getUTCDay())) continue;
    businessDays++;
    if (businessDays === obl.reins_within_days) return key;
  }
  throw new Error('休業日が多すぎて登録期限を数えられません');
}

/** 日付 (YYYY-MM-DD) の差 (日数)。b - a */
function daysBetweenYmd(a: string, b: string): number {
  const p = (s: string) => { const [y, m, d] = String(s).slice(0, 10).split('-').map(Number); return Date.UTC(y, m - 1, d); };
  return Math.round((p(b) - p(a)) / 86400000);
}

export interface ReinsComplianceInput {
  kind: MediationContractKind;
  /** 専任媒介契約の締結日 */
  contracted_at: string;
  /** 判定の基準日 (YYYY-MM-DD) */
  as_of: string;
  closedDates?: string[];
  closedWeekdays?: number[];
  registration?: { registered_at: string; registration_no?: string; transaction_status?: ReinsTransactionStatus };
  /** 書面による購入申込み (受付日・取下げ日) */
  written_applications?: { received_at: string; withdrawn_at?: string }[];
  /** 売主から一時紹介停止の指示を受けた記録 */
  seller_suspension_instruction?: { instructed_at: string } | null;
  /** 登録物件の売買・交換の契約の成立 */
  sale_contract?: { concluded_at: string } | null;
  /** 指定流通機構への成約の通知 (施行規則15条の13: 登録番号・取引価格・契約成立年月日) */
  reins_notification?: { notified_at: string; registration_no?: string; price_jpy?: number; concluded_on?: string } | null;
  /** 依頼者への業務処理状況の報告日 */
  reports?: string[];
}

export interface ReinsViolation {
  code:
    | 'REINS_NOT_REGISTERED'
    | 'REINS_LATE'
    | 'STATUS_NOT_SET'
    | 'STATUS_OPEN_WITH_WRITTEN_APPLICATION'
    | 'SUSPENDED_WITHOUT_SELLER_INSTRUCTION'
    | 'CONTRACT_NOT_NOTIFIED'
    | 'NOTIFICATION_MISSING_FIELDS'
    | 'REPORT_INTERVAL_EXCEEDED';
  message: string;
  basis: string;
}

/**
 * 専任媒介・専属専任媒介のレインズ関係の義務を点検する。
 *   - 登録期限 (34条の2第5項・規則15条の10)
 *   - 取引状況の登録 (規則15条の11第2号・2025-01-01〜): 書面による購入申込みがあるのに「公開中」のままは虚偽の登録
 *   - 売主の指示が無いのに「売主都合で一時紹介停止中」
 *   - 成約の通知 (34条の2第7項・規則15条の13: 登録番号・取引価格・契約成立年月日)。「遅滞なく」は日数の定めが無いため、基準日に未通知なら指摘する
 *   - 業務処理状況の報告 (34条の2第9項: 専任は2週間に1回以上、専属専任は1週間に1回以上)。
 *     ★「2週間に1回以上」は、契約日 (または前回の報告日) から 14 日 (専属専任は 7 日) を超えて報告が空かないことと解して判定する (要確認: 宅地建物取引士)
 */
export function checkReinsCompliance(p: ReinsComplianceInput): { ok: boolean; violations: ReinsViolation[] } {
  const v: ReinsViolation[] = [];
  const obl = getMediationObligations(p.kind);
  if (obl.reins_within_days === null) return { ok: true, violations: [] };
  const ymd = (s: string) => String(s).slice(0, 10);
  const asOf = ymd(p.as_of);
  const due = reinsRegistrationDeadline(p.kind, p.contracted_at, p)!;
  if (!p.registration) {
    if (asOf > due) v.push({ code: 'REINS_NOT_REGISTERED', message: `登録期限 ${due} を過ぎても指定流通機構に登録されていません`, basis: '宅地建物取引業法34条の2第5項・施行規則15条の10' });
  } else {
    if (ymd(p.registration.registered_at) > due) v.push({ code: 'REINS_LATE', message: `登録日 ${ymd(p.registration.registered_at)} が登録期限 ${due} を過ぎています`, basis: '宅地建物取引業法34条の2第5項・施行規則15条の10' });
    const activeWritten = (p.written_applications ?? []).filter((a) => ymd(a.received_at) <= asOf && !(a.withdrawn_at && ymd(a.withdrawn_at) <= asOf));
    const st = p.registration.transaction_status;
    if (asOf >= REINS_STATUS_DUTY_EFFECTIVE_DATE) {
      if (!st) v.push({ code: 'STATUS_NOT_SET', message: '取引状況 (公開中/書面による購入申込みあり/売主都合で一時紹介停止中) が登録されていません', basis: '宅地建物取引業法施行規則15条の11第2号' });
      if (st === 'open' && activeWritten.length > 0) v.push({ code: 'STATUS_OPEN_WITH_WRITTEN_APPLICATION', message: `書面による購入申込み (${activeWritten.map((a) => ymd(a.received_at)).join('・')} 受付) があるのに取引状況が「公開中」のままです。「書面による購入申込みあり」へ更新してください`, basis: '宅地建物取引業法施行規則15条の11第2号 (取引の申込みの受付に関する状況)' });
      if (st === 'suspended_by_seller' && !(p.seller_suspension_instruction && ymd(p.seller_suspension_instruction.instructed_at) <= asOf)) v.push({ code: 'SUSPENDED_WITHOUT_SELLER_INSTRUCTION', message: '売主からの一時紹介停止の指示の記録が無いのに「売主都合で一時紹介停止中」になっています', basis: '宅地建物取引業法施行規則15条の11第2号' });
    }
    if (p.sale_contract && ymd(p.sale_contract.concluded_at) <= asOf) {
      const n = p.reins_notification;
      if (!n) v.push({ code: 'CONTRACT_NOT_NOTIFIED', message: `売買契約が ${ymd(p.sale_contract.concluded_at)} に成立していますが、指定流通機構への成約の通知の記録がありません (遅滞なく通知)`, basis: '宅地建物取引業法34条の2第7項・施行規則15条の13' });
      else {
        const lack: string[] = [];
        if (!n.registration_no) lack.push('登録番号');
        if (!(typeof n.price_jpy === 'number' && n.price_jpy > 0)) lack.push('取引価格');
        if (!n.concluded_on) lack.push('契約の成立した年月日');
        if (lack.length) v.push({ code: 'NOTIFICATION_MISSING_FIELDS', message: `成約の通知に ${lack.join('・')} がありません`, basis: '宅地建物取引業法施行規則15条の13' });
      }
    }
  }
  // 業務処理状況の報告
  const limit = obl.report_interval_days!;
  const end = p.sale_contract && ymd(p.sale_contract.concluded_at) < asOf ? ymd(p.sale_contract.concluded_at) : asOf;
  const reps = (p.reports ?? []).map(ymd).filter((r) => r <= end).sort();
  let prev = ymd(p.contracted_at);
  for (const r of [...reps, end]) {
    if (daysBetweenYmd(prev, r) > limit) {
      v.push({ code: 'REPORT_INTERVAL_EXCEEDED', message: `${prev} から ${r} まで ${daysBetweenYmd(prev, r)} 日、業務処理状況の報告が空いています (${p.kind === 'exclusive' ? '2週間' : '1週間'}に1回以上)`, basis: '宅地建物取引業法34条の2第9項' });
      break;
    }
    prev = r;
  }
  return { ok: v.length === 0, violations: v };
}

// =============================================================================
// 重要事項説明 (35条) — 物件種別 × 取引種別の必須項目 (施行規則16条の2・16条の4の3 に基づく)
//
// 【出典 — 一次情報 (e-Gov 法令API v2 で 2026-10-03 取得)】
//   宅地建物取引業法 (327AC1000000176・2026-04-01 施行版) 35条1項・2項・4項・5項・8項、22条の2第3項
//   宅地建物取引業法施行規則 (332M50004000012・2026-04-01 施行版) 16条の2 (区分所有建物)・16条の2の3・16条の4の3
//     16条の4の3 柱書: 宅地の売買交換=1〜3の2号 / 建物の売買交換=1〜6号 / 宅地の貸借=1〜3の2号・8〜13号 / 建物の貸借=1〜5号・7〜12号
//     16条の2 柱書: 建物の貸借以外=1〜10号 / 建物の貸借=3号・8号
//     16条の2第9号 (管理者等がマンション管理業者である旨=管理業者管理者方式): 令和7年内閣府・国交省令第2号で追加・2026-04-01 施行
//   ★「〜があるときは、その内容」の項目も、書面では「該当なし」を含めて記載するのが実務のため、適用される取引では必須として扱う。
//   ★個別の物件の当てはめと説明は宅地建物取引士が行う (35条1項)。本部品は欠落の検出と交付の停止までを担う。
// =============================================================================

export type Disclosure35Object = 'land' | 'building';
/** 'sale' は売買・交換、'lease' は貸借 */
export type Disclosure35Deal = 'sale' | 'lease';

export interface Disclosure35Context {
  object: Disclosure35Object;
  deal: Disclosure35Deal;
  /** 区分所有建物 (区分所有法2条1項) か */
  condo?: boolean;
  /** 既存の建物か (35条1項6号の2) */
  existingBuilding?: boolean;
  /** 工事完了前か (35条1項5号) */
  underConstruction?: boolean;
  /** 宅建業者が自ら売主として手付金等を受領しようとするか (35条1項10号) */
  depositProtectionApplies?: boolean;
  /** 昭和56年6月1日以降に新築の工事に着手した建物か (規則16条の4の3第5号の除外)。不明は false (=耐震診断の項目を求める安全側) */
  builtOnOrAfter19810601?: boolean;
  /** 割賦販売か (35条2項) */
  installmentSale?: boolean;
  /** 説明・交付する日 (YYYY-MM-DD)。2026-04-01 以後は管理業者管理者方式の項目が加わる */
  explainedOn: string;
}

export interface Disclosure35Item { code: string; label: string; basis: string; applies: (c: Disclosure35Context) => boolean }

/** 管理業者管理者方式の項目 (規則16条の2第9号) の施行日 */
export const DISCLOSURE35_CONDO_MGMT_MANAGER_EFFECTIVE_DATE = '2026-04-01';

const isBldg = (c: Disclosure35Context) => c.object === 'building';
const isSale = (c: Disclosure35Context) => c.deal === 'sale';
const isLease = (c: Disclosure35Context) => c.deal === 'lease';
const isCondo = (c: Disclosure35Context) => c.object === 'building' && c.condo === true;

/** 35条書面の必須項目の表 (物件種別 × 取引種別で適用が決まる) */
export const DISCLOSURE35_ITEMS: Disclosure35Item[] = [
  { code: 'L1', label: '登記された権利の種類・内容、登記名義人', basis: '法35条1項1号', applies: () => true },
  { code: 'L2', label: '法令に基づく制限の概要', basis: '法35条1項2号', applies: () => true },
  { code: 'L3', label: '私道に関する負担', basis: '法35条1項3号 (建物の貸借以外)', applies: (c) => !(isBldg(c) && isLease(c)) },
  { code: 'L4', label: '飲用水・電気・ガスの供給・排水施設の整備状況', basis: '法35条1項4号', applies: () => true },
  { code: 'L5', label: '工事完了時の形状・構造', basis: '法35条1項5号 (工事完了前)', applies: (c) => c.underConstruction === true },
  { code: 'L6_2_I', label: '建物状況調査の実施の有無・結果の概要', basis: '法35条1項6号の2イ (既存の建物)', applies: (c) => isBldg(c) && c.existingBuilding === true },
  { code: 'L6_2_RO', label: '建物の建築・維持保全の状況に関する書類の保存状況', basis: '法35条1項6号の2ロ・規則16条の2の3 (既存住宅の売買・交換)', applies: (c) => isBldg(c) && isSale(c) && c.existingBuilding === true },
  { code: 'L7', label: '代金・交換差金・借賃以外に授受される金銭の額・目的', basis: '法35条1項7号', applies: () => true },
  { code: 'L8', label: '契約の解除に関する事項', basis: '法35条1項8号', applies: () => true },
  { code: 'L9', label: '損害賠償額の予定・違約金に関する事項', basis: '法35条1項9号', applies: () => true },
  { code: 'L10', label: '手付金等の保全措置の概要', basis: '法35条1項10号 (手付金等を受領しようとする場合)', applies: (c) => isSale(c) && c.depositProtectionApplies === true },
  { code: 'L11', label: '支払金・預り金の保全措置', basis: '法35条1項11号', applies: () => true },
  { code: 'L12', label: '代金・交換差金に関する金銭の貸借のあっせん', basis: '法35条1項12号', applies: isSale },
  { code: 'L13', label: '契約不適合責任の履行に関する措置 (保証保険契約の締結等)', basis: '法35条1項13号', applies: isSale },
  { code: 'R1', label: '造成宅地防災区域内か', basis: '法35条1項14号・規則16条の4の3第1号', applies: () => true },
  { code: 'R2', label: '土砂災害警戒区域内か', basis: '規則16条の4の3第2号', applies: () => true },
  { code: 'R3', label: '津波災害警戒区域内か', basis: '規則16条の4の3第3号', applies: () => true },
  { code: 'R3_2', label: '水害ハザードマップ (水防法施行規則11条1号の図面) における所在地', basis: '規則16条の4の3第3号の2', applies: () => true },
  { code: 'R4', label: '石綿の使用の有無の調査結果', basis: '規則16条の4の3第4号 (建物)', applies: isBldg },
  { code: 'R5', label: '耐震診断の内容', basis: '規則16条の4の3第5号 (昭和56年6月1日より前に着工した建物)', applies: (c) => isBldg(c) && c.builtOnOrAfter19810601 !== true },
  { code: 'R6', label: '住宅性能評価を受けた新築住宅である旨', basis: '規則16条の4の3第6号 (建物の売買・交換)', applies: (c) => isBldg(c) && isSale(c) },
  { code: 'R7', label: '台所・浴室・便所その他の設備の整備状況', basis: '規則16条の4の3第7号 (建物の貸借)', applies: (c) => isBldg(c) && isLease(c) },
  { code: 'R8', label: '契約期間・契約の更新に関する事項', basis: '規則16条の4の3第8号 (貸借)', applies: isLease },
  { code: 'R9', label: '定期借地権・定期建物賃貸借・終身建物賃貸借である旨', basis: '規則16条の4の3第9号 (貸借)', applies: isLease },
  { code: 'R10', label: '用途その他の利用の制限', basis: '規則16条の4の3第10号 (貸借)', applies: isLease },
  { code: 'R11', label: '敷金等の契約終了時の精算に関する事項', basis: '規則16条の4の3第11号 (貸借)', applies: isLease },
  { code: 'R12', label: '管理の委託先 (区分所有建物を除く)', basis: '規則16条の4の3第12号 (貸借)', applies: (c) => isLease(c) && !isCondo(c) },
  { code: 'R13', label: '契約終了時の建物の取壊しに関する事項', basis: '規則16条の4の3第13号 (宅地の貸借)', applies: (c) => c.object === 'land' && isLease(c) },
  { code: 'C1', label: '一棟の建物の敷地に関する権利の種類・内容', basis: '法35条1項6号・規則16条の2第1号', applies: (c) => isCondo(c) && isSale(c) },
  { code: 'C2', label: '共用部分に関する規約の定め', basis: '規則16条の2第2号', applies: (c) => isCondo(c) && isSale(c) },
  { code: 'C3', label: '専有部分の用途その他の利用の制限に関する規約の定め', basis: '規則16条の2第3号 (売買・貸借とも)', applies: isCondo },
  { code: 'C4', label: '専用使用権に関する規約の定め', basis: '規則16条の2第4号', applies: (c) => isCondo(c) && isSale(c) },
  { code: 'C5', label: '費用を特定の者にのみ減免する規約の定め', basis: '規則16条の2第5号', applies: (c) => isCondo(c) && isSale(c) },
  { code: 'C6', label: '修繕積立金の規約の定め・既に積み立てられている額', basis: '規則16条の2第6号', applies: (c) => isCondo(c) && isSale(c) },
  { code: 'C7', label: '通常の管理費用の額', basis: '規則16条の2第7号', applies: (c) => isCondo(c) && isSale(c) },
  { code: 'C8', label: '管理の委託先の氏名・住所', basis: '規則16条の2第8号 (売買・貸借とも)', applies: isCondo },
  { code: 'C9', label: '管理者等がマンション管理業者である旨 (管理業者管理者方式)', basis: '規則16条の2第9号 (2026-04-01 施行)', applies: (c) => isCondo(c) && isSale(c) && String(c.explainedOn).slice(0, 10) >= DISCLOSURE35_CONDO_MGMT_MANAGER_EFFECTIVE_DATE },
  { code: 'C10', label: '一棟の建物の維持修繕の実施状況の記録', basis: '規則16条の2第10号', applies: (c) => isCondo(c) && isSale(c) },
  { code: 'K1', label: '現金販売価格', basis: '法35条2項1号 (割賦販売)', applies: (c) => isSale(c) && c.installmentSale === true },
  { code: 'K2', label: '割賦販売価格', basis: '法35条2項2号', applies: (c) => isSale(c) && c.installmentSale === true },
  { code: 'K3', label: '引渡しまでに支払う金銭の額・賦払金の額と支払の時期・方法', basis: '法35条2項3号', applies: (c) => isSale(c) && c.installmentSale === true },
];

/** その取引で必要な項目のコード一覧 */
export function requiredDisclosure35Codes(c: Disclosure35Context): string[] {
  return DISCLOSURE35_ITEMS.filter((i) => i.applies(c)).map((i) => i.code);
}

export interface Disclosure35Document {
  context: Disclosure35Context;
  /** 記載・説明した項目のコード (該当なしと記載した項目も含む) */
  addressedItems: string[];
  /** 説明・記名する宅地建物取引士 */
  takkenShi?: {
    name?: string;
    registrationNo?: string;
    /** 宅地建物取引士証の番号と有効期間の満了日 (YYYY-MM-DD) */
    certificateNo?: string;
    certificateExpiresOn?: string;
    /** 書面に記名したか (35条5項) */
    signed?: boolean;
  };
  /** 交付日 (YYYY-MM-DD)。省略時は context.explainedOn */
  deliveredOn?: string;
  /** 電磁的方法で提供する場合、相手方の承諾を得たか (35条8項) */
  electronic?: { consentObtained: boolean } | null;
}

/**
 * 35条書面を交付してよいかを判定する。欠落・記名なし・取引士証の期限切れ・承諾なしの電磁的提供があれば交付不可。
 *   取引士証の有効期間は5年 (22条の2第3項)。満了日の翌日以後の記名・説明は認めない (35条4項・5項)。
 */
export function canIssue35Document(doc: Disclosure35Document): { canIssue: boolean; missing: string[]; blockers: string[] } {
  const ctx = doc.context;
  const blockers: string[] = [];
  if (!ctx || !ctx.explainedOn || !/^\d{4}-\d{2}-\d{2}/.test(String(ctx.explainedOn))) {
    return { canIssue: false, missing: [], blockers: ['説明日が無いため、適用される項目 (2026-04-01 の追加項目を含む) を決められません'] };
  }
  const addressed = new Set(doc.addressedItems ?? []);
  const missing = requiredDisclosure35Codes(ctx).filter((c) => !addressed.has(c));
  for (const code of missing) {
    const it = DISCLOSURE35_ITEMS.find((i) => i.code === code)!;
    blockers.push(`記載が無い項目: ${it.label} (${it.basis})`);
  }
  const t = doc.takkenShi;
  const on = String(doc.deliveredOn ?? ctx.explainedOn).slice(0, 10);
  if (!t || !t.name || !t.registrationNo) blockers.push('宅地建物取引士の氏名・登録番号がありません (35条1項・5項)');
  else if (t.signed !== true) blockers.push('宅地建物取引士の記名がありません (35条5項)');
  if (t && (!t.certificateNo || !t.certificateExpiresOn)) blockers.push('宅地建物取引士証の番号・有効期間の満了日がありません (35条4項の提示に要る)');
  else if (t && t.certificateExpiresOn && String(t.certificateExpiresOn).slice(0, 10) < on) blockers.push(`宅地建物取引士証の有効期間が ${String(t.certificateExpiresOn).slice(0, 10)} に満了しています。期限切れの取引士証では説明・記名できません (22条の2第3項)`);
  if (doc.electronic && doc.electronic.consentObtained !== true) blockers.push('電磁的方法で提供するには相手方の承諾が要ります (35条8項)');
  return { canIssue: blockers.length === 0, missing, blockers };
}

// =============================================================================
// 報酬の上限の検査 (保存の前に必ず通す)
//
// 【出典 — 一次情報】昭和45年建設省告示第1552号 (最終改正 令和6年国交省告示第949号・2024-07-01 施行)
//   https://www.mlit.go.jp/totikensangyo/const/content/001750229.pdf (2026-10-03 取得)
//   第二 売買・交換の媒介: 依頼者の一方につき 200万円以下の部分5.5% / 200万円超400万円以下の部分4.4% / 400万円超の部分3.3% (税込)
//   第三 売買・交換の代理: 第二の2倍以内 (相手方からも受けるときは合計で2倍以内)
//   第四 貸借の媒介: 双方合計で借賃1月分の1.1倍以内。居住用建物は承諾がなければ一方から0.55倍以内
//   第五 貸借の代理: 借賃1月分の1.1倍以内 (相手方からも受けるときは合計で1.1倍以内)
//   第六 居住用以外の賃貸借で権利金の授受があるとき: 権利金を売買代金とみなして第二・第三によることができる
//   第七 低廉な空家等 (800万円以下) の売買・交換の媒介: 費用を勘案して依頼者から30万円の1.1倍まで
//   第八 低廉な空家等の代理: 第七の2倍以内
//   第九 長期の空家等の貸借の媒介: 借主からの額が1.1倍 (居住用で承諾なしは0.55倍) 以内の場合に限り、双方合計で借賃の2.2倍まで
//   第十 長期の空家等の貸借の代理: 2.2倍以内
//   ★本部品は課税事業者の場合の上限を返す (免税事業者は第十一②で別計算。未対応のため null を返して保存させない)
// =============================================================================

export type BrokerageFeeKind = 'sale_mediation' | 'sale_agency' | 'lease_mediation' | 'lease_agency';

export interface BrokerageFeeInput {
  kind: BrokerageFeeKind;
  /** 売買代金・交換価額 (税抜) */
  price_jpy?: number;
  /** 借賃1月分 (税抜) */
  monthly_rent_jpy?: number;
  /** 居住の用に供する建物の賃貸借か */
  residential?: boolean;
  /** 媒介の依頼を受けるに当たって、その依頼者の承諾を得ているか (第四・第九) */
  client_consent?: boolean;
  /** 低廉な空家等の特例について、あらかじめ説明し合意しているか (第七・第八) */
  low_value_special_agreed?: boolean;
  /** 長期の空家等 (第九・第十) か */
  long_vacant?: boolean;
  /** 報酬を受ける相手: lessor=貸主 / lessee=借主 / seller / buyer */
  payer?: 'lessor' | 'lessee' | 'seller' | 'buyer';
  /** 同じ取引で相手方 (もう一方の依頼者) から受ける (受けた) 報酬の税込額 */
  other_party_fee_incl_tax?: number;
  /** 居住用以外の賃貸借の権利金 (税抜。返還されないもの) */
  key_money_jpy?: number;
  /** 免税事業者か (第十一②。未対応) */
  tax_exempt_business?: boolean;
}

/** 売買・交換の媒介の上限 (税込) を告示第二の段階別の率でそのまま計算する (円未満切捨て) */
function saleMediationCapInclTax(price: number): number {
  const p = Math.max(0, price);
  const a = Math.min(p, 2_000_000);
  const b = Math.min(Math.max(p - 2_000_000, 0), 2_000_000);
  const c = Math.max(p - 4_000_000, 0);
  // 整数のまま計算する (千分率): 5.5% = 55/1000, 4.4% = 44/1000, 3.3% = 33/1000
  return Math.floor((a * 55 + b * 44 + c * 33) / 1000);
}

/**
 * この依頼者から受けてよい報酬の上限 (税込) を返す。判定できないときは cap=null (保存させない)。
 */
export function calcBrokerageFeeCap(p: BrokerageFeeInput): { cap_incl_tax: number | null; basis: string; notes: string[] } {
  const notes: string[] = [];
  if (p.tax_exempt_business) return { cap_incl_tax: null, basis: '告示第十一②', notes: ['免税事業者の上限 (告示第十一②) は本部品では未対応です。税理士・宅地建物取引士に確認してください'] };
  const LOW_VALUE_CEIL = 8_000_000;
  const LOW_VALUE_CAP_INCL = 330_000; // 30万円の1.1倍
  if (p.kind === 'sale_mediation' || p.kind === 'sale_agency') {
    const price = p.price_jpy;
    if (!(typeof price === 'number' && price > 0)) return { cap_incl_tax: null, basis: '告示第二', notes: ['売買代金 (税抜) がありません'] };
    let base = saleMediationCapInclTax(price);
    let basis = '告示第二';
    if (price <= LOW_VALUE_CEIL && p.low_value_special_agreed === true && LOW_VALUE_CAP_INCL > base) {
      base = LOW_VALUE_CAP_INCL;
      basis = '告示第七 (低廉な空家等)';
      notes.push('低廉な空家等の特例の上限です。実際の額は当該媒介に要する費用を勘案して決めてください');
    }
    if (p.kind === 'sale_agency') {
      const total = base * 2;
      const other = Math.max(0, p.other_party_fee_incl_tax ?? 0);
      return { cap_incl_tax: Math.max(0, total - other), basis: basis === '告示第二' ? '告示第三 (代理は2倍以内・相手方と合計)' : '告示第八 (低廉な空家等の代理)', notes };
    }
    return { cap_incl_tax: base, basis, notes };
  }
  // 貸借
  const rent = p.monthly_rent_jpy;
  if (!(typeof rent === 'number' && rent > 0)) return { cap_incl_tax: null, basis: '告示第四', notes: ['借賃1月分 (税抜) がありません'] };
  const r110 = Math.floor((rent * 110) / 100);
  const r55 = Math.floor((rent * 55) / 100);
  const r220 = Math.floor((rent * 220) / 100);
  const other = Math.max(0, p.other_party_fee_incl_tax ?? 0);
  // 第六: 居住用以外で権利金の授受があるときは、売買の計算によることもできる (有利な方)
  const keyMoneyCap = !p.residential && typeof p.key_money_jpy === 'number' && p.key_money_jpy > 0
    ? (p.kind === 'lease_agency' ? saleMediationCapInclTax(p.key_money_jpy) * 2 : saleMediationCapInclTax(p.key_money_jpy))
    : 0;
  if (p.kind === 'lease_mediation') {
    const onePartyLimit = p.residential && p.client_consent !== true ? r55 : r110;
    if (p.long_vacant === true) {
      // 第九: 借主からは1.1倍 (居住用で承諾なしは0.55倍) 以内。その条件で、双方合計2.2倍まで (貸主が残りを負担)
      if (p.payer === 'lessee') return { cap_incl_tax: Math.max(0, Math.min(onePartyLimit, r220 - other)), basis: '告示第九 (借主からの上限)', notes };
      if (other > onePartyLimit) {
        notes.push('借主から受ける額が借主の上限を超えているため、長期の空家等の特例は使えません');
        return { cap_incl_tax: Math.max(0, r110 - other), basis: '告示第四 (特例の条件を満たさない)', notes };
      }
      return { cap_incl_tax: Math.max(0, r220 - other), basis: '告示第九 (長期の空家等: 双方合計で借賃の2.2倍以内)', notes };
    }
    const cap = Math.max(0, Math.min(onePartyLimit, r110 - other));
    if (keyMoneyCap > cap) return { cap_incl_tax: keyMoneyCap, basis: '告示第六 (権利金を売買代金とみなす)', notes };
    return { cap_incl_tax: cap, basis: p.residential && p.client_consent !== true ? '告示第四 (居住用・承諾なしは一方から0.55倍)' : '告示第四 (双方合計で1.1倍)', notes };
  }
  // lease_agency
  if (p.long_vacant === true) return { cap_incl_tax: Math.max(0, r220 - other), basis: '告示第十 (長期の空家等の代理: 2.2倍以内)', notes };
  const cap = Math.max(0, r110 - other);
  if (keyMoneyCap > cap) return { cap_incl_tax: Math.max(0, keyMoneyCap - other), basis: '告示第六 (権利金を売買代金とみなす)', notes };
  return { cap_incl_tax: cap, basis: '告示第五 (貸借の代理: 1.1倍以内・相手方と合計)', notes };
}

/**
 * 報酬を保存する前の検査。上限を超える額・判定できない額は保存させない (ok=false)。
 */
export function validateBrokerageFeeToSave(p: BrokerageFeeInput, proposed_fee_incl_tax: number): { ok: boolean; cap_incl_tax: number | null; reason: string } {
  if (!(typeof proposed_fee_incl_tax === 'number' && Number.isFinite(proposed_fee_incl_tax)) || proposed_fee_incl_tax < 0) {
    return { ok: false, cap_incl_tax: null, reason: '報酬額が数値ではありません' };
  }
  const c = calcBrokerageFeeCap(p);
  if (c.cap_incl_tax === null) return { ok: false, cap_incl_tax: null, reason: `上限を判定できないため保存できません: ${c.notes.join(' / ')}` };
  if (proposed_fee_incl_tax > c.cap_incl_tax) {
    return { ok: false, cap_incl_tax: c.cap_incl_tax, reason: `報酬額 ${proposed_fee_incl_tax.toLocaleString('ja-JP')}円 (税込) は上限 ${c.cap_incl_tax.toLocaleString('ja-JP')}円 (${c.basis}) を超えるため保存できません (宅地建物取引業法46条2項)` };
  }
  return { ok: true, cap_incl_tax: c.cap_incl_tax, reason: `上限 ${c.cap_incl_tax.toLocaleString('ja-JP')}円 (${c.basis}) 以内です` };
}

// 賃貸住宅管理業法・家賃の請求・督促の部品 (生成物の不動産エンジンへ一緒に届けるため、ここから再公開する)
export * from './rental_housing_mgmt';
export * from './rent_billing';
export * from './rent_delinquency';
