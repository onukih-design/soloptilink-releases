/**
 * 宛名の敬称（lib/japan の宛名の敬称の唯一の処理）
 *
 * 2026-09-30 REQ-JPO-FIX-006: 敬称の付与が3系統（keigo.ts personHonorific/companyHonorific・
 *   bug_prevention.ts attachHonorific・templates/japan-ui honorific.ts applyHonorific）に分かれ、
 *   「山田様 様」「ABC株式会社 御中 御中」（二重）、「株式会社ABC 山田御中」（個人名に御中）、
 *   「関係者各位様」、「山田太郎 行 様」（行の残り）、「山田先生様」を出していた。3系統ともこの関数を呼ぶ形に寄せた。
 *
 * 出典: 文化審議会答申「敬語の指針」（平成19年2月2日）第3章 第3の1【21】
 *   「御中」は具体的な人ではなく組織の関係者へあてる脇付けで、氏名が明らかなら「様」とする（御中と氏名の併用は不適切）。
 *   「先生」は敬称で、更に「様」を付けない。
 * ★次は公的な出典を確認できていないビジネス文書の慣行で、安全側の既定として置いた（要確認）:
 *   - 「各位」には更に敬称を付けない
 *   - 返信用の「行」「宛」は外して敬称を付ける（「銀行」「義行」のように名前の一部の「行」は外さない＝空白で区切られたときだけ外す）
 *   - 役職（部長・社長 等）の後には「様」を足さない（「山田部長」のまま。「殿」が既に付いていれば残す）
 *
 * 決まり:
 *   - 既に付いた敬称（様・御中・殿・さん・各位）は数えて、1つだけ残す。付いていなければ1つ付ける。
 *   - 「法人名＋空白＋個人名」（例: 株式会社ABC 山田）は個人宛てとして「様」。法人格を含む1語は組織宛てとして「御中」。
 *   - それ以外で判断が付かないときは、呼び出し側が指定した種類（個人／組織）に従う。
 *   - 既に付いている敬称が1つで、その種類に合っていれば、元の書き方（空白の有無）のまま返す（2回掛けても変わらない）。
 */

export type AtenaKind = 'person' | 'organization';

export interface AtenaOptions {
  /** 判断が付かないときの宛先の種類（既定: 個人） */
  kind?: AtenaKind;
  /** 名前と敬称の間の区切り（既定: 半角空白） */
  sep?: string;
  /** 個人宛てに付ける敬称（既定: 様） */
  personSuffix?: '様' | '殿' | 'さん';
  /** 利用者が敬称を明示的に選んだとき true: 法人名への「様」も選択どおりにする（個人名への「御中」だけは直す） */
  strictKind?: boolean;
}

const WS = '[\\s\\u3000]';
const TOKEN_RE = new RegExp(`(${WS}*)(様|御中|殿|各位|さん)$`);
const RETURN_MARK_RE = new RegExp(`${WS}+(行|宛て|宛)$`);
const TITLE_RE = /(部長|課長|係長|社長|会長|所長|院長|店長|室長|局長|支店長|理事長|専務|常務|取締役|先生|教授)$/;
const CORP_RE = /(株式会社|有限会社|合同会社|合資会社|合名会社|社団法人|財団法人|医療法人|社会福祉法人|学校法人|宗教法人|特定非営利活動法人|NPO法人|独立行政法人|国立大学法人|協同組合|[(（]株[)）]|[(（]有[)）]|㈱|㈲)/;
const ORG_STRONG_RE = /(会社|法人|組合|協会|商店|銀行|信用金庫|病院|医院|クリニック|大学|学校|学園|役所|役場|事務局|委員会|会議所|本部|事業部|営業所|支店|支社|本社|工場|センター|研究所|事務所)$/;
const ORG_WEAK_RE = /(部|課|室|係|店|庁|局|省)$/;

interface ParsedAtena {
  base: string;
  tokens: Array<{ tok: string; ws: string }>; // 内側（名前に近い側）から順
  hadReturnMark: boolean;
}

function parse(name: string): ParsedAtena {
  let s = String(name ?? '').trim();
  const tokens: Array<{ tok: string; ws: string }> = [];
  let hadReturnMark = false;
  for (let guard = 0; guard < 20; guard++) {
    const m = s.match(TOKEN_RE);
    if (m && s.length > m[0].length) {
      tokens.unshift({ tok: m[2], ws: m[1] });
      s = s.slice(0, s.length - m[0].length);
      continue;
    }
    const r = s.match(RETURN_MARK_RE);
    if (r && s.length > r[0].length) {
      hadReturnMark = true;
      s = s.slice(0, s.length - r[0].length);
      continue;
    }
    break;
  }
  return { base: s.trim(), tokens, hadReturnMark };
}

const isOrgSeg = (seg: string) => CORP_RE.test(seg) || ORG_STRONG_RE.test(seg) || (ORG_WEAK_RE.test(seg) && seg.length >= 2);

/** 名前の形から宛先の種類が決まるときだけ返す（決まらなければ null） */
function decisiveKind(base: string): 'title' | 'orgPerson' | 'organization' | null {
  const segs = base.split(/[\s　]+/).filter(Boolean);
  if (segs.length === 0) return null;
  const last = segs[segs.length - 1];
  if (TITLE_RE.test(last) && !CORP_RE.test(last)) return 'title';
  if (segs.length >= 2 && segs.slice(0, -1).some(isOrgSeg) && !isOrgSeg(last)) return 'orgPerson';
  if (CORP_RE.test(last) || ORG_STRONG_RE.test(last)) return 'organization';
  if (segs.length >= 2 && isOrgSeg(last)) return 'organization'; // 例: ABC株式会社 営業部
  return null;
}

/** 宛名に敬称を1つだけ付ける（既に付いていれば重ねない） */
export function formatAtena(name: string, opts: AtenaOptions = {}): string {
  const original = String(name ?? '').trim();
  if (!original) return '';
  const sep = opts.sep ?? ' ';
  const { base, tokens } = parse(original);
  if (!base) return original;

  // 各位: それ自体が敬称。更に付けない
  if (tokens.some((t) => t.tok === '各位')) return `${base}各位`;

  const cls = decisiveKind(base);
  if (cls === 'title') {
    if (/先生$/.test(base)) return base;
    const tono = tokens.find((t) => t.tok === '殿');
    return tono ? `${base}${tono.ws}殿` : base;
  }
  const kind: AtenaKind =
    cls === 'orgPerson' ? 'person'
      : cls === 'organization' && !opts.strictKind ? 'organization'
        : (opts.kind ?? 'person');
  const personSuffix = opts.personSuffix ?? '様';
  const target = kind === 'person' ? personSuffix : '御中';
  const validFor = (tok: string) =>
    kind === 'person' ? (tok === '様' || tok === '殿' || tok === 'さん') : (tok === '御中' || tok === '様' || tok === '殿');

  if (tokens.length === 0) return `${base}${sep}${target}`;
  const keep = tokens.find((t) => validFor(t.tok));
  if (keep) return `${base}${keep.ws}${keep.tok}`;
  return `${base}${sep}${target}`;
}

/** 宛名から、付けるべき敬称の種類を推定する（ひな形の inferHonorificFromName の本体） */
export function inferAtenaSuffix(name: string): '様' | '御中' {
  const { base, tokens } = parse(name);
  if (tokens.some((t) => t.tok === '各位')) return '様';
  const cls = decisiveKind(base);
  if (cls === 'orgPerson' || cls === 'title') return '様';
  if (cls === 'organization') return '御中';
  // 従来の判定（法人格・部署名の語尾）を1語の名前にだけ残す
  if (CORP_RE.test(base)) return '御中';
  if (/(部|課|室|本部|事業部|営業所|支店)$/.test(base)) return '御中';
  return '様';
}
