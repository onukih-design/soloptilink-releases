/**
 * 税・社会保険の判定部品 (T07・2026-10-03) — どの判定も「根拠・前提・基準日・専門家確認の要否」を必ず返す
 *
 * 収録する判定:
 *  - calcWithholdingTaxForPayDate      源泉徴収税額 (月額表／電算機特例・支払日で年分の表を切替)
 *  - judgeShortTimeWorkerCoverage      短時間労働者の社会保険の加入 (賃金要件の撤廃・企業規模の段階)
 *  - judgeDependentByContract          被扶養者の認定 (労働契約で見込む年収・130万/150万/180万円)
 *  - calcPremiumRemittance             社会保険料の納付額 (被保険者全員分を合計してから円未満切捨て)
 *  - splitResidentTaxSpecialCollection 住民税の特別徴収の月割 (12回・端数は最初の月)
 *  - judgeResidentTaxOnLeaving         退職時の住民税 (一括徴収・普通徴収への切替)
 *  - calcTeijiKettei                   算定基礎 (定時決定・支払基礎日数17日/11日/15日の扱い)
 *  - judgeZuijiKaitei                  随時改定 (2等級差・上限下限の1等級差の特例)
 *  - calcProfessionalFeeWithholding    士業報酬の源泉徴収 (士業の種類別・令和9年分以後の税目名)
 *
 * ★判定は参考であり、最終判断は専門家 (社会保険労務士・税理士) と市区町村・年金事務所が行う
 *   (税理士法第52条・社会保険労務士法第27条)。専門家確認が要る判定は status='needs_expert'、
 *   取り込んでいない年分・制度は status='unsupported' とし、旧い値で計算し続けない。
 * ★値 (金額・日付・日数) は下の PAYROLL_JUDGMENT_VALUES の1か所に置き、各判定はそれを読む。
 */
import {
  HEALTH_INSURANCE_GRADES,
  PENSION_INSURANCE_GRADES,
  calcStandardRemuneration,
  calcPensionStandardRemuneration,
  type StandardRemunerationGrade,
} from "./hr_payroll";
import {
  MONTHLY_WITHHOLDING_TABLES,
  DENZANKI_PARAMS,
  calcWithholdingFromTable,
  calcDenzankiWithholdingTax,
  withholdingYearOfPayDate,
} from "./gensen_withholding_by_year";

export { calcDenzankiWithholdingTax } from "./gensen_withholding_by_year";

// ============================================================================
// 判定の型 (REQ-016 / JPO-LAW-016)
// ============================================================================

export type JudgmentStatus = "ok" | "unsupported" | "needs_expert";
export interface JudgmentBasis { title_ja: string; url: string; }
export interface ExpertReview {
  /** 専門家確認が要るか */
  required: boolean;
  /** 要る理由 (required=true のとき必須) */
  reason_ja: string | null;
  /** 確認先 (社会保険労務士・税理士・市区町村 など) */
  who_ja: string;
}
export interface TaxSocialJudgment<T> {
  kind: string;
  status: JudgmentStatus;
  /** 判定・計算の結果。未対応のときは null */
  result: T | null;
  /** 根拠 (法令・通知・公表資料と出典URL) */
  basis: JudgmentBasis[];
  /** 前提 (入力の意味・判定の範囲・確認していないこと) */
  assumptions: string[];
  /** 基準日 (YYYY-MM-DD) */
  as_of: string;
  /** 専門家確認の要否 */
  expert_review: ExpertReview;
  /** 画面にそのまま出せる日本語の一文 */
  message_ja: string;
}

/** 判定部品の登録簿 (型の検査はこの一覧と検体側の一覧を突き合わせる) */
export const TAX_SOCIAL_JUDGMENT_FUNCTIONS = [
  "calcWithholdingTaxForPayDate",
  "judgeShortTimeWorkerCoverage",
  "judgeDependentByContract",
  "calcPremiumRemittance",
  "splitResidentTaxSpecialCollection",
  "judgeResidentTaxOnLeaving",
  "calcTeijiKettei",
  "judgeZuijiKaitei",
  "calcProfessionalFeeWithholding",
] as const;

// ============================================================================
// 根拠 (一次資料)
// ============================================================================

const SRC = {
  nta_r8: { title_ja: "国税庁「令和8年分 源泉徴収税額表」", url: "https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2026/01.htm" },
  nta_r9: { title_ja: "国税庁「令和9年分 源泉徴収税額表」(令和8年4月30日財務省告示第127号別表第一)", url: "https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2027/01.htm" },
  dz_r8: { title_ja: "国税庁「月額表の甲欄を適用する給与等に対する税額の電算機計算の特例について」(令和8年分)", url: "https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2026/data/denshi_01.pdf" },
  dz_r9: { title_ja: "国税庁「月額表の甲欄を適用する給与等に対する税額の電算機計算の特例について」(令和9年分以降)", url: "https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2027/data/denshi_01.pdf" },
  mhlw_tanjikan: { title_ja: "厚生労働省 社会保険適用拡大特設サイト「短時間労働者」(賃金要件は2026年10月に撤廃)", url: "https://www.mhlw.go.jp/tekiyoukakudai/seido/tanjikan/" },
  mhlw_top: { title_ja: "厚生労働省 社会保険適用拡大特設サイト (企業等の規模ごとの適用時期)", url: "https://www.mhlw.go.jp/tekiyoukakudai/" },
  mhlw_qa: { title_ja: "厚生労働省 社会保険適用拡大特設サイト 適用拡大Q&A", url: "https://www.mhlw.go.jp/tekiyoukakudai/qa/" },
  egov_272: { title_ja: "令和8年政令第272号 (令和七年改正法の一部の施行に伴う経過措置・令和8年10月1日施行)", url: "https://laws.e-gov.go.jp/law/508CO0000000272" },
  hoho1001: { title_ja: "厚生労働省 保保発1001第3号・年管管発1001第3号 (労働契約内容による年間収入が基準額未満である場合の被扶養者の認定・令和8年4月1日適用)", url: "https://www.mhlw.go.jp/web/t_doc?dataId=00tc9348&dataType=1&pageNo=1" },
  kyoukai_r8: { title_ja: "全国健康保険協会「令和8年3月分(4月納付分)からの健康保険・厚生年金保険の保険料額表」(備考: 端数処理・納入告知書の保険料額)", url: "https://www.kyoukaikenpo.or.jp/assets/R8_13tokyo.pdf" },
  nenkin_keisan: { title_ja: "日本年金機構「保険料の計算方法について」", url: "https://www.nenkin.go.jp/service/kounen/hokenryo/nofu/20121026.html" },
  chihozei_321_5: { title_ja: "地方税法 第321条の5 (給与所得に係る特別徴収税額の納入の義務等)", url: "https://laws.e-gov.go.jp/law/325AC0000000226" },
  chihozei_20_4_2: { title_ja: "地方税法 第20条の4の2 第6項・第8項 (分割金額の端数は最初の納期限に合算・特別徴収の住民税は百円)", url: "https://laws.e-gov.go.jp/law/325AC0000000226" },
  nenkin_teiji: { title_ja: "日本年金機構「定時決定（算定基礎届）」", url: "https://www.nenkin.go.jp/service/kounen/hokenryo/hoshu/20121017.html" },
  nenkin_zuiji: { title_ja: "日本年金機構「随時改定（月額変更届）」", url: "https://www.nenkin.go.jp/service/kounen/hokenryo/hoshu/20150515-02.html" },
  shotoku_204: { title_ja: "所得税法 第204条第1項第2号・第205条 / 所得税法施行令 第320条第2項・第322条", url: "https://laws.e-gov.go.jp/law/340AC0000000033" },
  nta_2798: { title_ja: "国税庁 タックスアンサー No.2798「弁護士や税理士等に支払う報酬・料金」", url: "https://www.nta.go.jp/taxes/shiraberu/taxanswer/gensen/2798.htm" },
  nta_kaisei2026: { title_ja: "国税庁「令和８年４月源泉所得税の改正のあらまし」(防衛特別所得税及び復興特別所得税の源泉徴収のあらまし)", url: "https://www.nta.go.jp/publication/pamph/gensen/2026kaisei.pdf" },
} as const satisfies Record<string, JudgmentBasis>;

// ============================================================================
// 値表 (この1か所に置き、各判定はここを読む)
// ============================================================================

export const PAYROLL_JUDGMENT_VALUES = {
  short_time_worker: {
    /** 賃金要件 (所定内賃金の月額) — 2026-10-01 に撤廃 (厚労省特設サイト・令和8年政令第272号の施行日) */
    wage_requirement_monthly_jpy: 88_000,
    wage_requirement_abolished_on: "2026-10-01",
    weekly_hours_min: 20,
    /** 企業規模要件 (厚生年金保険の被保険者数・法人は法人全体) の段階 */
    company_size_schedule: [
      { from: "2024-10-01", min_insured: 51 as number | null },
      { from: "2027-10-01", min_insured: 36 as number | null },
      { from: "2029-10-01", min_insured: 21 as number | null },
      { from: "2032-10-01", min_insured: 11 as number | null },
      { from: "2035-10-01", min_insured: null as number | null }, // 撤廃 (全企業)
    ],
    /** これより前の基準日は取り込んでいない (51人以上になる前の段階は未収録) */
    supported_from: "2024-10-01",
  },
  dependent: {
    contract_based_from: "2026-04-01",
    threshold_general_jpy: 1_300_000,
    threshold_age60_or_disabled_jpy: 1_800_000,
    threshold_age19_22_non_spouse_jpy: 1_500_000,
  },
  premium: {
    /** 給与から控除: 50銭以下切捨て・50銭超切上げ / 現金: 50銭未満切捨て・50銭以上切上げ */
    half_yen_micro: 500_000,
  },
  resident_tax: {
    /** 特別徴収の分割金額の端数単位 (地方税法20条の4の2第8項後段で「百円」。条例で別の定めがありうる) */
    rounding_unit_default_jpy: 100,
    lump_sum_required_months: [1, 2, 3, 4],
    lump_sum_by_request_months: [6, 7, 8, 9, 10, 11, 12],
  },
  santei: {
    base_days_general: 17,
    base_days_short_time_tokutei: 11,
    base_days_part_timer_fallback: 15,
  },
  zuiji: {
    grade_diff_required: 2,
    /** 上限・下限にわたる1等級差の特例 (日本年金機構「随時改定」の表) */
    cap_floor: {
      health: { top_up_avg_min: 1_415_000, bottom_prev_rem_below: 53_000 },
      pension: { top_up_avg_min: 665_000, bottom_prev_rem_below: 83_000 },
    },
  },
  professional_fee: {
    tier_threshold_jpy: 1_000_000,
    /** 合計税率 10.21% / 20.42% (所得税率×102.1%) を 1/10000 で持つ */
    rate_low_per10k: 1021,
    rate_high_per10k: 2042,
    judicial_deduction_jpy: 10_000,
    /** 防衛特別所得税が加わる日 (令和9年1月1日以後に生ずる所得) */
    defense_tax_from: "2027-01-01",
    tax_names_before_ja: "所得税及び復興特別所得税",
    tax_names_from_2027_ja: "所得税、防衛特別所得税及び復興特別所得税",
    /** 合計税率 2.1% が確かめられている期間の終わり (復興特別所得税の課税期間 令和29年12月31日) */
    supported_until: "2047-12-31",
  },
} as const;

// ============================================================================
// 共通の小道具
// ============================================================================

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
function todayLocal(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function asOfOrToday(v: unknown): string {
  return typeof v === "string" && DATE_RE.test(v) ? v : todayLocal();
}
const isNonNegInt = (v: unknown): v is number => typeof v === "number" && Number.isInteger(v) && v >= 0;

// 結果の型は各判定関数の戻り値の宣言 (TaxSocialJudgment<各結果>) で決める。ここでは型を絞らない。
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function make(p: {
  kind: string;
  status: JudgmentStatus;
  result: unknown;
  basis: JudgmentBasis[];
  assumptions: string[];
  as_of: string;
  who_ja: string;
  expert_reason_ja?: string | null;
  message_ja: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
}): TaxSocialJudgment<any> {
  // 専門家確認: needs_expert と unsupported は必ず要る (確認先へつなぐ)。ok は理由を渡されたときだけ要る。
  const reason =
    p.expert_reason_ja ??
    (p.status === "needs_expert"
      ? p.message_ja
      : p.status === "unsupported"
        ? `この判定は本部品の対象外です。${p.message_ja}`
        : null);
  return {
    kind: p.kind,
    status: p.status,
    result: p.result,
    basis: p.basis,
    assumptions: p.assumptions,
    as_of: p.as_of,
    expert_review: { required: p.status !== "ok" || reason !== null, reason_ja: reason, who_ja: p.who_ja },
    message_ja: p.message_ja,
  };
}

/**
 * 画面に出す「専門家への確認」の導線を組み立てる (専門家確認が要らない判定では show=false)。
 * リンク先は必ず開ける一次資料 (根拠の先頭) にする — 押してもどこへも行かないリンクを作らないため。
 */
export function buildExpertReviewNotice(j: TaxSocialJudgment<unknown>): {
  show: boolean;
  title_ja: string;
  body_ja: string;
  link_href: string;
  link_label_ja: string;
  who_ja: string;
} {
  const show = j.expert_review.required || j.status !== "ok";
  const title =
    j.status === "unsupported" ? "この判定は自動では行えません" : "専門家への確認が必要です";
  const body = show
    ? `${j.expert_review.reason_ja ?? j.message_ja} ${j.expert_review.who_ja}にご確認ください（基準日 ${j.as_of}）。`
    : "";
  return {
    show,
    title_ja: show ? title : "",
    body_ja: body,
    link_href: j.basis[0]?.url ?? "",
    link_label_ja: show ? `根拠の資料を開く（${j.basis[0]?.title_ja ?? ""}）` : "",
    who_ja: j.expert_review.who_ja,
  };
}

// ============================================================================
// 1. 源泉徴収税額 (月額表／電算機特例・支払日で年分の表を切替)
// ============================================================================

export interface WithholdingByDateInput {
  /** 給与の支払日 (YYYY-MM-DD)。どの年分の表を使うかはこれで決まる */
  pay_date: string;
  /** その月の社会保険料等控除後の給与等の金額 */
  monthly_taxable: number;
  /** 扶養親族等の数 (障害者・寡婦・ひとり親・勤労学生等の加算を済ませた数) */
  dependents?: number;
  column?: "kou" | "otsu";
  /** 'table' = 月額表 (既定) / 'denzanki' = 電算機計算の特例 (甲欄のみ) */
  method?: "table" | "denzanki";
}
export interface WithholdingByDateResult {
  tax_jpy: number;
  table_ja: string;
  tax_names_ja: string;
  method: "table" | "denzanki";
  column: "kou" | "otsu";
  year: number;
}

export function calcWithholdingTaxForPayDate(input: WithholdingByDateInput): TaxSocialJudgment<WithholdingByDateResult> {
  const kind = "withholding_tax_by_pay_date";
  const column = input.column ?? "kou";
  const method = input.method ?? "table";
  const asOf = typeof input.pay_date === "string" && DATE_RE.test(input.pay_date) ? input.pay_date : todayLocal();
  const baseAssumptions = [
    "入力はその月の社会保険料等控除後の給与等の金額です。",
    "どの年分の表を使うかは給与の支払日で決まります（国税庁の税額表の注意書き）。",
    "扶養親族等の数は扶養控除等申告書によるもので、障害者・寡婦・ひとり親・勤労学生などの加算を済ませた数として扱います。",
  ];
  let year: number;
  try { year = withholdingYearOfPayDate(input.pay_date); } catch (e) {
    return make({ kind, status: "unsupported", result: null, basis: [SRC.nta_r8, SRC.nta_r9], assumptions: baseAssumptions, as_of: asOf, who_ja: "税理士", message_ja: String((e as Error).message) });
  }
  const table = MONTHLY_WITHHOLDING_TABLES[year];
  const basis: JudgmentBasis[] = year === 2027 ? [SRC.nta_r9] : year === 2026 ? [SRC.nta_r8] : [SRC.nta_r8, SRC.nta_r9];
  if (!table) {
    return make({
      kind, status: "unsupported", result: null, basis, assumptions: baseAssumptions, as_of: asOf, who_ja: "税理士",
      message_ja: `令和${year - 2018}年分 (${year}年支払) の源泉徴収税額表は取り込んでいないため計算しません。国税庁の税額表で確認してください。`,
    });
  }
  if (!Number.isFinite(input.monthly_taxable) || input.monthly_taxable < 0) {
    return make({ kind, status: "unsupported", result: null, basis, assumptions: baseAssumptions, as_of: asOf, who_ja: "税理士", message_ja: "社会保険料等控除後の給与等の金額が数として読めません。" });
  }
  if (method === "denzanki") {
    const dzSrc = year === 2027 ? SRC.dz_r9 : SRC.dz_r8;
    if (column !== "kou" || !DENZANKI_PARAMS[year]) {
      return make({
        kind, status: "unsupported", result: null, basis: [dzSrc], assumptions: baseAssumptions, as_of: asOf, who_ja: "税理士",
        message_ja: "電算機計算の特例は月額表の甲欄を適用する給与等 (扶養控除等申告書の提出あり) に限られます。乙欄には使えません。",
      });
    }
    const tax = calcDenzankiWithholdingTax(year, input.monthly_taxable, input.dependents ?? 0);
    return make({
      kind, status: "ok",
      result: { tax_jpy: tax, table_ja: `${DENZANKI_PARAMS[year].year_ja} 電算機計算の特例`, tax_names_ja: table.tax_names_ja, method, column, year },
      basis: [dzSrc, ...basis],
      assumptions: [...baseAssumptions, "電算機計算の特例の税額は月額表の税額と必ずしも一致しません。その差は年末調整で精算されます（国税庁の説明）。"],
      as_of: asOf, who_ja: "税理士",
      message_ja: `${DENZANKI_PARAMS[year].year_ja}の電算機計算の特例で ${tax.toLocaleString("ja-JP")}円 です。`,
    });
  }
  const tax = calcWithholdingFromTable(table, input.monthly_taxable, input.dependents ?? 0, column);
  return make({
    kind, status: "ok",
    result: { tax_jpy: tax, table_ja: `${table.year_ja} 源泉徴収税額表 (月額表)`, tax_names_ja: table.tax_names_ja, method, column, year },
    basis, assumptions: baseAssumptions, as_of: asOf, who_ja: "税理士",
    message_ja: `${table.year_ja}の月額表 (${column === "kou" ? "甲欄" : "乙欄"}) で ${tax.toLocaleString("ja-JP")}円 です。`,
  });
}

// ============================================================================
// 2. 短時間労働者の社会保険の加入
// ============================================================================

export interface ShortTimeCoverageInput {
  as_of: string;
  /** 週の所定労働時間 */
  weekly_hours: number;
  /** 所定内賃金の月額 (2026-09-30 以前の判定でだけ使う) */
  monthly_wage?: number | null;
  /** 学生 (夜間・定時制・通信制・休学中などは false として入力する) */
  is_student: boolean;
  /** 2ヶ月を超えて雇用される見込みがあるか */
  expected_over_2_months: boolean;
  /** 厚生年金保険の被保険者数 (法人は法人全体) */
  insured_count?: number | null;
  /** 任意特定適用事業所 (労使合意で申出済み) */
  voluntary_tokutei?: boolean;
  /** 労働時間・労働日数がフルタイムの4分の3以上 (通常の被保険者) */
  meets_three_quarters?: boolean;
}
export interface ShortTimeCoverageResult {
  covered: boolean | null;
  reason_ja: string;
  /** 基準日に適用される企業規模要件 (被保険者数の下限。null は撤廃) */
  company_size_min: number | null;
  wage_requirement_applied: boolean;
}

export function judgeShortTimeWorkerCoverage(input: ShortTimeCoverageInput): TaxSocialJudgment<ShortTimeCoverageResult> {
  const kind = "short_time_worker_coverage";
  const V = PAYROLL_JUDGMENT_VALUES.short_time_worker;
  const asOf = asOfOrToday(input.as_of);
  const basis = [SRC.mhlw_tanjikan, SRC.mhlw_top, SRC.mhlw_qa, SRC.egov_272];
  const assumptions = [
    "企業等の規模は厚生年金保険の被保険者数（法人は法人全体）で数えます。「常時」の数え方は日本年金機構の基準によります。",
    "学生でも夜間・定時制・通信制・休学中などは加入の対象です。その場合は「学生でない」として入力してください。",
    "週の所定労働時間は就業規則・雇用契約書で判断します。実際の労働時間が2ヶ月連続で週20時間以上となり続く見込みのときは3ヶ月目から対象になります。",
    "賃金要件（月額8.8万円）の撤廃日は厚労省の案内「2026年10月」と経過措置政令（令和8年政令第272号・令和8年10月1日施行）から2026-10-01としています（施行期日政令第275号の官報原文は未確認）。",
  ];
  const who = "社会保険労務士・年金事務所";
  if (!(typeof input.as_of === "string" && DATE_RE.test(input.as_of))) {
    return make({ kind, status: "unsupported", result: null, basis, assumptions, as_of: asOf, who_ja: who, message_ja: "基準日 (YYYY-MM-DD) がありません。" });
  }
  if (asOf < V.supported_from) {
    return make({ kind, status: "unsupported", result: null, basis, assumptions, as_of: asOf, who_ja: who, message_ja: `${V.supported_from} より前の企業規模要件は取り込んでいないため判定しません。` });
  }
  const sched = [...V.company_size_schedule].filter((s) => s.from <= asOf).pop()!;
  const min = sched.min_insured;
  const wageApplied = asOf < V.wage_requirement_abolished_on;
  const res = (covered: boolean | null, reason: string): ShortTimeCoverageResult => ({ covered, reason_ja: reason, company_size_min: min, wage_requirement_applied: wageApplied });
  const ok = (covered: boolean, reason: string) => make({ kind, status: "ok", result: res(covered, reason), basis, assumptions, as_of: asOf, who_ja: who, message_ja: reason });

  if (input.meets_three_quarters) return ok(true, "労働時間・労働日数がフルタイムの4分の3以上のため、企業規模にかかわらず社会保険に加入します。");
  if (!input.expected_over_2_months) return ok(false, "2ヶ月を超えて雇用される見込みがないため、短時間労働者としての加入の対象になりません。");
  if (!(typeof input.weekly_hours === "number" && Number.isFinite(input.weekly_hours))) {
    return make({ kind, status: "needs_expert", result: res(null, "週の所定労働時間が分かりません。"), basis, assumptions, as_of: asOf, who_ja: who, message_ja: "週の所定労働時間が分からないため判定できません。" });
  }
  if (input.weekly_hours < V.weekly_hours_min) return ok(false, `週の所定労働時間が${V.weekly_hours_min}時間未満のため加入しません。`);
  if (input.is_student) return ok(false, "学生のため短時間労働者としての加入の対象になりません。");
  if (!input.voluntary_tokutei && min !== null) {
    if (!isNonNegInt(input.insured_count)) {
      return make({ kind, status: "needs_expert", result: res(null, "被保険者数が分かりません。"), basis, assumptions, as_of: asOf, who_ja: who, message_ja: "厚生年金保険の被保険者数が分からないため、企業規模要件を判定できません。" });
    }
    if (input.insured_count < min) {
      const next = V.company_size_schedule.find((s) => s.min_insured === null || (s.from > asOf && input.insured_count! >= s.min_insured));
      return ok(false, `基準日 ${asOf} の企業規模要件（被保険者${min}人以上）を満たさないため、まだ加入の対象ではありません。` +
        (next ? `${next.from.slice(0, 7).replace("-", "年")}月から対象になります。` : ""));
    }
  }
  if (wageApplied) {
    const w = input.monthly_wage;
    if (!(typeof w === "number" && Number.isFinite(w))) {
      return make({ kind, status: "needs_expert", result: res(null, "所定内賃金の月額が分かりません。"), basis, assumptions, as_of: asOf, who_ja: who, message_ja: `基準日 ${asOf} は賃金要件（月額8.8万円以上）がある期間ですが、所定内賃金の月額が分からないため判定できません。` });
    }
    if (w < V.wage_requirement_monthly_jpy) return ok(false, `基準日 ${asOf} は賃金要件（所定内賃金の月額8.8万円以上）があり、月額${w.toLocaleString("ja-JP")}円のため加入しません（2026年10月1日からは賃金要件がなくなります）。`);
  }
  return ok(true, `週${input.weekly_hours}時間以上・学生でない・2ヶ月超の雇用見込み・企業規模要件を満たすため、社会保険に加入します${wageApplied ? "" : "（賃金要件は2026年10月1日に撤廃済み）"}。`);
}

// ============================================================================
// 3. 被扶養者の認定 (労働契約ベース)
// ============================================================================

export interface DependentByContractInput {
  as_of: string;
  /** 労働条件通知書等の賃金 (諸手当・賞与を含む) から見込まれる年間収入 */
  contract_annual_income: number;
  /** 認定対象者の年齢 (通知の基準日での年齢) */
  age: number;
  is_spouse: boolean;
  is_disabled?: boolean;
  same_household: boolean;
  /** 被保険者の年間収入 (同一世帯のとき使う) */
  insured_annual_income?: number | null;
  /** 被保険者からの援助額 (別世帯のとき使う・年額) */
  support_from_insured?: number | null;
  /** 給与収入以外 (年金・事業収入等) の収入があるか */
  has_other_income: boolean;
}
export interface DependentByContractResult {
  eligible: boolean | null;
  threshold_jpy: number;
  reason_ja: string;
}

export function judgeDependentByContract(input: DependentByContractInput): TaxSocialJudgment<DependentByContractResult> {
  const kind = "dependent_by_contract";
  const V = PAYROLL_JUDGMENT_VALUES.dependent;
  const asOf = asOfOrToday(input.as_of);
  const basis = [SRC.hoho1001];
  const who = "社会保険労務士・加入している健康保険の保険者";
  const threshold =
    input.age >= 60 || input.is_disabled
      ? V.threshold_age60_or_disabled_jpy
      : !input.is_spouse && input.age >= 19 && input.age < 23
        ? V.threshold_age19_22_non_spouse_jpy
        : V.threshold_general_jpy;
  const assumptions = [
    "年間収入は労働条件通知書等に書かれた賃金（諸手当・賞与を含む）から見込んだ額で、認定対象者の「給与収入のみである」旨の申立てがある前提です。",
    "基準額: 130万円未満（60歳以上・障害者は180万円未満、配偶者以外の19歳以上23歳未満は150万円未満）。年齢は入力された値で判定します（19歳以上23歳未満の年齢をいつ時点で数えるかは保険者に確認してください）。",
    "当初想定されなかった臨時収入で結果的に基準額以上になっても、社会通念上妥当な範囲なら取扱いを変える必要はありません（通知の3）。",
    "労働契約の更新や条件変更があれば、その都度確認し直します。",
  ];
  const res = (eligible: boolean | null, reason: string): DependentByContractResult => ({ eligible, threshold_jpy: threshold, reason_ja: reason });
  if (!(typeof input.as_of === "string" && DATE_RE.test(input.as_of)) || asOf < V.contract_based_from) {
    return make({ kind, status: "unsupported", result: res(null, "労働契約ベースの取扱いの適用前です。"), basis, assumptions, as_of: asOf, who_ja: who,
      message_ja: `労働契約の内容による年間収入の取扱いは${V.contract_based_from}から適用です。それより前の基準日は従前の取扱い（今後1年間の収入見込み）で保険者が判断します。` });
  }
  if (input.has_other_income) {
    return make({ kind, status: "needs_expert", result: res(null, "給与収入以外の収入があります。"), basis, assumptions, as_of: asOf, who_ja: who,
      message_ja: "給与収入以外の収入（年金・事業収入等）があるため、労働契約の内容だけでは判定できません。従前の取扱いで保険者が判断します。" });
  }
  const inc = input.contract_annual_income;
  if (!(typeof inc === "number" && Number.isFinite(inc) && inc >= 0)) {
    return make({ kind, status: "unsupported", result: res(null, "年間収入が読めません。"), basis, assumptions, as_of: asOf, who_ja: who, message_ja: "労働契約から見込む年間収入が数として読めません。" });
  }
  const ok = (eligible: boolean, reason: string) => make({ kind, status: "ok", result: res(eligible, reason), basis, assumptions, as_of: asOf, who_ja: who, message_ja: reason });
  if (inc >= threshold) return ok(false, `労働契約から見込む年間収入${inc.toLocaleString("ja-JP")}円が基準額${threshold.toLocaleString("ja-JP")}円「未満」ではないため、被扶養者に該当しません。`);
  if (input.same_household) {
    const ins = input.insured_annual_income;
    if (!(typeof ins === "number" && Number.isFinite(ins) && ins > 0)) {
      return make({ kind, status: "needs_expert", result: res(null, "被保険者の年間収入が分かりません。"), basis, assumptions, as_of: asOf, who_ja: who, message_ja: "同一世帯の場合は被保険者の年間収入の2分の1未満かを見ますが、被保険者の年間収入が分かりません。" });
    }
    if (inc * 2 < ins) return ok(true, `年間収入${inc.toLocaleString("ja-JP")}円が基準額未満で、被保険者の年間収入の2分の1未満のため、被扶養者に該当します。`);
    if (inc <= ins) {
      return make({ kind, status: "needs_expert", result: res(null, "2分の1以上だが被保険者を上回らない"), basis, assumptions, as_of: asOf, who_ja: who,
        message_ja: "年間収入が被保険者の2分の1以上ですが被保険者を上回らないため、世帯の生計の状況を総合的に勘案して保険者が判断します（通知の注3）。" });
    }
    return ok(false, "年間収入が被保険者の年間収入を上回るため、被扶養者に該当しません。");
  }
  const sup = input.support_from_insured;
  if (!(typeof sup === "number" && Number.isFinite(sup) && sup >= 0)) {
    return make({ kind, status: "needs_expert", result: res(null, "援助額が分かりません。"), basis, assumptions, as_of: asOf, who_ja: who, message_ja: "別世帯の場合は被保険者からの援助額より少ないかを見ますが、援助額が分かりません。" });
  }
  if (inc < sup) return ok(true, "別世帯で、年間収入が基準額未満かつ被保険者からの援助額より少ないため、被扶養者に該当します。");
  return ok(false, "別世帯で、年間収入が被保険者からの援助額以上のため、被扶養者に該当しません。");
}

// ============================================================================
// 4. 社会保険料の納付額 (合計してから円未満切捨て)
// ============================================================================

export type PremiumRounding = "payroll_deduction" | "cash" | "truncate";
export interface PremiumRemittanceInput {
  /** 制度 (health / long_term_care / child_care_support / pension など — 制度ごとに合計する) */
  scheme: string;
  /** 制度の保険料率 (労使合計・折半前。例 0.0985) */
  rate: number;
  as_of: string;
  members: Array<{ standard_jpy: number; rounding?: PremiumRounding }>;
}
export interface PremiumRemittanceResult {
  scheme: string;
  total_jpy: number;
  employee_total_jpy: number;
  employer_share_jpy: number;
  members: Array<{ standard_jpy: number; employee_share_jpy: number; rounding: PremiumRounding }>;
}

/** 折半額の円未満処理 (N = 標準報酬×料率(百万分率) — 折半額は N / 2,000,000 円) */
function roundHalfShare(N: number, method: PremiumRounding): number {
  const yen = Math.floor(N / 2_000_000);
  const rem = N - yen * 2_000_000; // 0.5マイクロ円単位。50銭 = 1,000,000
  const half = PAYROLL_JUDGMENT_VALUES.premium.half_yen_micro * 2;
  if (method === "truncate") return yen;
  if (method === "cash") return rem >= half ? yen + 1 : yen;
  return rem > half ? yen + 1 : yen;
}

export function calcPremiumRemittance(input: PremiumRemittanceInput): TaxSocialJudgment<PremiumRemittanceResult> {
  const kind = "premium_remittance";
  const asOf = asOfOrToday(input.as_of);
  const basis = [SRC.kyoukai_r8, SRC.nenkin_keisan];
  const who = "社会保険労務士・年金事務所";
  const assumptions = [
    "納付額（納入告知額）は、被保険者ごとの標準報酬×料率を合計し、その合計の1円未満を切り捨てます（被保険者ごとには丸めません）。",
    "被保険者負担は給与から控除する場合50銭以下切捨て・50銭超切上げ、現金で支払う場合50銭未満切捨て・50銭以上切上げ、労使の特約があれば特約によります。",
    "事業主負担 = 納付額 − 被保険者負担の合計 です（端数処理のため折半とは一致しないことがあります）。",
    "料率は加入している保険者・支部・年度の料率を入力してください（健康保険料率は都道府県支部ごとに違います）。",
  ];
  const rate = input.rate;
  const rateMicro = Math.round(rate * 1_000_000);
  if (!(typeof rate === "number" && Number.isFinite(rate) && rate > 0 && rate < 1) || Math.abs(rate * 1_000_000 - rateMicro) > 1e-6) {
    return make({ kind, status: "unsupported", result: null, basis, assumptions, as_of: asOf, who_ja: who, message_ja: `保険料率が不正です (受け取った値: ${String(rate)})。0より大きく1未満、小数第6位までの率を入れてください。` });
  }
  if (!Array.isArray(input.members) || input.members.some((m) => !isNonNegInt(m?.standard_jpy))) {
    return make({ kind, status: "unsupported", result: null, basis, assumptions, as_of: asOf, who_ja: who, message_ja: "標準報酬 (円の整数) が読めない被保険者がいます。" });
  }
  let totalN = 0;
  const members = input.members.map((m) => {
    const N = m.standard_jpy * rateMicro;
    totalN += N;
    const method = m.rounding ?? "payroll_deduction";
    return { standard_jpy: m.standard_jpy, employee_share_jpy: roundHalfShare(N, method), rounding: method };
  });
  const total = Math.floor(totalN / 1_000_000);
  const empTotal = members.reduce((a, m) => a + m.employee_share_jpy, 0);
  return make({
    kind, status: "ok",
    result: { scheme: input.scheme, total_jpy: total, employee_total_jpy: empTotal, employer_share_jpy: total - empTotal, members },
    basis, assumptions, as_of: asOf, who_ja: who,
    message_ja: `${input.scheme} の納付額は ${total.toLocaleString("ja-JP")}円（被保険者負担 ${empTotal.toLocaleString("ja-JP")}円・事業主負担 ${(total - empTotal).toLocaleString("ja-JP")}円）です。`,
  });
}

// ============================================================================
// 5. 住民税の特別徴収 (月割) / 6. 退職時
// ============================================================================

export interface ResidentTaxSplitInput {
  /** 特別徴収税額 (年税額) */
  annual_tax_jpy: number;
  as_of: string;
  /** 最初に徴収する月 (通知が期日までに届けば6。期日後なら通知の翌月) */
  first_month?: number;
  /** 分割金額の端数単位 (既定100円。条例で別の定めがある市区町村はその値) */
  rounding_unit_jpy?: number;
  /** 均等割額 (特別徴収税額が均等割額以下なら最初の月に全額) */
  kintowari_jpy?: number;
}
export interface ResidentTaxSplitResult {
  monthly: Array<{ month: number; amount_jpy: number }>;
  total_jpy: number;
}

export function splitResidentTaxSpecialCollection(input: ResidentTaxSplitInput): TaxSocialJudgment<ResidentTaxSplitResult> {
  const kind = "resident_tax_special_collection_split";
  const asOf = asOfOrToday(input.as_of);
  const basis = [SRC.chihozei_321_5, SRC.chihozei_20_4_2];
  const who = "市区町村の住民税担当・税理士";
  const unit = input.rounding_unit_jpy ?? PAYROLL_JUDGMENT_VALUES.resident_tax.rounding_unit_default_jpy;
  const assumptions = [
    "市区町村から届く特別徴収税額の決定通知書に月割額が書かれている場合は、通知書の額を優先してください（本計算は確認用です）。",
    `分割金額の端数単位は地方税法上100円ですが、条例で異なる定めをした市区町村はその定めによります（今回は${unit}円で計算）。`,
    "特別徴収税額の12分の1を6月から翌年5月まで徴収し、端数は最初の月に寄せます（期日後に通知を受けた場合は通知の翌月から5月までの月数で割ります）。",
  ];
  const annual = input.annual_tax_jpy;
  const first = input.first_month ?? 6;
  if (!isNonNegInt(annual) || !Number.isInteger(first) || first < 1 || first > 12 || !(Number.isInteger(unit) && unit > 0)) {
    return make({ kind, status: "unsupported", result: null, basis, assumptions, as_of: asOf, who_ja: who, message_ja: "年税額・最初の月・端数単位のいずれかが読めません。" });
  }
  if (annual % 100 !== 0) assumptions.push("年税額に100円未満の端数があります。地方税の確定金額は100円未満を切り捨てる（地方税法20条の4の2第3項）ため、通知書の額を確認してください。");
  const months: number[] = [];
  for (let m = first; ; m = (m % 12) + 1) { months.push(m); if (m === 5) break; }
  const n = months.length;
  let amounts: number[];
  if (typeof input.kintowari_jpy === "number" && annual <= input.kintowari_jpy) {
    amounts = months.map((_, i) => (i === 0 ? annual : 0));
  } else {
    const per = Math.floor(annual / (n * unit)) * unit;
    amounts = months.map((_, i) => (i === 0 ? annual - per * (n - 1) : per));
  }
  const monthly = months.map((month, i) => ({ month, amount_jpy: amounts[i] }));
  return make({
    kind, status: "ok", result: { monthly, total_jpy: amounts.reduce((a, b) => a + b, 0) }, basis, assumptions, as_of: asOf, who_ja: who,
    message_ja: `${first}月 ${amounts[0].toLocaleString("ja-JP")}円、以降 ${n > 1 ? amounts[1].toLocaleString("ja-JP") : "0"}円 × ${n - 1}回 です。`,
  });
}

export interface ResidentTaxLeavingInput {
  /** 給与の支払を受けなくなった日 (退職日など) */
  leave_date: string;
  /** その年度の月割額 (splitResidentTaxSpecialCollection の monthly か、通知書の月割額) */
  monthly: Array<{ month: number; amount_jpy: number }>;
  /** その年の5月31日までに支払う給与・退職手当等の額 */
  payable_until_may_jpy: number;
  /** 一括徴収を希望する本人の申出 (6月1日〜12月31日の退職で使う) */
  employee_requested_lump_sum: boolean;
}
export interface ResidentTaxLeavingResult {
  mode: "lump_sum_required" | "lump_sum_by_request" | "switch_to_ordinary" | "none_remaining";
  /** 翌月以降の月割額の合計 (未徴収額) */
  remaining_jpy: number;
  lump_sum_jpy: number;
  reason_ja: string;
}

export function judgeResidentTaxOnLeaving(input: ResidentTaxLeavingInput): TaxSocialJudgment<ResidentTaxLeavingResult> {
  const kind = "resident_tax_on_leaving";
  const asOf = asOfOrToday(input.leave_date);
  const basis = [SRC.chihozei_321_5];
  const who = "市区町村の住民税担当・税理士";
  const assumptions = [
    "給与の支払を受けなくなった月の翌月以降の月割額が未徴収額です。",
    "給与の支払を受けなくなったときは、給与支払報告・特別徴収に係る給与所得者異動届出書を市区町村へ出します（地方税法321条の5第3項）。",
    "一括徴収は、その年の5月31日までに支払う給与・退職手当等が未徴収額を超えるときに限ります。",
  ];
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(input.leave_date));
  if (!m || !Array.isArray(input.monthly)) {
    return make({ kind, status: "unsupported", result: null, basis, assumptions, as_of: asOf, who_ja: who, message_ja: "退職日 (YYYY-MM-DD) か月割額が読めません。" });
  }
  const month = Number(m[2]);
  const ord = (mm: number) => (mm >= 6 ? mm - 6 : mm + 6); // 6月=0 … 5月=11
  const remaining = input.monthly.filter((e) => ord(e.month) > ord(month)).reduce((a, e) => a + e.amount_jpy, 0);
  const R = PAYROLL_JUDGMENT_VALUES.resident_tax;
  const res = (mode: ResidentTaxLeavingResult["mode"], lump: number, reason: string) =>
    make({ kind, status: "ok" as const, result: { mode, remaining_jpy: remaining, lump_sum_jpy: lump, reason_ja: reason }, basis, assumptions, as_of: asOf, who_ja: who, message_ja: reason });
  if (remaining === 0) return res("none_remaining", 0, "翌月以降の月割額が残っていないため、一括徴収も普通徴収への切替もありません。");
  const exceeds = input.payable_until_may_jpy > remaining;
  if ((R.lump_sum_required_months as readonly number[]).includes(month)) {
    return exceeds
      ? res("lump_sum_required", remaining, `1月1日〜4月30日の退職のため、未徴収額 ${remaining.toLocaleString("ja-JP")}円 を最後の給与・退職手当等から一括徴収します（義務）。`)
      : res("switch_to_ordinary", 0, "1月1日〜4月30日の退職ですが、5月31日までに支払う給与等が未徴収額を超えないため一括徴収の義務はありません。残りは普通徴収になります。");
  }
  if ((R.lump_sum_by_request_months as readonly number[]).includes(month)) {
    return input.employee_requested_lump_sum && exceeds
      ? res("lump_sum_by_request", remaining, `本人の申出により、未徴収額 ${remaining.toLocaleString("ja-JP")}円 を一括徴収します。`)
      : res("switch_to_ordinary", 0, "6月1日〜12月31日の退職で一括徴収の申出がない（または支払額が足りない）ため、残りは普通徴収に切り替わります。");
  }
  return res("none_remaining", 0, "翌月以降の月割額はありません。");
}

// ============================================================================
// 7. 算定基礎 (定時決定) / 8. 随時改定
// ============================================================================

export type WorkerType = "general" | "part_timer" | "short_time_tokutei";
export interface TeijiInput {
  /** 'general' 一般 / 'part_timer' 短時間就労者 (パート等) / 'short_time_tokutei' 特定適用事業所の短時間労働者 */
  worker_type: WorkerType;
  months: Array<{ month: number; remuneration_jpy: number; base_days: number }>;
  previous_standard_health_jpy?: number;
  previous_standard_pension_jpy?: number;
  as_of?: string;
}
export interface TeijiResult {
  used_months: number[];
  average_jpy: number | null;
  standard_health_jpy: number | null;
  standard_pension_jpy: number | null;
  fallback_previous: boolean;
}

export function calcTeijiKettei(input: TeijiInput): TaxSocialJudgment<TeijiResult> {
  const kind = "teiji_kettei";
  const S = PAYROLL_JUDGMENT_VALUES.santei;
  const asOf = asOfOrToday(input.as_of);
  const basis = [SRC.nenkin_teiji];
  const who = "社会保険労務士・年金事務所";
  const assumptions = [
    "4月・5月・6月に支払われた報酬と、その支払基礎日数（月給は暦日数、日給・時給は出勤日数）を入力とします。",
    "一般は17日以上の月、特定適用事業所の短時間労働者は11日以上の月を使います。短時間就労者（パート等）は17日以上の月が無ければ15日以上17日未満の月を使います。",
    "使える月が無いときは従前の標準報酬月額で決定します（保険者算定に当たるかは年金事務所の確認が要ります）。",
  ];
  const months = Array.isArray(input.months) ? input.months.filter((m) => [4, 5, 6].includes(m?.month)) : [];
  if (months.length === 0 || months.some((m) => !isNonNegInt(m.remuneration_jpy) || !isNonNegInt(m.base_days))) {
    return make({ kind, status: "unsupported", result: null, basis, assumptions, as_of: asOf, who_ja: who, message_ja: "4〜6月の報酬と支払基礎日数が読めません。" });
  }
  let used = input.worker_type === "short_time_tokutei"
    ? months.filter((m) => m.base_days >= S.base_days_short_time_tokutei)
    : months.filter((m) => m.base_days >= S.base_days_general);
  if (used.length === 0 && input.worker_type === "part_timer") {
    used = months.filter((m) => m.base_days >= S.base_days_part_timer_fallback && m.base_days < S.base_days_general);
  }
  if (used.length === 0) {
    const ph = input.previous_standard_health_jpy ?? null, pp = input.previous_standard_pension_jpy ?? null;
    return make({
      kind, status: "needs_expert",
      result: { used_months: [], average_jpy: null, standard_health_jpy: ph, standard_pension_jpy: pp, fallback_previous: true },
      basis, assumptions, as_of: asOf, who_ja: who,
      message_ja: "支払基礎日数の要件を満たす月が無いため、従前の標準報酬月額で決定します。保険者算定に当たるかを年金事務所に確認してください。",
    });
  }
  const sum = used.reduce((a, m) => a + m.remuneration_jpy, 0);
  const avg = sum / used.length;
  const h = calcStandardRemuneration(avg), p = calcPensionStandardRemuneration(avg);
  return make({
    kind, status: "ok",
    result: { used_months: used.map((m) => m.month), average_jpy: Math.floor(avg), standard_health_jpy: h, standard_pension_jpy: p, fallback_previous: false },
    basis, assumptions, as_of: asOf, who_ja: who,
    message_ja: `${used.map((m) => m.month + "月").join("・")}の平均 ${Math.floor(avg).toLocaleString("ja-JP")}円 から、健康保険 ${h.toLocaleString("ja-JP")}円・厚生年金 ${p.toLocaleString("ja-JP")}円 です。`,
  });
}

export interface ZuijiInput {
  previous_standard_health_jpy: number;
  previous_standard_pension_jpy: number;
  /** 従前の報酬月額 (上限・下限の等級からの改定の特例を判定するときに要る) */
  previous_remuneration_jpy?: number | null;
  /** 固定的賃金が変動した月以後引き続く3か月 */
  months: Array<{ remuneration_jpy: number; base_days: number }>;
  fixed_wage_change: "up" | "down" | "none";
  worker_type: WorkerType;
  as_of?: string;
}
export interface ZuijiSystemResult {
  required: boolean | null;
  grade_before: number;
  grade_after: number;
  grade_diff: number;
  standard_after_jpy: number;
  reason_ja: string;
}
export interface ZuijiResult {
  health: ZuijiSystemResult;
  pension: ZuijiSystemResult;
  notification_required: boolean | null;
  average_jpy: number;
}

function gradeOf(grades: StandardRemunerationGrade[], standard: number): number | null {
  const g = grades.find((x) => x.standard === standard);
  return g ? g.grade : null;
}
function gradeOfAvg(grades: StandardRemunerationGrade[], avg: number): StandardRemunerationGrade {
  let r = grades[0];
  for (const g of grades) if (g.lower_bound === null || avg >= g.lower_bound) r = g;
  return r;
}

export function judgeZuijiKaitei(input: ZuijiInput): TaxSocialJudgment<ZuijiResult> {
  const kind = "zuiji_kaitei";
  const Z = PAYROLL_JUDGMENT_VALUES.zuiji;
  const asOf = asOfOrToday(input.as_of);
  const basis = [SRC.nenkin_zuiji];
  const who = "社会保険労務士・年金事務所";
  const assumptions = [
    "随時改定は(1)固定的賃金の変動 (2)変動月以後3か月の平均による標準報酬月額と従前との2等級以上の差 (3)3か月とも支払基礎日数17日（特定適用事業所の短時間労働者は11日）以上 の3つがそろったときです。",
    "標準報酬月額の上限・下限にわたる等級変更は1等級差でも対象です（日本年金機構の表による）。",
    "固定的賃金の増減と平均額の増減の向きが逆のときは対象外です。遡り昇給の差額は差し引いた額を入力してください。",
  ];
  if (!Array.isArray(input.months) || input.months.length !== 3 || input.months.some((m) => !isNonNegInt(m?.remuneration_jpy) || !isNonNegInt(m?.base_days))) {
    return make({ kind, status: "unsupported", result: null, basis, assumptions, as_of: asOf, who_ja: who, message_ja: "変動月以後3か月の報酬と支払基礎日数が読めません。" });
  }
  const minDays = input.worker_type === "short_time_tokutei" ? PAYROLL_JUDGMENT_VALUES.santei.base_days_short_time_tokutei : PAYROLL_JUDGMENT_VALUES.santei.base_days_general;
  const daysOk = input.months.every((m) => m.base_days >= minDays);
  const avg = input.months.reduce((a, m) => a + m.remuneration_jpy, 0) / 3;
  let needsExpert = false;
  const judge = (sys: "health" | "pension", grades: StandardRemunerationGrade[], prevStd: number): ZuijiSystemResult | null => {
    const before = gradeOf(grades, prevStd);
    if (before === null) return null;
    const after = gradeOfAvg(grades, avg);
    const diff = after.grade - before;
    const top = grades[grades.length - 1].grade;
    const cf = Z.cap_floor[sys];
    const base = { grade_before: before, grade_after: after.grade, grade_diff: diff, standard_after_jpy: after.standard };
    if (input.fixed_wage_change === "none") return { ...base, required: false, reason_ja: "固定的賃金の変動が無いため対象外です。" };
    if ((input.fixed_wage_change === "up" && diff <= 0) || (input.fixed_wage_change === "down" && diff >= 0)) {
      return { ...base, required: false, reason_ja: "固定的賃金の増減と平均額の増減の向きが逆（または等級が変わらない）ため対象外です。" };
    }
    if (!daysOk) return { ...base, required: false, reason_ja: `3か月のうち支払基礎日数が${minDays}日未満の月があるため対象外です。` };
    if (Math.abs(diff) >= Z.grade_diff_required) return { ...base, required: true, reason_ja: `${Math.abs(diff)}等級の差があるため随時改定の対象です。` };
    // 1等級差の特例 (上限・下限にわたる等級変更)
    const prevRem = input.previous_remuneration_jpy;
    if (diff === 1 && before === top - 1 && after.grade === top) {
      return avg >= cf.top_up_avg_min
        ? { ...base, required: true, reason_ja: `上限等級への1等級差で、平均額が${cf.top_up_avg_min.toLocaleString("ja-JP")}円以上のため対象です。` }
        : { ...base, required: false, reason_ja: `上限等級への1等級差ですが、平均額が${cf.top_up_avg_min.toLocaleString("ja-JP")}円未満のため対象外です。` };
    }
    if (diff === -1 && before === top && after.grade === top - 1) {
      if (!(typeof prevRem === "number")) { needsExpert = true; return { ...base, required: null, reason_ja: "上限等級からの1等級差です。従前の報酬月額が分からないため特例に当たるか判定できません。" }; }
      return prevRem >= cf.top_up_avg_min
        ? { ...base, required: true, reason_ja: `上限等級（従前の報酬月額${cf.top_up_avg_min.toLocaleString("ja-JP")}円以上）からの1等級差のため対象です。` }
        : { ...base, required: false, reason_ja: "上限等級からの1等級差ですが、従前の報酬月額が特例の条件に当たらないため対象外です。" };
    }
    if (diff === 1 && before === 1 && after.grade === 2) {
      if (!(typeof prevRem === "number")) { needsExpert = true; return { ...base, required: null, reason_ja: "下限等級からの1等級差です。従前の報酬月額が分からないため特例に当たるか判定できません。" }; }
      return prevRem < cf.bottom_prev_rem_below
        ? { ...base, required: true, reason_ja: `下限等級（従前の報酬月額${cf.bottom_prev_rem_below.toLocaleString("ja-JP")}円未満）からの1等級差のため対象です。` }
        : { ...base, required: false, reason_ja: "下限等級からの1等級差ですが、従前の報酬月額が特例の条件に当たらないため対象外です。" };
    }
    if (diff === -1 && before === 2 && after.grade === 1) {
      return avg < cf.bottom_prev_rem_below
        ? { ...base, required: true, reason_ja: `下限等級への1等級差で、平均額が${cf.bottom_prev_rem_below.toLocaleString("ja-JP")}円未満のため対象です。` }
        : { ...base, required: false, reason_ja: "下限等級への1等級差ですが、平均額が特例の条件に当たらないため対象外です。" };
    }
    return { ...base, required: false, reason_ja: "1等級差のため対象外です（月額変更届は要りません）。" };
  };
  const h = judge("health", HEALTH_INSURANCE_GRADES, input.previous_standard_health_jpy);
  const p = judge("pension", PENSION_INSURANCE_GRADES, input.previous_standard_pension_jpy);
  if (!h || !p) {
    return make({ kind, status: "unsupported", result: null, basis, assumptions, as_of: asOf, who_ja: who, message_ja: "従前の標準報酬月額が等級表の値ではありません。" });
  }
  const notif = h.required === true || p.required === true ? true : h.required === null || p.required === null ? null : false;
  const msg = notif === true
    ? `随時改定の対象です（健康保険: ${h.reason_ja} 厚生年金: ${p.reason_ja}）。月額変更届を提出します。`
    : notif === false
      ? `随時改定の対象ではありません（健康保険: ${h.reason_ja} 厚生年金: ${p.reason_ja}）。`
      : `随時改定に当たるか判定できない制度があります（健康保険: ${h.reason_ja} 厚生年金: ${p.reason_ja}）。`;
  return make({
    kind, status: needsExpert ? "needs_expert" : "ok",
    result: { health: h, pension: p, notification_required: notif, average_jpy: Math.floor(avg) },
    basis, assumptions, as_of: asOf, who_ja: who, message_ja: msg,
  });
}

// ============================================================================
// 9. 士業報酬の源泉徴収
// ============================================================================

/** 所得税法204条1項2号・施行令320条2項の士業と、計算の型 (205条1号=段階 / 205条2号=1万円控除) */
export const PROFESSIONAL_FEE_KINDS: Readonly<Record<string, { label_ja: string; type: "tiered" | "deduct10k" }>> = {
  bengoshi: { label_ja: "弁護士", type: "tiered" },
  gaikokuho_jimu_bengoshi: { label_ja: "外国法事務弁護士", type: "tiered" },
  kounin_kaikeishi: { label_ja: "公認会計士", type: "tiered" },
  zeirishi: { label_ja: "税理士", type: "tiered" },
  sharoushi: { label_ja: "社会保険労務士", type: "tiered" },
  benrishi: { label_ja: "弁理士", type: "tiered" },
  sokuryoshi: { label_ja: "測量士", type: "tiered" },
  kenchikushi: { label_ja: "建築士", type: "tiered" },
  fudosan_kanteishi: { label_ja: "不動産鑑定士", type: "tiered" },
  gijutsushi: { label_ja: "技術士", type: "tiered" },
  keirishi: { label_ja: "計理士", type: "tiered" },
  kaikeishi_ho: { label_ja: "会計士補", type: "tiered" },
  kigyo_shindanin: { label_ja: "企業診断員", type: "tiered" },
  sokuryoshi_ho: { label_ja: "測量士補", type: "tiered" },
  kenchiku_dairishi: { label_ja: "建築代理士", type: "tiered" },
  fudosan_kanteishi_ho: { label_ja: "不動産鑑定士補", type: "tiered" },
  kasai_songai_kanteinin: { label_ja: "火災損害鑑定人", type: "tiered" },
  jidosha_songai_kanteinin: { label_ja: "自動車等損害鑑定人", type: "tiered" },
  gijutsushi_ho: { label_ja: "技術士補", type: "tiered" },
  shiho_shoshi: { label_ja: "司法書士", type: "deduct10k" },
  tochi_kaoku_chosashi: { label_ja: "土地家屋調査士", type: "deduct10k" },
  kaiji_dairishi: { label_ja: "海事代理士", type: "deduct10k" },
};

export interface ProfessionalFeeInput { profession: string; amount_jpy: number; pay_date: string; }
export interface ProfessionalFeeResult {
  profession_ja: string;
  withholding_jpy: number;
  net_jpy: number;
  tax_names_ja: string;
  formula_ja: string;
}

export function calcProfessionalFeeWithholding(input: ProfessionalFeeInput): TaxSocialJudgment<ProfessionalFeeResult> {
  const kind = "professional_fee_withholding";
  const P = PAYROLL_JUDGMENT_VALUES.professional_fee;
  const asOf = asOfOrToday(input.pay_date);
  const basis = [SRC.shotoku_204, SRC.nta_2798, SRC.nta_kaisei2026];
  const who = "税理士";
  const assumptions = [
    "居住者である士業個人への報酬・料金の支払で、給与等に当たらないものとして計算します（法人への支払は源泉徴収の対象外です）。",
    "請求書等で報酬・料金と消費税等の額が明確に区分されていれば税抜の額を、区分されていなければ税込の額を入力してください。",
    "支払者が国等へ直接納付する登録免許税・手数料に充てるものとして明らかに区分された額は含めません。",
    "100万円・1万円の判定は同一人に対する1回の支払金額で行います。",
    "令和9年1月1日以後は防衛特別所得税が加わりますが、合計税率（所得税率×102.1%）は変わりません。",
  ];
  const kindDef = PROFESSIONAL_FEE_KINDS[input.profession];
  if (!kindDef) {
    return make({ kind, status: "unsupported", result: null, basis, assumptions, as_of: asOf, who_ja: who,
      message_ja: `「${String(input.profession)}」は所得税法204条1項2号の士業の一覧にありません。源泉徴収の要否を税理士に確認してください（0円として扱いません）。` });
  }
  if (!(typeof input.pay_date === "string" && DATE_RE.test(input.pay_date)) || input.pay_date > P.supported_until || input.pay_date < "2013-01-01") {
    return make({ kind, status: "unsupported", result: null, basis, assumptions, as_of: asOf, who_ja: who, message_ja: "支払日が読めないか、合計税率を確かめている期間 (2013-01-01〜2047-12-31) の外です。" });
  }
  const A = input.amount_jpy;
  if (!isNonNegInt(A)) {
    return make({ kind, status: "unsupported", result: null, basis, assumptions, as_of: asOf, who_ja: who, message_ja: "支払金額 (円の整数) が読めません。" });
  }
  let tax: number, formula: string;
  if (kindDef.type === "deduct10k") {
    tax = Math.floor((Math.max(0, A - P.judicial_deduction_jpy) * P.rate_low_per10k) / 10000);
    formula = "（1回の支払金額 − 1万円）× 10.21%（1円未満切捨て）";
  } else if (A <= P.tier_threshold_jpy) {
    tax = Math.floor((A * P.rate_low_per10k) / 10000);
    formula = "支払金額 × 10.21%（1円未満切捨て）";
  } else {
    tax = Math.floor(((A - P.tier_threshold_jpy) * P.rate_high_per10k + P.tier_threshold_jpy * P.rate_low_per10k) / 10000);
    formula = "（支払金額 − 100万円）× 20.42% + 102,100円（1円未満切捨て）";
  }
  const names = input.pay_date >= P.defense_tax_from ? P.tax_names_from_2027_ja : P.tax_names_before_ja;
  return make({
    kind, status: "ok",
    result: { profession_ja: kindDef.label_ja, withholding_jpy: tax, net_jpy: A - tax, tax_names_ja: names, formula_ja: formula },
    basis, assumptions, as_of: asOf, who_ja: who,
    message_ja: `${kindDef.label_ja}への報酬 ${A.toLocaleString("ja-JP")}円 から源泉徴収する${names}は ${tax.toLocaleString("ja-JP")}円 です。`,
  });
}
