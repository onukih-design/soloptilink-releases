/**
 * 給与所得の源泉徴収税額 — 支払日の年分の表を引く部品と、電算機計算の特例 (財務省告示) の計算
 *
 * ★源泉徴収税額表は暦年単位 (「令和N年分」) で、どの年分の表を使うかは【給与の支払日】で決まる。
 *   2026-12-31 支払 → 令和8年分 / 2027-01-01 支払 → 令和9年分 (国税庁「令和9年分 源泉徴収税額表」の
 *   注意書き「令和8年分以前の給与等について税額を算出する際には、この税額表はご使用にならないでください」)。
 * ★取り込んでいない年分 (令和7年分以前・令和10年分以後) は、旧い表で計算し続けずに「対応していない」を返す。
 *
 * 【出典 — 一次情報】
 *   国税庁「令和8年分 源泉徴収税額表」 https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2026/01.htm
 *   国税庁「令和9年分 源泉徴収税額表」 https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2027/01.htm
 *   電算機計算の特例 (令和8年分) https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2026/data/denshi_01.pdf
 *   電算機計算の特例 (令和9年分以降) https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2027/data/denshi_01.pdf
 */
import {
  WITHHOLDING_TAX_TABLE_META,
  GENSEN_MONTHLY_BRACKETS_R8,
  GENSEN_MONTHLY_BOUNDARIES_R8,
  GENSEN_KOU_SEGMENTS_R8,
  GENSEN_OTSU_SEGMENTS_R8,
  GENSEN_UNDER_THRESHOLD_R8,
  GENSEN_OTSU_UNDER_RATE_R8,
  GENSEN_EXTRA_DEPENDENT_DEDUCTION_R8,
} from "./gensen_tax_table_r8";
import {
  WITHHOLDING_TAX_TABLE_META_R9,
  GENSEN_MONTHLY_BRACKETS_R9,
  GENSEN_MONTHLY_BOUNDARIES_R9,
  GENSEN_KOU_SEGMENTS_R9,
  GENSEN_OTSU_SEGMENTS_R9,
  GENSEN_UNDER_THRESHOLD_R9,
  GENSEN_OTSU_UNDER_RATE_R9,
  GENSEN_EXTRA_DEPENDENT_DEDUCTION_R9,
} from "./gensen_tax_table_r9";

/** 年分ごとの月額表 (同じ形にそろえたもの) */
export interface MonthlyWithholdingTable {
  year: number;
  year_ja: string;
  source_url: string;
  legal_basis_ja: string;
  /** 源泉徴収する税目の名称 (令和9年分から防衛特別所得税が加わる) */
  tax_names_ja: string;
  brackets: ReadonlyArray<readonly [number, number, readonly number[], number]>;
  boundaries: ReadonlyArray<{ amount: number; kou: readonly number[]; otsu: number | null }>;
  kou_segments: ReadonlyArray<{ over: number; until: number | null; rate: number }>;
  otsu_segments: ReadonlyArray<{ over: number; until: number | null; base?: number; rate: number }>;
  under_threshold: number;
  otsu_under_rate: number;
  extra_dependent_deduction: number;
}

/** 取り込み済みの月額表 (年分 → 表)。年分を足すときはここへ1行足す。 */
export const MONTHLY_WITHHOLDING_TABLES: Readonly<Record<number, MonthlyWithholdingTable>> = {
  2026: {
    year: 2026,
    year_ja: WITHHOLDING_TAX_TABLE_META.applied_year_ja,
    source_url: WITHHOLDING_TAX_TABLE_META.source_url,
    legal_basis_ja: WITHHOLDING_TAX_TABLE_META.legal_basis_ja,
    tax_names_ja: "所得税及び復興特別所得税",
    brackets: GENSEN_MONTHLY_BRACKETS_R8,
    boundaries: GENSEN_MONTHLY_BOUNDARIES_R8,
    kou_segments: GENSEN_KOU_SEGMENTS_R8,
    otsu_segments: GENSEN_OTSU_SEGMENTS_R8,
    under_threshold: GENSEN_UNDER_THRESHOLD_R8,
    otsu_under_rate: GENSEN_OTSU_UNDER_RATE_R8,
    extra_dependent_deduction: GENSEN_EXTRA_DEPENDENT_DEDUCTION_R8,
  },
  2027: {
    year: 2027,
    year_ja: WITHHOLDING_TAX_TABLE_META_R9.applied_year_ja,
    source_url: WITHHOLDING_TAX_TABLE_META_R9.source_url,
    legal_basis_ja: WITHHOLDING_TAX_TABLE_META_R9.legal_basis_ja,
    tax_names_ja: WITHHOLDING_TAX_TABLE_META_R9.tax_names_ja,
    brackets: GENSEN_MONTHLY_BRACKETS_R9,
    boundaries: GENSEN_MONTHLY_BOUNDARIES_R9,
    kou_segments: GENSEN_KOU_SEGMENTS_R9,
    otsu_segments: GENSEN_OTSU_SEGMENTS_R9,
    under_threshold: GENSEN_UNDER_THRESHOLD_R9,
    otsu_under_rate: GENSEN_OTSU_UNDER_RATE_R9,
    extra_dependent_deduction: GENSEN_EXTRA_DEPENDENT_DEDUCTION_R9,
  },
};

/** 取り込み済みの年分 (昇順) */
export const SUPPORTED_WITHHOLDING_YEARS: readonly number[] = Object.keys(MONTHLY_WITHHOLDING_TABLES)
  .map(Number)
  .sort((a, b) => a - b);

/** 対応していない年分を求められたときに投げる例外 (旧い表で黙って計算しないため) */
export class WithholdingTableUnsupportedError extends Error {
  constructor(public readonly year: number) {
    super(
      `令和${year - 2018}年分 (${year}年支払) の源泉徴収税額表は取り込んでいないため、源泉所得税を計算できません。` +
      `国税庁の「令和${year - 2018}年分 源泉徴収税額表」を取り込むまで、旧い年分の表では計算しません。`,
    );
    this.name = "WithholdingTableUnsupportedError";
  }
}

/** 支払日 (YYYY-MM-DD) から年分を取り出す。形式が違えば例外。 */
export function withholdingYearOfPayDate(payDate: string): number {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(payDate));
  if (!m) throw new Error(`支払日は YYYY-MM-DD の形で指定してください (受け取った値: ${JSON.stringify(payDate)})。`);
  return Number(m[1]);
}

/** 率 (例 0.2042) を 1/100000 の整数にする。表の率は小数第5位までなので誤差は出ない。 */
const ratePer100k = (rate: number) => Math.round(rate * 100000);

/**
 * 月額表を引いて源泉徴収税額を求める (年分の表を引数で受け取る共通の算出)。
 * 算出規則は国税庁「給与所得の源泉徴収税額の求め方」と表の備考による:
 *  - 税額0円の上限未満: 甲欄0円 / 乙欄はその月の社会保険料等控除後の給与等の金額の3.063% (1円未満切捨て)
 *  - 区間の表: 該当区間の額 / 境界金額ちょうど: 表に明示された額
 *  - 数式帯: 下端ちょうどの税額 + 超過分×率 (1円未満切捨て)
 *  - 扶養親族等が7人を超える場合: 7人の税額から1人ごとに1,610円を控除 (甲欄)
 */
export function calcWithholdingFromTable(
  table: MonthlyWithholdingTable,
  monthlyTaxable: number,
  numDependents: number = 0,
  column: "kou" | "otsu" = "kou",
): number {
  const x = Math.floor(monthlyTaxable);
  if (!(x > 0)) return 0;
  const dep = Math.max(0, Math.floor(numDependents));
  const d = Math.min(dep, 7);
  const extra = column === "kou" && dep > 7 ? (dep - 7) * table.extra_dependent_deduction : 0;
  const finish = (tax: number) => Math.max(0, tax - extra);

  if (x < table.under_threshold) {
    return column === "kou" ? 0 : Math.floor((x * ratePer100k(table.otsu_under_rate)) / 100000);
  }
  for (const [lo, hi, kou, otsu] of table.brackets) {
    if (x >= lo && x < hi) return finish(column === "kou" ? kou[d] : otsu);
  }
  const boundary = table.boundaries.find((b) => b.amount === x);
  if (boundary) {
    if (column === "kou") return finish(boundary.kou[d]);
    if (boundary.otsu !== null) return boundary.otsu;
  }
  if (column === "kou") {
    for (const seg of table.kou_segments) {
      if (x > seg.over && (seg.until === null || x < seg.until)) {
        const base = table.boundaries.find((b) => b.amount === seg.over);
        if (!base) break;
        return finish(base.kou[d] + Math.floor(((x - seg.over) * ratePer100k(seg.rate)) / 100000));
      }
    }
  } else {
    for (const seg of table.otsu_segments) {
      if (x >= seg.over && (seg.until === null || x < seg.until)) {
        const base = seg.base ?? table.boundaries.find((b) => b.amount === seg.over)?.otsu;
        if (base == null) break;
        return base + Math.floor(((x - seg.over) * ratePer100k(seg.rate)) / 100000);
      }
    }
  }
  throw new Error(
    `源泉徴収税額表マスタ (${table.year_ja}) から税額を求められませんでした (対象額 ${x.toLocaleString("ja-JP")}円)。` +
    "マスタの破損が疑われます。",
  );
}

/** 支払日の年分の表で源泉徴収税額を求める。対応していない年分は WithholdingTableUnsupportedError。 */
export function calcWithholdingTaxByPayYear(
  year: number,
  monthlyTaxable: number,
  numDependents: number = 0,
  column: "kou" | "otsu" = "kou",
): number {
  const table = MONTHLY_WITHHOLDING_TABLES[year];
  if (!table) throw new WithholdingTableUnsupportedError(year);
  return calcWithholdingFromTable(table, monthlyTaxable, numDependents, column);
}

/**
 * 電算機計算の特例 (月額表の甲欄を適用する給与等に限る) の値表 — 財務省告示の第1〜4表。
 * 年分で変わるのは第1表の最初の段 (給与所得控除の定額) と第3表の最初の段 (基礎控除の額) だけ。
 *   令和8年分: 158,333円以下 → 54,167円 / 基礎控除 48,334円
 *   令和9年分以降: 169,444円以下 → 57,500円 / 基礎控除 51,667円
 */
export const DENZANKI_PARAMS: Readonly<Record<number, {
  year_ja: string;
  source_url: string;
  /** 第1表: [以下の上限, 給与所得控除の算式] — 算式は (A×pct/100 + add) の1円未満切上げ、または定額 */
  kyuyo: ReadonlyArray<{ upTo: number | null; pct: number; add: number; flat: number | null }>;
  /** 第2表: 配偶者控除・扶養控除の額 (1人あたり) */
  per_dependent: number;
  /** 第3表: [以下の上限, 基礎控除の額] */
  basic: ReadonlyArray<{ upTo: number | null; amount: number }>;
  /** 第4表: [以下の上限, 率 (1/100000), 控除額] — 税額は10円未満四捨五入 */
  tax: ReadonlyArray<{ upTo: number | null; rate100k: number; minus: number }>;
}>> = (() => {
  const tax = [
    { upTo: 162500, rate100k: 5105, minus: 0 },
    { upTo: 275000, rate100k: 10210, minus: 8296 },
    { upTo: 579166, rate100k: 20420, minus: 36374 },
    { upTo: 750000, rate100k: 23483, minus: 54113 },
    { upTo: 1500000, rate100k: 33693, minus: 130688 },
    { upTo: 3333333, rate100k: 40840, minus: 237893 },
    { upTo: null, rate100k: 45945, minus: 408061 },
  ];
  const kyuyoRest = [
    { upTo: 299999, pct: 30, add: 6667, flat: null },
    { upTo: 549999, pct: 20, add: 36667, flat: null },
    { upTo: 708330, pct: 10, add: 91667, flat: null },
    { upTo: null, pct: 0, add: 0, flat: 162500 },
  ];
  const basicRest = [
    { upTo: 2162499, amount: 40000 },
    { upTo: 2204166, amount: 26667 },
    { upTo: 2245833, amount: 13334 },
    { upTo: null, amount: 0 },
  ];
  return {
    2026: {
      year_ja: "令和8年分",
      source_url: "https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2026/data/denshi_01.pdf",
      kyuyo: [{ upTo: 158333, pct: 0, add: 0, flat: 54167 }, ...kyuyoRest],
      per_dependent: 31667,
      basic: [{ upTo: 2120833, amount: 48334 }, ...basicRest],
      tax,
    },
    2027: {
      year_ja: "令和9年分",
      source_url: "https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2027/data/denshi_01.pdf",
      kyuyo: [{ upTo: 169444, pct: 0, add: 0, flat: 57500 }, ...kyuyoRest],
      per_dependent: 31667,
      basic: [{ upTo: 2120833, amount: 51667 }, ...basicRest],
      tax,
    },
  };
})();

/**
 * 電算機計算の特例による源泉徴収税額 (甲欄のみ)。
 * 税額 = 第4表の算式 (その月の課税給与所得金額 B) を10円未満四捨五入。
 *   B = A − 給与所得控除 (第1表・1円未満切上げ) − 31,667円×扶養親族等の数 (第2表) − 基礎控除 (第3表)
 * ★月額表の税額と一致しないことがある (差は年末調整で精算) — 告示の説明どおり。
 * @throws 対応していない年分
 */
export function calcDenzankiWithholdingTax(year: number, monthlyTaxable: number, numDependents: number = 0): number {
  const p = DENZANKI_PARAMS[year];
  if (!p) throw new WithholdingTableUnsupportedError(year);
  const A = Math.floor(monthlyTaxable);
  if (!(A > 0)) return 0;
  const deps = Math.max(0, Math.floor(numDependents));
  const kRow = p.kyuyo.find((r) => r.upTo === null || A <= r.upTo)!;
  const kyuyo = kRow.flat !== null ? kRow.flat : Math.ceil((A * kRow.pct + kRow.add * 100) / 100);
  const basic = p.basic.find((r) => r.upTo === null || A <= r.upTo)!.amount;
  const B = A - kyuyo - p.per_dependent * deps - basic;
  if (B <= 0) return 0;
  const t = p.tax.find((r) => r.upTo === null || B <= r.upTo)!;
  const num = B * t.rate100k - t.minus * 100000; // 1/100000 円
  if (num <= 0) return 0;
  return Math.floor((num + 500000) / 1000000) * 10; // 10円未満四捨五入
}
