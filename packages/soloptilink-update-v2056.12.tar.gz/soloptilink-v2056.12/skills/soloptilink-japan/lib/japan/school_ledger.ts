/**
 * lib/japan/school_ledger.ts — 学校の年度別の値と暦（就学支援金・給食費の国の支援・指導要録・出席停止・学校暦/入試暦・学校法人会計）
 *
 * 2026-10-04 新設（日本最適化 T32・REQ-139）。値は年度ごとの版つきで持ち、出典URL・確認日を付ける。
 * 一次資料で確かめていない値は作らず「確認できていない（unconfirmed）」を返す。
 *
 * 出典（2026-10-03 取得）:
 *  - e-Gov 高等学校等就学支援金の支給に関する法律（422AC0000000018）2025-06-01版・2026-04-01版、同施行令（422CO0000000112）2023-04-01版・2026-04-01版
 *  - 財務省 令和8年度文教・科学技術予算（政府案）— 給食費の負担軽減（公立小学校 児童1人当たり月5,200円）
 *  - e-Gov 学校教育法施行規則（322M40000080011）第24条・第28条
 *  - e-Gov 学校保健安全法施行規則（333M50000080018）第19条／民法第140条（初日不算入）
 *  - 大学入試センター「令和9年度試験」
 *  - e-Gov 学校法人会計基準（346M50000080018）2025-04-01版
 */

const EGOV = 'https://laws.e-gov.go.jp/law/';

function ymdAdd(ymd: string, days: number): string {
  const [y, m, d] = ymd.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1, d) + days * 86400000);
  return `${t.getUTCFullYear()}-${String(t.getUTCMonth() + 1).padStart(2, '0')}-${String(t.getUTCDate()).padStart(2, '0')}`;
}
function ymdDiff(from: string, to: string): number {
  const [y1, m1, d1] = from.split('-').map(Number);
  const [y2, m2, d2] = to.split('-').map(Number);
  return Math.round((Date.UTC(y2, m2 - 1, d2) - Date.UTC(y1, m1 - 1, d1)) / 86400000);
}
function toYmd(d: Date | string): string {
  if (typeof d === 'string') return d.slice(0, 10);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// ============================================================================
// 1. 高等学校等就学支援金（年度別。令和8年4月分から収入要件の撤廃・私立の上限引上げ）
// ============================================================================

export type ShugakuSetter = 'national' | 'public' | 'private';

/**
 * 支給限度額（月額・全日制の高等学校等）の版。
 *   R8: 施行令2条（2026-04-01版）— 国 9,600円・地方公共団体 9,900円・国及び地方公共団体以外 38,100円。収入要件なし。
 *   R5〜R7: 施行令（2023-04-01版）— 3条1号 9,900円（国立大学法人立は9,600円）、4条2項 算定基準額154,500円未満の私立は 9,900×(1+7/3)=33,000円、
 *           1条2項 算定基準額304,200円以上は支給対象外。
 */
export const SHUGAKU_SHIENKIN_VERSIONS = Object.freeze([
  {
    version: 'R8', fromMonth: '2026-04', toMonth: null as string | null,
    monthlyLimitJpy: { national: 9_600, public: 9_900, private: 38_100 },
    incomeRequirement: null,
    sourceUrl: `${EGOV}422CO0000000112`, checkedAt: '2026-10-03',
  },
  {
    version: 'R5-R7', fromMonth: '2023-04', toMonth: '2026-03' as string | null,
    monthlyLimitJpy: { national: 9_600, public: 9_900, private: 9_900 },
    incomeRequirement: { ineligibleAtOrAboveJpy: 304_200, privateAdditionBelowJpy: 154_500, privateAdditionMonthlyJpy: 33_000 },
    sourceUrl: `${EGOV}422CO0000000112`, checkedAt: '2026-10-03',
  },
]);

/**
 * 就学支援金の年額の見込み（全日制・授業料は年額で入力）。
 *   ★授業料の年額から月額への換算は文部科学省令による（本部品は年額で上限と比べる簡易計算。月ごとの端数は要確認）。
 *   ★令和7年度に所得制限で対象外の世帯への「高校生等臨時支援金」（予算事業）は法令の外のため本部品の対象外（要確認）。
 *   ★令和8年4月の施行日前から在学する者のうち新法3条1項に当たらない者は従前の例（附則2条2項）。本部品は新法の対象者として計算する。
 */
export function calcShugakuShienkin(input: { month: string; setter: ShugakuSetter; annualTuitionJpy: number; santeiKijungakuJpy?: number }) {
  const month = input.month.slice(0, 7);
  const v = SHUGAKU_SHIENKIN_VERSIONS.find((x) => x.fromMonth <= month && (x.toMonth === null || month <= x.toMonth));
  if (!v) return { status: 'unconfirmed' as const, annualSupportJpy: null, selfPayJpy: null, reason: `${month} の支給限度額は本部品に収録していません（要一次確認）` };
  let monthly = v.monthlyLimitJpy[input.setter];
  const notes: string[] = [];
  if (v.incomeRequirement) {
    const ir = v.incomeRequirement;
    if (input.santeiKijungakuJpy == null) {
      return { status: 'unconfirmed' as const, version: v.version, annualSupportJpy: null, selfPayJpy: null, reason: '令和7年度以前は算定基準額（市町村民税の課税標準額×6%−調整控除額）で支給額が変わります。算定基準額を入力してください' };
    }
    if (input.santeiKijungakuJpy >= ir.ineligibleAtOrAboveJpy) {
      return { status: 'not_eligible' as const, version: v.version, annualSupportJpy: 0, selfPayJpy: input.annualTuitionJpy, reason: `算定基準額 ${ir.ineligibleAtOrAboveJpy.toLocaleString()}円以上のため法令上は支給対象外です（令和7年度の高校生等臨時支援金は本部品の対象外・要確認）`, sourceUrl: v.sourceUrl };
    }
    if (input.setter === 'private' && input.santeiKijungakuJpy < ir.privateAdditionBelowJpy) {
      monthly = ir.privateAdditionMonthlyJpy;
      notes.push('私立の加算（算定基準額154,500円未満）を適用');
    }
  }
  const annualLimit = monthly * 12;
  const annualSupportJpy = Math.min(input.annualTuitionJpy, annualLimit);
  return { status: 'confirmed' as const, version: v.version, monthlyLimitJpy: monthly, annualLimitJpy: annualLimit, annualSupportJpy, selfPayJpy: input.annualTuitionJpy - annualSupportJpy, notes, sourceUrl: v.sourceUrl, checkedAt: v.checkedAt };
}

// ============================================================================
// 2. 給食費の国の支援（令和8年度から 公立小学校 児童1人当たり月5,200円を基準額に支援）
// ============================================================================

export const KYUSHOKU_NATIONAL_SUPPORT = Object.freeze([
  {
    fiscalYear: 2026, schoolType: 'public_elementary', monthlyBaseJpy: 5_200,
    status: '二次' as const, // 予算の政府案の資料。交付要綱（文部科学省）での確認は要一次確認
    sourceUrl: 'https://www.mof.go.jp/policy/budget/budger_workflow/budget/fy2026/seifuan2026/12.pdf', checkedAt: '2026-10-03',
    note: '自治体への交付の基準額であり、保護者への給付額・全国一律の給食費の上限ではない。基準額を超える分の扱いは自治体による',
  },
]);

export function getKyushokuNationalSupport(input: { fiscalYear: number; schoolType: 'public_elementary' | 'public_junior_high' | 'private' | string }) {
  const row = KYUSHOKU_NATIONAL_SUPPORT.find((r) => r.fiscalYear === input.fiscalYear && r.schoolType === input.schoolType);
  if (row) return { status: 'confirmed' as const, monthlyBaseJpy: row.monthlyBaseJpy, sourceStatus: row.status, sourceUrl: row.sourceUrl, checkedAt: row.checkedAt, note: row.note };
  if (input.fiscalYear === 2026) return { status: 'not_covered' as const, monthlyBaseJpy: null, reason: '令和8年度の国の支援の対象は給食を実施する公立小学校です（中学校等は対象外。自治体独自の支援は別途確認）' };
  return { status: 'unconfirmed' as const, monthlyBaseJpy: null, reason: `${input.fiscalYear}年度の国の給食費支援は本部品に収録していません（要一次確認）` };
}

// ============================================================================
// 3. 指導要録の保存（学校教育法施行規則28条2項）
// ============================================================================

export function getShidoYorokuRetention() {
  return {
    gakusekiYears: 20, // 入学・卒業等の学籍に関する記録
    shidoYears: 5, // その他（指導に関する記録）
    startDate: { status: 'unconfirmed' as const, display: '要確認', reason: '起算日は施行規則に明記が無く、文部科学省の通知・設置者の規程で確認してください' },
    transfer: '進学・転学時は抄本又は写しを送付（施行規則24条2項・3項）',
    sourceUrl: `${EGOV}322M40000080011`, checkedAt: '2026-10-03',
  };
}

// ============================================================================
// 4. 出席停止の期間（学校保健安全法施行規則19条）
// ============================================================================

/**
 * 出席停止の期間。「○日を経過するまで」は民法140条（初日不算入）で数え、経過した翌日を出席可能日とする。
 *   ★医師が感染のおそれがないと認めたときはこの限りでない（19条2号ただし書）。最終判断は学校医等。
 *   日数の数え方は文部科学省の解説資料での確認が要確認。
 */
export function calcShussekiTeishi(input: { disease: 'influenza' | 'covid19' | 'measles'; onsetDate: string; feverResolvedDate?: string; symptomImprovedDate?: string; isPreschool?: boolean }) {
  const elapsedNext = (ymd: string, days: number) => ymdAdd(ymd, days + 1);
  const candidates: string[] = [];
  let basis = '';
  if (input.disease === 'influenza') {
    if (!input.feverResolvedDate) return { status: 'unconfirmed' as const, earliestReturnDate: null, reason: '解熱した日を入力してください' };
    candidates.push(elapsedNext(input.onsetDate, 5), elapsedNext(input.feverResolvedDate, input.isPreschool ? 3 : 2));
    basis = '発症した後5日を経過し、かつ、解熱した後2日（幼児は3日）を経過するまで（施行規則19条2号イ）';
  } else if (input.disease === 'covid19') {
    if (!input.symptomImprovedDate) return { status: 'unconfirmed' as const, earliestReturnDate: null, reason: '症状が軽快した日を入力してください' };
    candidates.push(elapsedNext(input.onsetDate, 5), elapsedNext(input.symptomImprovedDate, 1));
    basis = '発症した後5日を経過し、かつ、症状が軽快した後1日を経過するまで（施行規則19条2号チ）';
  } else if (input.disease === 'measles') {
    if (!input.feverResolvedDate) return { status: 'unconfirmed' as const, earliestReturnDate: null, reason: '解熱した日を入力してください' };
    candidates.push(elapsedNext(input.feverResolvedDate, 3));
    basis = '解熱した後3日を経過するまで（施行規則19条2号ハ）';
  }
  const earliestReturnDate = candidates.sort().slice(-1)[0];
  return { status: 'confirmed' as const, earliestReturnDate, basis, countingNote: '初日不算入（民法140条）で数えています。数え方の最終確認は要確認。医師が認めた場合はこの限りでない', sourceUrl: `${EGOV}333M50000080018`, checkedAt: '2026-10-03' };
}

// ============================================================================
// 5. 入試暦・学校暦（出典URLと確認日つき。古い暦に警告）
// ============================================================================

export const EXAM_CALENDAR = Object.freeze([
  {
    exam: 'kyotsu_test', examYear: 2027, label: '令和9年度 大学入学共通テスト',
    main: ['2027-01-16', '2027-01-17'], makeup: ['2027-01-23', '2027-01-24'],
    sourceUrl: 'https://www.dnc.ac.jp/kyotsu/shiken_jouhou/r9/', checkedAt: '2026-10-03',
  },
]);

export function getExamCalendar(exam: string, examYear: number) {
  const r = EXAM_CALENDAR.find((e) => e.exam === exam && e.examYear === examYear);
  if (!r) return { status: 'unconfirmed' as const, main: null, makeup: null, reason: `${examYear}年の ${exam} の日程は収録していません。実施機関の公表を確認してください` };
  return { status: 'confirmed' as const, label: r.label, main: [...r.main], makeup: [...r.makeup], sourceUrl: r.sourceUrl, checkedAt: r.checkedAt };
}

/** 暦の鮮度検査: 出典URL・確認日の無い暦は誤り、確認日から maxAgeDays（既定365日）を超えた暦は警告 */
export function checkCalendarFreshness(entries: Array<{ id: string; kind?: string; sourceUrl?: string; checkedAt?: string }>, asOf: Date | string = new Date(), opt: { maxAgeDays?: number } = {}) {
  const maxAgeDays = opt.maxAgeDays ?? 365;
  const today = toYmd(asOf);
  const errors: Array<{ id: string; message: string }> = [];
  const warnings: Array<{ id: string; message: string }> = [];
  for (const e of entries) {
    if (!e.sourceUrl || !e.checkedAt) { errors.push({ id: e.id, message: '出典URLと確認日が無い暦は使えません（学校・実施機関の公表を確認して登録してください）' }); continue; }
    const age = ymdDiff(e.checkedAt, today);
    if (age > maxAgeDays) warnings.push({ id: e.id, message: `確認日 ${e.checkedAt} から ${age}日 経過した古い暦です。最新の公表を確認してください` });
  }
  return { asOf: today, errors, warnings };
}

// ============================================================================
// 6. 学校法人会計の計算書類（学校法人会計基準・令和7年度以降の会計年度）
// ============================================================================

export const GAKKOU_HOUJIN_KAIKEI_NOTICE = '勘定科目の当てはめ・計算書類の内容は、公認会計士（会計監査人）の確認を前提としています。本システムの出力をそのまま確定版として提出しないでください';

export function listGakkouHoujinRequiredDocuments(input: { fiscalYear: number; jurisdiction: 'mext' | 'governor'; hasAccountingAuditor: boolean; hasHighSchool: boolean; hasProfitBusiness: boolean }) {
  if (input.fiscalYear < 2025) {
    return { status: 'unconfirmed' as const, required: [] as string[], optional: [] as string[], notice: GAKKOU_HOUJIN_KAIKEI_NOTICE, reason: '令和6年度以前の会計年度は改正前の基準（従前の例）によります。本部品は令和7年度以降に対応' };
  }
  const required = ['貸借対照表', '事業活動収支計算書', '資金収支計算書', '活動区分資金収支計算書', '計算書類の注記', '固定資産明細書', '借入金明細書', '基本金明細書', '財産目録'];
  const optional: string[] = [];
  const notes: string[] = [];
  if (input.jurisdiction === 'governor' && !input.hasAccountingAuditor) {
    // 第50条: 活動区分資金収支計算書又は基本金明細書（高等学校を設置するものは活動区分資金収支計算書に限る）を作成しないことができる
    const omissible = input.hasHighSchool ? ['活動区分資金収支計算書'] : ['活動区分資金収支計算書', '基本金明細書'];
    for (const d of omissible) { required.splice(required.indexOf(d), 1); optional.push(d); }
    notes.push('会計監査人非設置知事所轄学校法人の特例（第50条）により、作成を省略できる書類があります');
  }
  if (input.hasProfitBusiness) required.push('収益事業会計の貸借対照表', '収益事業会計の損益計算書');
  return { status: 'confirmed' as const, required, optional, notes, notice: GAKKOU_HOUJIN_KAIKEI_NOTICE, basis: '学校法人会計基準 第1条第2項・第16条・第40条・第41条・第43条・第50条', sourceUrl: `${EGOV}346M50000080018`, checkedAt: '2026-10-03' };
}
