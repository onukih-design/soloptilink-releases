/**
 * lib/japan/after_school_club.ts — 放課後児童クラブ（学童保育）の国の基準と条例値・自治体パラメータ
 *
 * 2026-10-04 新設（日本最適化 T32・REQ-138）。
 *   国の基準（放課後児童健全育成事業の設備及び運営に関する基準・平成26年厚生労働省令第63号）は、市町村が条例で定めるに当たって
 *   「参酌すべき基準」（第1条）。条例の値が出典つきで与えられたときは条例値で判定し、国の値は別に持つ。
 *   自治体ごとの値（条例の配置・地域区分・利用料の階層・独自の無償化）は一次資料で確かめるまで「未確認」で持ち、国の値や推測で埋めない。
 *
 * 出典: e-Gov 426M60000100063（2025-10-01版）第1条・第9条・第10条・第18条（2026-10-03 取得）
 */

const KIJUN_URL = 'https://laws.e-gov.go.jp/law/426M60000100063';

/** 国の基準（参酌すべき基準） */
export const GAKUDO_NATIONAL_STANDARD = Object.freeze({
  minStaffPerUnit: 2, // 第10条第2項: 支援の単位ごとに放課後児童支援員2人以上
  minQualifiedPerUnit: 1, // 同項ただし書: うち1人を除き補助員で代えることができる（＝支援員1人以上）
  maxChildrenPerUnitGuideline: 40, // 第10条第4項: おおむね40人以下
  areaPerChildM2Guideline: 1.65, // 第9条第2項: 専用区画は児童1人につきおおむね1.65㎡以上
  openingHours: { holidayHours: 8, schoolDayHours: 3, daysPerYear: 250 }, // 第18条（原則）
  standardKind: '参酌すべき基準' as const,
  sourceUrl: KIJUN_URL, checkedAt: '2026-10-03',
});

export interface GakudoOrdinance {
  minStaffPerUnit: number;
  minQualifiedPerUnit: number;
  sourceUrl?: string; // 条例・規則の出典（例規集のURL）
  checkedAt?: string;
}

type ParamCell = { status: 'confirmed' | 'unconfirmed'; value: unknown; display: string; sourceUrl?: string; checkedAt?: string };
const UNCONFIRMED: ParamCell = Object.freeze({ status: 'unconfirmed', value: null, display: '未確認' }) as ParamCell;

/** 主要20自治体（地方自治法の指定都市20市）。値は一次資料で確かめたものだけを confirmed にする（2026-10-04 時点は全項目未取得） */
export const GAKUDO_MUNICIPALITIES_20: ReadonlyArray<{ municipality: string; prefecture: string; staffingOrdinance: ParamCell; regionalCategory: ParamCell; feeTiers: ParamCell; localFreeProgram: ParamCell }> = Object.freeze(
  [
    ['札幌市', '北海道'], ['仙台市', '宮城県'], ['さいたま市', '埼玉県'], ['千葉市', '千葉県'], ['横浜市', '神奈川県'],
    ['川崎市', '神奈川県'], ['相模原市', '神奈川県'], ['新潟市', '新潟県'], ['静岡市', '静岡県'], ['浜松市', '静岡県'],
    ['名古屋市', '愛知県'], ['京都市', '京都府'], ['大阪市', '大阪府'], ['堺市', '大阪府'], ['神戸市', '兵庫県'],
    ['岡山市', '岡山県'], ['広島市', '広島県'], ['北九州市', '福岡県'], ['福岡市', '福岡県'], ['熊本市', '熊本県'],
  ].map(([municipality, prefecture]) => ({ municipality, prefecture, staffingOrdinance: UNCONFIRMED, regionalCategory: UNCONFIRMED, feeTiers: UNCONFIRMED, localFreeProgram: UNCONFIRMED })),
);

export function listGakudoMunicipalityTable() {
  return GAKUDO_MUNICIPALITIES_20.map((r) => ({ ...r }));
}

export function getGakudoMunicipalityParams(municipality: string) {
  const r = GAKUDO_MUNICIPALITIES_20.find((x) => x.municipality === municipality);
  if (!r) return { status: 'unconfirmed' as const, municipality, staffingOrdinance: UNCONFIRMED, regionalCategory: UNCONFIRMED, feeTiers: UNCONFIRMED, localFreeProgram: UNCONFIRMED, reason: '収録外の自治体です（条例・要綱を確認して登録してください）' };
  return { status: 'listed' as const, ...r };
}

/**
 * 支援の単位ごとの職員配置の判定。
 *   ordinance（出典つき）を渡すと条例値で判定（basis='ordinance'）。出典の無い条例値は採らず国の基準で判定して注意を返す。
 *   municipality だけを渡し、その自治体の条例値が未確認なら、国の基準で判定したうえで「条例は未確認」と注意する（国の値で条例を埋めない）。
 */
export function checkGakudoStaffing(input: { qualifiedCount: number; assistantCount: number; childrenInUnit: number; municipality?: string; ordinance?: GakudoOrdinance }) {
  const warnings: string[] = [];
  let basis: 'national' | 'ordinance' = 'national';
  let minStaff = GAKUDO_NATIONAL_STANDARD.minStaffPerUnit;
  let minQualified = GAKUDO_NATIONAL_STANDARD.minQualifiedPerUnit;
  let ordinanceStatus: 'given' | 'unconfirmed' | 'not_requested' = 'not_requested';
  let ordinanceSource: string | undefined;

  if (input.ordinance) {
    if (input.ordinance.sourceUrl && /^https?:\/\//.test(input.ordinance.sourceUrl)) {
      basis = 'ordinance';
      minStaff = input.ordinance.minStaffPerUnit;
      minQualified = input.ordinance.minQualifiedPerUnit;
      ordinanceStatus = 'given';
      ordinanceSource = input.ordinance.sourceUrl;
    } else {
      ordinanceStatus = 'unconfirmed';
      warnings.push('条例値に出典（例規集のURL）が無いため採用せず、国の基準（参酌すべき基準）で判定しました');
    }
  } else if (input.municipality) {
    const p = getGakudoMunicipalityParams(input.municipality);
    const cell = p.staffingOrdinance;
    if (cell.status === 'confirmed' && cell.value && typeof cell.value === 'object') {
      const v = cell.value as { minStaffPerUnit: number; minQualifiedPerUnit: number };
      basis = 'ordinance'; minStaff = v.minStaffPerUnit; minQualified = v.minQualifiedPerUnit; ordinanceStatus = 'given'; ordinanceSource = cell.sourceUrl;
    } else {
      ordinanceStatus = 'unconfirmed';
      warnings.push(`${input.municipality} の条例値は未確認です。国の基準（参酌すべき基準）で判定しています。条例を確認してください`);
    }
  }

  const total = input.qualifiedCount + input.assistantCount;
  const reasons: string[] = [];
  if (total < minStaff) reasons.push(`職員が ${total}人（${basis === 'ordinance' ? '条例' : '国の基準'}は支援の単位ごとに ${minStaff}人以上）`);
  if (input.qualifiedCount < minQualified) reasons.push(`放課後児童支援員が ${input.qualifiedCount}人（${minQualified}人以上が必要。補助員で代えられない）`);
  if (input.childrenInUnit > GAKUDO_NATIONAL_STANDARD.maxChildrenPerUnitGuideline) warnings.push(`支援の単位の児童が ${input.childrenInUnit}人です（国の基準は「おおむね40人以下」第10条第4項）`);
  return { compliant: reasons.length === 0, basis, ordinanceStatus, ordinanceSource, reasons, warnings, nationalStandard: GAKUDO_NATIONAL_STANDARD };
}
