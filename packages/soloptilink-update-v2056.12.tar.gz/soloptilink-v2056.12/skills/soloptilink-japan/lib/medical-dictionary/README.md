# SoloptiLinkAI 医療用語辞書 (Medical Dictionary)

医療系業種システム構築時に参照される標準辞書の集約。**構造化 JSON + ローダ**で、生成物・Verify ゲート・Centuria ロールから共通参照する。

## 収録辞書

| ファイル | 内容 | 収録数 (骨格) |
|---|---|---|
| `data/medical-fees-r6.json` | 医科診療報酬点数表 (R6改定) | 主要 80+ 項目 |
| `data/medical-fees-r8.json` | 医科診療報酬点数表 (R8改定) **初・再診料のみの部分マスタ** | 59 項目 (全項目が告示原典由来) |
| `data/dental-fees-r6.json` | 歯科診療報酬点数表 (R6改定) | 主要 30+ 項目 |
| `data/dispensing-fees-r6.json` | 調剤報酬点数表 (R6改定) | 主要 30+ 項目 |
| `data/addition-common.json` | よく使う加算 (在宅/DX/かかりつけ 等) | 30+ 加算 |
| `data/icd10.json` | ICD-10 病名コード (代表章) | 80+ 疾病 |
| `data/yj-codes-sample.json` | YJコード (薬価収載品・代表) | 40+ 医薬品 |
| `data/medical-departments.json` | 診療科マスタ (厚労省告示) | 48 診療科 |
| `data/insurance-types.json` | 保険種別 (社保/国保/公費 等) | 12+ 保険種別 |
| `data/receipt-electronic-codes.json` | レセ電レコード種別 (UKE) | 13 レコード完全 |

## 設計原則

1. **完全 SoT でなく骨格 + 参照 URL**: 例: 診療報酬点数表は正式には約 4,000 項目・改定ごとに変わる。本辞書は**代表主要項目 + 出典 URL** を保持し、完全版は e-gov / 基盤機構 (旧 支払基金) マスタ連携 (Phase C IBL) で補完する。
2. **年度キー保持**: 診療報酬・薬価は改定年度キー (`R4` / `R6` / 次期 `R8`) で切り替え可能。
3. **JSON 単一形式**: すべての辞書は JSON。TS/JS/Python/シェルどこからでも読める。
4. **後方互換**: 既存 `~/.soloptilink/lib/japan/medical.ts` の型定義 (MedicalFeeItem/DiseaseMaster/YJCode) と整合する。

## ローダ API

### シェル (dictionary-loader.sh)

```bash
# 診療科名の日本語取得
bash ~/.soloptilink/lib/medical-dictionary/dictionary-loader.sh dept-name internal
# → 内科

# ICD-10 コードから病名取得
bash ~/.soloptilink/lib/medical-dictionary/dictionary-loader.sh icd10-name I10
# → 本態性高血圧症

# 診療報酬点数取得
bash ~/.soloptilink/lib/medical-dictionary/dictionary-loader.sh fee-points A000
# → 291

# 収録辞書のサマリ (JSON)
bash ~/.soloptilink/lib/medical-dictionary/dictionary-loader.sh summary
```

### JavaScript / TypeScript (dictionary-loader.mjs)

```js
import { loadDictionary, findFeeForServiceDate, findIcd10, findDept } from '.../dictionary-loader.mjs';

const dict = await loadDictionary();
// 点数は必ず診療日で引く (年度をまたぐと点数が変わる)。取り込んでいない年度は止まって理由を返す
findFeeForServiceDate(dict, 'A000', '2026-07-01');  // { applicable: false, stop: true, messages_ja: [...未取込...], ... }
// findFee(dict, 'A000') は診療日を見ない旧い入口 (令和6年度の表だけ)。点数を出す用途には使わない
findIcd10(dict, 'I10');          // { icd10: 'I10', standardName: '本態性高血圧症', ... }
findDept(dict, 'internal');      // { code: 'internal', name: '内科', ... }
```

## 整合性検証 (born-passing)

```bash
node ~/.soloptilink/lib/medical-dictionary/verify-dictionary.mjs
```

以下を検証:
- 全 JSON ファイルの構造妥当性
- コード重複ゼロ (fee code / ICD-10 / YJ code)
- 必須フィールド網羅 (code/name/points/revision 等)
- クロスリファレンス整合 (加算の親コード実在確認)
- 出典 URL 記載 (改定確認のため)

## 出典の裏取り方針 (点数を登録する前に必ず読むこと)

点数を推測で埋めると、医療機関がその点数で請求し損害を被る。よって本辞書は次を厳守する。

1. **一次情報 (告示原典・官公庁の公表資料) で確認できた値だけを登録する。** 検索結果の要約に出てきた数値は採用しない。
2. **登録する項目には必ず項目単位の出典を付ける** — 出典名 (`source`) / URL (`sourceUrl`) / 原典の該当箇所 (`sourceLocation`) / 種別 (`sourceType`) / 確認日 (`confirmedAt`)。ファイル単位の参照 URL は「この辞書はこの告示に由来する」までしか言えず、個々の点数の根拠にはならない。
3. **取得できなかったものは登録しない。** 器 (ファイル・スキーマ) だけ作り、`not_registered_ja` に「何を・なぜ登録しなかったか」を書く。
4. **未確認の留保は `open_risks_ja` に残す。** 官報訂正の未突合・施設基準の未取得などは、解消するまで消さない。
5. **部分マスタを「取り込み済み」にしない。** 点数表の一部しか収載していない年度を改定カレンダーで `loaded` にすると、未収載区分を 0 点として請求する事故になる。全体取込が終わるまで `not_loaded` のままにする。

`verify-dictionary.mjs` の C11 系がこの方針を機械的に強制する (出典欠落・非一次情報の混入・申告と実体の不一致があれば FAIL)。

## 充足状況レポート

```bash
node ~/.soloptilink/lib/medical-dictionary/coverage.mjs --as-of 2026-07-31
node ~/.soloptilink/lib/medical-dictionary/coverage.mjs --json --as-of 2026-07-31
```

収載件数・**出典種別ごとの件数 (一次情報 / 二次情報 / 出典なし)**・代表項目の収載点検 (改定年度別)・改定の取り込み状況・**点数表ファイルと改定カレンダーの接続状況** を実測して出力する。「ファイルが在ること」と「その年度の算定に使えること」を分けて表示するため、部分取込を取込済と誤認できない。

## 更新方針

- **診療報酬改定 (2年ごと)**: R6→R8 移行時は `medical-fees-r8.json` を新規追加し、既存 R6 は保持 (履歴保存)。生成物は年度キーで切替可能 (`findFeeByRevision(dict, code, 'R8')`)。`findFee()` は R6 のみを見るため、年度をまたぐ処理では使わないこと。
- **ICD-10 新版**: 現行 ICD-10 (2013版)。ICD-11 移行は日本の医療現場適用時期に合わせて対応。
- **YJ コード**: 薬価収載は毎年変わるため、代表品目のみ内蔵し、詳細はレセコン連携 (ORCA/QNET) or 基盤機構 (旧 支払基金) マスタ参照。

## 参照 URL (SoT)

| 領域 | 一次情報源 |
|---|---|
| 診療報酬点数表 | https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000188411_00038.html |
| 薬価基準 | https://www.mhlw.go.jp/topics/2024/03/tp20240305-01.html |
| ICD-10 (WHO) | https://www.mhlw.go.jp/toukei/sippei/index.html |
| YJ コード | 医薬品マスタ (基盤機構 (旧 支払基金)) |
| レセ電仕様 | https://www.ssk.or.jp/seikyushiharai/rezept/index.html |
| オンライン資格確認 | https://www.iryohokenjyoho-portalsite.jp/ |
| HL7 FHIR JP Core | https://jpfhir.jp/fhir/core/ |
| HPKI | https://www.medis.or.jp/8_hpki/ |
| 3省2ガイドライン | https://www.mhlw.go.jp/stf/shingi/0000516275_00004.html |

## 保守 (管理者)

辞書更新時は `verify-dictionary.mjs` を実行し全 born-passing PASS を確認してからコミットする。改定年度 (R6→R8 等) 移行時は README 冒頭の収録数を更新する。
