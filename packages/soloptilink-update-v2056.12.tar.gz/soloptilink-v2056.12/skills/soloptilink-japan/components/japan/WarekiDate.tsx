'use client';
import React, { useState } from 'react';
import { formatWareki, formatBoth, toWareki, toSeireki, toSeirekiChecked } from '../../lib/japan/wareki';

export interface WarekiDateProps {
  value?: Date | string;
  onChange?: (d: Date) => void;
  mode?: 'display' | 'input';
  display?: 'long' | 'short' | 'iso' | 'both' | 'ja_full';
  className?: string;
}

/**
 * 和暦日付コンポーネント
 * display モード: 西暦日付を受け取り和暦併記で表示
 * input モード: 和暦/西暦の両方で入力できる
 */
export function WarekiDate({ value, onChange, mode = 'display', display = 'both', className }: WarekiDateProps) {
  const date = value ? (typeof value === 'string' ? new Date(value) : value) : new Date();
  const [era, setEra] = useState(() => toWareki(date).era);
  const [year, setYear] = useState(() => toWareki(date).year);
  // 月日も日本時間の暦日で読む (2026-09-30 是正: 端末の時刻帯で1日ずれないように)
  const [month, setMonth] = useState(() => toWareki(date).month);
  const [day, setDay] = useState(() => toWareki(date).day);
  const [error, setError] = useState<string | null>(null);
  const [warning, setWarning] = useState<string | null>(null);

  if (mode === 'display') {
    const text = display === 'both'
      ? formatBoth(date)
      : formatWareki(date, display === 'ja_full' ? 'ja_full' : display as 'long' | 'short' | 'iso');
    return <span className={className}>{text}</span>;
  }

  // input モード
  // 実在しない和暦 (令和元年4月1日・平成32年・2月30日など) は例外にせず、入力欄の下に理由を出して onChange を呼ばない
  const handleChange = (newEra: string, newYear: number, newMonth: number, newDay: number) => {
    setEra(newEra);
    setYear(newYear);
    setMonth(newMonth);
    setDay(newDay);
    const r = toSeirekiChecked({ era: newEra, year: newYear, month: newMonth, day: newDay });
    if (!r.ok) {
      setError(r.error ?? '存在しない日付です');
      setWarning(null);
      return;
    }
    setError(null);
    setWarning(r.warnings[0] ?? null);
    onChange?.(toSeireki({ era: newEra, year: newYear, month: newMonth, day: newDay }));
  };
  const checked = toSeirekiChecked({ era, year, month, day });

  return (
    <div className={`inline-flex items-center gap-1 ${className ?? ''}`}>
      <select
        value={era}
        onChange={e => handleChange(e.target.value, year, month, day)}
        aria-label="元号"
        className="border rounded px-2 py-1"
      >
        <option value="令和">令和</option>
        <option value="平成">平成</option>
        <option value="昭和">昭和</option>
        <option value="大正">大正</option>
        <option value="明治">明治</option>
      </select>
      <input
        type="number"
        min={1}
        value={year}
        onChange={e => handleChange(era, Number(e.target.value), month, day)}
        aria-label="年"
        className="border rounded w-16 px-2 py-1 text-right"
      />
      <span>年</span>
      <input
        type="number"
        min={1}
        max={12}
        value={month}
        onChange={e => handleChange(era, year, Number(e.target.value), day)}
        aria-label="月"
        className="border rounded w-14 px-2 py-1 text-right"
      />
      <span>月</span>
      <input
        type="number"
        min={1}
        max={31}
        value={day}
        onChange={e => handleChange(era, year, month, Number(e.target.value))}
        aria-label="日"
        className="border rounded w-14 px-2 py-1 text-right"
      />
      <span>日</span>
      <small className="text-gray-500 ml-2">({checked.ok && checked.ymd ? `${checked.ymd.slice(0, 4)}年` : '—'})</small>
      {error && <small role="alert" className="text-red-600 ml-2">{error}。正しい年月日を入力してください</small>}
      {!error && warning && <small className="text-amber-700 ml-2">{warning}</small>}
    </div>
  );
}
