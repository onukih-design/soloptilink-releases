#!/usr/bin/env python3
"""推進工法図面生成 — gen_others.py (v2 View方式)

担当4種:
  - 坑口改良図         (draw_entrance_reinforcement)
  - 推進設備配置図     (draw_yard_layout)
  - 保安管理図         (draw_safety_management)
  - 人孔構造図         (draw_manhole)

残り3種 (draw_location / draw_system_diagram / draw_plan_profile) は
gen_route.py に移設済みのためここから import する。
gen_route.py が未存在の場合でも本ファイルは import できる（検証時は4関数のみで確認）。

【v2 方針】
  - 図形は実寸 mm で描く。sr = 1000/scale は一切使わない。
  - 注記文字・寸法は紙面 mm。
  - Panel / View / split_cols / split_rows で紙面を構成する。
  - d.table() / d.legend() / d.north_arrow() だけが紙面 mm 直書き可。
  - finish() を1回だけ呼ぶ。draw_titleblock() は finish() 内部が呼ぶ。
"""
from __future__ import annotations

import math
import json
import sys
from typing import List, Tuple

from dxf_base import OgumiDXF, TH_TINY, TH_SMALL, TH_BODY, TH_HEAD
from layout import View, Panel, split_cols, split_rows


# ------------------------------------------------------------------ #
# 共通ユーティリティ                                                    #
# ------------------------------------------------------------------ #

def _circle_pts(cx: float, cy: float, r: float, n: int = 48) -> List[Tuple[float, float]]:
    """円を n 角形で近似した頂点リスト（実寸 mm）"""
    return [
        (cx + r * math.cos(2 * math.pi * i / n),
         cy + r * math.sin(2 * math.pi * i / n))
        for i in range(n)
    ]


# ================================================================
# 1. 坑口改良図
# ================================================================
def draw_entrance_reinforcement(data: dict, out_path: str) -> dict:
    """坑口改良図: 発進/到達坑口周辺の地盤改良を平面・仕様表で表現。

    入力キー:
        project_name, paper, scale (optional, default 50)
        shaft_type         (str)   — 発進坑口 / 到達坑口 など
        entrance_od_mm     (int)   — 坑口外径 mm
        improvement_radius_m (float) — 改良半径 m
        improvement_depth_m  (float) — 改良深さ m
        improvement_method   (str)   — 薬液注入工法 等
        material, mix_ratio, injection_pressure, target_strength_kpa,
        material_volume_m3  (各仕様値)
    """
    method = data.get("improvement_method", "薬液注入工法")

    d = OgumiDXF(
        paper=data.get("paper", "A2"),
        scale=data.get("scale", 50),
        title=f"坑口改良図（{data.get('shaft_type', '発進坑口')}）",
        drawing_no=data.get("drawing_no", ""),
        project=data["project_name"],
        client=data.get("client", ""),
        designer=data.get("designer", ""),
        extra_meta={"改良工法": method},
    )

    main = d.content_panel()
    # 左: 改良平面図 / 右: 仕様表
    left, right = split_cols(main, [3, 2], gap=6, names=["改良平面図", "仕様表エリア"])

    entrance_r = data.get("entrance_od_mm", 1200) / 2        # 実寸 mm
    impr_r     = data.get("improvement_radius_m", 3.0) * 1000  # 実寸 mm

    # ---------- 改良平面図（実寸 mm） ----------
    v = View(left, preferred_scale=None, title="【坑口改良図（平面）】")

    # 改良範囲ハッチ（坑口部を中抜きした円環）。
    # 坑口は削孔部なので改良体としては塗らない。
    impr_pts = _circle_pts(0, 0, impr_r, n=64)
    v.hatch_ring((0, 0), impr_r, entrance_r,
                 pattern="ANSI37", layer="4-HATCH", pattern_scale=2.0)
    v.polyline(impr_pts, layer="8-PROPOSED", close=True)

    # 坑口円（外形線）
    v.circle((0, 0), entrance_r, layer="0-OUTLINE")

    # 中心線（改良範囲外まで延長）
    cl = impr_r * 1.2
    v.line((-cl, 0), (cl, 0), "1-CENTER")
    v.line((0, -cl), (0, cl), "1-CENTER")

    # 寸法: 坑口径 / 改良径
    v.dim((-entrance_r, 0), (entrance_r, 0), orient="h", offset_mm=12,
          text=f"坑口 φ{data.get('entrance_od_mm', 1200)}")
    v.dim((-impr_r, 0), (impr_r, 0), orient="h", offset_mm=26,
          text=f"改良径 D={data.get('improvement_radius_m', 3.0) * 2:.1f}m")

    # 注記
    v.label(f"改良範囲 R={data.get('improvement_radius_m', 3.0):.1f}m",
            (impr_r * 0.65, impr_r * 0.65), TH_SMALL, align="l_b", priority=3)
    v.label(method, (0, -impr_r), TH_TINY, align="c_t", dy=-2, priority=4)

    d.place(v)

    # ---------- 仕様表（紙面 mm、右パネル上部） ----------
    spec_rows: List[List[str]] = [
        ["項目", "仕様"],
        ["改良工法",    data.get("improvement_method", "薬液注入工法")],
        ["改良範囲",    f"坑口中心 R={data.get('improvement_radius_m', 3.0)}m"],
        ["改良深さ",    f"{data.get('improvement_depth_m', 5.0)}m"],
        ["材料",       data.get("material", "ホモゲル・スーパーソイル")],
        ["目標強度",   f"{data.get('target_strength_kpa', 500)} kN/㎡"],
        ["配合",       data.get("mix_ratio", "ホモゲル:水=1:1")],
        ["注入圧",     data.get("injection_pressure", "0.3〜0.5 MPa")],
        ["必要材料量", f"{data.get('material_volume_m3', 15)}㎥"],
    ]
    tx = right.x + 2
    ty = right.y + right.h - TH_BODY - 3
    d.table(tx, ty, spec_rows, col_widths=[28, 46],
            row_h=5.5, height=TH_SMALL, title="【改良仕様】")

    res = d.finish(out_path)
    res["type"] = "entrance_reinforcement"
    return res


# ================================================================
# 2. 推進設備配置図 (ヤード)
# ================================================================
def draw_yard_layout(data: dict, out_path: str) -> dict:
    """推進設備配置図: 立坑・プラント・クレーン・発電機・材料置場等の実寸配置。

    入力キー:
        project_name, paper, scale (optional, default 100)
        yard_width_m  (float) — 敷地幅 m
        yard_depth_m  (float) — 敷地奥行 m
        equipments    (list)  — [{name, x_m, y_m, w_m, h_m}, ...]
    """
    equipments = data.get("equipments", [
        {"name": "発進立坑",    "x_m": 5,  "y_m": 8,  "w_m": 4, "h_m": 4},
        {"name": "泥水プラント","x_m": 12, "y_m": 13, "w_m": 6, "h_m": 4},
        {"name": "クレーン",    "x_m": 3,  "y_m": 3,  "w_m": 5, "h_m": 5},
        {"name": "材料置場",    "x_m": 20, "y_m": 3,  "w_m": 6, "h_m": 6},
        {"name": "発電機",      "x_m": 24, "y_m": 13, "w_m": 3, "h_m": 3},
        {"name": "現場事務所",  "x_m": 20, "y_m": 12, "w_m": 4, "h_m": 3},
    ])

    # 敷地寸法（実寸 mm）。設備が飛び出す入力でも敷地を自動拡張
    yard_w = data.get("yard_width_m", 30) * 1000
    yard_d = data.get("yard_depth_m", 20) * 1000
    for eq in equipments:
        yard_w = max(yard_w, (eq["x_m"] + eq["w_m"]) * 1000 + 2000)
        yard_d = max(yard_d, (eq["y_m"] + eq["h_m"]) * 1000 + 2000)

    d = OgumiDXF(
        paper=data.get("paper", "A1"),
        scale=data.get("scale", 100),
        title="推進設備配置図",
        drawing_no=data.get("drawing_no", ""),
        project=data["project_name"],
        client=data.get("client", ""),
        designer=data.get("designer", ""),
        extra_meta={
            "敷地面積": f"{yard_w / 1000:.0f}×{yard_d / 1000:.0f}m",
            "設備数":   str(len(equipments)),
        },
    )

    main = d.content_panel()
    v = View(main, preferred_scale=data.get("scale", 100), title="【推進設備配置図】")

    # 敷地境界（実寸 mm）
    v.rect(0, 0, yard_w, yard_d, "0-OUTLINE")
    v.label("敷地境界", (0, yard_d), TH_SMALL, align="l_b", dy=2, priority=1)

    # 出入口（下辺中央）
    gate_w = 6000
    v.line((yard_w / 2 - gate_w / 2, 0),
           (yard_w / 2 + gate_w / 2, 0), "8-PROPOSED")
    v.label("出入口", (yard_w / 2, 0), TH_SMALL, align="c_t", dy=-2, priority=2)

    # 各設備（実寸 mm）
    for eq in equipments:
        ex = eq["x_m"] * 1000
        ey = eq["y_m"] * 1000
        ew = eq["w_m"] * 1000
        eh = eq["h_m"] * 1000
        is_shaft = "立坑" in eq["name"]
        layer = "14-SHAFT" if is_shaft else "8-PROPOSED"
        v.rect(ex, ey, ex + ew, ey + eh, layer)
        v.hatch_rect(ex, ey, ex + ew, ey + eh,
                     pattern="ANSI37" if is_shaft else "ANSI31",
                     pattern_scale=3.0)
        v.label(eq["name"],
                (ex + ew / 2, ey + eh / 2), TH_SMALL,
                layer="3-TEXT", align="c_m", priority=5)
        v.label(f"{eq['w_m']}×{eq['h_m']}m",
                (ex + ew / 2, ey + eh / 4), TH_TINY,
                layer="9-DIM-TEXT", align="c_m", priority=8)

    # 外周寸法
    v.dim((0, 0), (yard_w, 0), orient="h", offset_mm=12,
          text=f"敷地幅 {yard_w/1000:.0f}m")
    v.dim((0, 0), (0, yard_d), orient="v", offset_mm=12,
          text=f"奥行 {yard_d/1000:.0f}m")

    d.place(v)

    # 方位記号・凡例（紙面 mm）
    cp = d.content_panel()
    d.north_arrow(cp.x + cp.w - 18, cp.y + cp.h - 18, r=8)
    d.legend(
        cp.x + 2, cp.y + 16,
        [
            ("8-PROPOSED", "推進設備・プラント"),
            ("14-SHAFT",   "発進・到達立坑"),
            ("0-OUTLINE",  "敷地境界"),
        ],
    )

    res = d.finish(out_path)
    res["type"]        = "yard_layout"
    res["equipments"]  = len(equipments)
    return res


# ================================================================
# 3. 保安管理図
# ================================================================
def draw_safety_management(data: dict, out_path: str) -> dict:
    """保安管理図: 交通規制・保安施設配置・安全対策項目一覧。

    入力キー:
        project_name, paper, scale (optional, default 500)
        length_m            (float) — 施工延長 m
        road_width_m        (float) — 道路幅 m (default 8)
        regulation_margin_m (float) — 規制余裕 m (default 20)
        facilities          (list)  — [{name, count, x_ratio}, ...]
        safety_items        (list)  — 文字列リスト
    """
    d = OgumiDXF(
        paper=data.get("paper", "A2"),
        scale=data.get("scale", 500),
        title="保安管理図",
        drawing_no=data.get("drawing_no", ""),
        project=data["project_name"],
        client=data.get("client", ""),
        designer=data.get("designer", ""),
    )

    main = d.content_panel()
    # 左: 保安配置図 / 右: 安全対策表
    draw_panel, table_panel = split_cols(
        main, [3, 2], gap=6, names=["保安配置図", "安全対策表"]
    )

    length_m   = data.get("length_m", 100)
    road_w_m   = data.get("road_width_m", 8)
    reg_mg_m   = data.get("regulation_margin_m", 20)

    # 実寸 mm
    length_mm  = length_m * 1000
    road_w_mm  = road_w_m * 1000
    reg_mm     = reg_mg_m * 1000
    icon_r     = max(road_w_mm * 0.3, 1500)  # アイコン円半径（実寸 mm）

    v = View(draw_panel, preferred_scale=data.get("scale", 500),
             title="【保安管理図（平面）】")

    # 施工範囲
    v.rect(0, 0, length_mm, road_w_mm, "0-OUTLINE")
    v.hatch_rect(0, 0, length_mm, road_w_mm, pattern="ANSI31", pattern_scale=4.0)
    v.label("施工範囲", (length_mm / 2, road_w_mm / 2),
            TH_SMALL, align="c_m", priority=2)

    # 交通規制範囲（一点鎖線レイヤ）
    rx1, rx2 = -reg_mm, length_mm + reg_mm
    ry1, ry2 = -road_w_mm * 0.5, road_w_mm * 1.5
    v.rect(rx1, ry1, rx2, ry2, "1-CENTER")
    v.label("交通規制範囲", (rx1, ry2), TH_SMALL,
            layer="1-CENTER", align="l_b", dy=2, priority=1)
    total_reg_m = length_m + reg_mg_m * 2
    v.label(f"規制延長 {total_reg_m:.0f}m", (rx2 / 2, ry1),
            TH_TINY, layer="1-CENTER", align="c_t", dy=-2, priority=6)

    # 保安施設アイコン（道路上方に配置）
    facilities = data.get("facilities", [
        {"name": "警備員",    "count": 2,  "x_ratio": 0.0},
        {"name": "警備員",    "count": 2,  "x_ratio": 1.0},
        {"name": "工事看板",  "count": 1,  "x_ratio": 0.08},
        {"name": "工事看板",  "count": 1,  "x_ratio": 0.92},
        {"name": "バリケード","count": 20, "x_ratio": 0.5},
    ])
    icon_oy = road_w_mm + icon_r * 3   # 道路上辺からの離れ
    for fc in facilities:
        fx = fc["x_ratio"] * length_mm
        fy = icon_oy
        v.circle((fx, fy), icon_r, "12-CURVE")
        v.line((fx, fy - icon_r), (fx, road_w_mm), "12-CURVE")
        v.label(f"{fc['name']}×{fc['count']}",
                (fx, fy + icon_r), TH_TINY,
                layer="12-CURVE", align="c_b", dy=1, priority=7)

    # 施工延長寸法
    v.dim((0, 0), (length_mm, 0), orient="h", offset_mm=12,
          text=f"施工延長 L={length_m}m")

    d.place(v)

    # 安全対策項目表（紙面 mm、右パネル）
    items = data.get("safety_items", [
        "工事看板の設置（施工範囲両端）",
        "警備員による交通誘導（発進・到達側）",
        "夜間バリケード設置",
        "ガス漏れ検知器の常時使用",
        "有害ガス連続測定（H2S/CO/O2）",
        "避難経路の明示",
        "毎日朝礼でのKY活動",
        "月次リスクアセスメント実施",
    ])
    table_rows: List[List[str]] = [["No.", "安全対策項目"]] + [
        [str(i + 1), item] for i, item in enumerate(items)
    ]
    tx = table_panel.x + 2
    ty = table_panel.y + table_panel.h - TH_BODY - 3
    d.table(tx, ty, table_rows, col_widths=[10, 68],
            row_h=5.5, height=TH_SMALL, title="【安全対策項目】")

    res = d.finish(out_path)
    res["type"]       = "safety_management"
    res["facilities"] = len(facilities)
    return res


# ================================================================
# 4. 人孔構造図
# ================================================================
def draw_manhole(data: dict, out_path: str) -> dict:
    """人孔構造図: 平面図（左）・断面図（中）・仕様表（右）を split_cols で配置。

    入力キー:
        project_name, paper, scale (optional, default 20)
        manhole_name      (str)   — 図面名称
        manhole_type      (str)   — 組立式2号人孔 等
        inner_diameter_mm (int)   — 内径 mm
        outer_diameter_mm (int)   — 外径 mm (省略時 = 内径 + 300)
        total_height_m    (float) — 全高 m
        inlet_pipe_mm     (int)   — 流入管径 mm
        outlet_pipe_mm    (int)   — 流出管径 mm
        foundation        (str)   — 基礎仕様
        cover             (str)   — 蓋仕様
    """
    inner_d  = data.get("inner_diameter_mm", 900)
    outer_d  = data.get("outer_diameter_mm", inner_d + 300)
    inner_r  = inner_d / 2          # 実寸 mm
    outer_r  = outer_d / 2          # 実寸 mm
    wall_t   = outer_r - inner_r    # 壁厚 mm
    total_h  = data.get("total_height_m", 3.5) * 1000  # 実寸 mm
    inlet_r  = data.get("inlet_pipe_mm", 350) / 2
    outlet_r = data.get("outlet_pipe_mm", 350) / 2

    d = OgumiDXF(
        paper=data.get("paper", "A2"),
        scale=data.get("scale", 20),
        title=f"{data.get('manhole_name', '人孔')}構造図",
        drawing_no=data.get("drawing_no", ""),
        project=data["project_name"],
        client=data.get("client", ""),
        designer=data.get("designer", ""),
        extra_meta={
            "種別": data.get("manhole_type", "組立式2号人孔"),
            "内径": f"φ{inner_d}",
            "全高": f"H={data.get('total_height_m', 3.5):.1f}m",
        },
    )

    main = d.content_panel()
    plan_panel, sec_panel, spec_panel = split_cols(
        main, [2, 2, 1.5], gap=6, names=["平面図", "断面図", "仕様表"]
    )

    # ── 平面図（左パネル） ────────────────────────────────────────
    vp = View(plan_panel, preferred_scale=None, title="【平面図】")

    # 壁体（外形と内空の間だけを塗る）
    vp.hatch_ring((0, 0), outer_r, inner_r, pattern="ANSI31", pattern_scale=2.0)
    vp.circle((0, 0), outer_r, "0-OUTLINE")
    vp.circle((0, 0), inner_r, "0-OUTLINE")

    # 流入管（左）
    vp.line((-outer_r, 0), (-outer_r - inlet_r * 3 - 300, 0), "11-PIPE")
    vp.circle((-outer_r - inlet_r * 2 - 300, 0), inlet_r, "11-PIPE")
    vp.label(f"流入\nφ{data.get('inlet_pipe_mm', 350)}",
             (-outer_r - inlet_r * 2 - 300, -inlet_r),
             TH_TINY, align="c_t", dy=-1, priority=5)

    # 流出管（右）
    vp.line((outer_r, 0), (outer_r + outlet_r * 3 + 300, 0), "11-PIPE")
    vp.circle((outer_r + outlet_r * 2 + 300, 0), outlet_r, "11-PIPE")
    vp.label(f"流出\nφ{data.get('outlet_pipe_mm', 350)}",
             (outer_r + outlet_r * 2 + 300, -outlet_r),
             TH_TINY, align="c_t", dy=-1, priority=5)

    # 中心線
    ext = outer_r * 1.35
    vp.line((-ext, 0), (ext, 0), "1-CENTER")
    vp.line((0, -ext), (0, ext), "1-CENTER")

    # 内径・外径寸法
    vp.dim((-inner_r, 0), (inner_r, 0), orient="h", offset_mm=8,
           text=f"内径 φ{inner_d}", outside=True)
    vp.dim((-outer_r, 0), (outer_r, 0), orient="h", offset_mm=16,
           text=f"外径 φ{outer_d}", outside=True)

    # ── 断面図（中パネル） ────────────────────────────────────────
    # Y=0 = 地表面、下方向がマイナス（実寸 mm）
    vs = View(sec_panel, preferred_scale=None, title="【断面図】")

    # 蓋（地表面上）
    cap_h = wall_t * 0.6
    vs.rect(-outer_r, 0, outer_r, cap_h, "0-OUTLINE")
    vs.hatch_rect(-outer_r, 0, outer_r, cap_h, pattern="ANSI31", pattern_scale=2.0)

    # 左壁体
    vs.rect(-inner_r - wall_t, -total_h, -inner_r, 0, "0-OUTLINE")
    vs.hatch_rect(-inner_r - wall_t, -total_h, -inner_r, 0,
                  pattern="ANSI31", pattern_scale=2.0)

    # 右壁体
    vs.rect(inner_r, -total_h, inner_r + wall_t, 0, "0-OUTLINE")
    vs.hatch_rect(inner_r, -total_h, inner_r + wall_t, 0,
                  pattern="ANSI31", pattern_scale=2.0)

    # 底版
    vs.rect(-inner_r - wall_t, -total_h - wall_t,
            inner_r + wall_t, -total_h, "0-OUTLINE")
    vs.hatch_rect(-inner_r - wall_t, -total_h - wall_t,
                  inner_r + wall_t, -total_h,
                  pattern="ANSI31", pattern_scale=2.0)

    # 地表線（GL）
    gs_ext = wall_t * 4
    vs.line((-inner_r - wall_t - gs_ext, 0), (inner_r + wall_t + gs_ext, 0), "15-GROUND")
    vs.label("GL±0", (-inner_r - wall_t - gs_ext, 0),
             TH_SMALL, align="r_m", dx=-1, priority=1)

    # 流入管・流出管（管底は人孔底付近。落差は口径に応じた実務的な値に収める）
    bottom = -total_h
    stub = max(wall_t * 3, inner_r * 1.2)          # 壁から外へ出す長さ
    inlet_cy = bottom + wall_t + inlet_r + max(150.0, inner_d * 0.05)
    drop = min(300.0, max(50.0, inner_d * 0.05))   # 流入→流出の落差
    outlet_cy = max(bottom + wall_t + outlet_r + 50.0, inlet_cy - drop)

    # 管は上下2本線で描き、口径が読めるようにする
    for cy, r, x_in, x_out, lab, align, dx in (
        (inlet_cy, inlet_r, -inner_r, -inner_r - wall_t - stub,
         f"流入管 φ{data.get('inlet_pipe_mm', 350)}", "r_m", -2),
        (outlet_cy, outlet_r, inner_r, inner_r + wall_t + stub,
         f"流出管 φ{data.get('outlet_pipe_mm', 350)}", "l_m", 2),
    ):
        vs.line((x_in, cy + r), (x_out, cy + r), "11-PIPE")
        vs.line((x_in, cy - r), (x_out, cy - r), "11-PIPE")
        vs.line((x_out, cy - r), (x_out, cy + r), "11-PIPE")
        vs.line((x_in, cy), (x_out, cy), "1-CENTER")
        vs.label(lab, (x_out, cy), TH_TINY, align=align, dx=dx, priority=6)

    # 全高寸法（右外側縦）
    vs.dim((inner_r + wall_t, -total_h), (inner_r + wall_t, 0),
           orient="v", offset_mm=16,
           text=f"H={data.get('total_height_m', 3.5):.1f}m")

    # 壁厚寸法（横）
    vs.dim((inner_r, cap_h), (inner_r + wall_t, cap_h),
           orient="h", offset_mm=8, text=f"t={int(wall_t)}")

    # 平面図と断面図は同一縮尺に揃える（構造図で縮尺が食い違うと寸法感が狂う）
    common_s = max(vp.resolve_scale(), vs.resolve_scale())
    vp.preferred_scale = common_s
    vs.preferred_scale = common_s
    # 揃えた縮尺は必ず守らせる（片方だけ用紙最適化されると縮尺が食い違う）
    vp.lock_scale = True
    vs.lock_scale = True

    d.place(vp)
    d.place(vs)

    # ── 仕様表（右パネル、紙面 mm） ──────────────────────────────
    spec_rows: List[List[str]] = [
        ["項目",   "仕様"],
        ["種別",   data.get("manhole_type", "組立式2号人孔")],
        ["内径",   f"φ{inner_d}"],
        ["外径",   f"φ{outer_d}"],
        ["全高",   f"H={data.get('total_height_m', 3.5):.1f}m"],
        ["壁厚",   f"t={int(wall_t)}"],
        ["流入管", f"φ{data.get('inlet_pipe_mm', 350)}"],
        ["流出管", f"φ{data.get('outlet_pipe_mm', 350)}"],
        ["基礎",   data.get("foundation", "砕石基礎 t=200")],
        ["蓋",     data.get("cover", "鋳鉄製 T-25")],
    ]
    tx = spec_panel.x + 2
    ty = spec_panel.y + spec_panel.h - TH_BODY - 3
    d.table(tx, ty, spec_rows, col_widths=[22, 42],
            row_h=5.5, height=TH_SMALL, title="【仕様】")

    res = d.finish(out_path)
    res["type"]             = "manhole"
    res["inner_diameter_mm"] = inner_d
    return res


# ================================================================
# GENERATORS 辞書
# ================================================================
try:
    from gen_route import draw_location, draw_system_diagram, draw_plan_profile
    _ROUTE_OK = True
except ImportError:
    _ROUTE_OK = False
    draw_location = draw_system_diagram = draw_plan_profile = None  # type: ignore

GENERATORS: dict = {
    "entrance_reinforcement": draw_entrance_reinforcement,
    "yard_layout":            draw_yard_layout,
    "safety_management":      draw_safety_management,
    "manhole":                draw_manhole,
}
if _ROUTE_OK:
    GENERATORS.update({
        "location":       draw_location,
        "system_diagram": draw_system_diagram,
        "plan_profile":   draw_plan_profile,
    })


def main() -> None:
    if len(sys.argv) < 4:
        print("Usage: gen_others.py <type> <input.json> <output.dxf>")
        print("Types:", ", ".join(GENERATORS.keys()))
        sys.exit(1)
    typ = sys.argv[1]
    if typ not in GENERATORS:
        print(f"未対応の図面種別: {typ}")
        sys.exit(1)
    with open(sys.argv[2], encoding="utf-8") as f:
        data_in = json.load(f)
    result = GENERATORS[typ](data_in, sys.argv[3])
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
