#!/usr/bin/env python3
"""立坑構造図（Shaft Structure Drawing）自動生成
発進立坑・到達立坑の平面図＋断面図を1シートに配置

v2: 図形を実寸mmで描き、View/Panel で自動縮尺配置。
    文字被り・図枠はみ出しを構造的に防止。
"""
from __future__ import annotations

import json
import math
import sys
from dataclasses import dataclass
from typing import Optional

from dxf_base import OgumiDXF, TH_TINY, TH_SMALL, TH_BODY, TH_HEAD
from layout import View, Panel, split_cols, split_rows

# --- 定数 ---
WALL_T = 400   # 山留鋼矢板の壁厚（実寸mm, 図面表現用）
CEXT = 300     # 中心線の外延長さ（実寸mm）
ARROW_BASE = 2000  # 推進方向矢印の最小幅（実寸mm）
PILE_BELOW = 1500  # 矢板の掘削底より下の長さ（実寸mm）
PILE_ABOVE = 500   # 矢板のGL より上の長さ（実寸mm）
GROUND_ABOVE = 1000  # 地表ハッチ上端のGL からの高さ（実寸mm）


@dataclass
class ShaftInput:
    project_name: str
    drawing_no: str
    client: str
    shaft_name: str          # "発進立坑 No.1" 等
    shaft_type: str          # "start" / "arrival"
    length_m: float          # 立坑内径（推進方向）L
    width_m: float           # 立坑内径（推進直交方向）W
    depth_m: float           # 掘削深さ H
    ground_water_depth_m: float = 3.0
    steel_sheet_pile: str = "SP-Ⅱ型 L=12m"
    strut_type: str = "H-350×350"
    struts_count: int = 3
    entrance_od_mm: int = 900                  # 坑口外径（mm）
    method: str = "エースモール"
    diameter_mm: int = 350
    paper: str = "A1"
    scale: float = 50.0
    designer: str = ""

    @classmethod
    def from_json(cls, path: str) -> "ShaftInput":
        return cls(**json.load(open(path, encoding="utf-8")))


# ============================================================
# 平面図 View
# ============================================================

def _build_plan_view(panel: Panel, inp: ShaftInput, preferred_scale: float) -> View:
    """平面図 View を構築する（全図形を実寸mmで記述）

    座標系: 左下を原点 (0, 0) とし、X=L方向（推進方向）、Y=W方向。
    山留壁は (-WALL_T, -WALL_T) 〜 (L+WALL_T, W+WALL_T)。
    """
    L = inp.length_m * 1000      # 内空長さ mm（推進方向）
    W = inp.width_m * 1000       # 内空幅 mm（推進直交方向）
    wt = WALL_T
    ent_r = inp.entrance_od_mm / 2  # 坑口半径 mm

    v = View(panel, preferred_scale=preferred_scale, title="【平面図】")

    # --- 山留壁 ハッチ（外周矩形） ---
    v.hatch_rect(-wt, -wt, L + wt, W + wt, "ANSI31", "4-HATCH", 1.5)

    # --- 外周枠・内空枠 ---
    v.rect(-wt, -wt, L + wt, W + wt, "14-SHAFT")
    v.rect(0, 0, L, W, "14-SHAFT")

    # --- 中心線 ---
    v.line((-wt - CEXT, W / 2), (L + wt + CEXT, W / 2), "1-CENTER")
    v.line((L / 2, -wt - CEXT), (L / 2, W + wt + CEXT), "1-CENTER")

    # --- 坑口（推進方向側の内壁に円） ---
    is_start = (inp.shaft_type == "start")
    ent_cx = L if is_start else 0   # 内壁面の X 座標
    ent_cy = W / 2
    v.circle((ent_cx, ent_cy), ent_r, "8-PROPOSED")

    # 坑口ラベル（アンカーは坑口円外縁、dx で紙面mm オフセット）
    if is_start:
        v.label(f"坑口 φ{inp.entrance_od_mm}",
                (ent_cx + ent_r, ent_cy), TH_SMALL, "8-PROPOSED",
                align="l_m", dx=3.0, priority=3)
    else:
        v.label(f"坑口 φ{inp.entrance_od_mm}",
                (ent_cx - ent_r, ent_cy), TH_SMALL, "8-PROPOSED",
                align="r_m", dx=-3.0, priority=3)

    # --- 推進方向矢印（外壁面から延びる） ---
    arrow_len = max(ent_r * 2, ARROW_BASE)  # 矢印幹長 mm
    head_l = max(300, ent_r * 0.25)          # 矢羽長 mm
    head_w = head_l * 0.4                     # 矢羽幅 mm

    if is_start:
        ax0 = L + wt
        ax1 = ax0 + arrow_len
        v.line((ax0, ent_cy), (ax1, ent_cy), "8-PROPOSED")
        v.polyline([(ax1, ent_cy),
                    (ax1 - head_l, ent_cy - head_w),
                    (ax1 - head_l, ent_cy + head_w)],
                   "8-PROPOSED", close=True)
        v.label("推進方向",
                ((ax0 + ax1) / 2, ent_cy), TH_SMALL, "3-TEXT",
                align="c_b", dy=3.0)
    else:
        ax0 = -wt
        ax1 = ax0 - arrow_len
        v.line((ax0, ent_cy), (ax1, ent_cy), "8-PROPOSED")
        v.polyline([(ax1, ent_cy),
                    (ax1 + head_l, ent_cy - head_w),
                    (ax1 + head_l, ent_cy + head_w)],
                   "8-PROPOSED", close=True)
        v.label("推進方向",
                ((ax0 + ax1) / 2, ent_cy), TH_SMALL, "3-TEXT",
                align="c_b", dy=3.0)

    # --- 平面寸法（実寸mmの2点指定・紙面mm の離れ）---
    v.dim((0, -wt), (L, -wt), orient="h", offset_mm=16,
          text=f"内空L={inp.length_m:.1f}m")
    v.dim((-wt, 0), (-wt, W), orient="v", offset_mm=16,
          text=f"内空W={inp.width_m:.1f}m")

    return v


# ============================================================
# 断面図 View
# ============================================================

def _build_section_view(panel: Panel, inp: ShaftInput, preferred_scale: float) -> View:
    """断面図 View を構築する（全図形を実寸mmで記述）

    座標系: X=推進方向（0〜L_mm）、Y=深さ（0=掘削底、depth_mm=GL）。
    矢板は X=-WALL_T〜0（左）と X=L〜L+WALL_T（右）。
    """
    L = inp.length_m * 1000
    depth_mm = inp.depth_m * 1000
    gw_mm = inp.ground_water_depth_m * 1000   # GL から水位までの深さ mm
    ent_r = inp.entrance_od_mm / 2             # 坑口半径 mm
    wt = WALL_T
    GL = depth_mm    # GL の Y 座標（=掘削深さ）

    pile_bot = -PILE_BELOW   # 矢板下端（掘削底より下）
    pile_top = GL + PILE_ABOVE

    v = View(panel, preferred_scale=preferred_scale, title="【断面図】")

    # --- 地表面ハッチ（GL より上の土） ---
    v.hatch_rect(-wt - 300, GL, L + wt + 300, GL + GROUND_ABOVE,
                 "ANSI31", "4-HATCH", 1.5)

    # --- GL 地表面線 ---
    v.line((-wt - 300, GL), (L + wt + 300, GL), "15-GROUND")
    # GL ラベル（左壁外縁に貼り付け）
    v.label("GL", (-wt, GL), TH_SMALL, "15-GROUND",
            align="r_m", dx=-3.0, priority=2)

    # --- 山留壁（左右の鋼矢板）---
    # 左壁
    v.rect(-wt, pile_bot, 0, pile_top, "14-SHAFT")
    v.hatch_rect(-wt, pile_bot, 0, pile_top, "ANSI31", "4-HATCH", 0.6)
    # 右壁
    v.rect(L, pile_bot, L + wt, pile_top, "14-SHAFT")
    v.hatch_rect(L, pile_bot, L + wt, pile_top, "ANSI31", "4-HATCH", 0.6)

    # --- 掘削底 ---
    v.line((-wt, 0), (L + wt, 0), "0-OUTLINE")
    v.label("掘削底", (L, 0), TH_SMALL, "3-TEXT",
            align="l_m", dx=3.0)

    # --- 地下水位 ---
    water_y = GL - gw_mm
    v.line((-wt, water_y), (L + wt, water_y), "16-WATER")
    v.label(f"▽地下水位 GL-{inp.ground_water_depth_m:.1f}m",
            (L, water_y), TH_SMALL, "16-WATER",
            align="l_m", dx=3.0, priority=4)

    # --- 切梁（等間隔に struts_count 段）---
    for i in range(1, inp.struts_count + 1):
        # Y 座標: GL から等間隔に配置
        strut_y = GL - depth_mm * i / (inp.struts_count + 1)
        v.line((-wt, strut_y), (L + wt, strut_y), "0-OUTLINE")
        v.label(f"{inp.strut_type}  第{i}段",
                (L + wt, strut_y), TH_SMALL, "3-TEXT",
                align="l_m", dx=3.0, priority=5)

    # --- 坑口（推進方向側の壁に円）---
    ent_center_y = ent_r + 300   # 掘削底から少し上に入口中心
    if inp.shaft_type == "start":
        ent_cx = L   # 右壁内面（推進出口側）
        lbl_align = "l_m"
        lbl_dx = 3.0
    else:
        ent_cx = 0   # 左壁内面（到達側）
        lbl_align = "r_m"
        lbl_dx = -3.0
    v.circle((ent_cx, ent_center_y), ent_r, "8-PROPOSED")
    v.label(f"坑口 φ{inp.entrance_od_mm}",
            (ent_cx, ent_center_y), TH_SMALL, "8-PROPOSED",
            align=lbl_align, dx=lbl_dx, priority=3)

    # --- 断面寸法 ---
    # 掘削深さ（左側縦寸法）
    v.dim((-wt, 0), (-wt, GL), orient="v", offset_mm=22,
          text=f"H={inp.depth_m:.1f}m")
    # 内空幅（下部横寸法 ← 掘削底直下）
    v.dim((0, 0), (L, 0), orient="h", offset_mm=16,
          text=f"内空L={inp.length_m:.1f}m")

    return v


# ============================================================
# 外部 API
# ============================================================

def draw_shaft(inp: ShaftInput, out_path: str) -> dict:
    """立坑構造図を生成し DXF ファイルへ保存する。

    戻り値: {"output": out_path, "shaft": shaft_name, "dimensions": "L×W×H"}
    外部契約（引数・戻り値キー）は suishin.py の依存に合わせて不変とする。
    """
    shaft_kind = "発進立坑" if inp.shaft_type == "start" else "到達立坑"

    d = OgumiDXF(
        paper=inp.paper,
        scale=inp.scale,
        title=f"{inp.shaft_name} 構造図",
        drawing_no=inp.drawing_no,
        project=inp.project_name,
        client=inp.client,
        designer=inp.designer,
    )

    # ── レイアウト: 上 5/6 = 図面、下 1/6 = 仕様表 ──
    main = d.content_panel()
    rows = split_rows(main, [5, 1], gap=4, names=["drawing_area", "table_area"])
    drawing_area, table_area = rows[0], rows[1]

    # ── 図面領域を横 2 分割: 左=平面図、右=断面図 ──
    cols = split_cols(drawing_area, [1, 1], gap=4,
                      names=["plan_panel", "section_panel"])
    plan_panel, sect_panel = cols[0], cols[1]

    # ── 両 View を構築 ──
    v_plan = _build_plan_view(plan_panel, inp, preferred_scale=inp.scale)
    v_sect = _build_section_view(sect_panel, inp, preferred_scale=inp.scale)

    # ── 縮尺を両パネルで揃える ──
    # 片方だけ粗くならないよう、大きい方（粗い縮尺）に揃える。
    # preferred_scale を更新するだけで、emit() 内の resolve_scale() が正しく再計算する。
    plan_s = v_plan.resolve_scale()
    sect_s = v_sect.resolve_scale()
    common_s = max(plan_s, sect_s)
    v_plan.preferred_scale = common_s
    v_sect.preferred_scale = common_s
    # 揃えた縮尺は必ず守らせる（片方だけ用紙最適化されると縮尺が食い違う）
    v_plan.lock_scale = True
    v_sect.lock_scale = True

    # ── 配置 ──
    d.place(v_plan)
    d.place(v_sect)

    # ── 仕様表（紙面mmで配置）──
    spec_rows = [
        ["項目", "仕様"],
        ["種別", shaft_kind],
        ["内空寸法", f"L={inp.length_m:.1f}m × W={inp.width_m:.1f}m × H={inp.depth_m:.1f}m"],
        ["山留工", inp.steel_sheet_pile],
        ["切梁", f"{inp.strut_type} × {inp.struts_count}段"],
        ["坑口寸法", f"φ{inp.entrance_od_mm}mm"],
        ["工法", f"{inp.method} φ{inp.diameter_mm}mm"],
    ]
    col_widths = [38.0, 108.0]  # 合計 146mm
    table_top = table_area.y + table_area.h  # テーブル左上（紙面mm）
    d.table(
        table_area.x + 2, table_top,
        spec_rows, col_widths,
        row_h=6.0, height=TH_SMALL, header=True,
        title="【仕様】",
    )

    # ── 凡例（仕様表の右隣）──
    legend_x = table_area.x + sum(col_widths) + 14
    d.legend(
        legend_x, table_top,
        [
            ("14-SHAFT", "山留壁（鋼矢板）"),
            ("0-OUTLINE", "掘削底・切梁"),
            ("8-PROPOSED", "坑口"),
            ("16-WATER", "地下水位"),
            ("15-GROUND", "地表面GL"),
        ],
        title="【凡例】",
    )

    meta = {"立坑種別": shaft_kind,
            "工法": f"{inp.method} φ{inp.diameter_mm}mm",
            "採用縮尺": f"1/{int(common_s)}"}
    d.finish(out_path)
    return {
        "output": out_path,
        "shaft": inp.shaft_name,
        "dimensions": f"{inp.length_m}×{inp.width_m}×H{inp.depth_m}",
    }


def main() -> None:
    if len(sys.argv) < 3:
        print("Usage: gen_shaft.py <input.json> <output.dxf>")
        sys.exit(1)
    inp = ShaftInput.from_json(sys.argv[1])
    print(json.dumps(draw_shaft(inp, sys.argv[2]), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
