#!/usr/bin/env python3
"""推進工法図面エンジン 統合ディスパッチャ
1本のプロジェクトYAML/JSONから全図面種類を一括生成する
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Any

# サブモジュールをimport可能にする
sys.path.insert(0, str(Path(__file__).parent))
from method_engine import MethodEngine
from gen_kanwari import KanwariInput, draw_kanwari
from gen_thrust_calc import ThrustInput, compute_thrust, render_excel
from gen_alignment import AlignmentInput, draw_alignment
from gen_shaft import ShaftInput, draw_shaft
from gen_others import GENERATORS as OTHER_GENERATORS
from gen_construction_plan import render as render_construction_plan
from doctor import Doctor, exit_code_for as doctor_exit_code
import ipguard_bridge  # ご利用確認 (承認実績の無い端末では 1 点も作らない)

# ご利用確認を通らなかったときの終了コード (0=合格, 1=不合格, 2=未対応 と重ねない)
EXIT_LICENSE_DENIED = 3


DRAWING_TYPES = [
    "kanwari",              # 管割図
    "thrust_calc",          # 推力計算書
    "alignment",            # 線形図
    "shaft_start",          # 発進立坑構造図
    "shaft_arrival",        # 到達立坑構造図
    "entrance_reinforcement",   # 坑口改良図
    "yard_layout",          # 推進設備配置図
    "construction_plan",    # 施工計画書
    "location",             # 位置図
    "system_diagram",       # 系統図
    "plan_profile",         # 平面縦断図
    "safety_management",    # 保安管理図
    "manhole",              # 人孔構造図
]

# 図面種別の日本語名。--only に日本語で指定されても受けられるようにし、
# 対応外の指定 (例: 配筋図) を「無いものは無い」と名指しで返すために使う。
DRAWING_TYPE_LABELS = {
    "kanwari": "管割図",
    "thrust_calc": "推力計算書",
    "alignment": "線形図",
    "shaft_start": "発進立坑構造図",
    "shaft_arrival": "到達立坑構造図",
    "entrance_reinforcement": "坑口改良図",
    "yard_layout": "推進設備配置図",
    "construction_plan": "施工計画書",
    "location": "位置図",
    "system_diagram": "系統図",
    "plan_profile": "平面縦断図",
    "safety_management": "保安管理図",
    "manhole": "人孔構造図",
}
_TYPE_ALIASES = {k: k for k in DRAWING_TYPES}
_TYPE_ALIASES.update({v: k for k, v in DRAWING_TYPE_LABELS.items()})


def resolve_targets(only):
    """--only の指定を内部キーへ解決する。
    対応外の指定は黙って捨てず、未対応として呼び出し元へ返す
    (捨てると『0 件生成なのに合格』に見えるため)。"""
    if not only:
        return list(DRAWING_TYPES), []
    resolved, unsupported = [], []
    for name in only:
        key = _TYPE_ALIASES.get(str(name).strip())
        if key is None:
            unsupported.append(str(name).strip())
        elif key not in resolved:
            resolved.append(key)
    return resolved, unsupported


def run_project(project_path: str, out_dir: str, only: list = None,
                preview: bool = True) -> dict:
    """
    プロジェクト定義を読み込み、指定図面を全部生成する
    """
    project_path = Path(project_path)
    out_dir_p = Path(out_dir)

    # ご利用確認 (IP-057) を入口で 1 回通す。承認実績の無い端末では出力先も作らず、
    # LicenseDenied を投げて 1 点も作らない (各書き出し経路にも同じ確認があり二重に守る)。
    lic = ipguard_bridge.require_license(ipguard_bridge.STAGE_PROJECT)

    out_dir_p.mkdir(parents=True, exist_ok=True)

    project = json.load(open(project_path, encoding="utf-8"))
    engine = MethodEngine()

    results = {"project": project.get("project_name", ""), "outputs": [], "validations": [],
               "ご利用確認": ipguard_bridge.license_summary(lic)}

    # 事前検証
    for span in project.get("spans", []):
        v = engine.validate(
            method=project["method"],
            diameter_mm=span["diameter_mm"],
            length_m=span["length_m"],
            curve_radius_m=(span.get("curves") or [{}])[0].get("radius_m"),
            curved=bool(span.get("curves")),
        )
        results["validations"].append(v)
        if v["verdict"] == "NG":
            print(f"⚠ 事前検証NG: {v['errors']}", file=sys.stderr)

    prefix = out_dir_p / project.get("project_code", "PRJ")

    targets, unsupported = resolve_targets(only)
    results["requested_types"] = list(only) if only else list(DRAWING_TYPES)
    results["unsupported_types"] = unsupported
    if unsupported:
        print(f"⚠ 本エンジンが対応していない図面種別です: {', '.join(unsupported)}",
              file=sys.stderr)
        print(f"  対応図面: {', '.join(DRAWING_TYPE_LABELS.values())}", file=sys.stderr)

    # 1. 管割図
    if "kanwari" in targets:
        inp = KanwariInput(
            project_name=project["project_name"],
            drawing_no=project.get("drawing_no_prefix", "") + "-K",
            client=project.get("client", ""),
            method=project["method"],
            spans=_load_spans(project.get("spans", [])),
            paper=project.get("paper", "A1"),
            scale=float(project.get("scales", {}).get("kanwari", 100)),
            designer=project.get("designer", ""),
        )
        out = str(out_dir_p / "01_kanwari.dxf")
        meta = draw_kanwari(inp, out)
        (out_dir_p / "01_kanwari_meta.json").write_text(
            json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        results["outputs"].append({"type": "kanwari", "path": out, "meta": meta})

    # 2. 推力計算書
    if "thrust_calc" in targets:
        for span in project.get("spans", []):
            curves = span.get("curves") or []
            tinp = ThrustInput(
                project_name=project["project_name"],
                drawing_no=project.get("drawing_no_prefix", "") + "-C",
                client=project.get("client", ""),
                method=project["method"],
                diameter_mm=span["diameter_mm"],
                length_m=span["length_m"],
                soil=span.get("soil", project.get("soil", "粘性土")),
                depth_m=span.get("depth_m", project.get("depth_m", 5.0)),
                curve_present=bool(curves),
                curve_radius_m=(curves[0]["radius_m"] if curves else None),
                curve_length_m=sum(c.get("arc_length_m", 0) for c in curves) if curves else 0,
                friction_reduction_lube=project.get("friction_reduction_lube", 0.60),
                safety_factor_required=project.get("safety_factor_required", 1.5),
                designer=project.get("designer", ""),
            )
            calc = compute_thrust(tinp)
            out = str(out_dir_p / f"02_thrust_{_slug(span['name'])}.xlsx")
            render_excel(tinp, calc, out)
            results["outputs"].append({"type": "thrust_calc", "path": out, "result": calc})

    # 3. 線形図
    if "alignment" in targets and project.get("alignment_points"):
        from gen_alignment import SurveyPoint
        pts = [SurveyPoint(**p) for p in project["alignment_points"]]
        ai = AlignmentInput(
            project_name=project["project_name"],
            drawing_no=project.get("drawing_no_prefix", "") + "-A",
            client=project.get("client", ""),
            method=project["method"],
            points=pts,
            curves=project.get("alignment_curves", []),
            paper=project.get("paper", "A1"),
            scale=float(project.get("scales", {}).get("alignment", 500)),
            designer=project.get("designer", ""),
        )
        out = str(out_dir_p / "03_alignment.dxf")
        results["outputs"].append({"type": "alignment", "path": out,
                                    "meta": draw_alignment(ai, out)})

    # 4-5. 立坑構造図 (発進・到達)
    for typ, key in [("shaft_start", "start"), ("shaft_arrival", "arrival")]:
        if typ in targets and project.get("shafts", {}).get(key):
            sd = project["shafts"][key]
            sd.setdefault("project_name", project["project_name"])
            sd.setdefault("client", project.get("client", ""))
            sd.setdefault("drawing_no", project.get("drawing_no_prefix", "") + f"-S{key[0].upper()}")
            sd.setdefault("shaft_type", key)
            sd.setdefault("shaft_name", f"{'発進' if key=='start' else '到達'}立坑 " + sd.get("shaft_name", ""))
            sd.setdefault("method", project["method"])
            sd.setdefault("diameter_mm", project["spans"][0]["diameter_mm"])
            sd.setdefault("designer", project.get("designer", ""))
            sd.setdefault("paper", project.get("paper", "A1"))
            sd.setdefault("scale", float(project.get("scales", {}).get("shaft", 50)))
            si = ShaftInput(**sd)
            out = str(out_dir_p / f"04_shaft_{key}.dxf")
            results["outputs"].append({"type": typ, "path": out,
                                        "meta": draw_shaft(si, out)})

    # 6-13. その他図面
    for typ, gen_fn in OTHER_GENERATORS.items():
        if typ not in targets:
            continue
        data = project.get(typ)
        if not data:
            # プロジェクト側にセクションがなければ、基本情報から合成
            data = _synthesize_data(project, typ)
        data.setdefault("project_name", project["project_name"])
        data.setdefault("client", project.get("client", ""))
        data.setdefault("drawing_no", project.get("drawing_no_prefix", "") + f"-{typ[:2].upper()}")
        data.setdefault("designer", project.get("designer", ""))
        data.setdefault("paper", project.get("paper", "A2"))
        out = str(out_dir_p / f"XX_{typ}.dxf")
        try:
            meta = gen_fn(data, out)
            results["outputs"].append({"type": typ, "path": out, "meta": meta})
        except Exception as e:
            results["outputs"].append({"type": typ, "path": out, "error": str(e)})

    # 施工計画書 Excel
    if "construction_plan" in targets:
        cp_data = {
            "project_name": project["project_name"],
            "drawing_no": project.get("drawing_no_prefix", "") + "-P",
            "client": project.get("client", ""),
            "site_address": project.get("site_address", ""),
            "construction_period": project.get("construction_period", ""),
            "method": project["method"],
            "diameter_mm": project["spans"][0]["diameter_mm"],
            "length_m": sum(sp["length_m"] for sp in project["spans"]),
            "soil": project.get("soil", "粘性土"),
            "depth_m": project.get("depth_m", 5.0),
            "curve_present": any(sp.get("curves") for sp in project["spans"]),
            "min_curve_radius_m": min(
                (c.get("radius_m", 99999) for sp in project["spans"] for c in sp.get("curves", [])),
                default=None,
            ),
            "designer": project.get("designer", ""),
            "agent": project.get("agent", ""),
            "supervisor": project.get("supervisor", ""),
            "date": project.get("date", ""),
            "machine_type": project["spans"][0].get("machine_type", ""),
        }
        out = str(out_dir_p / "10_construction_plan.xlsx")
        render_construction_plan(cp_data, out)
        results["outputs"].append({"type": "construction_plan", "path": out})

    # ドクター実行
    doc = Doctor()
    # 対応外の指定・0 件生成を検査結果として明示的に残す。
    # これを残さないと検査 0 件のまま総合合格に見えてしまう。
    for name in unsupported:
        doc.add_not_applicable(
            f"図面種別: {name}",
            "本エンジンの対応図面ではありません (推進工法図面 13 種のみ)。"
            f"対応図面: {', '.join(DRAWING_TYPE_LABELS.values())}")
    if not results["outputs"]:
        req = "、".join(results["requested_types"])
        doc.add_not_applicable(
            "生成物",
            f"指定 ({req}) に対して生成物が 0 件でした。"
            "対応外の種別か、プロジェクト定義に必要なデータがありません。")
    for output in results["outputs"]:
        p = Path(output["path"])
        if p.suffix == ".dxf":
            doc.check_dxf(str(p))
        elif p.suffix == ".xlsx" and "thrust" not in p.name:
            doc.check_construction_plan(str(p))
        elif p.suffix == ".xlsx" and "thrust" in p.name and "result" in output:
            doc.check_thrust({"result": output["result"]})
    for meta_file in out_dir_p.glob("*_meta.json"):
        doc.check_kanwari_meta(str(meta_file))
    doctor_report = doc.summary()
    (out_dir_p / "doctor_report.json").write_text(
        json.dumps(doctor_report, ensure_ascii=False, indent=2), encoding="utf-8")

    results["doctor"] = doctor_report

    # プレビュー画像（CADを開かずに図面を確認できるようにする）
    if preview:
        results["preview"] = _render_previews(out_dir_p)

    (out_dir_p / "manifest.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    return results


def _render_previews(out_dir_p: Path) -> dict:
    """生成した全DXFをPNG化する。失敗しても生成物は壊さない。"""
    try:
        from render import render_dxf
    except Exception as e:
        return {"enabled": False, "reason": f"レンダラを読み込めません: {e}"}
    pv_dir = out_dir_p / "preview"
    pv_dir.mkdir(exist_ok=True)
    made, failed = [], []
    for dxf in sorted(out_dir_p.glob("*.dxf")):
        png = pv_dir / f"{dxf.stem}.png"
        try:
            render_dxf(str(dxf), str(png), mode="sheet")
            made.append(str(png))
        except Exception as e:
            failed.append({"file": dxf.name, "error": str(e)})
    return {"enabled": True, "dir": str(pv_dir),
            "rendered": len(made), "failed": failed}


def _load_spans(spans: list) -> list:
    from gen_kanwari import Span, Curve
    out = []
    for sp in spans:
        curves = []
        for c in sp.get("curves", []):
            cc = Curve(**c)
            cc.resolve()
            curves.append(cc)
        sp2 = {k: v for k, v in sp.items() if k != "curves"}
        out.append(Span(curves=curves, **sp2))
    return out


def _slug(s: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in s)[:30]


def _synthesize_data(project: dict, typ: str) -> dict:
    """プロジェクト情報から各図面用データを合成"""
    span0 = project["spans"][0]
    total_L = sum(sp["length_m"] for sp in project["spans"])
    base = {
        "project_name": project["project_name"],
        "client": project.get("client", ""),
        "site_address": project.get("site_address", ""),
        "method": project["method"],
        "diameter_mm": span0["diameter_mm"],
        "length_m": total_L,
    }
    if typ == "entrance_reinforcement":
        base.update({
            "shaft_type": "start",
            "entrance_od_mm": int(span0["diameter_mm"] * 1.5),
            "improvement_radius_m": 3.0,
            "improvement_depth_m": project.get("depth_m", 5.0) + 1.0,
            "improvement_method": "薬液注入工法",
        })
    elif typ == "yard_layout":
        base.update({"yard_width_m": 30, "yard_depth_m": 20})
    elif typ == "safety_management":
        pass
    elif typ == "manhole":
        base.update({
            "inner_diameter_mm": 900,
            "outer_diameter_mm": 1200,
            "total_height_m": project.get("depth_m", 5.0),
            "inlet_pipe_mm": span0["diameter_mm"],
            "outlet_pipe_mm": span0["diameter_mm"],
            "manhole_name": "組立式2号人孔",
        })
    elif typ == "location":
        pass
    elif typ == "system_diagram":
        # スパンをそのままエッジに変換
        nodes = [{"id": f"MH-{i+1}", "type": "起点" if i == 0 else "終点" if i == len(project["spans"]) else "中間人孔",
                  "x": 50 + i * 100, "y": 200, "invert": -3.5 - i * 0.5}
                 for i in range(len(project["spans"]) + 1)]
        edges = [{"from": f"MH-{i+1}", "to": f"MH-{i+2}",
                  "length_m": sp["length_m"], "diameter": sp["diameter_mm"],
                  "method": project["method"]}
                 for i, sp in enumerate(project["spans"])]
        base.update({"nodes": nodes, "edges": edges})
    elif typ == "plan_profile":
        base.update({
            "length_m": span0["length_m"],
            "diameter_mm": span0["diameter_mm"],
            "start_shaft": span0.get("start_shaft", "No.1"),
            "arrival_shaft": span0.get("arrival_shaft", "No.2"),
            "slope_permil": 5,
            "depth_start_m": project.get("depth_m", 5.0),
            "ground_water_depth_m": 3.0,
        })
    return base


def main():
    ap = argparse.ArgumentParser(description="推進工法図面エンジン 統合ディスパッチャ")
    ap.add_argument("project", help="プロジェクト定義JSON")
    ap.add_argument("out_dir", help="出力先ディレクトリ")
    ap.add_argument("--only", nargs="+", help="生成する図面種類のみ指定", default=None)
    ap.add_argument("--no-preview", action="store_true",
                    help="プレビューPNGを生成しない")
    args = ap.parse_args()
    try:
        results = run_project(args.project, args.out_dir, only=args.only,
                              preview=not args.no_preview)
    except ipguard_bridge.LicenseDenied as exc:
        # 承認実績の無い端末。図面・計算書は 1 点も作っていない。
        print(ipguard_bridge.denied_message(exc), file=sys.stderr)
        sys.exit(EXIT_LICENSE_DENIED)
    summary = {
        "outputs_count": len(results["outputs"]),
        "doctor": results["doctor"]["verdict"],
        "doctor_ja": results["doctor"]["verdict_ja"],
        "doctor_counts": results["doctor"]["counts"],
        "outputs": [{"type": o["type"], "path": o["path"]} for o in results["outputs"]],
    }
    if results.get("unsupported_types"):
        summary["unsupported_types"] = results["unsupported_types"]
        summary["supported_types"] = list(DRAWING_TYPE_LABELS.values())
    if results["doctor"]["verdict"] == "NOT_APPLICABLE":
        summary["note"] = ("合否を付けた検査は 0 件です。合格ではありません "
                           "(未対応の図面種別、または生成物 0 件)。")
    if results.get("preview"):
        summary["preview"] = results["preview"].get("dir")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    # FAIL は壊れた図面、NOT_APPLICABLE は何も検査していない状態。
    # どちらも正常終了させない (0 件生成を合格に丸めない)。
    sys.exit(doctor_exit_code(results["doctor"]["verdict"]))


if __name__ == "__main__":
    main()
