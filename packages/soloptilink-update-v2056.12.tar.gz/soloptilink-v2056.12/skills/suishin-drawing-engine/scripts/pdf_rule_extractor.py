#!/usr/bin/env python3
# 推進工法技術資料PDF ルール抽出エンジン
# 目的: 19本の技術PDFから 管割ルール・推力計算式・寸法表・曲線対応条件 を構造化JSONに落とす

import json
import re
import sys
from pathlib import Path
import pdfplumber

# 対象PDFの分類マップ (工法名 -> パターン)
METHOD_MAP = {
    "エースモール":    ["エースモール", "TP406050"],
    "リバースエース":  ["リバースエース"],
    "コマンド":        ["コマンド工法"],
    "Two-Way":         ["Two-Way", "ツーウェイ"],
    "ハイブリッド":    ["ハイブリッド"],
    "ベビーモール":    ["ベビーモール"],
    "スリムアーク":    ["スリムアーク", "TA500"],
    "アンクルモール":  ["アンクルモール"],
    "アンクルモールミニ":["アンクルモールミニ"],
    "Smart犀":         ["Smart犀"],
    "ラムサス":        ["ラムサス"],
    "ラムサスS":       ["ラムサス-S", "ラムサスS"],
    "Sリード":         ["Ｓ－リード", "S-リード", "Sリード"],
    "ユニコーン":      ["ユニコーン"],
    "ヒューム管":      ["ヒューム管"],
}

# 抽出したい正規化キーワード
KEY_PATTERNS = {
    "適用口径":     [r"適用口径", r"適用管径", r"呼び径", r"呼径", r"仕上り内径", r"内径"],
    "推進延長":     [r"推進延長", r"最大推進延長", r"標準推進延長", r"1スパン"],
    "曲線半径":     [r"曲線半径", r"最小曲線半径", r"最小R", r"曲線R", r"急曲線"],
    "推力計算":     [r"推力", r"元押力", r"許容押込力", r"総推力"],
    "管長":         [r"管長", r"標準管長", r"1本の長さ"],
    "掘進機外径":   [r"掘進機外径", r"機械外径", r"掘進機仕様"],
    "坑口":         [r"坑口", r"発進坑口", r"到達坑口", r"エントランス"],
    "土被り":       [r"土被り", r"土かぶり", r"最小土被り"],
    "適用土質":     [r"適用土質", r"適用地盤", r"土質条件"],
    "中押":         [r"中押", r"中押工", r"中押ジャッキ"],
    "滑材":         [r"滑材", r"滑材注入", r"低減材"],
}

# 数値表現の正規化 (mm/m/kN/度/% を持つトークン)
NUMBER_PATTERN = re.compile(
    r"(?P<value>[\d,]+(?:\.\d+)?)\s*"
    r"(?P<unit>mm|㎜|㎜|m|ｍ|kN|ｋN|ton|t|度|°|%|R=|φ|Φ|Ø)?"
)


def detect_method(pdf_name: str) -> str:
    for method, patterns in METHOD_MAP.items():
        for p in patterns:
            if p in pdf_name:
                return method
    return "不明"


def extract_pdf(pdf_path: Path) -> dict:
    method = detect_method(pdf_path.name)
    result = {
        "source_pdf": pdf_path.name,
        "method": method,
        "extracted_at": "auto",
        "sections": {},
        "raw_snippets": {},
        "page_count": 0,
    }

    try:
        with pdfplumber.open(pdf_path) as pdf:
            result["page_count"] = len(pdf.pages)
            all_text = []
            all_tables = []
            for i, page in enumerate(pdf.pages):
                try:
                    text = page.extract_text() or ""
                except Exception:
                    text = ""
                all_text.append(text)
                try:
                    tables = page.extract_tables()
                    for t in tables:
                        all_tables.append({"page": i + 1, "rows": t})
                except Exception:
                    pass
            full_text = "\n".join(all_text)

            for key, patterns in KEY_PATTERNS.items():
                snippets = []
                for p in patterns:
                    for m in re.finditer(rf"([^。\n]{{0,60}}{p}[^。\n]{{0,120}})", full_text):
                        snippet = m.group(1).strip()
                        if len(snippet) > 8:
                            snippets.append(snippet)
                unique = list(dict.fromkeys(snippets))[:10]
                if unique:
                    result["sections"][key] = unique

            numeric_findings = []
            for line in full_text.split("\n"):
                if any(kw in line for kw in ["φ", "Φ", "呼び径", "内径", "推進延長", "曲線半径",
                                              "管長", "推力", "土被り", "kN", "㎜", "mm"]):
                    numeric_findings.append(line.strip())
            result["numeric_lines"] = numeric_findings[:80]

            table_summary = []
            for t in all_tables[:30]:
                rows = t["rows"]
                if rows and len(rows) > 1:
                    table_summary.append({
                        "page": t["page"],
                        "shape": [len(rows), len(rows[0]) if rows[0] else 0],
                        "header": rows[0] if rows[0] else [],
                        "sample_row": rows[1] if len(rows) > 1 else [],
                    })
            result["tables_summary"] = table_summary

    except Exception as e:
        result["error"] = str(e)

    return result


def main():
    src_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(
        "/private/tmp/claude-501/-Users-(作業端末)-Downloads---------/43ba77bc-83e1-4a41-b180-c54e778622f8/scratchpad/extract/推進技術資料"
    )
    out_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(
        str(Path(__file__).resolve().parent.parent / "rules" / "raw")
    )
    out_dir.mkdir(parents=True, exist_ok=True)

    pdfs = sorted(src_dir.glob("*.pdf"))
    print(f"[抽出開始] {len(pdfs)}本のPDFを処理", flush=True)

    manifest = []
    for pdf in pdfs:
        print(f"  … {pdf.name}", flush=True)
        try:
            data = extract_pdf(pdf)
        except Exception as e:
            data = {"source_pdf": pdf.name, "error": str(e)}
        out_path = out_dir / (pdf.stem + ".json")
        out_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        manifest.append({
            "pdf": pdf.name,
            "method": data.get("method", "?"),
            "pages": data.get("page_count", 0),
            "sections_found": list(data.get("sections", {}).keys()),
            "tables_found": len(data.get("tables_summary", [])),
        })

    (out_dir / "_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"[抽出完了] {len(manifest)}本 → {out_dir}", flush=True)


if __name__ == "__main__":
    main()
