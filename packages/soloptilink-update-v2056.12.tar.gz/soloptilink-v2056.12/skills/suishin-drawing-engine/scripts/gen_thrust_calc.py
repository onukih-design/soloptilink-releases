#!/usr/bin/env python3
"""推力計算書 Excel 生成
推進工法用鉄筋コンクリート管技術資料 準拠の基本推力計算式:
  総推力 F = f0 + f × L
  f0 = 掘進機先端抵抗 (kN)
  f  = 管周面抵抗 (kN/m) = μ × 管重 + 土圧起因抵抗
  L  = 推進延長 (m)
安全率 SF = 許容押込力 / 総推力  ≥ 1.5 が必要
中押ジャッキ配置は元押のみで不足時に自動提案
"""
from __future__ import annotations
import json
import math
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

import ipguard_bridge  # ご利用確認と出所の印 (書き出しの直前で必ず通す)


# 工法・口径別の代表値（技術資料PDFから抽出した典型値）
MACHINE_THRUST_ALLOW_KN = {
    ("エースモール", 250): 800, ("エースモール", 300): 1200, ("エースモール", 350): 1500,
    ("エースモール", 450): 2500, ("エースモール", 500): 3000, ("エースモール", 600): 4000,
    ("エースモール", 700): 5000,
    ("Two-Way", 800): 6000, ("Two-Way", 1000): 8000, ("Two-Way", 1350): 12000,
    ("Two-Way", 1500): 15000, ("Two-Way", 1650): 17000, ("Two-Way", 2000): 22000,
    ("Two-Way", 2200): 26000, ("Two-Way", 2400): 30000,
    ("コマンド", 250): 800, ("コマンド", 350): 1500, ("コマンド", 500): 3000, ("コマンド", 700): 5000,
    ("ハイブリッド", 1000): 9000, ("ハイブリッド", 1350): 13000, ("ハイブリッド", 2000): 23000,
    ("ハイブリッド", 2200): 27000, ("ハイブリッド", 2400): 32000,
    ("ベビーモール", 150): 400, ("ベビーモール", 200): 500, ("ベビーモール", 250): 700,
    ("ベビーモール", 300): 900,
    "default": 5000,
}

# 土質別 管周面抵抗係数 f (kN/m/㎡)
FRICTION_COEF = {
    "粘性土":      0.30,
    "砂質土":      0.50,
    "礫混り土":    0.80,
    "軟弱土":      0.20,
    "巨石混り礫":  1.20,
}

# 掘進機先端抵抗 f0 (kN・口径・土質から見積り)
def machine_face_resistance(diameter_mm: int, soil: str) -> float:
    base_area = math.pi * (diameter_mm / 2000.0) ** 2  # 掘削断面積 (㎡)
    q = {"粘性土": 150, "砂質土": 250, "礫混り土": 400, "軟弱土": 100, "巨石混り礫": 600}.get(soil, 300)
    return round(q * base_area, 1)  # kN


def pipe_weight_kn_per_m(diameter_mm: int) -> float:
    """鉄筋コンクリート管の 単位長重量 (kN/m) 概算"""
    d = diameter_mm / 1000.0
    thickness = 0.05 + d * 0.10  # 概算厚 (m)
    volume = math.pi * ((d/2 + thickness) ** 2 - (d/2) ** 2)  # ㎥/m
    return round(volume * 24.5, 2)  # 鉄筋コン 24.5 kN/㎥


@dataclass
class ThrustInput:
    project_name: str
    drawing_no: str
    client: str
    method: str
    diameter_mm: int
    length_m: float
    soil: str = "粘性土"
    depth_m: float = 5.0
    curve_present: bool = False
    curve_radius_m: Optional[float] = None
    curve_length_m: float = 0.0
    friction_reduction_lube: float = 0.60   # 滑材注入による摩擦低減率（0.4=60%減）
    safety_factor_required: float = 1.5
    machine_allowable_kn: Optional[float] = None  # 未指定なら口径から推定
    designer: str = ""

    @classmethod
    def from_json(cls, path: str) -> "ThrustInput":
        return cls(**json.load(open(path, encoding="utf-8")))


def compute_thrust(inp: ThrustInput) -> dict:
    f0 = machine_face_resistance(inp.diameter_mm, inp.soil)
    pipe_w = pipe_weight_kn_per_m(inp.diameter_mm)
    mu = FRICTION_COEF.get(inp.soil, 0.5)
    # 管周面抵抗 (滑材効果適用)
    f_per_m = mu * pipe_w * (1 - inp.friction_reduction_lube)
    # 曲線抵抗の割増 (曲線区間は 20~40%増)
    curve_factor = 1.0
    if inp.curve_present and inp.curve_radius_m:
        curve_factor = 1.0 + max(0, (60 - inp.curve_radius_m) / 60) * 0.4
    f_per_m *= curve_factor

    thrust_kn = f0 + f_per_m * inp.length_m
    allow = inp.machine_allowable_kn or MACHINE_THRUST_ALLOW_KN.get(
        (inp.method, inp.diameter_mm), MACHINE_THRUST_ALLOW_KN["default"]
    )
    sf = allow / thrust_kn if thrust_kn > 0 else float("inf")
    verdict = "OK" if sf >= inp.safety_factor_required else "NG（中押ジャッキ必要）"
    # 中押ジャッキが必要なら推奨配置
    intermediate_jacks = 0
    if sf < inp.safety_factor_required:
        needed_reduction = 1 - (allow / (thrust_kn * inp.safety_factor_required))
        segment_len = inp.length_m * (1 - needed_reduction)
        intermediate_jacks = max(1, math.ceil(inp.length_m / segment_len) - 1)

    return {
        "f0_kn":            f0,
        "pipe_weight_kn_m": pipe_w,
        "mu":               mu,
        "friction_reduction": inp.friction_reduction_lube,
        "curve_factor":     round(curve_factor, 3),
        "f_per_m_kn":       round(f_per_m, 3),
        "total_thrust_kn":  round(thrust_kn, 1),
        "allowable_kn":     allow,
        "safety_factor":    round(sf, 2),
        "verdict":          verdict,
        "intermediate_jacks_recommended": intermediate_jacks,
    }


def render_excel(inp: ThrustInput, result: dict, out_path: str) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "推力計算書"
    thin = Side(style="thin", color="000000")
    med = Side(style="medium", color="000000")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    hdr_fill = PatternFill("solid", fgColor="1F4E79")
    hdr_font = Font(bold=True, color="FFFFFF", size=11)
    title_font = Font(bold=True, size=14, color="1F4E79")
    ok_fill = PatternFill("solid", fgColor="C6E0B4")
    ng_fill = PatternFill("solid", fgColor="F4B084")

    ws.column_dimensions['A'].width = 4
    ws.column_dimensions['B'].width = 22
    ws.column_dimensions['C'].width = 18
    ws.column_dimensions['D'].width = 18
    ws.column_dimensions['E'].width = 32

    # タイトル
    ws.merge_cells("B2:E2")
    ws["B2"] = f"推力計算書 ({inp.method} φ{inp.diameter_mm} L={inp.length_m}m)"
    ws["B2"].font = title_font
    ws["B2"].alignment = Alignment(horizontal="center", vertical="center")

    # 案件情報
    info = [
        ("工事名", inp.project_name),
        ("発注者", inp.client),
        ("図面No.", inp.drawing_no),
        ("設計者", inp.designer),
        ("計算日", "auto-generated"),
    ]
    r = 4
    for k, v in info:
        ws.cell(row=r, column=2, value=k).font = Font(bold=True)
        ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=5)
        ws.cell(row=r, column=3, value=v)
        for c in range(2, 6):
            ws.cell(row=r, column=c).border = border
        r += 1

    # 入力条件
    r += 1
    ws.cell(row=r, column=2, value="■ 入力条件").font = Font(bold=True, size=12, color="1F4E79")
    r += 1
    inputs = [
        ("項目", "値", "単位", "備考"),
        ("工法", inp.method, "-", ""),
        ("呼び径", inp.diameter_mm, "mm", ""),
        ("推進延長", inp.length_m, "m", ""),
        ("土質", inp.soil, "-", "PDF技術資料の適用土質参照"),
        ("土被り", inp.depth_m, "m", ""),
        ("曲線区間", "有" if inp.curve_present else "無", "-",
         f"R={inp.curve_radius_m}m" if inp.curve_present else ""),
        ("滑材注入", f"{int(inp.friction_reduction_lube*100)}%", "%減", "混合済み滑材系"),
        ("要求安全率", inp.safety_factor_required, "-", "SF≥1.5 標準"),
    ]
    _write_table(ws, r, 2, inputs, border, hdr_fill, hdr_font)
    r += len(inputs) + 2

    # 計算過程
    ws.cell(row=r, column=2, value="■ 計算過程").font = Font(bold=True, size=12, color="1F4E79")
    r += 1
    calcs = [
        ("項目", "計算値", "単位", "計算式・出典"),
        ("掘進機先端抵抗 f0", result["f0_kn"], "kN", f"q×A ({inp.soil} q値×掘削断面積)"),
        ("管単位重量", result["pipe_weight_kn_m"], "kN/m", "鉄筋コン管概算 24.5kN/㎥"),
        ("摩擦係数 μ", result["mu"], "-", f"{inp.soil} 標準値"),
        ("滑材低減率", f"{int(result['friction_reduction']*100)}%", "%", "混合済み滑材"),
        ("曲線抵抗補正", result["curve_factor"], "倍",
         "R≥60mで1.0、Rが小さいほど増加"),
        ("管周面抵抗 f", result["f_per_m_kn"], "kN/m", "μ×管重×(1-低減率)×曲線補正"),
        ("総推力 F = f0 + f×L", result["total_thrust_kn"], "kN", "推進協会標準式"),
    ]
    _write_table(ws, r, 2, calcs, border, hdr_fill, hdr_font)
    r += len(calcs) + 2

    # 判定
    ws.cell(row=r, column=2, value="■ 判定").font = Font(bold=True, size=12, color="1F4E79")
    r += 1
    is_ok = "OK" in result["verdict"]
    verdicts = [
        ("項目", "値", "単位", "備考"),
        ("必要推力 F", result["total_thrust_kn"], "kN", ""),
        ("掘進機許容押込力", result["allowable_kn"], "kN",
         f"{inp.method} φ{inp.diameter_mm} 標準値"),
        ("安全率 SF = 許容/必要", result["safety_factor"], "-",
         f"要求値 {inp.safety_factor_required}"),
        ("判定", result["verdict"], "-",
         f"中押ジャッキ {result['intermediate_jacks_recommended']}基 推奨"
         if not is_ok else "元押のみで施工可"),
    ]
    _write_table(ws, r, 2, verdicts, border, hdr_fill, hdr_font)
    # 判定行を色分け
    verdict_row = r + len(verdicts) - 1
    for c in range(2, 6):
        ws.cell(row=verdict_row, column=c).fill = ok_fill if is_ok else ng_fill
        ws.cell(row=verdict_row, column=c).font = Font(bold=True, size=12)

    # 中押ジャッキ提案
    r = verdict_row + 3
    if not is_ok:
        ws.cell(row=r, column=2, value="■ 中押ジャッキ配置提案").font = Font(bold=True, size=12, color="C00000")
        r += 1
        segment_len = round(inp.length_m / (result["intermediate_jacks_recommended"] + 1), 1)
        prop = [
            ("項目", "値", "単位", "備考"),
            ("中押ジャッキ基数", result["intermediate_jacks_recommended"], "基", ""),
            ("推奨区間長", segment_len, "m/基", "元押からの距離"),
            ("配置位置", ", ".join([f"{i*segment_len}m" for i in range(1, result["intermediate_jacks_recommended"] + 1)]),
             "m", "推進開始点からの距離"),
        ]
        _write_table(ws, r, 2, prop, border, hdr_fill, hdr_font)

    # ご利用確認 (IP-057)。通らなければ LicenseDenied を投げ、計算書は書かない。
    lic = ipguard_bridge.require_license(ipguard_bridge.STAGE_XLSX)
    # 出所の印はブックのプロパティにだけ入れる (セルの値・数式・書式は 1 つも変えない)
    origin = ipguard_bridge.stamp_workbook(wb, lic, drawing_no=inp.drawing_no)
    wb.save(out_path)
    ipguard_bridge.stamp_xlsx_company(out_path, origin.get("_mark") or {})


def _write_table(ws, start_row, start_col, rows, border, hdr_fill, hdr_font):
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            c = ws.cell(row=start_row + i, column=start_col + j, value=val)
            c.border = border
            c.alignment = Alignment(vertical="center", wrap_text=True)
            if i == 0:
                c.fill = hdr_fill
                c.font = hdr_font
                c.alignment = Alignment(horizontal="center", vertical="center")


def main():
    if len(sys.argv) < 3:
        print("Usage: python3 gen_thrust_calc.py <input.json> <output.xlsx>")
        sys.exit(1)
    inp = ThrustInput.from_json(sys.argv[1])
    result = compute_thrust(inp)
    try:
        render_excel(inp, result, sys.argv[2])
    except ipguard_bridge.LicenseDenied as exc:
        # 承認実績の無い端末。計算書は書いていない (終了コード 3)
        print(ipguard_bridge.denied_message(exc), file=sys.stderr)
        sys.exit(3)
    print(json.dumps({"output": sys.argv[2], "result": result}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
