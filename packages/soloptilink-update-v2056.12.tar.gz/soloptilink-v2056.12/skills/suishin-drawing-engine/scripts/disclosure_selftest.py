#!/usr/bin/env python3
import os
"""様式出典の開示（J-08）の両側検査

健全な図面では開示注記が入って PASS、壊した検体（開示なし／根拠の無い JIS 準拠の
名乗り／注記を消した改ざん）では必ず FAIL になることを実測する。
片側しか見ないと、検査が常に PASS を返すだけの飾りになっていても気づけない。

実行: python3 scripts/disclosure_selftest.py
""" 
import sys, os, shutil
sys.path.insert(0, os.path.expanduser("~/.claude/skills/suishin-drawing-engine/scripts"))
import ezdxf, drawing_qc, dxf_base
from dxf_base import OgumiDXF, TH_SMALL
from layout import View

import tempfile
W = os.path.join(tempfile.mkdtemp(prefix="suishin_disclosure_"), "j08")
shutil.rmtree(W, ignore_errors=True); os.makedirs(W)
fails = []
_total = 0
def check(name, ok, detail=""):
    global _total
    _total += 1
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: {detail}")
    if not ok: fails.append(name)

def build(path, patch=None):
    d = OgumiDXF(paper="A3", scale=100, title="開示検体", drawing_no="T-1",
                 project="J-08 検体", client="—", designer="—")
    v = View(d.content_panel(), preferred_scale=100, title="【検体】")
    v.rect(0, 0, 20000, 6000, "0-OUTLINE")
    d.place(v)
    if patch: patch(d)
    d.finish(path)
    return path

# --- 健全側 ---
good = build(f"{W}/good.dxf")
r = drawing_qc.analyze(good)["checks"]["standards_disclosure"]
check("健全: 開示注記が入り PASS", r["verdict"] == "PASS", r["detail"])
check("健全: 図面全体も PASS", drawing_qc.analyze(good)["verdict"] == "PASS")

# --- 欠陥検体A: 開示注記を描かない（古い版の図面と同じ状態） ---
_orig = OgumiDXF.draw_standards_disclosure
OgumiDXF.draw_standards_disclosure = lambda self: 0
try:
    bad_a = build(f"{W}/bad_no_disclosure.dxf")
finally:
    OgumiDXF.draw_standards_disclosure = _orig
ra = drawing_qc.analyze(bad_a)["checks"]["standards_disclosure"]
check("欠陥A: 開示注記が無いと FAIL", ra["verdict"] == "FAIL", ra["detail"])

# --- 欠陥検体B: 開示はあるが「JIS準拠」の名乗りを図面に足す ---
def add_claim(d):
    d.text_aligned("本図は JIS Z 8311 準拠", (120, 40), TH_SMALL, "3-TEXT", "l_b")
bad_b = build(f"{W}/bad_bare_claim.dxf", patch=add_claim)
rb = drawing_qc.analyze(bad_b)["checks"]["standards_disclosure"]
check("欠陥B: 開示を伴わない JIS 準拠の名乗りで FAIL",
      rb["verdict"] == "FAIL" and rb["bare_claims"] == 1, rb["detail"])

# --- 欠陥検体C: 開示注記を後から消したファイル（改ざん相当） ---
shutil.copy(good, f"{W}/tampered.dxf")
doc = ezdxf.readfile(f"{W}/tampered.dxf")
msp = doc.modelspace()
for e in [e for e in msp if e.dxftype() == "TEXT" and "規格票" in (e.dxf.text or "")]:
    msp.delete_entity(e)
doc.saveas(f"{W}/tampered.dxf")
rc = drawing_qc.analyze(f"{W}/tampered.dxf")["checks"]["standards_disclosure"]
check("欠陥C: 注記を消した図面で FAIL（ヘッダの申告だけでは通さない）",
      rc["verdict"] == "FAIL" and rc.get("header_flag") == "1", rc["detail"])

# --- ドクター側でも提出が止まることを測る ---
import doctor
D = doctor.Doctor(); D.check_layout(bad_a)
sm = D.summary()
check("ドクター: 開示欠落で総合 FAIL（提出を止める）", sm["verdict"] == "FAIL",
      str(sm["counts"]))
D2 = doctor.Doctor(); D2.check_layout(good)
check("ドクター: 健全な図面は総合 PASS", D2.summary()["verdict"] == "PASS",
      str(D2.summary()["counts"]))

print(f"\n[様式出典の開示 両側検査] PASS={_total-len(fails)} FAIL={len(fails)} {fails}")
shutil.rmtree(os.path.dirname(W), ignore_errors=True)
sys.exit(1 if fails else 0)
