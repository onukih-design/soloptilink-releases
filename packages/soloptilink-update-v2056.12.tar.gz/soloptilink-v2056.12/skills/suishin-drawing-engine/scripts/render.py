#!/usr/bin/env python3
"""DXF → PNG 検証レンダラ

生成した図面を実際に画像化して目視検証するための基盤。
ドクター機能・開発時の視覚確認の双方から使う。

モード:
  sheet : 用紙範囲だけを切り出す（印刷したときの見え方）
  full  : 全エンティティを表示し、用紙範囲を赤枠で重ねる（はみ出しの検出用）
"""
from __future__ import annotations

import os
import sys
from typing import Optional, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import Rectangle  # noqa: E402

import ezdxf  # noqa: E402
from ezdxf import bbox  # noqa: E402
from ezdxf.addons.drawing import Frontend, RenderContext  # noqa: E402
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend  # noqa: E402
from ezdxf.addons.drawing.config import Configuration  # noqa: E402
from ezdxf.addons.drawing.properties import LayoutProperties  # noqa: E402

import ipguard_bridge  # noqa: E402  ご利用確認と出所の印 (書き出しの直前で必ず通す)

# 日本語が豆腐にならないようフォントを明示（macOS/Linux 双方を想定）
_JP_CANDIDATES = [
    "Hiragino Kaku Gothic ProN",
    "Hiragino Sans",
    "Noto Sans CJK JP",
    "IPAGothic",
    "Yu Gothic",
    "Meiryo",
    "Arial Unicode MS",
    "DejaVu Sans",
]


def _setup_font() -> str:
    import matplotlib.font_manager as fm

    available = {f.name for f in fm.fontManager.ttflist}
    for name in _JP_CANDIDATES:
        if name in available:
            matplotlib.rcParams["font.family"] = [name]
            matplotlib.rcParams["axes.unicode_minus"] = False
            return name
    return matplotlib.rcParams["font.family"][0]


def paper_extents(doc) -> Optional[Tuple[float, float, float, float]]:
    """用紙範囲 (xmin, ymin, xmax, ymax) を返す。

    保存時に書き込んだカスタム変数を最優先し、無ければ図枠レイヤから推定する。
    """
    try:
        cv = doc.header.custom_vars
        w = float(cv.get("SUISHIN_PAPER_W"))
        h = float(cv.get("SUISHIN_PAPER_H"))
        return (0.0, 0.0, w, h)
    except Exception:
        pass
    # 旧世代DXF: 図枠レイヤの外接矩形から推定（余白を戻す）
    msp = doc.modelspace()
    frame = [e for e in msp if e.dxf.layer == "5-FRAME"]
    if not frame:
        return None
    try:
        b = bbox.extents(frame)
    except Exception:
        return None
    # 図枠は左25mm/他10mmの余白で描かれている前提
    return (b.extmin.x - 25.0, b.extmin.y - 10.0, b.extmax.x + 10.0, b.extmax.y + 10.0)


def render_dxf(dxf_path: str, png_path: str, mode: str = "full",
               dpi: int = 160, max_px: int = 2400) -> dict:
    """DXFを画像化する。戻り値は用紙範囲とはみ出し量の実測値。"""
    # ご利用確認 (IP-057)。通らなければ LicenseDenied を投げ、画像は書かない。
    lic = ipguard_bridge.require_license(ipguard_bridge.STAGE_PREVIEW)
    _setup_font()
    doc = ezdxf.readfile(dxf_path)
    msp = doc.modelspace()
    # 出所の印 (PNG の tEXt チャンク)。DXF に刻んだ印を引き継ぐ (無ければ作る)。
    mark = ipguard_bridge.mark_for_output(
        doc, os.path.basename(dxf_path), str(lic.get("watermark") or "unknown"))
    png_meta = ipguard_bridge.image_metadata(mark)

    paper = paper_extents(doc)
    try:
        content = bbox.extents(msp)
        cx1, cy1 = content.extmin.x, content.extmin.y
        cx2, cy2 = content.extmax.x, content.extmax.y
    except Exception:
        cx1 = cy1 = cx2 = cy2 = 0.0

    if mode == "sheet" and paper:
        vx1, vy1, vx2, vy2 = paper
    else:
        # full: 用紙と内容の和集合（はみ出しが見えるように少し余白）
        if paper:
            vx1, vy1 = min(paper[0], cx1), min(paper[1], cy1)
            vx2, vy2 = max(paper[2], cx2), max(paper[3], cy2)
        else:
            vx1, vy1, vx2, vy2 = cx1, cy1, cx2, cy2
        mx = max((vx2 - vx1) * 0.02, 5.0)
        vx1, vy1, vx2, vy2 = vx1 - mx, vy1 - mx, vx2 + mx, vy2 + mx

    vw = max(vx2 - vx1, 1e-6)
    vh = max(vy2 - vy1, 1e-6)

    # 画素数の上限を守りつつ縦横比を保つ
    fig_w = min(vw / 25.4, max_px / dpi)
    fig_h = fig_w * (vh / vw)
    if fig_h * dpi > max_px:
        fig_h = max_px / dpi
        fig_w = fig_h * (vw / vh)

    fig = plt.figure(figsize=(fig_w, fig_h), dpi=dpi)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("white")
    fig.patch.set_facecolor("white")

    ctx = RenderContext(doc)
    backend = MatplotlibBackend(ax)
    # 白背景を宣言しないと ACI=7（白/黒）が白のまま描かれ、図枠・文字が消える
    lp = LayoutProperties.from_layout(msp)
    lp.set_colors(bg="#FFFFFF")
    Frontend(ctx, backend, config=Configuration()).draw_layout(
        msp, finalize=False, layout_properties=lp
    )

    # 用紙範囲を赤破線で重ねる（はみ出しが一目で分かる）
    if paper and mode != "sheet":
        ax.add_patch(Rectangle(
            (paper[0], paper[1]), paper[2] - paper[0], paper[3] - paper[1],
            fill=False, edgecolor="red", linestyle="--", linewidth=1.2, zorder=1e6,
        ))

    ax.set_xlim(vx1, vx2)
    ax.set_ylim(vy1, vy2)
    ax.set_aspect("equal")
    ax.axis("off")
    os.makedirs(os.path.dirname(os.path.abspath(png_path)) or ".", exist_ok=True)
    fig.savefig(png_path, dpi=dpi, facecolor="white", metadata=png_meta)
    plt.close(fig)

    overflow = None
    if paper:
        overflow = {
            "left": round(max(0.0, paper[0] - cx1), 2),
            "bottom": round(max(0.0, paper[1] - cy1), 2),
            "right": round(max(0.0, cx2 - paper[2]), 2),
            "top": round(max(0.0, cy2 - paper[3]), 2),
        }
    return {
        "png": png_path,
        "paper": paper,
        "content": [round(cx1, 2), round(cy1, 2), round(cx2, 2), round(cy2, 2)],
        "overflow_mm": overflow,
        "出所の印": {"出所コード": mark.get("code") or "", "状態": mark.get("status")},
    }


def render_dir(dxf_dir: str, png_dir: str, mode: str = "full") -> list:
    import glob

    results = []
    for f in sorted(glob.glob(os.path.join(dxf_dir, "*.dxf"))):
        name = os.path.splitext(os.path.basename(f))[0]
        out = os.path.join(png_dir, f"{name}.png")
        try:
            results.append(render_dxf(f, out, mode=mode))
        except Exception as ex:  # 1枚失敗しても残りは描く
            results.append({"png": out, "error": f"{type(ex).__name__}: {ex}"})
    return results


def main() -> None:
    import json

    if len(sys.argv) < 3:
        print("Usage: render.py <in.dxf|dir> <out.png|dir> [sheet|full]")
        sys.exit(1)
    src, dst = sys.argv[1], sys.argv[2]
    mode = sys.argv[3] if len(sys.argv) > 3 else "full"
    try:
        if os.path.isdir(src):
            res = render_dir(src, dst, mode)
        else:
            res = render_dxf(src, dst, mode)
    except ipguard_bridge.LicenseDenied as exc:
        # 承認実績の無い端末。画像は書いていない (終了コード 3)
        print(ipguard_bridge.denied_message(exc), file=sys.stderr)
        sys.exit(3)
    print(json.dumps(res, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
