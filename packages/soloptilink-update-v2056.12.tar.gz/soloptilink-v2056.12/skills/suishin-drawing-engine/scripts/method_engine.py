#!/usr/bin/env python3
"""工法別ルールエンジン
入力パラメータ（工法・口径・延長・曲線R）を method_specs から検証し、
適用可否・推奨管長・警告を返す
"""
from __future__ import annotations
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Any


SPECS_PATH = Path(__file__).parent.parent / "rules" / "method_specs_seed.json"


class MethodEngine:
    def __init__(self, specs_path: Path = SPECS_PATH):
        self.specs = json.load(open(specs_path, encoding="utf-8"))
        self.methods = self.specs["methods"]

    def list_methods(self) -> List[str]:
        return list(self.methods.keys())

    def get_spec(self, method: str) -> Dict[str, Any]:
        if method not in self.methods:
            raise ValueError(f"未対応工法: {method}. 利用可能: {self.list_methods()}")
        return self.methods[method]

    def validate(
        self,
        method: str,
        diameter_mm: int,
        length_m: float,
        curve_radius_m: Optional[float] = None,
        curved: bool = False,
    ) -> Dict[str, Any]:
        """
        パラメータの妥当性を検証。エラー・警告・推奨事項を返す
        """
        spec = self.get_spec(method)
        errors: List[str] = []
        warnings: List[str] = []
        suggestions: List[str] = []

        # 口径チェック
        dia = spec.get("applicable_diameter_mm", {})
        if diameter_mm < dia.get("min", 0):
            errors.append(
                f"呼び径φ{diameter_mm}は工法{method}の適用最小径φ{dia.get('min')}未満"
            )
        if diameter_mm > dia.get("max", 99999):
            errors.append(
                f"呼び径φ{diameter_mm}は工法{method}の適用最大径φ{dia.get('max')}超過"
            )
        if "typical" in dia and diameter_mm not in dia["typical"]:
            warnings.append(
                f"呼び径φ{diameter_mm}は工法{method}の標準ラインアップ{dia['typical']}に含まれません"
            )

        # 延長チェック
        max_span = spec.get("max_span_length_m", {})
        limit = max_span.get("curved" if curved else "straight", 500)
        if length_m > limit:
            errors.append(
                f"推進延長{length_m}mは工法{method}の{'曲線' if curved else '直線'}"
                f"最大推進延長{limit}mを超過"
            )
        elif length_m > limit * 0.9:
            warnings.append(
                f"推進延長{length_m}mは工法{method}の最大値{limit}mの90%超過。"
                f"中押ジャッキ・滑材追加検討推奨"
            )

        # 曲線半径チェック
        if curved and curve_radius_m is not None:
            min_r = spec.get("min_curve_radius_m", {})
            standard = min_r.get("standard", 999)
            if curve_radius_m < min_r.get("sharp", min_r.get("special", 0)):
                errors.append(
                    f"曲線半径R={curve_radius_m}mは工法{method}の許容最小R={min_r.get('sharp', min_r.get('special'))}m未満"
                )
            elif curve_radius_m < standard:
                warnings.append(
                    f"曲線半径R={curve_radius_m}mは工法{method}の標準R={standard}m未満。"
                    f"曲線用短管・特殊対応が必要"
                )

        # 推奨管長
        pipe_lengths = spec.get("standard_pipe_length_m", [2.43, 1.2, 1.0, 0.6])
        suggestions.append(f"推奨管長ラインアップ: {pipe_lengths}m")

        # 掘進機外径
        machine_od = spec.get("machine_od_mm", {})
        if str(diameter_mm) in machine_od:
            suggestions.append(f"標準掘進機外径: φ{machine_od[str(diameter_mm)]}mm")

        return {
            "method": method,
            "spec_summary": {
                "適用口径": f"{dia.get('min')}-{dia.get('max')}mm",
                "最大延長": max_span,
                "最小曲線R": spec.get("min_curve_radius_m", {}),
                "推奨管長": pipe_lengths,
            },
            "input": {
                "diameter_mm": diameter_mm,
                "length_m": length_m,
                "curve_radius_m": curve_radius_m,
                "curved": curved,
            },
            "errors": errors,
            "warnings": warnings,
            "suggestions": suggestions,
            "verdict": "OK" if not errors else "NG",
        }

    def recommend_pipe_layout(
        self, method: str, length_m: float, in_curve: bool = False,
    ) -> List[float]:
        """推進延長に対して工法標準のパイプ配列を返す"""
        spec = self.get_spec(method)
        pipes = spec.get("standard_pipe_length_m", [2.43, 1.2, 1.0, 0.6])
        pipes_desc = sorted(pipes, reverse=True)
        pipes_asc = sorted(pipes)
        candidates = pipes_asc if in_curve else pipes_desc

        layout: List[float] = []
        remaining = length_m
        while remaining > 1e-6:
            chosen = next((p for p in candidates if p <= remaining + 1e-6), min(pipes))
            actual = min(chosen, remaining)
            layout.append(round(actual, 3))
            remaining -= actual
        return layout


def main():
    if len(sys.argv) < 2:
        print("Usage: method_engine.py <method> [diameter_mm] [length_m] [curve_radius_m]")
        print("       method_engine.py list")
        sys.exit(1)

    engine = MethodEngine()

    if sys.argv[1] == "list":
        for m in engine.list_methods():
            spec = engine.get_spec(m)
            dia = spec.get("applicable_diameter_mm", {})
            print(f"  {m:20s} φ{dia.get('min')}-{dia.get('max')}mm  {spec.get('category', '')}")
        return

    method = sys.argv[1]
    diameter = int(sys.argv[2]) if len(sys.argv) > 2 else 350
    length = float(sys.argv[3]) if len(sys.argv) > 3 else 80.0
    r = float(sys.argv[4]) if len(sys.argv) > 4 else None
    result = engine.validate(method, diameter, length, r, curved=(r is not None))
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
