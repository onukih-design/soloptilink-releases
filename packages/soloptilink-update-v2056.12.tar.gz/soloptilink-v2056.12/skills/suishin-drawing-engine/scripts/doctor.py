#!/usr/bin/env python3
"""ドクター機能: 生成物の自己検証
- DXFファイルの整合性 (レイヤ・エンティティ・寸法)
- 管割の総延長 = 入力推進延長
- 推力計算の物理妥当性 (SF≥1.5)
- Excelファイルの必須シート・セル埋め
- 工法仕様との整合性
"""
from __future__ import annotations
import json
import sys
from pathlib import Path
from typing import List, Dict, Any

import ezdxf
from openpyxl import load_workbook

import drawing_qc


# 判定語。NOT_APPLICABLE は「検査対象が無かった」であって合格ではない。
VERDICT_JA = {
    "PASS": "合格",
    "WARN": "要確認",
    "FAIL": "不合格",
    "NOT_APPLICABLE": "未対応／該当なし",
}
VERDICT_ICON = {"PASS": "✓", "WARN": "⚠", "FAIL": "✗", "NOT_APPLICABLE": "—"}
# 終了コード: 0=合格/要確認, 1=不合格, 2=未対応 (合格に丸めない)
EXIT_OK, EXIT_FAIL, EXIT_NOT_APPLICABLE = 0, 1, 2


def exit_code_for(verdict: str) -> int:
    if verdict == "FAIL":
        return EXIT_FAIL
    if verdict == "NOT_APPLICABLE":
        return EXIT_NOT_APPLICABLE
    return EXIT_OK


class Doctor:
    def __init__(self):
        self.results: List[Dict[str, Any]] = []

    def _add(self, check: str, verdict: str, detail: str = "", severity: str = "info"):
        self.results.append({
            "check": check,
            "verdict": verdict,
            "severity": severity,
            "detail": detail,
        })

    # ============ DXF検証 ============
    def check_dxf(self, dxf_path: str, expected_layers: List[str] = None) -> None:
        p = Path(dxf_path)
        if not p.exists():
            self._add(f"DXF実在: {p.name}", "FAIL", f"ファイル未生成", "critical")
            return
        self._add(f"DXF実在: {p.name}", "PASS", f"{p.stat().st_size} bytes")

        try:
            doc = ezdxf.readfile(dxf_path)
        except Exception as e:
            self._add(f"DXF読取: {p.name}", "FAIL", str(e), "critical")
            return
        self._add(f"DXF読取: {p.name}", "PASS", f"DXF version={doc.dxfversion}")

        msp = doc.modelspace()
        entity_types = {}
        for e in msp:
            t = e.dxftype()
            entity_types[t] = entity_types.get(t, 0) + 1
        total = sum(entity_types.values())
        self._add(
            f"エンティティ数: {p.name}",
            "PASS" if total > 20 else "WARN",
            f"合計{total}件 - {entity_types}",
            "info" if total > 20 else "warning",
        )

        # レイヤ検証
        layers = [l.dxf.name for l in doc.layers]
        self._add(f"レイヤ数: {p.name}", "PASS", f"{len(layers)}層 - {layers[:8]}...")

        if expected_layers:
            missing = [l for l in expected_layers if l not in layers]
            if missing:
                self._add(f"必須レイヤ: {p.name}", "WARN",
                          f"未定義: {missing}", "warning")
            else:
                self._add(f"必須レイヤ: {p.name}", "PASS", "全て存在")

        # 図枠（FRAMEレイヤ）にエンティティがあるか
        frame_count = sum(1 for e in msp if e.dxf.layer == "5-FRAME")
        self._add(f"図枠エンティティ: {p.name}",
                  "PASS" if frame_count >= 4 else "WARN",
                  f"{frame_count}件（外枠+タイトルブロック必要）",
                  "info" if frame_count >= 4 else "warning")

        # テキスト（3-TEXT）にエンティティがあるか
        text_count = sum(1 for e in msp if e.dxf.layer == "3-TEXT")
        self._add(f"文字要素: {p.name}",
                  "PASS" if text_count >= 5 else "WARN",
                  f"{text_count}件（案件情報・寸法値等）")

        # レイアウト品質（文字被り・図枠はみ出し・巨大文字の実測）
        self.check_layout(dxf_path)

    # ============ レイアウト品質検証 ============
    # v1 はエンティティ数とレイヤ名しか見ておらず、寸法文字が縮尺倍に巨大化して
    # 図面を覆い、図形が図枠を4000mm 突き破った状態を PASS と判定していた。
    # 生成物を実測してこの種の崩壊を必ず捕まえる。
    _LAYOUT_SEVERITY = {
        "layout_overflow": "critical",
        "text_too_large": "critical",
        "text_overlap": "critical",
        "dimstyle_scale": "critical",
        "text_too_small": "warning",
        # 根拠の無い規格準拠の名乗り／開示欠落は提出を止める（重大）
        "standards_disclosure": "critical",
        "sheet_usage": "warning",
    }
    _LAYOUT_LABEL = {
        "layout_overflow": "図枠内収まり",
        "text_too_large": "巨大文字なし",
        "text_overlap": "文字の重なりなし",
        "dimstyle_scale": "寸法スタイル整合",
        "text_too_small": "最小文字高",
        "sheet_usage": "紙面占有率",
        "standards_disclosure": "様式出典の開示",
    }

    def check_layout(self, dxf_path: str) -> None:
        p = Path(dxf_path)
        try:
            res = drawing_qc.analyze(dxf_path)
        except Exception as e:
            self._add(f"レイアウト検証: {p.name}", "WARN",
                      f"検証を実行できませんでした: {e}", "warning")
            return
        for key, c in res.get("checks", {}).items():
            label = self._LAYOUT_LABEL.get(key, key)
            sev = self._LAYOUT_SEVERITY.get(key, "warning")
            self._add(f"{label}: {p.name}", c["verdict"], c.get("detail", ""),
                      sev if c["verdict"] != "PASS" else "info")

    # ============ 管割図の物理検証 ============
    def check_kanwari_meta(self, meta_path: str, tolerance_m: float = 0.01) -> None:
        p = Path(meta_path)
        if not p.exists():
            return
        meta = json.load(open(p, encoding="utf-8"))
        for span in meta.get("spans", []):
            diff = abs(span["length_m"] - span["total_pipe_length_m"])
            self._add(
                f"管割整合性: {span['name']}",
                "PASS" if diff <= tolerance_m else "FAIL",
                f"設計L={span['length_m']}m vs 管割合計={span['total_pipe_length_m']}m (差={diff:.3f}m)",
                "critical" if diff > tolerance_m else "info",
            )
            if span["segment_count"] < 5:
                self._add(f"管数量: {span['name']}", "WARN",
                          f"{span['segment_count']}本のみ - 短スパン確認",
                          "warning")

    # ============ 推力計算検証 ============
    def check_thrust(self, thrust_json: dict, sf_required: float = 1.5) -> None:
        r = thrust_json.get("result", {})
        sf = r.get("safety_factor", 0)
        self._add(
            "推力安全率",
            "PASS" if sf >= sf_required else "FAIL",
            f"SF={sf} (要求≥{sf_required})",
            "critical" if sf < sf_required else "info",
        )
        # 物理妥当性: f_per_m > 0, thrust > f0
        if r.get("total_thrust_kn", 0) < r.get("f0_kn", 0):
            self._add("推力物理妥当性", "FAIL",
                      "総推力 < 掘進機先端抵抗 (計算式異常)", "critical")
        else:
            self._add("推力物理妥当性", "PASS",
                      f"総推力{r.get('total_thrust_kn')}kN > f0={r.get('f0_kn')}kN")

    # ============ 施工計画書Excel検証 ============
    def check_construction_plan(self, xlsx_path: str,
                                 required_sheets: List[str] = None) -> None:
        p = Path(xlsx_path)
        if not p.exists():
            self._add(f"施工計画書実在: {p.name}", "FAIL", "ファイル未生成", "critical")
            return
        self._add(f"施工計画書実在: {p.name}", "PASS", f"{p.stat().st_size} bytes")

        try:
            wb = load_workbook(xlsx_path)
        except Exception as e:
            self._add(f"Excel読取: {p.name}", "FAIL", str(e), "critical")
            return

        sheets = wb.sheetnames
        self._add(f"シート数: {p.name}", "PASS", f"{len(sheets)}シート - {sheets}")

        if required_sheets is None:
            required_sheets = ["表紙", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
        missing = [s for s in required_sheets if s not in sheets]
        if missing:
            self._add(f"必須シート: {p.name}", "FAIL",
                      f"欠落: {missing}", "critical")
        else:
            self._add(f"必須シート: {p.name}", "PASS", "10章＋表紙 完備")

        # 表紙の主要項目が埋まっているか
        cover = wb["表紙"]
        essentials = {"C6": "発注者", "C10": "工法", "C11": "推進延長"}
        for cell, label in essentials.items():
            v = cover[cell].value
            if v and str(v).strip():
                self._add(f"表紙記入: {label}", "PASS", f"{v}")
            else:
                self._add(f"表紙記入: {label}", "WARN",
                          "未記入 - パラメータ確認", "warning")

    # ============ 検査対象が無いことの記録 ============
    def add_not_applicable(self, check: str, detail: str = "") -> None:
        """『検査していない』ことを 1 件として明示的に残す。
        合否 (PASS/WARN/FAIL) には数えないので、これだけの状態は
        総合判定が NOT_APPLICABLE になる。"""
        self._add(check, "NOT_APPLICABLE", detail, "info")

    # ============ 総合判定 ============
    def summary(self) -> dict:
        passed = sum(1 for r in self.results if r["verdict"] == "PASS")
        warned = sum(1 for r in self.results if r["verdict"] == "WARN")
        failed = sum(1 for r in self.results if r["verdict"] == "FAIL")
        skipped = sum(1 for r in self.results if r["verdict"] == "NOT_APPLICABLE")
        critical_fail = any(r["verdict"] == "FAIL" and r["severity"] == "critical" for r in self.results)
        # 合否を付けた検査の件数。NOT_APPLICABLE は「検査していない」ので数えない。
        graded = passed + warned + failed
        # v1 は検査 0 件のとき PASS を返していた (0件生成でも総合合格に見えた)。
        # 何も検査していないことは合格ではないので、必ず未対応として返す。
        if graded == 0:
            verdict = "NOT_APPLICABLE"
        elif critical_fail:
            verdict = "FAIL"
        elif warned or failed:
            verdict = "WARN"
        else:
            verdict = "PASS"
        return {
            "verdict": verdict,
            "verdict_ja": VERDICT_JA[verdict],
            "counts": {"pass": passed, "warn": warned, "fail": failed,
                       "not_applicable": skipped},
            "graded_checks": graded,
            "total_checks": len(self.results),
            "results": self.results,
        }

    def print_report(self) -> None:
        sm = self.summary()
        print("=" * 70)
        print(f"  ドクター最終判定: {sm['verdict']} ({sm['verdict_ja']})  ({sm['counts']})")
        if sm["verdict"] == "NOT_APPLICABLE":
            print("  合否を付けた検査は 0 件です。合格ではありません "
                  "(生成物が無い/対応外の図面種別を指定した等)。")
        print("=" * 70)
        for r in self.results:
            icon = VERDICT_ICON.get(r["verdict"], "?")
            print(f"  {icon} [{r['verdict']}] {r['check']}")
            if r["detail"]:
                print(f"      {r['detail']}")
        print("=" * 70)


def main():
    """
    Usage:
      doctor.py <artifact-dir>
        artifact-dir 直下の *.dxf, *.xlsx, *_meta.json を全部検証する
    """
    if len(sys.argv) < 2:
        print("Usage: doctor.py <artifact-dir>")
        sys.exit(1)
    target = Path(sys.argv[1])
    if not target.is_dir():
        print(f"ディレクトリではありません: {target}")
        sys.exit(1)

    doc = Doctor()
    for dxf in target.glob("*.dxf"):
        doc.check_dxf(str(dxf), expected_layers=[
            "0-OUTLINE", "1-CENTER", "2-DIM", "3-TEXT", "5-FRAME", "11-PIPE",
        ])
    for meta in target.glob("*_meta.json"):
        doc.check_kanwari_meta(str(meta))
    for xlsx in target.glob("*.xlsx"):
        if "thrust" not in xlsx.name.lower():
            doc.check_construction_plan(str(xlsx))

    if not doc.results:
        # 検査できる生成物が 1 件も無い状態を、黙って合格にしない
        doc.add_not_applicable(
            "検査対象",
            f"{target} に DXF/Excel/管割メタが 1 件もありません (検査していません)")

    doc.print_report()
    sm = doc.summary()
    out_json = target / "doctor_report.json"
    out_json.write_text(json.dumps(sm, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nレポート保存: {out_json}")
    sys.exit(exit_code_for(sm["verdict"]))


if __name__ == "__main__":
    main()
