#!/usr/bin/env python3
"""路線系3図面

- 位置図       (draw_location)
- 管路系統図   (draw_system_diagram)
- 平面縦断図   (draw_plan_profile)

図形はすべて実寸mmで描き、用紙への配置と縮尺選定は layout.View に任せる
（docs/DRAWING_API.md の3原則）。
"""
from __future__ import annotations

import json
import sys
from typing import List, Optional

from dxf_base import OgumiDXF, TH_BODY, TH_HEAD, TH_SMALL, TH_TINY
from layout import View, split_rows

M = 1000.0   # 1m = 1000mm


# ================================================================
# 1. 位置図
# ================================================================
def draw_location(data: dict, out_path: str) -> dict:
    """位置図: 現場位置をランドマーク・主要道路との相対で示す"""
    d = OgumiDXF(
        paper=data.get("paper", "A3"),
        scale=data.get("scale", 2500),
        title="位置図",
        drawing_no=data.get("drawing_no", ""),
        project=data["project_name"],
        client=data.get("client", ""),
        designer=data.get("designer", ""),
        extra_meta={"所在地": data.get("site_address", "")} if data.get("site_address") else None,
    )

    landmarks = data.get("landmarks", [
        {"name": "○○駅", "dx": -600, "dy": 400},
        {"name": "△△小学校", "dx": 500, "dy": -300},
    ])
    # ランドマークの相対座標は m 単位。実寸mmへ変換する
    lms = [(lm["name"], lm["dx"] * M, lm["dy"] * M) for lm in landmarks]
    # 図の広がりはランドマークに合わせる（固定値だと現場が点になって位置図の用を成さない）
    reach = max([300.0 * M] + [max(abs(x), abs(y)) * 1.35 for _, x, y in lms])

    v = View(d.content_panel(), preferred_scale=None, title="【位 置 図】")

    # 主要道路（東西・南北）
    v.line((-reach, 0), (reach, 0), "0-OUTLINE")
    v.line((0, -reach), (0, reach), "0-OUTLINE")
    v.label(data.get("major_road_east", "国道"), (reach * 0.82, 0),
            TH_SMALL, align="c_b", dy=1.5, priority=4)
    v.label(data.get("major_road_north", "県道"), (0, reach * 0.82),
            TH_SMALL, align="l_m", dx=1.5, priority=4)

    # 現場位置マーカー（二重丸＋十字）
    mark_r = reach * 0.055
    v.circle((0, 0), mark_r, "12-CURVE")
    v.circle((0, 0), mark_r * 0.4, "12-CURVE")
    v.line((-mark_r * 1.6, 0), (mark_r * 1.6, 0), "12-CURVE")
    v.line((0, -mark_r * 1.6), (0, mark_r * 1.6), "12-CURVE")
    v.label("★ 工事現場", (mark_r * 1.2, mark_r * 1.2),
            TH_BODY, layer="12-CURVE", align="l_b", priority=1)
    if data.get("site_address"):
        v.label(data["site_address"], (mark_r * 1.2, mark_r * 1.2),
                TH_SMALL, align="l_t", dy=-1.0, priority=2)

    # ランドマーク
    for name, lx, ly in lms:
        v.circle((lx, ly), reach * 0.022, "3-TEXT")
        v.label(name, (lx, ly), TH_SMALL, align="l_m", dx=2.5, priority=6)

    info = d.place(v)

    # 方位記号と縮尺バー（紙面mm）
    panel = d.content_panel()
    d.north_arrow(panel.x + panel.w - 14, panel.y + panel.h - 16, r=8)
    _scale_bar(d, panel.x + 4, panel.y + 6, info.get("scale") or d.scale)

    res = d.finish(out_path)
    res["type"] = "location"
    return res


def _scale_bar(d: OgumiDXF, x: float, y: float, scale: float,
               candidates=(10, 20, 50, 100, 200, 500, 1000)) -> None:
    """採用縮尺に応じた縮尺バー（紙面mmで描く）"""
    bar_m = candidates[0]
    for c in candidates:
        if 20.0 <= c * M / scale <= 70.0:
            bar_m = c
            break
    else:
        bar_m = candidates[-1]
    ln = bar_m * M / scale
    d.line((x, y), (x + ln, y), "3-TEXT")
    for t in (0.0, 0.5, 1.0):
        d.line((x + ln * t, y - 1.5), (x + ln * t, y + 1.5), "3-TEXT")
    d.text_aligned("0", (x, y - 2.0), TH_TINY, "3-TEXT", "c_t")
    d.text_aligned(f"{bar_m}m", (x + ln, y - 2.0), TH_TINY, "3-TEXT", "c_t")
    d.text_aligned(f"S=1/{int(scale)}", (x, y + 2.5), TH_SMALL, "3-TEXT", "l_b")


# ================================================================
# 2. 管路系統図
# ================================================================
def draw_system_diagram(data: dict, out_path: str) -> dict:
    """管路系統図: 人孔ノードと区間の接続・流下方向を示す模式図"""
    nodes = data.get("nodes", [
        {"id": "MH-1", "type": "起点", "x": 50, "y": 200, "invert": -3.5},
        {"id": "MH-2", "type": "中間人孔", "x": 150, "y": 200, "invert": -4.2},
        {"id": "MH-3", "type": "終点", "x": 250, "y": 200, "invert": -4.8},
    ])
    edges = data.get("edges", [])
    node_map = {n["id"]: n for n in nodes}
    total_L = sum(e.get("length_m", 0) for e in edges)

    d = OgumiDXF(
        paper=data.get("paper", "A2"),
        scale=data.get("scale", 1),
        title="管路系統図",
        drawing_no=data.get("drawing_no", ""),
        project=data["project_name"],
        client=data.get("client", ""),
        designer=data.get("designer", ""),
        extra_meta={"総延長": f"{total_L}m", "人孔数": len(nodes), "区間数": len(edges)},
    )

    v = View(d.content_panel(), preferred_scale=None, title="【管路系統図】")

    xs = [n["x"] for n in nodes] or [0]
    span = max(max(xs) - min(xs), 1)
    node_r = span * M * 0.022     # ノード半径は図の広がりに比例させる

    # 区間（管路）
    for e in edges:
        n1, n2 = node_map.get(e["from"]), node_map.get(e["to"])
        if not n1 or not n2:
            continue
        x1, y1 = n1["x"] * M, n1["y"] * M
        x2, y2 = n2["x"] * M, n2["y"] * M
        v.line((x1, y1), (x2, y2), "11-PIPE")
        # 流下方向の矢羽（中央）
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        dx, dy = x2 - x1, y2 - y1
        ln = max((dx * dx + dy * dy) ** 0.5, 1e-9)
        ux, uy = dx / ln, dy / ln
        a = node_r * 0.9
        v.polyline([(mx + ux * a, my + uy * a),
                    (mx - ux * a * 0.4 - uy * a * 0.35, my - uy * a * 0.4 + ux * a * 0.35),
                    (mx - ux * a * 0.4 + uy * a * 0.35, my - uy * a * 0.4 - ux * a * 0.35)],
                   "11-PIPE", close=True)
        v.label(f"L={e.get('length_m', 0)}m  φ{e.get('diameter', '')}",
                (mx, my), TH_SMALL, align="c_b", dy=2.0, priority=5)
        if e.get("method"):
            v.label(f"({e['method']})", (mx, my), TH_TINY, align="c_t",
                    dy=-2.0, priority=7)

    # ノード（人孔）
    for n in nodes:
        nx, ny = n["x"] * M, n["y"] * M
        v.circle((nx, ny), node_r, "8-PROPOSED")
        v.circle((nx, ny), node_r * 0.62, "8-PROPOSED")
        v.label(n["id"], (nx, ny), TH_SMALL, align="c_m", movable=False, priority=0)
        v.label(n.get("type", ""), (nx, ny - node_r), TH_TINY, align="c_t",
                dy=-1.2, priority=4)
        if n.get("invert") is not None:
            v.label(f"IL={n['invert']}", (nx, ny + node_r), TH_TINY,
                    align="c_b", dy=1.2, priority=4)

    d.place(v)

    # 区間一覧表（紙面mm）
    panel = d.content_panel()
    rows: List[List[str]] = [["区間", "延長", "口径", "工法"]]
    for e in edges[:14]:
        rows.append([f"{e['from']}→{e['to']}", f"{e.get('length_m', 0)}m",
                     f"φ{e.get('diameter', '')}", e.get("method", "")])
    rows.append(["合計", f"{total_L}m", f"{len(edges)}区間", f"人孔{len(nodes)}"])
    d.table(panel.x + 2, panel.y + 4 + len(rows) * 5.0, rows,
            col_widths=[34, 20, 20, 34], row_h=5.0, height=TH_SMALL,
            title="【区間一覧】")

    res = d.finish(out_path)
    res["type"] = "system_diagram"
    res["nodes"] = len(nodes)
    res["edges"] = len(edges)
    res["total_length_m"] = total_L
    return res


# ================================================================
# 3. 平面縦断図
# ================================================================
def draw_plan_profile(data: dict, out_path: str) -> dict:
    """平面縦断図: 上段=平面図、下段=縦断図

    縦断は水平と鉛直で縮尺が異なるのが実務標準（H=1/500, V=1/100 等）。
    View は縦横同一縮尺なので、鉛直方向の実寸に (H/V) 倍を掛けて強調し、
    採用した H/V を図中に明記する。
    """
    length_m = float(data["length_m"])
    diameter = data.get("diameter_mm", 350)
    slope = float(data.get("slope_permil", 5))
    depth_start = float(data.get("depth_start_m", 5.0))
    h_scale = float(data.get("scale", 500))
    v_scale = float(data.get("vertical_scale", 100))
    vexag = max(1.0, h_scale / v_scale)      # 鉛直強調倍率

    d = OgumiDXF(
        paper=data.get("paper", "A1"),
        scale=h_scale,
        title="平面縦断図",
        drawing_no=data.get("drawing_no", ""),
        project=data["project_name"],
        client=data.get("client", ""),
        designer=data.get("designer", ""),
        extra_meta={"推進延長": f"{length_m}m", "口径": f"φ{diameter}",
                    "勾配": f"{slope}‰"},
    )

    main = d.content_panel()
    # 平面図は帯状で背が低いため、縦断図に高さを厚く配分する
    plan_panel, prof_panel = split_rows(main, [1, 2.4], gap=8,
                                        names=["平面", "縦断"])

    L = length_m * M
    start_name = data.get("start_shaft", "No.1")
    arrival_name = data.get("arrival_shaft", "No.2")

    # ---- 上段: 平面図 ----
    vp = View(plan_panel, preferred_scale=h_scale, title="【平 面 図】")
    half = max(diameter * 1.5, 600.0)
    # 道路幅員（推進管はこの中を通る）。帯だけの平面図にしないための表現
    road_half = float(data.get("road_width_m", 6.0)) * M / 2
    vp.line((0, road_half), (L, road_half), "7-EXISTING")
    vp.line((0, -road_half), (L, -road_half), "7-EXISTING")
    vp.label(f"道路幅員 {data.get('road_width_m', 6.0)}m", (L * 0.5, road_half),
             TH_TINY, align="c_b", dy=1.2, priority=7)
    vp.line((0, 0), (L, 0), "1-CENTER")
    vp.line((0, half), (L, half), "11-PIPE")
    vp.line((0, -half), (L, -half), "11-PIPE")

    shaft_w = max(L * 0.012, half * 2.2, road_half * 0.9)
    for sx, name, kind in ((0.0, start_name, "発進"), (L, arrival_name, "到達")):
        vp.rect(sx - shaft_w / 2, -shaft_w / 2, sx + shaft_w / 2, shaft_w / 2,
                "14-SHAFT")
        vp.label(f"{kind} {name}", (sx, shaft_w / 2), TH_SMALL,
                 align="c_b", dy=1.5, priority=2)

    # 測点（20m毎・本数が多い場合は間引く）
    step = 10 if length_m <= 120 else (20 if length_m <= 300 else 50)
    n = 0
    for i in range(0, int(length_m) + 1, step):
        sx = i * M
        vp.line((sx, -half * 1.6), (sx, half * 1.6), "3-TEXT")
        vp.label(f"No.{i // step}", (sx, -half * 1.6), TH_TINY,
                 align="c_t", dy=-1.2, priority=6)
        n += 1
    vp.dim((0, -half), (L, -half), orient="h", offset_mm=12,
           text=f"推進延長 L={length_m}m", outside=True)

    # ---- 下段: 縦断図 ----
    vs = View(prof_panel, preferred_scale=h_scale, title="【縦 断 図】")

    def vy(depth_m_: float) -> float:
        """深さ(m・下向き正) → View座標(実寸mm・鉛直強調済)"""
        return -depth_m_ * M * vexag

    # 地表線
    vs.line((0, vy(0)), (L, vy(0)), "15-GROUND")
    vs.label("GL", (0, vy(0)), TH_SMALL, align="r_m", dx=-2, priority=2)

    # 地質層
    layers = data.get("soil_layers", [
        {"depth_top_m": 0, "depth_bottom_m": 3, "name": "盛土", "n_value": 3},
        {"depth_top_m": 3, "depth_bottom_m": 8, "name": "粘性土", "n_value": 5},
        {"depth_top_m": 8, "depth_bottom_m": 15, "name": "砂質土", "n_value": 15},
    ])
    for lay in layers:
        yb = vy(float(lay["depth_bottom_m"]))
        yt = vy(float(lay["depth_top_m"]))
        vs.line((0, yb), (L, yb), "15-GROUND")
        vs.label(f"{lay['name']} (N={lay.get('n_value', '-')})",
                 (L, (yt + yb) / 2), TH_TINY, align="l_m", dx=2.5, priority=6)

    # 地下水位
    if data.get("ground_water_depth_m") is not None:
        wy = vy(float(data["ground_water_depth_m"]))
        vs.line((0, wy), (L, wy), "16-WATER")
        vs.label(f"▽GL-{data['ground_water_depth_m']}m", (0, wy),
                 TH_TINY, layer="16-WATER", align="r_m", dx=-2, priority=3)

    # 推進管（勾配付き・管厚を上下線で表現）
    depth_end = depth_start + slope / 1000.0 * length_m
    y0 = vy(depth_start)
    y1 = vy(depth_end)
    r = diameter / 2 * vexag
    vs.line((0, y0), (L, y1), "1-CENTER")
    vs.line((0, y0 + r), (L, y1 + r), "11-PIPE")
    vs.line((0, y0 - r), (L, y1 - r), "11-PIPE")
    vs.label(f"推進管 φ{diameter}  i={slope}‰", (L / 2, (y0 + y1) / 2 + r),
             TH_SMALL, layer="11-PIPE", align="c_b", dy=2.0, priority=3)

    # 立坑（縦断）
    for sx, yy, name, kind in ((0.0, y0, start_name, "発進"),
                               (L, y1, arrival_name, "到達")):
        w = max(L * 0.012, r * 2.4)
        vs.rect(sx - w / 2, yy - r * 1.8, sx + w / 2, vy(0), "14-SHAFT")
        vs.label(f"{kind} {name}", (sx, vy(0)), TH_SMALL,
                 align="c_b", dy=2.0, priority=2)

    # 土被り・延長の寸法
    vs.dim((0, y0), (0, vy(0)), orient="v", offset_mm=14,
           text=f"土被り {depth_start}m")
    vs.dim((0, y1 - r), (L, y1 - r), orient="h", offset_mm=12,
           text=f"L={length_m}m  勾配 {slope}‰", outside=True)

    # 平面図と縦断図は横方向の位置が対応するため、同一の水平縮尺に揃える。
    # 用紙に収まる範囲で最大化し、実際に採用した縮尺から H/V を逆算して明記する
    # （希望値をそのまま書くと、縮尺表記が実際の図と食い違う）。
    common_h = max(vp.resolve_scale(), vs.resolve_scale())
    vp.preferred_scale = vs.preferred_scale = common_h
    vp.lock_scale = vs.lock_scale = True
    d.place(vp)
    d.place(vs)

    # 縮尺の明記（縦断は H/V が異なるため必須）
    eff_v = common_h / vexag
    v_txt = f"{int(round(eff_v))}" if eff_v >= 1 else f"{eff_v:.2f}"
    d.text_aligned(f"縦断縮尺  H=1/{int(round(common_h))}   V=1/{v_txt}",
                   (prof_panel.x + 2, prof_panel.y + 1.5), TH_SMALL, "3-TEXT", "l_b")

    res = d.finish(out_path)
    res["type"] = "plan_profile"
    res["length_m"] = length_m
    res["slope_permil"] = data.get("slope_permil", 5)
    return res


# ================================================================
# CLI
# ================================================================
GENERATORS = {
    "location": draw_location,
    "system_diagram": draw_system_diagram,
    "plan_profile": draw_plan_profile,
}


def main() -> None:
    if len(sys.argv) < 4:
        print("Usage: gen_route.py <type> <input.json> <output.dxf>")
        print("Types:", ", ".join(GENERATORS))
        sys.exit(1)
    typ = sys.argv[1]
    if typ not in GENERATORS:
        print(f"未対応の図面種別: {typ}")
        sys.exit(1)
    data = json.load(open(sys.argv[2], encoding="utf-8"))
    print(json.dumps(GENERATORS[typ](data, sys.argv[3]), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
