#!/usr/bin/env python3
"""図面レイアウト品質の実測（ドクターの検証軸）

v1 の重大欠陥（寸法文字が縮尺倍に巨大化して図面を覆う／図形が図枠を突き破る）を
「生成物を実測して必ず捕まえる」ための検査。従来のドクターはエンティティ数と
レイヤ名しか見ておらず、崩壊した図面を PASS と判定していた。

検査軸:
  layout_overflow  図枠（用紙）の外に出ているエンティティがないか
  text_overlap     文字同士が重なっていないか
  text_too_large   紙面に対して異常に大きい文字がないか（縮尺二重適用の直接検出）
  text_too_small   印刷で潰れる文字がないか
  dimstyle_scale   寸法スタイルの倍率が 1.0 か
  sheet_usage      図形が紙面に対して極端に小さくないか
"""
from __future__ import annotations

import sys
from typing import Dict, List, Optional, Tuple

import ezdxf
from ezdxf import bbox

from textfit import Rect, text_rect

# 判定しきい値
OVERFLOW_TOL_MM = 0.5      # 図枠外への許容量
MIN_TEXT_MM = 1.5          # これ未満は印刷で潰れる
MAX_TEXT_RATIO = 0.10      # 用紙短辺に対する文字高の上限（A1短辺594mm→59mm）
MIN_SHEET_USAGE = 0.04     # 図形が紙面のこの割合未満だと小さすぎ

_ALIGN_FROM_EZDXF = {
    "LEFT": "l_b", "CENTER": "c_b", "RIGHT": "r_b",
    "BOTTOM_LEFT": "l_b", "BOTTOM_CENTER": "c_b", "BOTTOM_RIGHT": "r_b",
    "MIDDLE_LEFT": "l_m", "MIDDLE_CENTER": "c_m", "MIDDLE_RIGHT": "r_m",
    "MIDDLE": "c_m",
    "TOP_LEFT": "l_t", "TOP_CENTER": "c_t", "TOP_RIGHT": "r_t",
    "ALIGNED": "l_b", "FIT": "l_b",
}


def paper_extents(doc) -> Optional[Tuple[float, float, float, float]]:
    """用紙範囲 (xmin, ymin, xmax, ymax)。保存時のカスタム変数を最優先。"""
    try:
        cv = doc.header.custom_vars
        w = float(cv.get("SUISHIN_PAPER_W"))
        h = float(cv.get("SUISHIN_PAPER_H"))
        return (0.0, 0.0, w, h)
    except Exception:
        pass
    msp = doc.modelspace()
    frame = [e for e in msp if e.dxf.layer == "5-FRAME"]
    if not frame:
        return None
    try:
        b = bbox.extents(frame)
    except Exception:
        return None
    # 旧世代DXF: 図枠は左25mm/他10mmの余白で描かれている前提で用紙を復元
    return (b.extmin.x - 25.0, b.extmin.y - 10.0, b.extmax.x + 10.0, b.extmax.y + 10.0)


def collect_text_rects(msp) -> List[Tuple[Rect, str, float]]:
    """モデル空間の文字要素の外接矩形（余白なし=実字形に近い）

    寸法(DIMENSION)の文字は実体がブロックの中にあるため、展開して中身も見る。
    ここを見ないと「寸法文字だけが縮尺倍に巨大化している」状態を取り逃す。
    """
    out: List[Tuple[Rect, str, float]] = []
    for e in _iter_with_virtual(msp):
        t = e.dxftype()
        if t == "TEXT":
            s = e.dxf.text or ""
            if not s.strip():
                continue
            h = float(e.dxf.height or 0)
            rot = float(getattr(e.dxf, "rotation", 0.0) or 0.0)
            try:
                align_enum, p1, p2 = e.get_placement()
                align = _ALIGN_FROM_EZDXF.get(align_enum.name, "l_b")
                pt = p1
            except Exception:
                align = "l_b"
                pt = e.dxf.insert
            out.append((text_rect(s, pt[0], pt[1], h, align,
                                  pad_ratio=0.0, rotation=rot), s, h))
        elif t == "MTEXT":
            s = (e.text or "").replace("\\P", "\n")
            if not s.strip():
                continue
            h = float(e.dxf.char_height or 0)
            pt = e.dxf.insert
            out.append((text_rect(s, pt[0], pt[1], h, "l_t",
                                  pad_ratio=0.0), s, h))
    return out


def _iter_with_virtual(msp):
    """モデル空間のエンティティを、DIMENSION/INSERT は中身も展開して列挙する"""
    for e in msp:
        t = e.dxftype()
        if t in ("DIMENSION", "INSERT", "LEADER", "MULTILEADER"):
            yield e
            try:
                for ve in e.virtual_entities():
                    yield ve
            except Exception:
                pass
        else:
            yield e


def analyze(dxf_path: str) -> Dict:
    """1枚のDXFのレイアウト品質を実測する"""
    doc = ezdxf.readfile(dxf_path)
    msp = doc.modelspace()
    res: Dict = {"file": dxf_path, "checks": {}}

    paper = paper_extents(doc)
    res["paper"] = paper

    # --- layout_overflow ---
    try:
        content = bbox.extents(msp)
        cx1, cy1 = content.extmin.x, content.extmin.y
        cx2, cy2 = content.extmax.x, content.extmax.y
        res["content"] = [round(cx1, 2), round(cy1, 2), round(cx2, 2), round(cy2, 2)]
    except Exception:
        cx1 = cy1 = cx2 = cy2 = 0.0
        res["content"] = None

    if paper:
        ov = {
            "left": round(max(0.0, paper[0] - cx1), 2),
            "bottom": round(max(0.0, paper[1] - cy1), 2),
            "right": round(max(0.0, cx2 - paper[2]), 2),
            "top": round(max(0.0, cy2 - paper[3]), 2),
        }
        worst = max(ov.values())
        res["checks"]["layout_overflow"] = {
            "verdict": "PASS" if worst <= OVERFLOW_TOL_MM else "FAIL",
            "overflow_mm": ov,
            "detail": ("図枠内に収まっている" if worst <= OVERFLOW_TOL_MM
                       else f"図枠外へ最大{worst}mm はみ出している {ov}"),
        }
    else:
        res["checks"]["layout_overflow"] = {
            "verdict": "WARN", "detail": "用紙範囲を特定できない（図枠なし）"}

    # --- 文字関連 ---
    rects = collect_text_rects(msp)
    res["text_count"] = len(rects)

    short_side = min(paper[2] - paper[0], paper[3] - paper[1]) if paper else 297.0
    max_allowed = short_side * MAX_TEXT_RATIO

    too_large = [(s, h) for _, s, h in rects if h > max_allowed]
    res["checks"]["text_too_large"] = {
        "verdict": "PASS" if not too_large else "FAIL",
        "detail": ("異常な巨大文字なし" if not too_large else
                   f"用紙短辺の{int(MAX_TEXT_RATIO*100)}%({max_allowed:.0f}mm)を超える文字 {len(too_large)}件: "
                   + ", ".join(f"'{s[:14]}'={h:.0f}mm" for s, h in too_large[:3])),
        "count": len(too_large),
    }

    too_small = [(s, h) for _, s, h in rects if 0 < h < MIN_TEXT_MM]
    res["checks"]["text_too_small"] = {
        "verdict": "PASS" if not too_small else "WARN",
        "detail": ("最小文字高を満たす" if not too_small else
                   f"{MIN_TEXT_MM}mm未満の文字 {len(too_small)}件（印刷で潰れる恐れ）"),
        "count": len(too_small),
    }

    # --- text_overlap ---
    pairs = _overlap_pairs([r for r, _, _ in rects])
    samples = [f"'{rects[i][1][:12]}'×'{rects[j][1][:12]}'" for i, j in pairs[:3]]
    res["checks"]["text_overlap"] = {
        "verdict": "PASS" if not pairs else "FAIL",
        "detail": ("文字の重なりなし" if not pairs else
                   f"文字が重なっている箇所 {len(pairs)}組: " + ", ".join(samples)),
        "count": len(pairs),
    }

    # --- dimstyle_scale ---
    bad_styles = []
    for ds in doc.dimstyles:
        name = ds.dxf.name
        if name.startswith("EZ") or name == "Standard":
            continue
        sc = float(getattr(ds.dxf, "dimscale", 1.0) or 1.0)
        if abs(sc - 1.0) > 1e-6:
            bad_styles.append((name, sc))
    res["checks"]["dimstyle_scale"] = {
        "verdict": "PASS" if not bad_styles else "FAIL",
        "detail": ("寸法スタイルの倍率は 1.0" if not bad_styles else
                   "寸法倍率が1.0でない（文字・矢印が縮尺倍に巨大化する）: "
                   + ", ".join(f"{n}={s}" for n, s in bad_styles)),
    }

    # --- sheet_usage ---
    if paper and res["content"]:
        pw, ph = paper[2] - paper[0], paper[3] - paper[1]
        used = max(0.0, min(cx2, paper[2]) - max(cx1, paper[0])) * \
            max(0.0, min(cy2, paper[3]) - max(cy1, paper[1]))
        ratio = used / (pw * ph) if pw * ph else 0.0
        res["checks"]["sheet_usage"] = {
            "verdict": "PASS" if ratio >= MIN_SHEET_USAGE else "WARN",
            "detail": f"図形の紙面占有率 {ratio*100:.1f}%",
            "ratio": round(ratio, 4),
        }

    # --- standards_disclosure ---
    # 様式の出典が未確認である旨が図面に載っているか。
    # 併せて「開示を伴わない JIS 準拠の名乗り」が図面に残っていないかも見る。
    res["checks"]["standards_disclosure"] = check_standards_disclosure(doc, rects)

    verdicts = [c["verdict"] for c in res["checks"].values()]
    res["verdict"] = ("FAIL" if "FAIL" in verdicts
                      else ("WARN" if "WARN" in verdicts else "PASS"))
    return res


# 準拠の名乗りとみなす語（この語が図面にあるなら、根拠か開示のどちらかが要る）
_CONFORMANCE_WORDS = ("準拠", "適合", "に従う")
_STANDARD_WORDS = ("JIS", "ＪＩＳ")
# 開示注記の目印（standards_disclosure.disclosure_ja の本文に必ず含まれる語）
_DISCLOSURE_MARKS = ("規格票", "保証するものではありません")


def check_standards_disclosure(doc, rects) -> Dict:
    """様式の出典開示を実測する。

    PASS 条件はどちらか:
      (a) 未確認の開示注記が図面に描かれている
      (b) 未確認が 0 件で、かつ準拠の名乗りが1つも無い
    FAIL 条件:
      ・開示注記が無い（お客様が根拠を確かめられないまま図面が出る）
      ・開示を伴わない JIS 準拠の名乗りが図面文字にある
    """
    texts = [s for _, s, _ in rects]
    disclosed = any(all(m in s for m in _DISCLOSURE_MARKS) for s in texts)

    # 開示注記そのものは「JIS 準拠を保証するものではありません」と書くので名乗りに数えない
    bare_claims = []
    for s in texts:
        if all(m in s for m in _DISCLOSURE_MARKS):
            continue
        if any(w in s for w in _STANDARD_WORDS) and any(w in s for w in _CONFORMANCE_WORDS):
            bare_claims.append(s)

    try:
        declared = doc.header.custom_vars.get("SUISHIN_STD_DISCLOSED")
    except Exception:
        declared = None

    if bare_claims:
        return {
            "verdict": "FAIL",
            "detail": ("根拠の開示を伴わない規格準拠の表記が図面にあります "
                       f"{len(bare_claims)}件: "
                       + ", ".join(f"'{s[:24]}'" for s in bare_claims[:3])),
            "disclosed": disclosed,
            "bare_claims": len(bare_claims),
        }
    if not disclosed:
        return {
            "verdict": "FAIL",
            "detail": ("様式（用紙・尺度・文字高・図枠）の出典が未確認である旨の"
                       "注記が図面にありません（この図面は古い版で生成された可能性があります）"),
            "disclosed": False,
            "bare_claims": 0,
            "header_flag": declared,
        }
    return {
        "verdict": "PASS",
        "detail": "様式の出典が未確認である旨を図面上で開示している",
        "disclosed": True,
        "bare_claims": 0,
        "header_flag": declared,
    }


def _overlap_pairs(rects: List[Rect], min_area: float = 0.6) -> List[Tuple[int, int]]:
    """実質的に重なっている矩形ペア（面積 min_area mm² 超）を列挙"""
    pairs: List[Tuple[int, int]] = []
    n = len(rects)
    # 単純比較でも図面1枚の文字数（数百）なら十分速い
    for i in range(n):
        a = rects[i]
        for j in range(i + 1, n):
            b = rects[j]
            ow = min(a.x2, b.x2) - max(a.x1, b.x1)
            oh = min(a.y2, b.y2) - max(a.y1, b.y1)
            if ow > 0 and oh > 0 and ow * oh > min_area:
                pairs.append((i, j))
    return pairs


def main() -> None:
    import glob
    import json
    import os

    if len(sys.argv) < 2:
        print("Usage: drawing_qc.py <file.dxf|dir>")
        sys.exit(1)
    target = sys.argv[1]
    files = (sorted(glob.glob(os.path.join(target, "*.dxf")))
             if os.path.isdir(target) else [target])
    worst = "PASS"
    for f in files:
        r = analyze(f)
        print(f"\n=== {os.path.basename(f)} : {r['verdict']} ===")
        for k, c in r["checks"].items():
            icon = {"PASS": "✓", "WARN": "⚠", "FAIL": "✗"}[c["verdict"]]
            print(f"  {icon} {k}: {c['detail']}")
        if r["verdict"] == "FAIL":
            worst = "FAIL"
        elif r["verdict"] == "WARN" and worst == "PASS":
            worst = "WARN"
    print(f"\n総合: {worst}")
    sys.exit(1 if worst == "FAIL" else 0)


if __name__ == "__main__":
    main()
