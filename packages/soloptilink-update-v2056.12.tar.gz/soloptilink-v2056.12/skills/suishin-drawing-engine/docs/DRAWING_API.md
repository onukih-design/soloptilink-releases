# 図面生成 API 契約（v2）

v1 では図形を「紙面mmの固定座標」で直書きしていたため、延長・深さ・口径が変わると
図枠を突き破り、寸法文字が縮尺倍に巨大化して**文字被り**を起こしていた。
v2 は実CADのビューポートと同じ考え方に統一する。

## 3原則（例外なし）

1. **図形は実寸mmで描く。** 65m の管路なら `65000`。紙面mm換算（`1000/scale`）を生成器の中で行わない。
2. **注記文字・寸法は紙面mm。** 文字高は 1.8〜5.0mm の範囲。縮尺が変わっても文字の大きさは変わらない。
3. **紙面の絶対座標に図形を置かない。** 配置は `Panel` と `View` に任せる。
   表・凡例・方位記号だけは紙面mmで置いてよい（`d.table` / `d.legend` / `d.north_arrow`）。

## 骨格

```python
from dxf_base import OgumiDXF, TH_TINY, TH_SMALL, TH_BODY, TH_HEAD
from layout import View, split_cols, split_rows

d = OgumiDXF(paper="A1", scale=100,          # scale は「希望」。収まらなければ自動で粗くなる
             title="管割図（コマンドφ400）", drawing_no="MITO-K",
             project=..., client=..., designer="")

main = d.content_panel()                      # タイトルブロックを除いた配置可能領域
left, right = split_cols(main, [2, 1])        # 必要ならパネル分割

v = View(left, preferred_scale=100, title="【管 割 図】")
v.rect(0, 0, 65000, 400, "11-PIPE")           # ← 実寸mm
v.dim((0, 0), (65000, 0), "h", offset_mm=12, text="L=65.0m")
v.label("No.1 発進立坑", (0, 0), TH_SMALL, align="c_t", dy=-2)
d.place(v)                                    # 縮尺を自動決定して紙面へ配置

d.table(x, y, rows, col_widths, title="【管割集計】")   # 紙面mm
d.legend(x, y, [("11-PIPE", "直線部推進管"), ...])      # 紙面mm

meta = d.finish(out_path)                     # 注記の衝突解消 → 図枠 → 保存
```

`d.save(path)` も従来どおり使える（内部で `finish` を呼ぶ）。`finish` は1回だけ。

## View の API（すべて実寸mm）

| メソッド | 用途 |
|---|---|
| `v.line(p1, p2, layer)` | 線 |
| `v.polyline(pts, layer, close=False)` | 連続線 |
| `v.rect(x1, y1, x2, y2, layer)` | 矩形 |
| `v.circle(c, r, layer)` | 円 |
| `v.arc(c, r, a1_deg, a2_deg, layer)` | 円弧 |
| `v.hatch_rect(x1, y1, x2, y2, pattern, layer, pattern_scale)` | 矩形ハッチ |
| `v.hatch_poly(pts, pattern, layer, pattern_scale)` | 多角形ハッチ |
| `v.label(text, world_pt, height, layer, align, dx, dy, movable, priority)` | 注記 |
| `v.dim(p1, p2, orient="h"/"v", offset_mm, text, layer)` | 寸法 |

- `label` の `height` は**紙面mm**。`dx`/`dy` も**紙面mm**の微調整。
- `align` は `l_b, c_b, r_b, l_m, c_m, r_m, l_t, c_t, r_t`（水平_垂直）。
- `priority` は小さいほど動かない（0=固定）。重要な注記ほど小さく。
- `movable=False` にすると絶対に動かないが、被る危険があるので原則 True。
- `dim` の `text` を省略すると実寸から自動計算される。単位付きで見せたいときは明示する。

## 縮尺の決まり方

`View(panel, preferred_scale=S)` の `S` が収まるならそれを使う。収まらなければ
JIS 標準縮尺（1/1〜1/10000）から**収まる最大の縮尺**へ自動で粗くする。
`preferred_scale=None` にすると常に「紙面いっぱいに最大化」する。
採用された縮尺はタイトルブロックの「縮尺」欄に自動反映される（複数ビューなら「図中記載」）。

## パネル分割

```python
rows = split_rows(main, [3, 2], gap=6, names=["平面", "縦断"])   # 上→下
cols = split_cols(main, [2, 1], gap=6, names=["図", "表"])       # 左→右
```

## 文字高の目安（紙面mm）

| 定数 | 値 | 用途 |
|---|---|---|
| `TH_TINY` | 1.8 | 管番号・測点番号など多数並ぶ小さな添字 |
| `TH_SMALL` | 2.5 | 一般注記・寸法値・表のセル |
| `TH_BODY` | 3.5 | 図中見出し・凡例タイトル |
| `TH_HEAD` | 5.0 | 図面全体の大見出し |

**1.8mm 未満を使わないこと**（印刷で潰れる）。

## レイヤ（既存のハウスルールを踏襲）

`0-OUTLINE / 1-CENTER / 2-DIM / 3-TEXT / 4-HATCH / 5-FRAME / 6-LEGEND / 7-EXISTING /
8-PROPOSED / 9-DIM-TEXT / 10-GRID / 11-PIPE / 12-CURVE / 13-JOINT / 14-SHAFT /
15-GROUND / 16-WATER / 17-DIM-NET`

## 検証（必須）

生成したら必ず画像化して**実際に目を通す**こと。

```bash
python3 scripts/render.py <out.dxf> <out.png> full   # 用紙を赤破線で重ねて表示
```

戻り値の `overflow_mm` が全辺 0 であること。0 でなければ図枠外へ出ている。
仕上げに全図面をまとめて検証する:

```bash
python3 scripts/doctor.py <出力ディレクトリ>
```

`layout_overflow` / `text_overlap` / `text_too_small` / `dimscale` の各項目が
PASS であること。1つでも FAIL なら図面を提出しない。

## やってはいけないこと

- ❌ `1000/scale` で紙面mmへ自前換算する（縮尺自動化が壊れる）
- ❌ `d.msp.add_text` 等で直接エンティティを足す（衝突回避を通らない）
- ❌ 文字高に実寸を渡す（例: `height=span.length_m`）
- ❌ `View` を使わず紙面座標へ図形を直書きする
- ❌ 目視せずに「できました」と報告する
