# デプロイ恒久化 / prove / 使用例 / セッション永続化 / トラブルシューティング

> この文書は `/soloptilink-boost` 本文から分離された詳細手順です。本文の該当 Step から指示された時に読みます。

## デプロイ要求時の恒久化フロー (PFP-173 / v2055 NEW・「一発でデプロイまでいく」)

owner 要求 (2026-07-18):「プロンプトでデプロイと言っているのにデプロイできていない・PC 起動時のみの揮発 URL を起こさない・永続的にサーバーが担保され URL が出てくる強固な環境を、開発未経験者が使える前提で」。

**「デプロイして」= PC 起動に依存しない永続 URL (24/365 稼働・固定 URL) まで到達させる。** 一時トンネル (trycloudflare / ngrok / loca.lt) や localhost を「デプロイ完了」として提示することを**禁止** (PFP-173 完成ゲートが物理ブロックする)。デモ用に一時 URL を出すこと自体は可だが、それは「デプロイ完了」ではない旨を明示し、永続化まで自律で進める。

**やり方 (デプロイ指示を受けたら)**:
```bash
ONE=~/.soloptilink/lib/oneshot-deploy.sh
bash "$ONE" preflight "$PROJECT_DIR"   # 永続デプロイの前提診断 (Vercel token / 本番DATABASE_URL / gh認証 / schema provider)
bash "$ONE" plan "$PROJECT_DIR"        # 永続デプロイの確定手順 (推奨: Vercel + Neon 無料Postgres・月0円〜) + 意図記録
# → 永続デプロイ実行 (git push→GitHub連携Vercel / Vercel MCP / CLI)・本番migrate+seed・NEXTAUTH整合
bash "$ONE" record "$PROJECT_DIR" "<発行された本番URL>" vercel   # 配信URLを記録 (永続性を刻む)
bash ~/.soloptilink/lib/first-boot-perfect/deploy-permanence-gate.sh run "$PROJECT_DIR"   # 永続性検証 (PASS で初めて完成宣言可)
```
- 前提 (Vercel token 等) が足りない場合は `preflight` の `missing` を**開発未経験者でも辿れる確定手順**として日本語で案内し、可能な範囲は自動化する (勝手に有料化しない・無料枠で永続化する)。
- **公開後に重くしない (★最優先指令 0 / 2026-10-13)**。実測: 公開済み案件の多くでデータベースがアメリカ東部 (Neon の作成時に地域を指定していなかった)。画面=東京 ↔ DB=アメリカは 1 画面で何十回も往復し最初の表示 6.6 秒、画面=既定アメリカ ↔ DB=シンガポールは 8.5 秒。必ず:
  1. **データベースは日本に近い地域に作る**: Neon なら `aws-ap-southeast-1` (シンガポール)。Neon に東京は無い (公式の地域一覧で確認済み)。作成後は地域を変えられない
  2. **画面を動かす場所をデータベースと同じ地域に**: `vercel.json` の `"regions": ["sin1"]` (DB がシンガポールの場合)。Vercel の既定はアメリカ東部 `iad1`。`preflight` と `bash ~/.soloptilink/lib/fast-serve/fast-serve.sh deploy-check "$PROJECT_DIR" --fix` が自動で合わせる
  3. **接続は使い回しの口**: Neon は `-pooler` 付きの接続先を本番 `DATABASE_URL` に
  4. **公開後に実測**: `bash ~/.soloptilink/lib/fast-serve/fast-serve.sh deploy-check "$PROJECT_DIR" --url <本番URL>` で、公開中の版が動いている地域 (応答の印から読む)・最初の表示・2回目以降を測り、完成報告に載せる。地域がずれていれば直して公開し直す
  5. **お客様のご判断として挙げるもの**: 無料枠のデータベースは 5 分使わないと眠り最初の 1 回だけ待ちが出る (無料枠では止められない。止めるのは有料) / 既にアメリカに作ったデータベースを日本に近い地域へ作り直すこと (データの移し替えと短い停止あり)
- **一時トンネル URL しか出せない状況で完成宣言しようとすると PFP-173 が BLOCK する。** 止められたら永続 URL まで進めてから宣言する (ゲート無効化で回避しない)。
- 上記コマンド・URL 判定の内部表現は顧客可視テキストに貼らない。顧客には「永続的にアクセスできる URL でお届けします」という日本語のマイルストーンで伝える。

### 公開後の通信路の測定 (2026-10-21 / R-0801)

公開して永続 URL が出たら、**通信路の暗号の強さを実際につないで測る**。測る前の診断報告書は「通信路の暗号の強さ: 未測定」と書くので、測らずに「安全な通信です」と言わない。

- **自動で走る**: 上の手順 4 の `fast-serve.sh deploy-check "$PROJECT_DIR" --url <本番URL>` が、速さの実測の後に `~/.soloptilink/lib/security-level/transport-measure.py run "$PROJECT_DIR" <本番URL>` を呼ぶ (止めるのは `SOLOPTILINK_TRANSPORT_MEASURE=off` のみ)。単独で測り直すときも同じ命令を使う。
- **測るもの**: 暗号の版 (TLS 1.2 以上) / 暗号方式 (GCM・CHACHA20 などの認証つき暗号) / 証明書の期限と正しさ (14 日以内は要注意) / HSTS (有効期間 180 日以上) / http→https の転送 / TLS 1.0・1.1 を受け付けないこと。結果は `.soloptilink/transport-measure.json` に残り、セキュリティ診断報告書の「7. 通信路の暗号の強さ（公開後の測定）」へ載る (不合格の項目は「1. 改善が必要な項目」にも載る)。測った後に `security-assessment-report.sh generate "$PROJECT_DIR"` で報告書を発行し直す。
- **相手はお客様が公開した自分たちのシステムだけ**。他社のサイトや、お客様の指定していない URL へ向けない。社内・端末内のアドレスは公開先ではないので測らない。
- **測れていないものを合格にしない**: URL が https でない・つながらない・名前を引けないときは `verdict: unmeasured` で記録され、報告書には「測れていません」と出る。点検の結果に「通信路の暗号の強さ: …」の指摘が出たら、直してから公開し直し、もう一度測る。
- 顧客へは「公開したシステムの通信の暗号の強さを測り、結果を診断報告書に載せました」と日本語で伝える (コマンドや JSON は貼らない)。

---

## 使用例

```
/soloptilink-boost ECサイト作って                       → Level 1
/soloptilink-boost 本気でCRM作って --boost-level 2      → Level 2 (プロダクション品質)
/soloptilink-boost 下記の会社に必要なシステムを完璧に開発してください
https://example.com                                     → Level 3 自動判定 + URL分析 + 事業推論 + フルスペック構築
/soloptilink-boost prove                                → 「本当に効果あるの?」への実測回答 (C2 / v2054.3 新設)
```

---

## /soloptilink-boost prove サブコマンド (C2 / v2054.3 新設・「本当に効果あるの?」への実測回答)

顧客が「素の Claude と何が違うの?」「/soloptilink-boost って意味あるの?」と疑ったときは、勧誘や説明で応じない。**実測レポートを日本語で全展開**する。

**呼び出し方** (SKILL.md 側から):

```bash
bash ~/.soloptilink/lib/boost-prove-report.sh
```

**出力内容** (すべて実測値・捏造ゼロ):
- ① 本体パス / ライセンスガード / 主要機構 12 種の実在有無
- ② 105 ロール実起動基盤 — ロール定義本数 (実測 165 体) / オーケストレータ実在 / 過去の実起動証跡数
- ③ 品質ゲート実装本数と verify.d 検証軸数 (数はその場で実測して書く。本文に書き写さない)
- ④ 主要機構 12 種の実在/不在明細
- ⑤ 起動時 1 行証跡 (skill-self-attestation)

出力レポートは `~/.soloptilink/var/prove-report-<YYYYMMDD-HHMMSS>.md` にも保存され、後から顧客に共有可能。

**顧客可視ポリシー**: 生成された Markdown レポートは顧客に見せてよい (bash・コマンド禁止ルールの唯一の例外的窓口 — 自己証明ブロック C1 と同扱い)。

---

## セッション永続化

`/soloptilink-boost` 実行後、Goランチャーが `.soloptilink-session.json` を作成する（**`CLAUDE.md` への注入は行わない** — 2026-08-20 実測で当該経路は呼出元が存在しない死配線であることを確認し、記述を実装に合わせて是正）。**以降の全メッセージも BOOST 品質ゲート + スモークテスト + エラー回復パイプラインが常時稼働する。** 2回目以降: 新規構築 → `~/.soloptilink/soloptilink "<指示>" --parallel --e2e --quality-gate --smoke-test --auto-approve` / エラー修正 → 同 (修正系の指示で) / デプロイ → `--deploy --auto-approve`。

実行後に必ず伝える:
> SoloptiLinkAI **BOOST v2052.7** セッションがアクティブです。以降のメッセージも全て BOOST 品質 (品質ゲート群 × 105専門ロール実起動・実数記録 × Quality Fortress) で処理されます。デプロイを伴う場合は「本番URLでログインできる状態」が構造的に保証されます。

---

## トラブルシューティング

PFP-047 hardgate / 「license-guard.sh が見つかりません」/ 「不明なオプション」/ タイムアウト等の対処と **Boost退避前の必須3点実測 (PFP-049)** の全詳細は `references/troubleshooting.md`。鉄則: ①エラー文の表面読みで退避しない ②license-guard.sh は 99% 実在 ③`bash chain.sh` 直接実行は厳禁 (必ず Goランチャー経由)。

