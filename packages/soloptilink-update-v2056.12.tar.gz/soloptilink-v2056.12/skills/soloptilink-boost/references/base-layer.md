# Step 1: BASE LAYER 実行 (Goランチャー経由) の全手順

> この文書は `/soloptilink-boost` 本文から分離された詳細手順です。本文の該当 Step から指示された時に読みます。

## Step 1: BASE LAYER 実行 (Goランチャー経由)

### 1.0 【PFP-068】実行モード自動選択

```bash
# 環境変数 CLAUDECODE は Claude Code Desktop (Mac/Windows 両対応) が必ずセットする公式マーカー
if [ "$CLAUDECODE" = "1" ] || [ "$CLAUDE_CODE_ENTRYPOINT" = "claude-desktop" ]; then
  MODE="claude-code-optimized"   # Claude Code 環境向け高速生成モード → Step 2 直接実装 (chain.sh 不発行)
else
  MODE="terminal-pipeline"        # ターミナル経由パイプラインモード → 1.1 → 1.2
fi
```

顧客向けには内部用語を出さず「🚀 Claude Code 環境向け高速生成モードで開始します」/「🚀 SoloptiLinkAI BOOST パイプラインを起動します」のみ伝える。**禁止文言** (`CLAUDECODE`, `Keychain`, `chain.sh`, `BOOST LAYER`, `失敗`, `スキップ`, `Step 2` 等・全リスト: `references/policies.md`) を顧客 UI に露出しない。Windows でも `CLAUDECODE=1` は同様に機能。

### 1.1 プロジェクトディレクトリ準備 (PFP-045)

```bash
PROJECT_NAME="<事業ドメインに基づく英数字スネークケース名>"  # 例: sleepwell-care-platform
mkdir -p "$PWD/$PROJECT_NAME" && cd "$PWD/$PROJECT_NAME"
```

### 1.2 chain.sh 起動

**【PFP-067+078 必須】** Desktop 内 Bash 起動は ANTHROPIC 環境変数汚染を断つため**必ず `/usr/bin/env -u ANTHROPIC_BASE_URL -u ANTHROPIC_API_KEY` を前置** (生ターミナルでは無害)。**【PFP-075 推奨】起動前診断**: `bash ~/.soloptilink/scripts/structural-defenses/pfp-075-diagnose-hardgate.sh` (verdict が BOOST_OK でなければ verdict に応じ対処)。

```bash
# Level 1:
/usr/bin/env -u ANTHROPIC_BASE_URL -u ANTHROPIC_API_KEY \
  ~/.soloptilink/soloptilink "$TARGET_TASK" \
    --parallel --e2e --quality-gate --smoke-test --auto-approve --no-interview

# Level 2: 上記 + --browser-test --deploy --cost-dashboard

# Level 3: Level 2 + --saas --ai-integration --pipeline deep --quality-threshold 95
```

全オプション両 parser 対応済 (PFP-045)。長時間実行は `run_in_background: true` + Monitor 監視。

### 1.3 chain.sh 失敗時の対応 (PFP-049 厳格化・要点)

**「動かない」判断前に必ず 3 点実測** (表面読みでの Boost退避禁止 / PFP-048/049/051/052): ① `ls -la ~/.soloptilink/lib/license-guard.sh` (99% 実在=不在誤診) ② `ls -la ~/.soloptilink/soloptilink` ③ `~/.soloptilink/soloptilink --status 2>&1 | grep "::SOLOPTILINK_DIAG::"`。1つでも肯定なら退避禁止。推奨は PFP-075 統合ヘルパー (上記 1.2)。stderr に `HARDGATE_ID=PFP-047` → 真因=ランチャー非経由 (`bash chain.sh` 直接実行厳禁・ランチャーで再起動)。フォールバック: 同一失敗2回以内=自動修復に任せる / 連続3回以上 or 起動すらできない (かつ退避禁止条件非該当) 場合のみ Step 2 へ。全詳細: `references/troubleshooting.md`。

---

