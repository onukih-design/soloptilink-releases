# Step 3: 完成ゲート実行表 — 全ゲートの実行コマンドとPASS条件

> この文書は `/soloptilink-boost` 本文から分離された詳細手順です。本文の該当 Step から指示された時に読みます。

## Step 3: 完成ゲート実行表 (chain.sh 成功後も直接実装でも・完成宣言前に全該当ゲートを実走)

実行前の基礎 3 点 (モックデータ残存 grep / DB 接続テスト / .env 完備) を済ませてから、下表の該当ゲートを**上から順に実走**する。実行列の無印は `bash ~/.soloptilink/lib/first-boot-perfect/<実行> ` に `"$PROJECT_DIR"` を付けて実行 ($P と表記)。`SD/`=`~/.soloptilink/scripts/structural-defenses/`、`lib/`=`~/.soloptilink/lib/`。各ゲートの軸定義・自動修復・refiner 消化手順・禁止パターンの全詳細は **`references/gates.md`** (必ず該当節を参照してから実走)。

| ゲート (PFP+日本語名) | 実行コマンド | PASS 条件 | ブロック性 |
|---|---|---|---|
| PFP-061/071 初回ログインゼロ摩擦 | `SD/pfp-071-first-login-gate.sh --apply $P` | verdict=PASS (C1-C4) + seed pre-fill | Strict 既定=FAIL で停止 |
| PFP-079 ログイン redirect レース | `SD/pfp-079-login-redirect-race-gate.sh --apply $P` | L1-L3 passed・dashboard に1回で滞在 | Strict 既定 |
| PFP-074 フォーム重要パス三兄弟 | `rsc-event-handler-detector.sh run $P` / `form-critical-path-guarantor.sh run $P` / `one-shot-completeness-gate.sh run $P` | 3本とも exit 0 (REHD/FCPG 8軸/OSCG 13軸) | Strict 既定 |
| PFP-080 業界深掘り L0-L3 | `layered-depth-gate.sh run $P` | achieved ≥ L2 (既定) + 用語含有率 PASS | Strict 既定 |
| PFP-098 深さ L4-L6 | `deep-system-gate.sh run $P` | achieved ≥ L5 (既定) + refiner 全消化 | WARN 既定 (hook が本格規模をブロック) |
| PFP-100 CRUD 入力 | `crud-input-capability-gate.sh run $P` | verdict ≠ BLOCK/FAIL + needs_create_form 空 | **作成フォーム0=BLOCK (物理)** |
| PFP-106 セキュリティ強化 7軸 | `security-hardening-gate.sh apply $P` | verdict ≠ FAIL + S2/S3 実配線 (import 存在) | WARN 既定 |
| PFP-107 権限マトリクス 🆕 | `permission-matrix-gate.sh apply $P` | verdict ≠ FAIL + refiner (requireAdmin/ownedWhere 配線) 全消化 | WARN 既定 (STRICT で昇格) |
| PFP-108 帳票印刷/PDF | `document-output-gate.sh apply $P` | verdict ≠ FAIL (帳票対象なしは not_applicable) | **AUTO_STRICT (v2054)**: 帳票該当業種 (PFP-171 該当様式あり) は自動で Strict=FAIL 昇格・明示 env 最優先 |
| PFP-171 帳票様式忠実度 🆕 | `first-boot-perfect/form-fidelity-gate.sh run $P` | verdict ≠ FAIL (lib/japan 様式SoT=法定記載事項と帳票テンプレを突合。適格請求書の登録番号/税率別内訳、建設出来高/介護実績/源泉徴収票等の必須記載欠落=FAIL・非該当業種は not_applicable。実機PDF中身検証 F3 は WARN 型) | **必須記載の欠落=FAIL (物理)**・PFP-108 の D6 として統合済・gates-manifest 登録済・kill-switch `SOLOPTILINK_FORM_FIDELITY_GATE` |
| PFP-109 CSV 入出力 🆕 | `csv-io-gate.sh apply $P` | verdict ≠ FAIL (BOM 付き export 網羅 60%+) | WARN 既定 (STRICT で昇格) |
| PFP-110 性能基礎 🆕 | `performance-baseline-gate.sh run $P` | verdict 確認 + 非PASS 時 refiner 消化 (N+1/ページネーション) | WARN 既定・非ブロッキング |
| PFP-111 バックアップ/リストア 🆕 | `backup-restore-gate.sh apply $P` | verdict ≠ FAIL (backup 実体 + RESTORE.md) | WARN 既定 (STRICT で昇格) |
| PFP-115 基幹統合 🆕 | `enterprise-integration-gate.sh apply $P` | G1 仕訳連動 / G2 在庫引当 / G3 承認WF が PASS | enterprise 時のみ・WARN 既定 |
| PFP-094 追加開発結線 | `incremental-integration-gate.sh run $P --scope changed` | verdict 確認 (孤児テーブル/死蔵API/孤児ページ 0) | WARN 既定 (追加開発時必須) |
| PFP-FOLLOWTHROUGH 要件SoT台帳 🆕 | `requirement-completion-gate.sh run $P` (台帳発行は `lib/requirement-ledger/requirement-ledger.sh intake $P <計画書>`) | verdict ≠ BLOCK (全行が「実物到達」/「未検算(理由つき)」/「対象外(理由つき)」。未着手・実装済(未検証)の残存、行削除、証跡なしの到達主張、理由なしの未検算をいずれも検出。計画書類の無い案件は not_applicable) | **未達が残る完成宣言=BLOCK (物理)**・gates-manifest登録済・hook自動認識・kill-switch `SOLOPTILINK_REQUIREMENT_GATE` |
| PFP-086 実DBログイン (最重要) | `runtime-login-smoke.sh $P` | verdict=PASS (実走生成 JSON のみ有効・捏造封じ) | **hook が完成宣言を物理ブロック** |
| PFP-087 デプロイ時ログイン保証 | `deploy-login-guarantee.sh $P` (→`--apply`→`--probe <本番URL>`) | preflight ≠ BLOCK + probe=PASS | デプロイ時 BLOCK |
| PFP-173 デプロイ恒久化 (一発デプロイ) 🆕 | `deploy-permanence-gate.sh run $P` (計画は `lib/oneshot-deploy.sh plan $P`・記録は `lib/oneshot-deploy.sh record $P <URL> <method>`) | verdict ≠ BLOCK (配信URLが永続=Vercel/Netlify/Cloudflare Pages/Render/Fly/Railway/独自ドメイン。**一時トンネル (trycloudflare/ngrok/loca.lt) や localhost を『デプロイ完了』と称するのは BLOCK**。デプロイ意図なしは not_applicable) | **一時/揮発URLでの完成宣言=BLOCK (物理)**・kill-switch `SOLOPTILINK_DEPLOY_PERMANENCE_GATE` |
| PFP-089 データ永続化 | `data-persistence-guarantee.sh $P --apply` | verdict ≠ BLOCK (**無料の永続DBを既定適用・質問なし**=0円のままデータは永続保存。「有料でないと永続しない」という案内は誤りで禁止。有料は顧客の明示要求か無料枠超過見込み時のみ `lib/cost-simulator.sh estimate` の概算を提示して合意後に `--tier paid`) | BLOCK (未接続=none のみ) |
| PFP-090 機密保護 | `secret-protection-guarantee.sh $P` | verdict ≠ BLOCK (平文キー残存ゼロ) | BLOCK + hook |
| PFP-092 ビルド衛生+本番受け渡し | `build-dev-hygiene-gate.sh serve-prod --auto-stop $P` | verdict=PASS (signout 含む HTTP スモーク 500 ゼロ・`next start` で受け渡し) | 必須 |
| PFP-UI リッチ UI 12軸 | `ui-quality-gate.sh run $P` | verdict ≠ FAIL (理想 PASS≥9/12・不足は apply) | hook ブロック |
| PFP-190 レイアウト健全性 (読める見た目) 🆕 | `first-boot-perfect/layout-integrity-gate.sh run $P` | verdict ≠ FAIL (実ブラウザで採った寸法から「1文字ずつの縦積み」「数値の途中切れ」「指標カードの柱化」「横はみ出し」を物理検出。柱化1個以上/縦積み3件以上/クリップ3件以上=FAIL・軽度は WARN・**寸法の記録が無い画面は未測定として開示し PASS と言わない**・画面なしは not_applicable) | **読めない画面が残っていれば FAIL でブロック**・収集は実ブラウザ巡回に相乗り (ブラウザ追加起動ゼロ)・gates-manifest登録済・hook自動起動・kill-switch `SOLOPTILINK_LAYOUT_GATE=off`・厳格化 `STRICT_LAYOUT_INTEGRITY=true` |
| PFP-083 メガポータル 13軸 | `mega-portal-gate.sh apply $P` | PASS/PARTIAL (min 10/13) | Mega Portal 時のみ |
| PFP-084 画像 CMS 10軸 | `image-cms-gate.sh apply $P` | PASS/PARTIAL (min 7/10) | Mega Portal 時のみ |
| PFP-082 Watermark | `SD/pfp-082-watermark-validator.sh $P` | exit 0 (注入率 95%+) | 必須 |
| PFP-093 105ロール+CQI | `lib/centuria-live-orchestrator.sh verify $P` / `lib/centuria-synthesis.sh score $P` | 証跡 ≥ 計画編成数 (階層連動・総動員=全数/L=105/M=30/S=10) / CQI ≥80 (<90 は昇格ラダーで増強) | **hook が物理ブロック** |
| 相棒化 提案波 (2〜3体) 🆕 | `lib/centuria-live-orchestrator.sh verify-proposal $P` | 提案台帳に提案 ≥1・空回し(提案0)は不合格。根拠の名指し率を記録 | 完成条件ではない (開示条件) |
| PFP-125 敵対的検証波 (v2055=7体) 🆕 | `lib/centuria-live-orchestrator.sh verify-adversarial $P` | 反証証跡 ≥3 (7体=refuter/skeptic/falsifier/exploiter/saboteur/regression-hunter/ux-adversary 最終波) + 反証台帳の指摘解消 | 完成宣言前必須 |
| PFP-126 実走CRUD検証 🆕 | `first-boot-perfect/runtime-crud-smoke.sh run $P` | verdict ≠ FAIL (全業務モデルでtxn内 create→read→update→delete+rollback が実機成立・DB/schema未到達=FAIL) | WARN既定 (STRICTで昇格)・hook自動認識 |
| PFP-130 差別化機能 | `first-boot-perfect/differentiation-insight-gate.sh run $P` | verdict ≠ FAIL (DBL業務ロジックの実装 or 賢い機能ファイル≥2・汎用CRUD止まりを弁別) | **段階STRICT (v2054)**: リッチUI教典コンポ (lib/rich-ui-templates) 注入世代のビルドは STRICT 既定=FAIL 昇格 (PFP-150/160 も同条件で BLOCK 昇格)・旧世代ビルドは WARN 維持・明示 env 最優先 |
| PFP-133 法令実装 🆕 | `first-boot-perfect/compliance-implementation-gate.sh run $P` | verdict ≠ FAIL (検出業種に該当する日本法/規制の必須モデル・法的概念の実装 coverage ≥ 60%・該当法令は `compliance-attach.sh verify-spec` が逆引き・法令非該当業種は not_applicable) | WARN既定 (STRICT_COMPLIANCEで昇格)・gates-manifest登録済 |
| PFP-134 ドメインレーン注入 🆕 | `first-boot-perfect/domain-lane-gate.sh run $P` | verdict ≠ BLOCK (検出業種の日本堀レーンが生成物 lib/japan-runtime/ に実在しサンプル計算が法定値一致で実走・対象レーンは `domain-lane-injector.sh known-lanes` が正典 = 2026-08-07 時点 20 レーン (機械製図 mech-draft を含む)・非該当業種は not_applicable) | **該当業種で未注入=BLOCK (物理)**・gates-manifest登録済・hook自動認識 |
| PFP-046 全ページ実走 DPT (補助) | Playwright `tests/dpt.spec.mjs` (雛形: `lib/templates/dpt.spec.template.mjs`) | errors.json が在る場合のみ total=0 (受入テスト実施時) | 補助 (主軸は PFP-136) |
| PFP-136 実ブラウザ深掘り+ボタン操作スモーク 🆕 | `first-boot-perfect/live-browser-smoke.sh run $P` | verdict=PASS / errors total=0 (**dev モード**で systemChrome を実起動→実ログイン→**深さ6層まで潜って全画面を実訪問**→各画面のボタン/タブ/モーダルを**実クリック**。ページ表示時とボタン押下時の Hydration/例外/5xx を物理検出。破壊系ボタンは押さない=副作用ゼロ。依存ゼロ=Playwright不要・6階層fixtureで両側弁別実証済) | **fail-closed: 未実行/古い/偽物/FAIL/ERROR/操作検証なし を hook が物理ブロック** (本格ビルド規模・非webは not_applicable・kill-switch `SOLOPTILINK_LIVE_BROWSER_SMOKE=off`・深さ調整 `LBS_MAX_DEPTH`)・gates-manifest登録済 |
| PFP-145 ナビリンク整合性 🆕 | `first-boot-perfect/nav-link-integrity-gate.sh run $P` | verdict ≠ BLOCK (サイドバー/ナビ/本文に露出した内部リンク全件が実在ページに解決・`(group)`/`[id]`/catch-all 対応・public資産考慮。「リンク定義だけしてページ未実装=顧客に404露出」を静的検出。PFP-136 と合成で「露出リンクは全てエラーなく描画」保証が完成) | **ナビ由来の未実装リンク=BLOCK (物理)**・gates-manifest登録済・hook自動認識・kill-switch `SOLOPTILINK_NAV_LINK_GATE=off` |
| PFP-170 APIキー即納品性 🆕 | `first-boot-perfect/api-key-readiness-gate.sh run $P` (不足時 `apply $P`) | verdict ≠ WARN が理想 (未設定の外部APIキーが全て .env.example + docs/API_KEYS.md(取得手順・貼る場所・確認方法) に記載済=**「あとAPIキーを貼れば動く」状態**で納品可能。外部キー参照なしは not_applicable) | WARN 既定・完成報告に未設定キー一覧を必ず明記 |
| PFP-120 品質証明書 🆕 | `lib/quality-evidence-report.sh generate $P` | `品質証明書.html` 発行 (実測のみ・捏造ゼロ) | 非ブロッキング |
| PFP-SECREPORT セキュリティ診断報告書 🆕 | `lib/security-assessment-report.sh generate $P` | `セキュリティ診断報告書.html` 発行 (実装状況23項目/接続情報/外部部品の弱点/基準適合度を実測のみで記載。未実施の検査と診断範囲外は必ず開示) | 非ブロッキング |
| 段階別到達表 🆕 (2026-10-21・守りの段) | `lib/security-level/level-attainment.py report $P` | 守りの水準の記録がある案件で `段階別到達表.html` 発行 (選んだ水準の到達=約束の照合∧攻撃の巡回∧編成∧記録。実起動した守りの担当数・巡ごとの試した/防げた/対象なし数・未達件数を1枚で。認証未取得と範囲外を必ず開示・未達は先頭に) | 非ブロッキング・水準の記録が無い案件は発行しない・chain/完成ゲート/完成宣言の3経路で自動発行・kill-switch `ENABLE_LEVEL_ATTAINMENT_REPORT=false` |
| PFP-152 完璧収束ループ 🆕 | `first-boot-perfect/perfection-convergence-loop.sh run $P` | verdict ≠ FAIL (5 観点 security/data-accuracy/business-fit/UX/code-quality で最終レビュー→CRITICAL=0 まで最大 3 巡ループ収束・認証セッション 3 原則を inject-auth-guard.sh で自動注入) | **完成宣言前必須・BLOCK (物理)** ・gates-manifest 登録済・hook 自動認識・kill-switch `SOLOPTILINK_PERFECTION_LOOP=off` |

**主要ゲートの正式名と必須条件 (SoT 整合・詳細は `references/gates.md`)**:
- **PFP-074 Form Critical Path Gate 三兄弟 (REHD/FCPG/OSCG)** — 請求書/見積/契約/受注/予約フォームの一発送信保証。PFP-074 違反 0 件まで完成宣言禁止。
- **PFP-080 Sequential 105 + Layered Depth Gate** — L0/L1/L2/L3 連続到達 + 業界用語含有率 (DBL 登録済 100語+/未登録 150語+)。DBL 登録済み業種は L3 必須。
- **PFP-087 Deploy-Time Login Guarantee** — 「デプロイして」=本番URLでログインできる状態で出力が大前提。preflight (BLOCK 不可) → `--apply` → デプロイ後 `--probe <本番URL>` verdict=PASS まで完成宣言禁止 (PFP-087 検出 5 モード: SQLite-on-serverless / NEXTAUTH_URL 不一致 / SECRET 未設定 / 本番未シード / プール未設定)。

補助 (詳細: `references/gates.md`): セキュリティスキャン `--security-scan . --security-fix` (Level 2+) / docs 5点生成 (Level 3) / dev server 自動起動 (preview_*)。

### 完成時: 品質証明書の発行と案内 (PFP-120 / v2040 NEW)

全品質ゲートの実測記録 (`.soloptilink/*-results.json`) が出揃った完成宣言の直前に必ず実行:
```bash
bash ~/.soloptilink/lib/quality-evidence-report.sh generate "$PROJECT_DIR"
```
`$PROJECT_DIR/品質証明書.html` が実測データのみから生成される (results.json 判定 / agent-evidence 証跡実数 / ページ走査 / レーダーチャート・PFP 番号非露出)。完成報告でお客様に「**品質証明書を同梱しました**」と一言添える (中身のコード・内部ゲート名は地の文に貼らない)。生成失敗でも完成は妨げない (kill-switch: `ENABLE_QUALITY_EVIDENCE_REPORT=false`)。

---

