﻿# =============================================================================
# SoloptiLinkAI v2034.5 - Claude Desktop MCP 自動登録 (Windows)
# =============================================================================
# soloptilink-install.ps1 完了後にこれを実行することで、
# %APPDATA%\Claude\claude_desktop_config.json に soloptilink を MCP サーバーとして
# 自動登録します。既存設定を保持しつつマージするので、他の MCP サーバー設定は
# 失われません。
# =============================================================================

[CmdletBinding()]
param(
    [string]$InstallDir = "$HOME\.soloptilink"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

function Write-Step($msg) { Write-Host "[STEP] $msg" -ForegroundColor Cyan }
function Write-Ok($msg)   { Write-Host "[ OK ] $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Write-Err($msg)  { Write-Host "[FAIL] $msg" -ForegroundColor Red }

# ★修正F (2026-09-03): オブジェクトに指定の項目があるかを安全に調べる。
#   Set-StrictMode -Version Latest の下では、要素が 0 件のコレクションから
#   名前をまとめて取り出すと「このオブジェクトにプロパティ 'Name' が
#   見つかりません」で停止する。設定ファイルがまだ無い端末では必ず 0 件に
#   なるため、この復旧用スクリプトも同じ場所で必ず失敗していた。
#   (soloptilink-install.ps1 の STEP 9 と同一の欠陥。実機で確認済み)
function Test-HasProperty($obj, $name) {
    if ($null -eq $obj) { return $false }
    foreach ($p in $obj.PSObject.Properties) {
        if ($p.Name -eq $name) { return $true }
    }
    return $false
}

function End-Pause {
    Write-Host ""
    Write-Host "==============================================================="
    Write-Host " 完了しました。何かキーを押すとウィンドウを閉じます。"
    Write-Host "==============================================================="
    if ($Host.Name -eq "ConsoleHost") {
        [void][System.Console]::ReadKey($true)
    }
}

trap {
    Write-Err "エラーが発生しました: $($_.Exception.Message)"
    End-Pause
    exit 1
}

Write-Host ""
Write-Host "================================================================="
Write-Host " SoloptiLinkAI v2034.5  Claude Desktop MCP 自動登録"
Write-Host "================================================================="
Write-Host ""

# -----------------------------------------------------------------------------
# STEP 1: SoloptiLinkAI Goランチャー検出
# -----------------------------------------------------------------------------
Write-Step "1/4 Goランチャー検出"

$launcher = Join-Path $InstallDir "soloptilink.exe"
if (-not (Test-Path $launcher)) {
    Write-Err "  $launcher が見つかりません。"
    Write-Host "  先に soloptilink-install.ps1 (or .bat) を実行してください。"
    End-Pause; exit 1
}
Write-Ok "  $launcher 検出"

# -----------------------------------------------------------------------------
# STEP 2: claude_desktop_config.json の場所確認
# -----------------------------------------------------------------------------
Write-Step "2/4 Claude Desktop 設定ファイル"

$cfgDir = "$env:APPDATA\Claude"
$cfgPath = "$cfgDir\claude_desktop_config.json"

if (-not (Test-Path $cfgDir)) {
    Write-Warn "  Claude Desktop 設定ディレクトリがありません。"
    Write-Host "  先に Claude Desktop (https://claude.ai/download) をインストールしてください。"
    Write-Host "  続行しますか? (Y/n)"
    $ans = Read-Host
    if ($ans -ne "Y" -and $ans -ne "y" -and $ans -ne "") {
        End-Pause; exit 0
    }
    New-Item -ItemType Directory -Path $cfgDir | Out-Null
}
Write-Ok "  設定ディレクトリ: $cfgDir"

# -----------------------------------------------------------------------------
# STEP 3: 既存設定のバックアップ
# -----------------------------------------------------------------------------
Write-Step "3/4 既存設定のバックアップ"

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
if (Test-Path $cfgPath) {
    $bak = "$cfgPath.bak.$stamp"
    Copy-Item $cfgPath $bak -Force
    Write-Ok "  バックアップ: $bak"

    try {
        $cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        Write-Warn "  既存設定が JSON として読めません。新規作成します。"
        $cfg = [PSCustomObject]@{}
    }
} else {
    Write-Ok "  既存設定なし (新規作成)"
    $cfg = [PSCustomObject]@{}
}

# -----------------------------------------------------------------------------
# STEP 4: mcpServers.soloptilink を追加 (既存 mcpServers は保持)
# -----------------------------------------------------------------------------
Write-Step "4/4 soloptilink MCP サーバーを登録"

# mcpServers プロパティが無ければ追加
if (-not (Test-HasProperty $cfg "mcpServers")) {
    $cfg | Add-Member -MemberType NoteProperty -Name "mcpServers" -Value ([PSCustomObject]@{})
}

# 中身が空 (null) の設定への備え
if ($null -eq $cfg.mcpServers) { $cfg.mcpServers = [PSCustomObject]@{} }

# 既存 soloptilink エントリを上書き
$entry = [PSCustomObject]@{
    command = $launcher.Replace("\", "/")
    args    = @("--mcp-server")
}

# PSCustomObject に動的にプロパティ追加
if (Test-HasProperty $cfg.mcpServers "soloptilink") {
    $cfg.mcpServers.soloptilink = $entry
} else {
    $cfg.mcpServers | Add-Member -MemberType NoteProperty -Name "soloptilink" -Value $entry
}

# JSON書き戻し (UTF-8 BOMなし)
$json = $cfg | ConvertTo-Json -Depth 20
[System.IO.File]::WriteAllText($cfgPath, $json, [System.Text.UTF8Encoding]::new($false))

Write-Ok "  登録完了"
Write-Host ""
Write-Host "  登録内容:"
Write-Host "    mcpServers.soloptilink.command = $launcher"
Write-Host "    mcpServers.soloptilink.args    = [`"--mcp-server`"]"
Write-Host ""
Write-Host "================================================================="
Write-Host " 完了"
Write-Host "================================================================="
Write-Host ""
Write-Host " 次のステップ:"
Write-Host "   1. Claude Desktop を一度終了 (タスクトレイから完全終了)"
Write-Host "   2. Claude Desktop を再起動"
Write-Host "   3. チャット欄で /soloptilink-boost が使えるようになります"
Write-Host ""
Write-Host " トラブルシュート:"
Write-Host "   - MCP が見えない場合は Claude Desktop のログを確認"
Write-Host "     %APPDATA%\Claude\logs\"
Write-Host "   - サポート: nomura.y@soloptilink.com"
Write-Host ""

End-Pause
exit 0
