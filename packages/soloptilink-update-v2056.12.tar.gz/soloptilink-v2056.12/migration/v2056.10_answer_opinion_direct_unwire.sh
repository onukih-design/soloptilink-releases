#!/usr/bin/env bash
# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# ============================================================
# v2056.10 — 応答の見張りと所見の見張りの「直接の登録」を、お客様の設定から外す (2026-10-17 新設・K-10)
# ------------------------------------------------------------
# 【何が起きていたか (ソースからの推定・お客様の端末では未測定)】
#   お客様の端末では、1 回の停止 (Stop) で次の 2 本が 2 回ずつ走る作りになっていた。
#     - centuria-answer-guard-direct.sh (応答の見張り)
#     - opinion-guard-direct.sh         (所見の見張り)
#   ① migration/v2056_answer_guard_hook.sh が Stop へ直接登録する
#   ② lib/hooks/response-gate.sh (v2056.6_w5 / v2056.10_skill_heal_hook_wire が Stop へ登録) も、
#      既定の束 (RG_GUARDS_DEFAULT) で同じ 2 本を呼ぶ
#   束の中の重複のまとめ (response-gate.sh) は束の外の直接の登録とは重複を除けない。直接の登録を
#   外す処理は導入・更新のどこにも無かった (管理者端末は手で外してあり 1 回だけ)。
#   9/22 に完成ゲートで直した「1 回の停止で 2 回走る」と同じ型で、差し戻しの数え上げが 2 つ進み・
#   同じ指摘が 2 通出うる。
#
# 【本 migration がすること】
#   Stop に response-gate.sh が登録されていて実体もある端末に限り、Stop の中の
#   「当社の 2 本の見張りを直接呼ぶだけの登録」を外す。束で呼ばれ続けるので見張りは止まらない。
#   ★外さないもの (お客様の設定を壊さない・見張りを失わない):
#     - response-gate.sh が登録されていない端末 (直接の登録だけが頼り) → 何もせず、後で再試行
#     - 設定の env で SOLOPTILINK_RESPONSE_GATE=off (束ねる側を止めている) → 何もしない
#     - 設定の env の SOLOPTILINK_RESPONSE_GATE_GUARDS に、その見張りが入っていない → その見張りは外さない
#     - お客様が他の命令とつないで書いた登録 (例: 「bash 自社の台本.sh && bash …-direct.sh」) → 触らない
#     - Stop 以外の区切り・他のフック・permissions 等の他の設定 → 触らない
#
# 【なぜ別名の新しい migration か】
#   v2056_answer_guard_hook.sh は既に適用済み (state のキー v2056_answer_guard_hook.r2) の端末が多く、
#   直してもその端末では二度と走らない。外す処理はこの新しい名前 (= 新しい state のキー) で届ける
#   (v2056.10_skill_heal_hook_wire.sh と同じやり方)。あわせて v2056_answer_guard_hook.sh 側も、
#   response-gate.sh が登録済みの端末では直接登録を足さないように直した (新規導入で、台本の
#   実行順によって「外した後にまた足される」ことを防ぐ)。
#
# 【既存顧客への遡及】
#   auto-update.sh が起動のたびに migration/v*.sh を state 参照つきで実行する (更新で migration/ ごと届く)。
#   新規導入は setup.sh / Setup.command / soloptilink-install.ps1 が migration/ 配下を全実行する。
#   response-gate.sh がまだ登録されていない間は state を書かない (後で登録されたら次の起動で外す)。
#
# 【安全側の原則】(v2056.10_skill_heal_hook_wire.sh と同じ)
#   - 冪等 / 必ず控えを取る (~/.claude/.backups/) / 壊れた settings.json は 1 バイトも書き換えない
#   - 外すものが無いときは settings.json に一切書かない (お客様が整えた書式・並びを動かさない)
#   - 書いた直後に JSON として読み直し、読めなければ控えから戻す
#   - python3 が無ければ何もせず正常終了 (state を書かない = 再試行可能)
#   - 失敗しても導入・更新そのものは絶対に止めない (exit 0)
#
# 【kill-switch】
#   SOLOPTILINK_DIRECT_GUARD_UNWIRE=off … 本 migration を no-op にする (state を書かない)
#
# CLI:
#   bash ~/.soloptilink/migration/v2056.10_answer_opinion_direct_unwire.sh            (適用)
#   bash ~/.soloptilink/migration/v2056.10_answer_opinion_direct_unwire.sh selftest   (両側判定・砂箱のみ)
# ============================================================
set -u

MIG_NAME="v2056.10_answer_opinion_direct_unwire"
SL_DIR="${SOLOPTILINK_DIR:-${SOLOPTILINK_HOME:-$HOME/.soloptilink}}"
CLAUDE_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
SETTINGS_FILE="${CLAUDE_SETTINGS:-$CLAUDE_DIR/settings.json}"
BACKUP_DIR="$CLAUDE_DIR/.backups"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"

mig_log() {
    echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}

# ------------------------------------------------------------
# 外す処理の python 本体を一時ファイルへ書き出す
#   ★$( ) の内側にヒアドキュメントを置かない (bash 3.2 で壊れる = お客様の Mac で不動)
# ------------------------------------------------------------
_uw_write_py() {
    cat > "$1" <<'PYEOF'
import json, os, re, shutil, sys

settings = os.environ["UW_SETTINGS"]
sl_dir = os.environ["UW_SL_DIR"]
TARGETS = ["centuria-answer-guard-direct.sh", "opinion-guard-direct.sh"]
GATE = "response-gate.sh"
OFF = ("off", "0", "false", "no", "disabled")

if not os.path.exists(settings):
    print("WAIT_NO_SETTINGS"); sys.exit(0)
try:
    with open(settings, encoding="utf-8") as f:
        data = json.load(f)
except Exception:
    print("ABORT_UNPARSABLE"); sys.exit(0)
if not isinstance(data, dict):
    print("ABORT_NOT_DICT"); sys.exit(0)
hooks = data.get("hooks")
if not isinstance(hooks, dict):
    print("WAIT_NO_GATE"); sys.exit(0)
stop = hooks.get("Stop")
if not isinstance(stop, list):
    print("WAIT_NO_GATE"); sys.exit(0)

# 束ねる側が登録されていて実体もあるか
gate_path = os.path.join(sl_dir, "lib", "hooks", GATE)
def cmds(entry):
    for h in (entry.get("hooks") or []):
        if isinstance(h, dict):
            yield h, (h.get("command") or "")
gate_wired = any(GATE in c for e in stop if isinstance(e, dict) for _h, c in cmds(e))
if not gate_wired or not os.path.isfile(gate_path):
    print("WAIT_NO_GATE"); sys.exit(0)

# 設定の env で束ねる側を止めている / 束を差し替えているか
env = data.get("env") if isinstance(data.get("env"), dict) else {}
if str(env.get("SOLOPTILINK_RESPONSE_GATE", "on")).strip().lower() in OFF:
    print("SKIP_GATE_OFF"); sys.exit(0)
bundle = None
override = env.get("SOLOPTILINK_RESPONSE_GATE_GUARDS")
if isinstance(override, str) and override.strip():
    bundle = set(override.split())
else:
    # 実体の既定の束を読む (読めなければ外さない)
    try:
        src = open(gate_path, encoding="utf-8", errors="replace").read()
        m = re.search(r'^RG_GUARDS_DEFAULT="([^"]*)"', src, re.M)
        bundle = set(m.group(1).split()) if m else None
    except Exception:
        bundle = None
if bundle is None:
    print("SKIP_BUNDLE_UNKNOWN"); sys.exit(0)
removable = [t for t in TARGETS if t in bundle]

# 「当社の見張りを直接呼ぶだけ」の登録だけを外す。他の命令とつないだ登録には触らない。
def is_plain_direct(cmd, target):
    pat = (r'^\s*(?:env(?:\s+-u\s+\S+)*\s+)?bash\s+["\']?(?:\$HOME|\$\{HOME\}|~|' +
           re.escape(os.path.expanduser("~")) + r'|' + re.escape(os.path.dirname(os.path.abspath(sl_dir))) +
           r')/\.soloptilink/lib/hooks/' + re.escape(target) +
           r'["\']?\s*(?:2>\s*/dev/null)?\s*(?:\|\|\s*true)?\s*$')
    if re.match(pat, cmd):
        return True
    # SOLOPTILINK_DIR を既定以外に置いた端末: その場所の実体を直接呼ぶ形
    p2 = (r'^\s*bash\s+["\']?' + re.escape(os.path.join(os.path.abspath(sl_dir), "lib", "hooks", target)) +
          r'["\']?\s*(?:2>\s*/dev/null)?\s*(?:\|\|\s*true)?\s*$')
    return bool(re.match(p2, cmd))

removed = 0
left_custom = 0
new_stop = []
for entry in stop:
    if not isinstance(entry, dict) or not isinstance(entry.get("hooks"), list):
        new_stop.append(entry); continue
    kept = []
    touched = False
    for h in entry["hooks"]:
        c = (h.get("command") or "") if isinstance(h, dict) else ""
        hit = next((t for t in removable if t in c), None)
        if hit and is_plain_direct(c, hit):
            removed += 1; touched = True
            continue
        if any(t in c for t in TARGETS):
            left_custom += 1
        kept.append(h)
    if touched and not kept:
        continue                      # 中身が空になった登録だけを落とす
    if touched:
        entry = dict(entry); entry["hooks"] = kept
    new_stop.append(entry)

if removed == 0:
    print("UNWIRED removed=0 left_custom=%d (no write)" % left_custom); sys.exit(0)
hooks["Stop"] = new_stop
tmp = settings + ".tmp.%d" % os.getpid()
try:
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")
    with open(tmp, encoding="utf-8") as f:
        json.load(f)
    try:
        shutil.copymode(settings, tmp)   # 0600 で運用している端末を 0644 にしない
    except Exception:
        pass
except Exception as e:
    try:
        os.unlink(tmp)
    except Exception:
        pass
    print("ABORT_WRITE_INVALID %s" % type(e).__name__); sys.exit(0)
os.replace(tmp, settings)
print("UNWIRED removed=%d left_custom=%d" % (removed, left_custom))
PYEOF
}

mig_apply() {
    mkdir -p "$SL_DIR" "$CLAUDE_DIR" "$BACKUP_DIR" 2>/dev/null || true
    mig_log "START"

    case "$(printf '%s' "${SOLOPTILINK_DIRECT_GUARD_UNWIRE:-on}" | tr 'A-Z' 'a-z')" in
        off|0|false|no|disabled)
            mig_log "KILL_SWITCH SOLOPTILINK_DIRECT_GUARD_UNWIRE=off -> NOOP (retryable)"
            return 0 ;;
    esac
    if [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; then
        mig_log "ALREADY_APPLIED -> NOOP"; return 0
    fi
    if ! command -v python3 >/dev/null 2>&1; then
        mig_log "PRECONDITION_FAILED python3 not found (retryable)"; return 0
    fi
    UW_TMPD="$(mktemp -d "${TMPDIR:-/tmp}/uwhook.XXXXXX" 2>/dev/null)" || {
        mig_log "PRECONDITION_FAILED mktemp (retryable)"; return 0; }

    TS="$(date +%Y%m%dT%H%M%S)"
    if [ -f "$SETTINGS_FILE" ]; then
        cp -p "$SETTINGS_FILE" "$BACKUP_DIR/settings.json.pre-${MIG_NAME}-${TS}" 2>/dev/null || true
    fi

    _uw_write_py "$UW_TMPD/unwire.py"
    UW_RESULT="$(UW_SETTINGS="$SETTINGS_FILE" UW_SL_DIR="$SL_DIR" python3 "$UW_TMPD/unwire.py" 2>>"$LOG_FILE")"
    rm -rf "$UW_TMPD" 2>/dev/null || true

    # 書いた直後に、シェル側からも JSON として読み直して確かめる (二重の確認)
    if [ -f "$SETTINGS_FILE" ]; then
        if ! UW_SETTINGS="$SETTINGS_FILE" python3 -c 'import json,os; json.load(open(os.environ["UW_SETTINGS"],encoding="utf-8"))' >/dev/null 2>&1; then
            case "$UW_RESULT" in
                UNWIRED*)
                    mig_log "POSTCHECK_FAILED settings.json が JSON として読めない -> 控えから戻します"
                    [ -f "$BACKUP_DIR/settings.json.pre-${MIG_NAME}-${TS}" ] && \
                        cp -p "$BACKUP_DIR/settings.json.pre-${MIG_NAME}-${TS}" "$SETTINGS_FILE" 2>/dev/null || true
                    return 0 ;;
            esac
        fi
    fi
    # 何も書かなかった回の控えは残さない (控えが毎回の起動で積み上がらないように)
    case "$UW_RESULT" in
        "UNWIRED removed=0"*|WAIT*|SKIP*|ABORT*) rm -f "$BACKUP_DIR/settings.json.pre-${MIG_NAME}-${TS}" 2>/dev/null || true ;;
    esac

    case "$UW_RESULT" in
        UNWIRED*|SKIP_GATE_OFF*|SKIP_BUNDLE_UNKNOWN*)
            mig_log "RESULT ($UW_RESULT)" ;;
        *)
            # WAIT_* (束ねる側が未登録) / ABORT_* (壊れた設定) は state を書かず、次の起動で再試行する
            mig_log "WAIT ($UW_RESULT) -> state を書かず再試行可能にします"
            return 0 ;;
    esac
    case "$UW_RESULT" in
        SKIP_*) mig_log "SKIP ($UW_RESULT) -> 設定で束ねる側を止める/束を変えているため外さない。state を書かず再試行可能にします"
                return 0 ;;
    esac

    APPLIED_AT="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    UW_STATE_FILE="$STATE_FILE" UW_MIG_NAME="$MIG_NAME" UW_APPLIED_AT="$APPLIED_AT" python3 - <<'PYEOF' 2>>"$LOG_FILE"
import json, os
sf = os.environ['UW_STATE_FILE']
try:
    with open(sf, encoding="utf-8") as f:
        data = json.load(f)
except Exception:
    data = {}
if not isinstance(data, dict):
    data = {}
data[os.environ['UW_MIG_NAME']] = {"applied_at": os.environ['UW_APPLIED_AT']}
tmp = sf + ".tmp.%d" % os.getpid()
with open(tmp, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
os.replace(tmp, sf)
PYEOF
    mig_log "DONE applied_at=${APPLIED_AT} ($UW_RESULT)"
    return 0
}

# ------------------------------------------------------------
# selftest — 隔離した仮想 HOME で実走する (実際の ~/.claude・~/.soloptilink には触らない)
#   U1 束ねる側 + 直接 2 本の端末 → 直接 2 本だけが外れ、束ねる側と他のフックは残る・JSON 妥当・適用済み
#   U2 冪等: state を消して再実行しても何も変わらない (書かない)
#   U3 束ねる側が未登録の端末 → 直接の登録を外さない・適用済みにしない (後で再試行)
#   U4 お客様が他の命令とつないだ登録 → 触らない
#   U5 設定の env で束を差し替え (所見の見張りを入れていない) → 所見の見張りの直接登録は残す
#   U6 設定の env で束ねる側を止めている → 何も外さない
#   U7 壊れた settings.json → 1 バイトも書き換えない・適用済みにしない
#   U8 kill-switch off → 何も外さない
#   U9 実行順: 外す台本の後に v2056_answer_guard_hook.sh が走っても、直接登録は足されない
# ------------------------------------------------------------
mig_selftest() {
    local self rc=0
    self="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
    root="$(mktemp -d "${TMPDIR:-/tmp}/uwsel.XXXXXX")" || return 1
    trap 'rm -rf "$root" 2>/dev/null || true' EXIT INT TERM

    _mk_env() { # $1=name : 実体を置いた仮想 ~/.soloptilink と ~/.claude
        mkdir -p "$root/$1/sl/lib/hooks" "$root/$1/claude"
        printf '#!/usr/bin/env bash\nRG_GUARDS_DEFAULT="centuria-answer-guard-direct.sh opinion-guard-direct.sh persona-guard-direct.sh"\nexit 0\n' \
            > "$root/$1/sl/lib/hooks/response-gate.sh"
        printf '#!/usr/bin/env bash\nexit 0\n' > "$root/$1/sl/lib/hooks/centuria-answer-guard-direct.sh"
        printf '#!/usr/bin/env bash\nexit 0\n' > "$root/$1/sl/lib/hooks/opinion-guard-direct.sh"
    }
    _write() { # $1=settings.json $2=JSON の文字列
        UW_S="$1" UW_J="$2" python3 -c 'import json,os; json.dump(json.loads(os.environ["UW_J"]), open(os.environ["UW_S"],"w",encoding="utf-8"), indent=2, ensure_ascii=False)'
    }
    _count() { # $1=settings.json $2=名前 → Stop の中でその名前を含む命令の数
        UW_S="$1" UW_N="$2" python3 -c '
import json,os
try: d=json.load(open(os.environ["UW_S"],encoding="utf-8"))
except Exception: print(-1); raise SystemExit
n=0
for e in (d.get("hooks") or {}).get("Stop") or []:
    for h in (e.get("hooks") or []):
        if os.environ["UW_N"] in (h.get("command") or ""): n+=1
print(n)'
    }
    _applied() { [ -f "$root/$1/sl/.migration-state.json" ] && grep -q "\"${MIG_NAME}\"" "$root/$1/sl/.migration-state.json" && echo yes || echo no; }
    _run() { # $1=name, 以降は追加 env
        local name="$1"; shift
        env -u CLAUDE_SETTINGS "$@" SOLOPTILINK_DIR="$root/$name/sl" SOLOPTILINK_HOME="$root/$name/sl" \
            CLAUDE_CONFIG_DIR="$root/$name/claude" bash "$self" >/dev/null 2>&1
    }
    BASE='{"permissions":{"allow":["Bash(ls:*)"]},"hooks":{"SessionStart":[{"matcher":"*","hooks":[{"type":"command","command":"bash ~/.soloptilink/auto-update.sh"}]}],"Stop":[{"matcher":"*","hooks":[{"type":"command","command":"bash \"$HOME/.soloptilink/lib/hooks/response-gate.sh\"","timeout":60}]},{"matcher":"*","hooks":[{"type":"command","command":"bash \"$HOME/.soloptilink/lib/hooks/centuria-answer-guard-direct.sh\"","timeout":8}]},{"matcher":"*","hooks":[{"type":"command","command":"bash \"$HOME/.soloptilink/lib/hooks/opinion-guard-direct.sh\"","timeout":10}]},{"matcher":"","hooks":[{"type":"command","command":"bash ~/my-own-stop.sh"}]}]}}'

    # U1
    _mk_env u1; _write "$root/u1/claude/settings.json" "$BASE"; _run u1
    local a1 o1 g1 c1 p1 s1
    a1="$(_count "$root/u1/claude/settings.json" centuria-answer-guard-direct.sh)"
    o1="$(_count "$root/u1/claude/settings.json" opinion-guard-direct.sh)"
    g1="$(_count "$root/u1/claude/settings.json" response-gate.sh)"
    c1="$(_count "$root/u1/claude/settings.json" my-own-stop.sh)"
    p1="$(UW_S="$root/u1/claude/settings.json" python3 -c 'import json,os; d=json.load(open(os.environ["UW_S"])); print("yes" if d["permissions"]["allow"]==["Bash(ls:*)"] and "auto-update.sh" in json.dumps(d["hooks"]["SessionStart"]) else "no")' 2>/dev/null)"
    s1="$(_applied u1)"
    if [ "$a1/$o1/$g1/$c1/$p1/$s1" = "0/0/1/1/yes/yes" ]; then echo "  [OK] U1: 直接の 2 本だけを外し、束ねる側・お客様のフック・他の設定は残る (適用済み)"
    else echo "  [FAIL] U1: answer=$a1 opinion=$o1 gate=$g1 お客様=$c1 他設定=$p1 適用済み=$s1 (期待 0/0/1/1/yes/yes)"; rc=1; fi

    # U2 冪等
    rm -f "$root/u1/sl/.migration-state.json"
    local b2; b2="$(cksum < "$root/u1/claude/settings.json")"; _run u1
    if [ "$b2" = "$(cksum < "$root/u1/claude/settings.json")" ]; then echo "  [OK] U2: 再実行しても 1 バイトも変わらない"; else echo "  [FAIL] U2: 再実行で設定が変わった"; rc=1; fi

    # U3 束ねる側が未登録
    _mk_env u3
    _write "$root/u3/claude/settings.json" '{"hooks":{"Stop":[{"matcher":"*","hooks":[{"type":"command","command":"bash \"$HOME/.soloptilink/lib/hooks/centuria-answer-guard-direct.sh\"","timeout":8}]}]}}'
    _run u3
    local a3 s3; a3="$(_count "$root/u3/claude/settings.json" centuria-answer-guard-direct.sh)"; s3="$(_applied u3)"
    if [ "$a3/$s3" = "1/no" ]; then echo "  [OK] U3: 束ねる側が無い端末では外さず、適用済みにもしない (後で再試行)"; else echo "  [FAIL] U3: answer=$a3 適用済み=$s3 (期待 1/no)"; rc=1; fi

    # U4 他の命令とつないだ登録には触らない
    _mk_env u4
    _write "$root/u4/claude/settings.json" '{"hooks":{"Stop":[{"matcher":"*","hooks":[{"type":"command","command":"bash \"$HOME/.soloptilink/lib/hooks/response-gate.sh\""}]},{"matcher":"*","hooks":[{"type":"command","command":"bash ~/mine.sh && bash \"$HOME/.soloptilink/lib/hooks/opinion-guard-direct.sh\""}]}]}}'
    _run u4
    local o4; o4="$(_count "$root/u4/claude/settings.json" opinion-guard-direct.sh)"
    if [ "$o4" = "1" ]; then echo "  [OK] U4: お客様が他の命令とつないだ登録には触らない"; else echo "  [FAIL] U4: つないだ登録を消した (opinion=$o4)"; rc=1; fi

    # U5 束の差し替え (所見の見張りを入れていない)
    _mk_env u5
    UW_S="$root/u5/claude/settings.json" UW_B="$BASE" python3 -c 'import json,os; d=json.loads(os.environ["UW_B"]); d["env"]={"SOLOPTILINK_RESPONSE_GATE_GUARDS":"centuria-answer-guard-direct.sh persona-guard-direct.sh"}; json.dump(d,open(os.environ["UW_S"],"w"),indent=2)'
    _run u5
    local a5 o5; a5="$(_count "$root/u5/claude/settings.json" centuria-answer-guard-direct.sh)"; o5="$(_count "$root/u5/claude/settings.json" opinion-guard-direct.sh)"
    if [ "$a5/$o5" = "0/1" ]; then echo "  [OK] U5: 束に入っていない見張り (所見) の直接登録は残す"; else echo "  [FAIL] U5: answer=$a5 opinion=$o5 (期待 0/1)"; rc=1; fi

    # U6 束ねる側を止めている
    _mk_env u6
    UW_S="$root/u6/claude/settings.json" UW_B="$BASE" python3 -c 'import json,os; d=json.loads(os.environ["UW_B"]); d["env"]={"SOLOPTILINK_RESPONSE_GATE":"off"}; json.dump(d,open(os.environ["UW_S"],"w"),indent=2)'
    _run u6
    local a6 o6; a6="$(_count "$root/u6/claude/settings.json" centuria-answer-guard-direct.sh)"; o6="$(_count "$root/u6/claude/settings.json" opinion-guard-direct.sh)"
    if [ "$a6/$o6" = "1/1" ]; then echo "  [OK] U6: 束ねる側を止めている端末では何も外さない"; else echo "  [FAIL] U6: answer=$a6 opinion=$o6 (期待 1/1)"; rc=1; fi

    # U7 壊れた設定
    _mk_env u7; printf '{ "hooks": { "Stop": [ ' > "$root/u7/claude/settings.json"
    local b7; b7="$(cksum < "$root/u7/claude/settings.json")"; _run u7
    if [ "$b7" = "$(cksum < "$root/u7/claude/settings.json")" ] && [ "$(_applied u7)" = no ]; then echo "  [OK] U7: 壊れた設定は書き換えず、適用済みにもしない"; else echo "  [FAIL] U7: 壊れた設定を書き換えた/適用済みにした"; rc=1; fi

    # U8 kill-switch
    _mk_env u8; _write "$root/u8/claude/settings.json" "$BASE"; _run u8 SOLOPTILINK_DIRECT_GUARD_UNWIRE=off
    local a8; a8="$(_count "$root/u8/claude/settings.json" centuria-answer-guard-direct.sh)"
    if [ "$a8" = "1" ] && [ "$(_applied u8)" = no ]; then echo "  [OK] U8: kill-switch off で何も外さない"; else echo "  [FAIL] U8: kill-switch off でも外した (answer=$a8)"; rc=1; fi

    # U9 実行順: 外した後に直接登録の台本が走っても足されない (同じ migration/ の隣の台本を実走)
    local ag="$(dirname "$self")/v2056_answer_guard_hook.sh" a9="skip" o9="skip"
    if [ -f "$ag" ]; then
        _mk_env u9
        _write "$root/u9/claude/settings.json" '{"hooks":{"Stop":[{"matcher":"*","hooks":[{"type":"command","command":"bash \"$HOME/.soloptilink/lib/hooks/response-gate.sh\"","timeout":60}]}]}}'
        _run u9
        env -u CLAUDE_SETTINGS SOLOPTILINK_DIR="$root/u9/sl" CLAUDE_CONFIG_DIR="$root/u9/claude" bash "$ag" >/dev/null 2>&1
        a9="$(_count "$root/u9/claude/settings.json" centuria-answer-guard-direct.sh)"; o9="$(_count "$root/u9/claude/settings.json" opinion-guard-direct.sh)"
        if [ "$a9/$o9" = "0/0" ]; then echo "  [OK] U9: 束ねる側が登録済みの端末では、直接登録の台本が後から走っても足されない"
        else echo "  [FAIL] U9: 直接登録の台本が足した (answer=$a9 opinion=$o9)"; rc=1; fi
    else
        echo "  [FAIL] U9: 隣の v2056_answer_guard_hook.sh が見つからず測れなかった (未測定=合格にしない)"; rc=1
    fi

    if [ "$rc" -eq 0 ]; then
        echo "BOTHSIDED_SELFTEST:${MIG_NAME}:PASS:FAIL:健全側=直接の2本だけを外す・冪等 / 欠陥側=束ねる側なし・つないだ登録・束の差し替え・止めている・壊れた設定・kill-switch で外さない"
    else
        echo "BOTHSIDED_SELFTEST:${MIG_NAME}:UNMEASURED:UNMEASURED:両側判定のいずれかが不成立 (上の [FAIL] 行を参照)"
    fi
    return $rc
}

case "${1:-apply}" in
    selftest|--bothsided-selftest) mig_selftest; exit $? ;;
    apply|"") mig_apply; exit 0 ;;
    *)        mig_apply; exit 0 ;;
esac
