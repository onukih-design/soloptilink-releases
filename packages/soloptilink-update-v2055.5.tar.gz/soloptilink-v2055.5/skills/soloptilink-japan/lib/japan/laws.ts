/**
 * SoloptiLinkAI JAPAN-NATIVE Mode - 法令DNA Library
 * 8法令を網羅し、アプリケーションに直接注入できる判定・計算ユーティリティ群。
 *
 * 対応法令:
 *   1. インボイス制度 (消費税法 適格請求書等保存方式)
 *   2. 電子帳簿保存法 (電帳法)
 *   3. 個人情報保護法 (個情法)
 *   4. マイナンバー法 (番号法)
 *   5. 労働基準法 (労基法)
 *   6. 下請代金支払遅延等防止法 (下請法)
 *   7. 建設業法
 *   8. 金融商品取引法 (金商法)
 *
 * 使い方:
 *   import { Invoice, DenchoHo, PersonalInfo, MyNumber, LaborStd, Subcontract, Construction, FIEA } from './laws';
 *
 *   if (!Invoice.validateRegistrationNumber(supplier.invoiceNo)) throw new Error('登録番号不正');
 *   const tax = Invoice.calcTaxBreakdown(items); // { reduced8: 2400, standard10: 5000 }
 *   const violation = LaborStd.check36Agreement(monthlyOvertime);
 */

// =============================================================================
// Invoice: インボイス制度 (適格請求書等保存方式)
// =============================================================================
export const Invoice = {
  /**
   * 適格請求書発行事業者の登録番号検証
   * フォーマット: "T" + 13桁の数字 (法人番号と同じ桁数)
   */
  validateRegistrationNumber(no: string): boolean {
    if (!no) return false;
    return /^T\d{13}$/.test(no.trim());
  },

  /**
   * 税率別集計 (10% / 軽減8% / 非課税)
   */
  calcTaxBreakdown(items: Array<{ price: number; qty: number; rate: 'standard' | 'reduced' | 'exempt' }>): {
    subtotal: { standard: number; reduced: number; exempt: number };
    tax: { standard: number; reduced: number };
    total: number;
  } {
    const subtotal = { standard: 0, reduced: 0, exempt: 0 };
    for (const it of items) {
      const amount = it.price * it.qty;
      if (it.rate === 'standard') subtotal.standard += amount;
      else if (it.rate === 'reduced') subtotal.reduced += amount;
      else subtotal.exempt += amount;
    }
    const tax = {
      standard: Math.floor(subtotal.standard * 0.10),
      reduced: Math.floor(subtotal.reduced * 0.08),
    };
    const total = subtotal.standard + subtotal.reduced + subtotal.exempt + tax.standard + tax.reduced;
    return { subtotal, tax, total };
  },

  /**
   * 適格簡易請求書の発行可否判定 (小売/飲食/写真/旅行/タクシー/駐車場)
   */
  canIssueSimplified(industry: string): boolean {
    // ★2026-08-11 (全結線計画 BLK-2): 業種辞書の名前で呼ばれても正しく判定できるよう
    //   キーを正規化する。従来は 'retail-pos' が false になり、小売業なのに
    //   適格簡易請求書を発行できないと判定していた (消費税法第57条の4第2項が
    //   小売業に認めた特例を、システムが自ら捨てていた)。
    return ['retail', 'food_service', 'photo', 'travel', 'taxi', 'parking']
      .includes(normalizeIndustryKey(industry));
  },

  /**
   * 必須記載事項のチェック (適格請求書)
   */
  requiredFields(): string[] {
    return [
      '発行者の氏名または名称',
      '登録番号 (T + 13桁)',
      '取引年月日',
      '取引内容 (軽減税率対象である旨)',
      '税率ごとに区分した合計額',
      '税率ごとに区分した消費税額',
      '受領者の氏名または名称',
    ];
  },
};

// =============================================================================
// DenchoHo: 電子帳簿保存法
// =============================================================================
export const DenchoHo = {
  /**
   * 電子取引データの3要件検索キー生成 (取引年月日/取引金額/取引先)
   */
  buildSearchKeys(transaction: { date: string; amount: number; partner: string }): string[] {
    return [
      `date:${transaction.date}`,
      `amount:${transaction.amount}`,
      `partner:${transaction.partner}`,
    ];
  },

  /**
   * タイムスタンプ付与要件 (JIIMA認定タイムスタンプが必要)
   * スキャナ保存: おおむね7営業日以内
   * 電子取引: 法令遵守のため取引後速やかに
   */
  timestampDeadline(kind: 'scanner' | 'e_transaction'): number {
    return kind === 'scanner' ? 7 : 2; // 営業日
  },

  /**
   * 改ざん防止のためのハッシュ計算 (SHA-256 を推奨)
   */
  async computeFileHash(file: Uint8Array): Promise<string> {
    if (typeof crypto !== 'undefined' && crypto.subtle) {
      const buf = await crypto.subtle.digest('SHA-256', new Uint8Array(file));
      return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
    }
    throw new Error('Crypto API 利用不可。server-side で node:crypto を利用してください。');
  },

  /**
   * スキャナ保存要件 (解像度/階調)
   */
  scannerRequirements(): { dpi: number; colorDepth: number; fileFormat: string[] } {
    return { dpi: 200, colorDepth: 24, fileFormat: ['pdf', 'jpeg', 'png', 'tiff'] };
  },
};

// =============================================================================
// PersonalInfo: 個人情報保護法
// =============================================================================
export const PersonalInfo = {
  /**
   * 要配慮個人情報の分類 (医療/犯罪歴/人種/信条/社会的身分等)
   */
  isSensitive(field: string): boolean {
    const sensitive = [
      '病歴', '診療履歴', '服薬', '障害', '精神状態',
      '犯罪歴', '犯罪被害',
      '人種', '信条', '社会的身分', '国籍',
      '遺伝情報', '生体情報',
    ];
    return sensitive.some(s => field.includes(s));
  },

  /**
   * 利用目的通知文の雛形生成
   */
  generatePurposeNotice(params: { purposes: string[]; company: string; contact: string }): string {
    return [
      `${params.company} 個人情報の利用目的のお知らせ`,
      '',
      '当社では、以下の目的でお客さまの個人情報を取扱います:',
      ...params.purposes.map(p => `・${p}`),
      '',
      '上記目的の範囲を超えて利用することはございません。',
      '個人情報保護に関するお問い合わせ:',
      params.contact,
    ].join('\n');
  },

  /**
   * 第三者提供時の記録項目 (名簿屋規制対応)
   */
  thirdPartyRecordFields(): string[] {
    return ['提供年月日', '提供先の名称', '本人氏名', '提供した項目', '本人同意の有無'];
  },

  /**
   * 保有個人データの開示請求対応チェック (30日以内)
   */
  disclosureDeadlineDays(): number {
    return 30;
  },
};

// =============================================================================
// MyNumber: マイナンバー法
// =============================================================================
export const MyNumber = {
  /**
   * マイナンバーの形式検証 (12桁の数字 + チェックディジット)
   */
  validate(no: string): boolean {
    if (!/^\d{12}$/.test(no)) return false;
    const digits = no.split('').map(Number);
    const check = digits[11];
    const body = digits.slice(0, 11);
    // チェックディジット計算 (国税庁公表仕様)
    const weights = [6, 5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
    let sum = 0;
    for (let i = 0; i < 11; i++) sum += body[i] * weights[i];
    const rem = sum % 11;
    const cd = rem <= 1 ? 0 : 11 - rem;
    return cd === check;
  },

  /**
   * 表示用マスク (下4桁以外を * に)
   */
  mask(no: string): string {
    if (!no || no.length < 4) return '************';
    return '*'.repeat(no.length - 4) + no.slice(-4);
  },

  /**
   * 取扱可能業務の判定 (税・社保・災害対策の3分野のみ)
   */
  canHandle(purpose: 'tax' | 'social_security' | 'disaster' | string): boolean {
    return ['tax', 'social_security', 'disaster'].includes(purpose);
  },

  /**
   * 廃棄記録のフィールド
   */
  disposalRecordFields(): string[] {
    return ['廃棄年月日', '廃棄方法', '対象件数', '廃棄責任者', '立会者'];
  },
};

// =============================================================================
// LaborStd: 労働基準法
// =============================================================================
export const LaborStd = {
  /**
   * 36協定違反検知 (月45時間/年360時間の原則、特別条項で月100h/年720h上限)
   */
  check36Agreement(monthly: number[], yearly: number, hasSpecial: boolean): Array<{ month: number; hours: number; rule: string }> {
    const violations: Array<{ month: number; hours: number; rule: string }> = [];
    const monthLimit = hasSpecial ? 100 : 45;
    const yearLimit = hasSpecial ? 720 : 360;
    monthly.forEach((h, i) => {
      if (h > monthLimit) violations.push({ month: i + 1, hours: h, rule: `月${monthLimit}時間超過` });
    });
    if (yearly > yearLimit) violations.push({ month: 0, hours: yearly, rule: `年${yearLimit}時間超過` });
    // 特別条項ありでも、複数月平均80時間は違反
    if (hasSpecial) {
      for (let i = 2; i < monthly.length; i++) {
        const avg3 = (monthly[i - 2] + monthly[i - 1] + monthly[i]) / 3;
        if (avg3 > 80) violations.push({ month: i + 1, hours: Math.round(avg3), rule: '3ヶ月平均80時間超過' });
      }
    }
    return violations;
  },

  /**
   * 割増賃金率の算出 (時間外25%, 深夜25%, 法定休日35%, 月60h超50%)
   */
  overtimeRate(params: { overtimeHoursInMonth: number; isNight: boolean; isLegalHoliday: boolean }): number {
    let rate = 0;
    if (params.isLegalHoliday) rate = 0.35;
    else if (params.overtimeHoursInMonth > 60) rate = 0.50;
    else rate = 0.25;
    if (params.isNight) rate += 0.25;
    return rate;
  },

  /**
   * 有給休暇5日取得義務チェック (年10日付与される労働者対象)
   */
  check5DaysPaidLeave(annualPaidDays: number, takenDays: number): boolean {
    if (annualPaidDays < 10) return true; // 対象外
    return takenDays >= 5;
  },
};

// =============================================================================
// Subcontract: 下請代金支払遅延等防止法 (下請法)
// =============================================================================
export const Subcontract = {
  /**
   * 3条書面の必須記載事項
   */
  required3jouFields(): string[] {
    return [
      '発注者・受注者の名称',
      '発注日',
      '給付内容',
      '給付を受領する期日',
      '代金の額',
      '代金の支払期日',
      '代金の支払方法',
      '有償支給原材料等があるときはその内容',
    ];
  },

  /**
   * 支払遅延チェック (受領後60日以内が上限)
   */
  checkPaymentDeadline(receivedDate: Date, paymentDate: Date): { ok: boolean; days: number } {
    const days = Math.floor((paymentDate.getTime() - receivedDate.getTime()) / 86400000);
    return { ok: days <= 60, days };
  },

  /**
   * 下請法適用範囲判定 (資本金要件)
   */
  applies(parentCapital: number, childCapital: number, kind: 'manufacturing' | 'service'): boolean {
    if (kind === 'manufacturing') {
      if (parentCapital > 300_000_000 && childCapital <= 300_000_000) return true;
      if (parentCapital > 10_000_000 && parentCapital <= 300_000_000 && childCapital <= 10_000_000) return true;
    } else {
      if (parentCapital > 50_000_000 && childCapital <= 50_000_000) return true;
      if (parentCapital > 10_000_000 && parentCapital <= 50_000_000 && childCapital <= 10_000_000) return true;
    }
    return false;
  },

  /**
   * 禁止行為11類型
   */
  prohibitedActs(): string[] {
    return [
      '受領拒否', '下請代金の支払遅延', '下請代金の減額', '返品',
      '買いたたき', '購入・利用強制', '報復措置', '有償支給原材料等の対価の早期決済',
      '割引困難な手形の交付', '不当な経済上の利益の提供要請', '不当な給付内容の変更および不当なやり直し',
    ];
  },
};

// =============================================================================
// Construction: 建設業法
// =============================================================================
export const Construction = {
  /**
   * 建設業許可番号のフォーマット検証
   * 例: "国土交通大臣 特-30 第00001号" / "東京都知事 般-02 第000001号"
   */
  validateLicenseNumber(no: string): boolean {
    const pattern = /^(国土交通大臣|[都道府県]{2,3}知事)\s+(特|般)-\d{2}\s+第\d{5,6}号$/;
    return pattern.test(no.trim());
  },

  /**
   * 主任技術者/監理技術者の配置要件
   * 元請: 4500万円以上 (建築一式は7000万円以上) は監理技術者
   */
  requiredEngineer(contractAmount: number, isArchitecture: boolean, isPrime: boolean): 'chief' | 'supervisor' {
    const threshold = isArchitecture ? 70_000_000 : 45_000_000;
    if (isPrime && contractAmount >= threshold) return 'supervisor'; // 監理技術者
    return 'chief'; // 主任技術者
  },

  /**
   * 一括下請負の禁止 (公共工事は全面禁止、民間も原則禁止)
   */
  checkLumpSubcontracting(isPublic: boolean, hasConsent: boolean): { ok: boolean; reason?: string } {
    if (isPublic) return { ok: false, reason: '公共工事は一括下請負全面禁止' };
    if (!hasConsent) return { ok: false, reason: '民間工事でも書面承諾が必要' };
    return { ok: true };
  },

  /**
   * 建退共証紙の計算 (掛金日額310円 × 就労日数)
   */
  calcTaishokusho(workDays: number): number {
    return workDays * 310;
  },

  /**
   * 29業種の一覧
   */
  specialties(): string[] {
    return [
      '土木', '建築', '大工', '左官', 'とび・土工・コンクリート',
      '石', '屋根', '電気', '管', 'タイル・れんが・ブロック',
      '鋼構造物', '鉄筋', '舗装', 'しゅんせつ', '板金',
      'ガラス', '塗装', '防水', '内装仕上', '機械器具設置',
      '熱絶縁', '電気通信', '造園', 'さく井', '建具',
      '水道施設', '消防施設', '清掃施設', '解体',
    ];
  },
};

// =============================================================================
// FIEA: 金融商品取引法 (Financial Instruments and Exchange Act)
// =============================================================================
export const FIEA = {
  /**
   * 広告規制: 誇大表示禁止項目
   */
  prohibitedAdTerms(): string[] {
    return ['絶対', '必ず儲かる', '元本保証', '損失なし', '確実に'];
  },

  /**
   * 適合性の原則チェック (顧客属性と商品の適合)
   */
  checkSuitability(customer: { age: number; experience: number; income: number; assets: number }, product: { riskLevel: 1 | 2 | 3 | 4 | 5 }): { ok: boolean; reason?: string } {
    if (product.riskLevel >= 4 && customer.experience < 3) {
      return { ok: false, reason: '投資経験不足 (3年未満)' };
    }
    if (product.riskLevel === 5 && customer.age >= 75) {
      return { ok: false, reason: '75歳以上への高リスク商品勧誘制限' };
    }
    if (customer.assets < product.riskLevel * 1_000_000) {
      return { ok: false, reason: '必要金融資産不足' };
    }
    return { ok: true };
  },

  /**
   * 契約締結前交付書面の必須記載事項
   */
  preContractDocRequiredFields(): string[] {
    return [
      '手数料・報酬・費用',
      '元本欠損のおそれ',
      '金利変動・相場変動リスク',
      'クーリングオフの有無',
      '取扱業者の商号・登録番号',
      '指定紛争解決機関',
    ];
  },
};

// =============================================================================
// 統合判定: 業種から必要法令を推定
// =============================================================================
// =============================================================================
// 業種キーの正規化 (2026-08-11 / 全結線計画 BLK-2)
// =============================================================================
/**
 * 業種辞書の slug を、法令判定が分岐に使うキーへ寄せる。
 *
 * 【なぜ要るか — 実測で確かめた欠陥】
 *   法令判定の分岐キーはカテゴリ単位 (construction / manufacturing / healthcare /
 *   professional / retail / food_service / finance) だが、業種辞書の名前は具体名の
 *   kebab-case (retail-pos / food-service / printing …) である。両者が一致しないため、
 *   業種辞書の名前でそのまま呼ぶと **既定の基本3法しか返らない**。しかも
 *   「該当法令なし」として画面に出るだけで、欠落したこと自体が表示されない。
 *     実測: applicableLawsFor('retail-pos') → 基本3法 / 'retail' → 景品表示法・特定商取引法を含む
 *           canIssueSimplified('retail-pos') → false (小売業なのに適格簡易請求書が発行できない判定)
 *
 * 【機械的に寄せてはいけない — 実測で確かめた反例】
 *   業種辞書の category 宣言を機械的に使うと誤る。
 *     ・veterinary-clinic の category は healthcare だが、動物病院に医療法・介護保険法は
 *       当たらない (獣医師法・獣医療法は本ライブラリに実装が無い)。
 *     ・retail-pos / food-service は category を宣言していない。
 *   よって本表は **根拠のあるものだけ** を1件ずつ載せる。載っていない業種は
 *   従来どおり既定 (基本3法) に落ちる = 挙動は変わらない。
 *
 * 【この表に足すときの条件】
 *   ① 業種辞書が自らその category を宣言している、または
 *   ② 返る法令が、その業種辞書の regulations に書かれた法令名・数値と一致することを
 *      実装を読んで確認した
 *   どちらも満たさないものを推測で足さない。足すと、その業種に無関係な法令が
 *   「該当法令」として顧客の画面に出る。
 */
const INDUSTRY_KEY_ALIASES: Record<string, string> = {
  // 小売POS: 景品表示法 (景品額の上限)・特定商取引法第11条の8項目・製造物責任法第5条の
  //   3年/10年・薬機法第36条の8/9の販売区分が、業種辞書の regulations の記載値と
  //   一致することを確認済 (2026-08-11)
  'retail-pos': 'retail',
  // 飲食: 食品衛生法の営業許可業種と食中毒24時間届出・食品表示法のアレルゲン義務8品目/
  //   推奨20品目/栄養5項目が実装に実在し、業種辞書の要求と一致することを確認済
  'food-service': 'food_service',
  // 印刷: 業種辞書が category=manufacturing を宣言。かつ下請法の条文・数値
  //   (第2条の資本金区分・第2条の2の60日・第3条の三条書面・第4条の禁止行為) が
  //   実装 API と逐語で対応することを確認済
  printing: 'manufacturing',
  // 産業廃棄物処理: 廃棄物処理法 (S45法律137) の産廃20種・特別管理の性状判定・
  //   12条の3のマニフェスト・14条の許可5年更新が実装に実在することを確認済
  'industrial-waste': 'industrial_waste',
};

/** 法令判定が実際に分岐するキー。★この集合と下の switch を必ず一致させること。 */
const KNOWN_INDUSTRY_KEYS = new Set([
  'construction', 'manufacturing', 'healthcare', 'professional',
  'retail', 'food_service', 'finance', 'industrial_waste',
]);

export function normalizeIndustryKey(industry: string): string {
  if (!industry) return industry;
  const raw = industry.trim();
  // ★2026-08-13 是正: 別名表の参照を小文字化していなかったため、'Retail-POS' は
  //   別名に当たらず既定 (基本3法) へ落ち、一方 'FOOD-SERVICE' は下の snake 化経路で
  //   正しく当たっていた。同じ大文字混在なのに寄せ先が別名か分岐キー本体かで結果が
  //   変わる不一致になっており、簡易課税セレクタ (slug を小文字化する) との間でも
  //   同じ業種名の判定が食い違っていた。
  const alias = INDUSTRY_KEY_ALIASES[raw.toLowerCase()];
  if (alias) return alias;
  // 表記ゆれだけの不一致 (kebab-case ↔ snake_case) は寄せる。
  //   ★寄せた先が実在する分岐キーのときだけ採用する。実在しないキーへ寄せると、
  //     既定へ落ちるのと同じでありながら「寄せた」ように見えて紛らわしい。
  const snake = raw.toLowerCase().replace(/-/g, '_');
  if (KNOWN_INDUSTRY_KEYS.has(snake)) return snake;
  return raw;
}

/** 正規化しても既定 (基本3法) に落ちる業種かどうか。画面での開示に使う。 */
export function fallsBackToBaseLaws(industry: string): boolean {
  return !KNOWN_INDUSTRY_KEYS.has(normalizeIndustryKey(industry));
}

export function recommendLaws(industry: string): string[] {
  const base = ['インボイス制度', '電子帳簿保存法', '個人情報保護法'];
  switch (normalizeIndustryKey(industry)) {
    case 'construction':
      // 建設業界コア3法 (建築士法/建築基準法/建設業法) + 拡張8法 (下請法/建築物省エネ法/都市計画法/耐震改修促進法/バリアフリー法/建設リサイクル法/住宅品質確保促進法/消防法) + 労基法.
      // 消防法は H3 で追加 (第17条 消防用設備等 + 第8条 防火管理者. 設備図・防火区画設計の前提法令).
      // 建築物省エネ法は 2025年4月改正で全新築 (原則 10 ㎡超) 適合義務化.
      // 各法令の条文番号・規模閾値・工程フェーズとの対応は construction-knowledge レーンに集約.
      return [
        ...base,
        '建築士法',
        '建築基準法',
        '建設業法',
        '下請法',
        '労働基準法',
        '建築物省エネ法',
        '都市計画法',
        '耐震改修促進法',
        'バリアフリー法',
        '建設リサイクル法',
        '住宅品質確保促進法',
        '消防法',
      ];
    case 'manufacturing':
      return [...base, '下請法', 'PL法', '労働基準法'];
    case 'healthcare':
      return [...base, 'マイナンバー法', '医療法', '介護保険法'];
    case 'professional':
      return [...base, 'マイナンバー法', '士業法', '労働基準法'];
    case 'retail':
      return [...base, '景品表示法', '特定商取引法'];
    case 'food_service':
      return [...base, '食品衛生法', '景品表示法'];
    case 'finance':
      return [...base, '金融商品取引法', '貸金業法', '資金決済法'];
    // ★2026-08-11 追加 (全結線計画 第3群)。lib/japan/waste.ts が廃棄物処理法
    //   (S45法律137) の産廃20種・特別管理の性状判定・12条の3のマニフェスト90日/180日・
    //   14条の許可5年更新を実装しており、業種辞書 industrial-waste の regulations と
    //   直接対応することを確認したうえで追加した。
    //   ★確認していない法令 (建設リサイクル法・フロン排出抑制法) はここに書かない。
    //     解体工事や第一種特定製品を扱うかは事業者ごとに異なり、一律に「該当法令」として
    //     出すと誤った義務を提示することになる。
    case 'industrial_waste':
      return [...base, '廃棄物処理法'];
    default:
      return base;
  }
}
