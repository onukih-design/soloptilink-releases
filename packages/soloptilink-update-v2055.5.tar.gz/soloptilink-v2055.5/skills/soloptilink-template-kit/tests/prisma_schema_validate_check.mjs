/**
 * soloptilink-template-kit / 生成 Prisma スキーマ実走検証ゲート
 * (2026-08-01 新設 — GATE-ID: TK-PRISMA-VALIDATE)
 *
 * ## 何を守るゲートか
 * 「kit を実際に展開し、出てきた prisma/schema.prisma に本物の `prisma validate` を掛ける」。
 *
 * ## なぜ要るのか (このゲートが無かったために起きた事故)
 * kits/medical_overlay.json は要配慮個人情報の暗号化を意図して独自型 `EncryptedString` を
 * 12 フィールドに宣言していたが、scaffolder 側に変換が実装されておらず、型名がそのまま
 * Prisma スキーマへ出ていた。Prisma に該当型は無いため、medical / medical_overlay の
 * 生成物は `prisma validate` が通らない状態だった。
 * 既存ゲートは kit JSON の静的検査と scaffolder のソース文字列検査までで、
 * **「展開して検証する」軸が 1 本も無かった**ため、今日まで検出されなかった。
 *
 * ## 両側判定 (born-passing 対策)
 * 健全側だけを見るゲートは「常に合格する飾り」になりうる。本ゲートは自分自身に
 * 欠陥注入を掛け、**欠陥キットで確かに不合格になること**を毎回実走で証明する。
 *   - 健全側: 実 kits/*.json 全件 → prisma validate PASS
 *   - 欠陥側 1: 未定義の独自型を持つ合成 kit → prisma validate FAIL を検出できる
 *   - 欠陥側 2: EncryptedString を持つ kit で暗号化実装が生成されない → 検出できる
 *
 * ## 未測定を合格にしない
 * typescript / prisma CLI が使えない環境では PASS を出さず、
 * 終了コード 2 (UNMEASURED) で「測っていない」ことを明示して落ちる。
 *
 * 実行: node tests/prisma_schema_validate_check.mjs
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync, writeFileSync, mkdirSync, rmSync, existsSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';

const require_ = createRequire(import.meta.url);
const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const WORK = join(tmpdir(), `tk-prisma-validate-${process.pid}`);

/** prisma validate は datasource の env() を解決するため DATABASE_URL を要求する。 */
const VALIDATE_ENV = {
  ...process.env,
  DATABASE_URL: 'postgresql://validate:validate@127.0.0.1:5432/validate',
};

// ---------------------------------------------------------------------------
// 前提ツールの実在確認 (無ければ「未測定」で落とす。合格にはしない)
// ---------------------------------------------------------------------------

function loadTypeScript() {
  const candidates = ['typescript'];
  try {
    const root = execFileSync('npm', ['root', '-g'], { encoding: 'utf8', timeout: 30000 }).trim();
    if (root) candidates.push(join(root, 'typescript'));
  } catch { /* npm 不在は下で扱う */ }
  for (const c of candidates) {
    try { return require_(c); } catch { /* 次の候補 */ }
  }
  return null;
}

function prismaCliAvailable() {
  try {
    execFileSync('npx', ['--no-install', 'prisma', '--version'],
      { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 120000 });
    return true;
  } catch { return false; }
}

const ts = loadTypeScript();
const prismaOk = ts ? prismaCliAvailable() : false;
if (!ts || !prismaOk) {
  const missing = [!ts && 'typescript', !prismaOk && 'prisma CLI'].filter(Boolean).join(' / ');
  console.error(`UNMEASURED: ${missing} が使えないため、生成 Prisma スキーマを検証できませんでした。`);
  console.error('このゲートは未測定を合格として記録しません。上記を用意してから再実行してください。');
  process.exit(2);
}

// ---------------------------------------------------------------------------
// 実 scaffolder のロード (再実装しない・本体 lib/*.ts をそのまま実行する)
// ---------------------------------------------------------------------------

function transpileLib(outDir) {
  mkdirSync(outDir, { recursive: true });
  for (const f of ['kit_loader.ts', 'scaffolder.ts', 'kit_overlay_resolver.ts', 'index.ts']) {
    const src = readFileSync(join(ROOT, 'lib', f), 'utf8');
    const js = ts.transpileModule(src, {
      compilerOptions: {
        module: ts.ModuleKind.ESNext,
        target: ts.ScriptTarget.ES2022,
        isolatedModules: true,
      },
      fileName: f,
    }).outputText.replace(/from '\.\/(kit_loader|scaffolder|kit_overlay_resolver)'/g, "from './$1.mjs'");
    writeFileSync(join(outDir, f.replace(/\.ts$/, '.mjs')), js, 'utf8');
  }
  return join(outDir, 'index.mjs');
}

rmSync(WORK, { recursive: true, force: true });
mkdirSync(WORK, { recursive: true });

/**
 * ★2026-08-06 (T-302) 是正: 測る対象を「このゲートの隣にある kits/」に固定する。
 *
 * それまでは lib/*.ts を一時ディレクトリへ transpile してから読み込んでいたため、
 * kit_loader.resolveKitsDir() の候補2 (ソースの 1 つ上の kits/) が一時ディレクトリを
 * 指して外れ、候補3 の ~/.claude/skills/soloptilink-template-kit/kits/ に落ちていた。
 * つまり **~/.soloptilink 側の kits を直しても、このゲートは配布ミラー側の古い kits を
 * 測って PASS を出していた** (2026-08-06 実測: EncryptedString を 28 フィールド足した
 * 直後の実行が 24/24 PASS のまま、暗号化ファイルの生成を一度も観測していなかった)。
 * 未測定が合格として記録される典型なので、明示的に固定する。
 */
// 呼出側が明示的に別ディレクトリを指定している場合はその意図を尊重する
// (両側判定で欠陥検体の kits/ を当てるときに必要)。指定が無いときだけ隣の kits/ に固定する。
const KITS_DIR = process.env.SOLOPTILINK_TEMPLATE_KIT_DIR || join(ROOT, 'kits');
if (!existsSync(KITS_DIR)) {
  console.error(`UNMEASURED: ${KITS_DIR} が存在しないため、kit を測れませんでした。`);
  process.exit(2);
}
process.env.SOLOPTILINK_TEMPLATE_KIT_DIR = KITS_DIR;
console.error(`[測定対象] kits = ${KITS_DIR}`);

const kitLib = await import(pathToFileURL(transpileLib(join(WORK, 'lib'))).href);

/** 実際に prisma validate を走らせる。{ ok, out } を返す。 */
function prismaValidate(schemaPath) {
  try {
    const out = execFileSync('npx', ['--no-install', 'prisma', 'validate', '--schema', schemaPath],
      { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 180000, env: VALIDATE_ENV });
    return { ok: true, out };
  } catch (e) {
    return { ok: false, out: `${e.stdout ?? ''}${e.stderr ?? ''}` };
  }
}

function walk(dir, acc = []) {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) walk(p, acc); else acc.push(p);
  }
  return acc;
}

/** kit を展開し、prisma validate の結果まで返す (このゲートの中核判定)。 */
function scaffoldAndValidate(kitId, label = kitId) {
  const target = join(WORK, 'out', label);
  const report = kitLib.scaffoldKit(kitId, target);
  const schema = join(target, 'prisma', 'schema.prisma');
  assert.ok(existsSync(schema), `${label}: prisma/schema.prisma が生成されていない`);
  const v = prismaValidate(schema);
  return { target, report, schema, valid: v.ok, output: v.out, files: walk(target).length };
}

const KIT_IDS = readdirSync(join(ROOT, 'kits'))
  .filter((f) => f.endsWith('.json'))
  .map((f) => f.replace(/\.json$/, ''))
  .sort();

// ===========================================================================
// 健全側: 実在する全 kit の生成 Prisma スキーマが prisma validate を通ること
// ===========================================================================

test('A-1: kits/ に kit が 1 件以上ある (検体ゼロで空回りしない)', () => {
  assert.ok(KIT_IDS.length >= 10, `kits/ の検体数が少なすぎる: ${KIT_IDS.length}`);
});

test('A-0: 測っている kits ディレクトリが本ゲートの隣にある (別拠点の古い kit を測っていない)', () => {
  // 2026-08-06 (T-302) 新設。ここが外れると「直したのに PASS のまま」という
  // 最も気づきにくい状態になる (実際に配布ミラー側を測っていた)。
  const resolved = kitLib.resolveKitsDir();
  assert.equal(resolved, KITS_DIR,
    `kit_loader が別のディレクトリを見ている: 解決先=${resolved} / 期待=${KITS_DIR}`);
  // 実際にそこから読めていること (パスが合っていても中身を読めなければ未測定)。
  const sample = kitLib.loadKitWithOverlay(KIT_IDS[0]);
  assert.equal(sample.kit_id, KIT_IDS[0], '解決先から kit を読み出せていない');
});

for (const kitId of KIT_IDS) {
  test(`A-2: ${kitId} — 展開した prisma/schema.prisma が prisma validate を通る`, () => {
    const r = scaffoldAndValidate(kitId);
    assert.ok(
      r.valid,
      `${kitId}: prisma validate 不合格\n${r.output.replace(/\x1b\[[0-9;]*m/g, '').slice(0, 1500)}`,
    );
  });
}

test('A-3: 生成された schema.prisma に Prisma 非対応の独自型が残っていない', () => {
  const KNOWN_SCALARS = new Set([
    'String', 'Boolean', 'Int', 'BigInt', 'Float', 'Decimal', 'DateTime', 'Json', 'Bytes', 'Unsupported',
  ]);
  for (const kitId of KIT_IDS) {
    const schemaPath = join(WORK, 'out', kitId, 'prisma', 'schema.prisma');
    const text = readFileSync(schemaPath, 'utf8');
    const declared = new Set(
      [...text.matchAll(/^(?:model|enum|type)\s+([A-Za-z0-9_]+)\s*\{/gm)].map((m) => m[1]),
    );
    const unknown = [];
    let inBlock = false;
    for (const line of text.split('\n')) {
      if (/^(model|enum|type)\s+/.test(line)) { inBlock = !/^enum\s+/.test(line); continue; }
      if (line.startsWith('}')) { inBlock = false; continue; }
      if (!inBlock) continue;
      const m = line.match(/^\s{2}([A-Za-z_][A-Za-z0-9_]*)\s+([A-Za-z_][A-Za-z0-9_]*)(\[\])?\??/);
      if (!m) continue;
      const type = m[2];
      if (!KNOWN_SCALARS.has(type) && !declared.has(type)) unknown.push(`${kitId}: ${m[1]} ${type}`);
    }
    assert.deepEqual(unknown, [], `未定義の型が Prisma スキーマに残っている: ${unknown.join(', ')}`);
  }
});

// ===========================================================================
// 欠陥側 1: 未定義の独自型を持つ kit を注入し、本ゲートが確かに落ちること
// ===========================================================================

function writeFixtureKit(dir, kitId, extraField) {
  mkdirSync(dir, { recursive: true });
  const kit = {
    kit_id: kitId,
    name_ja: '欠陥注入用フィクスチャ',
    name_en: 'defect injection fixture',
    industry: 'test',
    industry_ja: 'テスト',
    description: '両側判定のための欠陥注入用フィクスチャ kit。実運用では使用しない。',
    use_case: 'ゲートが欠陥を確かに検出することの実証専用。',
    stack: { framework: 'next', ui: 'tailwind', orm: 'prisma', db: 'postgres', auth: 'next-auth' },
    domain_dictionary_ref: 'soloptilink-japan/domains/test.json',
    applicable_laws: ['個人情報保護法', '医師法'],
    prisma_models: [
      { model: 'FixtureA', fields: [{ name: 'id', type: 'String', unique: true }, extraField] },
      { model: 'FixtureB', fields: [{ name: 'id', type: 'String', unique: true }, { name: 'code', type: 'String' }] },
      { model: 'FixtureC', fields: [{ name: 'id', type: 'String', unique: true }, { name: 'value', type: 'Int' }] },
    ],
    routes: [
      { path: '/dashboard', purpose: 'dashboard', type: 'dashboard' },
      { path: '/fixture-a', purpose: 'a list' },
      { path: '/fixture-b', purpose: 'b list' },
      { path: '/fixture-c', purpose: 'c list' },
      { path: '/api/fixture-a', purpose: 'a api' },
    ],
    report_templates: ['R1', 'R2'],
    dashboard_kpis: ['K1', 'K2'],
    estimated_completion_percent: 90,
    scaffold_outputs: { files_count: 20, lines_count_approx: 2000, estimated_setup_minutes: 3 },
  };
  writeFileSync(join(dir, `${kitId}.json`), JSON.stringify(kit, null, 2), 'utf8');
  return kit;
}

/** フィクスチャ kits/ ディレクトリを一時的に差し替えて実行する。 */
function withFixtureKitsDir(dir, fn) {
  const saved = process.env.SOLOPTILINK_TEMPLATE_KIT_DIR;
  process.env.SOLOPTILINK_TEMPLATE_KIT_DIR = dir;
  try { return fn(); } finally {
    if (saved === undefined) delete process.env.SOLOPTILINK_TEMPLATE_KIT_DIR;
    else process.env.SOLOPTILINK_TEMPLATE_KIT_DIR = saved;
  }
}

test('B-1: [欠陥注入] 未定義の独自型を持つ kit は prisma validate に落ち、本ゲートが検出する', () => {
  const dir = join(WORK, 'fixtures', 'undefined-type');
  // 名前は scaffolder の enum 推定ヒューリスティクスに当たらないものを選ぶ
  // (当たると自動で enum が生成され、欠陥が消えてしまう)
  writeFixtureKit(dir, 'fixture_broken', { name: 'secret', type: 'NoSuchScalar' });
  const r = withFixtureKitsDir(dir, () => scaffoldAndValidate('fixture_broken', 'fixture_broken'));

  assert.equal(r.valid, false, '欠陥注入した kit が prisma validate を通ってしまった (ゲートが機能していない)');
  const plain = r.output.replace(/\x1b\[[0-9;]*m/g, '');
  assert.match(plain, /NoSuchScalar/, 'prisma が未定義型を指摘していない');
  assert.match(plain, /is neither a built-in type/, '想定した検出理由ではない');
});

test('B-2: [欠陥注入] 健全な合成 kit は同じ経路で合格する (落ち方の作為が無いことの対照)', () => {
  const dir = join(WORK, 'fixtures', 'healthy');
  writeFixtureKit(dir, 'fixture_healthy', { name: 'secret', type: 'String' });
  const r = withFixtureKitsDir(dir, () => scaffoldAndValidate('fixture_healthy', 'fixture_healthy'));
  assert.ok(r.valid, `健全な合成 kit が落ちた (ゲートが常時 FAIL になっている)\n${r.output.slice(0, 800)}`);
});

// ===========================================================================
// EncryptedString: 設計意図 (要配慮個人情報の暗号化) が実装に到達しているか
// ===========================================================================

const CRYPTO_FILES = [
  'src/lib/crypto/encrypted-fields.ts',
  'src/lib/crypto/field-encryption.ts',
  'src/lib/crypto/prisma-encryption-extension.ts',
];

/**
 * EncryptedString を宣言している実 kit を列挙する。
 *
 * 判定は **overlay 適用後 (=実際に scaffold される姿)** で行う。生の kits/*.json を見ると
 * medical.json 自身は EncryptedString を持たないため、overlay 経由で暗号化フィールドが
 * 入る medical を取りこぼす (この取りこぼしは本ゲート作成時に実際に踏んだ)。
 */
function kitsWithEncryptedFields() {
  const hits = [];
  for (const kitId of KIT_IDS) {
    const kit = kitLib.loadKitWithOverlay(kitId);
    const models = Array.isArray(kit.prisma_models) ? kit.prisma_models : [];
    const n = models.reduce(
      (a, m) => a + (m.fields ?? []).filter((f) => f.type === 'EncryptedString').length, 0);
    if (n > 0) hits.push({ kitId, count: n, kit });
  }
  return hits;
}

test('C-1: EncryptedString を宣言した kit では暗号化実装が生成物に同梱される', () => {
  const hits = kitsWithEncryptedFields();
  assert.ok(hits.length > 0, 'EncryptedString を使う kit が 1 件も無い (検体ゼロで空回りしている)');
  for (const { kitId } of hits) {
    const target = join(WORK, 'out', kitId);
    for (const rel of CRYPTO_FILES) {
      assert.ok(existsSync(join(target, rel)), `${kitId}: ${rel} が生成されていない (暗号化の設計意図が未到達)`);
    }
    const db = readFileSync(join(target, 'src', 'lib', 'db.ts'), 'utf8');
    assert.match(db, /withFieldEncryption/, `${kitId}: db.ts が暗号化 Extension を通していない`);
    const env = readFileSync(join(target, '.env.example'), 'utf8');
    assert.match(env, /FIELD_ENCRYPTION_KEY/, `${kitId}: .env.example に鍵の設定手順が無い`);
  }
});

test('C-2: EncryptedString フィールドは Prisma 上 String になり、暗号文である旨が残る', () => {
  for (const { kitId, kit } of kitsWithEncryptedFields()) {
    const schema = readFileSync(join(WORK, 'out', kitId, 'prisma', 'schema.prisma'), 'utf8');
    assert.ok(!/\bEncryptedString\b/.test(schema), `${kitId}: schema.prisma に EncryptedString が残っている`);
    let checked = 0;
    for (const m of kit.prisma_models ?? []) {
      for (const f of (m.fields ?? []).filter((x) => x.type === 'EncryptedString')) {
        const re = new RegExp(`^\\s{2}${f.name}\\s+String\\b.*encrypted:true`, 'm');
        assert.match(schema, re, `${kitId}.${m.model}.${f.name}: String + encrypted:true 注記になっていない`);
        checked += 1;
      }
    }
    assert.ok(checked > 0, `${kitId}: 検査対象フィールドが 0 件`);
  }
});

test('C-3: 暗号化対象を持たない kit には暗号化ファイルを増やさない (既存生成物を太らせない)', () => {
  const encrypted = new Set(kitsWithEncryptedFields().map((h) => h.kitId));
  for (const kitId of KIT_IDS) {
    if (encrypted.has(kitId)) continue;
    for (const rel of CRYPTO_FILES) {
      assert.ok(!existsSync(join(WORK, 'out', kitId, rel)),
        `${kitId}: 暗号化対象が無いのに ${rel} が生成されている`);
    }
  }
});

test('C-4: [欠陥注入] EncryptedString を持つのに暗号化実装が出ない場合は C-1 が落ちる', () => {
  // scaffolder が EncryptedString を素通しした「事故当時の状態」を合成 kit で再現する。
  const dir = join(WORK, 'fixtures', 'encrypted');
  writeFixtureKit(dir, 'fixture_encrypted', { name: 'secret', type: 'EncryptedString' });
  const r = withFixtureKitsDir(dir, () => scaffoldAndValidate('fixture_encrypted', 'fixture_encrypted'));

  // 健全側: 現行実装なら valid かつ暗号化ファイルが揃う
  assert.ok(r.valid, `EncryptedString を含む合成 kit が prisma validate に落ちた\n${r.output.slice(0, 800)}`);
  for (const rel of CRYPTO_FILES) {
    assert.ok(existsSync(join(r.target, rel)), `${rel} が生成されていない`);
  }

  // 欠陥側: 暗号化ファイルを 1 本削ると C-1 と同じ判定が確かに落ちること
  const victim = join(r.target, CRYPTO_FILES[1]);
  rmSync(victim);
  assert.throws(
    () => {
      for (const rel of CRYPTO_FILES) {
        assert.ok(existsSync(join(r.target, rel)), `${rel} が生成されていない (暗号化の設計意図が未到達)`);
      }
    },
    /field-encryption\.ts/,
    '暗号化実装が欠けても検出できない (C-1 が飾りになっている)',
  );
});

test('C-5: 生成された暗号化実装が実走で往復する (平文が暗号文に置き換わることの実証)', async () => {
  const hits = kitsWithEncryptedFields();
  const { kitId, kit } = hits[0];
  const gen = join(WORK, 'out', kitId, 'src', 'lib', 'crypto');
  const runDir = join(WORK, 'crypto-run');
  mkdirSync(join(runDir, 'node_modules', '@prisma', 'client'), { recursive: true });
  writeFileSync(join(runDir, 'package.json'), JSON.stringify({ type: 'module' }), 'utf8');
  writeFileSync(join(runDir, 'node_modules', '@prisma', 'client', 'package.json'),
    JSON.stringify({ name: '@prisma/client', type: 'module', main: 'index.js' }), 'utf8');
  writeFileSync(join(runDir, 'node_modules', '@prisma', 'client', 'index.js'),
    'export const Prisma = { defineExtension: (x) => x };\nexport class PrismaClient {}\n', 'utf8');
  // blind index を宣言している kit では Extension が blind-index を import するため、
  // 一緒に持ち込まないとモジュール解決に失敗する (2026-08-06 / T-302)。
  const runFiles = ['encrypted-fields', 'field-encryption', 'prisma-encryption-extension'];
  if (existsSync(join(gen, 'blind-index.ts'))) runFiles.splice(2, 0, 'blind-index');
  for (const f of runFiles) {
    const js = ts.transpileModule(readFileSync(join(gen, `${f}.ts`), 'utf8'), {
      compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022, isolatedModules: true },
    }).outputText.replace(/from '\.\/(encrypted-fields|field-encryption|blind-index)'/g, "from './$1.js'");
    writeFileSync(join(runDir, `${f}.js`), js, 'utf8');
  }

  const fe = await import(pathToFileURL(join(runDir, 'field-encryption.js')).href);
  const ext = await import(pathToFileURL(join(runDir, 'prisma-encryption-extension.js')).href);

  const savedKey = process.env.FIELD_ENCRYPTION_KEY;
  const savedPepper = process.env.FIELD_ENCRYPTION_INDEX_PEPPER;
  // 索引の算出も走る kit があるため pepper を用意する (未設定だと索引側で例外になる)。
  process.env.FIELD_ENCRYPTION_INDEX_PEPPER = Buffer.alloc(32, 9).toString('base64');
  try {
    // 鍵未設定なら平文保存へ倒れず例外で止まること (fail-safe)
    delete process.env.FIELD_ENCRYPTION_KEY;
    assert.throws(() => fe.encryptField('要配慮個人情報'), /FIELD_ENCRYPTION_KEY/,
      '鍵未設定でも暗号化なしで通ってしまう (平文保存へ倒れている)');

    process.env.FIELD_ENCRYPTION_KEY = Buffer.alloc(32, 7).toString('base64');
    const PLAIN = '主訴: 胸痛。既往に狭心症あり。';
    const cipher = fe.encryptField(PLAIN);
    assert.ok(fe.isEncrypted(cipher), '暗号文の形式になっていない');
    assert.ok(!cipher.includes(PLAIN), '暗号文に平文が残っている');
    assert.equal(fe.decryptField(cipher), PLAIN, '往復で元の平文に戻らない');
    assert.notEqual(fe.encryptField(PLAIN), fe.encryptField(PLAIN), '同一平文の暗号文が固定 (IV が乱数でない)');

    // Extension が DB へ渡る直前に暗号化していること
    const model = (kit.prisma_models ?? []).find((m) => (m.fields ?? []).some((f) => f.type === 'EncryptedString'));
    const field = model.fields.find((f) => f.type === 'EncryptedString').name;
    let seen;
    const out = await ext.fieldEncryptionExtension.query.$allModels.$allOperations({
      model: model.model,
      operation: 'create',
      args: { data: { [field]: PLAIN } },
      query: async (a) => { seen = a; return { ...a.data }; },
    });
    assert.ok(fe.isEncrypted(seen.data[field]), 'DB へ渡る値が平文のまま');
    assert.equal(out[field], PLAIN, '読み出し時に復号されていない');
  } finally {
    if (savedKey === undefined) delete process.env.FIELD_ENCRYPTION_KEY;
    else process.env.FIELD_ENCRYPTION_KEY = savedKey;
    if (savedPepper === undefined) delete process.env.FIELD_ENCRYPTION_INDEX_PEPPER;
    else process.env.FIELD_ENCRYPTION_INDEX_PEPPER = savedPepper;
  }
});

// ===========================================================================
// blind index: 暗号化列の完全一致検索が「宣言だけ」で終わっていないか
// (2026-08-06 / T-302 新設。宣言はあるのに索引を算出する実装が無く、
//  氏名を暗号化した瞬間に氏名検索が黙って 0 件になる状態を防ぐ)
// ===========================================================================

const BLIND_INDEX_FILE = 'src/lib/crypto/blind-index.ts';

/** blind_index_of を宣言している実 kit を列挙する (overlay 適用後の姿で判定)。 */
function kitsWithBlindIndex() {
  const hits = [];
  for (const kitId of KIT_IDS) {
    const kit = kitLib.loadKitWithOverlay(kitId);
    const pairs = [];
    for (const m of kit.prisma_models ?? []) {
      for (const f of m.fields ?? []) {
        if (f.blind_index_of) pairs.push({ model: m.model, index: f.name, source: f.blind_index_of });
      }
    }
    if (pairs.length > 0) hits.push({ kitId, kit, pairs });
  }
  return hits;
}

test('C-6: blind index を宣言した kit では索引の算出実装が生成物に同梱される', () => {
  const hits = kitsWithBlindIndex();
  assert.ok(hits.length > 0, 'blind_index_of を使う kit が 1 件も無い (検体ゼロで空回りしている)');
  for (const { kitId, kit, pairs } of hits) {
    const target = join(WORK, 'out', kitId);
    assert.ok(existsSync(join(target, BLIND_INDEX_FILE)),
      `${kitId}: ${BLIND_INDEX_FILE} が生成されていない (検索できると書いてあるのに検索できない状態)`);
    const bi = readFileSync(join(target, BLIND_INDEX_FILE), 'utf8');
    for (const p of pairs) {
      assert.match(bi, new RegExp(`index: '${p.index}', source: '${p.source}'`),
        `${kitId}: ${p.model}.${p.index} の宣言が生成物へ写っていない`);
      // 索引の元列は暗号化されている前提 (平文列への索引は宣言ミス)
      const src = (kit.prisma_models ?? []).find((m) => m.model === p.model)
        ?.fields.find((f) => f.name === p.source);
      assert.equal(src?.type, 'EncryptedString',
        `${kitId}: ${p.model}.${p.source} は EncryptedString ではない (暗号化していない列への blind index)`);
    }
    // 索引を埋める側 (Extension) が実際に blind-index を呼んでいること
    const ext = readFileSync(join(target, 'src', 'lib', 'crypto', 'prisma-encryption-extension.ts'), 'utf8');
    assert.match(ext, /from '\.\/blind-index'/, `${kitId}: Extension が blind-index を取り込んでいない`);
    assert.match(ext, /applyBlindIndex/, `${kitId}: Extension が索引の算出を呼んでいない (置くだけになっている)`);
    // 鍵手順が利用者に届いていること
    assert.match(readFileSync(join(target, '.env.example'), 'utf8'), /FIELD_ENCRYPTION_INDEX_PEPPER/,
      `${kitId}: .env.example に pepper の設定手順が無い`);
    assert.match(readFileSync(join(target, 'README.md'), 'utf8'), /blind index/,
      `${kitId}: README に検索方式の説明と制約が無い`);
  }
});

test('C-7: blind index が実走で機能する (書込で索引が埋まり、同じ語で引ける)', async () => {
  const { kitId } = kitsWithBlindIndex()[0];
  const gen = join(WORK, 'out', kitId, 'src', 'lib', 'crypto');
  const runDir = join(WORK, 'bix-run');
  mkdirSync(join(runDir, 'node_modules', '@prisma', 'client'), { recursive: true });
  writeFileSync(join(runDir, 'package.json'), JSON.stringify({ type: 'module' }), 'utf8');
  writeFileSync(join(runDir, 'node_modules', '@prisma', 'client', 'package.json'),
    JSON.stringify({ name: '@prisma/client', type: 'module', main: 'index.js' }), 'utf8');
  writeFileSync(join(runDir, 'node_modules', '@prisma', 'client', 'index.js'),
    'export const Prisma = { defineExtension: (x) => x };\nexport class PrismaClient {}\n', 'utf8');
  for (const f of ['encrypted-fields', 'field-encryption', 'blind-index', 'prisma-encryption-extension']) {
    const js = ts.transpileModule(readFileSync(join(gen, `${f}.ts`), 'utf8'), {
      compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022, isolatedModules: true },
    }).outputText.replace(/from '\.\/(encrypted-fields|field-encryption|blind-index)'/g, "from './$1.js'");
    writeFileSync(join(runDir, `${f}.js`), js, 'utf8');
  }
  const bi = await import(pathToFileURL(join(runDir, 'blind-index.js')).href);
  const ext = await import(pathToFileURL(join(runDir, 'prisma-encryption-extension.js')).href);

  const savedKey = process.env.FIELD_ENCRYPTION_KEY;
  const savedPepper = process.env.FIELD_ENCRYPTION_INDEX_PEPPER;
  try {
    // 欠陥側 1: pepper 未設定で索引を作れてしまわないこと (ハッシュ無しで保存へ倒れない)
    delete process.env.FIELD_ENCRYPTION_INDEX_PEPPER;
    assert.throws(() => bi.blindIndex('小貫'), /FIELD_ENCRYPTION_INDEX_PEPPER/,
      'pepper 未設定でも索引が作れてしまう (fail-open している)');

    process.env.FIELD_ENCRYPTION_KEY = Buffer.alloc(32, 7).toString('base64');
    process.env.FIELD_ENCRYPTION_INDEX_PEPPER = Buffer.alloc(32, 9).toString('base64');

    // 健全側: 書込みで索引が自動で埋まり、同じ語の索引と一致する
    const model = Object.keys(bi.BLIND_INDEX_FIELDS)[0];
    const pair = bi.BLIND_INDEX_FIELDS[model][0];
    const PLAIN = '小貫';
    let seen;
    const out = await ext.fieldEncryptionExtension.query.$allModels.$allOperations({
      model,
      operation: 'create',
      args: { data: { [pair.source]: PLAIN } },
      query: async (a) => { seen = a; return { ...a.data }; },
    });
    assert.ok(!String(seen.data[pair.source]).includes(PLAIN), '元列が平文のまま DB へ渡っている');
    assert.equal(typeof seen.data[pair.index], 'string', '索引列が埋まっていない (検索が常に 0 件になる)');
    assert.equal(out[pair.source], PLAIN, '読み出し時に復号されていない');
    const where = bi.blindIndexWhere(model, pair.source, PLAIN);
    assert.equal(where[pair.index], seen.data[pair.index], '検索用の索引が書込値と一致しない (完全一致で引けない)');
    // 正規化 (前後空白・全角半角) を通しても同じ索引になること
    assert.equal(bi.blindIndex(` ${PLAIN} `), seen.data[pair.index], '正規化が効いていない');
    // 欠陥側 2: 別の平文が同じ索引にならないこと (索引が定数化していない)
    assert.notEqual(bi.blindIndex('澁澤'), seen.data[pair.index], '異なる平文が同じ索引になっている');
    // 欠陥側 3: 宣言の無い列で検索しようとしたら止まること (暗号文への一致検索へ黙って落ちない)
    assert.throws(() => bi.blindIndexWhere(model, '__no_such_field__', 'x'), /blind index/,
      '宣言の無い列でも where を組めてしまう');
  } finally {
    if (savedKey === undefined) delete process.env.FIELD_ENCRYPTION_KEY;
    else process.env.FIELD_ENCRYPTION_KEY = savedKey;
    if (savedPepper === undefined) delete process.env.FIELD_ENCRYPTION_INDEX_PEPPER;
    else process.env.FIELD_ENCRYPTION_INDEX_PEPPER = savedPepper;
  }
});

test('C-8: [欠陥注入] blind index の宣言不整合は生成を止める / 宣言の無い kit は太らせない', () => {
  // 欠陥側 A: 実在しない列を指す宣言 → scaffold が例外で止まること
  //   (黙って読み飛ばすと「索引列は空のまま・検索は常に 0 件」の生成物が出荷される)
  const dirA = join(WORK, 'fixtures', 'bix-broken');
  mkdirSync(dirA, { recursive: true });
  writeFixtureKit(dirA, 'fixture_bix_broken', { name: 'secret', type: 'EncryptedString' });
  {
    const p = join(dirA, 'fixture_bix_broken.json');
    const k = JSON.parse(readFileSync(p, 'utf8'));
    k.prisma_models[0].fields.push({ name: 'secretIndex', type: 'String', blind_index_of: 'noSuchColumn' });
    writeFileSync(p, JSON.stringify(k, null, 2), 'utf8');
  }
  assert.throws(
    () => withFixtureKitsDir(dirA, () => kitLib.scaffoldKit('fixture_bix_broken', join(WORK, 'out', 'fixture_bix_broken'))),
    /blind_index_of/,
    '実在しない列への blind index 宣言でも生成が通ってしまう (検索が黙って壊れる)',
  );

  // 欠陥側 B: 暗号化列が 1 つも無いのに blind index だけ宣言 → 止まること
  const dirB = join(WORK, 'fixtures', 'bix-orphan');
  mkdirSync(dirB, { recursive: true });
  writeFixtureKit(dirB, 'fixture_bix_orphan', { name: 'secret', type: 'String' });
  {
    const p = join(dirB, 'fixture_bix_orphan.json');
    const k = JSON.parse(readFileSync(p, 'utf8'));
    k.prisma_models[0].fields.push({ name: 'secretIndex', type: 'String', blind_index_of: 'secret' });
    writeFileSync(p, JSON.stringify(k, null, 2), 'utf8');
  }
  assert.throws(
    () => withFixtureKitsDir(dirB, () => kitLib.scaffoldKit('fixture_bix_orphan', join(WORK, 'out', 'fixture_bix_orphan'))),
    /EncryptedString/,
    '暗号化列が無いのに blind index だけ宣言した kit が通ってしまう',
  );

  // 健全側 (対照): 宣言の無い kit に blind-index.ts を増やさない
  const declared = new Set(kitsWithBlindIndex().map((h) => h.kitId));
  for (const kitId of KIT_IDS) {
    if (declared.has(kitId)) continue;
    assert.ok(!existsSync(join(WORK, 'out', kitId, BLIND_INDEX_FILE)),
      `${kitId}: blind index の宣言が無いのに ${BLIND_INDEX_FILE} が生成されている`);
  }
});

// ===========================================================================
// C-9: 通電を「取り消す」退行を捕まえる床 (2026-08-06 / T-302 新設)
//
// C-1〜C-8 の母集団は「EncryptedString を宣言した kit」である。つまり宣言そのものを
// String へ戻すと、その kit は母集団から消えて全軸が素通りする。
// ★2026-08-06 実測: dispensing_pharmacy / home_nursing の宣言を String へ戻した検体で
//   C-1〜C-8 は 1 件も落ちなかった。宣言に依存しない床が無いと、通電の取り消しは検出できない。
// ここでは母集団を宣言から独立に決める。
// ===========================================================================

/**
 * 要配慮個人情報を扱うため暗号化の宣言が必須の kit と、その最低フィールド数。
 *
 * 更新してよい場合: kit を新設した / 設計判断で対象を増やした (数を増やす方向)。
 * 減らす場合は **理由をここに日本語で残すこと** (減らせてしまうと床の意味が消える)。
 *  - 2026-08-06 (T-302) 初版。medical_overlay=12 / dispensing_pharmacy=13 / home_nursing=15。
 *    dispensing_pharmacy は Patient.birthDate を対象から外したため 14 ではなく 13
 *    (owner 判断: 暗号化すると年齢集計・範囲検索・並べ替えが不能になるため)。
 */
const MUST_ENCRYPT_KITS = {
  medical_overlay: 12,
  dispensing_pharmacy: 13,
  home_nursing: 15,
};

test('C-9: 要配慮個人情報を扱う kit の暗号化宣言が減っていない (通電の取り消しを捕まえる床)', () => {
  const counts = new Map(kitsWithEncryptedFields().map((h) => [h.kitId, h.count]));
  const shortfalls = [];
  for (const [kitId, floor] of Object.entries(MUST_ENCRYPT_KITS)) {
    if (!KIT_IDS.includes(kitId)) continue; // kit 自体が無い環境は対象外 (下で開示)
    const n = counts.get(kitId) ?? 0;
    if (n < floor) shortfalls.push(`${kitId}: 実測 ${n} < 床 ${floor}`);
  }
  assert.deepEqual(shortfalls, [],
    `要配慮個人情報の暗号化宣言が床を下回った (通電が取り消されている): ${shortfalls.join(' / ')}`);

  const missingKits = Object.keys(MUST_ENCRYPT_KITS).filter((k) => !KIT_IDS.includes(k));
  assert.deepEqual(missingKits, [],
    `床に登録した kit が kits/ に存在しない (登録漏れか kit 削除): ${missingKits.join(', ')}`);
});

test('C-10: kit が自ら宣言した encrypted_fields リストと実際の型宣言が一致する', () => {
  // dispensing_pharmacy のように機械可読な「暗号化要件リスト」を持つ kit では、
  // リストと prisma_models の型が食い違うと「要件は書いたが実装していない」状態になる。
  // 2026-08-05 まで実際にその状態だった (リスト 14 件 / 実装 0 件)。
  const findList = (obj) => {
    if (Array.isArray(obj)) { for (const v of obj) { const r = findList(v); if (r) return r; } return null; }
    if (obj && typeof obj === 'object') {
      if (Array.isArray(obj.encrypted_fields)) return obj.encrypted_fields;
      for (const v of Object.values(obj)) { const r = findList(v); if (r) return r; }
    }
    return null;
  };
  let checkedKits = 0;
  const mismatches = [];
  for (const kitId of KIT_IDS) {
    const kit = kitLib.loadKitWithOverlay(kitId);
    const list = findList(kit);
    if (!list || list.length === 0) continue;
    checkedKits += 1;
    for (const entry of list) {
      const [mn, fn] = String(entry).split('.');
      const f = (kit.prisma_models ?? []).find((m) => m.model === mn)?.fields.find((x) => x.name === fn);
      if (!f) { mismatches.push(`${kitId}: ${entry} が prisma_models に無い`); continue; }
      if (f.type !== 'EncryptedString') mismatches.push(`${kitId}: ${entry} が ${f.type} のまま (要件だけで未実装)`);
    }
  }
  assert.ok(checkedKits > 0, 'encrypted_fields を持つ kit が 1 件も無い (検体ゼロで空回りしている)');
  assert.deepEqual(mismatches, [], `暗号化要件リストと実装が食い違っている: ${mismatches.join(' / ')}`);
});

test('Z: 一時ディレクトリの後始末', () => {
  rmSync(WORK, { recursive: true, force: true });
  assert.ok(!existsSync(WORK));
});
