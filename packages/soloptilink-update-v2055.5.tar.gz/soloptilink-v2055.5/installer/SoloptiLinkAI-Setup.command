#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI — Mac ダブルクリック起動インストーラ (.command)
# =============================================================================
# 顧客は Finder からこのファイルをダブルクリックするだけで:
#   1. Terminal.app が自動起動
#   2. 同梱パッケージ本体を ~/.soloptilink へ配置 (自己完結ZIP)
#      ※ 本体が無い場合のみ tar.gz / ネットワークから自動取得
#   3. アーキ(arm64/Intel)に合った Go ランチャーを配置
#   4. Claude Desktop の MCP サーバー設定を自動登録
#   5. 端末認証 (--activate) を自動チェーン
#   6. 完了画面まで自動誘導
#
# 配布レイアウト対応:
#   現行の per-platform ZIP (SoloptiLinkAI_vX.Y_Mac-*.zip) は
#   「展開済みパッケージ本体 + soloptilink バイナリ + この .command」が
#   同一フォルダに並ぶ自己完結キット。本スクリプトはそのレイアウトを
#   第一に検出して動作する (旧 .command は tar.gz 同梱前提で現行ZIPでは
#   動かなかった)。tar.gz 同梱キット / ネットワーク取得にもフォールバックする。
#
# Compliance:
#   - PFP-029 (cmd 窓即閉じ事案) 同等の堅牢設計: STEP マーカー / END_PAUSE 必須
#   - PFP-044 (AppleDouble 事案) AppleDouble セルフクリーンアップ
#   - PFP-101 (0 バイト取得事案) ネットワーク取得は -L で 302 追従 / updates/check 経由
#   - macOS Gatekeeper 対応: xattr -d com.apple.quarantine で隔離属性除去
# =============================================================================
set -e
# 失敗時に Terminal を即閉じさせない (お客様が次の一手を読めるように)
# ★従来はここで行番号・終了コード・失敗したコマンド文字列を
#   そのまま画面に出していた。お客様には意味が伝わらず、何をすればよいかも
#   分からない行き止まりになっていた (顧客可視出力の方針にも反する)。
#   画面には「起きたこと」と「次にすること」だけを日本語で出し、
#   調査に要る技術的な内容は控えのファイルへ回す。
trap '_EC=$?; _CMD="$BASH_COMMAND"; _LN=$LINENO; _LOGD="$HOME/.soloptilink/logs"; mkdir -p "$_LOGD" 2>/dev/null || _LOGD="${TMPDIR:-/tmp}"; printf "%s installer-failure line=%s exit=%s cmd=%s\n" "$(date +%Y-%m-%dT%H:%M:%S)" "$_LN" "$_EC" "$_CMD" >> "$_LOGD/setup-error.log" 2>/dev/null || true; _RPT="$HOME/.soloptilink/lib/cognitive/customer-error-reporter.sh"; [ -f "$_RPT" ] && bash "$_RPT" "installer-failure" "Mac .command セットアップ失敗 line=$_LN exit=$_EC cmd=$_CMD" 2>/dev/null; echo ""; echo "==============================================================="; echo " ⚠️  予期しない問題が発生しました"; echo ""; echo "     セットアップを最後まで進められませんでした。"; echo "     この画面の写真を撮って、"; echo "     assist@soloptilink.com までお送りください。"; echo "     こちらで原因をお調べして、ご連絡いたします。"; echo ""; echo "     お急ぎの場合も、まずはこの画面の写真をお送りください。"; echo "==============================================================="; echo "[Enterキーで閉じます]"; read -r _; exit 1' ERR

clear 2>/dev/null || true
KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
TS=$(date +%Y%m%d_%H%M%S)
API_BASE="https://admin.soloptilink.com/api/v1"

cat <<'BANNER'

  ╔════════════════════════════════════════════════════════════════╗
  ║         SoloptiLinkAI Setup (Mac版)                            ║
  ║         自動セットアップを開始します                          ║
  ║         (このウィンドウは自動で進みます。閉じずにお待ちください) ║
  ╚════════════════════════════════════════════════════════════════╝

BANNER

# ---------------------------------------------------------------------------
# STEP 0/6: 管理者端末の保護 (この .command は顧客用インストーラ)
# ---------------------------------------------------------------------------
if [ -f "$HOME/.soloptilink/.admin_mode" ]; then
    echo "  ⚠️  この端末は SoloptiLinkAI 管理者端末です。"
    echo "      顧客用インストーラの実行は中止しました (開発環境を保護)。"
    echo ""
    echo "[Enterキーで閉じます]"
    read -r _
    exit 0
fi

# ---------------------------------------------------------------------------
# STEP 1/6: macOS Gatekeeper 隔離属性の除去 (ダウンロードファイル特有)
# ---------------------------------------------------------------------------
echo "[STEP 1/6] セキュリティ属性のクリーンアップ"
find "$KIT_DIR" -name "*.command" -exec xattr -d com.apple.quarantine {} \; 2>/dev/null || true
find "$KIT_DIR" -name "*.sh" -exec xattr -d com.apple.quarantine {} \; 2>/dev/null || true
xattr -dr com.apple.quarantine "$KIT_DIR" 2>/dev/null || true
echo "  ✅ 完了"
echo ""

# ---------------------------------------------------------------------------
# STEP 2/6: AppleDouble (._*) / .DS_Store の除去 (PFP-044)
# ---------------------------------------------------------------------------
echo "[STEP 2/6] macOS メタデータの除去"
find "$KIT_DIR" -name '._*' -delete 2>/dev/null || true
find "$KIT_DIR" -name '.DS_Store' -delete 2>/dev/null || true
echo "  ✅ 完了"
echo ""

# ---------------------------------------------------------------------------
# [前提ソフト] Git / Node.js / Claude Code の確認と導入 (本体配置に先立って)
#   利用に必要な前提ソフトを、SoloptiLink 本体の配置の前に自動導入する。
#   各ソフトは「先に検出し、在ればスキップ」する冪等設計 (再実行しても無害)。
#     - Claude Code : 公式ネイティブインストーラ (curl | bash) で導入 (sudo不要・背景自動更新)
#     - Node.js     : 生成される業務システムの実行・ビルド検証に必要 (Claude Code 自体は Node 不要)
#     - Git         : SoloptiLink の bash 製 lib / chain.sh の動作に必要 (macOS は通常導入済み)
#   ★失敗しても中断しない: このフェーズだけ set +e で ERR トラップを抑止し、
#     未完了は「要対応」へ集約して完了画面で案内する (Windows 版と対称)。
# ---------------------------------------------------------------------------
echo "[前提ソフト] Git / Node.js / Claude Code を確認・導入"
# ★実行順の注意 (T-017a):
#   この前提ソフト工程は STEP 3 (既存環境の退避) より前に走る。Node 自動導入モジュールは
#   ③経路のとき ~/.soloptilink/runtime/node/ へ Node 本体を展開するため、
#   「既存環境の有無」をここで先に確定しておかないと、
#   【いま自動導入が作ったばかりの ~/.soloptilink】を STEP 3 が「既存環境」と誤認して
#   退避してしまい、新規導入なのに .bak が出来て Node も一緒に消える。
HAD_EXISTING_SOLOPTILINK=0
if [ -d "$HOME/.soloptilink" ]; then HAD_EXISTING_SOLOPTILINK=1; fi
PREREQ_ISSUES=()
add_issue() { PREREQ_ISSUES+=("$1|$2"); }   # "項目|対処"
set +e   # このフェーズは失敗しても中断しない
# ★実走で判明した落とし穴: set +e だけでは ERR トラップは止まらない
#   (bash では errexit と ERR トラップは別の仕組み)。この工程で外部コマンドが 1 つでも
#   非ゼロで終わると、「失敗しても中断しない」という宣言に反して異常終了画面が出る。
#   そのため、この工程の外部コマンドはすべて || で受けて ERR トラップの発火条件から外す。

# 公式ネイティブ Claude Code は ~/.local/bin に入るため、現セッション PATH へ前置き
export PATH="$HOME/.local/bin:$PATH"

# --- 前提ソフトの判定 (実行可否ベースの判定) --------------------------------
#   【この判定が必要な理由】判定が command -v (存在確認) だけで、
#     「実際に動くか」を見ていなかった。macOS は開発ツール (Command Line Tools) が
#     未導入でも /usr/bin/git ・ /usr/bin/python3 が【入口 (シム) として実在する】ため、
#     command -v は成功し、実行すると失敗する。実際の導入画面には
#       [skip] Git ()            ← 版数が空 = 存在するが動かない動かぬ証拠
#       xcode-select: No developer tools were found
#     が出ており、この状態で Node 判定まで巻き込まれて「Node.js を用意できませんでした」
#     と誤報告する経路があった。
#   【方針】存在確認だけで合格にしない。版数の取得まで実行し、期待する形の出力が
#     返ったときにだけ「使える」と判定する。Windows 側 (soloptilink-install.ps1) は
# 先に同じ規律で是正済みで、本変更は Mac 側をそれに揃えるもの。
#   【判定は 3 値】absent (入口ごと無い) / present_but_broken (入口はあるが動かない) /
#     available (実際に動く)。この 3 値を区別しないと、お客様に出す案内文が
#     「導入してください」に丸まり、既に入っているものを入れ直させることになる。
prereq_probe() {
    # $1 = コマンド名 / $2 = 版数取得の引数 / $3 = 期待する版数の形 (grep -E のパターン)
    # 標準出力: absent | present_but_broken | available
    # 標準エラー: 何も出さない (呼び出し側が表示を決める)
    local _cmd="$1" _verarg="$2" _pat="$3" _out=""
    command -v "$_cmd" >/dev/null 2>&1 || { printf 'absent'; return 0; }
    _out="$("$_cmd" "$_verarg" 2>/dev/null | head -1 | tr -d '\r')" || _out=""
    if [ -z "$_out" ]; then printf 'present_but_broken'; return 0; fi
    if printf '%s' "$_out" | grep -Eq "$_pat"; then
        PREREQ_VER="$_out"; printf 'available'; return 0
    fi
    printf 'present_but_broken'; return 0
}
# 開発ツール未導入は Git / Python 3 に同時に効くため、案内は 1 回だけ出す
DEVTOOLS_PROMPTED=0
prompt_devtools() {
    [ "$DEVTOOLS_PROMPTED" = "1" ] && return 0
    DEVTOOLS_PROMPTED=1
    xcode-select --install >/dev/null 2>&1 || true
}
DEVTOOLS_ISSUE="画面に表示される『コマンドラインデベロッパツール』の導入を完了してください (Git と Python 3 が含まれます)。導入が終わったら、この .command をもう一度ダブルクリックしてください。導入は途中まで完了しています"

# --- Git (macOS は Command Line Tools 同梱で通常導入済み) ---
PREREQ_VER=""
case "$(prereq_probe git --version 'git version [0-9]')" in
    available)
        echo "  [skip] Git ($PREREQ_VER)" ;;
    present_but_broken)
        # 入口はあるが動かない = 開発ツールが未導入。「未導入」と同じ案内にしない
        echo "  Git: 開発ツールの導入が必要です (コマンドはありますが実行できません)"
        prompt_devtools
        add_issue "Git" "$DEVTOOLS_ISSUE" ;;
    *)
        echo "  Git: 未導入 → コマンドラインデベロッパツールの導入を案内します"
        prompt_devtools
        add_issue "Git" "$DEVTOOLS_ISSUE" ;;
esac

# --- Node.js (v18 以上) — 自動導入モジュール AC-I06 への結線 (T-017a) ---
#   【この実装が必要な理由】ここは長らく「既存 node があれば skip → brew があれば brew install →
#     brew が無ければ自動導入をスキップして nodejs.org を手動案内」だった。
#     同梱している installer/lib/node-provision.sh (公式 tar.xz をユーザー領域へ展開する
#     ③経路を実装済み) を【一度も呼んでいなかった】= 呼出元ゼロの死配線。
#     その結果、brew 不在の端末では自動導入が発火せず、公式 pkg インストーラの
#     「★PCのパスワード」入力で顧客の手が止まる 74 分事案の経路がそのまま残っていた。
#     配布物に同梱されていることは build-update-package.sh の HARDGATE が毎回守っていたため、
#     「入っているから直った」と誤認しやすい状態だった。
#   【この結線の役割】判定順 (①既存 ②brew ③公式tar.xz展開) と SHA-256 照合・kill-switch は
#     すべてモジュール側が実装済みなので、ここは薄い結線に留める:
#       モジュールを読み込む → node_provision_ensure → 結果 verdict を add_issue へ流す。
#     モジュールが見つからない場合に旧 brew 経路へ黙って戻さないこと。戻すと
#     「部品が落ちても従来どおり動く」= 死配線に戻ったことを誰も検出できなくなる。
NODE_PROVISION_SH=""
for _np_cand in \
    "$KIT_DIR/installer/lib/node-provision.sh" \
    "$KIT_DIR/lib/node-provision.sh" \
    "$HOME/.soloptilink/installer/lib/node-provision.sh"; do
    if [ -f "$_np_cand" ]; then NODE_PROVISION_SH="$_np_cand"; break; fi
done
if [ -n "$NODE_PROVISION_SH" ]; then
    # shellcheck disable=SC1090
    . "$NODE_PROVISION_SH"
    node_provision_ensure || true
    # 当社の現セッション PATH にのみ前置き (~/.zshrc は書き換えない)
    node_provision_path_prepend >/dev/null 2>&1 || true
    case "${NODE_PROVISION_VERDICT:-}" in
        PASS)
            echo "  ✅ Node.js: 使える状態です (${NODE_PROVISION_VERSION:-版数不明})" ;;
        WARN)
            echo "  ⚠️  Node.js: 使えますが確認事項があります"
            add_issue "Node.js" "${NODE_PROVISION_ISSUE_JA:-Node.js の状態に確認事項があります。assist@soloptilink.com へご連絡ください}" ;;
        not_applicable)
            echo "  ℹ️  Node.js: このパソコンでは自動導入の対象外です"
            add_issue "Node.js" "このパソコンの種類では Node.js の自動導入に対応していません。https://nodejs.org/ja から LTS 版を導入してください" ;;
        "")
            # 【T-03 /  是正】判定そのものが返らなかった場合。
            #   この事象への対処。
            #   ここが空になった。従来はこの空が下の「用意できませんでした」に落ち、
            #   さらに案内文まで既定値に置き換わって【既に入っている Node.js を
            #   入れ直してください】という誤案内が出た。お客様は打つ手を失う。
            #   「用意できなかった」と「判定できなかった」は、お客様が取るべき行動が違う。
            #   判定不能は判定不能として出し、既定の導入案内へ落とさない。
            if [ -n "${NODE_PROVISION_VERSION:-}" ]; then
                echo "  ⚠️  Node.js: 導入済みですが状態を確認できませんでした (${NODE_PROVISION_VERSION})"
            else
                echo "  ⚠️  Node.js: 状態を判定できませんでした"
            fi
            add_issue "Node.js" "Node.js の状態を判定できませんでした。開発ツール (コマンドラインデベロッパツール) が未導入の場合は、その導入を終えてからこの .command をもう一度実行してください。解消しない場合は assist@soloptilink.com へご連絡ください (Node.js を入れ直す必要はありません)" ;;
        *)
            echo "  ⚠️  Node.js: 自動で用意できませんでした (要対応一覧に集約します)"
            add_issue "Node.js" "${NODE_PROVISION_ISSUE_JA:-https://nodejs.org/ja から LTS 版を導入してください}" ;;
    esac
else
    echo "  ⚠️  Node.js: 自動導入に必要な部品が見つかりません"
    add_issue "Node.js" "自動導入に必要な部品が配布物の中に見当たりません。ZIP をもう一度展開し直してから再実行するか、assist@soloptilink.com へご連絡ください"
fi

# --- Claude Code (公式ネイティブインストーラ = sudo 不要・背景自動更新) ---
if command -v claude >/dev/null 2>&1; then
    echo "  [skip] Claude Code ($(claude --version 2>/dev/null | head -1))"
else
    echo "  Claude Code: 未導入 → 公式ネイティブインストーラで導入します (自動更新あり)"
    curl -fsSL https://claude.ai/install.sh | bash >/dev/null 2>&1 || true
    export PATH="$HOME/.local/bin:$PATH"
    if command -v claude >/dev/null 2>&1; then
        echo "  ✅ Claude Code 導入完了 ($(claude --version 2>/dev/null | head -1))"
    else
        add_issue "Claude Code" "自動導入に失敗しました。ネットワーク(社内プロキシ/オフライン)をご確認のうえ再実行するか、assist@soloptilink.com へご連絡ください"
    fi
fi

# --- Python 3 (T-702 新設) ---
#   【なぜここに足したか / 実測】
#     このインストーラ自身が STEP 6 で Claude Desktop の設定を python3 で書き換え、
#     生成物の品質点検も 138 本中 107 本が python3 を呼ぶ。つまり導入の前提なのに、
#     お客様向けの手順書 7 本すべてに記載が 0 件で、前提ソフトの確認対象にも
#     入っていなかった (実測)。
#     python3 が無い状態で同じ組み立て (set -e + ERR トラップ + python3 のヒアドキュメント)
#     を走らせると、終了コード 127 で ERR トラップが発火し、導入がそこで止まる。
#     実際の品質点検も、判定が全て「-」になり合否を出せなくなることを実走で確認した。
#   【方針】自動導入はしない (Apple の開発ツール導入は同意画面を伴い、無人では進まない)。
#     ここでは検出だけ行い、無い場合は導入の案内を「要対応」へ集約する。
#   ★macOS には python3 の「入口」が開発ツール未導入でも実在する。
#     コマンドがあることだけを見ると入っている扱いになるため、版の表示まで確かめる
#     (Windows 側の python3.exe = ストアへ誘導するだけの入口と同じ構造)。
PREREQ_VER=""
case "$(prereq_probe python3 --version 'Python 3\.')" in
    available)
        echo "  [skip] Python 3 ($PREREQ_VER)" ;;
    present_but_broken)
        echo "  Python 3: 開発ツールの導入が必要です (コマンドはありますが実行できません)"
        prompt_devtools
        add_issue "Python 3" "$DEVTOOLS_ISSUE。導入せずに進めると、Claude Desktop の設定登録と、生成した業務システムの品質点検が行えません" ;;
    *)
        echo "  Python 3: 未導入 → 開発ツール一式の導入を案内します"
        prompt_devtools
        add_issue "Python 3" "$DEVTOOLS_ISSUE。導入せずに進めると、Claude Desktop の設定登録と、生成した業務システムの品質点検が行えません" ;;
esac

set -e   # 以降は通常のエラー検出に戻す
echo ""

# ---------------------------------------------------------------------------
# STEP 3/6: 既存環境のバックアップ
# ---------------------------------------------------------------------------
echo "[STEP 3/6] 既存環境のバックアップ"
if [ "$HAD_EXISTING_SOLOPTILINK" -eq 1 ] && [ -d "$HOME/.soloptilink" ]; then
    BK="$HOME/.soloptilink.bak.$TS"
    echo "  すでに入っているものを控えとして取っておきます"
    mv "$HOME/.soloptilink" "$BK"
    echo "  ✅ 控えを取りました (元に戻したいときは、この控えを使って戻せます)"
else
    echo "  既存環境なし (新規インストール)"
fi
mkdir -p "$HOME/.soloptilink"

# ── 再インストール時の認証引継ぎ (PFP-119) ──
# 退避した旧環境から認証系3ファイル (端末認証 activation.json / 端末識別
# .device_identity.json / ライセンスキャッシュ license.json) を新環境へ
# 自動コピー戻しし、再インストール後の再認証 (--activate やり直し) を不要にする。
# 配布物にはこれらの認証ファイルが含まれないため、後続の本体配置で上書きされない。
AUTH_CARRIED=0
if [ -n "${BK:-}" ] && [ -d "${BK:-}" ]; then
    for AUTH_FILE in activation.json .device_identity.json license.json; do
        if [ -f "$BK/$AUTH_FILE" ]; then
            if cp -p "$BK/$AUTH_FILE" "$HOME/.soloptilink/$AUTH_FILE" 2>/dev/null; then
                AUTH_CARRIED=$((AUTH_CARRIED+1))
            fi
        fi
    done
fi
if [ "$AUTH_CARRIED" -gt 0 ]; then
    echo "  ✅ 認証情報は引き継ぎました (再認証は不要です)"
fi

# ── Node ランタイムと導入記録の引継ぎ (T-017a) ──
# 前提ソフト工程で自動導入した Node 本体 (runtime/node/) と、その判定記録
# (var/node-provision-*) は退避先に入ってしまう。同じ絶対パスへ戻さないと
# runtime/node/env.sh が指す先が消え、せっかく導入した Node が使えなくなる。
# 退避元は消さない (コピーで戻す = 元に戻せる状態を保つ)。
if [ -n "${BK:-}" ] && [ -d "${BK:-}" ]; then
    if [ -d "$BK/runtime/node" ]; then
        mkdir -p "$HOME/.soloptilink/runtime" 2>/dev/null || true
        cp -R "$BK/runtime/node" "$HOME/.soloptilink/runtime/" 2>/dev/null || true
    fi
    for NP_FILE in node-provision-results.json node-provision-refiner.json node-provision.log; do
        if [ -f "$BK/var/$NP_FILE" ]; then
            mkdir -p "$HOME/.soloptilink/var" 2>/dev/null || true
            cp -p "$BK/var/$NP_FILE" "$HOME/.soloptilink/var/$NP_FILE" 2>/dev/null || true
        fi
    done
fi
echo ""

# ---------------------------------------------------------------------------
# STEP 4/6: パッケージ本体の配置 (自己完結ZIP → tar.gz → ネットワークの順)
# ---------------------------------------------------------------------------
echo "[STEP 4/6] SoloptiLinkAI 本体を配置中..."

if [ -f "$KIT_DIR/chain.sh" ] && [ -d "$KIT_DIR/lib" ]; then
    # ── モードA: 自己完結ZIP (現行 per-platform ZIP の既定レイアウト) ──
    echo "  自己完結キットを検出 (展開済みパッケージ本体)"
    # この .command 自身と Mac専用補助ファイルは除外して本体をコピー
    ( cd "$KIT_DIR" && \
      find . -mindepth 1 -maxdepth 1 \
        ! -name 'SoloptiLinkAI-Setup.command' \
        ! -name 'はじめに_Mac.txt' \
        ! -name '.DS_Store' \
        -exec cp -R {} "$HOME/.soloptilink/" \; )
    echo "  ✅ 本体の配置が完了しました"
else
    # ── モードB: tar.gz 同梱キット ──
    PAYLOAD_TGZ=$(ls "$KIT_DIR"/../soloptilink-update-v*.tar.gz "$KIT_DIR"/soloptilink-update-v*.tar.gz 2>/dev/null | sort -V | tail -1)
    if [ -n "$PAYLOAD_TGZ" ] && [ -f "$PAYLOAD_TGZ" ]; then
        echo "  オフライン配布物を検出: $(basename "$PAYLOAD_TGZ")"
        tar xzf "$PAYLOAD_TGZ" -C "$HOME/.soloptilink" --strip-components=1
        echo "  ✅ 展開完了"
    else
        # ── モードC: ネットワーク取得 (最終手段 / PFP-101: -L で302追従) ──
        echo "  本体が見つからないため、ネットワーク経由で取得します..."
        # HTTP status と本文を分離取得。stderr は退避して顧客可視に出さない。
        _NET_TMP=$(mktemp -t solai_net.XXXXXX 2>/dev/null || echo "/tmp/solai_net.$$")
        _NET_ERR="${_NET_TMP}.err"
        HTTP_CODE=$(curl -sSL --max-time 30 -o "$_NET_TMP" -w "%{http_code}" \
            "$API_BASE/updates/check?version=0&os=darwin&arch=$(uname -m | sed 's/x86_64/amd64/')" \
            2>"$_NET_ERR" || echo "000")
        LATEST_JSON=$(cat "$_NET_TMP" 2>/dev/null || echo "")
        TAR_URL=$(echo "$LATEST_JSON" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('package_url') or '')" 2>/dev/null || echo "")
        rm -f "$_NET_TMP" "$_NET_ERR" 2>/dev/null || true
        if [ -z "$TAR_URL" ]; then
            echo ""
            echo "  ⚠️  本体を取得できませんでした。"
            if [ "$HTTP_CODE" = "000" ]; then
                echo "      インターネットに接続できていない可能性があります。"
                echo "      Wi-Fi や有線接続、社内プロキシ / VPN の設定をご確認のうえ、"
                echo "      再度 SoloptiLinkAI-Setup.command を実行してください。"
            elif [ "$HTTP_CODE" -ge 500 ] 2>/dev/null; then
                echo "      配信サーバー側で一時的な問題が発生している可能性があります (応答コード: $HTTP_CODE)。"
                echo "      数分おいて再度実行してください。解消しない場合は下記までご連絡ください。"
            elif [ "$HTTP_CODE" -ge 400 ] 2>/dev/null; then
                echo "      配信サーバーへのアクセスが許可されていません (応答コード: $HTTP_CODE)。"
                echo "      ご契約状況の確認が必要な可能性があります。下記までご連絡ください。"
            elif [ "$HTTP_CODE" = "200" ]; then
                echo "      配信情報の読み取りに失敗しました (応答: $HTTP_CODE / 本体パッケージ URL 未指定)。"
                echo "      配信側の準備が完了していない可能性があります。下記までご連絡ください。"
            else
                echo "      配信サーバーから想定外の応答を受け取りました (応答コード: $HTTP_CODE)。"
                echo "      下記までご連絡ください。"
            fi
            echo ""
            echo "      連絡先: assist@soloptilink.com"
            echo "      お手数ですが上記の応答コードを本文にお書き添えください。"
            exit 1
        fi
        echo "  ダウンロード: $TAR_URL"
        curl -fsSL --max-time 300 -o "$HOME/.soloptilink/_latest.tar.gz" "$TAR_URL"
        tar xzf "$HOME/.soloptilink/_latest.tar.gz" -C "$HOME/.soloptilink" --strip-components=1
        rm -f "$HOME/.soloptilink/_latest.tar.gz"
        echo "  ✅ ダウンロード+展開完了"
    fi
fi

# AppleDouble 再除去 + 実行権限付与
find "$HOME/.soloptilink" -name '._*' -delete 2>/dev/null || true
find "$HOME/.soloptilink" -name '.DS_Store' -delete 2>/dev/null || true
chmod +x "$HOME/.soloptilink"/chain.sh 2>/dev/null || true
chmod +x "$HOME/.soloptilink"/*.sh 2>/dev/null || true
echo ""

# ---------------------------------------------------------------------------
# STEP 5/6: Goランチャーの配置 (アーキ自動判定)
# ---------------------------------------------------------------------------
echo "[STEP 5/6] Goランチャーを配置"
ARCH=$(uname -m)
case "$ARCH" in
    arm64)  LAUNCHER_NAME="soloptilink-darwin-arm64" ;;
    x86_64) LAUNCHER_NAME="soloptilink-darwin-amd64" ;;
    *) echo "  ⚠️  未対応のアーキ: $ARCH"; exit 1 ;;
esac

if [ -f "$HOME/.soloptilink/soloptilink" ]; then
    # 自己完結ZIP は arch 専用バイナリを soloptilink として同梱済み
    :
elif [ -f "$KIT_DIR/$LAUNCHER_NAME" ]; then
    cp "$KIT_DIR/$LAUNCHER_NAME" "$HOME/.soloptilink/soloptilink"
elif [ -f "$KIT_DIR/Mac/$LAUNCHER_NAME" ]; then
    cp "$KIT_DIR/Mac/$LAUNCHER_NAME" "$HOME/.soloptilink/soloptilink"
else
    LAUNCHER_URL="https://github.com/onukih-design/soloptilink-releases/releases/latest/download/${LAUNCHER_NAME}"
    echo "  ダウンロード: $LAUNCHER_URL"
    curl -fsSL --max-time 120 -o "$HOME/.soloptilink/soloptilink" "$LAUNCHER_URL"
fi
chmod +x "$HOME/.soloptilink/soloptilink"
xattr -d com.apple.quarantine "$HOME/.soloptilink/soloptilink" 2>/dev/null || true
echo "  ✅ アーキ: $ARCH 用バイナリを配置"
echo ""

# ---------------------------------------------------------------------------
# STEP 5.5/6: 自動更新フックの登録 (更新が自動で届かない状態を防ぐ)
# ---------------------------------------------------------------------------
# 【鶏卵デッドロックの解消】従来、自動更新フック (~/.claude/settings.json) を
# 登録するのは移行スクリプト 1本だけで、それを呼ぶのは「フックで起動される
# auto-update.sh 自身」だった。そのため新規導入時は誰もフックを登録せず、
# 一度も手動更新しない限り自動更新が永遠に始まらなかった。
# → 導入のこの瞬間にフックを登録し、自動更新の点火を保証する。冪等。
echo "[STEP 5.5/6] 自動更新を有効化"
_HOOK_OK=0
# ★「登録を実行した」ではなく「登録が効いた」で判定する。
#   【この実装が必要な理由】従来は登録コマンドの終了コードだけを見て成功としていた。
#   これは今日の前提ソフト事案とまったく同じ誤り (実行したことと、効いたことを混同する)。
#   登録が効いていないまま「以降は自動で最新版を取得します」と表示すると、
#   お客様は更新されていることを前提に使い続け、何世代も古いまま気づけない。
#   実際 一部の環境で導入・更新が完了しない事象が確認されたため。
#   そこで登録後に設定ファイルを実際に読み、自動更新の登録が入っているかを確かめる。
#   ★この確認は python3 を使わない (開発ツール未導入の端末でも必ず動く必要があるため)。
_hook_is_registered() {
    local _st="$HOME/.claude/settings.json"
    [ -f "$_st" ] || return 1
    # 自動更新の登録行が実在するかだけを見る (整形の違いに強い素朴な検索)
    grep -q 'auto-update.sh' "$_st" 2>/dev/null || return 1
    grep -q 'SessionStart' "$_st" 2>/dev/null || return 1
    return 0
}
# 第一経路: ランチャー経由の冪等登録 (全OS共通・テスト済みの単一実装・python3 非依存)
if [ -x "$HOME/.soloptilink/soloptilink" ]; then
    "$HOME/.soloptilink/soloptilink" --register-autoupdate-hook >/dev/null 2>&1 || true
    _hook_is_registered && _HOOK_OK=1
fi
# 第二経路 (保険): 移行スクリプト直接実行
if [ "$_HOOK_OK" -eq 0 ] && [ -f "$HOME/.soloptilink/migration/v2027_hook_install.sh" ]; then
    bash "$HOME/.soloptilink/migration/v2027_hook_install.sh" >/dev/null 2>&1 || true
    _hook_is_registered && _HOOK_OK=1
fi
# ★メニュー(スキル)の修復フックも登録する。
#   【この実装が必要な理由】このフックは「顧客端末で毎回確実に動く経路は自分だけである」と
#   自ら宣言しているのに、顧客の設定へ登録する処理が本体のどこにも存在しなかった
#   (全数検索してヒットしたのは同梱リスト・存在検査・資産台帳だけで、登録は 0 件)。
#   そのため、メニューが古い版のまま取り残されても直る機会が無く、
#   さらにこのフックだけが呼び出し元である「新しい版が出ています」の通知も
#   顧客端末で一度も出ていなかった。一部の環境で導入・更新が完了しない事象が確認されたため。
#   15 世代前の版が出続けたのは、この経路が繋がっていなかったためでもある。
#   ★python3 を使わずに登録する (開発ツール未導入の端末でも必ず動く必要があるため)。
_SKILL_HEAL="$HOME/.soloptilink/lib/hooks/session-start-skill-heal.sh"
_ST_JSON="$HOME/.claude/settings.json"
if [ -f "$_SKILL_HEAL" ] && [ -f "$_ST_JSON" ]; then
    if ! grep -q 'session-start-skill-heal.sh' "$_ST_JSON" 2>/dev/null; then
        # 自動更新の登録行に相乗りする形で 1 行だけ足す (既存の構造を壊さない)
        _tmp_st="$_ST_JSON.tmp.$$"
        sed 's|\(bash [^"]*auto-update\.sh\)|\1\&\& bash ~/.soloptilink/lib/hooks/session-start-skill-heal.sh >/dev/null 2>\&1 \|\| true|' \
            "$_ST_JSON" > "$_tmp_st" 2>/dev/null
        # 壊れた設定を残さない: 書けた場合のみ差し替え、登録できたかを必ず確かめる
        if [ -s "$_tmp_st" ] && grep -q 'session-start-skill-heal.sh' "$_tmp_st" 2>/dev/null; then
            cp "$_ST_JSON" "$_ST_JSON.bak.$TS" 2>/dev/null || true
            mv "$_tmp_st" "$_ST_JSON" 2>/dev/null || rm -f "$_tmp_st" 2>/dev/null
        else
            rm -f "$_tmp_st" 2>/dev/null || true
        fi
    fi
fi

if [ "$_HOOK_OK" -eq 1 ]; then
    echo "  ✅ 以降 Claude Code 起動時に自動で最新版を取得します (登録を確認済み)"
else
    # ★従来の案内は「チャット欄に『最新版にして』とお伝えください」
    #   だったが、これは効かない。チャットの中からは設定ファイルを書き換えられない
    #   仕組み (自己改変の防止) になっており、お客様が案内どおりにしても状況が変わらない。
    #   実際に効く手段だけを案内する。
    echo "  ⚠️  自動更新の設定を完了できませんでした (このままだと最新版が自動で届きません)"
    echo "      お手数ですが、この画面のあとに表示される案内に沿って"
    echo "      『コマンドラインデベロッパツール』の導入を完了し、"
    echo "      もう一度このセットアップをダブルクリックしてください。"
    echo "      解消しない場合は [REDACTED:EMAIL] へご連絡ください (端末の状態を確認します)。"
    add_issue "自動更新" "自動更新の設定が完了していません。このままでは最新版が自動で届きません。『コマンドラインデベロッパツール』の導入を終えてから、このセットアップをもう一度実行してください。解消しない場合は [REDACTED:EMAIL] までご連絡ください"
fi

# ---------------------------------------------------------------------------
# STEP 5.6/6: 品質・信頼性フックの登録
# ---------------------------------------------------------------------------
# 【この実装が必要な理由】ここで名指しで実行していたのは v2027 (自動更新) の1本だけだった。
#   そのため v2027 以降に追加された遡及配線 (品質ゲート・エラーゼロ化4本柱の結線層など) は
#   【新規導入の端末に一度も適用されない】。実測で、4本柱の結線層 7エントリが顧客端末の
#   ~/.claude/settings.json に一つも入っていないことが判明した (開発機でしか動いていなかった)。
#   名指し列挙は「今後増えるもの」を必ず取りこぼす構造なので、ここは列挙をやめて
#   migration/ 配下の全スクリプトを実行する (各スクリプトが自前で冪等性を保証している)。
echo "[STEP 5.6/6] 品質・信頼性フックを登録"
_MIG_N=0
if [ -d "$HOME/.soloptilink/migration" ]; then
    for _mig in "$HOME/.soloptilink/migration/"v*.sh; do
        [ -f "$_mig" ] || continue
        # v2027 は直前で実行済み (二重実行しても冪等だが、無駄な処理を避ける)
        case "$_mig" in *v2027_hook_install.sh) continue ;; esac
        bash "$_mig" >/dev/null 2>&1 || true
        _MIG_N=$((_MIG_N + 1))
    done
fi
if [ "$_MIG_N" -gt 0 ]; then
    echo "  ✅ 品質・信頼性の自動チェックを有効化しました (${_MIG_N} 項目)"
else
    echo "  ℹ️  追加で有効化する項目はありませんでした"
fi
echo ""

# ---------------------------------------------------------------------------
# STEP 6/6: Claude Desktop MCP 設定 + 端末認証起動
# ---------------------------------------------------------------------------
# ★見出しの「MCP」はお客様には通じない内部用語だった
echo "[STEP 6/6] Claude Desktop との連携設定 + 端末の登録"

CLAUDE_CONFIG="$HOME/Library/Application Support/Claude/claude_desktop_config.json"
mkdir -p "$(dirname "$CLAUDE_CONFIG")"
if [ -f "$CLAUDE_CONFIG" ]; then
    cp "$CLAUDE_CONFIG" "$CLAUDE_CONFIG.bak.$TS"
    echo "  既存 claude_desktop_config.json をバックアップ: $CLAUDE_CONFIG.bak.$TS"
fi

# python3 で安全に MERGE (既存 mcpServers を保持)
# ★python3 が無い場合の扱い (T-702)
#   従来はここで終了コード 127 になり、ERR トラップが発火して導入が丸ごと中断していた。
#   その結果、直後にある端末認証まで到達できず、お客様は登録すらできないまま終わる。
#   設定の書き換えは「検査」ではなく「作業」なので、行えなかった事実を要対応へ
#   集約したうえで、端末認証へは進む (前提ソフト工程と同じ fail-open の作法)。
# ★ここも「在るか」ではなく「動くか」で判定する。
#   開発ツール未導入の macOS では python3 の入口だけが実在するため、
#   存在確認だけだと先へ進んでしまい、設定の書き込みが途中で失敗する。
if ! { command -v python3 >/dev/null 2>&1 && python3 --version >/dev/null 2>&1; }; then
    echo "  ⚠️  Claude Desktop への登録は行えませんでした (Python 3 がこの端末で動きません)"
    # ★従来は「ターミナルで xcode-select --install」とだけ書いていた。
    #   ターミナルを開いたことがないお客様はここで手が止まる (行き止まり)。
    #   前提ソフトの工程で Apple の導入画面をすでに呼び出しているので、まずその画面を
    #   案内し、画面が出ていない場合だけ、開く場所と貼り付ける内容を1文字ずつ示す。
    add_issue "Claude Desktop への登録" "$(cat <<'PY3ISSUE'
Python 3 を導入したあと、このファイルをもう一度ダブルクリックしてください。
Python 3 の入れかた:
  1. 画面に『コマンドラインデベロッパツールをインストールしますか?』という
     Apple の確認画面が出ていれば、[インストール] を押して終わるまでお待ちください
     (Python 3 はこの中に含まれます)。
  2. その画面が見当たらないときは、画面上部のメニューから
     [移動] → [ユーティリティ] → [ターミナル] を開き
     (Finder のサイドバーからは アプリケーション → ユーティリティ → ターミナル)、
     下の1行をそのままコピーして貼り付け、Enter キーを押してください。
       xcode-select --install
     そのあとに出る Apple の確認画面で [インストール] を押してください。
  3. 終わったら、このファイルをもう一度ダブルクリックしてください。
うまくいかないときは assist@soloptilink.com までご連絡ください。
PY3ISSUE
)"
else
SOLOPTILINK_BIN="$HOME/.soloptilink/soloptilink" python3 - "$CLAUDE_CONFIG" <<'PYEOF'
import json, sys, os
cfg_path = sys.argv[1]
bin_path = os.environ['SOLOPTILINK_BIN']
if os.path.exists(cfg_path) and os.path.getsize(cfg_path) > 0:
    try:
        with open(cfg_path) as f:
            cfg = json.load(f)
    except Exception:
        cfg = {}
else:
    cfg = {}
cfg.setdefault('mcpServers', {})
cfg['mcpServers']['soloptilink'] = {'command': bin_path, 'args': ['--mcp-server']}
with open(cfg_path, 'w') as f:
    json.dump(cfg, f, indent=2, ensure_ascii=False)
# ★「MCP サーバー」はお客様には通じない内部用語だった
print("  ✅ Claude Desktop との連携を登録しました")
PYEOF
fi

# ★すでに登録済みなら、入力を求めずに飛ばす。
#   【なぜ要るか】案内はどれも「もう一度ダブルクリックしてください」で終わるが、
#   Mac 側にはこの事前確認が無かったため、再実行するたびに必ず入力待ちへ戻っていた。
#   お客様が席を離れていると、そこで止まったまま完了しない (申告①の「放置したが
#   完了しなかった」に直結する)。Windows 側には同等の確認が実装済みで、
#   これも Mac だけが取り残されていた片側実装である。
cd "$HOME/.soloptilink"
_ALREADY_REGISTERED=0
if [ -x "$HOME/.soloptilink/soloptilink" ]; then
    _st_out="$(./soloptilink --status 2>&1 || true)"
    case "$_st_out" in
        *承認済み*|*登録済み*|*承認待ち*) _ALREADY_REGISTERED=1 ;;
    esac
fi
# STEP 3 で既存環境から認証情報を引き継いだ場合も、登録は済んでいる
if [ "${AUTH_CARRIED:-0}" -gt 0 ]; then _ALREADY_REGISTERED=1; fi

if [ "$_ALREADY_REGISTERED" -eq 1 ]; then
    echo ""
    echo "  ✅ この端末はすでに登録済みです (入力は不要です)"
    echo ""
else

echo ""
echo "  端末認証を開始します。メールアドレスの入力を求められます。"
echo ""
sleep 2

# 端末認証を自動チェーン
# 承認待ちポーリング(最大30分)はインストーラ内では行わない
# (登録だけ行い即座に完了画面へ。承認後は自動で有効になる)。
SOLOPTILINK_ACTIVATE_NO_WAIT=1 ./soloptilink --activate || {
    # ★従来はここに打ち込むコマンドを並べていたが、
    #   ターミナルを使わないお客様には実行できない案内だった。
    #   もう一度ダブルクリックすれば同じ登録がやり直せるので、それだけを案内する。
    # ★ここで打ち切らない。
    #   【この実装が必要な理由】従来はここで導入そのものを終了していた。そのため、
    #   前提ソフトの工程が積み上げた「要対応一覧」も、導入の自己診断も、完了画面も
    #   一つも表示されないまま終わっていた。お客様の画面には「登録できませんでした」
    #   だけが残り、他に何が終わっていて何が残っているのかが分からない。
    #   Windows 側は同じ場面で続行し、要対応をまとめて出してから終わる。
    #   ここも同じ形に揃え、最後まで進んでから未完了をまとめてお伝えする。
    echo ""
    echo "  ⚠️  ご登録が完了しませんでした (この後の案内をあわせてご確認ください)"
    echo ""
    add_issue "端末の登録" "端末のご登録が完了していません。インターネット接続をご確認のうえ、このファイルをもう一度ダブルクリックしてください (二重に登録されることはありません)。解消しない場合は、この画面の写真を撮って assist@soloptilink.com までお送りください"
    ACTIVATION_FAILED=1
}
fi   # ★T-3: 登録済み事前確認の分岐ここまで

# ---------------------------------------------------------------------------
# 完了画面
# ---------------------------------------------------------------------------
cat <<'DONE'

  ╔════════════════════════════════════════════════════════════════╗
  ║                                                                ║
  ║      ✅ SoloptiLinkAI セットアップ完了！                        ║
  ║                                                                ║
  ╚════════════════════════════════════════════════════════════════╝

  次のステップ:

    1. Claude Desktop / Claude Code を一度終了して、再起動してください
       (SoloptiLinkAI との連携を読み込むため)

    2. 起動後、チャット欄に /soloptilink-boost と入力し、
       続けてお仕事の内容をそのままお伝えください

DONE

# ★例示とご利用開始の案内は正典 (lib/onboarding-canon.sh) から取り出して表示する
#   (T-703 / T-706)。ここに文面を書き写すと、手順書・同梱案内・
#   ランチャーの案内と必ずどこか 1 箇所だけが古くなる。実測でも、手順書 3 本は
#   「最大で1〜2営業日」、この完了画面は「通常1営業日以内」と食い違っていた。
_OBC="$HOME/.soloptilink/lib/onboarding-canon.sh"
if [ -f "$_OBC" ]; then
    bash "$_OBC" emit starter 2>/dev/null | sed 's/^/    /' || true
    echo ""
    bash "$_OBC" emit wait 2>/dev/null | sed 's/^/    /' || true
else
    echo "    ご利用開始のタイミングは、同梱の手順書をご覧ください。"
fi

# ★従来はここに打ち込むコマンドを 1 行そのまま出していた
#   (ステータス確認: cd ~/.soloptilink && ./soloptilink --status)。ターミナルを
#   開いたことのないお客様には実行できず、「自分の端末が使える状態か」を自力で
#   確かめる手段が無くなっていた。ご登録の状態を確かめる道順は正典 (上の
#   「ご利用開始のタイミングについて」) が持っているので、ここでは書き写さない。
cat <<'DONE'

  サポート: assist@soloptilink.com

DONE

# 動作確認 (各前提ソフトのバージョンを実測表示)
echo "  ── 動作確認 ──"
export PATH="$HOME/.local/bin:$PATH"
for c in git node npm claude python3; do
    if command -v "$c" >/dev/null 2>&1; then
        printf "    [ OK ] %-7s: %s\n" "$c" "$($c --version 2>/dev/null | head -1)"
    else
        printf "    [要対応] %-7s: 確認できません (再起動後に再確認してください)\n" "$c"
    fi
done
echo ""

# ---------------------------------------------------------------------------
# 導入自己診断 (AC-I08) — 「最後まで走った」ではなく「診断が通った」を完了とする
# ---------------------------------------------------------------------------
# 【何が壊れていたか (T-017e)】installer/self-check.sh は 12 項目の自己診断を
#   実装し配布物にも同梱されているのに、Mac/Windows どちらのインストーラからも
#   呼ばれていなかった (呼出元は社内テストの台帳行と同梱必須リストだけ)。
#   そのため従来の完了画面は「セットアップが最後まで走った」ことしか示さず、
#   スキル未配置・フック未登録のまま「完了」と表示していた。
# 【契約】診断は fail-open。× があってもここで導入を中断しない (要対応一覧へ集約する)。
#   無効化: SOLOPTILINK_SELF_CHECK=off (診断側が「無効化した事実」を記録して終了する)
SELF_CHECK_SH=""
for _sc_cand in \
    "$HOME/.soloptilink/installer/self-check.sh" \
    "$KIT_DIR/installer/self-check.sh" \
    "$KIT_DIR/self-check.sh"; do
    if [ -f "$_sc_cand" ]; then SELF_CHECK_SH="$_sc_cand"; break; fi
done
if [ -n "$SELF_CHECK_SH" ]; then
    echo "  ── 導入の自己診断 ──"
    # ★ERR トラップの落とし穴:
    #   set +e は ERR トラップを抑止しない (bash では errexit と ERR トラップは別物)。
    #   診断が × を返した瞬間に「エラーが発生しました」の異常終了画面が出て、
    #   せっかく印字した診断結果の意味が顧客に伝わらなくなる。
    #   || で受けることで ERR トラップの発火条件から外し、rc だけを回収する。
    SELF_CHECK_RC=0
    bash "$SELF_CHECK_SH" run || SELF_CHECK_RC=$?
    if [ "$SELF_CHECK_RC" -ne 0 ]; then
        add_issue "導入の自己診断" "診断で確認が必要な項目が見つかりました。上の診断結果に表示された「お客様がすること」を実施してから、もう一度このファイルをダブルクリックしてください"
    fi
    echo ""
else
    echo "  ⚠️  導入の自己診断を実施できませんでした (診断の部品が見つかりません)"
    add_issue "導入の自己診断" "自己診断に必要な部品が配布物の中に見当たりません。ZIP をもう一度展開し直してから再実行するか、assist@soloptilink.com へご連絡ください"
fi

# 前提ソフトの要対応一覧 (自動完了できなかったもの)
if [ "${#PREREQ_ISSUES[@]}" -gt 0 ]; then
    echo "  【要対応】以下は自動で完了できませんでした:"
    # 対処が複数行になる項目 (手順つきの案内) は 2 行目以降も字下げして読めるようにする
    for it in "${PREREQ_ISSUES[@]}"; do
        printf '    ・%s: %s\n' "${it%%|*}" "${it#*|}" | sed '2,$s/^/      /'
    done
    echo "    ※ まず上記を解消してから、次のステップへお進みください。"
    echo ""
fi

# Claude Code ログインと有料プランの注意
# ★従来は「またはターミナルで claude」と併記していたが、
#   打ち込む場所も手順も書かれておらず、Claude Desktop を使わないお客様が
#   そこで止まっていた。画面上で完結する Claude Desktop の道順だけを案内する。
echo "  ── Claude Code のログイン ──"
echo "    初回のみログインが必要です。Claude Desktop を起動し、画面の案内にしたがって"
echo "    ログインしてください (すでにログイン済みの場合はそのままお使いいただけます)。"
echo "    ※ ご利用には有料の Claude プラン (Pro / Max / Team / Enterprise) または"
echo "      API のご契約が必要です。無料プランでは Claude Code は使えません。"
echo ""

echo "[Enterキーで閉じます]"
read -r _
exit 0
