#!/usr/bin/env bash
# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
_sl_trial_runtime="${SOLOPTILINK_HOME:-$HOME/.soloptilink}/lib/free-trial/runtime_guard.py"
if [ ! -f "$_sl_trial_runtime" ]; then
  _sl_trial_runtime="$HOME/.soloptilink/lib/free-trial/runtime_guard.py"
fi
if [ ! -f "$_sl_trial_runtime" ]; then
  _sl_trial_runtime="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/../../../lib/free-trial/runtime_guard.py"
fi
if [ -f "$_sl_trial_runtime" ]; then
  python3 "$_sl_trial_runtime" soloptilink-boost || exit $?
else
  python3 - "${SOLOPTILINK_HOME:-$HOME/.soloptilink}" "$HOME/.soloptilink" <<'SL_TRIAL_CHECK'
import json, os, sys
from pathlib import Path
for root in map(Path, sys.argv[1:]):
    trial = os.path.lexists(root / '.free-trial/marker.json')
    try:
        trial = trial or json.loads((root / 'activation.json').read_text(encoding='utf-8-sig')).get('plan_kind') == 'trial'
    except (OSError, ValueError, AttributeError):
        pass
    if trial:
        print('無料トライアルの確認部品が見つからないため、この機能は実行できません。', file=sys.stderr)
        raise SystemExit(3)
SL_TRIAL_CHECK
  _sl_trial_result=$?
  if [ "$_sl_trial_result" -ne 0 ]; then exit "$_sl_trial_result"; fi
  unset _sl_trial_result
fi
unset _sl_trial_runtime
fi
# SOLOPTILINK-TRIAL-ENTRY:END

# =============================================================================
# Hearing → BOOST 連携バンドルの再ビルド
# -----------------------------------------------------------------------------
# hearing-entry.ts を単一の自己完結 .mjs にバンドルし、ソースハッシュの
# sidecar(meta.json) を更新する。バンドル後の .mjs は外部依存ゼロ (fs/os/path のみ)
# のため実行に esbuild は不要。
#
# 実行タイミング:
#   - hearing-entry.ts を変更したとき
#   - bridge が「バンドルが陳腐化」と WARN を出したとき
#
# 【重要】hearing 本体 (~/.claude/skills/soloptilink-hearing/) および
# ~/.soloptilink/lib/hearing-engine.sh は「無編集参照」= バンドルに取り込まない。
# 依頼書「越境ゼロ」を担保するため、source_hash は hearing-entry.ts 単独で計算する。
# =============================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENTRY="$HERE/hearing-entry.ts"
OUT="$HERE/hearing-recall.bundle.mjs"
META="$HERE/hearing-recall.bundle.meta.json"

# --- esbuild の所在を解決 ---
ESB=""
for c in \
  "$HOME/.soloptilink/admin-dashboard-true-source/node_modules/.bin/esbuild" \
  "$(command -v esbuild 2>/dev/null || true)" \
  "$HERE/node_modules/.bin/esbuild"; do
  if [ -n "$c" ] && [ -x "$c" ]; then ESB="$c"; break; fi
done
if [ -z "$ESB" ]; then
  echo "ERROR: esbuild が見つかりません。" >&2
  exit 2
fi

# --- バンドル生成 ---
"$ESB" "$ENTRY" \
  --bundle --platform=node --target=node18 --format=esm \
  --outfile="$OUT" --log-level=warning

# --- ソースハッシュ封緘 (entry 単独 = 越境ゼロ) ---
COMBINED="$(shasum -a 256 "$ENTRY" | awk '{print $1}')  hearing-entry.ts
"
SRC_HASH="$(printf '%s' "$COMBINED" | shasum -a 256 | awk '{print $1}')"
BUNDLE_HASH="$(shasum -a 256 "$OUT" | awk '{print $1}')"

cat > "$META" <<JSON
{
  "schema": "hearing-recall-bundle/1",
  "source_hash": "$SRC_HASH",
  "bundle_hash": "$BUNDLE_HASH",
  "note": "source_hash は hearing-entry.ts 単独の複合ハッシュ (hearing 本体・hearing-engine.sh は無編集参照=バンドルに取り込まない)。bridge が実行時に再計算して陳腐化を検知する。"
}
JSON

echo "OK: hearing bundle 再生成完了"
echo "  bundle: $OUT"
echo "  source_hash: $SRC_HASH"
