"use strict";
// 当社の端末で当社の入口ファイルが直接動かされたときだけ呼ぶ。
// process.exit で止めるのはその直接実行だけとし、入口を取り込む部品やお客様のシステムでは呼ばない。
exports.requireRuntime = function requireRuntime(skill) {
  // お客様のブラウザで使う部品は従来どおり。当社の端末側実行部品だけを判定する。
  if (typeof process === 'undefined' || !process.versions || !process.versions.node) return;
  const load = typeof __slTrialModuleRequire === 'function' ? __slTrialModuleRequire :
    (typeof module['require'] === 'function' ? module['require'].bind(module) :
      process.getBuiltinModule('module').createRequire(process.cwd() + '/'));
  const fs = load('node:fs');
  const os = load('node:os');
  const path = load('node:path');
  const homes = [...new Set([process.env.SOLOPTILINK_HOME, path.join(os.homedir(), '.soloptilink'), (typeof __dirname === 'string' ? path.resolve(__dirname, '../..') : process.cwd())].filter(Boolean))];
  for (const home of homes) {
    const guard = path.join(home, 'lib/free-trial/runtime_guard.cjs');
    if (fs.existsSync(guard)) { load(guard).requireRuntime(skill); return; }
  }
  for (const home of homes.slice(0, 2)) {
    let trial = false;
    try { fs.lstatSync(path.join(home, '.free-trial/marker.json')); trial = true; } catch {}
    try { trial ||= JSON.parse(fs.readFileSync(path.join(home, 'activation.json'), 'utf8').replace(/^\uFEFF/, '')).plan_kind === 'trial'; } catch {}
    if (trial) { process.stderr.write('無料トライアルの確認部品が見つからないため、この機能は実行できません。\n'); process.exit(3); }
  }
};
