#!/usr/bin/env python3
"""文字の外接矩形推定と衝突回避

図面の注記が互いに重なる（文字被り）のを構造的に防ぐための基盤。
すべて紙面mm単位で扱う（図形の縮尺に影響されない）。

- 日本語は全角=文字高×1.0、半角=文字高×0.55 で送り幅を推定
- 配置済みの矩形と衝突する注記は、候補位置へ退避させる
- 大きく動かす場合は引出線（リーダ）を引いて指示先を保つ
"""
from __future__ import annotations

# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if __name__ == "__main__":
    import sys as _sl_trial_sys
    from pathlib import Path as _SlTrialPath
    _sl_trial_sys.path.insert(0, str((_SlTrialPath(__file__).resolve().parent / ".").resolve()))
    from _trial_guard import require_runtime as _require_trial_runtime
    _require_trial_runtime("suishin-drawing-engine")
# SOLOPTILINK-TRIAL-ENTRY:END



import unicodedata
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

# 送り幅の係数（MSゴシック等の等幅日本語フォントを想定）
FULLWIDTH_RATIO = 1.0
HALFWIDTH_RATIO = 0.55
LINE_GAP_RATIO = 0.35   # 行間
PAD_RATIO = 0.18        # 文字外接矩形にもたせる余白（隣接文字の窮屈さを防ぐ）


def char_ratio(ch: str) -> float:
    """1文字の送り幅係数を返す"""
    if ch == "\n":
        return 0.0
    # East Asian Width: W(Wide)/F(Fullwidth)/A(Ambiguous)は全角扱い
    if unicodedata.east_asian_width(ch) in ("W", "F", "A"):
        return FULLWIDTH_RATIO
    return HALFWIDTH_RATIO


def text_width(s: str, height: float) -> float:
    """文字列の描画幅（紙面mm）。複数行は最長行を返す。"""
    if not s:
        return 0.0
    return max(
        sum(char_ratio(c) for c in line) * height
        for line in s.split("\n")
    )


def text_height_total(s: str, height: float) -> float:
    """複数行を含めた全体高さ（紙面mm）"""
    lines = max(1, len(s.split("\n")))
    return lines * height + (lines - 1) * height * LINE_GAP_RATIO


@dataclass
class Rect:
    x1: float
    y1: float
    x2: float
    y2: float

    @property
    def w(self) -> float:
        return self.x2 - self.x1

    @property
    def h(self) -> float:
        return self.y2 - self.y1

    @property
    def cx(self) -> float:
        return (self.x1 + self.x2) / 2

    @property
    def cy(self) -> float:
        return (self.y1 + self.y2) / 2

    def overlaps(self, o: "Rect", gap: float = 0.0) -> bool:
        return not (
            self.x2 + gap <= o.x1
            or o.x2 + gap <= self.x1
            or self.y2 + gap <= o.y1
            or o.y2 + gap <= self.y1
        )

    def contains(self, o: "Rect") -> bool:
        return (self.x1 <= o.x1 and self.y1 <= o.y1
                and self.x2 >= o.x2 and self.y2 >= o.y2)

    def expand(self, m: float) -> "Rect":
        return Rect(self.x1 - m, self.y1 - m, self.x2 + m, self.y2 + m)

    def union(self, o: "Rect") -> "Rect":
        return Rect(min(self.x1, o.x1), min(self.y1, o.y1),
                    max(self.x2, o.x2), max(self.y2, o.y2))

    def as_tuple(self) -> Tuple[float, float, float, float]:
        return (self.x1, self.y1, self.x2, self.y2)


# 配置基準（水平_垂直）: l/c/r × b/m/t
def text_rect(s: str, x: float, y: float, height: float,
              align: str = "l_b", pad_ratio: float = PAD_RATIO,
              rotation: float = 0.0) -> Rect:
    """挿入点・文字高・配置基準から文字の外接矩形を求める

    pad_ratio=0 にすると余白なしの実字形に近い矩形になる（重なり検出用）。
    rotation は 90 度系のみ考慮する（図面で使うのは水平と垂直のみ）。
    """
    w = text_width(s, height)
    h = text_height_total(s, height)
    if abs((rotation % 180) - 90) < 1e-6:
        w, h = h, w
    ha, va = (align.split("_") + ["b"])[:2]
    if ha == "c":
        x1 = x - w / 2
    elif ha == "r":
        x1 = x - w
    else:
        x1 = x
    if va == "m":
        y1 = y - h / 2
    elif va == "t":
        y1 = y - h
    else:
        y1 = y
    pad = height * pad_ratio
    return Rect(x1 - pad, y1 - pad * 0.5, x1 + w + pad, y1 + h + pad * 0.5)


@dataclass
class Label:
    """配置対象の注記"""
    text: str
    x: float                 # 紙面mm（希望位置）
    y: float
    height: float
    layer: str = "3-TEXT"
    align: str = "l_b"
    priority: int = 5        # 小さいほど動かしにくい（0=固定）
    movable: bool = True
    leader_to: Optional[Tuple[float, float]] = None  # 退避時の指示元
    rotation: float = 0.0

    def rect(self) -> Rect:
        return text_rect(self.text, self.x, self.y, self.height, self.align)


class LabelPlacer:
    """注記の衝突回避配置

    使い方:
        p = LabelPlacer(bounds=Rect(...))
        p.add_obstacle(Rect(...))        # 表・図枠など動かせない領域
        p.add(Label(...))
        placed, unresolved = p.resolve()
    """

    # 退避候補: (dx係数, dy係数) を文字高の倍数で試す。
    # 図面では上下へ逃がすほうが読み順を保ちやすいので縦方向を優先する。
    _DIRS = [
        (0, 1), (0, -1), (1, 0), (-1, 0),
        (1, 1), (-1, 1), (1, -1), (-1, -1),
    ]
    _STEPS = [1.4, 2.4, 3.4, 4.6, 6.0, 7.6, 9.4, 11.4, 14.0]

    def __init__(self, bounds: Optional[Rect] = None, gap: float = 1.0):
        self.bounds = bounds
        self.gap = gap
        self.obstacles: List[Rect] = []
        self.labels: List[Label] = []
        self.leaders: List[Tuple[Tuple[float, float], Tuple[float, float]]] = []

    def add_obstacle(self, r: Rect) -> None:
        self.obstacles.append(r)

    def add(self, label: Label) -> None:
        self.labels.append(label)

    def _collides(self, r: Rect, placed: List[Rect]) -> bool:
        if self.bounds is not None and not self.bounds.contains(r):
            return True
        for o in self.obstacles:
            if r.overlaps(o, self.gap):
                return True
        for p in placed:
            if r.overlaps(p, self.gap):
                return True
        return False

    def resolve(self) -> Tuple[List[Label], List[Label]]:
        """衝突を解消する。戻り: (配置済み, 解消できなかったもの)"""
        placed_rects: List[Rect] = []
        placed: List[Label] = []
        unresolved: List[Label] = []

        # 動かしにくいものから確定させる
        for lb in sorted(self.labels, key=lambda l: (l.priority, -l.height)):
            r = lb.rect()
            if not self._collides(r, placed_rects) or not lb.movable:
                placed_rects.append(r)
                placed.append(lb)
                continue

            origin = (lb.x, lb.y)
            found = False
            # 横へ逃がす量は文字幅を基準にしないと、隣とくっついて読めなくなる
            hstep = max(lb.height * 1.6, text_width(lb.text, lb.height) * 0.6 + self.gap)
            for step in self._STEPS:
                for dx, dy in self._DIRS:
                    nx = lb.x + dx * hstep * step
                    ny = lb.y + dy * lb.height * step
                    cand = text_rect(lb.text, nx, ny, lb.height, lb.align)
                    if not self._collides(cand, placed_rects):
                        lb.x, lb.y = nx, ny
                        # 大きく離れたら引出線で指示元を保つ
                        if step >= 2.0:
                            lb.leader_to = origin
                            self.leaders.append((origin, (nx, ny)))
                        placed_rects.append(cand)
                        placed.append(lb)
                        found = True
                        break
                if found:
                    break
            if not found:
                unresolved.append(lb)
        return placed, unresolved


def count_overlaps(rects: List[Rect], gap: float = 0.0) -> int:
    """重なっている矩形ペアの数（検証用）"""
    n = 0
    for i in range(len(rects)):
        for j in range(i + 1, len(rects)):
            if rects[i].overlaps(rects[j], gap):
                n += 1
    return n


if __name__ == "__main__":
    # 自己テスト: 意図的に重ねた注記が解消されることを確認
    p = LabelPlacer(bounds=Rect(0, 0, 200, 120))
    for i in range(6):
        p.add(Label(text=f"内空W=4.0m {i}", x=50, y=60, height=3.0))
    placed, unresolved = p.resolve()
    rects = [l.rect() for l in placed]
    print(f"配置 {len(placed)}件 / 未解消 {len(unresolved)}件 / 重なり {count_overlaps(rects)}組")
    assert count_overlaps(rects) == 0, "衝突が解消されていない"
    assert not unresolved, "配置できない注記が残った"
    print(f"幅推定: '内空W=4.0m' @3.0mm = {text_width('内空W=4.0m', 3.0):.2f}mm")
    print("[textfit] self-test OK")
