"""当社の端末で当社の入口を直接実行したときだけ呼ぶ。

SystemExit で止めるのはその直接実行だけとし、import された部品やお客様のシステムでは呼ばない。
"""
import importlib.util
import json
import os
import sys
from pathlib import Path

_checked = False

def require_runtime(skill):
    global _checked
    if _checked:
        return
    homes = list(dict.fromkeys([Path(os.environ.get("SOLOPTILINK_HOME", str(Path.home() / ".soloptilink"))), Path.home() / ".soloptilink", Path(__file__).resolve().parents[3]]))
    for home in homes:
        guard = home / "lib/free-trial/runtime_guard.py"
        if guard.is_file():
            spec = importlib.util.spec_from_file_location("sl_trial_runtime_guard", guard)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            module.require_runtime(skill)
            _checked = True
            return
    for home in homes[:2]:
        trial = os.path.lexists(home / ".free-trial/marker.json")
        try:
            trial = trial or json.loads((home / "activation.json").read_text(encoding="utf-8-sig")).get("plan_kind") == "trial"
        except (OSError, ValueError):
            pass
        if trial:
            print("無料トライアルの確認部品が見つからないため、この機能は実行できません。", file=sys.stderr)
            raise SystemExit(3)
