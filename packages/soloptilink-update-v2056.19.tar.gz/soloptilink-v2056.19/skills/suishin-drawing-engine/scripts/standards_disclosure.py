#!/usr/bin/env python3
"""図面様式の出典管理と「未確認」の開示（推進工法図面エンジン）

なぜこれが要るか:
  本エンジンは用紙寸法・標準縮尺・推奨文字高・図枠余白などを「JIS の様式に倣って」
  決めているが、規格票（原典）を参照して裏を取ったわけではない。
  裏を取っていないのに図面へ「JIS 準拠」と書けば、お客様が規格適合の根拠として
  使ってしまう。そこで本モジュールが未確認項目を1件ずつ台帳として持ち、
  生成される全図面の図枠外へ開示注記を必ず描き込む。

  規律の出典は機械製図エンジン lib/mech-draft/standards.py（unconfirmed / disclosure_ja）。
  同型の API を推進工法側にも置き、2つの図面エンジンで名乗りの規律を揃える。

台帳の書き方:
  provenance が "unconfirmed_working_default" の項目だけが未確認として開示される。
  原典を確認できた項目は provenance を "verified" にし、verified_source_ja に
  「どの規格のどの項目を確認したか」を書くこと。確認していない項目を verified に
  してはならない（開示注記が黙るため、この課題の症状そのものが戻る）。
"""
from __future__ import annotations

# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if __name__ == "__main__":
    import sys as _sl_trial_sys
    from pathlib import Path as _SlTrialPath
    _sl_trial_sys.path.insert(0, str((_SlTrialPath(__file__).resolve().parent / ".").resolve()))
    from _trial_guard import require_runtime as _require_trial_runtime
    _require_trial_runtime("suishin-drawing-engine")
# SOLOPTILINK-TRIAL-ENTRY:END



from typing import Dict, List

# --- 様式値の出典台帳 ---------------------------------------------------
# key         : 台帳の項目名（機械可読）
# title_ja    : お客様向けの項目名
# provenance  : "unconfirmed_working_default"（未確認の暫定値）/ "verified"（原典確認済み）
# source_ja   : 何に倣ったか（倣った先を書くだけで、準拠を意味しない）
# owner_action_ja : 確定させるために何をすればよいか
STANDARD_ITEMS: List[Dict] = [
    {
        "key": "paper_sizes",
        "title_ja": "用紙寸法 (A0〜A4)",
        "provenance": "unconfirmed_working_default",
        "source_ja": "JIS Z 8311 (製図に用いる図面の大きさ) の様式に倣う。規格票の原典は未参照。",
        "owner_action_ja": "JIS Z 8311 の規格票を入手し、用紙寸法表と照合して確定する。",
    },
    {
        "key": "standard_scales",
        "title_ja": "標準縮尺の系列",
        "provenance": "unconfirmed_working_default",
        "source_ja": "JIS Z 8311 の尺度の様式に倣う実用系列。規格票の原典は未参照。",
        "owner_action_ja": "JIS Z 8311 の尺度の規定を確認し、系列に無い値を除く。",
    },
    {
        "key": "text_heights",
        "title_ja": "文字高の推奨値",
        "provenance": "unconfirmed_working_default",
        "source_ja": "JIS Z 8313 (製図に用いる文字) に沿うとされる値。規格票の原典は未参照。",
        "owner_action_ja": "JIS Z 8313 の文字高系列を確認し、採用値を規格値へ合わせる。",
    },
    {
        "key": "frame_margins",
        "title_ja": "図枠の余白ととじ代 (左25mm / 他10mm)",
        "provenance": "unconfirmed_working_default",
        "source_ja": "一般的な作図慣行に倣う。規格票および発注機関の様式規定は未参照。",
        "owner_action_ja": "発注機関の図面様式規定（CAD 製図基準等）を入手し、余白を確定する。",
    },
    {
        "key": "titleblock_form",
        "title_ja": "タイトルブロックの様式 (幅180mm / 高さ46mm / 4段)",
        "provenance": "unconfirmed_working_default",
        "source_ja": "社内の作図慣行に倣う独自様式。規格票・発注機関様式は未参照。",
        "owner_action_ja": "納品先の表題欄様式を入手し、欄構成と寸法を合わせる。",
    },
    {
        "key": "layer_naming",
        "title_ja": "レイヤ名の体系 (0-OUTLINE ほか)",
        "provenance": "unconfirmed_working_default",
        "source_ja": "本エンジン独自の体系。CAD 製図基準のレイヤ命名規則とは対応づけていない。",
        "owner_action_ja": "納品先が CAD 製図基準を要求する場合、レイヤ名の対応表を作る。",
    },
    {
        "key": "pipe_technical_data",
        "title_ja": "推進管の技術資料に基づく諸元・算定式",
        "provenance": "unconfirmed_working_default",
        "source_ja": "推進工法用鉄筋コンクリート管の協会技術資料の式に倣う。技術資料の原典は未参照。",
        "owner_action_ja": "技術資料の原典を入手し、採用式と係数を照合する。",
    },
]

# 図面へ描く注記の見出し（検査が探す目印。変更するときは検査軸も一緒に直すこと）
DISCLOSURE_MARK = "注記:"


def items() -> List[Dict]:
    """台帳を丸ごと返す。"""
    return [dict(it) for it in STANDARD_ITEMS]


def unconfirmed() -> List[Dict]:
    """原典を参照できていない項目の一覧（開示義務のある項目）。

    出力物・CLI・報告書はこの一覧を必ず提示する。これを黙らせてはならない。
    """
    return [dict(it) for it in STANDARD_ITEMS
            if it.get("provenance") == "unconfirmed_working_default"]


def disclosure_ja() -> str:
    """未確認項目の日本語開示文（図面の図枠外・報告書に載せる用）。

    図面に載る = お客様が読む文。社内の操作方法や内部名称は書かない。
    """
    n = len(unconfirmed())
    if n == 0:
        return "本図の様式はすべて出典を確認済みです。"
    return (f"{DISCLOSURE_MARK} 本図の様式（用紙・尺度・文字高・図枠・表題欄）のうち "
            f"{n} 項目は規格票 (JIS 等) の一次情報を参照できておらず未確認の暫定値です。"
            f"JIS 準拠を保証するものではありません "
            f"(該当項目の一覧はご要望に応じて提出いたします)。")


def disclosure_lines_ja(max_chars: int = 62) -> List[str]:
    """開示文を図面へ描くための折り返し済み行。

    DXF の TEXT は自動折り返ししないため、ここで文字数で折る。
    行が1本も返らないことがあってはならない（開示が消える）。
    """
    s = disclosure_ja()
    if max_chars < 8:
        max_chars = 8
    lines: List[str] = []
    buf = ""
    for ch in s:
        buf += ch
        if len(buf) >= max_chars:
            lines.append(buf)
            buf = ""
    if buf:
        lines.append(buf)
    return lines or [s]


def report() -> Dict:
    """機械可読の開示（メタ JSON・ドクター用）。"""
    unc = unconfirmed()
    return {
        "total_items": len(STANDARD_ITEMS),
        "unconfirmed_count": len(unc),
        "unconfirmed": unc,
        "disclosure_ja": disclosure_ja(),
        "claims_jis_conformance": False,
    }


# --- 自己検査（両側） ---------------------------------------------------
def selftest() -> int:
    """健全側と欠陥側の両方を測る。戻り値 0 = 全項目 PASS。"""
    results: List[tuple] = []

    def check(name: str, ok: bool, detail: str = "") -> None:
        results.append((name, bool(ok), detail))

    unc = unconfirmed()

    # 健全側
    check("unconfirmed_not_empty", len(unc) > 0,
          f"未確認 {len(unc)} 項目")
    check("disclosure_says_unconfirmed", "未確認" in disclosure_ja(),
          "開示文に『未確認』が含まれる")
    check("disclosure_denies_conformance", "保証するものではありません" in disclosure_ja(),
          "開示文が準拠の保証を明確に否定する")
    check("disclosure_count_matches", str(len(unc)) in disclosure_ja(),
          "開示文の件数が台帳と一致する")
    check("lines_never_empty", len(disclosure_lines_ja()) > 0
          and all(l.strip() for l in disclosure_lines_ja()),
          "折り返し後も空行にならない")
    check("lines_join_equals_text",
          "".join(disclosure_lines_ja()) == disclosure_ja(),
          "折り返しで文字が欠落しない")
    check("report_denies_jis", report()["claims_jis_conformance"] is False,
          "機械可読側も JIS 準拠を名乗らない")
    check("every_item_has_owner_action",
          all(it.get("owner_action_ja") for it in STANDARD_ITEMS),
          "全項目に確定手順が書かれている")

    # 欠陥側（壊した検体で落ちること）
    saved = [dict(it) for it in STANDARD_ITEMS]
    try:
        # 検体A: 全項目を確認済みに書き換えると、開示文は「未確認」を言わなくなる
        for it in STANDARD_ITEMS:
            it["provenance"] = "verified"
        check("defect_A_all_verified_changes_text",
              len(unconfirmed()) == 0 and "未確認" not in disclosure_ja(),
              "全項目確認済みなら開示文が変わる（開示が固定文でない）")
        # 検体B: 1項目だけ未確認へ戻すと件数が1になる
        STANDARD_ITEMS[0]["provenance"] = "unconfirmed_working_default"
        check("defect_B_count_follows_ledger",
              len(unconfirmed()) == 1 and " 1 項目" in disclosure_ja(),
              "件数が台帳の実数に追随する")
    finally:
        for i, it in enumerate(saved):
            STANDARD_ITEMS[i].clear()
            STANDARD_ITEMS[i].update(it)

    # 復元できたことも測る（検査が台帳を壊したまま帰らない）
    check("ledger_restored", len(unconfirmed()) == len(unc),
          f"検査後も未確認 {len(unconfirmed())} 項目")

    fail = 0
    for name, ok, detail in results:
        print(f"[{'PASS' if ok else 'FAIL'}] {name}: {detail}")
        if not ok:
            fail += 1
    print(f"[standards_disclosure] PASS={len(results) - fail} FAIL={fail}")
    return 1 if fail else 0


if __name__ == "__main__":
    import json
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "selftest":
        sys.exit(selftest())
    print(json.dumps(report(), ensure_ascii=False, indent=2))
