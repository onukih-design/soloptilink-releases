#!/usr/bin/env python3
"""推力計算書 Excel 生成
推進工法用鉄筋コンクリート管技術資料 準拠の基本推力計算式:
  総推力 F = f0 + f × L
  f0 = 掘進機先端抵抗 (kN)
  f  = 管周面抵抗 (kN/m) = μ × 管重 + 土圧起因抵抗
  L  = 推進延長 (m)
安全率 SF = 許容押込力 / 総推力  ≥ 1.5 が必要
中押ジャッキ配置は元押のみで不足時に自動提案

許容押込力は諸元の表 (rules/method_specs_seed.json の allowable_thrust_kN) から、区分つきで引く
(2026-10-26 ご判断K-11):
  確定値 … 従来どおり計算する
  仮の値 … 計算するが、計算書の先頭・判定欄・注意欄に「仮の値で計算」と明記する (判定欄は黄色)
  未登録 … 既定値などを当てず、判定を「判定できません（許容押込力の値が未登録です）」にする
"""
from __future__ import annotations

# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if __name__ == "__main__":
    import sys as _sl_trial_sys
    from pathlib import Path as _SlTrialPath
    _sl_trial_sys.path.insert(0, str((_SlTrialPath(__file__).resolve().parent / ".").resolve()))
    from _trial_guard import require_runtime as _require_trial_runtime
    _require_trial_runtime("suishin-drawing-engine")
# SOLOPTILINK-TRIAL-ENTRY:END


import json
import math
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

import ipguard_bridge  # ご利用確認と出所の印 (書き出しの直前で必ず通す)
from method_engine import (MethodEngine, THRUST_CONFIRMED, THRUST_PROVISIONAL,
                           THRUST_UNREGISTERED)

# ---- 許容押込力の出所 (2026-10-26 ご判断K-11) ----
# 以前はここに工法・口径別の表 (5 工法) と既定値 5,000kN があり、表に無い工法・口径では
# 既定値を黙って当てて「OK」を返していた (16 工法 × 標準口径 51 通りのうち 39 通りが既定値で OK)。
# しかも既定値で計算した計算書にも備考欄は「標準値」と書かれ、表の値と見分けがつかなかった。
# 表の工法名「ハイブリッド」は諸元の表の「ハイブリッドモール」と一致せず、値があるのに使われなかった。
#
# 直し方 (3 点):
#   ① 値は諸元の表 (rules/method_specs_seed.json の allowable_thrust_kN) 1 か所に集め、
#      工法名は MethodEngine.resolve_method で名寄せして引く (「ハイブリッド」でも引ける)。
#   ② 区分 (確定値 / 仮の値 / 未登録) を値と一緒に持ち、仮の値で計算したら計算書に明記する。
#   ③ 値が無い (未登録) ときは既定値を当てず、判定を「判定できません」にする。
_ENGINE: Optional[MethodEngine] = None


def _engine() -> MethodEngine:
    global _ENGINE
    if _ENGINE is None:
        _ENGINE = MethodEngine()
    return _ENGINE


def _registered_table() -> dict:
    """互換用: 値が使える (工法, 呼び径) -> kN の対応。既定値 ("default") は廃止した。"""
    eng = _engine()
    table = {}
    for m, info in eng.thrust_status_table().items():
        for d in info["diameters"]:
            table[(m, d)] = eng.allowable_thrust(m, d)["value_kn"]
    return table


MACHINE_THRUST_ALLOW_KN = _registered_table()

# 区分の表示語。「指定値」はお客様が machine_allowable_kn で値を指定したときだけ
# (諸元の表の区分ではない。値の出典は指定した方が確かめる)。
THRUST_SPECIFIED = "指定値"
VERDICT_UNJUDGEABLE = "判定できません（許容押込力の値が未登録です）"

# 土質別 管周面抵抗係数 f (kN/m/㎡)
FRICTION_COEF = {
    "粘性土":      0.30,
    "砂質土":      0.50,
    "礫混り土":    0.80,
    "軟弱土":      0.20,
    "巨石混り礫":  1.20,
}

# 掘進機先端抵抗 f0 (kN・口径・土質から見積り)
def machine_face_resistance(diameter_mm: int, soil: str) -> float:
    base_area = math.pi * (diameter_mm / 2000.0) ** 2  # 掘削断面積 (㎡)
    q = {"粘性土": 150, "砂質土": 250, "礫混り土": 400, "軟弱土": 100, "巨石混り礫": 600}.get(soil, 300)
    return round(q * base_area, 1)  # kN


def pipe_weight_kn_per_m(diameter_mm: int) -> float:
    """鉄筋コンクリート管の 単位長重量 (kN/m) 概算"""
    d = diameter_mm / 1000.0
    thickness = 0.05 + d * 0.10  # 概算厚 (m)
    volume = math.pi * ((d/2 + thickness) ** 2 - (d/2) ** 2)  # ㎥/m
    return round(volume * 24.5, 2)  # 鉄筋コン 24.5 kN/㎥


@dataclass
class ThrustInput:
    project_name: str
    drawing_no: str
    client: str
    method: str
    diameter_mm: int
    length_m: float
    soil: str = "粘性土"
    depth_m: float = 5.0
    curve_present: bool = False
    curve_radius_m: Optional[float] = None
    curve_length_m: float = 0.0
    friction_reduction_lube: float = 0.60   # 滑材注入による摩擦低減率（0.4=60%減）
    safety_factor_required: float = 1.5
    machine_allowable_kn: Optional[float] = None  # 未指定なら口径から推定
    designer: str = ""

    @classmethod
    def from_json(cls, path: str) -> "ThrustInput":
        return cls(**json.load(open(path, encoding="utf-8")))


def compute_thrust(inp: ThrustInput) -> dict:
    f0 = machine_face_resistance(inp.diameter_mm, inp.soil)
    pipe_w = pipe_weight_kn_per_m(inp.diameter_mm)
    mu = FRICTION_COEF.get(inp.soil, 0.5)
    # 管周面抵抗 (滑材効果適用)
    f_per_m = mu * pipe_w * (1 - inp.friction_reduction_lube)
    # 曲線抵抗の割増 (曲線区間は 20~40%増)
    curve_factor = 1.0
    if inp.curve_present and inp.curve_radius_m:
        curve_factor = 1.0 + max(0, (60 - inp.curve_radius_m) / 60) * 0.4
    f_per_m *= curve_factor

    thrust_kn = f0 + f_per_m * inp.length_m
    # 許容押込力: お客様の指定 > 諸元の表 (区分つき)。どちらも無ければ未登録で、**値を当てない**。
    if inp.machine_allowable_kn:
        allow = inp.machine_allowable_kn
        allow_status = THRUST_SPECIFIED
        allow_source = "お客様が machine_allowable_kn で指定した値"
        allow_reason = ""
        allow_method = inp.method
    else:
        info = _engine().allowable_thrust(inp.method, inp.diameter_mm)
        allow = info["value_kn"]
        allow_status = info["status"]
        allow_source = info["source"]
        allow_reason = info["reason_ja"]
        allow_method = info["method"]      # 名寄せ後の正式名 (「ハイブリッド」→「ハイブリッドモール」)

    intermediate_jacks = 0
    if allow is None:
        # 未登録: 安全率も施工可否も出さない (OK と呼ばない)
        sf = None
        verdict = VERDICT_UNJUDGEABLE
    else:
        sf = allow / thrust_kn if thrust_kn > 0 else float("inf")
        verdict = "OK" if sf >= inp.safety_factor_required else "NG（中押ジャッキ必要）"
        # 中押ジャッキが必要なら推奨配置
        if sf < inp.safety_factor_required:
            needed_reduction = 1 - (allow / (thrust_kn * inp.safety_factor_required))
            segment_len = inp.length_m * (1 - needed_reduction)
            intermediate_jacks = max(1, math.ceil(inp.length_m / segment_len) - 1)

    return {
        "f0_kn":            f0,
        "pipe_weight_kn_m": pipe_w,
        "mu":               mu,
        "friction_reduction": inp.friction_reduction_lube,
        "curve_factor":     round(curve_factor, 3),
        "f_per_m_kn":       round(f_per_m, 3),
        "total_thrust_kn":  round(thrust_kn, 1),
        "allowable_kn":     allow,
        # 許容押込力の区分 (確定値 / 仮の値 / 未登録 / 指定値) と出所。仮の値・未登録は計算書に明記する
        "allowable_status": allow_status,
        "allowable_source": allow_source,
        "allowable_reason_ja": allow_reason,
        "allowable_method": allow_method,
        "safety_factor":    round(sf, 2) if sf is not None else None,
        "verdict":          verdict,
        "intermediate_jacks_recommended": intermediate_jacks,
    }


def render_excel(inp: ThrustInput, result: dict, out_path: str) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "推力計算書"
    thin = Side(style="thin", color="000000")
    med = Side(style="medium", color="000000")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    hdr_fill = PatternFill("solid", fgColor="1F4E79")
    hdr_font = Font(bold=True, color="FFFFFF", size=11)
    title_font = Font(bold=True, size=14, color="1F4E79")
    ok_fill = PatternFill("solid", fgColor="C6E0B4")
    ng_fill = PatternFill("solid", fgColor="F4B084")
    warn_fill = PatternFill("solid", fgColor="FFE699")   # 仮の値・未登録 (素の OK/NG と見分ける黄色)

    ws.column_dimensions['A'].width = 4
    ws.column_dimensions['B'].width = 22
    ws.column_dimensions['C'].width = 18
    ws.column_dimensions['D'].width = 18
    ws.column_dimensions['E'].width = 32

    # タイトル
    ws.merge_cells("B2:E2")
    ws["B2"] = f"推力計算書 ({inp.method} φ{inp.diameter_mm} L={inp.length_m}m)"
    ws["B2"].font = title_font
    ws["B2"].alignment = Alignment(horizontal="center", vertical="center")

    # 先頭の注意 (仮の値で計算したとき・許容押込力が未登録のときだけ。確定値・指定値では何も足さない)
    banner = _banner_text(inp, result)
    if banner:
        ws.merge_cells("B3:E3")
        ws["B3"] = banner
        ws["B3"].font = Font(bold=True, size=11, color="C00000")
        ws["B3"].alignment = Alignment(wrap_text=True, vertical="center")
        for c in range(2, 6):
            ws.cell(row=3, column=c).fill = warn_fill
            ws.cell(row=3, column=c).border = border
        ws.row_dimensions[3].height = _row_height(banner, 86) or 20

    # 案件情報
    info = [
        ("工事名", inp.project_name),
        ("発注者", inp.client),
        ("図面No.", inp.drawing_no),
        ("設計者", inp.designer),
        ("計算日", "auto-generated"),
    ]
    r = 4
    for k, v in info:
        ws.cell(row=r, column=2, value=k).font = Font(bold=True)
        ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=5)
        ws.cell(row=r, column=3, value=v)
        for c in range(2, 6):
            ws.cell(row=r, column=c).border = border
        r += 1

    # 入力条件
    r += 1
    ws.cell(row=r, column=2, value="■ 入力条件").font = Font(bold=True, size=12, color="1F4E79")
    r += 1
    inputs = [
        ("項目", "値", "単位", "備考"),
        ("工法", inp.method, "-", ""),
        ("呼び径", inp.diameter_mm, "mm", ""),
        ("推進延長", inp.length_m, "m", ""),
        ("土質", inp.soil, "-", "PDF技術資料の適用土質参照"),
        ("土被り", inp.depth_m, "m", ""),
        ("曲線区間", "有" if inp.curve_present else "無", "-",
         f"R={inp.curve_radius_m}m" if inp.curve_present else ""),
        ("滑材注入", f"{int(inp.friction_reduction_lube*100)}%", "%減", "混合済み滑材系"),
        ("要求安全率", inp.safety_factor_required, "-", "SF≥1.5 標準"),
    ]
    _write_table(ws, r, 2, inputs, border, hdr_fill, hdr_font)
    r += len(inputs) + 2

    # 計算過程
    ws.cell(row=r, column=2, value="■ 計算過程").font = Font(bold=True, size=12, color="1F4E79")
    r += 1
    calcs = [
        ("項目", "計算値", "単位", "計算式・出典"),
        ("掘進機先端抵抗 f0", result["f0_kn"], "kN", f"q×A ({inp.soil} q値×掘削断面積)"),
        ("管単位重量", result["pipe_weight_kn_m"], "kN/m", "鉄筋コン管概算 24.5kN/㎥"),
        ("摩擦係数 μ", result["mu"], "-", f"{inp.soil} 標準値"),
        ("滑材低減率", f"{int(result['friction_reduction']*100)}%", "%", "混合済み滑材"),
        ("曲線抵抗補正", result["curve_factor"], "倍",
         "R≥60mで1.0、Rが小さいほど増加"),
        ("管周面抵抗 f", result["f_per_m_kn"], "kN/m", "μ×管重×(1-低減率)×曲線補正"),
        ("総推力 F = f0 + f×L", result["total_thrust_kn"], "kN", "推進協会標準式"),
    ]
    _write_table(ws, r, 2, calcs, border, hdr_fill, hdr_font)
    r += len(calcs) + 2

    # 判定
    ws.cell(row=r, column=2, value="■ 判定").font = Font(bold=True, size=12, color="1F4E79")
    r += 1
    is_ok = str(result["verdict"]).startswith("OK")
    status = result.get("allowable_status", THRUST_CONFIRMED)
    unjudgeable = result.get("allowable_kn") is None      # 未登録 (許容押込力が無い)
    labels = _judgement_labels(inp, result, status, unjudgeable, is_ok)
    verdicts = [
        ("項目", "値", "単位", "備考"),
        ("必要推力 F", result["total_thrust_kn"], "kN", ""),
        ("掘進機許容押込力", labels["allow_cell"], "kN", labels["allow_note"]),
        ("安全率 SF = 許容/必要", labels["sf_cell"], "-", labels["sf_note"]),
        ("判定", labels["verdict_cell"], "-", labels["verdict_note"]),
    ]
    _write_table(ws, r, 2, verdicts, border, hdr_fill, hdr_font)
    # 判定行を色分け (確定値・指定値は従来どおり。仮の値・未登録は黄色にして、素の OK/NG と見分ける)
    verdict_row = r + len(verdicts) - 1
    provisional_look = status == THRUST_PROVISIONAL or unjudgeable
    for c in range(2, 6):
        ws.cell(row=verdict_row, column=c).fill = (
            warn_fill if provisional_look else (ok_fill if is_ok else ng_fill))
        ws.cell(row=verdict_row, column=c).font = Font(bold=True, size=12)

    # 中押ジャッキ提案 (未登録のときは出さない: 判定していないので提案の根拠が無い)
    r = verdict_row + 3
    end_row = verdict_row
    if not is_ok and not unjudgeable:
        ws.cell(row=r, column=2, value="■ 中押ジャッキ配置提案").font = Font(bold=True, size=12, color="C00000")
        r += 1
        segment_len = round(inp.length_m / (result["intermediate_jacks_recommended"] + 1), 1)
        prop = [
            ("項目", "値", "単位", "備考"),
            ("中押ジャッキ基数", result["intermediate_jacks_recommended"], "基",
             "仮の値による参考" if status == THRUST_PROVISIONAL else ""),
            ("推奨区間長", segment_len, "m/基", "元押からの距離"),
            ("配置位置", ", ".join([f"{i*segment_len}m" for i in range(1, result["intermediate_jacks_recommended"] + 1)]),
             "m", "推進開始点からの距離"),
        ]
        _write_table(ws, r, 2, prop, border, hdr_fill, hdr_font)
        end_row = r + len(prop) - 1

    # 許容押込力についての注意 (仮の値・未登録のときだけ。どの工法の値が仮かを日本語で書く)
    if provisional_look:
        _write_allowable_notes(ws, end_row + 3, inp, result, status)

    # ご利用確認 (IP-057)。通らなければ LicenseDenied を投げ、計算書は書かない。
    lic = ipguard_bridge.require_license(ipguard_bridge.STAGE_XLSX)
    # 出所の印はブックのプロパティにだけ入れる (セルの値・数式・書式は 1 つも変えない)
    origin = ipguard_bridge.stamp_workbook(wb, lic, drawing_no=inp.drawing_no)
    wb.save(out_path)
    ipguard_bridge.stamp_xlsx_company(out_path, origin.get("_mark") or {})


def _fmt_kn(v) -> str:
    """kN の数字を桁区切りで (整数なら小数点なし)。"""
    try:
        return f"{v:,.0f}" if float(v) == int(float(v)) else f"{v:,g}"
    except (TypeError, ValueError):
        return str(v)


def _row_height(text: str, width_chars: int):
    """折り返しが要る長さなら、結合セル用の行の高さ (pt) を返す。1 行で収まるなら None。
    全角文字は半角 2 つ分の幅として数える。"""
    wide = sum(2 if ord(ch) > 0x7F else 1 for ch in str(text))
    lines = max(1, math.ceil(wide / max(width_chars, 1)))
    return None if lines <= 1 else 16.0 * lines + 4.0


def _methods_by_status(status: str) -> List[str]:
    return [m for m, info in _engine().thrust_status_table().items() if info["status"] == status]


def _banner_text(inp: ThrustInput, result: dict) -> str:
    """表紙 (先頭) の注意文。仮の値・未登録のときだけ返す。"""
    status = result.get("allowable_status")
    m, d = inp.method, inp.diameter_mm
    if status == THRUST_PROVISIONAL:
        return (f"【ご注意：仮の値で計算しています】この計算書の許容押込力 {_fmt_kn(result['allowable_kn'])}kN"
                f"（{m} φ{d}）は、工法の資料で確かめていない仮の値です。"
                f"許容押込力が仮の値の工法：{'、'.join(_methods_by_status(THRUST_PROVISIONAL))}。"
                "確定するまでは参考の判定としてお使いください。")
    if result.get("allowable_kn") is None:
        return (f"【判定できません】{m} φ{d} の許容押込力の値が未登録のため、安全率と施工可否の判定は出していません"
                "（値を仮に置いての計算もしていません）。メーカーの技術資料で許容押込力をご確認ください。")
    return ""


def _judgement_labels(inp: ThrustInput, result: dict, status: str, unjudgeable: bool, is_ok: bool) -> dict:
    """判定の表 (許容押込力・安全率・判定) に書く値と備考。区分ごとに文言を変える。"""
    m, d = inp.method, inp.diameter_mm
    n_jacks = result["intermediate_jacks_recommended"]
    if unjudgeable:
        return {
            "allow_cell": "未登録",
            "allow_note": f"★区分: 未登録｜{m} φ{d} の許容押込力が表にありません。値を仮に置いていません",
            "sf_cell": "判定不可",
            "sf_note": "許容押込力が未登録のため算出していません",
            "verdict_cell": result["verdict"],
            "verdict_note": "許容押込力の値が登録されるまで、施工可否は判定できません。メーカーの技術資料でご確認ください",
        }
    jack_or_ok = (f"中押ジャッキ {n_jacks}基 推奨" if not is_ok else "元押のみで施工可")
    if status == THRUST_PROVISIONAL:
        return {
            "allow_cell": result["allowable_kn"],
            "allow_note": f"★区分: 仮の値｜{m} φ{d}。工法の資料で確かめていない値です",
            "sf_cell": result["safety_factor"],
            "sf_note": f"要求値 {inp.safety_factor_required}（仮の値による参考値）",
            "verdict_cell": f"{result['verdict']}／仮の値で計算",
            "verdict_note": f"{jack_or_ok}（仮の値による参考判定）",
        }
    if status == THRUST_SPECIFIED:
        allow_note = f"{m} φ{d} ご指定の値（区分: 指定値）"
    else:
        allow_note = f"{m} φ{d} 標準値（区分: 確定値）"
    return {
        "allow_cell": result["allowable_kn"],
        "allow_note": allow_note,
        "sf_cell": result["safety_factor"],
        "sf_note": f"要求値 {inp.safety_factor_required}",
        "verdict_cell": result["verdict"],
        "verdict_note": jack_or_ok,
    }


def _write_allowable_notes(ws, r: int, inp: ThrustInput, result: dict, status: str) -> None:
    """判定の下に「許容押込力についての注意」を書く。どの工法の値が仮か・未登録かを日本語で示す。"""
    eng = _engine()
    table = eng.thrust_status_table()
    prov = [f"{m}（{'・'.join('φ%d' % x for x in table[m]['diameters'])}）"
            for m in table if table[m]["status"] == THRUST_PROVISIONAL]
    conf = [m for m in table if table[m]["status"] == THRUST_CONFIRMED]
    unreg = [m for m in table if table[m]["status"] == THRUST_UNREGISTERED]
    ws.cell(row=r, column=2, value="■ 許容押込力についての注意").font = Font(bold=True, size=12, color="C00000")
    r += 1
    thin = Side(style="thin", color="000000")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    if status == THRUST_PROVISIONAL:
        what = ("この計算書の許容押込力は「仮の値」です。仮の値とは、表に値はあるものの、工法の資料で確かめていない値のことです。"
                "確定するまでは参考の判定として扱い、施工可否はメーカーの技術資料でご確認ください。")
    else:
        what = ("この計算書は、許容押込力の値が表に無い（未登録）ため、安全率と施工可否を判定していません。"
                "当社は値を仮に置いて計算することはしません。メーカーの技術資料で許容押込力をご確認のうえ、値をお知らせください。")
    rows = [
        ("この計算書の区分", f"{status}（{inp.method} φ{inp.diameter_mm}）"),
        ("意味", what),
        ("仮の値の工法（この版）", "、".join(prov) if prov else "なし"),
        ("確定値の工法（この版）", "、".join(conf) if conf else "なし"),
        ("未登録の工法（この版）", ("、".join(unreg) + f"（{len(unreg)}工法）。" if unreg else "なし。")
         + "登録済みの工法でも、表に無い呼び径は未登録として扱います"),
    ]
    for k, v in rows:
        ws.cell(row=r, column=2, value=k).font = Font(bold=True)
        ws.cell(row=r, column=2).alignment = Alignment(wrap_text=True, vertical="center")
        ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=5)
        ws.cell(row=r, column=3, value=v).alignment = Alignment(wrap_text=True, vertical="center")
        for c in range(2, 6):
            ws.cell(row=r, column=c).border = border
        # 結合セルは Excel が行の高さを自動で決めないので、折り返しの行数ぶんを明示する
        ws.row_dimensions[r].height = _row_height(v, 60) or 18
        r += 1


def _write_table(ws, start_row, start_col, rows, border, hdr_fill, hdr_font):
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            c = ws.cell(row=start_row + i, column=start_col + j, value=val)
            c.border = border
            c.alignment = Alignment(vertical="center", wrap_text=True)
            if i == 0:
                c.fill = hdr_fill
                c.font = hdr_font
                c.alignment = Alignment(horizontal="center", vertical="center")


def main():
    if len(sys.argv) < 3:
        print("Usage: python3 gen_thrust_calc.py <input.json> <output.xlsx>")
        sys.exit(1)
    inp = ThrustInput.from_json(sys.argv[1])
    result = compute_thrust(inp)
    try:
        render_excel(inp, result, sys.argv[2])
    except ipguard_bridge.LicenseDenied as exc:
        # 承認実績の無い端末。計算書は書いていない (終了コード 3)
        print(ipguard_bridge.denied_message(exc), file=sys.stderr)
        sys.exit(3)
    print(json.dumps({"output": sys.argv[2], "result": result}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
