#!/usr/bin/env python3
"""レイアウトエンジン（実寸描画 → 用紙への自動フィット）

実CADのビューポートと同じ考え方で図面を組み立てる。

  1. 生成器は図形を **実寸mm** で描く（65mの管路なら 65000）
  2. ビューは内容の外接矩形を測り、JIS の標準縮尺に倣う値から**収まる最大の縮尺**を自動選定
  3. 注記文字は**紙面mm固定**でスケールしない（縮尺を変えても常に読める）
  4. 収まらなければ縮尺を一段落として再試行するため、図枠外へは構造的に出ない

従来は紙面mm直書き＋固定座標だったため、延長や深さが変わると図枠を突き破っていた。
"""
from __future__ import annotations

# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if __name__ == "__main__":
    import sys as _sl_trial_sys
    from pathlib import Path as _SlTrialPath
    _sl_trial_sys.path.insert(0, str((_SlTrialPath(__file__).resolve().parent / ".").resolve()))
    from _trial_guard import require_runtime as _require_trial_runtime
    _require_trial_runtime("suishin-drawing-engine")
# SOLOPTILINK-TRIAL-ENTRY:END



import math
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from textfit import Label, LabelPlacer, Rect, text_rect, text_width

# JIS Z 8311 の様式に倣う実用標準縮尺（分母）
# ★規格票の原典は未確認。JIS 準拠を保証する値ではない（本体方針・機械製図エンジンと同じ規律）
STANDARD_SCALES: List[float] = [
    1, 2, 5, 10, 20, 25, 30, 40, 50, 60, 80,
    100, 125, 150, 200, 250, 300, 400, 500, 600, 800,
    1000, 1250, 1500, 2000, 2500, 3000, 4000, 5000, 6000, 8000,
    10000, 12500, 15000, 20000, 25000, 50000, 100000,
]


def next_scale(current: float) -> float:
    """一段粗い（分母の大きい）標準縮尺を返す"""
    for s in STANDARD_SCALES:
        if s > current + 1e-9:
            return s
    return STANDARD_SCALES[-1]


# 希望縮尺が「収まる最大の縮尺」より何倍粗いところまで許すか。
# これを超えると図が用紙の中で小さくなりすぎるので、用紙を活かす側へ寄せる。
MAX_SCALE_WASTE = 2.5


def fit_scale(world_w: float, world_h: float,
              avail_w: float, avail_h: float,
              preferred: Optional[float] = None,
              lock: bool = False) -> float:
    """実寸(mm)を利用可能な紙面(mm)に収める標準縮尺を選ぶ。

    - 収まらない希望縮尺は必ず粗くする（図枠外へ出さないため）
    - 希望縮尺が粗すぎて図が紙面で小さくなりすぎる場合も、用紙を活かす縮尺へ寄せる
    - lock=True のときは希望縮尺を必ず守る（複数ビューの縮尺を揃える用途）
    """
    if world_w <= 0 and world_h <= 0:
        return preferred or 1
    need = max(
        world_w / avail_w if avail_w > 0 else float("inf"),
        world_h / avail_h if avail_h > 0 else float("inf"),
    )
    # 収まる最大の縮尺（＝紙面をいちばん使う縮尺）
    best = math.ceil(need)
    for s in STANDARD_SCALES:
        if s >= need:
            best = s
            break
    if not preferred:
        return best
    if lock:
        return preferred
    if preferred < need:
        return best                      # 収まらない希望は却下
    if preferred / best <= MAX_SCALE_WASTE:
        return preferred                 # 標準的な縮尺指定として尊重
    return best                          # 粗すぎるので用紙を活かす


@dataclass
class Panel:
    """紙面上の配置枠（すべて紙面mm）"""
    name: str
    x: float
    y: float
    w: float
    h: float
    title: str = ""

    @property
    def rect(self) -> Rect:
        return Rect(self.x, self.y, self.x + self.w, self.y + self.h)

    def inset(self, m: float) -> "Panel":
        return Panel(self.name, self.x + m, self.y + m,
                     max(self.w - 2 * m, 1.0), max(self.h - 2 * m, 1.0), self.title)


# ---- 遅延描画プリミティブ（実寸mm） ----

@dataclass
class _Prim:
    kind: str
    args: tuple
    layer: str
    kw: dict = field(default_factory=dict)


@dataclass
class _Dim:
    p1: Tuple[float, float]
    p2: Tuple[float, float]
    orient: str            # "h" | "v"
    offset_mm: float       # 紙面mm（離れ）
    text: Optional[str]
    layer: str
    outside: bool = False  # True なら図形全体の外側に寸法線を出す


class View:
    """実寸で描いた内容を、指定パネルへ自動縮尺で配置するビュー"""

    def __init__(self, panel: Panel, preferred_scale: Optional[float] = None,
                 pad_mm: float = 4.0, title: str = "",
                 title_height: float = 3.5, lock_scale: bool = False):
        self.panel = panel
        self.preferred_scale = preferred_scale
        # True にすると希望縮尺を必ず守る（平面図と断面図の縮尺を揃えるときに使う）
        self.lock_scale = lock_scale
        self.pad_mm = pad_mm
        self.title = title
        self.title_height = title_height
        self.prims: List[_Prim] = []
        self.dims: List[_Dim] = []
        self.labels: List[dict] = []
        self.scale: Optional[float] = None
        self._tf: Optional[Callable] = None

    # --- 図形（実寸mm） ---
    def line(self, p1, p2, layer: str = "0-OUTLINE") -> None:
        self.prims.append(_Prim("line", (p1, p2), layer))

    def polyline(self, pts, layer: str = "0-OUTLINE", close: bool = False) -> None:
        self.prims.append(_Prim("polyline", (list(pts),), layer, {"close": close}))

    def rect(self, x1, y1, x2, y2, layer: str = "0-OUTLINE") -> None:
        self.polyline([(x1, y1), (x2, y1), (x2, y2), (x1, y2)], layer, close=True)

    def circle(self, c, r: float, layer: str = "0-OUTLINE") -> None:
        self.prims.append(_Prim("circle", (c, r), layer))

    def arc(self, c, r: float, a1: float, a2: float, layer: str = "0-OUTLINE") -> None:
        self.prims.append(_Prim("arc", (c, r, a1, a2), layer))

    def hatch_rect(self, x1, y1, x2, y2, pattern: str = "ANSI31",
                   layer: str = "4-HATCH", pattern_scale: float = 1.0) -> None:
        self.prims.append(_Prim("hatch_rect", (x1, y1, x2, y2), layer,
                                {"pattern": pattern, "pattern_scale": pattern_scale}))

    def hatch_poly(self, pts, pattern: str = "ANSI31",
                   layer: str = "4-HATCH", pattern_scale: float = 1.0,
                   holes=None) -> None:
        self.prims.append(_Prim("hatch_poly", (list(pts),), layer,
                                {"pattern": pattern, "pattern_scale": pattern_scale,
                                 "holes": [list(h) for h in (holes or [])]}))

    def hatch_ring(self, c, r_outer: float, r_inner: float,
                   pattern: str = "ANSI31", layer: str = "4-HATCH",
                   pattern_scale: float = 1.0) -> None:
        """円環ハッチ（人孔壁体・坑口改良範囲など）。半径は実寸mm。"""
        self.prims.append(_Prim("hatch_ring", (c, r_outer, r_inner), layer,
                                {"pattern": pattern, "pattern_scale": pattern_scale}))

    # --- 注記（実寸アンカー ＋ 紙面mmの文字高） ---
    def label(self, text: str, world_pt, height: float = 2.5,
              layer: str = "3-TEXT", align: str = "l_b",
              dx: float = 0.0, dy: float = 0.0,
              movable: bool = True, priority: int = 5) -> None:
        """world_pt を指す注記。dx/dy は紙面mmの微調整。"""
        self.labels.append(dict(text=text, pt=world_pt, height=height, layer=layer,
                                align=align, dx=dx, dy=dy,
                                movable=movable, priority=priority))

    def dim(self, p1, p2, orient: str = "h", offset_mm: float = 10.0,
            text: Optional[str] = None, layer: str = "2-DIM",
            outside: bool = False) -> None:
        """寸法（実寸の2点間・寸法線の離れは紙面mm）

        outside=True にすると、図形全体の外側に寸法線を出す。
        円の直径のように、測る2点が図形の内側にある寸法で使う
        （そうしないと寸法線が図形を横切って読みにくくなる）。
        """
        self.dims.append(_Dim(tuple(p1), tuple(p2), orient, offset_mm, text,
                              layer, outside))

    # --- 内部: 外接矩形 ---
    def _geom_bbox(self) -> Optional[Rect]:
        xs: List[float] = []
        ys: List[float] = []

        def add(x, y):
            xs.append(x)
            ys.append(y)

        for p in self.prims:
            if p.kind == "line":
                (x1, y1), (x2, y2) = p.args[0], p.args[1]
                add(x1, y1)
                add(x2, y2)
            elif p.kind in ("polyline", "hatch_poly"):
                for pt in p.args[0]:
                    add(pt[0], pt[1])
            elif p.kind == "circle":
                (cx, cy), r = p.args[0], p.args[1]
                add(cx - r, cy - r)
                add(cx + r, cy + r)
            elif p.kind == "arc":
                (cx, cy), r = p.args[0], p.args[1]
                add(cx - r, cy - r)
                add(cx + r, cy + r)
            elif p.kind == "hatch_rect":
                x1, y1, x2, y2 = p.args
                add(x1, y1)
                add(x2, y2)
            elif p.kind == "hatch_ring":
                (cx, cy), ro = p.args[0], p.args[1]
                add(cx - ro, cy - ro)
                add(cx + ro, cy + ro)
        for d in self.dims:
            add(*d.p1)
            add(*d.p2)
        for lb in self.labels:
            add(lb["pt"][0], lb["pt"][1])
        if not xs:
            return None
        return Rect(min(xs), min(ys), max(xs), max(ys))

    def _annotation_reserve(self) -> Tuple[float, float, float, float]:
        """注記・寸法のために各辺へ確保する紙面mm (左,下,右,上)"""
        l = b = r = t = self.pad_mm
        for d in self.dims:
            need = d.offset_mm + 4.0
            if d.orient == "h":
                b = max(b, need)
            else:
                l = max(l, need)
        # 注記の最大文字高ぶんは上下に確保
        if self.labels:
            hmax = max(lb["height"] for lb in self.labels)
            t = max(t, hmax * 2.2)
            b = max(b, hmax * 2.2)
        if self.title:
            t = max(t, self.title_height * 2.4)
        return l, b, r, t

    # --- 配置確定 ---
    def resolve_scale(self) -> float:
        bb = self._geom_bbox()
        if bb is None:
            self.scale = self.preferred_scale or 1
            return self.scale
        l, b, r, t = self._annotation_reserve()
        avail_w = max(self.panel.w - l - r, 1.0)
        avail_h = max(self.panel.h - b - t, 1.0)
        self.scale = fit_scale(bb.w, bb.h, avail_w, avail_h,
                               self.preferred_scale, lock=self.lock_scale)
        return self.scale

    def _make_transform(self) -> Callable[[Sequence[float]], Tuple[float, float]]:
        bb = self._geom_bbox()
        s = self.scale or 1
        l, b, r, t = self._annotation_reserve()
        if bb is None:
            ox, oy = self.panel.x + l, self.panel.y + b
            wx0 = wy0 = 0.0
        else:
            draw_w = bb.w / s
            draw_h = bb.h / s
            inner_w = self.panel.w - l - r
            inner_h = self.panel.h - b - t
            ox = self.panel.x + l + max(0.0, (inner_w - draw_w) / 2)
            oy = self.panel.y + b + max(0.0, (inner_h - draw_h) / 2)
            wx0, wy0 = bb.x1, bb.y1

        def tf(pt):
            return (ox + (pt[0] - wx0) / s, oy + (pt[1] - wy0) / s)

        return tf

    def emit(self, builder, placer: Optional[LabelPlacer] = None) -> dict:
        """builder（紙面mmで描くDXFビルダー）へ実体を書き出す"""
        self.resolve_scale()
        tf = self._make_transform()
        self._tf = tf
        s = self.scale or 1

        for p in self.prims:
            if p.kind == "line":
                builder.line(tf(p.args[0]), tf(p.args[1]), p.layer)
            elif p.kind == "polyline":
                builder.polyline([tf(pt) for pt in p.args[0]], p.layer,
                                 close=p.kw.get("close", False))
            elif p.kind == "circle":
                c = tf(p.args[0])
                builder.circle(c, p.args[1] / s, p.layer)
            elif p.kind == "arc":
                c = tf(p.args[0])
                builder.arc(c, p.args[1] / s, p.args[2], p.args[3], p.layer)
            elif p.kind == "hatch_rect":
                x1, y1, x2, y2 = p.args
                a = tf((x1, y1))
                b2 = tf((x2, y2))
                builder.hatch_rectangle(a[0], a[1], b2[0], b2[1],
                                        pattern=p.kw.get("pattern", "ANSI31"),
                                        layer=p.layer,
                                        scale=p.kw.get("pattern_scale", 1.0))
            elif p.kind == "hatch_poly":
                builder.hatch_polygon([tf(pt) for pt in p.args[0]],
                                      pattern=p.kw.get("pattern", "ANSI31"),
                                      layer=p.layer,
                                      scale=p.kw.get("pattern_scale", 1.0),
                                      holes=[[tf(pt) for pt in hole]
                                             for hole in p.kw.get("holes") or []])
            elif p.kind == "hatch_ring":
                c = tf(p.args[0])
                builder.hatch_ring(c, p.args[1] / s, p.args[2] / s,
                                   pattern=p.kw.get("pattern", "ANSI31"),
                                   layer=p.layer,
                                   scale=p.kw.get("pattern_scale", 1.0))

        # 寸法（紙面mmで実体化するため縮尺に影響されない）
        gbb = self._geom_bbox()
        pbb = None
        if gbb is not None:
            lo = tf((gbb.x1, gbb.y1))
            hi = tf((gbb.x2, gbb.y2))
            pbb = Rect(lo[0], lo[1], hi[0], hi[1])
        for d in self.dims:
            a = tf(d.p1)
            b2 = tf(d.p2)
            off = d.offset_mm
            if d.outside and pbb is not None:
                # 図形の外側へ寸法線を逃がす（測る点が図形の内側にある場合）
                if d.orient == "h":
                    off = min(a[1], b2[1]) - (pbb.y1 - d.offset_mm)
                else:
                    off = min(a[0], b2[0]) - (pbb.x1 - d.offset_mm)
                off = max(off, d.offset_mm)
            builder.dim_paper(a, b2, orient=d.orient, offset=off,
                              text=d.text, layer=d.layer)

        # 見出しは図形の直上に置く（パネル隅だと図と離れて対応が分からなくなる）
        if self.title:
            bb = self._geom_bbox()
            if bb is not None:
                a = tf((bb.x1, bb.y2))
                tx, ty = a[0], a[1] + self.title_height * 0.9
                ty = min(ty, self.panel.y + self.panel.h - self.title_height)
            else:
                tx = self.panel.x + 1.0
                ty = self.panel.y + self.panel.h - self.title_height
            builder.text_aligned(self.title, (tx, ty), self.title_height, "3-TEXT", "l_b")
            # 見出しは動かさない代わりに障害物として登録する。
            # ここを登録しないと、注記が見出しの上に乗って文字被りになる。
            if placer is not None:
                placer.add_obstacle(
                    text_rect(self.title, tx, ty, self.title_height, "l_b"))

        # 注記は衝突回避に載せる
        out_labels = []
        for lb in self.labels:
            px, py = tf(lb["pt"])
            out_labels.append(Label(
                text=lb["text"], x=px + lb["dx"], y=py + lb["dy"],
                height=lb["height"], layer=lb["layer"], align=lb["align"],
                priority=lb["priority"], movable=lb["movable"],
            ))
        if placer is not None:
            for l in out_labels:
                placer.add(l)
        else:
            for l in out_labels:
                builder.text_aligned(l.text, (l.x, l.y), l.height, l.layer, l.align)

        return {"panel": self.panel.name, "scale": s,
                "labels": len(out_labels), "prims": len(self.prims)}


def split_rows(panel: Panel, ratios: Sequence[float], gap: float = 4.0,
               names: Optional[Sequence[str]] = None) -> List[Panel]:
    """パネルを上から下へ比率分割する"""
    total = sum(ratios)
    n = len(ratios)
    avail = panel.h - gap * (n - 1)
    out: List[Panel] = []
    y = panel.y + panel.h
    for i, rr in enumerate(ratios):
        h = avail * rr / total
        y -= h
        nm = names[i] if names and i < len(names) else f"{panel.name}-r{i}"
        out.append(Panel(nm, panel.x, y, panel.w, h))
        y -= gap
    return out


def split_cols(panel: Panel, ratios: Sequence[float], gap: float = 4.0,
               names: Optional[Sequence[str]] = None) -> List[Panel]:
    """パネルを左から右へ比率分割する"""
    total = sum(ratios)
    n = len(ratios)
    avail = panel.w - gap * (n - 1)
    out: List[Panel] = []
    x = panel.x
    for i, rr in enumerate(ratios):
        w = avail * rr / total
        nm = names[i] if names and i < len(names) else f"{panel.name}-c{i}"
        out.append(Panel(nm, x, panel.y, w, panel.h))
        x += w + gap
    return out


if __name__ == "__main__":
    # 自己テスト: 縮尺選定と分割
    assert fit_scale(65000, 800, 700, 300) == 100, fit_scale(65000, 800, 700, 300)
    assert fit_scale(88500, 900, 700, 300) == 150, fit_scale(88500, 900, 700, 300)
    # 希望縮尺が収まるなら尊重
    assert fit_scale(5000, 4000, 700, 300, preferred=50) == 50
    # 収まらない希望縮尺は自動で粗くする
    assert fit_scale(65000, 800, 700, 300, preferred=20) == 100
    p = Panel("main", 0, 0, 800, 500)
    rows = split_rows(p, [2, 1])
    assert abs(rows[0].h + rows[1].h + 4 - 500) < 1e-6
    cols = split_cols(p, [1, 1, 1])
    assert len(cols) == 3
    print("縮尺選定 65m→1/100 / 88.5m→1/150 / 希望尊重 / 自動粗化 すべてOK")
    print("[layout] self-test OK")
