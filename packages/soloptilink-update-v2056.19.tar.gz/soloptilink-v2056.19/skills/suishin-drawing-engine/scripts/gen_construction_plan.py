#!/usr/bin/env python3
"""施工計画書（本編）Excel 自動生成
☆施工計画書フォルダのマスターXLSXに準拠した項目立てで、
案件パラメータから章立て・数値表・工程表を自動展開する
"""
from __future__ import annotations

# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if __name__ == "__main__":
    import sys as _sl_trial_sys
    from pathlib import Path as _SlTrialPath
    _sl_trial_sys.path.insert(0, str((_SlTrialPath(__file__).resolve().parent / ".").resolve()))
    from _trial_guard import require_runtime as _require_trial_runtime
    _require_trial_runtime("suishin-drawing-engine")
# SOLOPTILINK-TRIAL-ENTRY:END


import json
import sys
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

import ipguard_bridge  # ご利用確認と出所の印 (書き出しの直前で必ず通す)


def _hdr_style(ws, cell, color="1F4E79"):
    cell.fill = PatternFill("solid", fgColor=color)
    cell.font = Font(bold=True, color="FFFFFF", size=11)
    cell.alignment = Alignment(horizontal="center", vertical="center")


def _border_all(ws, r1, c1, r2, c2):
    thin = Side(style="thin", color="000000")
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            ws.cell(row=r, column=c).border = Border(left=thin, right=thin, top=thin, bottom=thin)


CHAPTERS = [
    "1. 工事概要",
    "2. 現場組織表",
    "3. 実施工程表",
    "4. 施工方法",
    "5. 使用機械・設備",
    "6. 安全衛生管理",
    "7. 品質管理計画",
    "8. 環境対策",
    "9. 緊急時対応",
    "10. 完成検査要領",
]


def render(data: dict, out_path: str) -> None:
    wb = Workbook()
    ws0 = wb.active
    ws0.title = "表紙"

    # --- 表紙 ---
    ws0.column_dimensions["B"].width = 30
    ws0.column_dimensions["C"].width = 50
    ws0.merge_cells("B2:C4")
    ws0["B2"] = f"{data['project_name']}\n\n施工計画書"
    ws0["B2"].font = Font(bold=True, size=22, color="1F4E79")
    ws0["B2"].alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws0["B6"] = "発注者"; ws0["C6"] = data.get("client", "")
    ws0["B7"] = "施工者"; ws0["C7"] = data.get("designer", "")
    ws0["B8"] = "工事場所"; ws0["C8"] = data.get("site_address", "")
    ws0["B9"] = "工期"; ws0["C9"] = data.get("construction_period", "")
    ws0["B10"] = "工法"; ws0["C10"] = f"{data.get('method', '')} φ{data.get('diameter_mm', '')}mm"
    ws0["B11"] = "推進延長"; ws0["C11"] = f"{data.get('length_m', 0)}m"
    ws0["B12"] = "現場代理人"; ws0["C12"] = data.get("agent", "")
    ws0["B13"] = "作成日"; ws0["C13"] = data.get("date", "")
    for r in range(6, 14):
        ws0.cell(row=r, column=2).font = Font(bold=True)
        ws0.cell(row=r, column=2).fill = PatternFill("solid", fgColor="DDEBF7")
    _border_all(ws0, 6, 2, 13, 3)

    # 目次
    ws0["B16"] = "【 目 次 】"
    ws0["B16"].font = Font(bold=True, size=14, color="1F4E79")
    for i, ch in enumerate(CHAPTERS):
        ws0.cell(row=17 + i, column=2, value=ch).font = Font(size=11)
        ws0.cell(row=17 + i, column=3, value=f"シート「{ch.split('.')[0]}」参照").font = Font(size=10, color="808080")

    # --- 各章シート ---
    _sheet_1_overview(wb, data)
    _sheet_2_organization(wb, data)
    _sheet_3_schedule(wb, data)
    _sheet_4_method(wb, data)
    _sheet_5_equipment(wb, data)
    _sheet_6_safety(wb, data)
    _sheet_7_quality(wb, data)
    _sheet_8_environment(wb, data)
    _sheet_9_emergency(wb, data)
    _sheet_10_inspection(wb, data)

    # ご利用確認 (IP-057)。通らなければ LicenseDenied を投げ、計画書は書かない。
    lic = ipguard_bridge.require_license(ipguard_bridge.STAGE_XLSX)
    # 出所の印はブックのプロパティにだけ入れる (セルの値・数式・書式は 1 つも変えない)
    origin = ipguard_bridge.stamp_workbook(wb, lic, drawing_no=data.get("drawing_no", ""))
    wb.save(out_path)
    ipguard_bridge.stamp_xlsx_company(out_path, origin.get("_mark") or {})


def _write_kv_table(ws, title, rows, start_row=2):
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 25
    ws.column_dimensions["C"].width = 55
    ws["B" + str(start_row)] = title
    ws["B" + str(start_row)].font = Font(bold=True, size=14, color="1F4E79")
    r = start_row + 2
    for k, v in rows:
        ws.cell(row=r, column=2, value=k).font = Font(bold=True)
        ws.cell(row=r, column=2).fill = PatternFill("solid", fgColor="DDEBF7")
        ws.cell(row=r, column=3, value=v)
        ws.cell(row=r, column=3).alignment = Alignment(vertical="center", wrap_text=True)
        r += 1
    _border_all(ws, start_row + 2, 2, r - 1, 3)


def _sheet_1_overview(wb, data):
    ws = wb.create_sheet("1")
    _write_kv_table(ws, "1. 工事概要", [
        ("工事名", data.get("project_name", "")),
        ("発注者", data.get("client", "")),
        ("施工者", data.get("designer", "")),
        ("工事場所", data.get("site_address", "")),
        ("工期", data.get("construction_period", "")),
        ("工事内容", f"{data.get('method', '')} φ{data.get('diameter_mm', '')} L={data.get('length_m', 0)}m"),
        ("推進工法", data.get("method", "")),
        ("呼び径", f"φ{data.get('diameter_mm', 0)}mm"),
        ("推進延長", f"{data.get('length_m', 0)}m"),
        ("土質", data.get("soil", "粘性土")),
        ("土被り", f"{data.get('depth_m', 5)}m"),
        ("曲線", "あり" if data.get("curve_present") else "なし（直線推進）"),
        ("立坑構成", f"発進立坑1箇所・到達立坑1箇所"),
        ("契約金額", data.get("contract_amount", "非開示")),
    ])


def _sheet_2_organization(wb, data):
    ws = wb.create_sheet("2")
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 25
    ws.column_dimensions["C"].width = 25
    ws.column_dimensions["D"].width = 25
    ws.column_dimensions["E"].width = 25
    ws["B2"] = "2. 現場組織表"
    ws["B2"].font = Font(bold=True, size=14, color="1F4E79")

    r = 4
    headers = ["役職", "氏名", "資格", "業務内容"]
    for i, h in enumerate(headers):
        c = ws.cell(row=r, column=2 + i, value=h)
        _hdr_style(ws, c)

    org = data.get("organization", [
        {"role": "現場代理人", "name": data.get("agent", ""), "cert": "1級土木施工管理技士",
         "duty": "現場統括・発注者対応"},
        {"role": "監理技術者", "name": data.get("supervisor", ""), "cert": "1級土木施工管理技士",
         "duty": "施工計画・品質・安全管理"},
        {"role": "推進工事主任", "name": "", "cert": "推進工事管理技士", "duty": "推進施工管理"},
        {"role": "測量担当", "name": "", "cert": "測量士補", "duty": "測量・線形管理"},
        {"role": "安全管理者", "name": "", "cert": "安全管理士", "duty": "安全衛生管理"},
    ])
    for i, m in enumerate(org):
        ws.cell(row=r + 1 + i, column=2, value=m.get("role", ""))
        ws.cell(row=r + 1 + i, column=3, value=m.get("name", ""))
        ws.cell(row=r + 1 + i, column=4, value=m.get("cert", ""))
        ws.cell(row=r + 1 + i, column=5, value=m.get("duty", ""))
    _border_all(ws, r, 2, r + len(org), 5)


def _sheet_3_schedule(wb, data):
    ws = wb.create_sheet("3")
    ws["B2"] = "3. 実施工程表"
    ws["B2"].font = Font(bold=True, size=14, color="1F4E79")
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 25
    for c in range(3, 15):
        ws.column_dimensions[get_column_letter(c)].width = 6

    stages = [
        ("準備工", 1, 2),
        ("仮設工（立坑掘削）", 2, 5),
        ("坑口改良工", 5, 6),
        ("掘進機組立・据付", 6, 7),
        ("推進工（本体）", 7, 10),
        ("到達立坑掘削", 8, 11),
        ("坑口・人孔築造", 11, 12),
        ("復旧工", 12, 13),
        ("後片付け・検査", 13, 14),
    ]
    r = 4
    ws.cell(row=r, column=2, value="工種")
    _hdr_style(ws, ws.cell(row=r, column=2))
    for w in range(1, 15):
        c = ws.cell(row=r, column=2 + w, value=f"{w}W")
        _hdr_style(ws, c)
    for i, (name, start, end) in enumerate(stages):
        rr = r + 1 + i
        ws.cell(row=rr, column=2, value=name)
        for w in range(start, end + 1):
            cell = ws.cell(row=rr, column=2 + w, value="■")
            cell.fill = PatternFill("solid", fgColor="4472C4")
            cell.font = Font(color="4472C4")  # 見えないように
    _border_all(ws, r, 2, r + len(stages), 16)


def _sheet_4_method(wb, data):
    ws = wb.create_sheet("4")
    _write_kv_table(ws, "4. 施工方法", [
        ("採用工法", data.get("method", "")),
        ("工法概要",
         f"{data.get('method', '')}は、鉄筋コンクリート管を油圧ジャッキで推進する非開削工法。"
         f"適用口径 φ{data.get('diameter_mm', 0)}、推進延長 {data.get('length_m', 0)}m を1スパンで施工する。"),
        ("掘進機型式", data.get("machine_type", "")),
        ("推進管仕様", f"鉄筋コンクリート管 呼び径 {data.get('diameter_mm', 0)}mm  管長 2.43m（曲線部 1.0m/0.6m 併用）"),
        ("推進順序",
         "①発進立坑掘削 → ②坑口改良 → ③掘進機据付 → ④推進管接続・推進 → "
         "⑤到達立坑掘削 → ⑥掘進機回収 → ⑦坑口・人孔築造"),
        ("曲線施工", f"最小曲線半径 R={data.get('min_curve_radius_m', 30)}m を短管（1.0m/0.6m）併用で対応"),
        ("測量方法", "レーザートランシットによる方向制御・電磁位置計測併用"),
        ("排土処理", "泥濃式による排土。プラント経由で分離・産廃処理"),
        ("裏込め", "スーパーソイル系裏込め材を継手部より加圧注入"),
        ("滑材注入", "混合済み滑材（普通土用/粘性土用）を推進中に注入し摩擦低減"),
    ])


def _sheet_5_equipment(wb, data):
    ws = wb.create_sheet("5")
    ws["B2"] = "5. 使用機械・設備"
    ws["B2"].font = Font(bold=True, size=14, color="1F4E79")
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 25
    ws.column_dimensions["C"].width = 30
    ws.column_dimensions["D"].width = 15
    ws.column_dimensions["E"].width = 30
    r = 4
    for i, h in enumerate(["名称", "仕様", "台数", "用途"]):
        _hdr_style(ws, ws.cell(row=r, column=2 + i, value=h))
    equipment = data.get("equipment_list", [
        {"name": "掘進機", "spec": data.get("machine_type", "DL35C"), "count": 1, "usage": "推進本体"},
        {"name": "元押ジャッキ", "spec": "500kN×4本", "count": 1, "usage": "推進力供給"},
        {"name": "泥水プラント", "spec": "泥濃式 20㎥/h", "count": 1, "usage": "排土分離"},
        {"name": "クレーン", "spec": "ラフター 25t", "count": 1, "usage": "資機材揚重"},
        {"name": "発電機", "spec": "150kVA", "count": 1, "usage": "電源供給"},
        {"name": "コンプレッサ", "spec": "3.7kW", "count": 1, "usage": "圧気・工具"},
        {"name": "レーザートランシット", "spec": "測量精度±5mm", "count": 1, "usage": "方向管理"},
        {"name": "電磁位置計測装置", "spec": "深度10mまで", "count": 1, "usage": "曲線管理"},
    ])
    for i, eq in enumerate(equipment):
        ws.cell(row=r + 1 + i, column=2, value=eq["name"])
        ws.cell(row=r + 1 + i, column=3, value=eq["spec"])
        ws.cell(row=r + 1 + i, column=4, value=eq["count"])
        ws.cell(row=r + 1 + i, column=5, value=eq["usage"])
    _border_all(ws, r, 2, r + len(equipment), 5)


def _sheet_6_safety(wb, data):
    ws = wb.create_sheet("6")
    _write_kv_table(ws, "6. 安全衛生管理", [
        ("安全目標", "労働災害ゼロ・第三者災害ゼロ"),
        ("安全管理体制", "統括安全衛生責任者：現場代理人／安全管理者：常駐"),
        ("有害ガス対策", "H2S/CO/O2/CH4 の連続測定器を坑内配置・警報時退避訓練実施"),
        ("酸欠防止", "坑内換気ファン常時稼働・酸素濃度18%以上維持"),
        ("交通対策", "工事看板・警備員配置（両端各2名）・夜間バリケード"),
        ("KY活動", "毎朝礼にてリスクアセスメント・当日作業KY実施"),
        ("労働安全教育", "新規入場者教育・特別教育（酸欠・玉掛け・アーク溶接等）"),
        ("第三者対策", "騒音振動測定（近隣配慮）・粉塵飛散防止散水"),
        ("消防計画", "消火器3基以上配置・非常時避難経路明示"),
    ])


def _sheet_7_quality(wb, data):
    ws = wb.create_sheet("7")
    _write_kv_table(ws, "7. 品質管理計画", [
        ("推進精度", f"線形精度：中心線±{data.get('accuracy_center_mm', 50)}mm 以内、"
                      f"高さ精度：±{data.get('accuracy_height_mm', 30)}mm 以内"),
        ("推進管検査", "管受入時に外観検査・寸法検査・強度試験成績書確認"),
        ("継手止水", "継手部Oリング取付・裏込め注入後の漏水試験実施"),
        ("測量頻度", "1本推進毎に線形・高さ測量・記録"),
        ("推力管理", "元押ジャッキ推力を推進中連続監視・許容値超過時は滑材追加注入"),
        ("裏込め注入管理", "注入圧・注入量を連続記録"),
        ("完成検査", "推進完了後：内部検査（テレビカメラ）・水密試験・水準測量"),
        ("使用材料検査", "スーパーソイル・滑材・シール材の受入検査（成分表・SDS確認）"),
    ])


def _sheet_8_environment(wb, data):
    ws = wb.create_sheet("8")
    _write_kv_table(ws, "8. 環境対策", [
        ("騒音対策", "騒音規制法遵守（85dB以下）・低騒音型機械採用・防音シート設置"),
        ("振動対策", "振動規制法遵守（75dB以下）・重機作業時間帯配慮（8:00-17:00）"),
        ("粉塵対策", "散水頻度 3回/日・作業車両タイヤ洗浄"),
        ("排水対策", "泥水は沈殿槽で処理後、下水道排除基準遵守（pH5.8-8.6・SS200以下）"),
        ("廃棄物処理", "産業廃棄物マニフェスト管理・電子マニフェスト対応"),
        ("CO2削減", "アイドリングストップ徹底・エコドライブ研修"),
        ("周辺配慮", "工事看板による事前周知・苦情窓口設置"),
    ])


def _sheet_9_emergency(wb, data):
    ws = wb.create_sheet("9")
    _write_kv_table(ws, "9. 緊急時対応", [
        ("連絡体制", "現場→現場代理人→本社→発注者 の3系統確立"),
        ("緊急連絡先",
         "消防119／警察110／病院：最寄り救急指定病院／ガス漏れ：ガス会社緊急窓口／"
         "電力：電力会社緊急窓口／水道：水道局緊急窓口"),
        ("災害時対応",
         "地震：作業中断・安全確認後継続判断／豪雨：立坑内水位監視・排水ポンプ稼働／"
         "台風：仮設物撤去・機械格納"),
        ("坑内事故対応", "退避経路確保・救護員配置・SCBA（自給式呼吸器）2基配備"),
        ("漏水・出水対応", "止水袋・薬液注入により止水／地表沈下発生時は即時薬液注入"),
        ("報告義務", "重大事故発生時は発注者・監督員に30分以内に第一報"),
    ])


def _sheet_10_inspection(wb, data):
    ws = wb.create_sheet("10")
    _write_kv_table(ws, "10. 完成検査要領", [
        ("検査時期", "工程末（推進完了・立坑復旧完了時）"),
        ("検査項目",
         "① 推進線形（中心線・高さ）／② 継手部止水／③ 管内清掃状態／"
         "④ 人孔・坑口の仕上げ／⑤ 復旧舗装／⑥ 各種書類"),
        ("線形測定", "1本毎の水準測量記録を集約・許容値内であることを確認"),
        ("止水試験", "各人孔間で水張り試験（水頭圧h=3m×30分保持）"),
        ("テレビカメラ検査", "推進管全長の内面検査・目地部を含む記録映像を提出"),
        ("提出書類",
         "① 施工計画書／② 施工日報／③ 測量記録／④ 推力記録／"
         "⑤ 材料承認願／⑥ 完成図（DXF＋PDF）／⑦ テレビカメラDVD／"
         "⑧ 品質管理記録／⑨ 安全管理記録／⑩ 環境測定記録"),
        ("引渡し", "検査合格後、鍵・関連書類・保証書を発注者に引渡"),
        ("保証期間", "瑕疵担保責任期間 2年間"),
    ])


def main():
    if len(sys.argv) < 3:
        print("Usage: gen_construction_plan.py <input.json> <output.xlsx>")
        sys.exit(1)
    data = json.load(open(sys.argv[1], encoding="utf-8"))
    try:
        render(data, sys.argv[2])
    except ipguard_bridge.LicenseDenied as exc:
        # 承認実績の無い端末。計画書は書いていない (終了コード 3)
        print(ipguard_bridge.denied_message(exc), file=sys.stderr)
        sys.exit(3)
    print(json.dumps({"output": sys.argv[2], "sheets": len(CHAPTERS) + 1},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
