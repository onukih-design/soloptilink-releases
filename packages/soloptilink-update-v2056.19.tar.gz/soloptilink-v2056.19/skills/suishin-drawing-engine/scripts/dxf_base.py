#!/usr/bin/env python3
"""DXF生成の共通基盤
標準作図ルール（レイヤ命名・線種・図枠・寸法スタイル）に統一

v2 の方針転換（文字被り・図枠はみ出しの根絶）:
  - 図形は View（layout.py）に実寸で描き、用紙へ自動縮尺で配置する
  - 注記文字はすべて紙面mm固定。縮尺の影響を受けない
  - 寸法は紙面mmの実体線分として描く。DIMSCALE 倍率による巨大化が起きない
  - 全注記は LabelPlacer を通し、重なりを解消してから書き出す
"""
from __future__ import annotations

# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if __name__ == "__main__":
    import sys as _sl_trial_sys
    from pathlib import Path as _SlTrialPath
    _sl_trial_sys.path.insert(0, str((_SlTrialPath(__file__).resolve().parent / ".").resolve()))
    from _trial_guard import require_runtime as _require_trial_runtime
    _require_trial_runtime("suishin-drawing-engine")
# SOLOPTILINK-TRIAL-ENTRY:END



import math
from datetime import datetime
from typing import Iterable, List, Optional, Sequence, Tuple

import ezdxf
from ezdxf.enums import TextEntityAlignment

import ipguard_bridge
import standards_disclosure
from layout import Panel, View
from textfit import Label, LabelPlacer, Rect, text_rect, text_width

# --- 標準レイヤ定義（AutoCAD Color Index） ---
STANDARD_LAYERS = {
    "0-OUTLINE":    {"color": 7, "lineweight": 50,  "desc": "外形線 (太線)"},
    "1-CENTER":     {"color": 1, "lineweight": 18,  "desc": "中心線 (赤・一点鎖線)", "linetype": "CENTER"},
    "2-DIM":        {"color": 4, "lineweight": 13,  "desc": "寸法線 (シアン)"},
    "3-TEXT":       {"color": 7, "lineweight": 18,  "desc": "文字"},
    "4-HATCH":      {"color": 8, "lineweight": 9,   "desc": "ハッチング (グレー)"},
    "5-FRAME":      {"color": 7, "lineweight": 50,  "desc": "図枠 (太線)"},
    "6-LEGEND":     {"color": 7, "lineweight": 18,  "desc": "凡例"},
    "7-EXISTING":   {"color": 8, "lineweight": 13,  "desc": "既設 (グレー・点線)", "linetype": "DASHED"},
    "8-PROPOSED":   {"color": 3, "lineweight": 25,  "desc": "計画 (緑)"},
    "9-DIM-TEXT":   {"color": 2, "lineweight": 18,  "desc": "寸法文字 (黄)"},
    "10-GRID":      {"color": 8, "lineweight": 5,   "desc": "格子 (グレー細)"},
    "11-PIPE":      {"color": 5, "lineweight": 35,  "desc": "推進管 (青・太)"},
    "12-CURVE":     {"color": 6, "lineweight": 25,  "desc": "曲線部 (マゼンタ)"},
    "13-JOINT":     {"color": 2, "lineweight": 18,  "desc": "継手位置 (黄)"},
    "14-SHAFT":     {"color": 3, "lineweight": 50,  "desc": "立坑 (緑・太)"},
    "15-GROUND":    {"color": 8, "lineweight": 13,  "desc": "地盤"},
    "16-WATER":     {"color": 5, "lineweight": 13,  "desc": "地下水位 (青)", "linetype": "DASHED"},
    "17-DIM-NET":   {"color": 4, "lineweight": 9,   "desc": "寸法補助線 (シアン細)"},
}

# --- 標準用紙寸法 (mm) ---
PAPER_SIZES = {
    "A0": (1189, 841),
    "A1": (841, 594),
    "A2": (594, 420),
    "A3": (420, 297),
    "A4": (297, 210),
}

TITLE_BLOCK_WIDTH = 180   # 標準タイトルブロック幅 (mm)
TITLE_BLOCK_HEIGHT = 46   # 標準タイトルブロック高さ (mm)
MARGIN_LEFT = 25          # とじ代
MARGIN_OTHER = 10

# JIS Z 8313 に沿う推奨文字高（紙面mm）
TH_TINY = 1.8
TH_SMALL = 2.5
TH_BODY = 3.5
TH_HEAD = 5.0

_ALIGN_MAP = {
    "l_b": TextEntityAlignment.BOTTOM_LEFT,
    "c_b": TextEntityAlignment.BOTTOM_CENTER,
    "r_b": TextEntityAlignment.BOTTOM_RIGHT,
    "l_m": TextEntityAlignment.MIDDLE_LEFT,
    "c_m": TextEntityAlignment.MIDDLE_CENTER,
    "r_m": TextEntityAlignment.MIDDLE_RIGHT,
    "l_t": TextEntityAlignment.TOP_LEFT,
    "c_t": TextEntityAlignment.TOP_CENTER,
    "r_t": TextEntityAlignment.TOP_RIGHT,
}


def fit_height(s: str, max_w: float, height: float, min_height: float = 1.6) -> float:
    """指定幅に収まるよう文字高を落とす（枠からの文字あふれ防止）"""
    if not s:
        return height
    w = text_width(s, height)
    if w <= max_w:
        return height
    return max(min_height, height * max_w / w)


def _fit_view_to_extents(doc):
    """CAD で開いた直後に図面全体が見えるよう、範囲と最初の表示窓を描いた図形に合わせる。

    ezdxf の既定のままだと範囲 ($EXTMIN/$EXTMAX) は未設定 (±1e20)、モデル空間の
    表示窓 (VPORT *Active) は中心 (0,0)・高さ 1000 のままで、図面がこの窓に入らないと
    開いた直後に一部しか見えない・空白に見えることがある (2026-10-27 の確認)。
    書き換えるのは範囲 (見出しとモデル空間の配置情報) と表示窓の中心・高さだけで、
    図形・画層・出所の印・図形の並び順には触らない。保存の直前 (出所の印を刻んだ後) に呼ぶ。
    失敗しても書き出しは止めない (表示の初期値が既定のまま残るだけ)。
    """
    try:
        import ezdxf.bbox
        msp = doc.modelspace()
        box = ezdxf.bbox.extents(msp, fast=True)
        if not box.has_data:
            return
        lo, hi = box.extmin, box.extmax
        ext_min, ext_max = (lo.x, lo.y, lo.z), (hi.x, hi.y, hi.z)
        # ezdxf は保存のたびに見出しの範囲をモデル空間の配置情報の範囲で上書きするので、両方に入れる
        msp.dxf.extmin, msp.dxf.extmax = ext_min, ext_max
        doc.header["$EXTMIN"], doc.header["$EXTMAX"] = ext_min, ext_max
        # 高さは横幅からも決める (横縦比 4:3 に近い狭い画面でも左右が切れない)。周りに 5% の余白
        height = max(hi.y - lo.y, (hi.x - lo.x) / 1.3, 1.0) * 1.05
        center = ((lo.x + hi.x) / 2.0, (lo.y + hi.y) / 2.0)
        vports = list(doc.viewports.get_config("*Active"))
        plain = all(tuple(v.dxf.get("direction", (0, 0, 1))) == (0, 0, 1)
                    and tuple(v.dxf.get("target", (0, 0, 0))) == (0, 0, 0)
                    and not v.dxf.get("view_twist", 0) for v in vports)
        if vports and plain:
            # 既存の表示窓の中心と高さだけを書き換える (元図面の座標系の設定は残す)
            for v in vports:
                v.dxf.center = center
                v.dxf.height = height
        else:
            # 表示窓が無い・立体の向きやねじれが付いている → 真上から見る表示窓 1 枚に置き換える
            doc.set_modelspace_vport(height, center)
    except Exception as exc:  # noqa: BLE001  表示の初期値のための処理で書き出しを止めない
        import sys
        sys.stderr.write("注意: CAD で開いたときの表示範囲を設定できませんでした (%s)。"
                         "図面の中身はそのまま書き出します。\n" % type(exc).__name__)


class OgumiDXF:
    """標準作図ルール準拠 DXFビルダー（紙面mmで描く）"""

    def __init__(self, paper: str = "A1", scale: float = 100.0,
                 title: str = "", drawing_no: str = "", project: str = "",
                 client: str = "", designer: str = "",
                 date: str = "", extra_meta: Optional[dict] = None):
        if paper not in PAPER_SIZES:
            raise ValueError(f"未対応の用紙サイズ: {paper}")
        self.paper = paper
        self.paper_w, self.paper_h = PAPER_SIZES[paper]
        self.scale = scale          # 希望縮尺（View が収まらなければ自動で粗くする）
        self.title = title
        self.drawing_no = drawing_no
        self.project = project
        self.client = client
        self.designer = designer
        self.date = date or datetime.now().strftime("%Y-%m-%d")
        self.extra_meta = extra_meta or {}

        self.doc = ezdxf.new(dxfversion="R2018", setup=True)
        self.msp = self.doc.modelspace()
        self._setup_layers()
        self._setup_textstyles()
        self._setup_dimstyle()

        # 注記の衝突回避は図面全体で1つの配置器が受け持つ
        self.placer = LabelPlacer(bounds=self.sheet_rect(), gap=1.0)
        self.view_scales: List[float] = []
        self._finished = False
        self._disclosure_lines = 0

    # ---------------- 初期化 ----------------
    def _setup_layers(self) -> None:
        for lt in ("CENTER", "DASHED", "DASHDOT", "PHANTOM", "HIDDEN"):
            if lt not in self.doc.linetypes:
                try:
                    self.doc.linetypes.new(name=lt, dxfattribs={"description": lt, "pattern": ""})
                except Exception:
                    pass
        for name, attr in STANDARD_LAYERS.items():
            if name in self.doc.layers:
                continue
            kw = {"color": attr["color"], "lineweight": attr["lineweight"]}
            if "linetype" in attr and attr["linetype"] in self.doc.linetypes:
                kw["linetype"] = attr["linetype"]
            self.doc.layers.add(name, **kw)

    def _setup_textstyles(self) -> None:
        for st in ("JIS", "TITLE"):
            if st not in self.doc.styles:
                self.doc.styles.new(st, dxfattribs={"font": "msgothic.ttc", "width": 1.0})

    def _setup_dimstyle(self) -> None:
        s = "SUISHIN"
        if s in self.doc.dimstyles:
            return
        dim = self.doc.dimstyles.new(s)
        # 図形も注記も紙面mmで描くため、DIMSCALE は必ず 1.0。
        # ここに縮尺値を入れると寸法文字・矢印が縮尺倍に巨大化する（v1の重大欠陥）。
        dim.dxf.dimscale = 1.0
        dim.dxf.dimtxsty = "JIS"
        dim.dxf.dimtxt = TH_SMALL
        dim.dxf.dimasz = 2.0
        dim.dxf.dimexo = 0.625
        dim.dxf.dimexe = 1.25
        dim.dxf.dimtad = 1
        dim.dxf.dimdec = 0
        dim.dxf.dimzin = 8

    # ---------------- 用紙・パネル ----------------
    def sheet_rect(self) -> Rect:
        """図枠内の全域（紙面mm）"""
        return Rect(MARGIN_LEFT, MARGIN_OTHER,
                    self.paper_w - MARGIN_OTHER, self.paper_h - MARGIN_OTHER)

    def content_panel(self, pad: float = 6.0) -> Panel:
        """図形を配置できる領域（タイトルブロックを除く）"""
        r = self.sheet_rect()
        return Panel("content", r.x1 + pad, r.y1 + TITLE_BLOCK_HEIGHT + pad,
                     r.w - 2 * pad,
                     r.h - TITLE_BLOCK_HEIGHT - 2 * pad)

    def titleblock_rect(self) -> Rect:
        r = self.sheet_rect()
        return Rect(r.x2 - TITLE_BLOCK_WIDTH, r.y1, r.x2, r.y1 + TITLE_BLOCK_HEIGHT)

    # ---------------- 基本描画API（紙面mm） ----------------
    def line(self, p1, p2, layer: str = "0-OUTLINE") -> None:
        self.msp.add_line(p1, p2, dxfattribs={"layer": layer})

    def polyline(self, points: Iterable, layer: str = "0-OUTLINE", close: bool = False) -> None:
        pl = self.msp.add_lwpolyline(list(points), dxfattribs={"layer": layer})
        if close:
            pl.close(True)

    def circle(self, center, radius: float, layer: str = "0-OUTLINE") -> None:
        if radius <= 0:
            return
        self.msp.add_circle(center, radius, dxfattribs={"layer": layer})

    def arc(self, center, radius: float, start_deg: float, end_deg: float,
            layer: str = "0-OUTLINE") -> None:
        if radius <= 0:
            return
        self.msp.add_arc(center, radius, start_deg, end_deg, dxfattribs={"layer": layer})

    def text(self, s: str, insert, height: float = TH_SMALL, layer: str = "3-TEXT",
             rotation: float = 0.0,
             align: TextEntityAlignment = TextEntityAlignment.BOTTOM_LEFT) -> None:
        if s is None or s == "":
            return
        t = self.msp.add_text(
            str(s),
            dxfattribs={"layer": layer, "height": height, "style": "JIS", "rotation": rotation},
        )
        t.set_placement(insert, align=align)

    def text_aligned(self, s: str, insert, height: float = TH_SMALL,
                     layer: str = "3-TEXT", align: str = "l_b",
                     rotation: float = 0.0) -> None:
        self.text(s, insert, height, layer, rotation,
                  _ALIGN_MAP.get(align, TextEntityAlignment.BOTTOM_LEFT))

    def hatch_rectangle(self, x1, y1, x2, y2, pattern: str = "ANSI31",
                        layer: str = "4-HATCH", scale: float = 1.0) -> None:
        self.hatch_polygon([(x1, y1), (x2, y1), (x2, y2), (x1, y2)],
                           pattern=pattern, layer=layer, scale=scale)

    def hatch_polygon(self, pts, pattern: str = "ANSI31",
                      layer: str = "4-HATCH", scale: float = 1.0,
                      holes: Optional[Sequence[Sequence]] = None) -> None:
        """多角形ハッチ。holes を渡すと中抜き（環状）になる。

        人孔の壁体や坑口改良範囲のように「外形と内空の間だけを塗る」表現に使う。
        """
        pts = list(pts)
        if len(pts) < 3:
            return
        h = self.msp.add_hatch(dxfattribs={"layer": layer})
        try:
            h.set_pattern_fill(pattern, scale=scale)
        except Exception:
            h.set_pattern_fill("ANSI31", scale=scale)
        h.paths.add_polyline_path(pts, is_closed=True,
                                  flags=ezdxf.const.BOUNDARY_PATH_EXTERNAL)
        for hole in (holes or []):
            hole = list(hole)
            if len(hole) >= 3:
                h.paths.add_polyline_path(
                    hole, is_closed=True,
                    flags=ezdxf.const.BOUNDARY_PATH_OUTERMOST)
        # 入れ子境界を交互に塗る（中抜きが効く）
        h.dxf.hatch_style = 0

    def hatch_ring(self, center, r_outer: float, r_inner: float,
                   pattern: str = "ANSI31", layer: str = "4-HATCH",
                   scale: float = 1.0, segments: int = 72) -> None:
        """円環（ドーナツ）ハッチ。人孔壁体・坑口改良範囲などに使う。"""
        if r_outer <= 0:
            return
        r_inner = max(0.0, min(r_inner, r_outer))
        cx, cy = center[0], center[1]

        def ring(r):
            return [(cx + r * math.cos(2 * math.pi * i / segments),
                     cy + r * math.sin(2 * math.pi * i / segments))
                    for i in range(segments)]

        self.hatch_polygon(ring(r_outer), pattern, layer, scale,
                           holes=[ring(r_inner)] if r_inner > 0 else None)

    # ---------------- 寸法（紙面mmの実体線分） ----------------
    def dim_paper(self, p1, p2, orient: str = "h", offset: float = 10.0,
                  text: Optional[str] = None, layer: str = "2-DIM",
                  arrow: float = 2.0, height: float = TH_SMALL) -> None:
        """紙面mmの寸法を実体として描く。

        DXFのDIMENSIONエンティティは DIMSCALE の影響で巨大化しうるため、
        寸法線・補助線・矢羽・寸法値をすべて明示的な図形として描く。
        """
        (x1, y1), (x2, y2) = tuple(p1), tuple(p2)
        rot = 0.0
        if orient == "h":
            base = min(y1, y2) - offset
            self.line((x1, y1), (x1, base - 1.2), "17-DIM-NET")
            self.line((x2, y2), (x2, base - 1.2), "17-DIM-NET")
            self.line((x1, base), (x2, base), layer)
            self._arrow((x1, base), (1, 0), arrow, layer)
            self._arrow((x2, base), (-1, 0), arrow, layer)
            tx, ty = (x1 + x2) / 2, base + 0.9
            align = "c_b"
        else:
            base = min(x1, x2) - offset
            self.line((x1, y1), (base - 1.2, y1), "17-DIM-NET")
            self.line((x2, y2), (base - 1.2, y2), "17-DIM-NET")
            self.line((base, y1), (base, y2), layer)
            self._arrow((base, y1), (0, 1), arrow, layer)
            self._arrow((base, y2), (0, -1), arrow, layer)
            tx, ty = base - 0.9, (y1 + y2) / 2
            align = "c_b"
            rot = 90.0
        if text:
            self.text_aligned(text, (tx, ty), height, "9-DIM-TEXT", align, rotation=rot)
            # 寸法値は幾何が決める位置に固定なので動かさない。
            # 障害物として登録し、可動の注記側に避けさせる（登録漏れは文字被りになる）。
            self.placer.add_obstacle(
                text_rect(text, tx, ty, height, align, rotation=rot))

    def _arrow(self, tip, direction, size: float, layer: str) -> None:
        """寸法矢羽（塗り三角）"""
        dx, dy = direction
        bx, by = tip[0] + dx * size, tip[1] + dy * size
        px, py = -dy * size * 0.28, dx * size * 0.28
        pts = [tip, (bx + px, by + py), (bx - px, by - py)]
        try:
            h = self.msp.add_hatch(color=STANDARD_LAYERS[layer]["color"],
                                   dxfattribs={"layer": layer})
            h.paths.add_polyline_path(pts, is_closed=True)
        except Exception:
            self.polyline(pts, layer, close=True)

    # ---------------- ビュー配置 ----------------
    def place(self, view: View) -> dict:
        """View（実寸描画）を用紙へ自動縮尺で配置する"""
        info = view.emit(self, placer=self.placer)
        if view.scale:
            self.view_scales.append(view.scale)
        return info

    # ---------------- 表・凡例（紙面mm） ----------------
    def table(self, x: float, y: float, rows: Sequence[Sequence[str]],
              col_widths: Sequence[float], row_h: float = 5.0,
              height: float = 2.2, header: bool = True,
              layer: str = "5-FRAME", title: str = "",
              title_height: float = TH_BODY) -> Rect:
        """左上を (x, y) とする表を描く。戻り値は占有矩形（衝突回避の障害物になる）"""
        total_w = sum(col_widths)
        top = y
        if title:
            self.text_aligned(title, (x, y + 1.2), title_height, "3-TEXT", "l_b")
        cy = top
        for ri, row in enumerate(rows):
            cx = x
            for ci, cell in enumerate(row):
                cw = col_widths[ci] if ci < len(col_widths) else col_widths[-1]
                self.polyline([(cx, cy - row_h), (cx + cw, cy - row_h),
                               (cx + cw, cy), (cx, cy)], layer, close=True)
                s = "" if cell is None else str(cell)
                hh = fit_height(s, cw - 2.0, height)
                if header and ri == 0:
                    self.text_aligned(s, (cx + cw / 2, cy - row_h / 2), hh, "3-TEXT", "c_m")
                else:
                    self.text_aligned(s, (cx + 1.2, cy - row_h / 2), hh, "3-TEXT", "l_m")
                cx += cw
            cy -= row_h
        r = Rect(x, cy, x + total_w, top + (title_height + 1.5 if title else 0))
        self.placer.add_obstacle(r)
        return r

    def legend(self, x: float, y: float, entries: Sequence[Tuple[str, str]],
               height: float = TH_SMALL, title: str = "【凡例】") -> Rect:
        """凡例 [(レイヤ, 説明), ...]。左上を (x, y) とする。"""
        self.text_aligned(title, (x, y), TH_BODY, "6-LEGEND", "l_t")
        cy = y - TH_BODY - 2.5
        max_w = text_width(title, TH_BODY)
        for lyr, desc in entries:
            self.line((x + 1, cy), (x + 12, cy), lyr)
            self.text_aligned(desc, (x + 14, cy), height, "6-LEGEND", "l_m")
            max_w = max(max_w, 14 + text_width(desc, height))
            cy -= height + 2.0
        r = Rect(x, cy, x + max_w + 2, y + 1)
        self.placer.add_obstacle(r)
        return r

    def north_arrow(self, x: float, y: float, r: float = 8.0) -> Rect:
        """方位記号（北）"""
        self.circle((x, y), r, "3-TEXT")
        self.polyline([(x, y + r * 0.85), (x - r * 0.34, y - r * 0.5),
                       (x, y - r * 0.2), (x + r * 0.34, y - r * 0.5)],
                      "3-TEXT", close=True)
        self.text_aligned("N", (x, y + r + 1.0), TH_BODY, "3-TEXT", "c_b")
        rect = Rect(x - r, y - r, x + r, y + r + TH_BODY + 1.5)
        self.placer.add_obstacle(rect)
        return rect

    # ---------------- 図枠・タイトルブロック ----------------
    def draw_titleblock(self, extra_meta: Optional[dict] = None) -> None:
        w, h = self.paper_w, self.paper_h
        self.polyline(
            [(MARGIN_LEFT, MARGIN_OTHER), (w - MARGIN_OTHER, MARGIN_OTHER),
             (w - MARGIN_OTHER, h - MARGIN_OTHER), (MARGIN_LEFT, h - MARGIN_OTHER)],
            layer="5-FRAME", close=True,
        )
        tb = self.titleblock_rect()
        x0, y0 = tb.x1, tb.y1
        tb_w, tb_h = tb.w, tb.h
        self.polyline([(x0, y0), (x0 + tb_w, y0),
                       (x0 + tb_w, y0 + tb_h), (x0, y0 + tb_h)],
                      layer="5-FRAME", close=True)

        rows = 4
        rh = tb_h / rows
        label_w = 22.0
        for i in range(1, rows):
            self.line((x0, y0 + rh * i), (x0 + tb_w, y0 + rh * i), "5-FRAME")
        self.line((x0 + label_w, y0), (x0 + label_w, y0 + tb_h), "5-FRAME")
        self.line((x0 + label_w + (tb_w - label_w) * 0.42, y0),
                  (x0 + label_w + (tb_w - label_w) * 0.42, y0 + rh), "5-FRAME")
        self.line((x0 + label_w + (tb_w - label_w) * 0.70, y0),
                  (x0 + label_w + (tb_w - label_w) * 0.70, y0 + rh), "5-FRAME")

        val_x = x0 + label_w + 1.5
        val_w = tb_w - label_w - 3.0

        def row_center(i: int) -> float:
            return y0 + rh * i + rh / 2

        # 上から: 工事名 / 図面名 / 発注者・施工者 / 図面No・縮尺・日付
        self.text_aligned("工事名", (x0 + 1.5, row_center(3)), TH_SMALL, "3-TEXT", "l_m")
        self.text_aligned(self.project, (val_x, row_center(3)),
                          fit_height(self.project, val_w, TH_BODY), "3-TEXT", "l_m")

        self.text_aligned("図面名", (x0 + 1.5, row_center(2)), TH_SMALL, "3-TEXT", "l_m")
        self.text_aligned(self.title, (val_x, row_center(2)),
                          fit_height(self.title, val_w, TH_HEAD * 0.9), "3-TEXT", "l_m")

        self.text_aligned("発注者", (x0 + 1.5, row_center(1)), TH_SMALL, "3-TEXT", "l_m")
        who = self.client or ""
        if self.designer:
            who = f"{who}    施工: {self.designer}" if who else f"施工: {self.designer}"
        self.text_aligned(who, (val_x, row_center(1)),
                          fit_height(who, val_w, TH_SMALL), "3-TEXT", "l_m")

        self.text_aligned("図面No.", (x0 + 1.5, row_center(0)), TH_SMALL, "3-TEXT", "l_m")
        seg_w = (tb_w - label_w) * 0.42 - 3.0
        self.text_aligned(self.drawing_no or "-", (val_x, row_center(0)),
                          fit_height(self.drawing_no or "-", seg_w, TH_BODY), "3-TEXT", "l_m")
        sx = x0 + label_w + (tb_w - label_w) * 0.42 + 1.5
        s_lab = f"縮尺 {self.scale_label()}"
        self.text_aligned(s_lab, (sx, row_center(0)),
                          fit_height(s_lab, (tb_w - label_w) * 0.28 - 3.0, TH_SMALL),
                          "3-TEXT", "l_m")
        dx = x0 + label_w + (tb_w - label_w) * 0.70 + 1.5
        d_lab = f"{self.date}  {self.paper}"
        self.text_aligned(d_lab, (dx, row_center(0)),
                          fit_height(d_lab, (tb_w - label_w) * 0.30 - 3.0, TH_SMALL),
                          "3-TEXT", "l_m")

        # 補足事項はタイトルブロック直上に積む
        meta = dict(self.extra_meta)
        meta.update(extra_meta or {})
        if meta:
            y = y0 + tb_h + 2.0
            for k, v in meta.items():
                self.text_aligned(f"{k}: {v}", (x0, y), TH_SMALL, "3-TEXT", "l_b")
                y += TH_SMALL + 1.4
            self.placer.add_obstacle(Rect(x0 - 1, y0 + tb_h, x0 + tb_w, y + 1))

        self.placer.add_obstacle(tb.expand(0.5))

    # ---------------- 様式出典の開示注記 ----------------
    def draw_standards_disclosure(self) -> int:
        """様式（用紙・尺度・文字高・図枠・表題欄）の未確認を図面上へ開示する。

        置き場所は **図枠の外**（下側の余白帯）に固定する。図枠の中へ入れると
        レイアウトのフィット計算（layout.py）と干渉して図が縮むため。
        余白帯は LabelPlacer の bounds（= sheet_rect = 図枠内）にも含まれないので、
        既存の注記配置に影響しない。

        戻り値: 実際に描いた行数（0 なら開示できていない = 欠陥）。
        """
        lines = standards_disclosure.disclosure_lines_ja(
            max_chars=self._disclosure_wrap_chars())
        if not lines:
            return 0
        avail_w = self.paper_w - MARGIN_LEFT - MARGIN_OTHER
        y = 1.4
        drawn = 0
        # 下から上へ積むので、最終行が一番下に来るよう逆順に描く
        for s in reversed(lines):
            h = fit_height(s, avail_w, TH_TINY, min_height=1.5)
            self.text_aligned(s, (MARGIN_LEFT, y), h, "3-TEXT", "l_b")
            y += h + 0.6
            drawn += 1
        self._disclosure_lines = drawn
        return drawn

    def _disclosure_wrap_chars(self) -> int:
        """余白帯の幅に収まる1行あたりの文字数（全角基準・実測で決める）。"""
        avail_w = self.paper_w - MARGIN_LEFT - MARGIN_OTHER
        s = standards_disclosure.disclosure_ja()
        n = len(s)
        while n > 8:
            w = text_width(s[:n], TH_TINY)
            if w <= avail_w:
                break
            n -= 4
        return max(8, n)

    def scale_label(self) -> str:
        """実際に採用された縮尺の表示（複数あれば図中記載）"""
        uniq = sorted(set(self.view_scales))
        if not uniq:
            return f"1/{int(self.scale)}"
        if len(uniq) == 1:
            return f"1/{int(uniq[0])}"
        return "図中記載"

    # ---------------- 確定・保存 ----------------
    def finish(self, out_path: str) -> dict:
        """注記の衝突を解消し、図枠を描いて保存する"""
        if self._finished:
            raise RuntimeError("finish() は1度だけ呼べます")
        self._finished = True

        self.draw_titleblock()
        # 様式の出典が未確認である旨は、全図面に必ず載せる（黙らせない）
        disclosure_lines = self.draw_standards_disclosure()

        placed, unresolved = self.placer.resolve()
        for lb in placed:
            self.text_aligned(lb.text, (lb.x, lb.y), lb.height, lb.layer,
                              lb.align, rotation=lb.rotation)
            if lb.leader_to:
                self._leader(lb.leader_to, (lb.x, lb.y), lb.height, lb.layer)
        # 置けなかった注記も欠落させず、希望位置に小さく残す
        for lb in unresolved:
            self.text_aligned(lb.text, (lb.x, lb.y), lb.height, lb.layer, lb.align)

        # 用紙寸法を書き残す（レンダラ・検証が用紙範囲を正確に知るため）
        cv = self.doc.header.custom_vars
        cv.append("SUISHIN_PAPER", self.paper)
        cv.append("SUISHIN_PAPER_W", str(self.paper_w))
        cv.append("SUISHIN_PAPER_H", str(self.paper_h))
        cv.append("SUISHIN_SCALES", ",".join(str(int(s)) for s in sorted(set(self.view_scales))))
        # 検査が「開示が入ったか」を機械的に測れるようにする
        cv.append("SUISHIN_STD_UNCONFIRMED",
                  str(len(standards_disclosure.unconfirmed())))
        cv.append("SUISHIN_STD_DISCLOSED", "1" if disclosure_lines > 0 else "0")

        # ご利用確認 (IP-057)。止めるのは承認実績の無い端末だけ (ipguard_bridge 参照)。
        # 通らなければ LicenseDenied を投げ、ファイルは 1 枚も書かない。
        lic = ipguard_bridge.require_license(ipguard_bridge.STAGE_DXF)
        # 出所の印 (Ch-A 可視 / Ch-B 半可視 / Ch-C 出力順)。図形の座標は 1 つも変えない。
        origin = ipguard_bridge.stamp_dxf(self, lic)

        _fit_view_to_extents(self.doc)   # 開いた直後に図面全体が見える範囲と表示窓 (出所の印の後・保存の直前)
        self.doc.saveas(out_path)
        return {"output": out_path, "paper": self.paper,
                "scales": sorted(set(self.view_scales)),
                "labels_placed": len(placed),
                "labels_unresolved": len(unresolved),
                "standards_unconfirmed": len(standards_disclosure.unconfirmed()),
                "standards_disclosure_lines": disclosure_lines,
                "standards_disclosure_ja": standards_disclosure.disclosure_ja(),
                "出所の印": origin}

    def _leader(self, frm, to, height: float, layer: str) -> None:
        """退避した注記の引出線"""
        fx, fy = frm
        tx, ty = to
        if abs(tx - fx) < 1e-9 and abs(ty - fy) < 1e-9:
            return
        ang = math.atan2(ty - fy, tx - fx)
        bx = tx - math.cos(ang) * height * 0.4
        by = ty - math.sin(ang) * height * 0.4
        self.line((fx, fy), (bx, by), "17-DIM-NET")
        self.circle((fx, fy), height * 0.16, "17-DIM-NET")

    # 旧APIの互換
    def save(self, out_path: str) -> None:
        if not self._finished:
            self.finish(out_path)
        else:
            # 確定済みの図面を別名で書き出す経路にもご利用確認を通す (印は確定時に刻み済み)
            ipguard_bridge.require_license(ipguard_bridge.STAGE_DXF)
            _fit_view_to_extents(self.doc)   # 開いた直後に図面全体が見える範囲と表示窓 (出所の印の後・保存の直前)
            self.doc.saveas(out_path)

    def draw_legend(self, entries: list, x: float, y: float,
                    layer: str = "6-LEGEND") -> None:
        self.legend(x, y, [(l, d) for l, d in entries])


if __name__ == "__main__":
    import os
    import sys

    out = sys.argv[1] if len(sys.argv) > 1 else "/tmp/suishin_smoke.dxf"
    d = OgumiDXF(paper="A3", scale=100, title="スモークテスト",
                 drawing_no="000", project="疎通確認",
                 client="サンプル", designer="Suishin Drawing Engine")
    panel = d.content_panel()
    v = View(panel, preferred_scale=100, title="【試験図】")
    # 実寸mmで描く（20m × 6m の矩形）
    v.rect(0, 0, 20000, 6000, "0-OUTLINE")
    v.circle((10000, 3000), 2000, "1-CENTER")
    v.dim((0, 0), (20000, 0), orient="h", offset_mm=10, text="L=20.0m")
    v.dim((0, 0), (0, 6000), orient="v", offset_mm=10, text="W=6.0m")
    for i in range(5):
        v.label(f"注記{i}", (10000, 3000), TH_SMALL)   # 意図的に同一点へ重ねる
    d.place(v)
    res = d.finish(out)
    print(f"[smoke] saved: {out} ({os.path.getsize(out)} bytes) {res}")
    assert res["labels_unresolved"] == 0, "注記の衝突が解消できていない"
    assert d.doc.dimstyles.get("SUISHIN").dxf.dimscale == 1.0
    print("[dxf_base] self-test OK")
