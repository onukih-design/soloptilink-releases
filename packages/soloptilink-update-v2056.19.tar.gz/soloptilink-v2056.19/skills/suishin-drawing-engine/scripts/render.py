#!/usr/bin/env python3
"""DXF → PNG 検証レンダラ

生成した図面を実際に画像化して目視検証するための基盤。
ドクター機能・開発時の視覚確認の双方から使う。

モード:
  sheet : 用紙範囲だけを切り出す（印刷したときの見え方）
  full  : 全エンティティを表示し、用紙範囲を赤枠で重ねる（はみ出しの検出用）
"""
from __future__ import annotations

# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if __name__ == "__main__":
    import sys as _sl_trial_sys
    from pathlib import Path as _SlTrialPath
    _sl_trial_sys.path.insert(0, str((_SlTrialPath(__file__).resolve().parent / ".").resolve()))
    from _trial_guard import require_runtime as _require_trial_runtime
    _require_trial_runtime("suishin-drawing-engine")
# SOLOPTILINK-TRIAL-ENTRY:END



import os
import sys
from typing import Optional, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import Rectangle  # noqa: E402

import ezdxf  # noqa: E402
from ezdxf import bbox  # noqa: E402
from ezdxf.addons.drawing import Frontend, RenderContext  # noqa: E402
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend  # noqa: E402
from ezdxf.addons.drawing.config import Configuration  # noqa: E402
from ezdxf.addons.drawing.properties import LayoutProperties  # noqa: E402

import ipguard_bridge  # noqa: E402  ご利用確認と出所の印 (書き出しの直前で必ず通す)

# 日本語が豆腐にならないようフォントを明示（macOS/Linux 双方を想定）
_JP_CANDIDATES = [
    "Hiragino Kaku Gothic ProN",
    "Hiragino Sans",
    "Noto Sans CJK JP",
    "IPAGothic",
    "Yu Gothic",
    "Meiryo",
    "Arial Unicode MS",
    "DejaVu Sans",
]


def _setup_font() -> str:
    import matplotlib.font_manager as fm

    available = {f.name for f in fm.fontManager.ttflist}
    for name in _JP_CANDIDATES:
        if name in available:
            matplotlib.rcParams["font.family"] = [name]
            matplotlib.rcParams["axes.unicode_minus"] = False
            return name
    return matplotlib.rcParams["font.family"][0]


def paper_extents(doc) -> Optional[Tuple[float, float, float, float]]:
    """用紙範囲 (xmin, ymin, xmax, ymax) を返す。

    保存時に書き込んだカスタム変数を最優先し、無ければ図枠レイヤから推定する。
    """
    try:
        cv = doc.header.custom_vars
        w = float(cv.get("SUISHIN_PAPER_W"))
        h = float(cv.get("SUISHIN_PAPER_H"))
        return (0.0, 0.0, w, h)
    except Exception:
        pass
    # 旧世代DXF: 図枠レイヤの外接矩形から推定（余白を戻す）
    msp = doc.modelspace()
    frame = [e for e in msp if e.dxf.layer == "5-FRAME"]
    if not frame:
        return None
    try:
        b = bbox.extents(frame)
    except Exception:
        return None
    # 図枠は左25mm/他10mmの余白で描かれている前提
    return (b.extmin.x - 25.0, b.extmin.y - 10.0, b.extmax.x + 10.0, b.extmax.y + 10.0)


def render_dxf(dxf_path: str, png_path: str, mode: str = "full",
               dpi: int = 160, max_px: int = 2400) -> dict:
    """DXFを画像化する。戻り値は用紙範囲とはみ出し量の実測値。"""
    # ご利用確認 (IP-057)。通らなければ LicenseDenied を投げ、画像は書かない。
    lic = ipguard_bridge.require_license(ipguard_bridge.STAGE_PREVIEW)
    _setup_font()
    doc = ezdxf.readfile(dxf_path)
    msp = doc.modelspace()
    # 出所の印 (PNG の tEXt チャンク)。DXF に刻んだ印を引き継ぐ (無ければ作る)。
    mark = ipguard_bridge.mark_for_output(
        doc, os.path.basename(dxf_path), str(lic.get("watermark") or "unknown"))
    png_meta = ipguard_bridge.image_metadata(mark)

    paper = paper_extents(doc)
    try:
        content = bbox.extents(msp)
        cx1, cy1 = content.extmin.x, content.extmin.y
        cx2, cy2 = content.extmax.x, content.extmax.y
    except Exception:
        cx1 = cy1 = cx2 = cy2 = 0.0

    if mode == "sheet" and paper:
        vx1, vy1, vx2, vy2 = paper
    else:
        # full: 用紙と内容の和集合（はみ出しが見えるように少し余白）
        if paper:
            vx1, vy1 = min(paper[0], cx1), min(paper[1], cy1)
            vx2, vy2 = max(paper[2], cx2), max(paper[3], cy2)
        else:
            vx1, vy1, vx2, vy2 = cx1, cy1, cx2, cy2
        mx = max((vx2 - vx1) * 0.02, 5.0)
        vx1, vy1, vx2, vy2 = vx1 - mx, vy1 - mx, vx2 + mx, vy2 + mx

    vw = max(vx2 - vx1, 1e-6)
    vh = max(vy2 - vy1, 1e-6)

    # 画素数の上限を守りつつ縦横比を保つ
    fig_w = min(vw / 25.4, max_px / dpi)
    fig_h = fig_w * (vh / vw)
    if fig_h * dpi > max_px:
        fig_h = max_px / dpi
        fig_w = fig_h * (vw / vh)

    fig = plt.figure(figsize=(fig_w, fig_h), dpi=dpi)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("white")
    fig.patch.set_facecolor("white")

    ctx = RenderContext(doc)
    backend = MatplotlibBackend(ax)
    # 白背景を宣言しないと ACI=7（白/黒）が白のまま描かれ、図枠・文字が消える
    lp = LayoutProperties.from_layout(msp)
    lp.set_colors(bg="#FFFFFF")
    Frontend(ctx, backend, config=Configuration()).draw_layout(
        msp, finalize=False, layout_properties=lp
    )

    # 用紙範囲を赤破線で重ねる（はみ出しが一目で分かる）
    if paper and mode != "sheet":
        ax.add_patch(Rectangle(
            (paper[0], paper[1]), paper[2] - paper[0], paper[3] - paper[1],
            fill=False, edgecolor="red", linestyle="--", linewidth=1.2, zorder=1e6,
        ))

    ax.set_xlim(vx1, vx2)
    ax.set_ylim(vy1, vy2)
    ax.set_aspect("equal")
    ax.axis("off")
    os.makedirs(os.path.dirname(os.path.abspath(png_path)) or ".", exist_ok=True)
    fig.savefig(png_path, dpi=dpi, facecolor="white", metadata=png_meta)
    plt.close(fig)

    overflow = None
    if paper:
        overflow = {
            "left": round(max(0.0, paper[0] - cx1), 2),
            "bottom": round(max(0.0, paper[1] - cy1), 2),
            "right": round(max(0.0, cx2 - paper[2]), 2),
            "top": round(max(0.0, cy2 - paper[3]), 2),
        }
    return {
        "png": png_path,
        "paper": paper,
        "content": [round(cx1, 2), round(cy1, 2), round(cx2, 2), round(cy2, 2)],
        "overflow_mm": overflow,
        "出所の印": {"出所コード": mark.get("code") or "", "状態": mark.get("status")},
    }


def render_dir(dxf_dir: str, png_dir: str, mode: str = "full") -> list:
    import glob

    results = []
    for f in sorted(glob.glob(os.path.join(dxf_dir, "*.dxf"))):
        name = os.path.splitext(os.path.basename(f))[0]
        out = os.path.join(png_dir, f"{name}.png")
        try:
            results.append(render_dxf(f, out, mode=mode))
        except Exception as ex:  # 1枚失敗しても残りは描く
            results.append({"png": out, "error": f"{type(ex).__name__}: {ex}"})
    return results


# ============================================================
# PDF 出力 (lot19 第3回・2026-10-26 / 設計書19 W3-5)
#   図面 (DXF) は用紙の実寸 (mm) のページで書き出す (A1 なら 841x594mm)。印刷して縮尺が保たれる。
#   計算書・計画書 (xlsx) は表をそのまま A4 横のページに並べる (セルの文字を罫線つきで描く)。
#   どちらも書き出しの直前でご利用確認を通し、出所の印を PDF の文書情報に入れる (PNG と同じ規律)。
#   外部の変換ソフト (表計算ソフト等) は使わない (お客様の端末に入っているとは限らないため)。
# ============================================================
STAGE_PDF = getattr(ipguard_bridge, "STAGE_PDF", "suishin.pdf")


def _pdf_metadata(title: str, mark: dict) -> dict:
    """PDF の文書情報。出所の印 (可視の 1 行・半可視の値) を入れる。"""
    meta = ipguard_bridge.image_metadata(mark)
    return {
        "Title": title,
        "Creator": meta.get("Software") or "",
        "Subject": meta.get("Source") or "",
        "Keywords": meta.get("Source") or "",
    }


def render_pdf(dxf_path: str, pdf_path: str) -> dict:
    """DXF を用紙の実寸のページで PDF に書き出す。戻り値は用紙とページの実測値。"""
    lic = ipguard_bridge.require_license(STAGE_PDF)
    _setup_font()
    doc = ezdxf.readfile(dxf_path)
    msp = doc.modelspace()
    mark = ipguard_bridge.mark_for_output(
        doc, os.path.basename(dxf_path), str(lic.get("watermark") or "unknown"))

    paper = paper_extents(doc)
    if paper:
        vx1, vy1, vx2, vy2 = paper
    else:
        # 用紙が分からない図面は内容の外接矩形に余白を足す (縮尺の保証はしない)
        try:
            content = bbox.extents(msp)
            vx1, vy1 = content.extmin.x, content.extmin.y
            vx2, vy2 = content.extmax.x, content.extmax.y
        except Exception:
            vx1 = vy1 = 0.0
            vx2, vy2 = 420.0, 297.0
        mx = max((vx2 - vx1) * 0.02, 5.0)
        vx1, vy1, vx2, vy2 = vx1 - mx, vy1 - mx, vx2 + mx, vy2 + mx
    vw = max(vx2 - vx1, 1e-6)
    vh = max(vy2 - vy1, 1e-6)

    # 図面の座標は mm (推進工法図面エンジンの作図単位)。1 インチ = 25.4mm で実寸のページにする
    fig = plt.figure(figsize=(vw / 25.4, vh / 25.4))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("white")
    fig.patch.set_facecolor("white")
    ctx = RenderContext(doc)
    backend = MatplotlibBackend(ax)
    lp = LayoutProperties.from_layout(msp)
    lp.set_colors(bg="#FFFFFF")
    Frontend(ctx, backend, config=Configuration()).draw_layout(
        msp, finalize=False, layout_properties=lp
    )
    ax.set_xlim(vx1, vx2)
    ax.set_ylim(vy1, vy2)
    ax.set_aspect("equal")
    ax.axis("off")
    os.makedirs(os.path.dirname(os.path.abspath(pdf_path)) or ".", exist_ok=True)
    fig.savefig(pdf_path, format="pdf", facecolor="white",
                metadata=_pdf_metadata(os.path.splitext(os.path.basename(dxf_path))[0], mark))
    plt.close(fig)
    return {
        "pdf": pdf_path,
        "paper": paper,
        "page_mm": [round(vw, 1), round(vh, 1)],
        "実寸のページ": bool(paper),
        "出所の印": {"出所コード": mark.get("code") or "", "状態": mark.get("status")},
    }


# --- 表 (xlsx) の PDF 化 ---------------------------------------------
_A4_LANDSCAPE_MM = (297.0, 210.0)
_PAGE_MARGIN_MM = 12.0
_CELL_PAD_MM = 1.2
_TEXT_PT = 8.0
_TITLE_PT = 11.0


def _char_w_mm(ch: str, pt: float) -> float:
    """1 文字の幅の見積り (全角 = 文字の大きさ、半角 = その 0.55 倍)。"""
    em = pt * 25.4 / 72.0
    return em if ord(ch) > 0x2E7F else em * 0.55


def _wrap(text: str, width_mm: float, pt: float) -> list:
    """セルの幅で折り返した行の並び。改行はそのまま生かす。"""
    lines = []
    for para in str(text).split("\n"):
        cur, w = "", 0.0
        for ch in para:
            cw = _char_w_mm(ch, pt)
            if cur and w + cw > width_mm:
                lines.append(cur)
                cur, w = ch, cw
            else:
                cur += ch
                w += cw
        lines.append(cur)
    return lines or [""]


def _sheet_grid(ws):
    """シートの使われている範囲を (行の並び, 列数, 結合セル) に直す。"""
    max_r, max_c = ws.max_row, ws.max_column
    rows = []
    for r in range(1, max_r + 1):
        rows.append([ws.cell(row=r, column=c).value for c in range(1, max_c + 1)])
    merged = {}
    for rg in ws.merged_cells.ranges:
        merged[(rg.min_row, rg.min_col)] = (rg.max_row, rg.max_col)
    covered = set()
    for (r0, c0), (r1, c1) in merged.items():
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                if (r, c) != (r0, c0):
                    covered.add((r, c))
    return rows, max_c, merged, covered


def _col_widths_mm(ws, ncol: int, usable_mm: float) -> list:
    """列幅。表計算ソフトの列幅 (文字数) を比率として使い、用紙の幅に収める。"""
    from openpyxl.utils import get_column_letter

    raw = []
    for c in range(1, ncol + 1):
        w = ws.column_dimensions[get_column_letter(c)].width
        raw.append(float(w) if w else 10.0)
    total = sum(raw) or 1.0
    return [usable_mm * x / total for x in raw]


def xlsx_to_pdf(xlsx_path: str, pdf_path: str) -> dict:
    """計算書・計画書 (xlsx) を A4 横の PDF にする。シートごとに改ページし、溢れた行は次のページへ送る。"""
    from matplotlib.backends.backend_pdf import PdfPages
    import openpyxl

    lic = ipguard_bridge.require_license(STAGE_PDF)
    font = _setup_font()
    # 日本語の字体に無い記号 (≥ など) は欧文の字体で補う (豆腐にしない)
    matplotlib.rcParams["font.family"] = [font, "DejaVu Sans"]
    matplotlib.rcParams["pdf.fonttype"] = 42  # 文字を PDF に埋め込む (検索・文字の抜き出しができる)
    wb = openpyxl.load_workbook(xlsx_path)
    props = wb.properties
    meta = {
        "Title": os.path.splitext(os.path.basename(xlsx_path))[0],
        "Creator": str(props.description or ""),
        "Subject": str(props.keywords or ""),
        "Keywords": str(props.identifier or props.keywords or ""),
    }
    page_w, page_h = _A4_LANDSCAPE_MM
    usable_w = page_w - 2 * _PAGE_MARGIN_MM
    line_h = _TEXT_PT * 25.4 / 72.0 * 1.35
    pages = 0
    os.makedirs(os.path.dirname(os.path.abspath(pdf_path)) or ".", exist_ok=True)
    with PdfPages(pdf_path, metadata=meta) as pdf:
        for ws in wb.worksheets:
            rows, ncol, merged, covered = _sheet_grid(ws)
            widths = _col_widths_mm(ws, ncol, usable_w)
            xs = [_PAGE_MARGIN_MM]
            for w in widths:
                xs.append(xs[-1] + w)
            # 行ごとに高さを決める (折り返した行数の最大)
            layout = []
            for ri, row in enumerate(rows, start=1):
                cells, nlines = [], 1
                for ci, v in enumerate(row, start=1):
                    if (ri, ci) in covered:
                        continue
                    r1, c1 = merged.get((ri, ci), (ri, ci))
                    span_w = xs[c1] - xs[ci - 1]
                    text = "" if v is None else str(v)
                    lines = _wrap(text, max(span_w - 2 * _CELL_PAD_MM, 5.0), _TEXT_PT) if text else []
                    nlines = max(nlines, len(lines) if r1 == ri else 1)
                    cells.append((ci, c1, r1, lines))
                layout.append((ri, cells, nlines * line_h + 2 * _CELL_PAD_MM))

            def _new_page(title):
                fig = plt.figure(figsize=(page_w / 25.4, page_h / 25.4))
                ax = fig.add_axes([0, 0, 1, 1])
                ax.set_xlim(0, page_w)
                ax.set_ylim(page_h, 0)
                ax.axis("off")
                ax.text(_PAGE_MARGIN_MM, _PAGE_MARGIN_MM - 4.0, title, fontsize=_TITLE_PT, va="bottom")
                return fig, ax

            title = "%s ／ %s" % (meta["Title"], ws.title)
            fig, ax = _new_page(title)
            y = _PAGE_MARGIN_MM
            row_h = {}
            for ri, cells, h in layout:
                row_h[ri] = h
            for ri, cells, h in layout:
                if y + h > page_h - _PAGE_MARGIN_MM and y > _PAGE_MARGIN_MM:
                    pdf.savefig(fig)
                    plt.close(fig)
                    pages += 1
                    fig, ax = _new_page(title + " (続き)")
                    y = _PAGE_MARGIN_MM
                for ci, c1, r1, lines in cells:
                    x0, x1 = xs[ci - 1], xs[c1]
                    hh = sum(row_h.get(r, 0.0) for r in range(ri, r1 + 1))
                    ax.add_patch(Rectangle((x0, y), x1 - x0, hh, fill=False,
                                           edgecolor="#808080", linewidth=0.3))
                    for k, ln in enumerate(lines):
                        ax.text(x0 + _CELL_PAD_MM, y + _CELL_PAD_MM + (k + 0.8) * line_h, ln,
                                fontsize=_TEXT_PT, va="baseline")
                y += h
            # 出所の印 (表計算の文書情報に刻んだ 1 行) をページの下に小さく描く
            if meta["Creator"]:
                ax.text(_PAGE_MARGIN_MM, page_h - 4.0, meta["Creator"], fontsize=5.5, color="#606060")
            pdf.savefig(fig)
            plt.close(fig)
            pages += 1
    return {"pdf": pdf_path, "sheets": len(wb.worksheets), "pages": pages, "font": font,
            "ご利用確認": ipguard_bridge.license_summary(lic) if hasattr(ipguard_bridge, "license_summary") else None}


def main() -> None:
    import json

    if len(sys.argv) < 3:
        print("Usage: render.py <in.dxf|dir> <out.png|dir> [sheet|full]")
        sys.exit(1)
    src, dst = sys.argv[1], sys.argv[2]
    mode = sys.argv[3] if len(sys.argv) > 3 else "full"
    try:
        if os.path.isdir(src):
            res = render_dir(src, dst, mode)
        else:
            res = render_dxf(src, dst, mode)
    except ipguard_bridge.LicenseDenied as exc:
        # 承認実績の無い端末。画像は書いていない (終了コード 3)
        print(ipguard_bridge.denied_message(exc), file=sys.stderr)
        sys.exit(3)
    print(json.dumps(res, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
