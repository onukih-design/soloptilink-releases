#!/usr/bin/env python3
"""平面線形図（Alignment Drawing）自動生成
入力: 測量点座標列 (x, y: m単位) + 曲線条件
出力: 平面線形図 DXF

v2: 測量座標を実寸mm に変換して View へ渡す。縮尺は自動選定。
    IP 曲線部は BC/EC を算出して円弧折れ線で描く（bounding-box 膨張回避のため
    View.arc() ではなく polyline 近似を使用）。
"""
from __future__ import annotations

# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if __name__ == "__main__":
    import sys as _sl_trial_sys
    from pathlib import Path as _SlTrialPath
    _sl_trial_sys.path.insert(0, str((_SlTrialPath(__file__).resolve().parent / ".").resolve()))
    from _trial_guard import require_runtime as _require_trial_runtime
    _require_trial_runtime("suishin-drawing-engine")
# SOLOPTILINK-TRIAL-ENTRY:END



import json
import math
import sys
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from dxf_base import OgumiDXF, TH_TINY, TH_SMALL, TH_BODY, TH_HEAD
from layout import View, Panel, split_cols

# 測点マーカーサイズ（実寸mm）
MARKER_SIZE = 30   # 三角マーカーの半辺長（mm単位で実寸換算: 後で view に渡す）
# ただし測量座標は m 単位で入力されるため、mm 換算時: MARKER_SIZE = 30mm = 実際の 0.03m
# 縮尺 1/500 で 30mm → 0.06mm（紙上）… 小さすぎる。
# 実務では marker は紙面mmで固定サイズとするため label のみで表現する。


@dataclass
class SurveyPoint:
    id: str          # 例: "No.1", "IP1"
    x: float         # 東方向 (m)
    y: float         # 北方向 (m)
    z: Optional[float] = None  # 標高 (m)
    type: str = "point"        # "point"/"ip"/"start"/"end"/"bc"/"ec"


@dataclass
class AlignmentInput:
    project_name: str
    drawing_no: str
    client: str
    method: str
    points: List[SurveyPoint]
    curves: List[dict] = field(default_factory=list)   # [{"ip_id":"IP1", "radius_m":30}]
    paper: str = "A1"
    scale: float = 500.0
    designer: str = ""

    @classmethod
    def from_json(cls, path: str) -> "AlignmentInput":
        d = json.load(open(path, encoding="utf-8"))
        d["points"] = [SurveyPoint(**p) for p in d["points"]]
        return cls(**d)


# ============================================================
# 曲線計算
# ============================================================

def compute_curve(
    p_prev: Tuple[float, float],
    p_ip: Tuple[float, float],
    p_next: Tuple[float, float],
    R_mm: float,
) -> Optional[Tuple]:
    """IP 点前後の座標（mm）と半径（mm）から円弧パラメータを計算する。

    戻り値: (bc, ec, center, arc_a1_deg, arc_a2_deg) または None
    - bc, ec: BC・EC 点の座標（mm）
    - center: 円弧中心座標（mm）
    - arc_a1_deg, arc_a2_deg: ezdxf の CCW 弧 [start, end]（度）
      ezdxf arc は常に CCW なので、右折の場合は (a_ec, a_bc) の順にして
      同じ形状（90°弧など）を描く。
    """
    p_prev = (float(p_prev[0]), float(p_prev[1]))
    p_ip = (float(p_ip[0]), float(p_ip[1]))
    p_next = (float(p_next[0]), float(p_next[1]))

    dx1 = p_ip[0] - p_prev[0]
    dy1 = p_ip[1] - p_prev[1]
    dx2 = p_next[0] - p_ip[0]
    dy2 = p_next[1] - p_ip[1]

    d1 = math.hypot(dx1, dy1)
    d2 = math.hypot(dx2, dy2)
    if d1 < 1e-6 or d2 < 1e-6:
        return None

    t1x, t1y = dx1 / d1, dy1 / d1
    t2x, t2y = dx2 / d2, dy2 / d2

    cos_ia = max(-1.0, min(1.0, t1x * t2x + t1y * t2y))
    ia = math.acos(cos_ia)   # 偏角（ラジアン）: 入射方向と退出方向の差

    if ia < 1e-6:
        return None   # ほぼ直線: 曲線不要

    # 接線長 TL = R * tan(ia/2)
    TL = R_mm * math.tan(ia / 2)

    # 接線長が辺長を超える場合は 95% に制限
    TL_max = min(d1, d2) * 0.95
    if TL > TL_max:
        TL = TL_max

    # BC・EC 座標
    bc = (p_ip[0] - t1x * TL, p_ip[1] - t1y * TL)
    ec = (p_ip[0] + t2x * TL, p_ip[1] + t2y * TL)

    # 外積で旋回方向を判定
    cross = t1x * t2y - t1y * t2x

    # 円弧中心: BC から t1 の法線方向へ R
    if cross > 0:   # 左折（CCW）
        nx, ny = -t1y, t1x
    else:           # 右折（CW）
        nx, ny = t1y, -t1x

    center = (bc[0] + nx * R_mm, bc[1] + ny * R_mm)

    # 円弧の開始・終了角度
    def angle_deg(cx: float, cy: float, px: float, py: float) -> float:
        return math.degrees(math.atan2(py - cy, px - cx))

    a_bc = angle_deg(center[0], center[1], bc[0], bc[1])
    a_ec = angle_deg(center[0], center[1], ec[0], ec[1])

    # ezdxf は CCW のみ。左折は BC→EC が CCW、右折は EC→BC が CCW (同形状)。
    if cross > 0:
        arc_a1, arc_a2 = a_bc, a_ec
    else:
        arc_a1, arc_a2 = a_ec, a_bc

    return (bc, ec, center, arc_a1, arc_a2)


def arc_to_polyline(
    center: Tuple[float, float],
    R_mm: float,
    a1_deg: float,
    a2_deg: float,
    n_segs: int = 16,
) -> List[Tuple[float, float]]:
    """円弧を折れ線近似する（View.arc の bounding-box 膨張を避けるため）。

    View.arc() は内部で円全体の外接矩形を bbox に使うため、大半径・小偏角の
    曲線で bbox が過大になり縮尺が粗くなりすぎる。折れ線にすることで
    実際の弧区間だけが bbox に寄与する。
    """
    cx, cy = center
    a1 = math.radians(a1_deg)
    a2 = math.radians(a2_deg)

    # ezdxf CCW: a2 < a1 なら 360° ラップ
    if a2 <= a1:
        a2 += 2 * math.pi

    pts: List[Tuple[float, float]] = []
    for k in range(n_segs + 1):
        t = a1 + (a2 - a1) * k / n_segs
        pts.append((cx + R_mm * math.cos(t), cy + R_mm * math.sin(t)))
    return pts


def _choose_scalebar_m(scale: float) -> int:
    """採用縮尺に合わせて縮尺バーの代表距離（m）を選ぶ。
    紙面上で 30〜80mm 程度になる最小の候補を返す。
    """
    for m in [5, 10, 20, 50, 100, 200, 500, 1000]:
        pmm = m * 1000 / scale
        if 30 <= pmm <= 80:
            return m
    return 100


# ============================================================
# 外部 API
# ============================================================

def draw_alignment(inp: AlignmentInput, out_path: str) -> dict:
    """平面線形図を生成し DXF ファイルへ保存する。

    戻り値: {"output": out_path, "points": n_points, "curves": n_curves}
    外部契約（引数・戻り値キー）は suishin.py の依存に合わせて不変とする。
    """
    d = OgumiDXF(
        paper=inp.paper,
        scale=inp.scale,
        title=f"平面線形図（{inp.method}）",
        drawing_no=inp.drawing_no,
        project=inp.project_name,
        client=inp.client,
        designer=inp.designer,
    )

    # ── 測量座標 m → mm 変換 ──
    # View は実寸mmで受け取る。測量座標 (m) × 1000 → mm。
    coords: Dict[str, Tuple[float, float]] = {
        p.id: (p.x * 1000.0, p.y * 1000.0) for p in inp.points
    }

    # ── IP ごとの曲線パラメータを計算 ──
    ip_r_map: Dict[str, float] = {
        c["ip_id"]: c["radius_m"] * 1000.0 for c in inp.curves
    }
    curve_info: Dict[str, tuple] = {}  # ip_id → (bc, ec, center, a1, a2)

    for i, pt in enumerate(inp.points):
        if pt.id not in ip_r_map:
            continue
        if i == 0 or i == len(inp.points) - 1:
            continue
        result = compute_curve(
            coords[inp.points[i - 1].id],
            coords[pt.id],
            coords[inp.points[i + 1].id],
            ip_r_map[pt.id],
        )
        if result:
            curve_info[pt.id] = result

    # ── レイアウト: 左 3/4 = 線形図、右 1/4 = 表・方位 ──
    main = d.content_panel()
    draw_panel, table_panel = split_cols(
        main, [3, 1], gap=4, names=["alignment", "table"]
    )

    # ── 線形図 View ──
    v = View(draw_panel, preferred_scale=inp.scale,
             title=f"【平面線形図（{inp.method}）】")

    # ---- 中心線（直線部 + IP 曲線部） ----
    prev_exit: Optional[Tuple[float, float]] = None

    for i, pt in enumerate(inp.points):
        cur = coords[pt.id]
        if i == 0:
            prev_exit = cur
            continue

        if pt.id in curve_info:
            # 曲線区間: prev_exit → BC（直線）→ 弧（BC to EC）
            bc, ec, center, a1, a2 = curve_info[pt.id]
            R = ip_r_map[pt.id]

            # BC までの直線
            if prev_exit is not None and math.dist(prev_exit, bc) > 1.0:
                v.line(prev_exit, bc, "1-CENTER")

            # BC/EC マーカー（小さい十字: 縦横 1mm は紙面mm のため label を使う）
            # arc を polyline 近似することで bbox 膨張を防ぐ
            n_segs = max(8, int(abs(a2 - a1) / 5) + 1)
            arc_pts = arc_to_polyline(center, R, a1, a2, n_segs=n_segs)
            v.polyline(arc_pts, "12-CURVE")

            prev_exit = ec
        else:
            # 直線区間 または IP を通過する折れ線
            if prev_exit is not None:
                v.line(prev_exit, cur, "1-CENTER")
            prev_exit = cur

    # ---- 測点マーカー・注記 ----
    # マーカーは紙面mm で固定サイズにしたいが、View は実寸mm なので
    # ラベルの三角記号をテキスト文字（△）で代替する。
    # 座標値・標高は字数が多いので priority を低めにして退避可とする。
    bc_ids = {pt_id: curve_info[pt_id][0] for pt_id in curve_info}   # ip_id → BC 座標
    ec_ids = {pt_id: curve_info[pt_id][1] for pt_id in curve_info}   # ip_id → EC 座標

    for pt in inp.points:
        xy = coords[pt.id]

        if pt.id in curve_info:
            # IP 点: BC・EC に加えて注記
            bc, ec, _ctr, _a1, _a2 = curve_info[pt.id]
            R_m = ip_r_map[pt.id] / 1000.0

            # IP 点マーカー（○）
            v.label(f"○IP {pt.id}", xy, TH_SMALL, "12-CURVE",
                    align="l_b", dy=3.0, priority=4)
            v.label(f"R={R_m:.0f}m", xy, TH_TINY, "12-CURVE",
                    align="l_t", dy=-3.0, priority=6)

            # BC 注記
            v.label(f"BC", bc, TH_TINY, "12-CURVE",
                    align="c_b", dy=2.0, priority=7)
            # EC 注記
            v.label(f"EC", ec, TH_TINY, "12-CURVE",
                    align="c_b", dy=2.0, priority=7)
        else:
            # 通常測点
            # 測点 ID（優先度高め）
            v.label(f"△{pt.id}", xy, TH_SMALL, "3-TEXT",
                    align="l_b", dy=3.0, priority=3)

        # 座標値・標高（字数が多いため movable で逃がせるよう priority を低く）
        coord_str = f"({pt.x:.2f}, {pt.y:.2f})"
        v.label(coord_str, xy, TH_TINY, "3-TEXT",
                align="l_t", dy=-3.0, priority=8)
        if pt.z is not None:
            v.label(f"H={pt.z:.2f}m", xy, TH_TINY, "3-TEXT",
                    align="l_t", dy=-5.5, priority=9)

    # ---- 配置・縮尺取得 ----
    info = d.place(v)
    adopted_scale = info["scale"]  # 実際に採用された縮尺の分母

    # ---- 縮尺バー（紙面mm で描く）----
    bar_m = _choose_scalebar_m(adopted_scale)
    bar_pmm = bar_m * 1000 / adopted_scale   # 紙面mm
    sb_x = draw_panel.x + 6
    sb_y = draw_panel.y + 14
    d.line((sb_x, sb_y), (sb_x + bar_pmm, sb_y), "3-TEXT")
    d.line((sb_x, sb_y - 2), (sb_x, sb_y + 2), "3-TEXT")
    d.line((sb_x + bar_pmm, sb_y - 2), (sb_x + bar_pmm, sb_y + 2), "3-TEXT")
    # 中間目盛
    half = bar_pmm / 2
    d.line((sb_x + half, sb_y - 1), (sb_x + half, sb_y + 1), "3-TEXT")
    d.text_aligned("0", (sb_x, sb_y + 2.5), TH_TINY, "3-TEXT", "c_b")
    d.text_aligned(f"{bar_m // 2}m", (sb_x + half, sb_y + 2.5), TH_TINY, "3-TEXT", "c_b")
    d.text_aligned(f"{bar_m}m", (sb_x + bar_pmm, sb_y + 2.5), TH_TINY, "3-TEXT", "c_b")
    d.text_aligned(f"縮尺  1 / {int(adopted_scale)}",
                   (sb_x, sb_y - 5), TH_SMALL, "3-TEXT", "l_b")

    # ── 右パネル: 方位記号 ──
    north_x = table_panel.x + table_panel.w / 2
    north_y = table_panel.y + table_panel.h - 18
    d.north_arrow(north_x, north_y, r=8.0)

    # ── 右パネル: 測点一覧表 ──
    table_rows = [["測点 ID", "X(m)", "Y(m)", "標高(m)"]]
    for pt in inp.points:
        z_str = f"{pt.z:.2f}" if pt.z is not None else "―"
        table_rows.append([pt.id, f"{pt.x:.2f}", f"{pt.y:.2f}", z_str])

    col_ws = [22.0, 26.0, 26.0, 22.0]   # 合計 96mm
    table_top = north_y - 22             # 方位記号の下に少し余白を取ってから
    d.table(
        table_panel.x + 2, table_top,
        table_rows, col_ws,
        row_h=5.0, height=TH_TINY, header=True,
        title="【測点一覧】",
    )

    # ── 補足メタデータ ──
    d.finish(out_path)
    return {
        "output": out_path,
        "points": len(inp.points),
        "curves": len(inp.curves),
    }


def main() -> None:
    if len(sys.argv) < 3:
        print("Usage: gen_alignment.py <input.json> <output.dxf>")
        sys.exit(1)
    inp = AlignmentInput.from_json(sys.argv[1])
    print(json.dumps(draw_alignment(inp, sys.argv[2]), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
