#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""推力計算書の「許容押込力の区分」の両側検査（ご判断 K-11・2026-10-26）

実行: python3 scripts/thrust_k11_selftest.py

## 何を確かめるか

実際に推力計算書（Excel）を作り、**書き出したファイルを読み直して**セルの中身を見る。
結果の辞書だけを見ていると、書き出しの側で注記が落ちても気づけないため。

| 区分 | 使う例 | 狙い |
|---|---|---|
| 確定値 | エースモール φ350 | 従来どおり。先頭に注意文を足さない。判定は OK/NG のまま |
| 仮の値 | ハイブリッドモール φ2200 | 先頭・判定欄・備考・注意欄に「仮の値で計算」と書く（黄色） |
| 未登録 | ラムサス φ1000 / エースモール φ400 | 既定値を当てない。判定は「判定できません（許容押込力の値が未登録です）」 |

さらに、ドクターの check_thrust_sheet が「注記を消した計算書」を FAIL にできること（飾りでないこと）も確かめる。

ご利用確認（IP-057）が通らない端末では計算書を書けないので、その場合は検査していない旨を出して
終了コード 3 で終わる（合格にしない）。
"""

# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if __name__ == "__main__":
    import sys as _sl_trial_sys
    from pathlib import Path as _SlTrialPath
    _sl_trial_sys.path.insert(0, str((_SlTrialPath(__file__).resolve().parent / ".").resolve()))
    from _trial_guard import require_runtime as _require_trial_runtime
    _require_trial_runtime("suishin-drawing-engine")
# SOLOPTILINK-TRIAL-ENTRY:END

import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from openpyxl import load_workbook                                       # noqa: E402

import ipguard_bridge                                                    # noqa: E402
from doctor import Doctor                                                # noqa: E402
from gen_thrust_calc import (ThrustInput, compute_thrust, render_excel,  # noqa: E402
                             VERDICT_UNJUDGEABLE)

W = os.path.join(tempfile.gettempdir(), "suishin_thrust_k11_selftest")
os.makedirs(W, exist_ok=True)
checks = []


def check(name, ok, detail=""):
    checks.append({"check": name, "result": "PASS" if ok else "FAIL", "detail": detail})


def build(tag, method, dia, length, **kw):
    inp = ThrustInput(project_name=f"K11試験 {tag}", drawing_no=f"K11-{tag}", client="試験",
                      method=method, diameter_mm=dia, length_m=length, **kw)
    res = compute_thrust(inp)
    path = os.path.join(W, f"{tag}.xlsx")
    render_excel(inp, res, path)
    return inp, res, path


def read(path):
    """書き出した計算書から、判定まわりのセルを機械で取り出す。"""
    ws = load_workbook(path).worksheets[0]
    rows = {}
    for row in ws.iter_rows(min_col=2, max_col=5):
        k = row[0].value
        if isinstance(k, str):
            rows.setdefault(k.strip(), [c.value for c in row[1:]])
    allcells = " ".join(str(c.value) for row in ws.iter_rows() for c in row if c.value not in (None, ""))
    vrow = next(r for r in range(1, ws.max_row + 1) if ws.cell(row=r, column=2).value == "判定")
    return {
        "top": str(ws["B3"].value or ""),
        "allow": rows["掘進機許容押込力"], "sf": rows["安全率 SF = 許容/必要"], "verdict": rows["判定"],
        "verdict_fill": ws.cell(row=vrow, column=3).fill.fgColor.rgb,
        "has_notes": "■ 許容押込力についての注意" in allcells,
        "has_jack_block": "■ 中押ジャッキ配置提案" in allcells,
        "all": allcells,
    }


try:
    # --- 確定値（従来どおり）---
    inpA, resA, pA = build("A確定", "エースモール", 350, 80.0)
    A = read(pA)
    check("sheet.confirmed_unchanged",
          resA["allowable_status"] == "確定値" and A["allow"][0] == 1500 and A["verdict"][0] == "OK"
          and A["verdict"][2] == "元押のみで施工可" and A["sf"][0] == 35.92 and A["top"] == ""
          and not A["has_notes"] and A["verdict_fill"].endswith("C6E0B4") and "確定値" in A["allow"][2],
          f"許容押込力={A['allow'][0]}kN・SF={A['sf'][0]}・判定={A['verdict'][0]}（直す前と同じ値）・"
          "先頭の注意なし・緑・備考に「確定値」")

    # --- 仮の値 ---
    inpB, resB, pB = build("B仮", "ハイブリッドモール", 2200, 120.0)
    B = read(pB)
    check("sheet.provisional_is_marked",
          resB["allowable_status"] == "仮の値" and B["allow"][0] == 27000
          and "仮の値" in B["top"] and "ハイブリッドモール" in B["top"]
          and B["verdict"][0].startswith("OK") and "仮の値" in B["verdict"][0]
          and "仮の値" in B["allow"][2] and "仮の値" in B["verdict"][2]
          and B["has_notes"] and B["verdict_fill"].endswith("FFE699"),
          f"先頭「{B['top'][:34]}…」・判定「{B['verdict'][0]}」・備考「{B['allow'][2][:30]}…」・注意欄あり・黄色")
    check("sheet.provisional_names_which_methods",
          "ハイブリッドモール" in B["all"] and "φ1000・φ1350・φ2000・φ2200・φ2400" in B["all"]
          and "リバースエース" in B["all"] and "エースモール、コマンド、Two-Way、ベビーモール" in B["all"],
          "注意欄に、仮の値の工法（ハイブリッドモールの口径）・確定値の工法・未登録の工法が書かれている")

    # --- 名前の食い違い（②のうち ①）: 「ハイブリッド」で指定しても同じ ---
    inpB2, resB2, pB2 = build("B2別名", "ハイブリッド", 1000, 80.0)
    check("sheet.old_hybrid_name_still_works",
          resB2["allowable_status"] == "仮の値" and resB2["allowable_kn"] == 9000
          and resB2["allowable_method"] == "ハイブリッドモール",
          "旧の名前「ハイブリッド」で直接指定しても、正式名「ハイブリッドモール」の値（9000kN・仮の値）で計算する")

    # --- 未登録（工法ごと）---
    inpC, resC, pC = build("C未登録", "ラムサス", 1000, 100.0)
    C = read(pC)
    check("sheet.unregistered_method_cannot_judge",
          resC["allowable_status"] == "未登録" and C["allow"][0] == "未登録" and C["sf"][0] == "判定不可"
          and C["verdict"][0] == VERDICT_UNJUDGEABLE == "判定できません（許容押込力の値が未登録です）"
          and "OK" not in C["verdict"][0] and "判定できません" in C["top"]
          and not C["has_jack_block"] and C["has_notes"] and C["verdict_fill"].endswith("FFE699"),
          f"許容押込力「{C['allow'][0]}」・安全率「{C['sf'][0]}」・判定「{C['verdict'][0]}」・"
          "中押ジャッキの提案なし・先頭に明記・黄色（以前は 5000kN で「OK」）")
    # --- 未登録（登録済みの工法でも、表に無い口径）---
    inpD, resD, pD = build("D口径", "エースモール", 400, 60.0)
    D = read(pD)
    check("sheet.unregistered_diameter_cannot_judge",
          resD["allowable_status"] == "未登録" and D["verdict"][0] == VERDICT_UNJUDGEABLE
          and "φ250" in resD["allowable_reason_ja"] and "判定できません" in D["top"],
          f"エースモール φ400（工法は登録済み・口径が無い）→「{D['verdict'][0]}」。登録済みの口径を理由に添える")

    # --- NG の経路（確定値・仮の値とも、中押ジャッキの提案が従来どおり出る）---
    inpE, resE, pE = build("E確定NG", "エースモール", 250, 1000.0, soil="巨石混り礫")
    E = read(pE)
    check("sheet.confirmed_ng_path_unchanged",
          resE["verdict"].startswith("NG") and E["verdict"][0] == resE["verdict"] and E["has_jack_block"]
          and E["top"] == "" and E["verdict_fill"].endswith("F4B084"),
          f"確定値で NG（{E['verdict'][0]}）のとき、中押ジャッキの提案が出て、先頭の注意は無い（橙）")
    inpF, resF, pF = build("F仮NG", "ハイブリッドモール", 1000, 1000.0, soil="巨石混り礫")
    F = read(pF)
    check("sheet.provisional_ng_path",
          resF["verdict"].startswith("NG") and "仮の値" in F["verdict"][0] and F["verdict"][0].startswith("NG")
          and F["has_jack_block"] and "仮の値" in F["top"],
          f"仮の値で NG（{F['verdict'][0]}）のとき、中押ジャッキの提案は出るが、仮の値であることも書く")

    # --- 指定値（お客様が値を指定したとき）---
    inpG, resG, pG = build("G指定", "ラムサス", 1000, 100.0, machine_allowable_kn=3000)
    G = read(pG)
    check("sheet.specified_value_path",
          resG["allowable_status"] == "指定値" and G["allow"][0] == 3000 and "指定値" in G["allow"][2]
          and G["top"] == "" and G["verdict"][0] == "OK",
          "お客様が許容押込力を指定したときは、従来どおり計算し「指定値」と備考に書く（先頭の注意なし）")

    # --- ドクター：書き出した計算書の注記を読み直す（両側）---
    good = Doctor()
    for r, p in ((resA, pA), (resB, pB), (resC, pC), (resD, pD), (resE, pE), (resF, pF), (resG, pG)):
        good.check_thrust_sheet(p, r)
    g = [x for x in good.results if x["check"].startswith("推力計算書の注記")]
    check("doctor.sheet_check_passes_on_good_sheets",
          len(g) == 7 and all(x["verdict"] == "PASS" for x in g),
          f"注記が入っている 7 冊（確定値・仮の値・未登録・NG・指定値）はすべて PASS（{len(g)} 件）")

    def tamper(src, dst, edit):
        wb = load_workbook(src)
        ws = wb.worksheets[0]
        edit(ws)
        wb.save(dst)
        return dst

    def find_row(ws, label):
        return next(r for r in range(1, ws.max_row + 1) if ws.cell(row=r, column=2).value == label)

    bad = Doctor()
    # 仮の値の計算書から、先頭の注意を消す
    t1 = tamper(pB, os.path.join(W, "改ざん1_先頭の注意を消した仮の値.xlsx"),
                lambda ws: setattr(ws["B3"], "value", None))
    bad.check_thrust_sheet(t1, resB)
    # 未登録の計算書の判定欄を「OK」に書き換える
    t2 = tamper(pC, os.path.join(W, "改ざん2_判定をOKにした未登録.xlsx"),
                lambda ws: setattr(ws.cell(row=find_row(ws, "判定"), column=3), "value", "OK"))
    bad.check_thrust_sheet(t2, resC)
    # 仮の値の計算書の判定欄から「仮の値」の語を消す
    t3 = tamper(pB, os.path.join(W, "改ざん3_判定欄の仮の値を消した.xlsx"),
                lambda ws: setattr(ws.cell(row=find_row(ws, "判定"), column=3), "value", "OK"))
    bad.check_thrust_sheet(t3, resB)
    b = [x for x in bad.results if x["check"].startswith("推力計算書の注記")]
    check("doctor.sheet_check_fails_on_tampered_sheets",
          len(b) == 3 and all(x["verdict"] == "FAIL" and x["severity"] == "critical" for x in b),
          "注意を消した仮の値・判定を OK に書き換えた未登録・判定欄の「仮の値」を消した計算書は、すべて FAIL（提出を止める）")

    # --- ドクター（単独の実行 doctor.py <dir>: 結果の辞書が無く、セルだけから検査する）---
    def verdicts(doc):
        return {x["check"].split(":")[0]: x["verdict"] for x in doc.results}

    s1 = Doctor()
    s1.check_thrust_sheet_file(pA)      # 確定値
    s2 = Doctor()
    s2.check_thrust_sheet_file(pC)      # 未登録
    s3 = Doctor()
    s3.check_thrust_sheet_file(pB)      # 仮の値

    def drop_kubun(ws):                 # 2026-10-26 より前の版の備考欄（「区分:」の記載が無い）を真似る
        r = find_row(ws, "掘進機許容押込力")
        ws.cell(row=r, column=5).value = f"{inpA.method} φ{inpA.diameter_mm} 標準値"

    old_style = tamper(pA, os.path.join(W, "旧版の形_区分の記載なし.xlsx"), drop_kubun)
    s4 = Doctor()
    s4.check_thrust_sheet_file(old_style)
    v1, v2, v3, v4 = verdicts(s1), verdicts(s2), verdicts(s3), verdicts(s4)
    check("doctor.standalone_reads_cells",
          v1.get("許容押込力の区分") == "PASS" and v1.get("推力計算書の注記") == "PASS"
          and v2.get("許容押込力の区分") == "WARN" and v2.get("推力計算書の注記") == "PASS"
          and v3.get("許容押込力の区分") == "WARN" and v3.get("推力計算書の注記") == "PASS"
          and v4.get("推力計算書の区分") == "WARN" and "許容押込力の区分" not in v4,
          "単独のドクターが計算書のセルだけから区分を読む：確定値=合格・仮の値/未登録=要確認。"
          "「区分:」の記載が無い旧版の形の計算書は「出所が分からない」として要確認（合格にしない）")

    # --- ドクター（結果の側）---
    d = Doctor()
    d.check_thrust({"result": resC})
    cc = {x["check"]: x["verdict"] for x in d.results}
    d2 = Doctor()
    d2.check_thrust({"result": resB})
    cb = {x["check"]: x["verdict"] for x in d2.results}
    d3 = Doctor()
    d3.check_thrust({"result": resA})
    ca = {x["check"]: x["verdict"] for x in d3.results}
    check("doctor.result_states",
          cc.get("推力安全率") == "WARN" and cc.get("許容押込力の区分") == "WARN"
          and cb.get("許容押込力の区分") == "WARN" and cb.get("推力安全率") == "PASS"
          and ca.get("許容押込力の区分") == "PASS" and ca.get("推力安全率") == "PASS",
          "未登録は 安全率=要確認・区分=要確認、仮の値は 安全率=合格・区分=要確認、確定値は どちらも合格"
          "（未登録を合格にも不合格にもしない）")

except ipguard_bridge.LicenseDenied as exc:
    print(json.dumps({"selftest": "NOT_RUN", "reason": "ご利用確認を通らない端末のため、計算書を書けず検査していません"
                      "（合格ではありません）", "detail": str(exc)}, ensure_ascii=False))
    sys.exit(3)

n_fail = sum(1 for c in checks if c["result"] == "FAIL")
print(json.dumps({"selftest": "PASS" if n_fail == 0 else "FAIL",
                  "pass": len(checks) - n_fail, "fail": n_fail,
                  "checks": checks}, ensure_ascii=False))
sys.exit(0 if n_fail == 0 else 1)
