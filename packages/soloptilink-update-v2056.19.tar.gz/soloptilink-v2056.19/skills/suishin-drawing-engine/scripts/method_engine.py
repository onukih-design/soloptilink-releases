#!/usr/bin/env python3
"""工法別ルールエンジン
入力パラメータ（工法・口径・延長・曲線R）を method_specs から検証し、
適用可否・推奨管長・警告を返す
"""
from __future__ import annotations

# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if __name__ == "__main__":
    import sys as _sl_trial_sys
    from pathlib import Path as _SlTrialPath
    _sl_trial_sys.path.insert(0, str((_SlTrialPath(__file__).resolve().parent / ".").resolve()))
    from _trial_guard import require_runtime as _require_trial_runtime
    _require_trial_runtime("suishin-drawing-engine")
# SOLOPTILINK-TRIAL-ENTRY:END


import json
import sys
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Any


SPECS_PATH = Path(__file__).parent.parent / "rules" / "method_specs_seed.json"

# ---- 工法名の名寄せ表 (2026-10-25・図面だけプラン 要件 REQ-790 / 用語集 Y-07) ----
#
# ★スキルの説明文・メーカー資料の表記と、諸元の表のキーが食い違っていた。
#   説明文どおり「S-リード」「スリムアーク」と指定すると「未対応工法」で弾かれ、
#   1 点も図面が出なかった (2026-10-25 に実測で再現)。
# ★引き方の順番 (今通っている指定の結果は変えない):
#   ① 諸元の表のキーと完全一致 → そのまま (従来どおり)
#   ② 全角・半角をそろえて (NFKC) 一致 → 表のキー
#   ③ 下の名寄せ表 → 表のキー
#   ④ 区切り記号 (ハイフン・中点・空白) を除いて比べ、**1 件だけ**一致 → 表のキー
#      (2 件以上当たるときは推測で選ばず、従来どおり未対応として返す)
# ★名寄せ表に足すのは、同じ工法であることが資料で確かめられたものだけ。
METHOD_ALIASES: Dict[str, str] = {
    "S-リード": "Sリード",          # スキル説明文・メーカー資料 (Ｓ－リード) の表記
    "スリムアーク": "スリムアークTA500",  # スキル説明文の略称。諸元の表は TA500 だけを持つ
    # 2026-10-26 ご判断K-11: 推力計算の表と PDF 抽出器は「ハイブリッド」、諸元の表と説明文は
    # 「ハイブリッドモール」と書いていて、推力計算の表の値が一度も使われなかった。
    # 同じ工法である根拠: docs/データ出典.md の表が「【2026】ハイブリッド技術資料」を
    # 工法「ハイブリッドモール」の資料としており、諸元の表の reference_pdf も同じ PDF を指す。
    "ハイブリッド": "ハイブリッドモール",
}

# ---- 許容押込力の区分 (2026-10-26 ご判断K-11) ----
#   確定値 … 諸元の許容押込力欄 (allowable_thrust_kN) に値があり、出典の欄が書かれている。
#   仮の値 … 値はあるが、工法の資料で確かめていない。計算には使うが、計算書に「仮の値」と明記する。
#   未登録 … 値が無い。既定値などを**当てない**。推力計算書は「判定できません」と出す。
# 区分は諸元の欄の中身から機械で決まる (人の記憶や口頭の申し送りに頼らない)。
THRUST_CONFIRMED = "確定値"
THRUST_PROVISIONAL = "仮の値"
THRUST_UNREGISTERED = "未登録"

# 比較のときだけ除く区切り記号 (長音「ー」は工法名の一部なので含めない)
_SEPARATORS = "-‐‑‒–—―・･ 　_"


def _fold(name: str) -> str:
    """全角・半角をそろえ、前後の空白を落とす。"""
    return unicodedata.normalize("NFKC", str(name)).strip()


def _strip_separators(name: str) -> str:
    """区切り記号を除いた比較用の形。"""
    return "".join(ch for ch in _fold(name) if ch not in _SEPARATORS)


class MethodEngine:
    def __init__(self, specs_path: Path = SPECS_PATH):
        self.specs = json.load(open(specs_path, encoding="utf-8"))
        self.methods = self.specs["methods"]

    def list_methods(self) -> List[str]:
        return list(self.methods.keys())

    def resolve_method(self, method: str) -> Optional[str]:
        """指定された工法名を諸元の表のキーへ寄せる。寄せられなければ None。"""
        if method in self.methods:
            return method
        folded = _fold(method)
        if folded in self.methods:
            return folded
        for alias, key in METHOD_ALIASES.items():
            if folded == _fold(alias) and key in self.methods:
                return key
        target = _strip_separators(folded)
        hits = [k for k in self.methods if _strip_separators(k) == target]
        if len(hits) == 1:
            return hits[0]
        return None

    def get_spec(self, method: str) -> Dict[str, Any]:
        key = self.resolve_method(method)
        if key is None:
            raise ValueError(f"未対応工法: {method}. 利用可能: {self.list_methods()}")
        return self.methods[key]

    # ---- 許容押込力の引き方 (2026-10-26 ご判断K-11) ----
    def allowable_thrust(self, method: str, diameter_mm) -> Dict[str, Any]:
        """工法・呼び径の許容押込力を、区分つきで返す。

        返す区分は 確定値 / 仮の値 / 未登録 の 3 つ。**値を発明しない**:
        表に無い・欄の中身が壊れている・確定値なのに出典の欄が空、のいずれも「未登録」で返し、
        既定値などは当てない (以前は既定値 5,000kN を黙って当てて「OK」を返していた)。
        """
        d = None
        try:
            if diameter_mm is not None and float(diameter_mm) == int(float(diameter_mm)):
                d = int(float(diameter_mm))
        except (TypeError, ValueError):
            d = None

        def _unreg(reason: str, key: Optional[str] = None, regs: Optional[List[int]] = None):
            return {"method": key or method, "diameter_mm": d if d is not None else diameter_mm,
                    "status": THRUST_UNREGISTERED, "value_kn": None, "source": "",
                    "registered_diameters": regs or [], "reason_ja": reason}

        key = self.resolve_method(method)
        if key is None:
            return _unreg(f"工法名「{method}」が諸元の表にありません")
        block = self.methods[key].get("allowable_thrust_kN")
        if not isinstance(block, dict) or not isinstance(block.get("by_diameter_mm"), dict) \
                or not block["by_diameter_mm"]:
            return _unreg(f"工法{key}の許容押込力が諸元にありません", key)
        status = block.get("status")
        source = str(block.get("source") or "").strip()
        if status not in (THRUST_CONFIRMED, THRUST_PROVISIONAL):
            return _unreg(f"工法{key}の許容押込力の区分が「確定値」「仮の値」のどちらでもないため使いません", key)
        if status == THRUST_CONFIRMED and not source:
            return _unreg(f"工法{key}の許容押込力は出典の欄が空のため、確定値として使いません", key)
        by: Dict[int, float] = {}
        for k, v in block["by_diameter_mm"].items():
            try:
                kk = int(k)
            except (TypeError, ValueError):
                continue
            if isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0:
                by[kk] = v
        regs = sorted(by)
        if d is None or d not in by:
            return _unreg(f"工法{key}の呼び径φ{diameter_mm}の許容押込力が諸元にありません"
                          f"（登録済みの呼び径: {', '.join('φ%d' % x for x in regs) or 'なし'}）", key, regs)
        return {"method": key, "diameter_mm": d, "status": status, "value_kn": by[d],
                "source": source, "registered_diameters": regs, "reason_ja": ""}

    def method_thrust_status(self, method: str) -> str:
        """工法ごとの区分。値が 1 つも使えなければ未登録、仮の値の工法は仮の値、それ以外は確定値。"""
        key = self.resolve_method(method)
        if key is None:
            return THRUST_UNREGISTERED
        regs = self._registered_diameters(key)
        if not regs:
            return THRUST_UNREGISTERED
        return self.allowable_thrust(key, regs[0])["status"]

    def _registered_diameters(self, key: str) -> List[int]:
        block = self.methods[key].get("allowable_thrust_kN")
        if not isinstance(block, dict) or not isinstance(block.get("by_diameter_mm"), dict):
            return []
        out = []
        for k in block["by_diameter_mm"]:
            try:
                kk = int(k)
            except (TypeError, ValueError):
                continue
            if self.allowable_thrust(key, kk)["status"] != THRUST_UNREGISTERED:
                out.append(kk)
        return sorted(out)

    def thrust_status_table(self) -> Dict[str, Dict[str, Any]]:
        """全工法の区分の一覧 {工法: {status, diameters, source}}。計算書の注記と自己検証が使う。"""
        table: Dict[str, Dict[str, Any]] = {}
        for m in self.list_methods():
            regs = self._registered_diameters(m)
            first = self.allowable_thrust(m, regs[0]) if regs else None
            table[m] = {
                "status": first["status"] if first else THRUST_UNREGISTERED,
                "diameters": regs,
                "source": first["source"] if first else "",
            }
        return table

    def validate(
        self,
        method: str,
        diameter_mm: int,
        length_m: float,
        curve_radius_m: Optional[float] = None,
        curved: bool = False,
    ) -> Dict[str, Any]:
        """
        パラメータの妥当性を検証。エラー・警告・推奨事項を返す
        """
        spec = self.get_spec(method)
        # 名寄せした正式名で判定文を書く (REQ-790)。get_spec が通った時点で必ず寄せられる
        method = self.resolve_method(method) or method
        errors: List[str] = []
        warnings: List[str] = []
        suggestions: List[str] = []
        # ---- 諸元が無くて判定できなかったもの (2026-10-23 新設・要件 REQ-117) ----
        #
        # ★以前は、諸元が無い工法に **発明した既定値** を当てて OK を返していた。
        #   実測で見つかった事故:
        #     ・最大推進延長の既定 500m → ラムサスφ1000・L=400m が「OK」になる
        #       (ラムサスの実際の最大延長は諸元に無く、誰も知らないまま通していた)
        #     ・許容最小R の既定 0m   → R=0m でも「OK」になる
        #     ・標準R の既定 999m     → 「標準R=999m未満」という存在しない数字の警告が出る
        #     ・推進延長の下限が無い  → L=0m・L=−100m が「OK」になる
        #
        #   16 工法のうち **最大延長が無いもの 10 件・許容最小R が無いもの 11 件**
        #   (2026-10-23 に諸元の表を機械で数えた実測)。
        #
        # ★直し方: **数字を発明しない。** 諸元が無いときは既定値で通さず
        #   「諸元が無いため判定できません」と答え、何をメーカーに確かめるかを示す。
        #   判定は OK / NG / 要確認 の 3 値になる。
        #   諸元を埋めるには工法の一次情報 (メーカーの技術資料) が必要で、
        #   それはこの端末にはない (要件 REQ-116 として残っている)。
        unknown: List[str] = []
        # 2026-10-26 lotWA（REQ-359・統括の決定 D-W1「OK にならないこと（要確認か NG。理由に出典を示す）」）:
        #   判定できない理由の文に、その工法の諸元の出典（諸元の表の reference_pdf）を必ず添える。
        #   出典が登録されていない工法は「登録なし」と書く（出典を作らない）。
        _src = str(spec.get("reference_pdf") or "").strip()
        if _src.lower().endswith(".pdf"):
            _src = _src[:-4]
        src_ja = f"（諸元の出典: {_src}）" if _src else "（諸元の出典: 登録なし）"

        # 口径チェック
        dia = spec.get("applicable_diameter_mm", {})
        if not dia or dia.get("min") is None or dia.get("max") is None:
            unknown.append(
                f"工法{method}の適用口径が諸元にありません。"
                "メーカーの技術資料で適用口径をご確認ください" + src_ja)
        else:
            if diameter_mm < dia["min"]:
                errors.append(
                    f"呼び径φ{diameter_mm}は工法{method}の適用最小径φ{dia['min']}未満"
                )
            if diameter_mm > dia["max"]:
                errors.append(
                    f"呼び径φ{diameter_mm}は工法{method}の適用最大径φ{dia['max']}超過"
                )
            if "typical" in dia and diameter_mm not in dia["typical"]:
                warnings.append(
                    f"呼び径φ{diameter_mm}は工法{method}の標準ラインアップ{dia['typical']}に含まれません"
                )

        # ---- 推進延長: まず物理的に成立しない値を止める ----
        #   これは諸元が無くても判定できる (0 以下の延長は工事として成立しない)
        if length_m <= 0:
            errors.append(
                f"推進延長{length_m}mは 0 以下です。推進延長は 0 より大きい値で"
                "ご指定ください")

        # 延長チェック (諸元がある工法だけ。無いものは既定値で通さない)
        max_span = spec.get("max_span_length_m")
        _key = "curved" if curved else "straight"
        limit = (max_span or {}).get(_key)
        if limit is None:
            unknown.append(
                f"工法{method}の{'曲線' if curved else '直線'}最大推進延長が諸元に"
                f"ありません。推進延長{length_m}mが工法の範囲内かを判定できていません。"
                "メーカーの技術資料で最大推進延長をご確認ください" + src_ja)
        elif length_m > limit:
            errors.append(
                f"推進延長{length_m}mは工法{method}の{'曲線' if curved else '直線'}"
                f"最大推進延長{limit}mを超過"
            )
        elif length_m > limit * 0.9:
            warnings.append(
                f"推進延長{length_m}mは工法{method}の最大値{limit}mの90%超過。"
                f"中押ジャッキ・滑材追加検討推奨"
            )

        # ---- 曲線半径 ----
        if curved:
            # 曲線なのに半径が渡されていなければ、黙って検査を飛ばさない
            if curve_radius_m is None:
                unknown.append(
                    "曲線施工として指定されていますが曲線半径が渡されていないため、"
                    "曲線の判定をしていません。曲線半径 R をご指定ください")
            elif curve_radius_m <= 0:
                # 諸元が無くても判定できる (半径 0 以下の曲線は成立しない)
                errors.append(
                    f"曲線半径R={curve_radius_m}mは 0 以下です。"
                    "曲線半径は 0 より大きい値でご指定ください")
            else:
                min_r = spec.get("min_curve_radius_m")
                allowed = (min_r or {}).get("sharp", (min_r or {}).get("special"))
                standard = (min_r or {}).get("standard")
                if allowed is None:
                    unknown.append(
                        f"工法{method}の許容最小曲線半径が諸元にありません。"
                        f"曲線半径R={curve_radius_m}mが工法の範囲内かを判定できていません。"
                        "メーカーの技術資料で許容最小曲線半径をご確認ください" + src_ja)
                elif curve_radius_m < allowed:
                    errors.append(
                        f"曲線半径R={curve_radius_m}mは工法{method}の"
                        f"許容最小R={allowed}m未満"
                    )
                elif standard is not None and curve_radius_m < standard:
                    # ★標準R が諸元に無いときは警告を出さない
                    #   (以前は既定 999m を当てて、存在しない数字で警告していた)
                    warnings.append(
                        f"曲線半径R={curve_radius_m}mは工法{method}の標準R={standard}m未満。"
                        f"曲線用短管・特殊対応が必要"
                    )

        # ---- 許容押込力 ----
        #   2026-10-23 の実測では 16 工法すべてで諸元に無かった。
        #   2026-10-26 ご判断K-11 で、5 工法 (確定値 4・仮の値 1) の値を諸元の許容押込力欄へ移した。
        #   残り 11 工法は未登録のまま (既定値を当てない)。
        #
        #   ★これは unknown (判定の値を変えるもの) に入れない。
        #     未登録の工法が多く、入れると**すべての判定が要確認になり**
        #     「どの条件が本当に危ないか」の信号が消える。
        #     押込力を使うのは推力計算の部品 (gen_thrust_calc.py) であって、
        #     この関数が判定しているのは口径・延長・曲線半径である。
        #   ★ただし黙らない。別枠で必ず開示し、警告にも出す。
        #     未登録 … 推力計算書は既定値で計算せず「判定できません」と出す。
        #     仮の値 … 推力計算書に「仮の値で計算」と明記する。
        thrust = self.allowable_thrust(method, diameter_mm)
        thrust_status = thrust["status"]
        thrust_missing = thrust_status == THRUST_UNREGISTERED
        if thrust_missing:
            _reason = thrust.get("reason_ja") or f"工法{method}の許容押込力が諸元にありません"
            if "諸元にありません" not in _reason:
                _reason = f"工法{method}の許容押込力が諸元にありません（{_reason}）"
            warnings.append(
                f"{_reason}。推力計算書は既定値では計算せず「判定できません（許容押込力の値が未登録です）」と出します。"
                "メーカーの技術資料で許容押込力をご確認ください" + src_ja)
        elif thrust_status == THRUST_PROVISIONAL:
            warnings.append(
                f"工法{method}の呼び径φ{diameter_mm}の許容押込力は仮の値（{thrust['value_kn']}kN）です。"
                "工法の資料で確かめていないため、推力計算書に「仮の値で計算」と明記します。"
                "メーカーの技術資料でご確認ください" + src_ja)

        # 推奨管長
        pipe_lengths = spec.get("standard_pipe_length_m", [2.43, 1.2, 1.0, 0.6])
        suggestions.append(f"推奨管長ラインアップ: {pipe_lengths}m")

        # 掘進機外径
        machine_od = spec.get("machine_od_mm", {})
        if str(diameter_mm) in machine_od:
            suggestions.append(f"標準掘進機外径: φ{machine_od[str(diameter_mm)]}mm")

        return {
            "method": method,
            "spec_summary": {
                "適用口径": f"{dia.get('min')}-{dia.get('max')}mm",
                "最大延長": max_span,
                "最小曲線R": spec.get("min_curve_radius_m", {}),
                "推奨管長": pipe_lengths,
            },
            "input": {
                "diameter_mm": diameter_mm,
                "length_m": length_m,
                "curve_radius_m": curve_radius_m,
                "curved": curved,
            },
            "errors": errors,
            "warnings": warnings,
            "suggestions": suggestions,
            # 諸元が無くて判定できなかったもの (空なら全項目を判定できた)
            "unknown": unknown,
            # 許容押込力が諸元に無いか (未登録なら推力計算書は「判定できません」と出す)
            "allowable_thrust_spec_missing": thrust_missing,
            # 許容押込力の区分 (確定値 / 仮の値 / 未登録) と、使う値 (未登録なら None)
            "allowable_thrust_status": thrust_status,
            "allowable_thrust_value_kn": thrust["value_kn"],
            # ★3 値になった (2026-10-23・要件 REQ-117)。
            #   NG   … 工法の範囲を外れている / 物理的に成立しない
            #   要確認 … 諸元が無く判定できない項目がある (**OK と呼ばない**)
            #   OK   … 判定できる項目をすべて判定し、範囲内だった
            "verdict": ("NG" if errors else ("要確認" if unknown else "OK")),
            "verdict_note_ja": (
                "工法の範囲を外れているか、成立しない値が含まれています"
                if errors else
                (f"諸元が無いため判定できない項目が {len(unknown)} 件あります。"
                 "この条件で施工できるかはメーカーへご確認ください "
                 "(こちらで既定値を当てて「問題なし」とは申し上げません)"
                 if unknown else
                 "判定できる項目をすべて判定し、いずれも工法の範囲内でした")),
        }

    def recommend_pipe_layout(
        self, method: str, length_m: float, in_curve: bool = False,
    ) -> List[float]:
        """推進延長に対して工法標準のパイプ配列を返す"""
        spec = self.get_spec(method)
        pipes = spec.get("standard_pipe_length_m", [2.43, 1.2, 1.0, 0.6])
        pipes_desc = sorted(pipes, reverse=True)
        pipes_asc = sorted(pipes)
        candidates = pipes_asc if in_curve else pipes_desc

        layout: List[float] = []
        remaining = length_m
        while remaining > 1e-6:
            chosen = next((p for p in candidates if p <= remaining + 1e-6), min(pipes))
            actual = min(chosen, remaining)
            layout.append(round(actual, 3))
            remaining -= actual
        return layout


def main():
    if len(sys.argv) < 2:
        print("Usage: method_engine.py <method> [diameter_mm] [length_m] [curve_radius_m]")
        print("       method_engine.py list")
        sys.exit(1)

    engine = MethodEngine()

    if sys.argv[1] == "list":
        for m in engine.list_methods():
            spec = engine.get_spec(m)
            dia = spec.get("applicable_diameter_mm", {})
            print(f"  {m:20s} φ{dia.get('min')}-{dia.get('max')}mm  {spec.get('category', '')}")
        return

    method = sys.argv[1]
    diameter = int(sys.argv[2]) if len(sys.argv) > 2 else 350
    length = float(sys.argv[3]) if len(sys.argv) > 3 else 80.0
    r = float(sys.argv[4]) if len(sys.argv) > 4 else None
    result = engine.validate(method, diameter, length, r, curved=(r is not None))
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
