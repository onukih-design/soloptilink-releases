#!/usr/bin/env bash
# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
_sl_trial_runtime="${SOLOPTILINK_HOME:-$HOME/.soloptilink}/lib/free-trial/runtime_guard.py"
if [ ! -f "$_sl_trial_runtime" ]; then
  _sl_trial_runtime="$HOME/.soloptilink/lib/free-trial/runtime_guard.py"
fi
if [ ! -f "$_sl_trial_runtime" ]; then
  _sl_trial_runtime="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/../../../../lib/free-trial/runtime_guard.py"
fi
if [ -f "$_sl_trial_runtime" ]; then
  python3 "$_sl_trial_runtime" soloptilink-japan || exit $?
else
  python3 - "${SOLOPTILINK_HOME:-$HOME/.soloptilink}" "$HOME/.soloptilink" <<'SL_TRIAL_CHECK'
import json, os, sys
from pathlib import Path
for root in map(Path, sys.argv[1:]):
    trial = os.path.lexists(root / '.free-trial/marker.json')
    try:
        trial = trial or json.loads((root / 'activation.json').read_text(encoding='utf-8-sig')).get('plan_kind') == 'trial'
    except (OSError, ValueError, AttributeError):
        pass
    if trial:
        print('無料トライアルの確認部品が見つからないため、この機能は実行できません。', file=sys.stderr)
        raise SystemExit(3)
SL_TRIAL_CHECK
  _sl_trial_result=$?
  if [ "$_sl_trial_result" -ne 0 ]; then exit "$_sl_trial_result"; fi
  unset _sl_trial_result
fi
unset _sl_trial_runtime
fi
# SOLOPTILINK-TRIAL-ENTRY:END

# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# =============================================================================
# medical-dictionary/dictionary-loader.sh
#   医療用語辞書のシェル向け参照 API。python3 で JSON parse (jq 非依存)。
#
# 使い方:
#   dictionary-loader.sh dept-name <code>              # 診療科コード→日本語名
#   dictionary-loader.sh icd10-name <code>             # ICD-10コード→標準病名
#   dictionary-loader.sh fee-points <code> [scope]     # 診療報酬点数取得
#                                                       (scope: medical|dental|dispensing|addition)
#   dictionary-loader.sh yj-info <yjCode>              # YJコード→薬品情報
#   dictionary-loader.sh insurance-name <code>         # 保険種別→日本語名
#   dictionary-loader.sh receipt-record <code>         # レセ電レコード種別説明
#   dictionary-loader.sh summary                       # 収録辞書サマリ(JSON)
#   dictionary-loader.sh path                          # 辞書ディレクトリパス
# =============================================================================
set -euo pipefail

MD_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_DIR="$MD_DIR/data"

_py() { python3 -c "$1" "$@" 2>/dev/null || true; }

_lookup() {
  # $1=json path, $2=key field, $3=value field, $4=lookup value
  local jf="$1" kf="$2" vf="$3" lv="$4"
  python3 - "$jf" "$kf" "$vf" "$lv" <<'PY' 2>/dev/null || echo ""
import json, sys
p, kf, vf, lv = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
try:
    with open(p, 'r', encoding='utf-8') as f: d = json.load(f)
    items = d.get('items') or d.get('records') or []
    for it in items:
        if str(it.get(kf, '')) == lv:
            print(it.get(vf, ''))
            break
except Exception:
    pass
PY
}

case "${1:-help}" in
  dept-name)
    _lookup "$DATA_DIR/medical-departments.json" "code" "name" "${2:-}"
    ;;
  icd10-name)
    _lookup "$DATA_DIR/icd10.json" "icd10" "standardName" "${2:-}"
    ;;
  fee-points)
    scope="${3:-medical}"
    case "$scope" in
      medical) f="$DATA_DIR/medical-fees-r6.json" ;;
      dental)  f="$DATA_DIR/dental-fees-r6.json" ;;
      dispensing) f="$DATA_DIR/dispensing-fees-r6.json" ;;
      addition) f="$DATA_DIR/addition-common.json" ;;
      *) echo "unknown scope: $scope" >&2; exit 2 ;;
    esac
    _lookup "$f" "code" "points" "${2:-}"
    ;;
  yj-info)
    python3 - "$DATA_DIR/yj-codes-sample.json" "${2:-}" <<'PY' 2>/dev/null || true
import json, sys
p, yj = sys.argv[1], sys.argv[2]
with open(p, 'r', encoding='utf-8') as f: d = json.load(f)
for it in d.get('items', []):
    if it.get('yjCode') == yj:
        print(json.dumps({
            'productName': it.get('productName'),
            'genericName': it.get('genericName'),
            'unitPriceYen': it.get('unitPriceYen'),
            'isGeneric': it.get('isGeneric'),
            'narcotic': it.get('narcotic', False),
        }, ensure_ascii=False))
        break
PY
    ;;
  insurance-name)
    _lookup "$DATA_DIR/insurance-types.json" "code" "name" "${2:-}"
    ;;
  receipt-record)
    _lookup "$DATA_DIR/receipt-electronic-codes.json" "code" "description" "${2:-}"
    ;;
  summary)
    python3 - "$DATA_DIR" <<'PY' 2>/dev/null
import json, os, sys
data_dir = sys.argv[1]
out = {"dictionaries": {}}
for fn in sorted(os.listdir(data_dir)):
    if not fn.endswith('.json'): continue
    p = os.path.join(data_dir, fn)
    try:
        with open(p, 'r', encoding='utf-8') as f: d = json.load(f)
        n = len(d.get('items') or d.get('records') or [])
        out['dictionaries'][fn] = {
            'items': n,
            'revision': d.get('revision', ''),
            'source': d.get('source', ''),
        }
    except Exception as e:
        out['dictionaries'][fn] = {'error': str(e)}
print(json.dumps(out, ensure_ascii=False, indent=2))
PY
    ;;
  path)
    echo "$DATA_DIR"
    ;;
  help|*)
    grep '^#' "$0" | grep -v '^#!' | sed 's/^# \{0,1\}//'
    ;;
esac
