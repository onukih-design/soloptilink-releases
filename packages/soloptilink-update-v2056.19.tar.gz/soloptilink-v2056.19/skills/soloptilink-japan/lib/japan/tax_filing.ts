/**
 * SoloptiLinkAI Phase 24-FA — 確定申告 / 法人税申告 / 消費税申告 (Tax Filing)
 *
 * 日本の主要な税務申告書の計算ロジック骨子。
 * Phase 16 gov_eapps.ts (e-Tax 提出フロー) と組み合わせて使う前段の数値計算。
 *
 * カバー範囲:
 *  - 個人事業主の確定申告 (青色申告: 65万/55万/10万円控除 + 白色申告)
 *  - 所得税の累進税率 (5%〜45%)
 *  - 復興特別所得税 (基準所得税額の2.1%)
 *  - 法人税申告 (中小法人: 800万円以下15%/超19% R6時点)
 *  - 法人住民税 (均等割 + 法人税割)
 *  - 法人事業税 (所得割)
 *  - 消費税申告 (一般課税 / 簡易課税 / インボイス2割特例 / 個人の3割特例 / 少額特例 / 経過措置)
 *  - 消費税 8% / 10% 区分集計
 */

// ★2026-08-11 (owner 決定 束E-2): 年分別 税マスタを計算へ接続する。
//   これまで基礎控除 480,000 円と法人税率は本ファイルに直書きされており、
//   一次情報から取り込んだ令和8年分マスタは **どの計算からも読まれていなかった** (実測)。
//   ここから読込口を通して実際に使う。ただし査読前の値を黙って確定値にはしない:
//   年分を明示した呼び出しだけがマスタを使い、その結果には必ず査読状態と注意書きが付く。
import {
  resolveBasicDeduction,
  resolveCorporateTaxBrackets,
  calcCorporateTaxFromBrackets,
  TaxMasterUnavailableError,
} from "./tax-engine/year-value-loader.js";
// ★2026-09-30 (JPO-I1): 消費税の経過措置・特例の値は値表 (tax-calendar.json) から引く
import { loadTaxCalendar, type TaxCalendar } from "./tax-engine/calendar-loader.js";
import {
  calcInvoiceTransitionalCredit as calcTransitionalCreditForFiling,
  resolveInvoiceTransitional as resolveTransitionalForFiling,
} from "./tax-engine/consumption-tax-calculator.js";

// ===================
// 個人事業主 確定申告
// ===================

export type FilingType = "blue65" | "blue55" | "blue10" | "white";

export interface IndividualFilingInput {
  business_income: number; // 事業収入
  business_expenses: number; // 事業必要経費
  filing_type: FilingType;
  // 所得控除
  social_insurance_premiums: number; // 国民年金/国民健康保険等
  small_business_mutual_aid: number; // 小規模企業共済
  ideco: number; // iDeCo
  life_insurance_deduction?: number; // 最大4万 (新生命保険料)
  earthquake_insurance_deduction?: number; // 最大5万
  medical_expense_deduction?: number; // 医療費控除 (10万円超 or 所得5%)
  donation_deduction?: number; // 寄附金 (ふるさと納税等)
  spouse_deduction?: number; // 配偶者控除/特別控除
  dependent_deduction?: number; // 扶養控除
  basic_deduction?: number; // 基礎控除 (金額を明示するとき。省略時は下の tax_year で解決)
  /**
   * 年分 (西暦。令和8年分なら 2026)。
   * 指定すると基礎控除を年分マスタ (lib/japan/tax-values/) から解決する。
   * 省略すると従来どおり令和6年分の固定値を使い、結果にその旨を明示する。
   */
  tax_year?: number;
}

export const BLUE_FILING_DEDUCTION: Record<FilingType, number> = {
  blue65: 650_000, // e-Tax提出 + 電子帳簿保存
  blue55: 550_000, // 複式簿記 + 期限内提出 (紙)
  blue10: 100_000, // 簡易簿記 (現金主義含む)
  white: 0,
};

export const DEFAULT_BASIC_DEDUCTION = 480_000; // R6 基礎控除

// 所得税 累進税率 (R6)
export const INCOME_TAX_BRACKETS = [
  { up_to: 1_950_000, rate: 0.05, deduction: 0 },
  { up_to: 3_300_000, rate: 0.10, deduction: 97_500 },
  { up_to: 6_950_000, rate: 0.20, deduction: 427_500 },
  { up_to: 9_000_000, rate: 0.23, deduction: 636_000 },
  { up_to: 18_000_000, rate: 0.33, deduction: 1_536_000 },
  { up_to: 40_000_000, rate: 0.40, deduction: 2_796_000 },
  { up_to: Infinity, rate: 0.45, deduction: 4_796_000 },
] as const;

export function calcIncomeTax(taxableIncome: number): number {
  if (taxableIncome <= 0) return 0;
  // 千円未満切り捨て
  const taxable = Math.floor(taxableIncome / 1000) * 1000;
  for (const b of INCOME_TAX_BRACKETS) {
    if (taxable <= b.up_to) {
      return Math.floor(taxable * b.rate - b.deduction);
    }
  }
  return 0;
}

// 復興特別所得税 (基準所得税額の2.1%)
export function calcReconstructionSurtax(baseIncomeTax: number): number {
  return Math.floor(baseIncomeTax * 0.021);
}

export interface IndividualFilingResult {
  business_income: number;
  business_expenses: number;
  blue_filing_deduction: number;
  net_business_income: number;
  total_deductions: number;
  taxable_income: number;
  income_tax_base: number;
  reconstruction_surtax: number;
  total_tax: number;
  /** 基礎控除をどこから取ったか (お客様への説明にそのまま使える日本語) */
  basic_deduction_source_ja: string;
  /** 基礎控除の値の査読状態 */
  basic_deduction_review_status: string;
  /** その値を確定値として業務に使ってよいか */
  basic_deduction_confirmed: boolean;
  /** 確定でないときの注意書き (確定なら空文字) */
  basic_deduction_caution_ja: string;
}

/**
 * 基礎控除の既定値を決める。
 *  ・呼び出し側が金額を明示した   → その金額 (従来どおり)
 *  ・年分 (tax_year) が指定された → 年分マスタから解決する (査読状態を必ず返す)
 *  ・年分の指定が無い             → 従来の固定値。ただし「令和6年分の固定値」と明示する
 * ★年分を指定したのにマスタが読めない/範囲外のときは、黙って固定値へ倒さず例外にする。
 *   「読めなかったので古い控除額で計算しました」は、誤った税額を静かに出す経路そのもの。
 */
function resolveBasicDeductionForFiling(input: IndividualFilingInput): {
  amount: number;
  source_ja: string;
  review_status: string;
  confirmed: boolean;
  caution_ja: string;
} {
  if (input.basic_deduction !== undefined && input.basic_deduction !== null) {
    return {
      amount: input.basic_deduction,
      source_ja: "呼び出し側が指定した金額",
      review_status: "caller-specified",
      confirmed: true,
      caution_ja: "",
    };
  }
  if (input.tax_year !== undefined && input.tax_year !== null) {
    const totalIncome = Math.max(
      0,
      input.business_income - input.business_expenses - BLUE_FILING_DEDUCTION[input.filing_type]
    );
    const r = resolveBasicDeduction(input.tax_year, totalIncome);
    return {
      amount: r.value,
      source_ja: `${r.wareki} の年分マスタ (${r.source_file})`,
      review_status: r.review_status,
      confirmed: r.confirmed,
      caution_ja: r.caution_ja,
    };
  }
  return {
    amount: DEFAULT_BASIC_DEDUCTION,
    source_ja: "令和6年分の固定値 (年分の指定が無いため)",
    review_status: "legacy-fixed-r6",
    confirmed: false,
    caution_ja:
      "年分の指定が無いため、令和6年分の基礎控除額で計算しています。" +
      "令和7年分以降は金額が変わっているため、年分を指定してください。",
  };
}

export function calcIndividualFiling(input: IndividualFilingInput): IndividualFilingResult {
  const blueDeduction = BLUE_FILING_DEDUCTION[input.filing_type];
  const netBusiness = Math.max(0, input.business_income - input.business_expenses - blueDeduction);
  const basic = resolveBasicDeductionForFiling(input);
  const deductions =
    basic.amount +
    input.social_insurance_premiums +
    input.small_business_mutual_aid +
    input.ideco +
    (input.life_insurance_deduction ?? 0) +
    (input.earthquake_insurance_deduction ?? 0) +
    (input.medical_expense_deduction ?? 0) +
    (input.donation_deduction ?? 0) +
    (input.spouse_deduction ?? 0) +
    (input.dependent_deduction ?? 0);
  const taxable = Math.max(0, netBusiness - deductions);
  const tax = calcIncomeTax(taxable);
  const reconstruction = calcReconstructionSurtax(tax);
  return {
    business_income: input.business_income,
    business_expenses: input.business_expenses,
    blue_filing_deduction: blueDeduction,
    net_business_income: netBusiness,
    total_deductions: deductions,
    taxable_income: taxable,
    income_tax_base: tax,
    reconstruction_surtax: reconstruction,
    total_tax: tax + reconstruction,
    basic_deduction_source_ja: basic.source_ja,
    basic_deduction_review_status: basic.review_status,
    basic_deduction_confirmed: basic.confirmed,
    basic_deduction_caution_ja: basic.caution_ja,
  };
}

// ===================
// 法人税申告
// ===================

export interface CorporateFilingInput {
  taxable_income: number; // 所得金額
  is_smb: boolean; // 中小法人 (期末資本金1億円以下)
  prefecture?: string; // 法人住民税の地域差
  capital_yen: number; // 期末資本金
  number_of_employees?: number; // 均等割計算用
  /**
   * 事業年度の開始日 'YYYY-MM-DD'。
   * 指定すると法人税率を年分マスタ (lib/japan/tax-values/) から解決する。
   * 省略すると従来どおり R6 の固定税率で計算する (挙動は変わらない)。
   */
  fiscal_year_start?: string;
}

// 法人税率 (R6時点 中小法人)
const CORPORATE_TAX_THRESHOLD_SMB = 8_000_000;
const CORPORATE_TAX_RATE_SMB_LOW = 0.15; // 800万円以下
const CORPORATE_TAX_RATE_SMB_HIGH = 0.232; // 超過部分 (中小軽減後 19% + 地方法人税)
const CORPORATE_TAX_RATE_LARGE = 0.232; // 大法人

export function calcCorporateTax(input: CorporateFilingInput): number {
  if (input.taxable_income <= 0) return 0;
  // ★2026-08-11 (束E-2): 事業年度の開始日が渡されたら年分マスタで解決する。
  //   直書きの R6 税率には、令和7年4月1日以後開始事業年度の条件付税率
  //   (所得が年10億円超のとき 800 万円以下の部分が 17%) が存在しなかった。
  //   開始日が渡されないときは従来どおり (挙動を一切変えない)。
  if (input.fiscal_year_start) {
    const category = input.is_smb ? "普通法人 (資本金1億円以下" : "上記以外の普通法人";
    const r = resolveCorporateTaxBrackets(input.fiscal_year_start, category, input.taxable_income);
    return calcCorporateTaxFromBrackets(r.value, input.taxable_income);
  }
  if (input.is_smb) {
    const low = Math.min(input.taxable_income, CORPORATE_TAX_THRESHOLD_SMB);
    const high = Math.max(0, input.taxable_income - CORPORATE_TAX_THRESHOLD_SMB);
    return Math.floor(low * CORPORATE_TAX_RATE_SMB_LOW + high * CORPORATE_TAX_RATE_SMB_HIGH);
  }
  return Math.floor(input.taxable_income * CORPORATE_TAX_RATE_LARGE);
}

// 地方法人税 (法人税額の10.3%)
export function calcLocalCorporateTax(corporateTax: number): number {
  return Math.floor(corporateTax * 0.103);
}

// 法人住民税 (均等割: 資本金+従業員数) — 標準税率
export interface MunicipalEqualPortion {
  prefectural: number; // 道府県民税
  municipal: number; // 市町村民税
  total: number;
}

export function calcMunicipalEqualPortion(input: CorporateFilingInput): MunicipalEqualPortion {
  const cap = input.capital_yen;
  const emp = input.number_of_employees ?? 0;
  // 道府県民税均等割 (5段階)
  let pref = 20_000;
  if (cap > 50_000_000_000) pref = 800_000;
  else if (cap > 10_000_000_000) pref = 540_000;
  else if (cap > 1_000_000_000) pref = 130_000;
  else if (cap > 100_000_000) pref = 50_000;
  // 市町村民税均等割 (資本金+従業員50人超で増額)
  let muni = 50_000;
  if (cap > 50_000_000_000 && emp > 50) muni = 3_000_000;
  else if (cap > 10_000_000_000 && emp > 50) muni = 1_750_000;
  else if (cap > 1_000_000_000 && emp > 50) muni = 400_000;
  else if (cap > 100_000_000 && emp > 50) muni = 150_000;
  else if (cap > 100_000_000) muni = 120_000;
  return { prefectural: pref, municipal: muni, total: pref + muni };
}

// 法人住民税 法人税割 (法人税額×標準税率 7.0% = 道府県民税 1.0% + 市町村民税 6.0%)
// ★2026-11-08 是正: 以前は 10.4% (平成26年10月〜令和元年9月に開始する事業年度の税率) のままだった。
//   令和元年10月1日以後に開始する事業年度は 7.0% (地方税法 51条・314条の4)。超過課税の地域差は扱わない。
export const MUNICIPAL_INCOME_PORTION_RATE = 0.07;
export function calcMunicipalIncomePortion(corporateTax: number): number {
  return Math.floor(corporateTax * MUNICIPAL_INCOME_PORTION_RATE);
}

// 法人事業税 (所得割: 中小=外形非対象として簡易)
const BUSINESS_TAX_BRACKETS = [
  { up_to: 4_000_000, rate: 0.035 }, // 軽減税率 (R6 中小)
  { up_to: 8_000_000, rate: 0.053 },
  { up_to: Infinity, rate: 0.07 },
];
export function calcBusinessTax(taxableIncome: number, isSmb: boolean): number {
  if (taxableIncome <= 0) return 0;
  if (!isSmb) return Math.floor(taxableIncome * 0.07);
  let tax = 0;
  let remaining = taxableIncome;
  let prev = 0;
  for (const b of BUSINESS_TAX_BRACKETS) {
    const span = Math.min(remaining, b.up_to - prev);
    if (span <= 0) break;
    tax += span * b.rate;
    remaining -= span;
    prev = b.up_to;
  }
  return Math.floor(tax);
}

// 特別法人事業税 (国税・都道府県が事業税と併せて徴収)
// ★2026-11-08 追加: 以前は総額から抜けていた。
//   外形標準課税の対象でない普通法人: 標準税率で計算した所得割額 (基準法人所得割額) × 37%
//   (特別法人事業税及び特別法人事業譲与税に関する法律 7条)。上の区分の税率は標準税率なので、そのまま基準に使える。
//   資本金1億円超の法人は外形標準課税の対象で、所得割・特別法人事業税とも別の税率になる。ここでは扱わない (結果に注意書きを付ける)。
export const SPECIAL_CORPORATE_BUSINESS_TAX_RATE = 0.37;
export function calcSpecialCorporateBusinessTax(businessTax: number): number {
  if (businessTax <= 0) return 0;
  return Math.floor(businessTax * SPECIAL_CORPORATE_BUSINESS_TAX_RATE);
}

export interface CorporateFilingResult {
  corporate_tax: number;
  local_corporate_tax: number;
  municipal_equal: MunicipalEqualPortion;
  municipal_income_portion: number;
  business_tax: number;
  special_business_tax: number;
  total_tax: number;
  /** 簡易計算が当てはまらない条件のときの注意書き (当てはまるときは空文字) */
  caution_ja: string;
}

export function calcCorporateFiling(input: CorporateFilingInput): CorporateFilingResult {
  const cTax = calcCorporateTax(input);
  const localC = calcLocalCorporateTax(cTax);
  const muniEq = calcMunicipalEqualPortion(input);
  const muniInc = calcMunicipalIncomePortion(cTax);
  const biz = calcBusinessTax(input.taxable_income, input.is_smb);
  const sbt = calcSpecialCorporateBusinessTax(biz);
  return {
    corporate_tax: cTax,
    local_corporate_tax: localC,
    municipal_equal: muniEq,
    municipal_income_portion: muniInc,
    business_tax: biz,
    special_business_tax: sbt,
    total_tax: cTax + localC + muniEq.total + muniInc + biz + sbt,
    caution_ja: input.is_smb
      ? ""
      : "資本金1億円超の法人は外形標準課税の対象です。事業税と特別法人事業税はこの簡易計算と異なるため、申告には使わないでください。",
  };
}

// ===================
// 消費税申告
// ===================

export type ConsumptionTaxRate = "10%" | "8%" | "exempt";
export type ConsumptionTaxMethod = "general" | "simplified" | "two_percent_special" | "three_percent_special";
/** ★2026-09-30 (JPO-I1) 追加: 事業者の区分 (3割特例は個人だけ) */
export type TaxpayerKind = "individual" | "corporation";

export interface ConsumptionTaxLine {
  amount_excl: number; // 税抜
  rate: ConsumptionTaxRate;
  /**
   * ★2026-09-30 (JPO-I1) 追加 (仕入の明細だけで使う):
   * 仕入先が適格請求書発行事業者か。false のとき経過措置の対象 (申告する側の登録の有無ではない)。
   * 省略時は従来どおり登録事業者からの仕入として満額で控除する。
   */
  from_registered_issuer?: boolean;
  /** 課税仕入れの日 (資産は引渡しの日・役務は提供完了の日)。経過措置の控除割合はこの日で判定する */
  transaction_date?: string;
  /** 仕入先の識別子 (一の免税事業者等ごとの控除限度額の累計に使う) */
  supplier_id?: string;
}

export interface ConsumptionTaxInput {
  sales: ConsumptionTaxLine[];
  purchases: ConsumptionTaxLine[];
  method: ConsumptionTaxMethod;
  business_category?: 1 | 2 | 3 | 4 | 5 | 6; // 簡易課税の事業区分 (1=卸売 90% 〜 6=不動産 40%)
  is_invoice_registered?: boolean; // 適格請求書発行事業者
  /**
   * 登録がなければ免税事業者となる事業者か (2割特例・3割特例に共通の前提)。
   * 使えるかどうかは課税期間でも判定する (2割特例=令和8年9月30日の属する課税期間まで)。
   */
  is_two_percent_eligible?: boolean;
  /** ★2026-09-30 (JPO-I1) 追加: 個人/法人。3割特例は個人だけ */
  taxpayer_kind?: TaxpayerKind;
  /** ★2026-09-30 (JPO-I1) 追加: 課税期間の開始日・終了日 (ISO)。2割・3割特例と控除限度額の判定に使う */
  taxable_period_start?: string;
  taxable_period_end?: string;
  /** ★2026-09-30 (JPO-I1) 追加: 基準期間の課税売上高 (3割特例は1,000万円以下) */
  base_period_taxable_sales?: number;
}

const CONSUMPTION_RATE_VAT: Record<ConsumptionTaxRate, number> = {
  "10%": 0.10,
  "8%": 0.08,
  "exempt": 0,
};

const SIMPLIFIED_DEEMED_RATE: Record<1 | 2 | 3 | 4 | 5 | 6, number> = {
  1: 0.90, // 卸売業
  2: 0.80, // 小売業
  3: 0.70, // 製造業等
  4: 0.60, // その他 (飲食店等)
  5: 0.50, // サービス業等
  6: 0.40, // 不動産業
};

export interface ConsumptionTaxResult {
  total_sales_excl: number;
  total_purchases_excl: number;
  output_tax: number; // 売上に係る消費税
  input_tax: number; // 仕入に係る消費税控除
  net_tax: number;
  method_used: ConsumptionTaxMethod;
  notes: string[];
}

/* ------------------------------------------------------------------
 * ★2026-09-30 (JPO-I1): 経過措置・2割特例・3割特例・少額特例の値は tax-calendar.json (値表) だけから引く。
 *   値表を読めないときは旧い値で計算を続けず、「判定できません」を返して一般課税・控除なしの安全側に倒す。
 * ------------------------------------------------------------------ */
function calendarOrNull(cal?: TaxCalendar): TaxCalendar | null {
  if (cal) return cal;
  try {
    return loadTaxCalendar();
  } catch {
    return null;
  }
}
const CALENDAR_MISSING_JA = "税の値表(tax-calendar.json)を読み込めないため";
const pct = (r: number) => `${Math.round(r * 100)}%`;

/** 経過措置の控除割合の表を値表から組み立てる (案内文の割合を計算と同じ出所にするため) */
export function describeInvoiceTransitionalSchedule(cal?: TaxCalendar): string {
  const c = calendarOrNull(cal);
  if (!c) return `${CALENDAR_MISSING_JA}、経過措置の控除割合を表示できません。`;
  const ps = c.consumption_tax.invoice_transitional_measures.periods;
  return (
    "経過措置の控除割合(課税仕入れの日で判定): " +
    ps.map((p) => `${p.wareki ?? `${p.effective_from}〜${p.effective_to ?? ""}`} ${pct(p.deduction_ratio)}`).join(" / ")
  );
}

export interface SpecialJudgement {
  eligible: boolean;
  deemed_deduction_ratio: number | null;
  reason: string;
}

/** 2割特例: 課税期間が令和8年9月30日までの日を含むか (取引日では判定しない)。国税庁Q&A 問114・問115 */
export function judgeTwoPercentSpecial(input: ConsumptionTaxInput, cal?: TaxCalendar): SpecialJudgement {
  if (!input.is_two_percent_eligible || !input.is_invoice_registered) {
    return { eligible: false, deemed_deduction_ratio: null, reason: "2割特例: インボイス登録 + 免税事業者からの転換等の要件未充足" };
  }
  const s = input.taxable_period_start;
  const e = input.taxable_period_end;
  if (!s || !e) {
    return { eligible: false, deemed_deduction_ratio: null, reason: "課税期間(開始日・終了日)が指定されていないため、2割特例を使えるか判定できません" };
  }
  const c = calendarOrNull(cal);
  const spec = c?.consumption_tax.two_percent_special;
  if (!spec || spec.effective_to === null) {
    return { eligible: false, deemed_deduction_ratio: null, reason: `${CALENDAR_MISSING_JA}、2割特例を使えるか判定できません` };
  }
  if (s > spec.effective_to) {
    const three = c?.consumption_tax.three_percent_special;
    const hint =
      input.taxpayer_kind === "individual" && three
        ? `個人の${three.tax_years.map((y) => `${y}年分`).join("・")}は3割特例(three_percent_special)の対象か確認してください`
        : input.taxpayer_kind === "corporation"
          ? "法人に後継の特例はありません"
          : "個人は3割特例の対象か確認してください(法人に後継の特例はありません)";
    return {
      eligible: false,
      deemed_deduction_ratio: null,
      reason: `課税期間 ${s}〜${e} は ${spec.effective_to} の属する課税期間より後のため、2割特例は使えません。${hint}`,
    };
  }
  if (e < spec.effective_from) {
    return { eligible: false, deemed_deduction_ratio: null, reason: `課税期間 ${s}〜${e} はインボイス制度の開始 (${spec.effective_from}) より前のため、2割特例は使えません` };
  }
  return {
    eligible: true,
    deemed_deduction_ratio: spec.deemed_deduction_ratio,
    reason: `インボイス制度の2割特例 (課税期間 ${s}〜${e} が ${spec.effective_to} までの日を含む) で計算: 納付税額=売上税額×${pct(1 - spec.deemed_deduction_ratio)}`,
  };
}

/** 3割特例: 個人の令和9年分・令和10年分・基準期間の課税売上高1,000万円以下。国税庁Q&A 問114-2 */
export function judgeThreePercentSpecial(input: ConsumptionTaxInput, cal?: TaxCalendar): SpecialJudgement {
  const no = (reason: string): SpecialJudgement => ({ eligible: false, deemed_deduction_ratio: null, reason });
  if (!input.is_two_percent_eligible || !input.is_invoice_registered) {
    return no("3割特例: インボイス登録 + 登録がなければ免税事業者となる要件が未充足");
  }
  if (input.taxpayer_kind !== "individual") {
    return no(input.taxpayer_kind === "corporation" ? "法人は3割特例を使えません" : "個人か法人かが指定されていないため、3割特例を使えるか判定できません");
  }
  const s = input.taxable_period_start;
  const e = input.taxable_period_end;
  if (!s || !e) return no("課税期間(年分)が指定されていないため、3割特例を使えるか判定できません");
  const c = calendarOrNull(cal);
  const spec = c?.consumption_tax.three_percent_special;
  if (!spec) return no(`${CALENDAR_MISSING_JA}(または3割特例の定めが無いため)、3割特例を使えるか判定できません`);
  const year = Number(s.slice(0, 4));
  if (s.slice(0, 4) !== e.slice(0, 4) || !spec.tax_years.includes(year)) {
    return no(`課税期間 ${s}〜${e} は3割特例の対象年分 (${spec.tax_years.map((y) => `${y}年分`).join("・")}) ではありません`);
  }
  if (typeof input.base_period_taxable_sales !== "number") {
    return no("基準期間の課税売上高が指定されていないため、3割特例を使えるか判定できません");
  }
  if (input.base_period_taxable_sales > spec.base_period_sales_ceiling) {
    return no(`基準期間の課税売上高 ${input.base_period_taxable_sales.toLocaleString("ja-JP")}円 が ${spec.base_period_sales_ceiling.toLocaleString("ja-JP")}円 を超えるため、3割特例は使えません`);
  }
  return {
    eligible: true,
    deemed_deduction_ratio: spec.deemed_deduction_ratio,
    reason: `3割特例 (個人の${year}年分) で計算: 納付税額=売上税額×${pct(1 - spec.deemed_deduction_ratio)}`,
  };
}

/** 一般課税で、仕入先が適格請求書発行事業者でない課税仕入れの控除額 (経過措置後) を出す */
function transitionalInputTaxForFiling(lines: ConsumptionTaxLine[], input: ConsumptionTaxInput, cal: TaxCalendar | undefined, notes: string[]): number {
  const c = calendarOrNull(cal);
  if (!c) {
    notes.push(`${CALENDAR_MISSING_JA}、仕入先が適格請求書発行事業者でない課税仕入れ ${lines.length} 件の控除割合を判定できず、控除に含めていません`);
    return 0;
  }
  const dated = lines.filter((l) => !!l.transaction_date && l.rate !== "exempt");
  const undated = lines.filter((l) => !l.transaction_date && l.rate !== "exempt");
  if (undated.length > 0) {
    notes.push(`仕入先が適格請求書発行事業者でない課税仕入れ ${undated.length} 件は課税仕入れの日が無く、経過措置の控除割合を判定できないため控除に含めていません`);
  }
  if (dated.length === 0) return 0;
  const r = calcTransitionalCreditForFiling(
    dated.map((l) => ({
      amount_excl: l.amount_excl,
      rate_kind: l.rate === "8%" ? ("reduced" as const) : ("standard" as const),
      transaction_date: l.transaction_date as string,
      supplier_id: l.supplier_id,
    })),
    c,
    { taxable_period_start: input.taxable_period_start },
  );
  const byDate = new Map<string, number>();
  for (const l of dated) byDate.set(l.transaction_date as string, (byDate.get(l.transaction_date as string) ?? 0) + 1);
  const parts = [...byDate.entries()].sort().map(([d, n]) => {
    const p = resolveTransitionalForFiling(d, c);
    return `${d} ${n}件=${pct(p.deduction_ratio)}(${p.wareki ?? p.label})`;
  });
  notes.push(`仕入先が適格請求書発行事業者でない課税仕入れに経過措置を適用 (課税仕入れの日で判定): ${parts.join(" / ")}`);
  notes.push(describeInvoiceTransitionalSchedule(c));
  notes.push(...r.notes);
  return r.total_creditable;
}

export function calcConsumptionTax(input: ConsumptionTaxInput, cal?: TaxCalendar): ConsumptionTaxResult {
  const notes: string[] = [];
  const totalSales = input.sales.reduce((a, b) => a + b.amount_excl, 0);
  const totalPurchases = input.purchases.reduce((a, b) => a + b.amount_excl, 0);
  const outputTax = input.sales.reduce(
    (a, b) => a + b.amount_excl * CONSUMPTION_RATE_VAT[b.rate],
    0,
  );

  let inputTax = 0;
  let methodUsed = input.method;

  if (input.method === "simplified") {
    if (!input.business_category) {
      notes.push("簡易課税は事業区分が必要。一般課税にフォールバック");
      methodUsed = "general";
    } else {
      const deemedRate = SIMPLIFIED_DEEMED_RATE[input.business_category];
      inputTax = outputTax * deemedRate;
      notes.push(`簡易課税 区分${input.business_category} みなし仕入率 ${(deemedRate * 100).toFixed(0)}%`);
    }
  }

  if (input.method === "two_percent_special") {
    const j2 = judgeTwoPercentSpecial(input, cal);
    if (!j2.eligible || j2.deemed_deduction_ratio === null) {
      notes.push(`${j2.reason}。一般課税にフォールバック`);
      methodUsed = "general";
    } else {
      // 売上税額の8割を仕入税額控除と看做す = 納税は売上税額の2割 (割合は値表から)
      const deemedBp = Math.round(j2.deemed_deduction_ratio * 10000);
      inputTax = (outputTax * deemedBp) / 10000;
      notes.push(j2.reason);
    }
  }

  if (input.method === "three_percent_special") {
    const j3 = judgeThreePercentSpecial(input, cal);
    if (!j3.eligible || j3.deemed_deduction_ratio === null) {
      notes.push(`${j3.reason}。一般課税にフォールバック`);
      methodUsed = "general";
    } else {
      // 売上税額の7割を仕入税額控除と看做す = 納税は売上税額の3割 (割合は値表から)
      const deemed3Bp = Math.round(j3.deemed_deduction_ratio * 10000);
      inputTax = (outputTax * deemed3Bp) / 10000;
      notes.push(j3.reason);
    }
  }

  if (methodUsed === "general") {
    // 仕入先が適格請求書発行事業者の仕入 (from_registered_issuer 省略=登録事業者) は満額で控除
    const registeredPurchases = input.purchases.filter((p) => p.from_registered_issuer !== false);
    const nonRegistrantPurchases = input.purchases.filter((p) => p.from_registered_issuer === false);
    inputTax = registeredPurchases.reduce(
      (a, b) => a + b.amount_excl * CONSUMPTION_RATE_VAT[b.rate],
      0,
    );
    if (nonRegistrantPurchases.length > 0) {
      inputTax += transitionalInputTaxForFiling(nonRegistrantPurchases, input, cal, notes);
    }
  }

  const net = Math.max(0, Math.floor(outputTax - inputTax));
  return {
    total_sales_excl: totalSales,
    total_purchases_excl: totalPurchases,
    output_tax: Math.floor(outputTax),
    input_tax: Math.floor(inputTax),
    net_tax: net,
    method_used: methodUsed,
    notes,
  };
}

/**
 * 少額特例 (旧い判定・互換のため残す)。
 * @deprecated 課税仕入れの日と税込の判定ができない。judgeShougakuTokurei を使うこと。
 *   第1引数は「支払対価の額(税込)」を渡すこと (税抜を渡すと 税込1万円以上の取引を対象と誤判定する)。
 */
export function isShougakuTokureiEligible(
  amountIncl: number,
  baseTaxableSales: number,
  specialPeriodSales?: number,
): boolean {
  if (amountIncl >= 10_000) return false;
  if (baseTaxableSales <= 100_000_000) return true;
  if (specialPeriodSales !== undefined && specialPeriodSales <= 50_000_000) return true;
  return false;
}

/**
 * ★2026-09-30 (JPO-I1) 追加: 少額特例の判定 (税込・課税仕入れの日・基準期間/特定期間)。
 *   値 (1万円・期限・1億円・5,000万円) は tax-calendar.json の shougaku_tokurei から引く。
 *   出典: 国税庁「少額特例における１万円未満の判定単位」(0024003-016)
 */
export function judgeShougakuTokurei(
  input: {
    amount_incl: number;
    transaction_date: string;
    base_period_taxable_sales?: number;
    special_period_taxable_sales?: number;
  },
  cal?: TaxCalendar,
): { eligible: boolean; reason: string } {
  const c = calendarOrNull(cal);
  const sp = c?.consumption_tax.shougaku_tokurei;
  if (!sp) return { eligible: false, reason: `${CALENDAR_MISSING_JA}、少額特例を判定できません` };
  if (typeof input.amount_incl !== "number") return { eligible: false, reason: "支払対価の額(税込)が無いため判定できません" };
  const d = input.transaction_date;
  if (!d || d < sp.effective_from || (sp.effective_to !== null && d > sp.effective_to)) {
    return { eligible: false, reason: `課税仕入れの日 ${d} は少額特例の期間 (${sp.effective_from}〜${sp.effective_to ?? ""}) の外です` };
  }
  if (input.amount_incl >= sp.threshold_amount_incl) {
    return { eligible: false, reason: `支払対価の額(税込) ${input.amount_incl.toLocaleString("ja-JP")}円 は ${sp.threshold_amount_incl.toLocaleString("ja-JP")}円 未満ではありません` };
  }
  if (typeof input.base_period_taxable_sales === "number" && input.base_period_taxable_sales <= sp.base_period_sales_ceiling) {
    return { eligible: true, reason: "基準期間の課税売上高が上限以下" };
  }
  if (typeof input.special_period_taxable_sales === "number" && input.special_period_taxable_sales <= sp.special_period_sales_ceiling) {
    return { eligible: true, reason: "特定期間の課税売上高が上限以下" };
  }
  if (typeof input.base_period_taxable_sales !== "number") {
    return { eligible: false, reason: "基準期間の課税売上高が無いため判定できません" };
  }
  return { eligible: false, reason: "基準期間・特定期間の課税売上高が上限を超えています" };
}

// ============================================================
// [L7/v2043 橋渡し] インボイス経過措置の実行可能化 (wave2-tax-edit.lock mkdir原子で追記)
// ------------------------------------------------------------
// 以前の calcConsumptionTax の notes は免税事業者からの仕入について経過措置を「別途適用」と
// 案内するのみで(しかも改正前の段階を書いていた)、実際の控除額計算は持っていなかった(片肺)。
// ★2026-09-30 (JPO-I1): calcConsumptionTax も仕入先が未登録の明細を経過措置で計算し、案内文を値表から作る。
// 実計算(施行日境界での 80→70→50→30→0% 解決と、一の免税事業者等ごとの控除限度額)は
// tax-engine/consumption-tax-calculator.ts に年度キー(tax-calendar.json)方式で実装済み。
// 既存利用側がそのまま到達できるよう re-export する(既存 export は無改変・追加のみ)。
export {
  calcInvoiceTransitionalCredit,
  calcConsumptionTaxWithTransitional,
  resolveInvoiceTransitional,
} from "./tax-engine/consumption-tax-calculator.js";
// ★2026-09-30 (JPO-I1): 控除限度額 (課税期間の開始日で 10億円/1億円) の引き口も公開する
export { resolveTransitionalCap } from "./tax-engine/consumption-tax-calculator.js";
