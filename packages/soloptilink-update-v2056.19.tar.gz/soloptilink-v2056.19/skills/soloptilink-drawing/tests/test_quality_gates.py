#!/usr/bin/env python3
"""品質ゲートの回帰テスト（両側弁別）

2026-07 に発覚した重大欠陥
  ・寸法文字が縮尺倍に巨大化して図面を覆う（文字被り）
  ・図形が図枠を数千mm突き破る
  ・それをドクターが PASS と判定していた
を二度と通さないための番人。

「健全な図面は PASS」だけでなく「壊れた図面は必ず FAIL」の両方を実証する。
片側しか見ないと、検査が常に PASS を返すだけの飾りになっていても気づけない。

実行: python3 tests/test_quality_gates.py
"""
from __future__ import annotations

# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if __name__ == "__main__":
    import sys as _sl_trial_sys
    from pathlib import Path as _SlTrialPath
    _sl_trial_sys.path.insert(0, str((_SlTrialPath(__file__).resolve().parent / "..").resolve()))
    from _trial_guard import require_runtime as _require_trial_runtime
    _require_trial_runtime("soloptilink-drawing")
# SOLOPTILINK-TRIAL-ENTRY:END


import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))

import ezdxf  # noqa: E402

import drawing_qc  # noqa: E402
from dxf_base import OgumiDXF, TH_SMALL  # noqa: E402
from layout import Panel, View, fit_scale, split_cols, split_rows  # noqa: E402
from textfit import Label, LabelPlacer, Rect, count_overlaps, text_width  # noqa: E402

_failures: list = []
_passes = 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passes
    if cond:
        _passes += 1
        print(f"  ✓ {name}")
    else:
        _failures.append(name)
        print(f"  ✗ {name}  {detail}")


def build_healthy(path: str) -> None:
    """新基盤で作った健全な図面"""
    d = OgumiDXF(paper="A1", scale=100, title="回帰テスト図",
                 drawing_no="T-001", project="品質ゲート回帰テスト",
                 client="", designer="")
    v = View(d.content_panel(), preferred_scale=None, title="【試験図】")
    v.rect(0, 0, 60000, 4000, "11-PIPE")
    v.circle((30000, 2000), 1500, "1-CENTER")
    v.dim((0, 0), (60000, 0), "h", offset_mm=12, text="L=60.0m")
    v.dim((0, 0), (0, 4000), "v", offset_mm=12, text="W=4.0m")
    for i in range(12):
        v.label(f"注記{i}", (30000, 2000), TH_SMALL)   # 全部同じ点に重ねる
    d.place(v)
    d.table(60, 120, [["項目", "値"], ["工法", "コマンド"], ["口径", "φ400"]],
            [30, 40], title="【仕様】")
    d.legend(60, 80, [("11-PIPE", "推進管"), ("1-CENTER", "中心線")])
    d.finish(path)


def build_broken(path: str) -> None:
    """v1 と同じ壊れ方を再現した図面（巨大寸法文字＋図枠外へはみ出し）"""
    doc = ezdxf.new(dxfversion="R2018", setup=True)
    msp = doc.modelspace()
    doc.layers.add("5-FRAME", color=7)
    doc.layers.add("3-TEXT", color=7)
    # A1 図枠
    msp.add_lwpolyline([(25, 10), (831, 10), (831, 584), (25, 584)],
                       dxfattribs={"layer": "5-FRAME"}).close(True)
    # 縮尺倍に巨大化した寸法文字（v1 の DIMSCALE=100 相当）
    msp.add_text("L=88.5m (74本)",
                 dxfattribs={"layer": "3-TEXT", "height": 250}).set_placement((100, 300))
    # 図枠外へ大きくはみ出す図形
    msp.add_line((-200, -100), (1200, 800), dxfattribs={"layer": "3-TEXT"})
    # 重なる文字
    msp.add_text("内空W=4.0m", dxfattribs={"layer": "3-TEXT", "height": 3}).set_placement((100, 100))
    msp.add_text("内空L=5.0m", dxfattribs={"layer": "3-TEXT", "height": 3}).set_placement((101, 100))
    doc.saveas(path)


def main() -> int:
    tmp = tempfile.mkdtemp(prefix="suishin_qc_")
    healthy = os.path.join(tmp, "healthy.dxf")
    broken = os.path.join(tmp, "broken.dxf")

    print("\n[1] 部品の単体動作")
    check("縮尺選定: 65m を A1 に収める", fit_scale(65000, 800, 700, 300) == 100)
    check("縮尺選定: 収まらない希望縮尺は自動で粗くする",
          fit_scale(65000, 800, 700, 300, preferred=20) == 100)
    check("縮尺選定: 収まる希望縮尺は尊重する",
          fit_scale(5000, 4000, 700, 300, preferred=50) == 50)
    check("日本語の文字幅推定（全角は文字高と同幅）",
          abs(text_width("あいう", 3.0) - 9.0) < 1e-6,
          f"実測 {text_width('あいう', 3.0)}")
    p = LabelPlacer(bounds=Rect(0, 0, 200, 120))
    for i in range(8):
        p.add(Label(text=f"重なる注記{i}", x=50, y=60, height=3.0))
    placed, unresolved = p.resolve()
    check("文字衝突回避: 8件を重なりゼロで配置",
          count_overlaps([l.rect() for l in placed]) == 0 and not unresolved)
    left = split_cols(Panel("m", 0, 0, 800, 500), [2, 1])[0]
    panels = split_rows(left, [1, 1])
    check("パネル分割が破綻しない",
          len(panels) == 2 and all(p.w > 0 and p.h > 0 for p in panels))

    print("\n[2] 健全な図面は PASS になる")
    build_healthy(healthy)
    good = drawing_qc.analyze(healthy)
    for key in ("layout_overflow", "text_too_large", "text_overlap", "dimstyle_scale"):
        check(f"健全: {key} = PASS", good["checks"][key]["verdict"] == "PASS",
              good["checks"][key]["detail"])
    check("健全: 総合 PASS", good["verdict"] == "PASS", str(good["verdict"]))

    print("\n[3] 壊れた図面は必ず FAIL になる（検査が飾りでないことの証明）")
    build_broken(broken)
    bad = drawing_qc.analyze(broken)
    check("壊れ: 図枠はみ出しを検出",
          bad["checks"]["layout_overflow"]["verdict"] == "FAIL",
          bad["checks"]["layout_overflow"]["detail"])
    check("壊れ: 巨大文字を検出",
          bad["checks"]["text_too_large"]["verdict"] == "FAIL",
          bad["checks"]["text_too_large"]["detail"])
    check("壊れ: 文字の重なりを検出",
          bad["checks"]["text_overlap"]["verdict"] == "FAIL",
          bad["checks"]["text_overlap"]["detail"])
    check("壊れ: 総合 FAIL", bad["verdict"] == "FAIL", str(bad["verdict"]))

    print("\n[4] 寸法スタイルの倍率が 1.0 に固定されている")
    d = OgumiDXF(paper="A3", scale=2500, title="倍率確認", project="t")
    check("縮尺2500でも DIMSCALE は 1.0",
          float(d.doc.dimstyles.get("SUISHIN").dxf.dimscale) == 1.0,
          str(d.doc.dimstyles.get("SUISHIN").dxf.dimscale))

    print("\n" + "=" * 60)
    if _failures:
        print(f"  結果: FAIL  （成功 {_passes} / 失敗 {len(_failures)}）")
        for f in _failures:
            print(f"    - {f}")
        print("=" * 60)
        return 1
    print(f"  結果: PASS  （全 {_passes} 項目）")
    print("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
