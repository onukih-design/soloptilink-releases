#!/usr/bin/env bash
# 自己検査は通常処理と終了フックより先に分岐し、本物の設定には触れない。
mig_selftest() {
    python3 - "$0" "$$" <<'PYTEST'
import hashlib, json, os, stat, subprocess, sys, tempfile
from pathlib import Path

script = Path(sys.argv[1]).resolve()
secret = "sl-sentinel-" + sys.argv[2] + "-do-not-copy"
wirings = [('SessionStart', 'killswitch-drift-sentinel.sh', 'lib/hooks/killswitch-drift-sentinel.sh')]
passed = failed = 0

def report(label, ok):
    global passed, failed
    print("  " + ("PASS" if ok else "FAIL") + "  " + label)
    if ok:
        passed += 1
    else:
        failed += 1

def secret_files(home):
    matches = []
    for folder in (home / ".claude", home / ".soloptilink"):
        for path in folder.rglob("*"):
            if stat.S_ISREG(path.lstat().st_mode) and secret.encode() in path.read_bytes():
                matches.append(path)
    return matches

def prepare(home):
    (home / ".claude").mkdir(parents=True)
    sl = home / ".soloptilink"
    sl.mkdir()
    for event, fragment, target in wirings:
        path = sl / target
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
        path.chmod(0o700)

    return home / ".claude/settings.json"

def apply(home, extra=None):
    env = dict(os.environ, HOME=str(home), SOLOPTILINK_DIR=str(home / ".soloptilink"))
    if extra:
        env.update(extra)
    return subprocess.run(["/bin/bash", str(script)], env=env, capture_output=True)

def healthy(home, extra=None):
    settings = prepare(home)
    settings.write_text(json.dumps({"env": {"SL_SENTINEL_SECRET": secret}, "customer_setting": "維持"}), encoding="utf-8")
    settings.chmod(0o600)
    before = settings.read_bytes()
    result = apply(home, extra)
    data = json.loads(settings.read_text(encoding="utf-8"))
    registered = all(any(fragment in hook.get("command", "")
        for group in data.get("hooks", {}).get(event, [])
        for hook in group.get("hooks", [])) for event, fragment, target in wirings)
    return (result.returncode == 0 and before != settings.read_bytes() and registered
        and secret_files(home) == [settings]
        and not (home / ".claude" / ("." + "backups")).exists()
        and stat.S_IMODE(os.stat(settings).st_mode) == 0o600
        and data.get("env", {}).get("SL_SENTINEL_SECRET") == secret
        and data.get("customer_setting") == "維持")

parent = Path(tempfile.gettempdir())
parent.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(prefix=script.stem + "-selftest-", dir=str(parent)) as temporary:
    root = Path(temporary)
    control = root / "control"
    settings = prepare(control)
    settings.write_text(json.dumps({"env": {"SL_SENTINEL_SECRET": secret}}), encoding="utf-8")
    (control / ".soloptilink" / "fake-copy.txt").write_text(secret, encoding="utf-8")
    control_ok = len(secret_files(control)) == 2
    report("偽の控えを含む 2 ファイルを検出して不合格にできる", control_ok)
    report("登録を実走し、全文控えなし・権限 600・環境変数の維持を確認", healthy(root / "healthy") and control_ok)
    unchanged = True
    for index, malformed in enumerate((b"{broken", b"[]", b"null", b"{}\n{}")):
        home = root / ("broken-%d" % index)
        settings = prepare(home)
        settings.write_bytes(malformed)
        before = hashlib.sha256(settings.read_bytes()).digest()
        apply(home)
        state = home / ".soloptilink/.migration-state.json"
        names = home / ".soloptilink/.migration-state.json.names"
        unchanged = unchanged and hashlib.sha256(settings.read_bytes()).digest() == before and not state.exists() and not names.exists()
    report("壊れた設定と辞書以外の設定はバイト不変・state 未記録", unchanged)

print("合計: PASS %d / FAIL %d" % (passed, failed))
sys.exit(1 if failed else 0)
PYTEST
}
if [ "${1:-}" = "selftest" ]; then
    mig_selftest
    exit $?
fi

# 試用端末では、登録した命令全体を終了時に試用の関所で覆う（有料端末は変更しない）。
trap '[ ! -f "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" ] || bash "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" >/dev/null 2>&1 || true' EXIT
# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# ============================================================
# v2054.7 kill-switch 自動復旧センチネル 配線 migration (2026-07-25)
# ------------------------------------------------------------
# 構造欠陥の遡及修正: 完成ゲート群の kill-switch が settings.json で off のまま放置されると
#   顧客の全ビルドで物理検証 (実ログイン・実ブラウザ全ページ巡回) が素通りする。
#   これを毎セッション自動復旧する killswitch-drift-sentinel.sh は配布はされていたが、
#   顧客端末の settings.json へ登録する経路が存在せず **一度も起動していなかった**。
#   本 migration は SessionStart への配線を冪等に行う。
#
# - 冪等: コマンド断片が既に配線済みなら何もしない
# 設定の全文の控えは作らない（環境変数や許可の設定が残り続けていたため。2026-10-28）。
# 読めない設定は書き換えず、一時ファイルを JSON として読み直してから原子的に置き換える。
# - 万一 python3 が無い環境では何もせず正常終了 (再試行可能)
# 手動実行: bash ~/.soloptilink/migration/v2054_killswitch_sentinel.sh
# ============================================================
set -u

MIG_NAME="v2054_killswitch_sentinel"
SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
CLAUDE_DIR="$HOME/.claude"
SETTINGS_FILE="$CLAUDE_DIR/settings.json"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"

mkdir -p "$SL_DIR" "$CLAUDE_DIR" 2>/dev/null || true

mig_log() {
    echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}

mig_log "START"

# 冪等性: 適用済みなら NOOP
if [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; then
    mig_log "ALREADY_APPLIED -> NOOP"
    exit 0
fi

# python3 必須 (無ければ再試行可能なまま終了)
if ! command -v python3 >/dev/null 2>&1; then
    mig_log "PRECONDITION_FAILED python3 not found (retryable)"
    exit 0
fi

# 配線 (実体が存在するフックのみ / コマンド断片一致で重複防止)
WIRE_RESULT=$(SETTINGS_FILE="$SETTINGS_FILE" python3 - <<'PYEOF'
import json, os, sys
# >>> sl-safe-settings-write v2 (2026-10-29) >>>
# お客様の設定の全文の控えは作らない。控えには環境変数や許可の設定がそのまま写り、
# 消す処理がどこにも無いまま残り続けていた。読めた設定だけを一時ファイルに書き、
# JSON として読み直してから原子的に置き換える。読んでから置き換えるまでに
# 別の処理が設定を書いていたら、上書きせずに次の起動でやり直す。
# 設定がリンクのときはリンクを残し、リンク先の実体を同じ手順で置き換える。
# 撤去の段 3 と同じ扱いにそろえた (2026-10-29 独立審査で指摘)。
# v1 はリンクそのものを普通のファイルに置き換え、お客様の管理の先から切り離していた。
# 壊れたリンクと、読んでから置き換えるまでに行き先が変わったリンクには書かずに止める。
def sl_safe_settings_write(path, data, before):
    import json as _json, os as _os, stat as _stat
    target = _os.path.realpath(path)
    folder = _os.path.dirname(target) or "."
    tmp = _os.path.join(folder, "." + _os.path.basename(target) + ".sl-new.%d" % _os.getpid())
    flags = _os.O_WRONLY | _os.O_CREAT | _os.O_EXCL | getattr(_os, "O_NOFOLLOW", 0)
    try:
        fd = _os.open(tmp, flags, 0o600 if before is not None else 0o666)
    except OSError:
        return False
    try:
        with _os.fdopen(fd, "w", encoding="utf-8") as handle:
            if before is not None:
                try:
                    _os.fchmod(handle.fileno(), _stat.S_IMODE(before.st_mode))
                except (AttributeError, OSError):
                    pass
            _json.dump(data, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            _os.fsync(handle.fileno())
        with open(tmp, encoding="utf-8") as handle:
            if not isinstance(_json.load(handle), dict):
                return False
        if _os.path.realpath(path) != target:
            return False
        if before is not None:
            now = _os.stat(path)
            if (now.st_ino, now.st_size, now.st_mtime_ns) != (before.st_ino, before.st_size, before.st_mtime_ns):
                return False
        elif _os.path.lexists(path):
            return False
        _os.replace(tmp, target)
        return True
    except Exception:
        return False
    finally:
        if _os.path.lexists(tmp) and not _os.path.islink(tmp):
            try:
                _os.unlink(tmp)
            except OSError:
                pass
# <<< sl-safe-settings-write v2 <<<
sp = os.environ["SETTINGS_FILE"]
try:
    before = os.stat(sp) if os.path.exists(sp) else None
    if before is None or before.st_size == 0:
        d = {}
    else:
        with open(sp, encoding="utf-8") as f:
            d = json.load(f)
except Exception:
    print("ABORT_UNPARSABLE"); sys.exit(0)
if not isinstance(d, dict):
    print("ABORT_NOT_DICT"); sys.exit(0)
hooks = d.setdefault("hooks", {})
def has(ev, frag):
    for m in hooks.get(ev, []):
        for h in (m.get("hooks") or []):
            if frag in (h.get("command") or ""):
                return True
    return False
home = os.path.expanduser("~")
wirings = [
    ("SessionStart", "killswitch-drift-sentinel.sh",
     "bash ~/.soloptilink/lib/hooks/killswitch-drift-sentinel.sh 2>/dev/null || true",
     home + "/.soloptilink/lib/hooks/killswitch-drift-sentinel.sh"),
]
added = []
missing = 0
for ev, frag, cmd, target in wirings:
    if not os.path.exists(target):
        missing += 1
        continue
    if not has(ev, frag):
        hooks.setdefault(ev, []).append({"hooks": [{"type": "command", "command": cmd}]})
        added.append(f"{ev}:{frag}")
if added and not sl_safe_settings_write(sp, d, before):
    print("WRITE_ABORTED"); sys.exit(0)
if added:
    print("WIRED:" + ",".join(added))
elif missing:
    # 実体がまだ届いていないだけ。「配線済み」と記録すると実体が届いても永久に未配線になる
    print("TARGET_MISSING:%d" % missing)
else:
    print("NOOP_ALREADY_WIRED")
PYEOF
) || { mig_log "WIRE_FAILED (retryable)"; exit 0; }

mig_log "RESULT $WIRE_RESULT"

# state 記録 (配線成功 or 既配線の場合のみ)
case "$WIRE_RESULT" in
    TARGET_MISSING:*)
        mig_log "TARGET_MISSING (not recorded; retry on next update)"
        exit 0
        ;;
    WIRED:*|NOOP_ALREADY_WIRED)
        if [ -f "$STATE_FILE" ]; then
            STATE_FILE="$STATE_FILE" MIG_NAME="$MIG_NAME" python3 -c "
import json, os
p = os.environ['STATE_FILE']
try:
    with open(p) as f:
        d = json.load(f)
except Exception:
    d = {}
d.setdefault('applied', []).append(os.environ['MIG_NAME'])
with open(p, 'w') as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
" 2>/dev/null || echo "{\"applied\":[\"$MIG_NAME\"]}" > "$STATE_FILE"
        else
            echo "{\"applied\":[\"$MIG_NAME\"]}" > "$STATE_FILE"
        fi
        mig_log "APPLIED"
        ;;
    *)
        mig_log "NOT_RECORDED ($WIRE_RESULT) — 次回再試行"
        ;;
esac

exit 0
