#!/usr/bin/env bash
# 試用端末では、登録した命令全体を終了時に試用の関所で覆う（有料端末は変更しない）。
trap '[ ! -f "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" ] || bash "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" >/dev/null 2>&1 || true' EXIT
# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04 の既知事象)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# ============================================================
# v2056.9 — 振り分け (スキル自動連動) の登録を、3 つの導入経路すべてへ届ける
#           R4-09 / 2026-09-16 新設
# ------------------------------------------------------------
# 【何が起きていたか (2026-09-16 の実測)】
#   お客様が 1 文お書きになるたびに適した機能を選ぶ「振り分け」は、端末側の設定
#   (~/.claude/settings.json の UserPromptSubmit) に登録されてはじめて走る。
#   登録する道具 lib/sar-linkage/wire-sar-hook.sh を呼ぶ箇所を数えたところ:
#       setup.sh = 4 件 / installer/SoloptiLinkAI-Setup.command = 0 件 /
#       installer/soloptilink-install.ps1 = 0 件 / auto-update.sh = 0 件 / migration = 0 本
#   配布物の案内が示す導入経路は 3 つ (Mac のダブルクリック・Windows・Linux の setup.sh)
#   だが、結線されていたのは setup.sh だけだった。Mac と Windows の導入経路は
#   setup.sh を一度も呼ばず、代わりに migration/ を全実行する。ほかの 7 本のフックは
#   その migration 経由で届いている。つまり **Windows のお客様には一切届かず、
#   Mac も既定の手順 (ダブルクリック) では届かない** 状態だった。
#
# 【この migration の役目】
#   migration/ は 3 経路すべて (Mac の .command / Windows の .ps1 / Linux の setup.sh) と
#   自動更新 (auto-update.sh) から実行される。ここで登録を行えば、どの入口から入った
#   端末にも同じ登録が残る。導入台本の側にも直接の呼び出しを置いてあり、こちらは
#   「すでに入っている端末」と「python3 が後から入った端末」を拾う二重化である。
#
# 【安全側の原則 (同型 v2056.6_w5_customer_hook_delivery.sh と同じ規律)】
#   - 書くのは 1 本だけ。実体 (lib/sar-linkage/sar-gate.sh) が無ければ登録しない
#   - settings.json が壊れて読めないときは一切書かない (お客様の設定を壊さない)
#     ★判断は登録する道具 wire-sar-hook.sh 側に持たせてある (出どころを 2 つにしない)
#   - 書く前に控えを取る (道具側で実施)
#   - 冪等: すでに登録されていれば何もしない
#   - 退去済み (墓標あり) の端末では登録し直さない (R4-10)
#   - 失敗しても導入・更新そのものは止めない (exit 0)。state を書かないので再試行できる
#
# 【kill-switch】
#   SOLOPTILINK_SAR_WIRE=off … 本 migration を no-op にする (setup.sh の停止スイッチと同名)
#
# CLI:
#   bash ~/.soloptilink/migration/v2056.9_sar_gate_wire.sh            (適用)
#   bash ~/.soloptilink/migration/v2056.9_sar_gate_wire.sh selftest   (両側で測る自己検査)
# ============================================================
set -u

MIG_NAME="v2056.9_sar_gate_wire"
SL_DIR="${SOLOPTILINK_DIR:-${SOLOPTILINK_HOME:-$HOME/.soloptilink}}"
SAR_HOME="${SL_SAR_HOME:-$HOME}"
WIRE_TOOL="${SL_DIR}/lib/sar-linkage/wire-sar-hook.sh"
LOG_FILE="${SL_DIR}/.migration.log"
STATE_FILE="${SL_DIR}/.migration-state.json"

mig_log() {
    echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}

# いま登録されている本数を数える (宣言でなく現物を見る)
mig_count() {
    python3 - "${SAR_HOME}/.claude/settings.json" <<'PY' 2>/dev/null
import json,sys
try: d=json.load(open(sys.argv[1],encoding='utf-8'))
except Exception: print(-1); sys.exit(0)
n=0
for _ev,arr in (d.get('hooks') or {}).items():
    for g in (arr or []):
        for h in ((g or {}).get('hooks') or []):
            if 'sar-linkage/sar-gate.sh' in str((h or {}).get('command','')): n+=1
print(n)
PY
}

mig_apply() {
    mkdir -p "$SL_DIR" 2>/dev/null || true
    mig_log "START home=${SAR_HOME}"

    case "$(printf '%s' "${SOLOPTILINK_SAR_WIRE:-on}" | tr 'A-Z' 'a-z')" in
        off|0|false|no|disabled)
            mig_log "KILL_SWITCH SOLOPTILINK_SAR_WIRE=off -> NOOP (retryable)"
            return 0 ;;
    esac

    # 退去済みの端末では何もしない (R4-10)
    if [ -f "${SAR_HOME}/.claude/.soloptilink-evicted.json" ] &&
       [ "${SOLOPTILINK_EVICT_GUARD:-on}" != "off" ]; then
        mig_log "EVICTED -> NOOP (退去したものを復活させない)"
        return 0
    fi

    if [ ! -f "$WIRE_TOOL" ]; then
        mig_log "PRECONDITION_FAILED wire-sar-hook.sh が無い (retryable)"
        return 0
    fi
    if [ ! -f "${SL_DIR}/lib/sar-linkage/sar-gate.sh" ]; then
        # 実体が無いものは登録しない (毎回失敗する死配線を作らない)
        mig_log "PRECONDITION_FAILED sar-gate.sh の実体が無い (retryable)"
        return 0
    fi
    if ! command -v python3 >/dev/null 2>&1; then
        mig_log "PRECONDITION_FAILED python3 not found (retryable)"
        return 0
    fi

    # すでに登録済みなら何もしない (state を当てにせず現物で判断する)
    if SL_SAR_HOME="$SAR_HOME" bash "$WIRE_TOOL" check >/dev/null 2>&1; then
        mig_log "ALREADY_WIRED -> 台帳だけ確かめます"
    else
        SL_SAR_HOME="$SAR_HOME" bash "$WIRE_TOOL" apply >/dev/null 2>&1
        local arc=$?
        if [ "$arc" -ne 0 ]; then
            mig_log "WIRE_FAILED rc=${arc} (お客様の設定は書き換えていません) -> retryable"
            return 0
        fi
    fi

    # 書いた結果を数え直す (書けた=効いた ではない)
    local n; n="$(mig_count)"
    case "$n" in ''|*[!0-9-]*) n=-1 ;; esac
    if [ "$n" != "1" ]; then
        mig_log "VERIFY_INCOMPLETE registered=${n}/1 -> state を書かず再試行可能にします"
        return 0
    fi

    # 導入台帳 (退去で取り除く対象) に 2 件載っているか
    local mfn; mfn="$(SL_SAR_HOME="$SAR_HOME" bash "$WIRE_TOOL" manifest 2>/dev/null | tr -dc '0-9')"
    case "${mfn:-}" in ''|*[!0-9]*) mfn=0 ;; esac
    if [ "$mfn" -lt 2 ]; then
        mig_log "MANIFEST_INCOMPLETE entries=${mfn}/2 -> state を書かず再試行可能にします"
        return 0
    fi

    local applied_at; applied_at="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    SAR_STATE_FILE="$STATE_FILE" SAR_MIG_NAME="$MIG_NAME" SAR_APPLIED_AT="$applied_at" python3 - <<'PY' 2>>"$LOG_FILE"
import json, os
sf = os.environ['SAR_STATE_FILE']
try:
    with open(sf, encoding="utf-8") as f: data = json.load(f)
except Exception:
    data = {}
if not isinstance(data, dict): data = {}
data[os.environ['SAR_MIG_NAME']] = {"applied_at": os.environ['SAR_APPLIED_AT']}
tmp = sf + ".tmp.%d" % os.getpid()
with open(tmp, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
os.replace(tmp, sf)
PY
    mig_log "DONE applied_at=${applied_at} registered=${n}/1 manifest=${mfn}/2"
    return 0
}

# ------------------------------------------------------------
# selftest — 隔離した偽ホームで実際に走らせて、両側で測る
#   M1 設定ゼロの端末で 1 本登録される
#   M2 冪等 (2 回走らせても 1 本のまま)
#   M3 kill-switch off で 1 本も登録しない
#   M4 壊れた設定を 1 バイトも書き換えない
#   M5 退去済み (墓標あり) の端末では登録しない
#   M6 実体 (sar-gate.sh) が無い端末では登録しない (死配線を作らない)
#   ★砂箱は mktemp -d で作り、消さずに残して場所を表示する
# ------------------------------------------------------------
mig_selftest() {
    local self root rc=0
    self="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
    root="$(mktemp -d "${TMPDIR:-/tmp}/sarmig.XXXXXX")" || return 1

    _mk() {   # $1=名前 : 偽ホーム + 本体の写し (振り分けに要る分だけ)
        local h="$root/$1"
        mkdir -p "$h/.claude" "$h/.soloptilink/lib/sar-linkage" "$h/.soloptilink/lib/evict"
        cp "${SL_DIR}/lib/sar-linkage/wire-sar-hook.sh" "$h/.soloptilink/lib/sar-linkage/" 2>/dev/null
        printf '#!/usr/bin/env bash\nexit 0\n' > "$h/.soloptilink/lib/sar-linkage/sar-gate.sh"
        [ -f "${SL_DIR}/lib/evict/manifest.sh" ] &&
            cp "${SL_DIR}/lib/evict/manifest.sh" "$h/.soloptilink/lib/evict/" 2>/dev/null
        printf '%s' "$h"
    }
    _cnt() { # $1=偽ホーム
        python3 - "$1/.claude/settings.json" <<'PY' 2>/dev/null
import json,sys
try: d=json.load(open(sys.argv[1],encoding='utf-8'))
except Exception: print(-1); sys.exit(0)
n=0
for _ev,arr in (d.get('hooks') or {}).items():
    for g in (arr or []):
        for h in ((g or {}).get('hooks') or []):
            if 'sar-linkage/sar-gate.sh' in str((h or {}).get('command','')): n+=1
print(n)
PY
    }
    _run() { # $1=偽ホーム, 以降 env
        local h="$1"; shift
        env "$@" HOME="$h" SOLOPTILINK_DIR="$h/.soloptilink" SOLOPTILINK_HOME="$h/.soloptilink" \
            bash "$self" >/dev/null 2>&1
    }

    local H1; H1="$(_mk zero)"; _run "$H1"
    local n1; n1="$(_cnt "$H1")"
    if [ "$n1" = "1" ]; then echo "  [OK] 設定ゼロの端末: 1 本登録"; else echo "  [FAIL] 設定ゼロの端末: 登録数=$n1 (期待1)"; rc=1; fi

    _run "$H1"; local n2; n2="$(_cnt "$H1")"
    if [ "$n2" = "1" ]; then echo "  [OK] 冪等: 再実行しても 1 本のまま"; else echo "  [FAIL] 冪等性違反: 登録数=$n2"; rc=1; fi

    local H3; H3="$(_mk killsw)"; _run "$H3" SOLOPTILINK_SAR_WIRE=off
    local n3; n3="$(_cnt "$H3")"
    if [ "$n3" = "0" ] || [ "$n3" = "-1" ]; then echo "  [OK] kill-switch: off で 1 本も登録しない"; else echo "  [FAIL] kill-switch off でも登録した: 登録数=$n3"; rc=1; fi

    local H4; H4="$(_mk broken)"
    printf '{ "env": {"CUSTOMER_KEY":"keep-me"}, こわれた\n' > "$H4/.claude/settings.json"
    local b4; b4="$(cat "$H4/.claude/settings.json")"
    _run "$H4"
    local a4; a4="$(cat "$H4/.claude/settings.json")"
    if [ "$b4" = "$a4" ]; then echo "  [OK] 壊れた設定: 1 バイトも書き換えない"; else echo "  [FAIL] 壊れた設定を書き換えた"; rc=1; fi

    local H5; H5="$(_mk evicted)"
    printf '{"evicted_at":"2026-09-16T00:00:00Z"}\n' > "$H5/.claude/.soloptilink-evicted.json"
    _run "$H5"; local n5; n5="$(_cnt "$H5")"
    if [ "$n5" = "0" ] || [ "$n5" = "-1" ]; then echo "  [OK] 退去済み: 登録し直さない (R4-10)"; else echo "  [FAIL] 退去したものを復活させた: 登録数=$n5"; rc=1; fi

    local H6; H6="$(_mk noentity)"
    mv "$H6/.soloptilink/lib/sar-linkage/sar-gate.sh" "$H6/sar-gate.sh.away" 2>/dev/null
    _run "$H6"; local n6; n6="$(_cnt "$H6")"
    if [ "$n6" = "0" ] || [ "$n6" = "-1" ]; then echo "  [OK] 実体不在: 死配線を作らない"; else echo "  [FAIL] 実体が無いのに登録した: 登録数=$n6"; rc=1; fi

    echo "  砂箱: $root (消さずに残しています)"
    [ "$rc" -eq 0 ] && echo "  検査6項目: 不合格 0 件" || echo "  検査6項目: 不合格あり"
    return $rc
}

case "${1:-apply}" in
    selftest) mig_selftest; exit $? ;;
    apply|"") mig_apply; exit 0 ;;
    *)        mig_apply; exit 0 ;;
esac
