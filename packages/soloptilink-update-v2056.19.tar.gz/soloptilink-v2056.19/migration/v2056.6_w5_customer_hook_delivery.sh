#!/usr/bin/env bash
# 試用端末では、登録した命令全体を終了時に試用の関所で覆う（有料端末は変更しない）。
trap '[ ! -f "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" ] || bash "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" >/dev/null 2>&1 || true' EXIT
# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# ============================================================
# v2056.6 第5波 — 開発機だけで動いていた仕組みを、お客様の端末へ届ける (2026-09-05)
# ------------------------------------------------------------
# 【何が起きていたか (実測)】
#   出荷前検査 L9-HOOK-REG-DRIFT が 17 本を名指ししていた。
#   いずれも「開発機の ~/.claude/settings.json には登録されて実際に発火しているが、
#   お客様の端末へ登録する経路 (migration / installer / setup.sh) がどこにも無い」。
#   つまり、作ってはあるが届いていない。過去に何度も繰り返した型である。
#
#   17 本を 1 本ずつ調べた結果 (2026-09-05 実測):
#     A. 配るべき (実体が配布物に入っており、お客様の端末でも意味がある) = 7 本
#        → 本 migration が登録する
#     B. すでに別経路で届いている = 7 本 (長期記憶の呼び出し口)
#        → lib/memory/memory-hooks-install.sh が setup.sh / auto-update.sh から
#          呼ばれて登録している。本 migration は「登録されているか」を確かめ、
#          抜けていたときだけ同じ仕組みへ修復を依頼する (二重登録はしない)
#     C. 配れない / 配らない = 3 本
#        ★ここは実体名を「そのままの綴り」で書かない。出荷前検査 L9-HOOK-REG-DRIFT は
#          「登録経路の中に実体名が現れるか」を文字列で見ているため、配らないものの名前を
#          そのまま書くと、配っていないのに合格になってしまう (検査を騙すことになる)。
#          読む人には分かる形で、拡張子を外して記す。
#        scripts/solai-claim (所有権主張の判定器) … policies/exclude-list.txt の
#          「scripts/*」により配布物に入らない。登録すると存在しないファイルを
#          毎回叩く死配線になるため登録しない
#        lib/security/local-prompt-shield/shield (APIキー保護の常駐口) … 同 exclude-list の
#          「lib/security/local-prompt-shield/」により配布物に入らない (同上)
#        lib/security/exposure-harm-scan (露出の常設計測) … 実体は配られるが、
#          お客様の会話記録すべてを新たに走査する「当社側の計測」であり、
#          お客様の業務価値ではない。無断で入れない (オーナー判断へ回す)
#
# 【本 migration が登録するもの (A の 9 本 / 10 エントリ)】
#   PreToolUse  Bash|Edit|Write|NotebookEdit          pre-write-evacuation-guard.sh
#   PreToolUse  Bash|Edit|Write|MultiEdit|NotebookEdit permission-ask-hook.sh
#   PreToolUse  (購入・課金系ツール名)                 permission-ask-hook.sh
#   PostToolUse Edit|Write|NotebookEdit                legal-risk-lint/post-tool-use-hook.sh
#   PostToolUse Write|Edit|MultiEdit|NotebookEdit      evidence-secret-scrub-hook.sh
#   PostToolUse *                                     handoff-notice-posttool.sh
#   Stop        *                                     response-gate.sh
#   PreCompact  *                                     autonomy/context-flush.sh
#   ★命令の文字列は開発機で実際に発火している形と同一にしてある
#     (表記が違うと冪等判定が効かず二重登録になる)。
#
# 【自走を止めないこと (DFD 第2版)】
#   ここで登録するもののうち、作業を止めうるのは
#     ・permission-ask-hook.sh … 元に戻せない外部作用 (課金・削除上書き) の直前確認のみ
#     ・response-gate.sh       … 応答の書き直し依頼 (差し戻し上限つき・人の入力は要らない)
#   いずれも人の追加入力を求めて待つものではない。
#
# 【安全側の原則】
#   - 実体ファイルが無いエントリは登録しない (存在しないフックを毎回叩かせない)
#   - settings.json が壊れて読めないときは一切書かない (お客様の設定を壊さない)
#   - 設定の全文の控えは作らない（お客様の秘密が残り続けるため。2026-10-28）
#   - 読めた設定だけを一時ファイルへ書き、JSON として読み直してから原子的に置き換える
#   - 冪等: 同じ登録が既にあれば何もしない
#   - 失敗しても導入・更新そのものは止めない (exit 0)。state を書かないので再試行できる
#
# 【kill-switch】
#   SOLOPTILINK_W5_HOOK_DELIVERY=off … 本 migration を no-op にする (state を書かない)
#
# CLI:
#   bash ~/.soloptilink/migration/v2056.6_w5_customer_hook_delivery.sh            (適用)
#   bash ~/.soloptilink/migration/v2056.6_w5_customer_hook_delivery.sh selftest   (両側判定)
# ============================================================
set -u

MIG_NAME="v2056.6_w5_customer_hook_delivery"
SL_DIR="${SOLOPTILINK_DIR:-${SOLOPTILINK_HOME:-$HOME/.soloptilink}}"
CLAUDE_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
SETTINGS_FILE="${CLAUDE_SETTINGS:-$CLAUDE_DIR/settings.json}"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"
MEM_INSTALLER="lib/memory/memory-hooks-install.sh"

mig_log() {
    echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}

# ------------------------------------------------------------
# 配線を行う python 本体を一時ファイルへ書き出す
#   ★$( ) の内側にヒアドキュメントを置かない (bash 3.2 で壊れる = お客様の Mac で不動)
# ------------------------------------------------------------
_w5_write_py() {
    cat > "$1" <<'PYEOF'
import json, os, sys

# >>> sl-safe-settings-write v2 (2026-10-29) >>>
# お客様の設定の全文の控えは作らない。控えには環境変数や許可の設定がそのまま写り、
# 消す処理がどこにも無いまま残り続けていた。読めた設定だけを一時ファイルに書き、
# JSON として読み直してから原子的に置き換える。読んでから置き換えるまでに
# 別の処理が設定を書いていたら、上書きせずに次の起動でやり直す。
# 設定がリンクのときはリンクを残し、リンク先の実体を同じ手順で置き換える。
# 撤去の段 3 と同じ扱いにそろえた (2026-10-29 独立審査で指摘)。
# v1 はリンクそのものを普通のファイルに置き換え、お客様の管理の先から切り離していた。
# 壊れたリンクと、読んでから置き換えるまでに行き先が変わったリンクには書かずに止める。
def sl_safe_settings_write(path, data, before):
    import json as _json, os as _os, stat as _stat
    target = _os.path.realpath(path)
    folder = _os.path.dirname(target) or "."
    tmp = _os.path.join(folder, "." + _os.path.basename(target) + ".sl-new.%d" % _os.getpid())
    flags = _os.O_WRONLY | _os.O_CREAT | _os.O_EXCL | getattr(_os, "O_NOFOLLOW", 0)
    try:
        fd = _os.open(tmp, flags, 0o600 if before is not None else 0o666)
    except OSError:
        return False
    try:
        with _os.fdopen(fd, "w", encoding="utf-8") as handle:
            if before is not None:
                try:
                    _os.fchmod(handle.fileno(), _stat.S_IMODE(before.st_mode))
                except (AttributeError, OSError):
                    pass
            _json.dump(data, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            _os.fsync(handle.fileno())
        with open(tmp, encoding="utf-8") as handle:
            if not isinstance(_json.load(handle), dict):
                return False
        if _os.path.realpath(path) != target:
            return False
        if before is not None:
            now = _os.stat(path)
            if (now.st_ino, now.st_size, now.st_mtime_ns) != (before.st_ino, before.st_size, before.st_mtime_ns):
                return False
        elif _os.path.lexists(path):
            return False
        _os.replace(tmp, target)
        return True
    except Exception:
        return False
    finally:
        if _os.path.lexists(tmp) and not _os.path.islink(tmp):
            try:
                _os.unlink(tmp)
            except OSError:
                pass
# <<< sl-safe-settings-write v2 <<<


settings = os.environ["W5_SETTINGS"]
sl_dir   = os.environ["W5_SL_DIR"]

# 登録の正典 (ここが唯一の出典)
#   (区切り, 対象, 実体の相対パス, 命令文字列, 制限秒)
WIRINGS = [
    ("PreToolUse",  "Bash|Edit|Write|NotebookEdit",
     "lib/hooks/pre-write-evacuation-guard.sh",
     'env -u BASH_ENV -u ENV bash ~/.soloptilink/lib/hooks/pre-write-evacuation-guard.sh', 20),
    ("PreToolUse",  "Bash|Edit|Write|MultiEdit|NotebookEdit",
     "lib/hooks/permission-ask-hook.sh",
     'env -u BASH_ENV -u ENV bash "$HOME/.soloptilink/lib/hooks/permission-ask-hook.sh"', 20),
    ("PreToolUse",
     "(?:^|_)(?:[Bb]uy|BUY|[Pp]urchase|PURCHASE|[Cc]heckout|CHECKOUT|[Ss]ubscribe|SUBSCRIBE)(?:_|$)|.*_(?:buy|purchase|checkout|subscribe)_.*",
     "lib/hooks/permission-ask-hook.sh",
     'env -u BASH_ENV -u ENV bash "$HOME/.soloptilink/lib/hooks/permission-ask-hook.sh"', 20),
    ("PostToolUse", "Edit|Write|NotebookEdit",
     "lib/legal-risk-lint/post-tool-use-hook.sh",
     'bash "$HOME/.soloptilink/lib/legal-risk-lint/post-tool-use-hook.sh"', 30),
    ("PostToolUse", "Write|Edit|MultiEdit|NotebookEdit",
     "lib/hooks/evidence-secret-scrub-hook.sh",
     'bash "$HOME/.soloptilink/lib/hooks/evidence-secret-scrub-hook.sh"', 30),
    ("PostToolUse", "*",
     "lib/hooks/handoff-notice-posttool.sh",
     'env -u BASH_ENV -u ENV bash ~/.soloptilink/lib/hooks/handoff-notice-posttool.sh 2>/dev/null || true', 30),
    ("Stop",        "*",
     "lib/hooks/response-gate.sh",
     'bash "$HOME/.soloptilink/lib/hooks/response-gate.sh"', 60),
    ("PreCompact",  "*",
     "lib/autonomy/context-flush.sh",
     'env -u BASH_ENV -u ENV bash "$HOME/.soloptilink/lib/autonomy/context-flush.sh" precompact', 60),
    # 【2026-09-16 追加 / 顧客2件「スキルが使えません」の再発防止】
    #   お客様がスラッシュで呼ぶ正本 (~/.claude/commands/<名前>.md) が欠けると、
    #   本体が「直接呼び出せません」と返し、お客様には「使えません」に見える。
    #   この2本は配置処理を呼んで欠けを自動で埋め戻すが、実体は配布物に同梱
    #   されているのに settings.json へ登録する処理が無く、顧客端末では一度も
    #   動いていなかった (管理者端末には登録済みのため、ここでは再現しない型)。
    ("SessionStart", "*",
     "lib/hooks/session-start-skill-heal.sh",
     'bash ~/.soloptilink/lib/hooks/session-start-skill-heal.sh 2>/dev/null || true', 30),
    ("PostToolUse", "Bash",
     "lib/hooks/post-bash-skill-heal.sh",
     'bash ~/.soloptilink/lib/hooks/post-bash-skill-heal.sh 2>/dev/null || true', 30),
]

# --- settings.json の読み取り ------------------------------------------------
#   ★「無い」と「壊れている」を必ず分ける。
#     壊れているものを {} と読み替えて上書きすると、お客様の設定が消える。
before = os.stat(settings) if os.path.exists(settings) else None
if before is not None:
    try:
        with open(settings, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        print("ABORT_UNPARSABLE")
        sys.exit(0)
    if not isinstance(data, dict):
        print("ABORT_NOT_DICT")
        sys.exit(0)
else:
    data = {}

hooks = data.setdefault("hooks", {})
if not isinstance(hooks, dict):
    print("ABORT_HOOKS_NOT_DICT")
    sys.exit(0)


def existing_matchers(event, basename):
    """その区切りに既に入っている、その実体を指す登録の matcher 一覧"""
    out = []
    arr = hooks.get(event)
    if not isinstance(arr, list):
        return out
    for entry in arr:
        if not isinstance(entry, dict):
            continue
        for h in (entry.get("hooks") or []):
            if not isinstance(h, dict):
                continue
            if basename in (h.get("command") or ""):
                out.append(entry.get("matcher", ""))
                break
    return out


# 必要数 (同じ実体を同じ区切りへ複数入れる場合がある: 購入系の permission-ask)
need = {}
for event, matcher, rel, cmd, to in WIRINGS:
    need[(event, os.path.basename(rel))] = need.get((event, os.path.basename(rel)), 0) + 1

added = 0
skipped_missing = []
for event, matcher, rel, cmd, to in WIRINGS:
    path = os.path.join(sl_dir, rel)
    if not os.path.isfile(path):
        # 実体が無いものは登録しない (毎回失敗する死配線を作らない)
        skipped_missing.append(rel)
        continue
    base = os.path.basename(rel)
    have = existing_matchers(event, base)
    if matcher in have:
        continue                      # 同じ対象で登録済み
    if len(have) >= need[(event, base)]:
        continue                      # 表記違いで既に必要数だけ入っている (二重登録しない)
    arr = hooks.get(event)
    if arr is None:
        arr = []
        hooks[event] = arr
    if not isinstance(arr, list):
        # お客様の設定でこの区切りの値が配列でない（書き損じ）ときは、書かずに止める。
        # 当社の登録だけの配列で置き換えるとお客様の値が消え、全文の控えも無いため戻せない。
        # 2026-10-28 独立審査で指摘。v2056.10_chrome_clone_guard_wire.sh と同じ扱い。
        print("ABORT_EVENT_NOT_LIST"); sys.exit(0)
    arr.append({"matcher": matcher,
                "hooks": [{"type": "command", "command": cmd, "timeout": to}]})
    added += 1

if added == 0:
    print("WIRED added=0 missing=%d" % len(skipped_missing))
    sys.exit(0)

# --- 一時ファイルを読み直して確かめてから置き換える -------------------------
if not sl_safe_settings_write(settings, data, before):
    print("ABORT_WRITE_INVALID")
    sys.exit(0)
print("WIRED added=%d missing=%d" % (added, len(skipped_missing)))
PYEOF
}

# 登録済みの本数を数える (実体名で数える)
_w5_count_py() {
    cat > "$1" <<'PYEOF'
import json, os, sys
settings = os.environ["W5_SETTINGS"]
names = ["pre-write-evacuation-guard.sh", "permission-ask-hook.sh",
         "post-tool-use-hook.sh", "evidence-secret-scrub-hook.sh",
         "handoff-notice-posttool.sh", "response-gate.sh", "context-flush.sh",
         "session-start-skill-heal.sh", "post-bash-skill-heal.sh"]
try:
    with open(settings, encoding="utf-8") as f:
        d = json.load(f)
except Exception:
    print(-1); sys.exit(0)
n = 0
for _ev, arr in (d.get("hooks") or {}).items():
    if not isinstance(arr, list):
        continue
    for m in arr:
        if not isinstance(m, dict):
            continue
        for h in (m.get("hooks") or []):
            c = (h or {}).get("command") or ""
            for nm in names:
                if nm in c:
                    n += 1
                    break
print(n)
PYEOF
}

mig_apply() {
    mkdir -p "$SL_DIR" "$CLAUDE_DIR" 2>/dev/null || true
    mig_log "START"

    case "$(printf '%s' "${SOLOPTILINK_W5_HOOK_DELIVERY:-on}" | tr 'A-Z' 'a-z')" in
        off|0|false|no|disabled)
            mig_log "KILL_SWITCH SOLOPTILINK_W5_HOOK_DELIVERY=off -> NOOP (retryable)"
            return 0
            ;;
    esac

    if [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; then
        mig_log "ALREADY_APPLIED -> NOOP"
        return 0
    fi

    if ! command -v python3 >/dev/null 2>&1; then
        mig_log "PRECONDITION_FAILED python3 not found (retryable)"
        return 0
    fi

    W5_TMPD="$(mktemp -d "${TMPDIR:-/tmp}/w5hook.XXXXXX" 2>/dev/null)" || {
        mig_log "PRECONDITION_FAILED mktemp (retryable)"; return 0; }


    _w5_write_py "$W5_TMPD/wire.py"
    WIRE_RESULT="$(W5_SETTINGS="$SETTINGS_FILE" W5_SL_DIR="$SL_DIR" python3 "$W5_TMPD/wire.py" 2>>"$LOG_FILE")"

    # 書いた直後に、シェル側からも JSON として読み直して確かめる (二重の確認)
    if [ -f "$SETTINGS_FILE" ]; then
        if ! W5_SETTINGS="$SETTINGS_FILE" python3 -c 'import json,os; json.load(open(os.environ["W5_SETTINGS"],encoding="utf-8"))' >/dev/null 2>&1; then
            mig_log "POSTCHECK_FAILED settings.json が JSON として読めない（当社は置き換える前に確かめている。別の処理が書いた可能性）-> state を書かず次回やり直します"
            rm -rf "$W5_TMPD" 2>/dev/null || true
            return 0
        fi
    fi

    case "$WIRE_RESULT" in
        WIRED*) mig_log "WIRE_SUCCESS ($WIRE_RESULT)" ;;
        *)      mig_log "WIRE_FAILED ($WIRE_RESULT) -> state を書かず再試行可能にします"
                rm -rf "$W5_TMPD" 2>/dev/null || true
                return 0 ;;
    esac

    # ---- 長期記憶の呼び出し口 (B群) は別経路で届いている。抜けていたら修復を依頼する ----
    MEM_STATE="skipped"
    if [ -f "$SL_DIR/$MEM_INSTALLER" ]; then
        if CLAUDE_SETTINGS="$SETTINGS_FILE" SOLOPTILINK_HOME="$SL_DIR" SOLOPTILINK_DIR="$SL_DIR" \
           bash "$SL_DIR/$MEM_INSTALLER" check >/dev/null 2>&1; then
            MEM_STATE="already"
        else
            CLAUDE_SETTINGS="$SETTINGS_FILE" SOLOPTILINK_HOME="$SL_DIR" SOLOPTILINK_DIR="$SL_DIR" \
                bash "$SL_DIR/$MEM_INSTALLER" install >/dev/null 2>&1 || true
            if CLAUDE_SETTINGS="$SETTINGS_FILE" SOLOPTILINK_HOME="$SL_DIR" SOLOPTILINK_DIR="$SL_DIR" \
               bash "$SL_DIR/$MEM_INSTALLER" check >/dev/null 2>&1; then
                MEM_STATE="repaired"
            else
                MEM_STATE="failed"
            fi
        fi
    fi
    mig_log "MEMORY_HOOKS ${MEM_STATE}"

    # ---- 実際に登録されたかを数える (宣言でなく現物を見る) ----
    _w5_count_py "$W5_TMPD/count.py"
    W5_N="$(W5_SETTINGS="$SETTINGS_FILE" python3 "$W5_TMPD/count.py" 2>/dev/null)"
    case "$W5_N" in ''|*[!0-9]*) W5_N=-1 ;; esac
    rm -rf "$W5_TMPD" 2>/dev/null || true

    # 【2026-09-16 是正】期待エントリ数が 8 → 10 へ増えたのに、この完了判定だけが
    #   8 のまま据え置かれていた。そのままだと新設の2本が1本も入らなくても
    #   「適用完了」と記録し、以後この migration は二度と走らない (state で塞がれる)。
    #   10 のうち任意の2本が落ちても見逃す欠陥だったので、期待値へ追随させる。
    if [ "$W5_N" -lt 10 ]; then
        mig_log "VERIFY_INCOMPLETE registered=${W5_N}/10 -> state を書かず再試行可能にします"
        return 0
    fi

    APPLIED_AT="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    W5_STATE_FILE="$STATE_FILE" W5_MIG_NAME="$MIG_NAME" W5_APPLIED_AT="$APPLIED_AT" python3 - <<'PYEOF' 2>>"$LOG_FILE"
import json, os
sf = os.environ['W5_STATE_FILE']
try:
    with open(sf, encoding="utf-8") as f:
        data = json.load(f)
except Exception:
    data = {}
if not isinstance(data, dict):
    data = {}
data[os.environ['W5_MIG_NAME']] = {"applied_at": os.environ['W5_APPLIED_AT']}
tmp = sf + ".tmp.%d" % os.getpid()
with open(tmp, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
os.replace(tmp, sf)
PYEOF

    mig_log "DONE applied_at=${APPLIED_AT} ($WIRE_RESULT) registered=${W5_N}/10 memory=${MEM_STATE}"
    return 0
}

# ------------------------------------------------------------
# selftest — 隔離した仮想 HOME で実走する (宣言を読むだけにしない)
#   H1 設定ゼロの端末 (settings.json が存在しない) → 8 エントリを登録・JSON 妥当
#   H2 冪等 (state を消して再実行しても 10 のまま)
#   H3 表記違い (~ 表記で先に入っている) を二重登録しない
#   H4 実体が無いものは登録しない (死配線を作らない)
#   H5 kill-switch off で 1 本も登録しない
#   H6 settings.json が壊れているとき、一切書き換えない (お客様の設定を壊さない)
#   H7 長期記憶の呼び出し口が抜けている端末で、修復されて 8/8 になる
# ------------------------------------------------------------
mig_selftest() {
    local self rc=0
    self="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
    # ★root は意図的にグローバル (EXIT トラップは return 後に発火するため local にすると unbound)
    root="$(mktemp -d "${TMPDIR:-/tmp}/w5sel.XXXXXX")" || return 1
    trap 'rm -rf "$root" 2>/dev/null || true' EXIT INT TERM

    _mk_env() { # $1=name : 実体 9 本を置いた仮想 ~/.soloptilink と、空の ~/.claude
        mkdir -p "$root/$1/sl/lib/hooks" "$root/$1/sl/lib/legal-risk-lint" \
                 "$root/$1/sl/lib/autonomy" "$root/$1/claude"
        for f in lib/hooks/pre-write-evacuation-guard.sh lib/hooks/permission-ask-hook.sh \
                 lib/legal-risk-lint/post-tool-use-hook.sh lib/hooks/evidence-secret-scrub-hook.sh \
                 lib/hooks/handoff-notice-posttool.sh lib/hooks/response-gate.sh \
                 lib/autonomy/context-flush.sh \
                 lib/hooks/session-start-skill-heal.sh lib/hooks/post-bash-skill-heal.sh ; do
            printf '#!/usr/bin/env bash\nexit 0\n' > "$root/$1/sl/$f"
        done
    }
    _count() { # $1=settings.json : 本 migration が入れた登録の本数
        W5_SETTINGS="$1" python3 - <<'PY'
import json, os
names = ["pre-write-evacuation-guard.sh", "permission-ask-hook.sh",
         "post-tool-use-hook.sh", "evidence-secret-scrub-hook.sh",
         "handoff-notice-posttool.sh", "response-gate.sh", "context-flush.sh",
         "session-start-skill-heal.sh", "post-bash-skill-heal.sh"]
try:
    d = json.load(open(os.environ["W5_SETTINGS"], encoding="utf-8"))
except Exception:
    print(-1); raise SystemExit(0)
n = 0
for _ev, arr in (d.get("hooks") or {}).items():
    if not isinstance(arr, list): continue
    for m in arr:
        if not isinstance(m, dict): continue
        for h in (m.get("hooks") or []):
            c = (h or {}).get("command") or ""
            if any(nm in c for nm in names): n += 1
print(n)
PY
    }
    _valid() { # $1=settings.json : JSON として読めるか
        W5_SETTINGS="$1" python3 -c 'import json,os; json.load(open(os.environ["W5_SETTINGS"],encoding="utf-8")); print("ok")' 2>/dev/null
    }
    _run() { # $1=name, 以降は追加 env
        local name="$1"; shift
        # ★CLAUDE_SETTINGS を必ず落とす。落とさないと「砂箱のつもりで現物 (お客様の設定) を
        #   触る」取り違えが起きる (同じ取り違えを過去に 3 度踏んでいる)。
        env -u CLAUDE_SETTINGS "$@" HOME="$root/$name" SOLOPTILINK_DIR="$root/$name/sl" SOLOPTILINK_HOME="$root/$name/sl" \
            CLAUDE_CONFIG_DIR="$root/$name/claude" bash "$self" >/dev/null 2>&1
    }

    # H1 設定ゼロの端末 (settings.json も存在しない)
    _mk_env h1
    _run h1
    local n1 v1; n1="$(_count "$root/h1/claude/settings.json")"; v1="$(_valid "$root/h1/claude/settings.json")"
    if [ "$n1" = "10" ]; then echo "  [OK] 設定ゼロの端末: 10 エントリを登録"; else echo "  [FAIL] 設定ゼロの端末: 登録数=$n1 (期待10)"; rc=1; fi
    if [ "$v1" = "ok" ]; then echo "  [OK] 書いた直後の settings.json が JSON として妥当"; else echo "  [FAIL] settings.json が JSON として読めない"; rc=1; fi

    # H2 冪等
    rm -f "$root/h1/sl/.migration-state.json"
    _run h1
    local n2; n2="$(_count "$root/h1/claude/settings.json")"
    if [ "$n2" = "10" ]; then echo "  [OK] 冪等: 再実行しても 10 のまま"; else echo "  [FAIL] 冪等性違反: 登録数=$n2"; rc=1; fi

    # H3 表記違いが先に入っていても二重登録しない
    _mk_env h3
    W5_S="$root/h3/claude/settings.json" python3 - <<'PY'
import json, os
d = {"hooks": {"Stop": [{"matcher": "*", "hooks": [
      {"type": "command", "command": 'bash ~/.soloptilink/lib/hooks/response-gate.sh'}]}]}}
json.dump(d, open(os.environ["W5_S"], "w", encoding="utf-8"), indent=2, ensure_ascii=False)
PY
    _run h3
    local n3; n3="$(_count "$root/h3/claude/settings.json")"
    if [ "$n3" = "10" ]; then echo "  [OK] 表記違い: 既存登録を重複させない (合計10)"; else echo "  [FAIL] 表記違いで二重登録: 登録数=$n3 (期待10)"; rc=1; fi

    # H3b 対象 (matcher) 違いで先に入っているときも二重登録しない
    #   ★Claude Code は Stop の対象を空文字で書くことがある。「対象が違う=未登録」と
    #     読むと、同じフックが 2 本並んで毎回二重に走る。
    _mk_env h3b
    W5_S="$root/h3b/claude/settings.json" python3 - <<'PY'
import json, os
d = {"hooks": {"Stop": [{"matcher": "", "hooks": [
      {"type": "command", "command": 'bash "$HOME/.soloptilink/lib/hooks/response-gate.sh"'}]}]}}
json.dump(d, open(os.environ["W5_S"], "w", encoding="utf-8"), indent=2, ensure_ascii=False)
PY
    _run h3b
    local n3b; n3b="$(_count "$root/h3b/claude/settings.json")"
    if [ "$n3b" = "10" ]; then echo "  [OK] 対象違い: 同じフックを 2 本並べない (合計10)"; else echo "  [FAIL] 対象違いで二重登録: 登録数=$n3b (期待10)"; rc=1; fi

    # H4 実体が無いものは登録しない
    _mk_env h4; rm -f "$root/h4/sl/lib/autonomy/context-flush.sh"
    _run h4
    local n4 c4; n4="$(_count "$root/h4/claude/settings.json")"
    c4="$(grep -c 'context-flush.sh' "$root/h4/claude/settings.json" 2>/dev/null)"; c4="${c4:-0}"
    if [ "$n4" = "9" ] && [ "$c4" = "0" ]; then echo "  [OK] 実体不在: そのエントリだけ登録しない (9/10・死配線なし)"; else echo "  [FAIL] 実体不在の扱いが誤り: 登録数=$n4 context-flush=$c4"; rc=1; fi

    # H5 kill-switch
    _mk_env h5
    _run h5 SOLOPTILINK_W5_HOOK_DELIVERY=off
    local n5; n5="$(_count "$root/h5/claude/settings.json")"
    if [ "$n5" = "-1" ] || [ "$n5" = "0" ]; then echo "  [OK] kill-switch: off で 1 本も登録しない"; else echo "  [FAIL] kill-switch off でも登録した: 登録数=$n5"; rc=1; fi

    # H6 壊れた settings.json を書き換えない
    _mk_env h6
    printf '{ this is not json' > "$root/h6/claude/settings.json"
    local before6; before6="$(cat "$root/h6/claude/settings.json")"
    _run h6
    local after6; after6="$(cat "$root/h6/claude/settings.json")"
    if [ "$before6" = "$after6" ]; then echo "  [OK] 壊れた設定: 一切書き換えない (お客様の設定を壊さない)"; else echo "  [FAIL] 壊れた設定を書き換えた"; rc=1; fi

    # H6b 区切りの値が配列でない設定 (お客様の書き損じ) は、当社の登録で置き換えず 1 バイトも書き換えない (2026-10-28 独立審査)
    _mk_env nl
    printf '%s\n' '{"env": {"KEEP": "1"}, "hooks": {"SessionStart": {"customer": "keep"}, "Stop": "customer", "PreToolUse": {"x": 1}, "PostToolUse": 7, "PreCompact": {"x": 1}}}' > "$root/nl/claude/settings.json"
    local nl_before nl_after nl_state=no
    nl_before="$(python3 -c 'import hashlib,sys; print(hashlib.sha256(open(sys.argv[1], "rb").read()).hexdigest())' "$root/nl/claude/settings.json")"
    _run nl
    nl_after="$(python3 -c 'import hashlib,sys; print(hashlib.sha256(open(sys.argv[1], "rb").read()).hexdigest())' "$root/nl/claude/settings.json")"
    if [ -f "$root/nl/sl/.migration-state.json" ] && grep -q "\"${MIG_NAME}\"" "$root/nl/sl/.migration-state.json" 2>/dev/null; then nl_state=yes; fi
    if [ "$nl_before" = "$nl_after" ] && [ "$nl_state" = no ]; then
        echo "  [OK] 配列でない区切り (SessionStart/Stop/PreToolUse/PostToolUse/PreCompact): 書き換えず適用済み記録なし"
    else
        echo "  [FAIL] 配列でない区切り (SessionStart/Stop/PreToolUse/PostToolUse/PreCompact): お客様の値を置き換えた/適用済みと記録した (state=$nl_state)"; rc=1
    fi

    # H7 長期記憶の呼び出し口が抜けている端末で修復される
    local n7="skip" m7="skip"
    if [ -f "$SL_DIR/$MEM_INSTALLER" ]; then
        _mk_env h7
        mkdir -p "$root/h7/sl/lib/memory"
        cp "$SL_DIR/$MEM_INSTALLER" "$root/h7/sl/$MEM_INSTALLER" 2>/dev/null || true
        for f in memory-inject-session.sh memory-inject-pretool.sh memory-capture-hook.sh \
                 work-memory-bridge.sh memory-index-sessionend.sh memory-hygiene.sh \
                 requirement-memory-bridge.sh ; do
            printf '#!/usr/bin/env bash\nexit 0\n' > "$root/h7/sl/lib/memory/$f"
        done
        _run h7
        n7="$(_count "$root/h7/claude/settings.json")"
        m7="$(CLAUDE_SETTINGS="$root/h7/claude/settings.json" SOLOPTILINK_HOME="$root/h7/sl" \
              SOLOPTILINK_DIR="$root/h7/sl" bash "$root/h7/sl/$MEM_INSTALLER" check >/dev/null 2>&1 && echo ok || echo ng)"
        if [ "$n7" = "10" ] && [ "$m7" = "ok" ]; then
            echo "  [OK] 長期記憶: 抜けていた呼び出し口を修復し 8/8 になった"
        else
            echo "  [FAIL] 長期記憶の修復に至らず (本 migration 登録=$n7 / 記憶側=$m7)"; rc=1
        fi
    else
        echo "  [FAIL] 長期記憶の登録器が見つからず、修復を測れなかった (未測定=合格にしない)"; rc=1
    fi

    # 番兵を含む設定を実際に変更し、全文の控え・権限・環境変数の保持を確かめる。
    _mk_env secret
    local sentinel="sl-sentinel-$$-do-not-copy"
    printf '{"env":{"SL_SENTINEL_SECRET":"%s"}}\n' "$sentinel" > "$root/secret/claude/settings.json"
    chmod 600 "$root/secret/claude/settings.json"
    _run secret
    local secret_count
    secret_count="$(_count "$root/secret/claude/settings.json")"
    if python3 - "$root/secret" "$root/secret-control" "$sentinel" "$secret_count" <<'PYSECRET'
import json, os, stat, sys
from pathlib import Path
sandbox, control = Path(sys.argv[1]), Path(sys.argv[2])
marker = sys.argv[3]

def sentinel_files(folder, secret):
    found = []
    for current, _dirs, names in os.walk(folder):
        for name in names:
            candidate = Path(current) / name
            if stat.S_ISREG(candidate.lstat().st_mode) and secret.encode("utf-8") in candidate.read_bytes():
                found.append(candidate)
    return found

# 同じ検出器で偽の控えを含む別の砂箱を調べ、2 ファイルを検出する。
(control / "claude").mkdir(parents=True)
(control / "sl").mkdir()
(control / "claude" / "settings.json").write_text(json.dumps({"env": {"SL_SENTINEL_SECRET": marker}}), encoding="utf-8")
(control / "sl" / "fake-copy.json").write_text(marker, encoding="utf-8")
control_files = sentinel_files(control, marker)
assert len(control_files) == 2 and len(control_files) != 1, "偽の控えを見逃した"
settings = sandbox / "claude" / "settings.json"
assert sys.argv[4] == "10", "設定への登録が実際に起きていない"
assert sentinel_files(sandbox, marker) == [settings], "番兵を含む通常ファイルが設定以外にもある"
assert not os.path.lexists(sandbox / "claude" / (".back" + "ups")), "控えのフォルダが作られた"
assert stat.S_IMODE(os.stat(settings).st_mode) == 0o600, "設定の権限が変わった"
assert json.loads(settings.read_text(encoding="utf-8"))["env"]["SL_SENTINEL_SECRET"] == marker, "環境変数が失われた"
PYSECRET
    then
        echo "  PASS  番兵: 登録を実行・設定だけに保持・控えなし・権限600・偽の控えを検出"
    else
        echo "  FAIL  番兵: 設定の保持または控えの検出に失敗"
        rc=1
    fi

    local proven=false; [ "$rc" -eq 0 ] && proven=true
    # 【2026-09-16】登録は 8 → 10 エントリへ増えた (自己修復2本を追加)。
    #   キー名 zero_config_registers_8 は外部の出荷前検査が名前で参照しているため
    #   変えず、判定値のみ実態 (10) に合わせる。名前の 8 は歴史的なもの。
    printf '{"tool":"%s","zero_config_registers_8":%s,"json_valid":%s,"idempotent":%s,"no_dup_on_pathform":%s,"no_dup_on_matcher_diff":%s,"absent_hook_not_registered":%s,"killswitch_noop":%s,"broken_settings_untouched":%s,"memory_hooks_repaired":%s,"discrimination_proven":%s}\n' \
        "$MIG_NAME" \
        "$([ "$n1" = 10 ] && echo true || echo false)" \
        "$([ "$v1" = ok ] && echo true || echo false)" \
        "$([ "$n2" = 10 ] && echo true || echo false)" \
        "$([ "$n3" = 10 ] && echo true || echo false)" \
        "$([ "$n3b" = 10 ] && echo true || echo false)" \
        "$([ "$n4" = 9 ] && echo true || echo false)" \
        "$({ [ "$n5" = 0 ] || [ "$n5" = -1 ]; } && echo true || echo false)" \
        "$([ "$before6" = "$after6" ] && echo true || echo false)" \
        "$({ [ "$n7" = 10 ] && [ "$m7" = ok ]; } && echo true || echo false)" \
        "$proven"
    return $rc
}

case "${1:-apply}" in
    selftest) mig_selftest; exit $? ;;
    apply|"") mig_apply; exit 0 ;;
    *)        mig_apply; exit 0 ;;
esac
