#!/usr/bin/env bash
# 試用端末では、登録した命令全体を終了時に試用の関所で覆う（有料端末は変更しない）。
trap '[ ! -f "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" ] || bash "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" >/dev/null 2>&1 || true' EXIT
# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# ============================================================
# v2055.0 エラーゼロ化4本柱 ライフサイクル結線の顧客端末登録 (2026-08-01)
# ------------------------------------------------------------
# 【何が壊れていたか (実測)】
#   エラーゼロ化4本柱 (見張り番 / 資源ガバナー / 完成宣言 / デモ前チェック) を
#   Claude Code のライフサイクルへ載せる唯一の結線層
#   lib/hooks/reliability-lifecycle-hook.sh は、開発機の ~/.claude/settings.json には
#   7エントリ登録されて実発火していたが、【顧客端末へ登録する経路がどこにも無かった】。
#   installer/SoloptiLinkAI-Setup.command は自動更新フック (v2027) しか登録せず、
#   migration にも自動更新経路にも本フックの登録は存在しなかった。
#   つまり柱2 (資源ガバナー) と柱4 (完成宣言) は【開発機でしか動いていなかった】。
#
# 【本 migration がすること】
#   ~/.claude/settings.json へ次の7エントリを冪等に登録する
#   (実体ファイルが存在するときだけ。存在しなければ何もせず、後で再試行できる)。
#     UserPromptSubmit  *          prompt      lease延命 + デモ前チェック自動実行
#     PreToolUse        Task|Agent govern      並列起動前の資源チェック
#     PostToolUse       Bash       adopt       devサーバー起動検知 → 見張り番起動
#     Stop              *          declare     完成宣言の自動生成
#     SessionStart      *          sweep       前回セッションの見張り番の後始末
#     SessionEnd        *          release     このセッションの見張り番を停止
#     SubagentStop      *          agent_done  並列エージェント終了の反映
#
# 【既存顧客への遡及】
#   auto-update.sh が起動のたびに migration/v*.sh を state 参照つきで実行するため、
#   本ファイルが配布物に含まれれば導入済み端末にも自動で行き渡る (1回だけ適用)。
#   新規導入は installer/SoloptiLinkAI-Setup.command の STEP 5.5 が全 migration を
#   実行することで登録される。
#
# 【安全側の原則】
#   - 冪等: コマンド文字列が既に配線済みなら何もしない (二重登録しない)
#   - 設定の全文の控えは作らない。読めた設定だけを一時ファイルで確かめて置き換える (2026-10-28)
#   - 実体ファイル不在なら登録しない (存在しないフックを登録して毎回エラーを出させない)
#   - python3 が無ければ何もせず正常終了 (state を書かない = 再試行可能)
#   - 失敗しても導入・更新そのものは絶対に止めない (exit 0)
#
# 【kill-switch】
#   SOLOPTILINK_RELIABILITY_HOOK_INSTALL=off … 本 migration を no-op にする
#     (state を書かないので、外せば次回起動で適用される)
#   登録後にフックの働きを止めたい場合は結線層側の kill-switch を使う:
#     ENABLE_RELIABILITY_WIRING=off (結線層まるごと従来動作へ)
#
# CLI:
#   bash ~/.soloptilink/migration/v2055_reliability_hooks.sh            (適用)
#   bash ~/.soloptilink/migration/v2055_reliability_hooks.sh selftest   (両側判定)
# ============================================================
set -u

MIG_NAME="v2055_reliability_hooks"
SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
CLAUDE_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
SETTINGS_FILE="$CLAUDE_DIR/settings.json"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"
HOOK_REL="lib/hooks/reliability-lifecycle-hook.sh"

mig_log() {
    echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}

mig_apply() {
    mkdir -p "$SL_DIR" "$CLAUDE_DIR" 2>/dev/null || true
    mig_log "START"

    # kill-switch (state を書かない = 解除すれば次回適用される)
    case "$(printf '%s' "${SOLOPTILINK_RELIABILITY_HOOK_INSTALL:-on}" | tr 'A-Z' 'a-z')" in
        off|0|false|no|disabled)
            mig_log "KILL_SWITCH SOLOPTILINK_RELIABILITY_HOOK_INSTALL=off -> NOOP (retryable)"
            return 0
            ;;
    esac

    # 冪等: 適用済みなら NOOP
    if [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; then
        mig_log "ALREADY_APPLIED -> NOOP"
        return 0
    fi

    # 前提: 結線層の実体があること (無いものを登録して毎回エラーを出させない)
    if [ ! -f "$SL_DIR/$HOOK_REL" ]; then
        mig_log "PRECONDITION_FAILED $HOOK_REL not found (retryable)"
        return 0
    fi

    # 前提: python3 (無ければ再試行可能なまま終了)
    if ! command -v python3 >/dev/null 2>&1; then
        mig_log "PRECONDITION_FAILED python3 not found (retryable)"
        return 0
    fi

    WIRE_RESULT="$(SETTINGS_FILE="$SETTINGS_FILE" HOOK_PATH="$SL_DIR/$HOOK_REL" python3 - <<'PYEOF' 2>>"$LOG_FILE"
import json, os, sys

# >>> sl-safe-settings-write v2 (2026-10-29) >>>
# お客様の設定の全文の控えは作らない。控えには環境変数や許可の設定がそのまま写り、
# 消す処理がどこにも無いまま残り続けていた。読めた設定だけを一時ファイルに書き、
# JSON として読み直してから原子的に置き換える。読んでから置き換えるまでに
# 別の処理が設定を書いていたら、上書きせずに次の起動でやり直す。
# 設定がリンクのときはリンクを残し、リンク先の実体を同じ手順で置き換える。
# 撤去の段 3 と同じ扱いにそろえた (2026-10-29 独立審査で指摘)。
# v1 はリンクそのものを普通のファイルに置き換え、お客様の管理の先から切り離していた。
# 壊れたリンクと、読んでから置き換えるまでに行き先が変わったリンクには書かずに止める。
def sl_safe_settings_write(path, data, before):
    import json as _json, os as _os, stat as _stat
    target = _os.path.realpath(path)
    folder = _os.path.dirname(target) or "."
    tmp = _os.path.join(folder, "." + _os.path.basename(target) + ".sl-new.%d" % _os.getpid())
    flags = _os.O_WRONLY | _os.O_CREAT | _os.O_EXCL | getattr(_os, "O_NOFOLLOW", 0)
    try:
        fd = _os.open(tmp, flags, 0o600 if before is not None else 0o666)
    except OSError:
        return False
    try:
        with _os.fdopen(fd, "w", encoding="utf-8") as handle:
            if before is not None:
                try:
                    _os.fchmod(handle.fileno(), _stat.S_IMODE(before.st_mode))
                except (AttributeError, OSError):
                    pass
            _json.dump(data, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            _os.fsync(handle.fileno())
        with open(tmp, encoding="utf-8") as handle:
            if not isinstance(_json.load(handle), dict):
                return False
        if _os.path.realpath(path) != target:
            return False
        if before is not None:
            now = _os.stat(path)
            if (now.st_ino, now.st_size, now.st_mtime_ns) != (before.st_ino, before.st_size, before.st_mtime_ns):
                return False
        elif _os.path.lexists(path):
            return False
        _os.replace(tmp, target)
        return True
    except Exception:
        return False
    finally:
        if _os.path.lexists(tmp) and not _os.path.islink(tmp):
            try:
                _os.unlink(tmp)
            except OSError:
                pass
# <<< sl-safe-settings-write v2 <<<


sp = os.environ["SETTINGS_FILE"]
hook_path = os.environ["HOOK_PATH"]

# フック本体の場所は $HOME 直下の既定配置のときだけ "$HOME/..." 表記を使う。
# ★開発機に既に入っている表記と完全一致させることが冪等性の要 (表記が違うと二重登録になる)。
home = os.path.expanduser("~")
default = os.path.join(home, ".soloptilink", "lib", "hooks", "reliability-lifecycle-hook.sh")
if os.path.abspath(hook_path) == os.path.abspath(default):
    ref = '"$HOME/.soloptilink/lib/hooks/reliability-lifecycle-hook.sh"'
else:
    ref = '"%s"' % hook_path

WIRINGS = [
    ("UserPromptSubmit", "*",          "prompt",     30),
    ("PreToolUse",       "Task|Agent", "govern",     20),
    ("PostToolUse",      "Bash",       "adopt",      30),
    ("Stop",             "*",          "declare",    60),
    ("SessionStart",     "*",          "sweep",      30),
    ("SessionEnd",       "*",          "release",    30),
    ("SubagentStop",     "*",          "agent_done", 15),
]

try:
    before = os.stat(sp) if os.path.exists(sp) else None
    if before is not None and before.st_size > 0:
        with open(sp) as f:
            data = json.load(f)
    else:
        data = {}
except Exception:
    print("ABORT_UNPARSABLE")
    sys.exit(0)
if not isinstance(data, dict):
    print("ABORT_NOT_DICT")
    sys.exit(0)

hooks = data.setdefault("hooks", {})
if not isinstance(hooks, dict):
    print("ABORT_HOOKS_NOT_DICT")
    sys.exit(0)

added = 0
for event, matcher, mode, timeout in WIRINGS:
    cmd = "bash %s %s" % (ref, mode)
    arr = hooks.get(event)
    if arr is None:
        arr = []
        hooks[event] = arr
    if not isinstance(arr, list):
        # お客様の設定でこの区切りの値が配列でない（書き損じ）ときは、書かずに止める。
        # 当社の登録だけの配列で置き換えるとお客様の値が消え、全文の控えも無いため戻せない。
        # 2026-10-28 独立審査で指摘。v2056.10_chrome_clone_guard_wire.sh と同じ扱い。
        print("ABORT_EVENT_NOT_LIST"); sys.exit(0)
    # 冪等判定: 「同じフック本体を同じモードで呼ぶ登録」が既にあるか
    # (完全一致だけで見ると、絶対パス表記/$HOME 表記の違いで二重登録になる)
    found = False
    for entry in arr:
        if not isinstance(entry, dict):
            continue
        for h in (entry.get("hooks") or []):
            if not isinstance(h, dict):
                continue
            c = h.get("command") or ""
            if "reliability-lifecycle-hook.sh" in c and c.rstrip().endswith(" " + mode):
                found = True
                break
        if found:
            break
    if found:
        continue
    arr.append({
        "matcher": matcher,
        "hooks": [{"type": "command", "command": cmd, "timeout": timeout}],
    })
    added += 1

# 追加が無いなら settings.json には一切書かない
# (顧客が手で整えた書式・並びを、意味の変わらない書き換えで動かさない)
if added == 0:
    print("WIRED added=0 (already-wired / no write)")
    sys.exit(0)

if not sl_safe_settings_write(sp, data, before):
    print("ABORT_WRITE_INVALID")
    sys.exit(0)
print("WIRED added=%d" % added)
PYEOF
)"

    case "$WIRE_RESULT" in
        WIRED*)
            mig_log "WIRE_SUCCESS ($WIRE_RESULT)"
            ;;
        *)
            mig_log "WIRE_FAILED ($WIRE_RESULT) -> state を書かず再試行可能にします"
            return 0
            ;;
    esac

    # state 追記 (atomic)
    APPLIED_AT="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    STATE_FILE="$STATE_FILE" MIG_NAME="$MIG_NAME" APPLIED_AT="$APPLIED_AT" python3 - <<'PYEOF' 2>>"$LOG_FILE"
import json, os
sf = os.environ['STATE_FILE']
try:
    with open(sf) as f:
        data = json.load(f)
except Exception:
    data = {}
if not isinstance(data, dict):
    data = {}
data[os.environ['MIG_NAME']] = {"applied_at": os.environ['APPLIED_AT']}
tmp = sf + ".tmp.%d" % os.getpid()
with open(tmp, "w") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
os.replace(tmp, sf)
PYEOF

    mig_log "DONE applied_at=${APPLIED_AT} ($WIRE_RESULT)"
    return 0
}

# ------------------------------------------------------------
# selftest: 両側判定 (隔離した仮想 HOME で実走)
#   H1 健全側: 未登録の settings.json へ 7エントリが登録される
#   H2 冪等  : 2回目で追加ゼロ (二重登録しない)
#   H3 冪等  : 絶対パス表記で先に入っていても二重登録しない
#   H4 欠陥側: 結線層の実体が無ければ登録しない (存在しないフックを登録しない)
#   H5 kill-switch: SOLOPTILINK_RELIABILITY_HOOK_INSTALL=off で何も登録しない
# ------------------------------------------------------------
mig_selftest() {
    local self rc=0
    self="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
    # ★root は意図的にグローバル: EXIT トラップは関数 return 後(スクリプト終了時)にも
    #   発火するため local にすると set -u で unbound になる (既知の罠)
    root="$(mktemp -d "${TMPDIR:-/tmp}/v2055hook.XXXXXX")" || return 1
    trap "python3 -c 'import shutil; shutil.rmtree(\"$root\", ignore_errors=True)'" EXIT INT TERM

    _mk_env() { # $1=name  → SL_DIR/CLAUDE_DIR を用意し、結線層の実体も置く
        mkdir -p "$root/$1/sl/lib/hooks" "$root/$1/claude"
        printf '#!/usr/bin/env bash\nexit 0\n' > "$root/$1/sl/lib/hooks/reliability-lifecycle-hook.sh"
        printf '{}\n' > "$root/$1/claude/settings.json"
    }
    _count() { # $1=settings.json → 結線層を指す登録の件数
        python3 - "$1" <<'PY'
import json, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception:
    print(0); raise SystemExit(0)
n = 0
for _ev, arr in (d.get("hooks") or {}).items():
    for m in (arr or []):
        for h in (m.get("hooks") or []):
            if "reliability-lifecycle-hook.sh" in (h.get("command") or ""):
                n += 1
print(n)
PY
    }
    _run() { # $1=name, 残りは追加 env
        local name="$1"; shift
        env "$@" HOME="$root/$name" SOLOPTILINK_DIR="$root/$name/sl" CLAUDE_CONFIG_DIR="$root/$name/claude" \
            bash "$self" >/dev/null 2>&1
    }

    # H1 健全側
    _mk_env h1; _run h1
    local n1; n1="$(_count "$root/h1/claude/settings.json")"
    if [ "$n1" = "7" ]; then echo "  [OK] 健全側: 7エントリを登録"; else echo "  [FAIL] 健全側: 登録数=$n1 (期待7)"; rc=1; fi

    # H2 冪等 (2回目)
    rm -f "$root/h1/sl/.migration-state.json"   # state を消しても二重登録しないこと
    _run h1
    local n2; n2="$(_count "$root/h1/claude/settings.json")"
    if [ "$n2" = "7" ]; then echo "  [OK] 冪等: 再実行しても 7 のまま (二重登録なし)"; else echo "  [FAIL] 冪等性違反: 登録数=$n2"; rc=1; fi

    # H3 表記違い (絶対パス) が先に入っていても二重登録しない
    _mk_env h3
    python3 - "$root/h3/claude/settings.json" "$root/h3/sl/lib/hooks/reliability-lifecycle-hook.sh" <<'PY'
import json, sys
p, hp = sys.argv[1], sys.argv[2]
d = {"hooks": {"Stop": [{"matcher": "*", "hooks": [
    {"type": "command", "command": 'bash "%s" declare' % hp, "timeout": 60}]}]}}
json.dump(d, open(p, "w"), indent=2, ensure_ascii=False)
PY
    _run h3
    local n3; n3="$(_count "$root/h3/claude/settings.json")"
    if [ "$n3" = "7" ]; then echo "  [OK] 表記違い: 既存の絶対パス登録を重複させない (合計7)"; else echo "  [FAIL] 表記違いで二重登録: 登録数=$n3 (期待7)"; rc=1; fi

    # H4 欠陥側: 結線層の実体が無ければ登録しない
    _mk_env h4; rm -f "$root/h4/sl/lib/hooks/reliability-lifecycle-hook.sh"
    _run h4
    local n4; n4="$(_count "$root/h4/claude/settings.json")"
    if [ "$n4" = "0" ]; then echo "  [OK] 欠陥側: 実体が無ければ登録しない (存在しないフックを登録しない)"; else echo "  [FAIL] 実体不在でも登録した: 登録数=$n4"; rc=1; fi

    # H5 kill-switch
    _mk_env h5
    _run h5 SOLOPTILINK_RELIABILITY_HOOK_INSTALL=off
    local n5; n5="$(_count "$root/h5/claude/settings.json")"
    if [ "$n5" = "0" ]; then echo "  [OK] kill-switch: off で何も登録しない (従来動作)"; else echo "  [FAIL] kill-switch off でも登録した: 登録数=$n5"; rc=1; fi

    # 番兵入り設定を実際に更新し、全文の控え・権限・検出対照を確かめる。
    local sentinel="sl-sentinel-$$-do-not-copy"
    _mk_env sentinel
    python3 - "$root/sentinel/claude/settings.json" "$sentinel" <<'PY_SENTINEL_SETUP'
import json, os, sys
with open(sys.argv[1], "w", encoding="utf-8") as handle:
    json.dump({"env": {"SL_SENTINEL_SECRET": sys.argv[2]}}, handle)
os.chmod(sys.argv[1], 0o600)
PY_SENTINEL_SETUP
    _run sentinel
    if python3 - "$root/sentinel/claude" "$root/sentinel/sl" "$root/sentinel-control" "$sentinel" <<'PY_SENTINEL_CHECK'
import json, os, stat, sys
claude, sl_dir, control, sentinel = sys.argv[1:]
settings = os.path.join(claude, "settings.json")

def containing(roots):
    found = []
    for folder in roots:
        for base, _dirs, files in os.walk(folder):
            for name in files:
                path = os.path.join(base, name)
                if os.path.isfile(path) and not os.path.islink(path):
                    with open(path, "rb") as handle:
                        if sentinel.encode("utf-8") in handle.read():
                            found.append(path)
    return sorted(found)

def only_settings(roots, path):
    return containing(roots) == [path]

os.makedirs(control, exist_ok=True)
control_settings = os.path.join(control, "settings.json")
for name in ("settings.json", "fake-copy"):
    with open(os.path.join(control, name), "w", encoding="utf-8") as handle:
        handle.write(sentinel)
control_ok = len(containing([control])) == 2 and not only_settings([control], control_settings)
with open(settings, encoding="utf-8") as handle:
    data = json.load(handle)
secret_ok = data.get("env", {}).get("SL_SENTINEL_SECRET") == sentinel
mode_ok = stat.S_IMODE(os.stat(settings).st_mode) == 0o600
copies_ok = only_settings([claude, sl_dir], settings)
folder_ok = not os.path.lexists(os.path.join(claude, "." + "backups"))
commands = [h.get("command", "") for arr in data.get("hooks", {}).values()
            for entry in arr for h in entry.get("hooks", [])]
wrote = sum("reliability-lifecycle-hook.sh" in command for command in commands) == 7
if not all((control_ok, secret_ok, mode_ok, copies_ok, folder_ok, wrote)):
    print("登録変更=%s 番兵保全=%s 権限=%s 全文控えなし=%s 控え用フォルダなし=%s 検出対照=%s" %
          (wrote, secret_ok, mode_ok, copies_ok, folder_ok, control_ok))
    sys.exit(1)
PY_SENTINEL_CHECK
    then
        echo "  [OK] 番兵検査: 実更新・全文控えなし・権限600・環境変数保全・偽の控え検出"
    else
        echo "  [FAIL] 番兵検査: 実更新・全文控えなし・権限・環境変数・検出対照のいずれかが不成立"; rc=1
    fi

    # 壊れた設定は、内容の照合値も適用済み記録も変えない。
    _mk_env broken
    printf '%s\n' '{ "hooks": ' > "$root/broken/claude/settings.json"
    local broken_before broken_after
    broken_before="$(python3 -c 'import hashlib,sys; print(hashlib.sha256(open(sys.argv[1], "rb").read()).hexdigest())' "$root/broken/claude/settings.json")"
    _run broken
    broken_after="$(python3 -c 'import hashlib,sys; print(hashlib.sha256(open(sys.argv[1], "rb").read()).hexdigest())' "$root/broken/claude/settings.json")"
    if [ "$broken_before" = "$broken_after" ] && [ ! -f "$root/broken/sl/.migration-state.json" ]; then
        echo "  [OK] 壊れた設定: SHA256 が同じで適用済み記録なし"
    else
        echo "  [FAIL] 壊れた設定: 内容または適用済み記録が変化"; rc=1
    fi

    # H7 区切りの値が配列でない設定 (お客様の書き損じ) は、当社の登録で置き換えず 1 バイトも書き換えない (2026-10-28 独立審査)
    _mk_env nl
    printf '%s\n' '{"hooks": {"UserPromptSubmit": {"c": 1}, "PreToolUse": "c", "PostToolUse": {"c": 1}, "Stop": {"c": 1}, "SessionStart": 3, "SessionEnd": {"c": 1}, "SubagentStop": {"c": 1}}}' > "$root/nl/claude/settings.json"
    local nl_before nl_after nl_state=no
    nl_before="$(python3 -c 'import hashlib,sys; print(hashlib.sha256(open(sys.argv[1], "rb").read()).hexdigest())' "$root/nl/claude/settings.json")"
    _run nl
    nl_after="$(python3 -c 'import hashlib,sys; print(hashlib.sha256(open(sys.argv[1], "rb").read()).hexdigest())' "$root/nl/claude/settings.json")"
    if [ -f "$root/nl/sl/.migration-state.json" ] && grep -q "\"${MIG_NAME}\"" "$root/nl/sl/.migration-state.json" 2>/dev/null; then nl_state=yes; fi
    if [ "$nl_before" = "$nl_after" ] && [ "$nl_state" = no ]; then
        echo "  [OK] 配列でない区切り (7 区切りすべて): 書き換えず適用済み記録なし"
    else
        echo "  [FAIL] 配列でない区切り (7 区切りすべて): お客様の値を置き換えた/適用済みと記録した (state=$nl_state)"; rc=1
    fi

    local proven=false; [ "$rc" -eq 0 ] && proven=true
    printf '{"tool":"%s","healthy_registers_7":%s,"idempotent":%s,"no_dup_on_pathform":%s,"absent_hook_not_registered":%s,"killswitch_noop":%s,"discrimination_proven":%s}\n' \
        "$MIG_NAME" \
        "$([ "$n1" = 7 ] && echo true || echo false)" \
        "$([ "$n2" = 7 ] && echo true || echo false)" \
        "$([ "$n3" = 7 ] && echo true || echo false)" \
        "$([ "$n4" = 0 ] && echo true || echo false)" \
        "$([ "$n5" = 0 ] && echo true || echo false)" \
        "$proven"
    return $rc
}

case "${1:-apply}" in
    selftest) mig_selftest; exit $? ;;
    apply|"") mig_apply; exit 0 ;;
    *)        mig_apply; exit 0 ;;
esac
