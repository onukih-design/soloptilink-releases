#!/usr/bin/env bash
# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04 の既定に倣う)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# ============================================================
# v2056.13 — 書類の PDF 化とお渡し用 ZIP の見張りを、道具の実行後の点検へ登録する (2026-10-26 新設)
# ------------------------------------------------------------
# 【なぜ要るか (実例)】
#   2026-10-24 に社外へお送りした ZIP 3 点の中身が「HTML・テキスト・MD」のままで、
#   受け取った企業から「MD ファイルは開けない」とご指摘を受けた (2026-10-26 オーナー指示)。
#   調べると、3 点とも日本語のファイル名に UTF-8 の印が無く (日本語の Windows で文字化けする)、
#   Mac の付属ファイル (__MACOSX/・.DS_Store) も混ざっていた。手順書を通らずに、
#   コマンドで直接 ZIP を作ると、この 3 つがそのまま出る。
#
# 【守りは二段】
#   一段目 (本 migration の外): 書類を作る各モードの手順書と共通の決まりに
#           「お渡しする書類は lib/deliver-pdf/deliver-pdf.sh pack で PDF だけの ZIP にする」を入れた。
#   二段目 (本 migration): コマンドで ZIP を作った直後に、その ZIP がお渡し用に見えるのに
#           MD・テキスト・HTML が入っている・名前が文字化けする形なら、作り直しの 1 行を知らせる
#           見張り (deliver-pdf.sh posttool) を PostToolUse の Bash へ登録する。止めはしない。
#   三段目 (本 migration・同日追加): オーナー指示「書類は作るときから、人が見て理解できる PDF で出す」。
#           AI が書類 (MD) を書いた・直した直後に、同じ場所へ見て分かる PDF を作る。
#           同じ見張りを PostToolUse の Write|Edit|MultiEdit へも登録する (1 本の実体で 2 か所)。
#
# 【安全策 (v2056.10_chrome_clone_guard_wire.sh と同じ規律)】
#   ・設定の全文の控えは作らない（お客様の秘密が残り続けるため。2026-10-28）
#   ・壊れた settings.json には一切触らない
#   ・同じ見張りが既に入っていれば足さない (表記違いも実体名で見て二重登録しない)
#   ・実体が無ければ登録しない (毎回失敗する死配線を作らない)
#   ・読めた設定だけを一時ファイルへ書き、JSON として読み直してから原子的に置き換える
#   ・停止スイッチ: SOLOPTILINK_DELIVER_PDF_HOOK_WIRE=off (登録しない) /
#                   SOLOPTILINK_DELIVER_PDF_HOOK=off (登録済みの見張りを黙らせる)
# ============================================================
set -u

MIG_NAME="v2056.13_deliver_pdf_hook_wire"
SL_DIR="${SOLOPTILINK_DIR:-${SOLOPTILINK_HOME:-$HOME/.soloptilink}}"
CLAUDE_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
SETTINGS_FILE="${CLAUDE_SETTINGS:-$CLAUDE_DIR/settings.json}"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"
HOOK_REL="lib/deliver-pdf/deliver-pdf.sh"
HOOK_CMD='bash ~/.soloptilink/lib/deliver-pdf/deliver-pdf.sh posttool 2>/dev/null || true'
HOOK_TIMEOUT=60

mig_log() {
    echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}

# 登録を行う python 本体 (★$( ) の内側にヒアドキュメントを置かない: bash 3.2 で壊れる)
_dph_write_py() {
    cat > "$1" <<'PYEOF'
import json, os, sys

# >>> sl-safe-settings-write v2 (2026-10-29) >>>
# お客様の設定の全文の控えは作らない。控えには環境変数や許可の設定がそのまま写り、
# 消す処理がどこにも無いまま残り続けていた。読めた設定だけを一時ファイルに書き、
# JSON として読み直してから原子的に置き換える。読んでから置き換えるまでに
# 別の処理が設定を書いていたら、上書きせずに次の起動でやり直す。
# 設定がリンクのときはリンクを残し、リンク先の実体を同じ手順で置き換える。
# 撤去の段 3 と同じ扱いにそろえた (2026-10-29 独立審査で指摘)。
# v1 はリンクそのものを普通のファイルに置き換え、お客様の管理の先から切り離していた。
# 壊れたリンクと、読んでから置き換えるまでに行き先が変わったリンクには書かずに止める。
def sl_safe_settings_write(path, data, before):
    import json as _json, os as _os, stat as _stat
    target = _os.path.realpath(path)
    folder = _os.path.dirname(target) or "."
    tmp = _os.path.join(folder, "." + _os.path.basename(target) + ".sl-new.%d" % _os.getpid())
    flags = _os.O_WRONLY | _os.O_CREAT | _os.O_EXCL | getattr(_os, "O_NOFOLLOW", 0)
    try:
        fd = _os.open(tmp, flags, 0o600 if before is not None else 0o666)
    except OSError:
        return False
    try:
        with _os.fdopen(fd, "w", encoding="utf-8") as handle:
            if before is not None:
                try:
                    _os.fchmod(handle.fileno(), _stat.S_IMODE(before.st_mode))
                except (AttributeError, OSError):
                    pass
            _json.dump(data, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            _os.fsync(handle.fileno())
        with open(tmp, encoding="utf-8") as handle:
            if not isinstance(_json.load(handle), dict):
                return False
        if _os.path.realpath(path) != target:
            return False
        if before is not None:
            now = _os.stat(path)
            if (now.st_ino, now.st_size, now.st_mtime_ns) != (before.st_ino, before.st_size, before.st_mtime_ns):
                return False
        elif _os.path.lexists(path):
            return False
        _os.replace(tmp, target)
        return True
    except Exception:
        return False
    finally:
        if _os.path.lexists(tmp) and not _os.path.islink(tmp):
            try:
                _os.unlink(tmp)
            except OSError:
                pass
# <<< sl-safe-settings-write v2 <<<

settings = os.environ["DPH_SETTINGS"]
cmd = os.environ["DPH_CMD"]
timeout = int(os.environ["DPH_TIMEOUT"])
name = "deliver-pdf.sh"

# 「無い」と「壊れている」を分ける。壊れているものを {} と読み替えて上書きしない
before = os.stat(settings) if os.path.exists(settings) else None
if before is not None:
    try:
        with open(settings, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        print("ABORT_UNPARSABLE"); sys.exit(0)
    if not isinstance(data, dict):
        print("ABORT_NOT_DICT"); sys.exit(0)
else:
    data = {}
hooks = data.setdefault("hooks", {})
if not isinstance(hooks, dict):
    print("ABORT_HOOKS_NOT_DICT"); sys.exit(0)
arr = hooks.get("PostToolUse")
if arr is None:
    arr = []
    hooks["PostToolUse"] = arr
if not isinstance(arr, list):
    print("ABORT_POSTTOOLUSE_NOT_LIST"); sys.exit(0)

# 登録先は 2 か所: コマンドの後 (ZIP の確かめ) と、書き込みの後 (書類の PDF 化)
WANT = ["Bash", "Write|Edit|MultiEdit"]
have = set()
for entry in arr:
    if not isinstance(entry, dict):
        continue
    for h in (entry.get("hooks") or []):
        if isinstance(h, dict) and name in (h.get("command") or ""):
            m = entry.get("matcher", "")
            have.add("Bash" if "Bash" in m else ("Write|Edit|MultiEdit" if ("Write" in m or "Edit" in m) else m))
added = 0
for m in WANT:
    if m in have:
        continue
    arr.append({"matcher": m, "hooks": [{"type": "command", "command": cmd, "timeout": timeout}]})
    added += 1
if added == 0:
    print("WIRED added=0"); sys.exit(0)
if not sl_safe_settings_write(settings, data, before):
    print("ABORT_WRITE_INVALID")
    sys.exit(0)
print("WIRED added=%d" % added)
PYEOF
}

# 登録されている本数 (実体名で数える)
_dph_count() {
    DPH_SETTINGS="$1" python3 - <<'PYEOF' 2>/dev/null
import json, os
try:
    d = json.load(open(os.environ["DPH_SETTINGS"], encoding="utf-8"))
except Exception:
    print(-1); raise SystemExit(0)
n = 0
for m in ((d.get("hooks") or {}).get("PostToolUse") or []):
    if not isinstance(m, dict): continue
    for h in (m.get("hooks") or []):
        if "deliver-pdf.sh" in ((h or {}).get("command") or ""): n += 1
print(n)
PYEOF
}

_dph_write_state() {
    DPH_STATE_FILE="$STATE_FILE" DPH_MIG_NAME="$MIG_NAME" DPH_NOTE="$1" python3 - <<'PYEOF' 2>>"$LOG_FILE"
import json, os, datetime
sf = os.environ["DPH_STATE_FILE"]
try:
    data = json.load(open(sf, encoding="utf-8"))
except Exception:
    data = {}
if not isinstance(data, dict):
    data = {}
data[os.environ["DPH_MIG_NAME"]] = {
    "applied_at": datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
    "note": os.environ["DPH_NOTE"]}
tmp = sf + ".tmp.%d" % os.getpid()
with open(tmp, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
os.replace(tmp, sf)
PYEOF
}

mig_apply() {
    mkdir -p "$SL_DIR" "$CLAUDE_DIR" 2>/dev/null || true
    mig_log "START"

    case "$(printf '%s' "${SOLOPTILINK_DELIVER_PDF_HOOK_WIRE:-on}" | tr 'A-Z' 'a-z')" in
        off|0|false|no|disabled)
            mig_log "KILL_SWITCH -> NOOP (retryable)"; return 0 ;;
    esac
    if [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; then
        mig_log "ALREADY_APPLIED -> NOOP"; return 0
    fi
    if ! command -v python3 >/dev/null 2>&1; then
        mig_log "PRECONDITION_FAILED python3 not found (retryable)"; return 0
    fi
    if [ ! -f "$SL_DIR/$HOOK_REL" ]; then
        mig_log "PRECONDITION_FAILED 実体が無い $HOOK_REL (retryable)"; return 0
    fi

    DPH_TMPD="$(mktemp -d "${TMPDIR:-/tmp}/dphwire.XXXXXX" 2>/dev/null)" || {
        mig_log "PRECONDITION_FAILED mktemp (retryable)"; return 0; }

    _dph_write_py "$DPH_TMPD/wire.py"
    RESULT="$(DPH_SETTINGS="$SETTINGS_FILE" DPH_CMD="$HOOK_CMD" DPH_TIMEOUT="$HOOK_TIMEOUT" \
              python3 "$DPH_TMPD/wire.py" 2>>"$LOG_FILE")"
    rm -rf "$DPH_TMPD" 2>/dev/null || true

    # 書いた直後にシェル側からも JSON として読み直す (二重の確認)
    if [ -f "$SETTINGS_FILE" ] && ! DPH_S="$SETTINGS_FILE" python3 -c \
        'import json,os; json.load(open(os.environ["DPH_S"],encoding="utf-8"))' >/dev/null 2>&1; then
        mig_log "POSTCHECK_FAILED settings.json が読めない（当社は置き換える前に確かめている。別の処理が書いた可能性）-> state を書かず次回やり直します"
        return 0
    fi
    case "$RESULT" in
        WIRED*) mig_log "WIRE_SUCCESS ($RESULT)" ;;
        *)      mig_log "WIRE_FAILED ($RESULT) -> state を書かず再試行可能にします"; return 0 ;;
    esac

    # 宣言でなく現物を数える
    N="$(_dph_count "$SETTINGS_FILE")"
    case "$N" in ''|*[!0-9]*) N=-1 ;; esac
    if [ "$N" -lt 2 ]; then
        mig_log "VERIFY_INCOMPLETE registered=${N} -> state を書かず再試行可能にします"; return 0
    fi

    _dph_write_state "wired registered=${N}"
    mig_log "DONE ($RESULT) registered=${N}"
    return 0
}

# ------------------------------------------------------------
# selftest — 隔離した仮想 HOME で実走する
#   C1 設定ゼロの端末 → 1 本登録・JSON 妥当
#   C2 冪等 (state を消して再実行しても 1 本のまま)
#   C3 表記違い ("$HOME/..." で先に入っている) を二重登録しない
#   C4 実体が無いときは登録しない (済み扱いにもしない)
#   C5 停止スイッチ off で登録しない
#   C6 壊れた settings.json を一切書き換えない
#   C7 既存の他の登録と設定を消さない
# ------------------------------------------------------------
mig_selftest() {
    local self rc=0
    self="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
    root="$(mktemp -d "${TMPDIR:-/tmp}/dphsel.XXXXXX")" || return 1
    trap 'rm -rf "$root" 2>/dev/null || true' EXIT INT TERM
    _mk() { mkdir -p "$root/$1/sl/lib/deliver-pdf" "$root/$1/claude"
            printf '#!/usr/bin/env bash\nexit 0\n' > "$root/$1/sl/$HOOK_REL"; }
    _run() { local n="$1"; shift
             env -u CLAUDE_SETTINGS "$@" HOME="$root/$n" SOLOPTILINK_DIR="$root/$n/sl" \
                 SOLOPTILINK_HOME="$root/$n/sl" CLAUDE_CONFIG_DIR="$root/$n/claude" \
                 bash "$self" >/dev/null 2>&1; }
    _ok() { if [ "$1" = "$2" ]; then echo "  [OK] $3"; else echo "  [FAIL] $3 (実際=$1 期待=$2)"; rc=1; fi; }

    _mk c1; _run c1
    _ok "$(_dph_count "$root/c1/claude/settings.json")" 2 "設定ゼロの端末に2本登録 (コマンドの後・書き込みの後)"
    rm -f "$root/c1/sl/.migration-state.json"; _run c1
    _ok "$(_dph_count "$root/c1/claude/settings.json")" 2 "冪等: 再実行しても2本のまま"

    _mk c3
    printf '%s' '{"hooks":{"PostToolUse":[{"matcher":"Bash","hooks":[{"type":"command","command":"bash \"$HOME/.soloptilink/lib/deliver-pdf/deliver-pdf.sh\" posttool"}]}]}}' \
        > "$root/c3/claude/settings.json"
    _run c3
    _ok "$(_dph_count "$root/c3/claude/settings.json")" 2 "表記違いで先に入っていても二重登録しない (足りない1本だけ足す)"

    _mk c4; rm -f "$root/c4/sl/$HOOK_REL"; _run c4
    _ok "$(_dph_count "$root/c4/claude/settings.json")" -1 "実体が無いときは登録しない"
    local st4=0; grep -q "\"${MIG_NAME}\"" "$root/c4/sl/.migration-state.json" 2>/dev/null && st4=1
    _ok "$st4" 0 "実体が無いときは済み扱いにせず、次の更新で再試行できる"

    _mk c5; _run c5 SOLOPTILINK_DELIVER_PDF_HOOK_WIRE=off
    _ok "$(_dph_count "$root/c5/claude/settings.json")" -1 "停止スイッチ off で登録しない"

    _mk c6; printf '{ this is not json' > "$root/c6/claude/settings.json"
    local b6; b6="$(cat "$root/c6/claude/settings.json")"; _run c6
    _ok "$(cat "$root/c6/claude/settings.json")" "$b6" "壊れた設定を一切書き換えない"

    _mk c7
    printf '%s' '{"model":"x","hooks":{"PostToolUse":[{"matcher":"Bash","hooks":[{"type":"command","command":"bash other.sh"}]}],"Stop":[{"matcher":"*","hooks":[{"type":"command","command":"bash stop.sh"}]}]}}' \
        > "$root/c7/claude/settings.json"
    _run c7
    local k7; k7="$(DPH_S="$root/c7/claude/settings.json" python3 -c 'import json,os; d=json.load(open(os.environ["DPH_S"])); print(d.get("model"), len(d["hooks"]["PostToolUse"]), len(d["hooks"]["Stop"]))' 2>/dev/null)"
    _ok "$k7" "x 3 1" "既存の他の登録と設定を消さない"
    # 番兵を含む設定を実際に変更し、全文の控え・権限・環境変数の保持を確かめる。
    _mk secret
    local sentinel="sl-sentinel-$$-do-not-copy"
    printf '{"env":{"SL_SENTINEL_SECRET":"%s"}}\n' "$sentinel" > "$root/secret/claude/settings.json"
    chmod 600 "$root/secret/claude/settings.json"
    _run secret
    local secret_count
    secret_count="$(_dph_count "$root/secret/claude/settings.json")"
    if python3 - "$root/secret" "$root/secret-control" "$sentinel" "$secret_count" <<'PYSECRET'
import json, os, stat, sys
from pathlib import Path
sandbox, control = Path(sys.argv[1]), Path(sys.argv[2])
marker = sys.argv[3]

def sentinel_files(folder, secret):
    found = []
    for current, _dirs, names in os.walk(folder):
        for name in names:
            candidate = Path(current) / name
            if stat.S_ISREG(candidate.lstat().st_mode) and secret.encode("utf-8") in candidate.read_bytes():
                found.append(candidate)
    return found

# 同じ検出器で偽の控えを含む別の砂箱を調べ、2 ファイルを検出する。
(control / "claude").mkdir(parents=True)
(control / "sl").mkdir()
(control / "claude" / "settings.json").write_text(json.dumps({"env": {"SL_SENTINEL_SECRET": marker}}), encoding="utf-8")
(control / "sl" / "fake-copy.json").write_text(marker, encoding="utf-8")
control_files = sentinel_files(control, marker)
assert len(control_files) == 2 and len(control_files) != 1, "偽の控えを見逃した"
settings = sandbox / "claude" / "settings.json"
assert sys.argv[4] == "2", "設定への登録が実際に起きていない"
assert sentinel_files(sandbox, marker) == [settings], "番兵を含む通常ファイルが設定以外にもある"
assert not os.path.lexists(sandbox / "claude" / (".back" + "ups")), "控えのフォルダが作られた"
assert stat.S_IMODE(os.stat(settings).st_mode) == 0o600, "設定の権限が変わった"
assert json.loads(settings.read_text(encoding="utf-8"))["env"]["SL_SENTINEL_SECRET"] == marker, "環境変数が失われた"
PYSECRET
    then
        echo "  PASS  番兵: 登録を実行・設定だけに保持・控えなし・権限600・偽の控えを検出"
    else
        echo "  FAIL  番兵: 設定の保持または控えの検出に失敗"
        rc=1
    fi

    [ "$rc" -eq 0 ] && echo "SELFTEST PASS" || echo "SELFTEST FAIL"
    return $rc
}

case "${1:-apply}" in
    selftest) mig_selftest; exit $? ;;
    *)        mig_apply; exit 0 ;;
esac
