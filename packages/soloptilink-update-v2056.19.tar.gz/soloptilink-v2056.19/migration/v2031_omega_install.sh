#!/usr/bin/env bash
# 自己検査は通常処理と終了フックより先に分岐し、本物の設定には触れない。
mig_selftest() {
    python3 - "$0" "$$" <<'PYTEST'
import hashlib, json, os, stat, subprocess, sys, tempfile
from pathlib import Path

script = Path(sys.argv[1]).resolve()
secret = "sl-sentinel-" + sys.argv[2] + "-do-not-copy"
wirings = [('Stop', 'soloptilink-omega-hook.sh', 'lib/soloptilink-omega-hook.sh')]
passed = failed = 0

def report(label, ok):
    global passed, failed
    print("  " + ("PASS" if ok else "FAIL") + "  " + label)
    if ok:
        passed += 1
    else:
        failed += 1

def secret_files(home):
    matches = []
    for folder in (home / ".claude", home / ".soloptilink"):
        for path in folder.rglob("*"):
            if stat.S_ISREG(path.lstat().st_mode) and secret.encode() in path.read_bytes():
                matches.append(path)
    return matches

def prepare(home):
    (home / ".claude").mkdir(parents=True)
    sl = home / ".soloptilink"
    sl.mkdir()
    for event, fragment, target in wirings:
        path = sl / target
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
        path.chmod(0o700)
    fortress = sl / "lib/quality-fortresses/unvigintifortress.sh"
    fortress.parent.mkdir(parents=True, exist_ok=True)
    fortress.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
    return home / ".claude/settings.json"

def apply(home, extra=None):
    env = dict(os.environ, HOME=str(home), SOLOPTILINK_DIR=str(home / ".soloptilink"))
    if extra:
        env.update(extra)
    return subprocess.run(["/bin/bash", str(script)], env=env, capture_output=True)

def healthy(home, extra=None):
    settings = prepare(home)
    settings.write_text(json.dumps({"env": {"SL_SENTINEL_SECRET": secret}, "customer_setting": "維持"}), encoding="utf-8")
    settings.chmod(0o600)
    before = settings.read_bytes()
    result = apply(home, extra)
    data = json.loads(settings.read_text(encoding="utf-8"))
    registered = all(any(fragment in hook.get("command", "")
        for group in data.get("hooks", {}).get(event, [])
        for hook in group.get("hooks", [])) for event, fragment, target in wirings)
    return (result.returncode == 0 and before != settings.read_bytes() and registered
        and secret_files(home) == [settings]
        and not (home / ".claude" / ("." + "backups")).exists()
        and stat.S_IMODE(os.stat(settings).st_mode) == 0o600
        and data.get("env", {}).get("SL_SENTINEL_SECRET") == secret
        and data.get("customer_setting") == "維持")

parent = Path(tempfile.gettempdir())
parent.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(prefix=script.stem + "-selftest-", dir=str(parent)) as temporary:
    root = Path(temporary)
    control = root / "control"
    settings = prepare(control)
    settings.write_text(json.dumps({"env": {"SL_SENTINEL_SECRET": secret}}), encoding="utf-8")
    (control / ".soloptilink" / "fake-copy.txt").write_text(secret, encoding="utf-8")
    control_ok = len(secret_files(control)) == 2
    report("偽の控えを含む 2 ファイルを検出して不合格にできる", control_ok)
    report("登録を実走し、全文控えなし・権限 600・環境変数の維持を確認", healthy(root / "healthy") and control_ok)
    unchanged = True
    for index, malformed in enumerate((b"{broken", b"[]", b"null", b"{}\n{}")):
        home = root / ("broken-%d" % index)
        settings = prepare(home)
        settings.write_bytes(malformed)
        before = hashlib.sha256(settings.read_bytes()).digest()
        apply(home)
        state = home / ".soloptilink/.migration-state.json"
        names = home / ".soloptilink/.migration-state.json.names"
        unchanged = unchanged and hashlib.sha256(settings.read_bytes()).digest() == before and not state.exists() and not names.exists()
    report("壊れた設定と辞書以外の設定はバイト不変・state 未記録", unchanged)

print("合計: PASS %d / FAIL %d" % (passed, failed))
sys.exit(1 if failed else 0)
PYTEST
}
if [ "${1:-}" = "selftest" ]; then
    mig_selftest
    exit $?
fi

# 試用端末では、登録した命令全体を終了時に試用の関所で覆う（有料端末は変更しない）。
trap '[ ! -f "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" ] || bash "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" >/dev/null 2>&1 || true' EXIT
# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# ============================================================
# v2031.0 ARTE-Omega 配線 migration
# ------------------------------------------------------------
# 既存顧客 (35社) の端末に v2025-v2030 ARTE-Omega を遡及配線する。
#
# 配線内容:
#   1. lib/security/arte/v2025-v2030/ 配置確認
#   2. lib/soloptilink-omega-hook.sh 配置確認
#   3. lib/quality-fortresses/{21st-30th}fortress.sh 配置確認
#   4. settings.json の Stop hook に omega-hook 自動起動を追加
#   5. CLAUDE.md にセキュリティ自動稼働セクション追記
#
# 冪等: 既に配線済みなら何もしない
# 設定の全文の控えは作らない（環境変数や許可の設定が残り続けていたため。2026-10-28）。
# 読めない設定は書き換えず、一時ファイルを JSON として読み直してから原子的に置き換える。
# 状態: ~/.soloptilink/.migration-state.json
# ============================================================
set -u

MIG_NAME="v2031_omega_install"
SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
CLAUDE_DIR="$HOME/.claude"
SETTINGS_FILE="$CLAUDE_DIR/settings.json"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"

mkdir -p "$SL_DIR" "$CLAUDE_DIR" 2>/dev/null || true

mig_log() {
  echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}
mig_log "START"

# 冪等性チェック (M-4修正: sidecar .names も参照し python3 不在環境でも二重適用しない)
NAMES_MARK="$STATE_FILE.names"
if { [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; } || grep -qxF "$MIG_NAME" "$NAMES_MARK" 2>/dev/null; then
  mig_log "ALREADY_APPLIED -> NOOP"
  echo "[migration] v2031 omega install already applied"
  exit 0
fi

# 1. v2025-v2030 ディレクトリ存在確認
MISSING=()
for V in v2025 v2026 v2027 v2028 v2029 v2030; do
  if [ ! -d "$SL_DIR/lib/security/arte/$V" ]; then
    MISSING+=("lib/security/arte/$V")
  fi
done
if [ ${#MISSING[@]} -gt 0 ]; then
  mig_log "WARN: missing dirs: ${MISSING[*]}"
  echo "[migration] WARN: v2025-v2030 一部欠如: ${MISSING[*]}"
  echo "[migration] tar.gz 再配信で同梱されるまで omega-hook は no-op で動作します"
fi

# 2. omega-hook 配置確認
if [ ! -x "$SL_DIR/lib/soloptilink-omega-hook.sh" ]; then
  mig_log "WARN: omega-hook missing"
  echo "[migration] WARN: omega-hook.sh 不在 (tar.gz 再配信待ち)"
fi

# 3. Fortress 21st-30th 配置確認
FORTRESS_COUNT=0
for F in unvigintifortress duovigintifortress tervigintifortress quattuorvigintifortress \
         quinvigintifortress sexvigintifortress septuvigintifortress octovigintifortress \
         novemvigintifortress trigintafortress; do
  [ -f "$SL_DIR/lib/quality-fortresses/$F.sh" ] && FORTRESS_COUNT=$((FORTRESS_COUNT+1))
done
mig_log "Fortress 21st-30th 配置: $FORTRESS_COUNT/10"
echo "[migration] Fortress 21st-30th 配置: $FORTRESS_COUNT/10"

# 4. settings.json の Stop hook に omega-hook 自動起動を追加
if [ -f "$SETTINGS_FILE" ]; then
  # 既に omega-hook が登録済みかチェック
  if grep -q "soloptilink-omega-hook" "$SETTINGS_FILE" 2>/dev/null; then
    mig_log "settings.json: omega-hook 既登録"
    echo "[migration] settings.json: omega-hook 既に登録済み"
  elif [ "$FORTRESS_COUNT" -eq 0 ]; then
    # ★2026-10-26: 配布物では採点の部品 (lib/quality-fortresses/*vigintifortress*.sh) を
    #   build-update-package.sh が必ず取り除くため、お客様の端末では毎回「未実施」になる。
    #   しかも Stop の標準出力はお客様にもモデルにも届かない。動かない登録を足さない。
    mig_log "採点の部品が 0/10 のため omega-hook を登録しません (動かない登録を作らない)"
    echo "[migration] omega-hook: 採点の部品が配布物に無いため登録を見送りました"
  elif ! command -v python3 >/dev/null 2>&1; then
    # python3 不在 (標準的な Windows + Git Bash)。settings.json の JSON 編集は
    # sed では安全にできないため配線をスキップするが、必ず告知を残す (静音スキップ禁止)。
    # 自動更新フック自体はランチャーバイナリの register-autoupdate-hook が担うため
    # 更新経路は失われない。omega-hook は python3 導入後の更新で自動配線される。
    mig_log "python3 不在のため omega-hook 配線をスキップ (次回 python3 導入後の更新で自動配線)"
    echo "[migration] ⚠ python3 が見つからないため omega-hook の配線を保留しました"
  else
    # python3 で安全に append
    if ! python3 - "$SETTINGS_FILE" <<'PY'
import json, sys, os
# >>> sl-safe-settings-write v2 (2026-10-29) >>>
# お客様の設定の全文の控えは作らない。控えには環境変数や許可の設定がそのまま写り、
# 消す処理がどこにも無いまま残り続けていた。読めた設定だけを一時ファイルに書き、
# JSON として読み直してから原子的に置き換える。読んでから置き換えるまでに
# 別の処理が設定を書いていたら、上書きせずに次の起動でやり直す。
# 設定がリンクのときはリンクを残し、リンク先の実体を同じ手順で置き換える。
# 撤去の段 3 と同じ扱いにそろえた (2026-10-29 独立審査で指摘)。
# v1 はリンクそのものを普通のファイルに置き換え、お客様の管理の先から切り離していた。
# 壊れたリンクと、読んでから置き換えるまでに行き先が変わったリンクには書かずに止める。
def sl_safe_settings_write(path, data, before):
    import json as _json, os as _os, stat as _stat
    target = _os.path.realpath(path)
    folder = _os.path.dirname(target) or "."
    tmp = _os.path.join(folder, "." + _os.path.basename(target) + ".sl-new.%d" % _os.getpid())
    flags = _os.O_WRONLY | _os.O_CREAT | _os.O_EXCL | getattr(_os, "O_NOFOLLOW", 0)
    try:
        fd = _os.open(tmp, flags, 0o600 if before is not None else 0o666)
    except OSError:
        return False
    try:
        with _os.fdopen(fd, "w", encoding="utf-8") as handle:
            if before is not None:
                try:
                    _os.fchmod(handle.fileno(), _stat.S_IMODE(before.st_mode))
                except (AttributeError, OSError):
                    pass
            _json.dump(data, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            _os.fsync(handle.fileno())
        with open(tmp, encoding="utf-8") as handle:
            if not isinstance(_json.load(handle), dict):
                return False
        if _os.path.realpath(path) != target:
            return False
        if before is not None:
            now = _os.stat(path)
            if (now.st_ino, now.st_size, now.st_mtime_ns) != (before.st_ino, before.st_size, before.st_mtime_ns):
                return False
        elif _os.path.lexists(path):
            return False
        _os.replace(tmp, target)
        return True
    except Exception:
        return False
    finally:
        if _os.path.lexists(tmp) and not _os.path.islink(tmp):
            try:
                _os.unlink(tmp)
            except OSError:
                pass
# <<< sl-safe-settings-write v2 <<<
p = sys.argv[1]
try:
    before = os.stat(p) if os.path.exists(p) else None
    with open(p) as f:
        d = json.load(f)
except Exception as e:
    print(f"settings.json parse failed: {e}", file=sys.stderr)
    sys.exit(1)
if not isinstance(d, dict):
    print("ABORT_NOT_DICT", file=sys.stderr)
    sys.exit(1)
hooks = d.setdefault("hooks", {})
stop_hooks = hooks.setdefault("Stop", [])
# 配線対象: Stop hook で omega-hook --quick を呼ぶ (cwd を自動判定)
omega_entry = {
    "matcher": "*",
    "hooks": [{
        "type": "command",
        "command": "bash $HOME/.soloptilink/lib/soloptilink-omega-hook.sh check \"$(pwd)\" --quick 2>/dev/null | tail -5 || true"
    }]
}
# 既存と重複しないか
already = False
for h in stop_hooks:
    cmd = ""
    if isinstance(h, dict):
        for inner in h.get("hooks", []):
            if isinstance(inner, dict) and "omega-hook" in inner.get("command", ""):
                already = True; break
    if already: break
if not already:
    stop_hooks.append(omega_entry)
    if not sl_safe_settings_write(p, d, before):
        print("ABORT_WRITE_INVALID", file=sys.stderr)
        sys.exit(1)
    print("settings.json: Stop hook に omega-hook 追加完了")
else:
    print("settings.json: 既に配線済み")
PY
    then
      mig_log "ABORTED settings.json の配線を中止 -> state を書かず次回やり直します"
      exit 0
    fi
    mig_log "settings.json hook 配線完了"
  fi
else
  mig_log "settings.json 不在 (新規作成スキップ)"
fi

# 5. 状態記録 (M-4修正: sidecar .names を記録の正とし既存 state を壊さない)
TS=$(date +%Y-%m-%dT%H:%M:%S%z)
printf '%s\n' "$MIG_NAME" >> "$NAMES_MARK" 2>/dev/null || true
if [ -f "$STATE_FILE" ] && command -v python3 >/dev/null 2>&1; then
  python3 - "$STATE_FILE" "$MIG_NAME" "$TS" <<'PY' 2>/dev/null || true
import json, sys
p, name, ts = sys.argv[1:4]
try:
    with open(p) as f: d = json.load(f)
except: d = {"applied": []}
d.setdefault("applied", []).append({"name": name, "ts": ts})
with open(p, "w") as f:
    json.dump(d, f, indent=2, ensure_ascii=False)
PY
elif [ ! -f "$STATE_FILE" ]; then
  printf '{"applied":[{"name":"%s","ts":"%s"}]}\n' "$MIG_NAME" "$TS" > "$STATE_FILE"
fi
mig_log "DONE"
echo "[migration] v2031 omega install complete"
exit 0
