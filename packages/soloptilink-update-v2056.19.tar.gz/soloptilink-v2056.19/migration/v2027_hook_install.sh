#!/usr/bin/env bash
# 自己検査は通常処理と終了フックより先に分岐し、本物の設定には触れない。
mig_selftest() {
    python3 - "$0" "$$" <<'PYTEST'
import hashlib, json, os, stat, subprocess, sys, tempfile
from pathlib import Path

script = Path(sys.argv[1]).resolve()
secret = "sl-sentinel-" + sys.argv[2] + "-do-not-copy"
wirings = [('UserPromptSubmit', 'auto-update.sh', 'auto-update.sh'), ('SessionStart', 'auto-update.sh', 'auto-update.sh')]
passed = failed = 0

def report(label, ok):
    global passed, failed
    print("  " + ("PASS" if ok else "FAIL") + "  " + label)
    if ok:
        passed += 1
    else:
        failed += 1

def secret_files(home):
    matches = []
    for folder in (home / ".claude", home / ".soloptilink"):
        for path in folder.rglob("*"):
            if stat.S_ISREG(path.lstat().st_mode) and secret.encode() in path.read_bytes():
                matches.append(path)
    return matches

def prepare(home):
    (home / ".claude").mkdir(parents=True)
    sl = home / ".soloptilink"
    sl.mkdir()
    for event, fragment, target in wirings:
        path = sl / target
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
        path.chmod(0o700)

    return home / ".claude/settings.json"

def apply(home, extra=None):
    env = dict(os.environ, HOME=str(home), SOLOPTILINK_DIR=str(home / ".soloptilink"))
    if extra:
        env.update(extra)
    return subprocess.run(["/bin/bash", str(script)], env=env, capture_output=True)

def healthy(home, extra=None):
    settings = prepare(home)
    settings.write_text(json.dumps({"env": {"SL_SENTINEL_SECRET": secret}, "customer_setting": "維持"}), encoding="utf-8")
    settings.chmod(0o600)
    before = settings.read_bytes()
    result = apply(home, extra)
    data = json.loads(settings.read_text(encoding="utf-8"))
    registered = all(any(fragment in hook.get("command", "")
        for group in data.get("hooks", {}).get(event, [])
        for hook in group.get("hooks", [])) for event, fragment, target in wirings)
    return (result.returncode == 0 and before != settings.read_bytes() and registered
        and secret_files(home) == [settings]
        and not (home / ".claude" / ("." + "backups")).exists()
        and stat.S_IMODE(os.stat(settings).st_mode) == 0o600
        and data.get("env", {}).get("SL_SENTINEL_SECRET") == secret
        and data.get("customer_setting") == "維持")

parent = Path(tempfile.gettempdir())
parent.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(prefix=script.stem + "-selftest-", dir=str(parent)) as temporary:
    root = Path(temporary)
    control = root / "control"
    settings = prepare(control)
    settings.write_text(json.dumps({"env": {"SL_SENTINEL_SECRET": secret}}), encoding="utf-8")
    (control / ".soloptilink" / "fake-copy.txt").write_text(secret, encoding="utf-8")
    control_ok = len(secret_files(control)) == 2
    report("偽の控えを含む 2 ファイルを検出して不合格にできる", control_ok)
    report("登録を実走し、全文控えなし・権限 600・環境変数の維持を確認", healthy(root / "healthy") and control_ok)
    unchanged = True
    for index, malformed in enumerate((b"{broken", b"[]", b"null", b"{}\n{}")):
        home = root / ("broken-%d" % index)
        settings = prepare(home)
        settings.write_bytes(malformed)
        before = hashlib.sha256(settings.read_bytes()).digest()
        apply(home)
        state = home / ".soloptilink/.migration-state.json"
        names = home / ".soloptilink/.migration-state.json.names"
        unchanged = unchanged and hashlib.sha256(settings.read_bytes()).digest() == before and not state.exists() and not names.exists()
    report("壊れた設定と辞書以外の設定はバイト不変・state 未記録", unchanged)
    shim = root / "python-path"
    shim.mkdir()
    (shim / "jq").write_text("#!/usr/bin/env bash\nexit 1\n", encoding="utf-8")
    (shim / "jq").chmod(0o700)
    report("jq 失敗後の Python 経路でも登録・秘密と権限の維持を確認",
        healthy(root / "python-fallback", {"PATH": str(shim) + os.pathsep + os.environ.get("PATH", "")}) and control_ok)
    # 区切りの値が配列でない設定 (お客様の書き損じ) は、jq と Python のどちらの経路でも書き換えない (2026-10-28 独立審査)
    nonlist_ok = True
    for index, raw in enumerate((b'{"hooks": {"UserPromptSubmit": {"customer": 1}}}', b'{"hooks": {"SessionStart": "customer"}}',
                                 b'{"hooks": {"SessionStart": false}}', b'{"hooks": "customer"}')):
        for label, extra in (("jq", None), ("py", {"PATH": str(shim) + os.pathsep + os.environ.get("PATH", "")})):
            home = root / ("nonlist-%d-%s" % (index, label))
            settings = prepare(home)
            settings.write_bytes(raw)
            before = hashlib.sha256(settings.read_bytes()).digest()
            apply(home, extra)
            state = home / ".soloptilink/.migration-state.json"
            names = home / ".soloptilink/.migration-state.json.names"
            nonlist_ok = nonlist_ok and hashlib.sha256(settings.read_bytes()).digest() == before and not state.exists() and not names.exists()
    report("区切りの値が配列でない設定は jq と Python のどちらの経路でもバイト不変・state 未記録", nonlist_ok)
    # 設定がリンクのときはリンクを残し、リンク先の実体へ登録する。壊れたリンクの先には何も作らない (2026-10-29 独立審査)
    link_ok = True
    for label, extra in (("jq", None), ("py", {"PATH": str(shim) + os.pathsep + os.environ.get("PATH", "")})):
        home = root / ("link-" + label)
        settings = prepare(home)
        real = home / "dotfiles" / "claude-settings.json"
        real.parent.mkdir()
        real.write_text(json.dumps({"env": {"SL_SENTINEL_SECRET": secret}}), encoding="utf-8")
        real.chmod(0o600)
        settings.symlink_to(real)
        apply(home, extra)
        data = json.loads(real.read_text(encoding="utf-8"))
        registered = all(any(fragment in hook.get("command", "")
            for group in data.get("hooks", {}).get(event, [])
            for hook in group.get("hooks", [])) for event, fragment, target in wirings)
        link_ok = (link_ok and settings.is_symlink() and registered
            and stat.S_IMODE(os.stat(real).st_mode) == 0o600
            and data.get("env", {}).get("SL_SENTINEL_SECRET") == secret
            and not any(".sl-new" in n or ".tmp." in n for n in os.listdir(str(real.parent)) + os.listdir(str(settings.parent))))
        home = root / ("dangling-" + label)
        settings = prepare(home)
        settings.symlink_to(home / "dotfiles" / "nowhere.json")
        apply(home, extra)
        link_ok = (link_ok and settings.is_symlink() and not (home / "dotfiles").exists()
            and not (home / ".soloptilink/.migration-state.json").exists())
    report("リンクの設定はリンクを残して先へ登録し、壊れたリンクの先には何も作らない (jq と Python の両方の経路)", link_ok)
print("合計: PASS %d / FAIL %d" % (passed, failed))
sys.exit(1 if failed else 0)
PYTEST
}
if [ "${1:-}" = "selftest" ]; then
    mig_selftest
    exit $?
fi

# 試用端末では、登録した命令全体を終了時に試用の関所で覆う（有料端末は変更しない）。
trap '[ ! -f "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" ] || bash "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" >/dev/null 2>&1 || true' EXIT
# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# ============================================================
# v2027.0 hook install migration
# ------------------------------------------------------------
# 既存顧客 (~/.soloptilink/ がインストール済みだが ~/.claude/settings.json
# には auto-update.sh の hook が配線されていない端末) を遡及的に
# 自動更新可能な状態へ移行する。
#
# - 冪等: 既に配線済みなら何もしない (NOOP で正常終了)
# 設定の全文の控えは作らない（環境変数や許可の設定が残り続けていたため。2026-10-28）。
# 読めない設定は書き換えず、一時ファイルを JSON として読み直してから原子的に置き換える。
# - 状態は ~/.soloptilink/.migration-state.json に追記
# - ログは ~/.soloptilink/.migration.log に追記
# - jq → python3 → 安全 abort の優先順
#
# 単独実行可: setup.sh が無くても動作する。
# auto-update.sh が冒頭でこのスクリプトを冪等に呼び出すのが正規ルート。
# 手動実行: bash ~/.soloptilink/migration/v2027_hook_install.sh
# ============================================================
set -u

MIG_NAME="v2027_hook_install"
SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
CLAUDE_DIR="$HOME/.claude"
SETTINGS_FILE="$CLAUDE_DIR/settings.json"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"

# ------------------------------------------------------------
# HOOK_CMD を OS で出し分ける (Windows 導入時の恒久対策)
# ------------------------------------------------------------
# 従来は全 OS で `bash auto-update.sh` を登録していたが、Windows は bash を
# 標準搭載しないためフックが起動できなかった。
#   - Windows (Git Bash/MSYS/Cygwin から実行): ランチャー(.exe)経由に切替。
#     Claude Code がフックを cmd/PowerShell で実行しても bash リテラルに依存しない。
#     ランチャーは内部で Git Bash 等を探索し、無ければ Go ネイティブ更新を行う。
#   - Unix (Mac/Linux): 従来どおり `bash auto-update.sh` (既存顧客の冪等性を維持・
#     HOOK_CMD 文字列が変わらないので二重登録が起きない)。
case "$(uname -s 2>/dev/null)" in
    MINGW*|MSYS*|CYGWIN*|Windows_NT)
        HOOK_CMD="\"$HOME/.soloptilink/soloptilink.exe\" --hook-autoupdate"
        ;;
    *)
        HOOK_CMD="bash $HOME/.soloptilink/auto-update.sh"
        ;;
esac

# Windows はフック登録を Go ランチャーに一任する (2026-06-16 二重登録解消)。
# 本スクリプトの jq/python マージは command 文字列の厳密一致で冪等判定するため、
# .ps1 インストーラが Go で登録した表記 (C:/...) と本スクリプトの $HOME 展開表記 (/c/...) が
# 食い違うと二重登録される。Go の登録は意味一致 de-dup を持つので、Windows ではランチャーへ委譲する。
case "$(uname -s 2>/dev/null)" in
    MINGW*|MSYS*|CYGWIN*|Windows_NT)
        if [ -x "$HOME/.soloptilink/soloptilink.exe" ]; then
            "$HOME/.soloptilink/soloptilink.exe" --register-autoupdate-hook >/dev/null 2>&1 || true
            mig_log "DELEGATED_TO_LAUNCHER (windows)"
            exit 0
        fi
        ;;
esac

mkdir -p "$SL_DIR" "$CLAUDE_DIR" 2>/dev/null || true

mig_log() {
    echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}

mig_log "START"

# ------------------------------------------------------------
# 既に適用済みかチェック (冪等性)
# ------------------------------------------------------------
if [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; then
    mig_log "ALREADY_APPLIED (state=$STATE_FILE) -> NOOP"
    exit 0
fi

# ------------------------------------------------------------
# auto-update.sh の存在確認 (前提)
# ------------------------------------------------------------
# v2054.0: $HOME/.soloptilink 直書きを $SL_DIR に是正 (SOLOPTILINK_DIR 上書き環境=
# sandbox 検証・recover.sh selftest で precondition が誤 FAIL する潜在バグの修正。
# 実顧客環境では SL_DIR == $HOME/.soloptilink のため挙動不変)
if [ ! -f "$SL_DIR/auto-update.sh" ]; then
    mig_log "PRECONDITION_FAILED auto-update.sh not found"
    exit 0  # 致命的エラーにはしない (再試行可能なので)
fi

# ------------------------------------------------------------
# settings.json の準備
# ------------------------------------------------------------
# 壊れたリンクの先に新しい設定を作らない (リンクは共通の書き込み関数が見て止める)
if [ ! -e "$SETTINGS_FILE" ] && [ ! -L "$SETTINGS_FILE" ]; then
    echo '{}' > "$SETTINGS_FILE"
    mig_log "CREATED empty settings.json"
fi

# ------------------------------------------------------------
# jq があれば jq で merge
# ------------------------------------------------------------
merge_with_jq() {
    # 設定がリンクのときは jq の経路では書かず、Python の経路 (共通の書き込み関数 v2) に任せる。
    # 下の mv はリンクそのものを普通のファイルに置き換えてしまうため (2026-10-29 独立審査で指摘)。
    # 判定を 2 か所に持たないよう、リンク先へ書く手順は共通の書き込み関数の 1 か所だけに置く。
    if [ -L "$SETTINGS_FILE" ]; then
        mig_log "SETTINGS_IS_LINK -> python3 の経路で書きます"
        return 1
    fi
    local tmp="${SETTINGS_FILE}.tmp.$$"
    if ( umask 077; jq -s --arg cmd "$HOOK_CMD" '
        if length == 1 and (.[0] | type == "object") then .[0]
        else error("ABORT_UNPARSABLE_OR_NOT_DICT") end |
        if (.hooks == null) or (.hooks | type == "object") then .
        else error("ABORT_HOOKS_NOT_DICT") end |
        if ([.hooks.UserPromptSubmit, .hooks.SessionStart]
            | map(select(. != null and (type != "array"))) | length) == 0 then .
        else error("ABORT_EVENT_NOT_LIST") end |
        .hooks //= {} |
        .hooks.UserPromptSubmit //= [] |
        (.hooks.UserPromptSubmit
         | map(.hooks // [] | map(.command))
         | flatten
         | index($cmd)) as $exists_ups |
        (if $exists_ups == null then
            .hooks.UserPromptSubmit += [{
                "matcher": "*",
                "hooks": [{"type": "command", "command": $cmd, "timeout": 30}]
            }]
        else . end) |
        .hooks.SessionStart //= [] |
        (.hooks.SessionStart
         | map(.hooks // [] | map(.command))
         | flatten
         | index($cmd)) as $exists_ss |
        (if $exists_ss == null then
            .hooks.SessionStart += [{
                "matcher": "*",
                "hooks": [{"type": "command", "command": $cmd, "timeout": 30}]
            }]
        else . end)
    ' "$SETTINGS_FILE" > "$tmp" 2>>"$LOG_FILE" ); then
        if ! jq -e 'type == "object"' "$tmp" >/dev/null 2>>"$LOG_FILE"; then
            rm -f "$tmp" 2>/dev/null || true
            return 1
        fi
        if command -v python3 >/dev/null 2>&1; then
            python3 -c 'import shutil, sys; shutil.copymode(sys.argv[1], sys.argv[2])' "$SETTINGS_FILE" "$tmp" 2>>"$LOG_FILE" || true
        else
            local mode
            mode=$(stat -f '%Lp' "$SETTINGS_FILE" 2>/dev/null) || mode=$(stat -c '%a' "$SETTINGS_FILE" 2>/dev/null) || mode=""
            if [ -n "$mode" ]; then
                chmod "$mode" "$tmp" 2>>"$LOG_FILE" || true
            fi
        fi
        if mv "$tmp" "$SETTINGS_FILE"; then
            return 0
        fi
        rm -f "$tmp" 2>/dev/null || true
        return 1
    else
        rm -f "$tmp" 2>/dev/null || true
        return 1
    fi
}

# ------------------------------------------------------------
# python3 fallback
# ------------------------------------------------------------
merge_with_python() {
    if SETTINGS_FILE="$SETTINGS_FILE" HOOK_CMD="$HOOK_CMD" python3 - <<'PYEOF' 2>>"$LOG_FILE"
import json, os, sys
# >>> sl-safe-settings-write v2 (2026-10-29) >>>
# お客様の設定の全文の控えは作らない。控えには環境変数や許可の設定がそのまま写り、
# 消す処理がどこにも無いまま残り続けていた。読めた設定だけを一時ファイルに書き、
# JSON として読み直してから原子的に置き換える。読んでから置き換えるまでに
# 別の処理が設定を書いていたら、上書きせずに次の起動でやり直す。
# 設定がリンクのときはリンクを残し、リンク先の実体を同じ手順で置き換える。
# 撤去の段 3 と同じ扱いにそろえた (2026-10-29 独立審査で指摘)。
# v1 はリンクそのものを普通のファイルに置き換え、お客様の管理の先から切り離していた。
# 壊れたリンクと、読んでから置き換えるまでに行き先が変わったリンクには書かずに止める。
def sl_safe_settings_write(path, data, before):
    import json as _json, os as _os, stat as _stat
    target = _os.path.realpath(path)
    folder = _os.path.dirname(target) or "."
    tmp = _os.path.join(folder, "." + _os.path.basename(target) + ".sl-new.%d" % _os.getpid())
    flags = _os.O_WRONLY | _os.O_CREAT | _os.O_EXCL | getattr(_os, "O_NOFOLLOW", 0)
    try:
        fd = _os.open(tmp, flags, 0o600 if before is not None else 0o666)
    except OSError:
        return False
    try:
        with _os.fdopen(fd, "w", encoding="utf-8") as handle:
            if before is not None:
                try:
                    _os.fchmod(handle.fileno(), _stat.S_IMODE(before.st_mode))
                except (AttributeError, OSError):
                    pass
            _json.dump(data, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            _os.fsync(handle.fileno())
        with open(tmp, encoding="utf-8") as handle:
            if not isinstance(_json.load(handle), dict):
                return False
        if _os.path.realpath(path) != target:
            return False
        if before is not None:
            now = _os.stat(path)
            if (now.st_ino, now.st_size, now.st_mtime_ns) != (before.st_ino, before.st_size, before.st_mtime_ns):
                return False
        elif _os.path.lexists(path):
            return False
        _os.replace(tmp, target)
        return True
    except Exception:
        return False
    finally:
        if _os.path.lexists(tmp) and not _os.path.islink(tmp):
            try:
                _os.unlink(tmp)
            except OSError:
                pass
# <<< sl-safe-settings-write v2 <<<
sf = os.environ["SETTINGS_FILE"]
hc = os.environ["HOOK_CMD"]
try:
    before = os.stat(sf) if os.path.exists(sf) else None
    if before is None or before.st_size == 0:
        data = {}
    else:
        with open(sf, encoding="utf-8") as f:
            data = json.load(f)
except Exception:
    print("ABORT_UNPARSABLE", file=sys.stderr)
    sys.exit(1)
if not isinstance(data, dict):
    print("ABORT_NOT_DICT", file=sys.stderr)
    sys.exit(1)
hooks = data.setdefault('hooks', {})
if hooks is None:
    hooks = data['hooks'] = {}
if not isinstance(hooks, dict):
    print("ABORT_HOOKS_NOT_DICT", file=sys.stderr)
    sys.exit(1)
for evt in ('UserPromptSubmit', 'SessionStart'):
    arr = hooks.get(evt)
    if arr is None:
        arr = []
        hooks[evt] = arr
    if not isinstance(arr, list):
        # お客様の設定でこの区切りの値が配列でない（書き損じ）ときは、書かずに止める。
        # 当社の登録だけの配列で置き換えるとお客様の値が消え、全文の控えも無いため戻せない。
        # 2026-10-28 独立審査で指摘。v2056.10_chrome_clone_guard_wire.sh と同じ扱い。
        print("ABORT_EVENT_NOT_LIST", file=sys.stderr)
        sys.exit(1)
    found = False
    for entry in arr:
        if not isinstance(entry, dict):
            continue
        for h in entry.get('hooks', []) or []:
            if isinstance(h, dict) and h.get('command') == hc:
                found = True
                break
        if found:
            break
    if not found:
        arr.append({
            'matcher': '*',
            'hooks': [{'type': 'command', 'command': hc, 'timeout': 30}]
        })
if not sl_safe_settings_write(sf, data, before):
    print("ABORT_WRITE_INVALID", file=sys.stderr)
    sys.exit(1)
PYEOF
    then
        return 0
    else
        return 1
    fi
}

MERGED=false
if command -v jq >/dev/null 2>&1; then
    if merge_with_jq; then
        MERGED=true
        mig_log "JQ_MERGE_SUCCESS"
    else
        mig_log "JQ_MERGE_FAILED -> trying python3"
    fi
fi

if [ "$MERGED" = false ] && command -v python3 >/dev/null 2>&1; then
    if merge_with_python; then
        MERGED=true
        mig_log "PYTHON_MERGE_SUCCESS"
    else
        mig_log "PYTHON_MERGE_FAILED"
    fi
fi

if [ "$MERGED" = false ]; then
    mig_log "ABORTED neither jq nor python3 worked"
    exit 1
fi

# ------------------------------------------------------------
# state 書き込み (atomic)
# ------------------------------------------------------------
APPLIED_AT="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
STATE_TMP="${STATE_FILE}.tmp.$$"

if command -v jq >/dev/null 2>&1; then
    if [ -f "$STATE_FILE" ]; then
        if jq --arg name "$MIG_NAME" --arg at "$APPLIED_AT" '
            . + {($name): {"applied_at": $at}}
        ' "$STATE_FILE" > "$STATE_TMP" 2>>"$LOG_FILE"; then
            mv "$STATE_TMP" "$STATE_FILE"
        else
            rm -f "$STATE_TMP" 2>/dev/null || true
        fi
    else
        printf '{"%s": {"applied_at": "%s"}}\n' "$MIG_NAME" "$APPLIED_AT" > "$STATE_FILE"
    fi
elif command -v python3 >/dev/null 2>&1; then
    STATE_FILE="$STATE_FILE" MIG_NAME="$MIG_NAME" APPLIED_AT="$APPLIED_AT" STATE_TMP="$STATE_TMP" python3 - <<'PYEOF' 2>>"$LOG_FILE"
import json, os
sf = os.environ['STATE_FILE']
mn = os.environ['MIG_NAME']
at = os.environ['APPLIED_AT']
tmp = os.environ['STATE_TMP']
try:
    with open(sf, 'r') as f:
        data = json.load(f)
except Exception:
    data = {}
if not isinstance(data, dict):
    data = {}
data[mn] = {"applied_at": at}
with open(tmp, 'w') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
os.rename(tmp, sf)
PYEOF
else
    # 最終フォールバック: 単純に上書き (state ファイルが既に存在する場合は壊れる可能性あり)
    if [ ! -f "$STATE_FILE" ]; then
        printf '{"%s": {"applied_at": "%s"}}\n' "$MIG_NAME" "$APPLIED_AT" > "$STATE_FILE"
    fi
fi

mig_log "DONE applied_at=${APPLIED_AT}"
exit 0
