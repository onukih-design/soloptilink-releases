#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2034.5 - Claude Desktop MCP 自動登録 (Mac)
# =============================================================================
# SoloptiLinkAI-Setup.command 内でも実行されますが、後から単体で再登録する
# 場合のためにこのファイルを残してあります。ダブルクリック実行で動作。
# =============================================================================
set -e
trap 'echo ""; echo "⚠️ エラー。Enterキーで閉じます。"; read -r _; exit 1' ERR

clear 2>/dev/null || true

cat <<'BANNER'

  ╔════════════════════════════════════════════════════════════════╗
  ║    SoloptiLinkAI Claude Desktop MCP 自動登録 (Mac)            ║
  ╚════════════════════════════════════════════════════════════════╝

BANNER

LAUNCHER="$HOME/.soloptilink/soloptilink"
CLAUDE_CONFIG="$HOME/Library/Application Support/Claude/claude_desktop_config.json"

# STEP 1: Goランチャー検出
echo "[STEP 1/3] Goランチャー検出"
if [ ! -f "$LAUNCHER" ]; then
    echo "  ⚠️  $LAUNCHER が見つかりません。"
    echo "  先に SoloptiLinkAI-Setup.command を実行してください。"
    echo "[Enterキーで閉じます]"
    read -r _
    exit 1
fi
echo "  ✅ $LAUNCHER"
echo ""

# STEP 2: 既存設定の確認
# ★2026-10-28: 既存の設定の全文の控え (claude_desktop_config.json.bak.<日時>) は作らない。
#   控えには他社の接続先の鍵などがそのまま写り、消す処理がどこにも無いまま残り続けていた。
#   代わりに、読めない・想定外の形の設定は書き換えずに止まり、書くときは読み直して確かめてから置き換える。
echo "[STEP 2/3] Claude Desktop 設定確認"
mkdir -p "$(dirname "$CLAUDE_CONFIG")"
if [ -f "$CLAUDE_CONFIG" ]; then
    echo "  ✅ 既存の設定があります (ほかの連携の登録はそのまま残します)"
else
    echo "  既存設定なし (新規作成)"
fi
echo ""

# STEP 3: soloptilink MCP サーバー登録 (既存 mcpServers 保持)
echo "[STEP 3/3] soloptilink MCP サーバーを登録"
_mcp_rc=0
SOLOPTILINK_BIN="$LAUNCHER" python3 - "$CLAUDE_CONFIG" <<'PYEOF' || _mcp_rc=$?
import json, sys, os

# >>> sl-safe-settings-write v2 (2026-10-29) >>>
# お客様の設定の全文の控えは作らない。控えには環境変数や許可の設定がそのまま写り、
# 消す処理がどこにも無いまま残り続けていた。読めた設定だけを一時ファイルに書き、
# JSON として読み直してから原子的に置き換える。読んでから置き換えるまでに
# 別の処理が設定を書いていたら、上書きせずに次の起動でやり直す。
# 設定がリンクのときはリンクを残し、リンク先の実体を同じ手順で置き換える。
# 撤去の段 3 と同じ扱いにそろえた (2026-10-29 独立審査で指摘)。
# v1 はリンクそのものを普通のファイルに置き換え、お客様の管理の先から切り離していた。
# 壊れたリンクと、読んでから置き換えるまでに行き先が変わったリンクには書かずに止める。
def sl_safe_settings_write(path, data, before):
    import json as _json, os as _os, stat as _stat
    target = _os.path.realpath(path)
    folder = _os.path.dirname(target) or "."
    tmp = _os.path.join(folder, "." + _os.path.basename(target) + ".sl-new.%d" % _os.getpid())
    flags = _os.O_WRONLY | _os.O_CREAT | _os.O_EXCL | getattr(_os, "O_NOFOLLOW", 0)
    try:
        fd = _os.open(tmp, flags, 0o600 if before is not None else 0o666)
    except OSError:
        return False
    try:
        with _os.fdopen(fd, "w", encoding="utf-8") as handle:
            if before is not None:
                try:
                    _os.fchmod(handle.fileno(), _stat.S_IMODE(before.st_mode))
                except (AttributeError, OSError):
                    pass
            _json.dump(data, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            _os.fsync(handle.fileno())
        with open(tmp, encoding="utf-8") as handle:
            if not isinstance(_json.load(handle), dict):
                return False
        if _os.path.realpath(path) != target:
            return False
        if before is not None:
            now = _os.stat(path)
            if (now.st_ino, now.st_size, now.st_mtime_ns) != (before.st_ino, before.st_size, before.st_mtime_ns):
                return False
        elif _os.path.lexists(path):
            return False
        _os.replace(tmp, target)
        return True
    except Exception:
        return False
    finally:
        if _os.path.lexists(tmp) and not _os.path.islink(tmp):
            try:
                _os.unlink(tmp)
            except OSError:
                pass
# <<< sl-safe-settings-write v2 <<<

cfg_path = sys.argv[1]
bin_path = os.environ['SOLOPTILINK_BIN']

# 読めない・想定外の形の設定は作り直さない (ほかの連携の登録を消してしまうため)。1 バイトも書き換えずに止まる
before = None
cfg = {}
if os.path.exists(cfg_path):
    try:
        before = os.stat(cfg_path)
        with open(cfg_path, encoding='utf-8') as f:
            raw = f.read()
        if raw.strip():
            cfg = json.loads(raw)
    except Exception:
        sys.exit(3)
if not isinstance(cfg, dict):
    sys.exit(3)
servers = cfg.get('mcpServers')
if servers is None:
    servers = cfg['mcpServers'] = {}
if not isinstance(servers, dict):
    sys.exit(3)
servers['soloptilink'] = {
    'command': bin_path,
    'args': ['--mcp-server']
}
if not sl_safe_settings_write(cfg_path, cfg, before):
    sys.exit(4)
print(f"  ✅ 登録完了")
print(f"     mcpServers.soloptilink.command = {bin_path}")
print(f"     mcpServers.soloptilink.args    = [\"--mcp-server\"]")
PYEOF
if [ "$_mcp_rc" -ne 0 ]; then
    if [ "$_mcp_rc" -eq 3 ]; then
        echo "  ⚠️  Claude Desktop の設定ファイルを読み取れないため、登録を見送りました。"
        echo "     ★お客様の設定は一切書き換えていません。"
        echo "     次にしていただくこと: 設定ファイルの書式をご確認いただくか、この画面を添えて nomura.y@soloptilink.com までご連絡ください。"
    else
        echo "  ⚠️  Claude Desktop の設定を書き換えられなかったため、登録を見送りました (設定は元のままです)。"
        echo "     次にしていただくこと: Claude Desktop を完全に終了 (⌘+Q) してから、このファイルをもう一度ダブルクリックしてください。"
    fi
    echo "[Enterキーで閉じます]"
    read -r _ || true
    exit 1
fi

cat <<'DONE'

  ╔════════════════════════════════════════════════════════════════╗
  ║      ✅ Claude Desktop MCP 登録 完了                          ║
  ╚════════════════════════════════════════════════════════════════╝

  次のステップ:

    1. Claude Desktop を一度完全終了 (⌘+Q)
    2. Claude Desktop を再起動
    3. チャット欄で /soloptilink-boost が使えるようになります

  サポート: nomura.y@soloptilink.com

DONE

echo "[Enterキーで閉じます]"
read -r _
exit 0
