﻿# =============================================================================
# SoloptiLinkAI v2034.5 - Claude Desktop MCP 自動登録 (Windows)
# =============================================================================
# soloptilink-install.ps1 完了後にこれを実行することで、
# %APPDATA%\Claude\claude_desktop_config.json に soloptilink を MCP サーバーとして
# 自動登録します。既存設定を保持しつつマージするので、他の MCP サーバー設定は
# 失われません。
# =============================================================================

[CmdletBinding()]
param(
    [string]$InstallDir = "$HOME\.soloptilink"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

function Write-Step($msg) { Write-Host "[STEP] $msg" -ForegroundColor Cyan }
function Write-Ok($msg)   { Write-Host "[ OK ] $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Write-Err($msg)  { Write-Host "[FAIL] $msg" -ForegroundColor Red }

# ★修正F (2026-09-03): オブジェクトに指定の項目があるかを安全に調べる。
#   Set-StrictMode -Version Latest の下では、要素が 0 件のコレクションから
#   名前をまとめて取り出すと「このオブジェクトにプロパティ 'Name' が
#   見つかりません」で停止する。設定ファイルがまだ無い端末では必ず 0 件に
#   なるため、この復旧用スクリプトも同じ場所で必ず失敗していた。
#   (soloptilink-install.ps1 の STEP 9 と同一の欠陥。実機で確認済み)
function Test-HasProperty($obj, $name) {
    if ($null -eq $obj) { return $false }
    foreach ($p in $obj.PSObject.Properties) {
        if ($p.Name -eq $name) { return $true }
    }
    return $false
}

# >>> sl-safe-settings-write-ps v1 (2026-10-28) >>>
# お客様の設定の全文の控えは作らない (Python の sl-safe-settings-write v1 と同じ考え方の PowerShell 版)。
# 控えには環境変数や許可の設定、接続の鍵がそのまま写り、消す処理がどこにも無いまま残り続けていた。
# 読めた設定だけを一時ファイルに書き、JSON として読み直してから置き換える。
# 読んでから置き換えるまでに別の処理が設定を書いていたら、上書きせずに $false を返す。
# $Json は書く中身そのまま (改行も含めて呼ぶ側が決める)。$Before は読む前に取った
# Get-Item の結果 (設定が無かったときは $null)。置き換えは同じフォルダの中で行うため、
# Windows では置き換え先の権限 (ACL) がそのまま残る。
function Write-SlSettingsSafely {
    param([string]$Path, [string]$Json, $Before)
    $folder = Split-Path -Parent $Path
    if (-not $folder) { $folder = '.' }
    $tmp = Join-Path $folder ('.' + (Split-Path -Leaf $Path) + '.sl-new.' + $PID)
    $stream = $null
    try {
        $stream = [System.IO.File]::Open($tmp, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
    } catch {
        return $false
    }
    try {
        if ($null -ne $Before -and [System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Unix) {
            try { [System.IO.File]::SetUnixFileMode($tmp, [System.IO.File]::GetUnixFileMode($Path)) } catch { }
        }
        $bytes = (New-Object System.Text.UTF8Encoding($false)).GetBytes($Json)
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush($true)
        $stream.Dispose()
        $stream = $null
        $back = [System.IO.File]::ReadAllText($tmp, (New-Object System.Text.UTF8Encoding($false))) | ConvertFrom-Json
        if ($null -eq $back -or -not ($back -is [System.Management.Automation.PSCustomObject])) { return $false }
        if ($null -ne $Before) {
            $now = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
            if ($now.Length -ne $Before.Length -or $now.LastWriteTimeUtc.Ticks -ne $Before.LastWriteTimeUtc.Ticks) { return $false }
            [System.IO.File]::Replace($tmp, $Path, [NullString]::Value)
        } else {
            if (Test-Path -LiteralPath $Path) { return $false }
            [System.IO.File]::Move($tmp, $Path)
        }
        return $true
    } catch {
        return $false
    } finally {
        if ($null -ne $stream) { try { $stream.Dispose() } catch { } }
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
    }
}
# <<< sl-safe-settings-write-ps v1 <<<

# >>> sl-desktop-mcp-entry-ps v1 (2026-10-28) >>>
# Claude Desktop の設定 (claude_desktop_config.json) へ当社の連携 (mcpServers.soloptilink) を足す。
# 全文の控えは作らない (控えには他社の接続先の鍵などがそのまま写り、消されずに残り続けていた)。
# 読めない・想定外の形の設定は 1 バイトも書き換えない (以前は空とみなして当社の登録だけで上書きし、
# ほかの連携の登録を消していた)。置き換えは Write-SlSettingsSafely で読み直して確かめてから行う。
# 戻り値: 'ok' = 登録した / 'unreadable' = 読めない・想定外の形のため書き換えていない / 'failed' = 置き換えられなかった
function Set-SlDesktopMcpEntry {
    param([string]$Path, $Entry)
    $before = $null
    $cfg = $null
    if (Test-Path -LiteralPath $Path) {
        try {
            $before = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
            $raw = [System.IO.File]::ReadAllText($Path, (New-Object System.Text.UTF8Encoding($false)))
            if (-not [string]::IsNullOrWhiteSpace($raw)) { $cfg = $raw | ConvertFrom-Json -ErrorAction Stop }
        } catch {
            return 'unreadable'
        }
        if ($null -ne $cfg -and -not ($cfg -is [System.Management.Automation.PSCustomObject])) { return 'unreadable' }
    }
    if ($null -eq $cfg) { $cfg = [PSCustomObject]@{} }
    $hasServers = $false
    foreach ($p in $cfg.PSObject.Properties) { if ($p.Name -eq 'mcpServers') { $hasServers = $true } }
    if (-not $hasServers) {
        $cfg | Add-Member -MemberType NoteProperty -Name 'mcpServers' -Value ([PSCustomObject]@{})
    } elseif ($null -eq $cfg.mcpServers) {
        $cfg.mcpServers = [PSCustomObject]@{}
    } elseif (-not ($cfg.mcpServers -is [System.Management.Automation.PSCustomObject])) {
        return 'unreadable'
    }
    $hasMine = $false
    foreach ($p in $cfg.mcpServers.PSObject.Properties) { if ($p.Name -eq 'soloptilink') { $hasMine = $true } }
    if ($hasMine) { $cfg.mcpServers.soloptilink = $Entry }
    else { $cfg.mcpServers | Add-Member -MemberType NoteProperty -Name 'soloptilink' -Value $Entry }
    $json = (ConvertTo-Json -InputObject $cfg -Depth 20) + "`n"
    if (Write-SlSettingsSafely -Path $Path -Json $json -Before $before) { return 'ok' }
    return 'failed'
}
# <<< sl-desktop-mcp-entry-ps v1 <<<

function End-Pause {
    Write-Host ""
    Write-Host "==============================================================="
    Write-Host " 完了しました。何かキーを押すとウィンドウを閉じます。"
    Write-Host "==============================================================="
    if ($Host.Name -eq "ConsoleHost") {
        [void][System.Console]::ReadKey($true)
    }
}

trap {
    Write-Err "エラーが発生しました: $($_.Exception.Message)"
    End-Pause
    exit 1
}

Write-Host ""
Write-Host "================================================================="
Write-Host " SoloptiLinkAI v2034.5  Claude Desktop MCP 自動登録"
Write-Host "================================================================="
Write-Host ""

# -----------------------------------------------------------------------------
# STEP 1: SoloptiLinkAI Goランチャー検出
# -----------------------------------------------------------------------------
Write-Step "1/4 Goランチャー検出"

$launcher = Join-Path $InstallDir "soloptilink.exe"
if (-not (Test-Path $launcher)) {
    Write-Err "  $launcher が見つかりません。"
    Write-Host "  先に soloptilink-install.ps1 (or .bat) を実行してください。"
    End-Pause; exit 1
}
Write-Ok "  $launcher 検出"

# -----------------------------------------------------------------------------
# STEP 2: claude_desktop_config.json の場所確認
# -----------------------------------------------------------------------------
Write-Step "2/4 Claude Desktop 設定ファイル"

$cfgDir = Join-Path $env:APPDATA "Claude"
$cfgPath = Join-Path $cfgDir "claude_desktop_config.json"

if (-not (Test-Path $cfgDir)) {
    Write-Warn "  Claude Desktop 設定ディレクトリがありません。"
    Write-Host "  先に Claude Desktop (https://claude.ai/download) をインストールしてください。"
    Write-Host "  続行しますか? (Y/n)"
    $ans = Read-Host
    if ($ans -ne "Y" -and $ans -ne "y" -and $ans -ne "") {
        End-Pause; exit 0
    }
    New-Item -ItemType Directory -Path $cfgDir | Out-Null
}
Write-Ok "  設定ディレクトリ: $cfgDir"

# -----------------------------------------------------------------------------
# STEP 3: 既存設定の確認
# ★2026-10-28: 既存の設定の全文の控え (claude_desktop_config.json.bak.<日時>) は作らない。
#   控えには他社の接続先の鍵などがそのまま写り、消す処理がどこにも無いまま残り続けていた。
#   また、読めない設定を空とみなして当社の登録だけで上書きしていた (ほかの連携の登録が消える)。
# -----------------------------------------------------------------------------
Write-Step "3/4 既存設定の確認"

if (Test-Path $cfgPath) {
    Write-Ok "  既存の設定があります (ほかの連携の登録はそのまま残します)"
} else {
    Write-Ok "  既存設定なし (新規作成)"
}

# -----------------------------------------------------------------------------
# STEP 4: mcpServers.soloptilink を追加 (既存 mcpServers は保持)
# -----------------------------------------------------------------------------
Write-Step "4/4 soloptilink MCP サーバーを登録"

$entry = [PSCustomObject]@{
    command = $launcher.Replace("\", "/")
    args    = @("--mcp-server")
}
$mcpState = Set-SlDesktopMcpEntry -Path $cfgPath -Entry $entry
if ($mcpState -eq 'unreadable') {
    Write-Err "  Claude Desktop の設定ファイルを読み取れないため、登録を見送りました。"
    Write-Host "  お客様の設定は一切書き換えていません。"
    Write-Host "  次にしていただくこと: 設定ファイルの書式をご確認いただくか、この画面を添えて nomura.y@soloptilink.com までご連絡ください。"
    End-Pause; exit 1
} elseif ($mcpState -ne 'ok') {
    Write-Err "  Claude Desktop の設定を書き換えられなかったため、登録を見送りました (設定は元のままです)。"
    Write-Host "  次にしていただくこと: Claude Desktop を完全に終了してから、もう一度実行してください。"
    End-Pause; exit 1
}

Write-Ok "  登録完了"
Write-Host ""
Write-Host "  登録内容:"
Write-Host "    mcpServers.soloptilink.command = $launcher"
Write-Host "    mcpServers.soloptilink.args    = [`"--mcp-server`"]"
Write-Host ""
Write-Host "================================================================="
Write-Host " 完了"
Write-Host "================================================================="
Write-Host ""
Write-Host " 次のステップ:"
Write-Host "   1. Claude Desktop を一度終了 (タスクトレイから完全終了)"
Write-Host "   2. Claude Desktop を再起動"
Write-Host "   3. チャット欄で /soloptilink-boost が使えるようになります"
Write-Host ""
Write-Host " トラブルシュート:"
Write-Host "   - MCP が見えない場合は Claude Desktop のログを確認"
Write-Host "     %APPDATA%\Claude\logs\"
Write-Host "   - サポート: nomura.y@soloptilink.com"
Write-Host ""

End-Pause
exit 0
