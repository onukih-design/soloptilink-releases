#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI — Mac ダブルクリック起動インストーラ (.command)
# =============================================================================
# 顧客は Finder からこのファイルをダブルクリックするだけで:
#   1. Terminal.app が自動起動
#   2. 同梱パッケージ本体を ~/.soloptilink へ配置 (自己完結ZIP)
#      ※ 本体が無い場合のみ tar.gz / ネットワークから自動取得
#   3. アーキ(arm64/Intel)に合った Go ランチャーを配置
#   4. Claude Desktop の MCP サーバー設定を自動登録
#   5. 端末認証 (--activate) を自動チェーン
#   6. 完了画面まで自動誘導
#
# 配布レイアウト対応:
#   現行の per-platform ZIP (SoloptiLinkAI_vX.Y_Mac-*.zip) は
#   「展開済みパッケージ本体 + soloptilink バイナリ + この .command」が
#   同一フォルダに並ぶ自己完結キット。本スクリプトはそのレイアウトを
#   第一に検出して動作する (旧 .command は tar.gz 同梱前提で現行ZIPでは
#   動かなかった)。tar.gz 同梱キット / ネットワーク取得にもフォールバックする。
#
# Compliance:
#   - PFP-029 (cmd 窓即閉じ事案) 同等の堅牢設計: STEP マーカー / END_PAUSE 必須
#   - PFP-044 (AppleDouble 事案) AppleDouble セルフクリーンアップ
#   - PFP-101 (0 バイト取得事案) ネットワーク取得は -L で 302 追従 / updates/check 経由
#   - macOS Gatekeeper 対応: xattr -d com.apple.quarantine で隔離属性除去
# =============================================================================
set -e
# 失敗時に Terminal を即閉じさせない (お客様が次の一手を読めるように)
# ★従来はここで行番号・終了コード・失敗したコマンド文字列を
#   そのまま画面に出していた。お客様には意味が伝わらず、何をすればよいかも
#   分からない行き止まりになっていた (顧客可視出力の方針にも反する)。
#   画面には「起きたこと」と「次にすること」だけを日本語で出し、
#   調査に要る技術的な内容は控えのファイルへ回す。
#   ★どの工程で止まったかを必ず伝える (2026-08-15 追加)
#     従来この画面は「予期しない問題が発生しました」としか言えなかった。工程名は
#     画面に【表示】されるだけで、どこまで進んだかを【保持する変数がどこにも無かった】ため、
#     異常終了時に工程を名指しできなかった。お客様は自分がどこで止まったのか分からず、
#     次の一手も分からないまま放置される (過去の導入失敗では、お客様が
#     自力で回避策を探すことになった)。工程名と「その工程で次にすること」を保持し、
#     この画面で必ず日本語で伝える。
trap '_EC=$?; _CMD="$BASH_COMMAND"; _LN=$LINENO; _LOGD="$HOME/.soloptilink/logs"; mkdir -p "$_LOGD" 2>/dev/null || _LOGD="${TMPDIR:-/tmp}"; printf "%s installer-failure phase=%s line=%s exit=%s cmd=%s\n" "$(date +%Y-%m-%dT%H:%M:%S)" "${SETUP_PHASE:-準備中}" "$_LN" "$_EC" "$_CMD" >> "$_LOGD/setup-error.log" 2>/dev/null || true; _RPT="$HOME/.soloptilink/lib/cognitive/customer-error-reporter.sh"; [ -f "$_RPT" ] && bash "$_RPT" "installer-failure" "Mac .command セットアップ失敗 phase=${SETUP_PHASE:-準備中} line=$_LN exit=$_EC cmd=$_CMD" 2>/dev/null; echo ""; echo "==============================================================="; echo " ⚠️  予期しない問題が発生しました"; echo ""; echo "     セットアップを最後まで進められませんでした。"; echo ""; echo "     止まったところ: ${SETUP_PHASE:-準備中}"; echo ""; echo "     次にしていただくこと:"; echo "       ${SETUP_PHASE_NEXT:-このファイルをもう一度ダブルクリックして、はじめからやり直してください。}"; echo ""; echo "     それでも同じところで止まる場合は、この画面の写真を撮って、"; echo "     nomura.y@soloptilink.com までお送りください。"; echo "     こちらで原因をお調べして、ご連絡いたします。"; echo ""; echo "     お急ぎの場合も、まずはこの画面の写真をお送りください。"; echo "==============================================================="; echo "[Enterキーで閉じます]"; read -r _ || true; exit 1' ERR

# ── いま実行中の工程 (異常終了画面が「どこで止まったか」を言えるようにするための状態) ──
#   ★表示だけでは足りない。表示は流れて消えるが、この変数は失敗の瞬間まで残る。
#   無効化スイッチは設けない (状態を持つだけで挙動を変えないため)。
SETUP_PHASE="準備中"
SETUP_PHASE_NEXT="このファイルをもう一度ダブルクリックして、はじめからやり直してください。"
set_phase() { SETUP_PHASE="$1"; SETUP_PHASE_NEXT="$2"; }

clear 2>/dev/null || true
KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
TS=$(date +%Y%m%d_%H%M%S)
API_BASE="https://admin-dashboard-blue-alpha-78.vercel.app/api/v1"

# >>> SETUP-PACKAGE-VERIFY (2026-10-10) >>>
# 【何が起きていたか】ネット経由で本体を受け取る経路 (下のモードC) だけが、受け取った本体を
#   一切確かめずに展開していた。自動更新と回収は「配信元が示す照合値との一致」と
#   「当社の鍵の署名」の両方を確かめてから適用しており、新規導入の入口だけが丸腰だった。
# 【どう確かめるか】自動更新・回収と同じ値 (package_sha256・package_signature) と同じ公開鍵で確かめる。
#   ・照合値が示されていて、一致しない → 中止 (破損・差し替えの疑い)
#   ・署名が示されていて、当社の鍵 (主・移行用のどちらか) で合わない → 中止
#   ・配信元が値を示していない / 確かめる道具 (shasum・openssl) が無い → 従来どおり進める
#     (新規導入を止めない。確かめられなかったことは画面に一言出す)
# 公開鍵は公開してよい情報 (launcher/encrypted/public_key.pem・public_key_transition.pem と同じ。
#   食い違いは installer/lib/setup-package-verify-selftest.sh が検出する)。
_SETUP_PUBKEY_PEM='-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEArmC7SmViTmMrqcjybuZO
ps1np3QJpL8gmTUFDgA5dHEcMxewaHdMYnDWcjyg6BIX5+ATPV8BOkZjdAFIzKI0
8ooTjvZCUYRSBcAEtc5WMEjVcxCM/sfbAW1Us1HXdJ7WDT5dtTJMQzWF9cNRV/FP
vJ9IughiNxZeA7bH1En9cZUD9L0Ugqgr2sTg6a7COi6gS79he/UljzE0YzbOSuml
hLSFVI/H6zoT9LIKYfRo5EXPEZMi02dfFoy0WuaIUVGaEKtuaLkHmkRGK4Od0Ays
kSHWuHej4qlRMjJKXioxUkrEE+TzonSo5r9oKu8U62+y4SyWaM3qcI1DB6vffcR+
RH18wg+3DwgyS1jAKN8Mq1NRXrfOWI4nv3MfZZFbfJXiFIbjUyPOQVUdUa43jjz8
cS9Z4P0JVzFvUYgeoOPLXiv72VPACWXDpGApcITWhvz/fOh5IXsnHm+R/GL1z5Ja
DaESQT/WGJYOGMlO0Kd1dLA4LxSsBXchoWbCYRXdjD54I4zZi7GRmj5I6QClz3ZF
uQcMj14iDHKMkHB820vQdQx/87NdyAOxEuWKQLnRCtItEDGUlFFe3jJaqQROnNOS
w1IAOEfb2HMZUOy6kpktglQt6bvGz9+RXK1cyG/ttwZh7XRIRYFcGH9TAnmGwkyt
dg+14GO/gMoJUJ9DKuHlZdECAwEAAQ==
-----END PUBLIC KEY-----'
_SETUP_PUBKEY_TRANSITION_PEM='-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAjHDKXqwd/9CUR+EbfFB/
LaV8DCezlT8HO8DVNeO7JXJy8lt87Nrb+F2gxoiBsk3LtanZfOOnvANoj4+ImUWn
+AW5lIhKRJDoT/zMT61n/1aJ8c3I4cms5NfSw3FUzt3g0QLBmfz9Iau9vUAwneVA
fUSgmMmYF4ot88mm7DccmbPBa5/Mr3fvKtKzZTa2Onpgylz8YRkg+xurnYNqDG1F
8HjVmvJDg5kvrCf5WC87k0Isq8azbroJqr0AktryRAxhT68deuAFCqvoqgNlV57v
7UFqVayUFLxHS3RWdF65OStznKL+UKKz3PzFBT9EFfCJ7RBxfXj+M1oHRsYiU2V1
IJOeWFLbD6QJqhFqLuLkjBtV6aq/FoG+K0LVnBj6Y5t+GsZNFActIbDLcMnPaqwg
9DdQralUhRJREwScNMnPUTUVOlRAq1/gRcEh7KJD9RVaty//NV0gj1JXHOmVaxgq
w2Fj0FD4XVIFPkdN2pg/clA8mtMDc3zGEO5RA+5bmysS3eBQqf9jPZcAyYTFDN0k
06MVrwzwgRtVnUwdeihFiWHKqSLfh9JV/l2s2YgS0YeLhhR0ZmuiA+mSsxaI9B0R
WtZLsjTtPRMQauLE4sEj/qrcnHMVaR09pYNAowTfTIsbIFflRp90xcmGSHw30Kf+
1lgiw4b3tPcMVfS4nfHXQkcCAwEAAQ==
-----END PUBLIC KEY-----'
_setup_json_field() {
    # $1=JSON文字列 $2=キー。素の macOS では python3 が動かないことがあるため sed を先に使う。
    local v
    v="$(printf '%s' "$1" | sed -n "s/.*\"$2\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p" | head -1)"
    if [ -z "$v" ] && command -v python3 >/dev/null 2>&1 && python3 --version >/dev/null 2>&1; then
        v="$(printf '%s' "$1" | SJF_KEY="$2" python3 -c "import json,os,sys; d=json.load(sys.stdin); print(d.get(os.environ['SJF_KEY']) or '')" 2>/dev/null || true)"
    fi
    printf '%s' "$v"
}
_setup_sha256() {
    if command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" 2>/dev/null | cut -d' ' -f1
    elif command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" 2>/dev/null | cut -d' ' -f1
    fi
}
# _setup_verify_package <ファイル> <照合値> <署名(base64)>  0=進めてよい / 1=中止
_setup_verify_package() {
    local f="$1" want got sig="$3" sigf keyf
    want="$(printf '%s' "$2" | tr 'A-Z' 'a-z')"
    if [ -n "$want" ]; then
        got="$(_setup_sha256 "$f" | tr 'A-Z' 'a-z')"
        if [ -z "$got" ]; then
            echo "  (この端末では照合の道具が使えないため、受け取った本体の照合を省きます)"
        elif [ "$got" != "$want" ]; then
            return 1
        else
            echo "  ✅ 受け取った本体が配信元の示す本体と一致しました"
        fi
    fi
    [ -n "$sig" ] || return 0
    if ! command -v openssl >/dev/null 2>&1; then
        echo "  (この端末では署名を確かめる道具が使えないため、照合値の一致だけで進めます)"; return 0
    fi
    sigf="$(mktemp "${TMPDIR:-/tmp}/sl-setupsig.XXXXXX" 2>/dev/null)" || return 0
    keyf="$(mktemp "${TMPDIR:-/tmp}/sl-setupkey.XXXXXX" 2>/dev/null)" || { rm -f "$sigf"; return 0; }
    printf '%s' "$sig" | tr -d ' \t\n\r' | base64 -d > "$sigf" 2>/dev/null || true
    if [ ! -s "$sigf" ]; then rm -f "$sigf" "$keyf"; return 1; fi
    printf '%s\n' "$_SETUP_PUBKEY_PEM" > "$keyf"
    if openssl dgst -sha256 -verify "$keyf" -signature "$sigf" "$f" >/dev/null 2>&1; then
        rm -f "$sigf" "$keyf"; echo "  ✅ 受け取った本体に当社の署名があることを確認しました"; return 0
    fi
    printf '%s\n' "$_SETUP_PUBKEY_TRANSITION_PEM" > "$keyf"
    if openssl dgst -sha256 -verify "$keyf" -signature "$sigf" "$f" >/dev/null 2>&1; then
        rm -f "$sigf" "$keyf"; echo "  ✅ 受け取った本体に当社の署名があることを確認しました"; return 0
    fi
    rm -f "$sigf" "$keyf"
    return 1
}
# <<< SETUP-PACKAGE-VERIFY <<<

cat <<'BANNER'

  ╔════════════════════════════════════════════════════════════════╗
  ║         SoloptiLinkAI Setup (Mac版)                            ║
  ║         自動セットアップを開始します                          ║
  ║         (このウィンドウは自動で進みます。閉じずにお待ちください) ║
  ╚════════════════════════════════════════════════════════════════╝

BANNER

# ---------------------------------------------------------------------------
# STEP 0/6: 管理者端末の保護 (この .command は顧客用インストーラ)
# ---------------------------------------------------------------------------
if [ -f "$HOME/.soloptilink/.admin_mode" ]; then
    echo "  ⚠️  この端末は SoloptiLinkAI 管理者端末です。"
    echo "      顧客用インストーラの実行は中止しました (開発環境を保護)。"
    echo ""
    echo "[Enterキーで閉じます]"
    read -r _ || true
    exit 0
fi

# ---------------------------------------------------------------------------
# STEP 1/6: macOS Gatekeeper 隔離属性の除去 (ダウンロードファイル特有)
# ---------------------------------------------------------------------------
set_phase "受け取ったファイルの安全確認" "受け取った書庫 (ZIP) をデスクトップなど分かりやすい場所に展開し直してから、もう一度ダブルクリックしてください。"
echo "[STEP 1/6] セキュリティ属性のクリーンアップ"
find "$KIT_DIR" -name "*.command" -exec xattr -d com.apple.quarantine {} \; 2>/dev/null || true
find "$KIT_DIR" -name "*.sh" -exec xattr -d com.apple.quarantine {} \; 2>/dev/null || true
xattr -dr com.apple.quarantine "$KIT_DIR" 2>/dev/null || true
echo "  ✅ 完了"
echo ""

# ---------------------------------------------------------------------------
# STEP 2/6: AppleDouble (._*) / .DS_Store の除去 (PFP-044)
# ---------------------------------------------------------------------------
set_phase "不要ファイルの整理" "受け取った書庫 (ZIP) をもう一度展開し直してから、ダブルクリックしてください。"
echo "[STEP 2/6] macOS メタデータの除去"
find "$KIT_DIR" -name '._*' -delete 2>/dev/null || true
find "$KIT_DIR" -name '.DS_Store' -delete 2>/dev/null || true
echo "  ✅ 完了"
echo ""

# ---------------------------------------------------------------------------
# [前提ソフト] Git / Node.js / Claude Code の確認と導入 (本体配置に先立って)
#   利用に必要な前提ソフトを、SoloptiLink 本体の配置の前に自動導入する。
#   各ソフトは「先に検出し、在ればスキップ」する冪等設計 (再実行しても無害)。
#     - Claude Code : 公式ネイティブインストーラ (curl | bash) で導入 (sudo不要・背景自動更新)
#     - Node.js     : 生成される業務システムの実行・ビルド検証に必要 (Claude Code 自体は Node 不要)
#     - Git         : SoloptiLink の bash 製 lib / chain.sh の動作に必要 (macOS は通常導入済み)
#   ★失敗しても中断しない: このフェーズだけ set +e で ERR トラップを抑止し、
#     未完了は「要対応」へ集約して完了画面で案内する (Windows 版と対称)。
# ---------------------------------------------------------------------------
set_phase "このパソコンの準備状況の確認" "画面に出ている『準備がととのっていない項目』を解消してから、このファイルをもう一度ダブルクリックしてください。"
echo "[準備状況の確認] 導入をはじめる前に、このパソコンの状態をまとめて確認します"
# ★実行順の注意 (T-017a):
#   この前提ソフト工程は STEP 3 (既存環境の退避) より前に走る。Node 自動導入モジュールは
#   ③経路のとき ~/.soloptilink/runtime/node/ へ Node 本体を展開するため、
#   「既存環境の有無」をここで先に確定しておかないと、
#   【いま自動導入が作ったばかりの ~/.soloptilink】を STEP 3 が「既存環境」と誤認して
#   退避してしまい、新規導入なのに .bak が出来て Node も一緒に消える。
HAD_EXISTING_SOLOPTILINK=0
if [ -d "$HOME/.soloptilink" ]; then HAD_EXISTING_SOLOPTILINK=1; fi
PREREQ_ISSUES=()
add_issue() { PREREQ_ISSUES+=("$1|$2"); }   # "項目|対処"
set +e   # このフェーズは失敗しても中断しない
# ★実走で判明した落とし穴: set +e だけでは ERR トラップは止まらない
#   (bash では errexit と ERR トラップは別の仕組み)。この工程で外部コマンドが 1 つでも
#   非ゼロで終わると、「失敗しても中断しない」という宣言に反して異常終了画面が出る。
#   そのため、この工程の外部コマンドはすべて || で受けて ERR トラップの発火条件から外す。

# 公式ネイティブ Claude Code は ~/.local/bin に入るため、現セッション PATH へ前置き
export PATH="$HOME/.local/bin:$PATH"

# --- 前提ソフトの判定 (実行可否ベースの判定) --------------------------------
#   【この判定が必要な理由】判定が command -v (存在確認) だけで、
#     「実際に動くか」を見ていなかった。macOS は開発ツール (Command Line Tools) が
#     未導入でも /usr/bin/git ・ /usr/bin/python3 が【入口 (シム) として実在する】ため、
#     command -v は成功し、実行すると失敗する。実際の導入画面には
#       [skip] Git ()            ← 版数が空 = 存在するが動かない動かぬ証拠
#       xcode-select: No developer tools were found
#     が出ており、この状態で Node 判定まで巻き込まれて「Node.js を用意できませんでした」
#     と誤報告する経路があった。
#   【方針】存在確認だけで合格にしない。版数の取得まで実行し、期待する形の出力が
#     返ったときにだけ「使える」と判定する。Windows 側 (soloptilink-install.ps1) は
# 先に同じ規律で是正済みで、本変更は Mac 側をそれに揃えるもの。
#   【判定は 3 値】absent (入口ごと無い) / present_but_broken (入口はあるが動かない) /
#     available (実際に動く)。この 3 値を区別しないと、お客様に出す案内文が
#     「導入してください」に丸まり、既に入っているものを入れ直させることになる。
prereq_probe() {
    # $1 = コマンド名 / $2 = 版数取得の引数 / $3 = 期待する版数の形 (grep -E のパターン)
    # 標準出力: absent | present_but_broken | available
    # 標準エラー: 何も出さない (呼び出し側が表示を決める)
    # ★判定は PREREQ_VERDICT にも入れる。版数は PREREQ_VER に入れる。
    #   【なぜ両方が要るか / 2026-08-15 実測で判明した表示の欠陥】
    #   呼び出し側が case "$(prereq_probe ...)" と書くと、判定は取れるが
    #   関数の中で入れた版数は【別のシェルの中で消える】ため親には届かない。
    #   その結果、正常に動く Git でも画面には「[skip] Git ()」と出て、
    #   版数が空 = 壊れている端末の見分けがつかなくなっていた (実走で再現済み)。
    #   標準出力の答え方は変えない (既存の検査がこの形を見ている) ので、
    #   受け取り口だけを増やし、呼び出し側はこちらを読む。
    local _cmd="$1" _verarg="$2" _pat="$3" _out=""
    PREREQ_VERDICT=""
    command -v "$_cmd" >/dev/null 2>&1 || { PREREQ_VERDICT="absent"; printf 'absent'; return 0; }
    _out="$("$_cmd" "$_verarg" 2>/dev/null | head -1 | tr -d '\r')" || _out=""
    if [ -z "$_out" ]; then PREREQ_VERDICT="present_but_broken"; printf 'present_but_broken'; return 0; fi
    if printf '%s' "$_out" | grep -Eq "$_pat"; then
        PREREQ_VER="$_out"; PREREQ_VERDICT="available"; printf 'available'; return 0
    fi
    PREREQ_VERDICT="present_but_broken"; printf 'present_but_broken'; return 0
}
PREREQ_VERDICT=""
# 開発ツール未導入は Git / Python 3 に同時に効くため、案内は 1 回だけ出す
DEVTOOLS_PROMPTED=0
prompt_devtools() {
    [ "$DEVTOOLS_PROMPTED" = "1" ] && return 0
    DEVTOOLS_PROMPTED=1
    xcode-select --install >/dev/null 2>&1 || true
}
DEVTOOLS_ISSUE="画面に表示される『コマンドラインデベロッパツール』の導入を完了してください (Git と Python 3 が含まれます)。導入が終わったら、この .command をもう一度ダブルクリックしてください。導入は途中まで完了しています"

# >>> PREFLIGHT-LIB-BEGIN (この範囲は両側検証が切り出して単体で実行する。境界を消さないこと) >>>
# ---------------------------------------------------------------------------
# 準備状況の一括診断 (2026-08-15 新設)
#
# 【なぜ要るか】導入が途中まで進んでから失敗し、お客様は
#   「どこまで進んだのか」「何をすればよいのか」が分からない状態に置かれた。
#   足りないものがあるなら、作業を始める前に【まとめて一度に】お伝えするべきである。
#
# 【設計】
#   ・判定器は作らない。既にある 3 値判定 (prereq_probe) をそのまま呼ぶ。
#     ここで新しく足すのは、どのインストーラにも無かった 3 つだけ:
#       空き容量 / インターネット接続 / 基本ソフト (macOS) の版
#   ・全部そろっているときは一覧を出さない (毎回長い一覧が出るのは邪魔になる)。
#   ・足りないときは【自動導入を始める前に】1 画面で示し、続けるか中断するかを尋ねる。
#   ・確認できなかった項目は「問題なし」に丸めない。確認できなかったと出す。
#     ("確認できないので通す" は禁止。素通りの分岐には入れない)
#
# 無効化: SOLOPTILINK_PREFLIGHT=off (無効化した事実を控えのファイルに残して通過する)
# 調整  : SOLOPTILINK_MIN_FREE_MB (既定 2048) / SOLOPTILINK_MIN_MACOS (既定 12)
#         SOLOPTILINK_PREFLIGHT_NET_TIMEOUT (既定 6 秒) / SOLOPTILINK_PREFLIGHT_WAIT (既定 120 秒)
# ---------------------------------------------------------------------------
PREFLIGHT_ROWS=()
PREFLIGHT_NEED=0      # お客様の操作が要る項目
PREFLIGHT_AUTO=0      # このあと自動で用意する項目 (お客様の操作は不要)
PREFLIGHT_UNKNOWN=0   # 確認できなかった項目 (合格に数えない)
PREFLIGHT_OSVER=""
PREFLIGHT_MIN_FREE_MB="${SOLOPTILINK_MIN_FREE_MB:-2048}"
PREFLIGHT_MIN_MACOS="${SOLOPTILINK_MIN_MACOS:-12}"
# 空き容量の下限の根拠: 本体の展開分に加え、Node.js のランタイム (約 100MB) と、
# これから作る業務システムの部品置き場 (1 件あたり数百 MB) を見込んだ最低限。
PREFLIGHT_DEVTOOLS="Apple の『コマンドラインデベロッパツール』の導入が必要です (Git と Python 3 が含まれます)。このあと Apple の確認画面をお出ししますので、[インストール] を押して、終わるまでお待ちください"

_pf_row() {
    # $1=項目名 $2=判定(ok|auto|need|unknown) $3=お客様への案内 $4=完了画面へ持ち越すか(yes|no)
    # 案内文に縦棒は使わない (項目の区切りに使っているため)
    PREFLIGHT_ROWS+=("$1|$2|$3|${4:-no}")
    case "$2" in
        need)    PREFLIGHT_NEED=$((PREFLIGHT_NEED+1)) ;;
        auto)    PREFLIGHT_AUTO=$((PREFLIGHT_AUTO+1)) ;;
        unknown) PREFLIGHT_UNKNOWN=$((PREFLIGHT_UNKNOWN+1)) ;;
    esac
}

# 空き容量 (MB)。取れなければ空文字を返す (呼び出し側で「確認できなかった」にする)
_pf_free_mb() {
    local _kb=""
    _kb="$(df -Pk "$HOME" 2>/dev/null | awk 'NR==2 {print $4}' 2>/dev/null)" || _kb=""
    case "${_kb:-x}" in ''|*[!0-9]*) printf ''; return 0 ;; esac
    printf '%s' $(( _kb / 1024 ))
}

# 接続確認。0=つながる / 1=つながらない / 2=確かめる手段が無い
#   応答の中身は見ない。何らかの応答が返ること自体が「そこへ届いた」証拠になる。
_pf_net() {
    command -v curl >/dev/null 2>&1 || return 2
    local _code=""
    _code="$(curl -sS -o /dev/null -w '%{http_code}' \
        --max-time "${SOLOPTILINK_PREFLIGHT_NET_TIMEOUT:-6}" "$1" 2>/dev/null)" || _code="000"
    case "${_code:-000}" in
        ''|000) return 1 ;;
        *)      return 0 ;;
    esac
}

# 基本ソフトの版。0=対応範囲 / 1=古すぎる / 2=確かめられない
_pf_macos() {
    PREFLIGHT_OSVER=""
    command -v sw_vers >/dev/null 2>&1 || return 2
    PREFLIGHT_OSVER="$(sw_vers -productVersion 2>/dev/null | head -1 | tr -d '\r')" || PREFLIGHT_OSVER=""
    [ -n "$PREFLIGHT_OSVER" ] || return 2
    local _maj="${PREFLIGHT_OSVER%%.*}"
    case "${_maj:-x}" in ''|*[!0-9]*) return 2 ;; esac
    [ "$_maj" -ge "$PREFLIGHT_MIN_MACOS" ] 2>/dev/null && return 0
    return 1
}

preflight_collect() {
    local _rc=0 _free="" _net_admin=0 _net_claude=0 _major=""
    PREFLIGHT_ROWS=(); PREFLIGHT_NEED=0; PREFLIGHT_AUTO=0; PREFLIGHT_UNKNOWN=0

    # ① パソコンの基本ソフト
    _pf_macos; _rc=$?
    case "$_rc" in
        0) _pf_row "パソコンの基本ソフト" ok "macOS ${PREFLIGHT_OSVER} — 対応しています" no ;;
        1) _pf_row "パソコンの基本ソフト" need "この Mac の macOS ${PREFLIGHT_OSVER} は、当社が動作を確認している範囲より古いものです。macOS ${PREFLIGHT_MIN_MACOS} 以降へ更新していただくか、nomura.y@soloptilink.com までご相談ください" yes ;;
        *) _pf_row "パソコンの基本ソフト" unknown "基本ソフトの版を確認できませんでした (確認できなかっただけで、問題があると判断したわけではありません)" yes ;;
    esac

    # ② 空き容量
    _free="$(_pf_free_mb)"
    if [ -z "$_free" ]; then
        _pf_row "ディスクの空き容量" unknown "空き容量を確認できませんでした (確認できなかっただけで、足りないと判断したわけではありません)" yes
    elif [ "$_free" -lt "$PREFLIGHT_MIN_FREE_MB" ] 2>/dev/null; then
        _pf_row "ディスクの空き容量" need "空きが ${_free} MB しかありません。導入と、これから作る業務システムのために ${PREFLIGHT_MIN_FREE_MB} MB 以上の空きをご用意ください (使っていないファイルをゴミ箱へ移し、ゴミ箱を空にすると増えます)" yes
    else
        _pf_row "ディスクの空き容量" ok "${_free} MB の空きがあります" no
    fi

    # ③ インターネット接続 (本体の受け取り先と、前提ソフトの配布元)
    _pf_net "https://admin-dashboard-blue-alpha-78.vercel.app/"; _net_admin=$?
    _pf_net "https://claude.ai/"; _net_claude=$?
    if [ "$_net_admin" -eq 2 ] || [ "$_net_claude" -eq 2 ]; then
        _pf_row "インターネット接続" unknown "接続を確認する手段がこのパソコンにありませんでした (確認できなかっただけで、つながっていないと判断したわけではありません)" yes
    elif [ "$_net_admin" -eq 0 ] && [ "$_net_claude" -eq 0 ]; then
        _pf_row "インターネット接続" ok "必要な接続先につながります" no
    else
        _pf_row "インターネット接続" need "必要な接続先につながりませんでした。Wi-Fi や有線の接続をご確認ください。社内のネットワーク制限 (プロキシ / VPN) が原因のこともありますので、その場合はネットワーク管理者に接続の許可をご依頼ください" yes
    fi

    # ④ Git (既存の 3 値判定をそのまま使う)
    PREREQ_VER=""
    prereq_probe git --version 'git version [0-9]' >/dev/null
    case "$PREREQ_VERDICT" in
        available) _pf_row "Git" ok "使えます (${PREREQ_VER})" no ;;
        *)         _pf_row "Git" need "$PREFLIGHT_DEVTOOLS" no ;;
    esac

    # ⑤ Python 3 (同じ開発ツールに含まれる)
    PREREQ_VER=""
    prereq_probe python3 --version 'Python 3\.' >/dev/null
    case "$PREREQ_VERDICT" in
        available) _pf_row "Python 3" ok "使えます (${PREREQ_VER})" no ;;
        *)         _pf_row "Python 3" need "$PREFLIGHT_DEVTOOLS" no ;;
    esac

    # ⑥ Node.js (無ければ当社側で自動的に用意するため、お客様の操作は要らない)
    PREREQ_VER=""
    prereq_probe node -v 'v[0-9]' >/dev/null
    if [ "$PREREQ_VERDICT" = "available" ]; then
        _major="${PREREQ_VER#v}"; _major="${_major%%.*}"
        case "${_major:-x}" in
            ''|*[!0-9]*)
                _pf_row "Node.js" unknown "入っていますが版を読み取れませんでした (${PREREQ_VER})" no ;;
            *)
                if [ "$_major" -ge 18 ] 2>/dev/null; then
                    _pf_row "Node.js" ok "使えます (${PREREQ_VER})" no
                else
                    _pf_row "Node.js" auto "入っている ${PREREQ_VER} は古いため、このあと新しいものを用意します (お客様の操作は不要です)" no
                fi ;;
        esac
    else
        _pf_row "Node.js" auto "このあと自動で用意します (お客様の操作は不要です)" no
    fi

    # ⑦ Claude Code (無ければ当社側で自動的に用意する)
    PREREQ_VER=""
    prereq_probe claude --version '[0-9]' >/dev/null
    case "$PREREQ_VERDICT" in
        available) _pf_row "Claude Code" ok "使えます (${PREREQ_VER})" no ;;
        *)         _pf_row "Claude Code" auto "このあと自動で用意します (お客様の操作は不要です)" no ;;
    esac
}

# 一覧を出すか、出さずに素通りするかを決めて表示する。
#   戻り値 0 = このまま導入へ進む / 1 = お客様が「中断する」を選んだ
preflight_present() {
    local _row="" _name="" _verdict="" _msg="" _rest="" _ans=""
    if [ "$PREFLIGHT_NEED" -eq 0 ] && [ "$PREFLIGHT_AUTO" -eq 0 ] && [ "$PREFLIGHT_UNKNOWN" -eq 0 ]; then
        # ★全部そろっているときは一覧を出さない (毎回の長い一覧はかえって読まれなくなる)
        echo "  ✅ 準備はととのっています (${#PREFLIGHT_ROWS[@]} 項目すべて確認しました)。このまま導入を進めます"
        return 0
    fi
    echo ""
    echo "  ───────────────────────────────────────────────"
    echo "   導入をはじめる前に、次の点をご確認ください"
    echo "  ───────────────────────────────────────────────"
    for _row in "${PREFLIGHT_ROWS[@]}"; do
        _name="${_row%%|*}"; _rest="${_row#*|}"
        _verdict="${_rest%%|*}"; _rest="${_rest#*|}"
        _msg="${_rest%%|*}"
        case "$_verdict" in
            ok)      printf '    [ 済 ] %s\n' "$_name" ;;
            auto)    printf '    [自動] %s\n           %s\n' "$_name" "$_msg" ;;
            need)    printf '    [ご確認] %s\n           %s\n' "$_name" "$_msg" ;;
            unknown) printf '    [未確認] %s\n           %s\n' "$_name" "$_msg" ;;
        esac
    done
    echo "  ───────────────────────────────────────────────"
    echo ""
    if [ "$PREFLIGHT_NEED" -eq 0 ] && [ "$PREFLIGHT_UNKNOWN" -eq 0 ]; then
        echo "   お客様の操作が必要な項目はありません。[自動] の項目はこのあと当社側で用意します。"
        echo "   そのままお待ちください。"
        echo ""
        return 0
    fi
    echo "   このまま進めることもできます (進んだ分はそのまま残ります)。"
    echo "   [ご確認] [未確認] の項目は、最後にもう一度まとめてお伝えします。"
    echo ""
    echo "     このまま進める場合   … そのまま Enter キーを押してください"
    echo "     いったん中断する場合 … 半角の n を入力して Enter キーを押してください"
    echo ""
    printf '   どちらになさいますか? (何も押さない場合はこのまま進みます) '
    _ans=""
    read -r -t "${SOLOPTILINK_PREFLIGHT_WAIT:-120}" _ans || _ans=""
    echo ""
    case "$(printf '%s' "$_ans" | tr '[:upper:]' '[:lower:]')" in
        n|no|いいえ|ちゅうだん|中断)
            return 1 ;;
    esac
    echo "  このまま導入を進めます。"
    echo ""
    return 0
}
# <<< PREFLIGHT-LIB-END <<<

# --- 準備状況の一括診断をここで実走する (自動導入より前・本体の配置より前) -----
if [ "$(printf '%s' "${SOLOPTILINK_PREFLIGHT:-on}" | tr '[:upper:]' '[:lower:]')" = "off" ]; then
    echo "  ℹ️  準備状況の確認は無効化されています (確認していません。問題が無いという意味ではありません)"
    _PF_LOGD="$HOME/.soloptilink/logs"
    mkdir -p "$_PF_LOGD" 2>/dev/null || _PF_LOGD="${TMPDIR:-/tmp}"
    printf '%s\tSOLOPTILINK_PREFLIGHT=off\t準備状況の一括確認を実行せず通過\n' \
        "$(date +%Y-%m-%dT%H:%M:%S)" >> "$_PF_LOGD/preflight.log" 2>/dev/null || true
else
    preflight_collect
    if ! preflight_present; then
        echo "  いったん中断しました。"
        echo "  上の [ご確認] の項目を解消してから、このファイルをもう一度ダブルクリックしてください。"
        echo "  SoloptiLinkAI 本体はまだ入れていませんので、はじめからやり直していただけます。"
        echo ""
        echo "[Enterキーで閉じます]"
        read -r _ || true
        exit 0
    fi
    # 解消されないまま進んだ環境面の項目は、最後の「要対応」にも必ず残す
    # (お伝えしたことを、完了画面で無かったことにしない)
    for _pf_carry in "${PREFLIGHT_ROWS[@]}"; do
        _pf_c_name="${_pf_carry%%|*}"; _pf_c_rest="${_pf_carry#*|}"
        _pf_c_rest="${_pf_c_rest#*|}"
        _pf_c_msg="${_pf_c_rest%%|*}"; _pf_c_flag="${_pf_c_rest#*|}"
        if [ "$_pf_c_flag" = "yes" ]; then add_issue "$_pf_c_name" "$_pf_c_msg"; fi
    done
fi
echo ""

set_phase "前提ソフト (Git / Node.js / Claude Code) の確認と導入" "画面に出ている『要対応』の項目を解消してから、このファイルをもう一度ダブルクリックしてください。ここまでの導入内容はそのまま残っています。"
echo "[前提ソフト] Git / Node.js / Claude Code を確認・導入"

# --- Git (macOS は Command Line Tools 同梱で通常導入済み) ---
PREREQ_VER=""
prereq_probe git --version 'git version [0-9]' >/dev/null
case "$PREREQ_VERDICT" in
    available)
        echo "  [skip] Git ($PREREQ_VER)" ;;
    present_but_broken)
        # 入口はあるが動かない = 開発ツールが未導入。「未導入」と同じ案内にしない
        echo "  Git: 開発ツールの導入が必要です (コマンドはありますが実行できません)"
        prompt_devtools
        add_issue "Git" "$DEVTOOLS_ISSUE" ;;
    *)
        echo "  Git: 未導入 → コマンドラインデベロッパツールの導入を案内します"
        prompt_devtools
        add_issue "Git" "$DEVTOOLS_ISSUE" ;;
esac

# --- Node.js (v18 以上) — 自動導入モジュール AC-I06 への結線 (T-017a) ---
#   【この実装が必要な理由】ここは長らく「既存 node があれば skip → brew があれば brew install →
#     brew が無ければ自動導入をスキップして nodejs.org を手動案内」だった。
#     同梱している installer/lib/node-provision.sh (公式 tar.xz をユーザー領域へ展開する
#     ③経路を実装済み) を【一度も呼んでいなかった】= 呼出元ゼロの死配線。
#     その結果、brew 不在の端末では自動導入が発火せず、公式 pkg インストーラの
#     「★PCのパスワード」入力で顧客の手が止まる 74 分事案の経路がそのまま残っていた。
#     配布物に同梱されていることは build-update-package.sh の HARDGATE が毎回守っていたため、
#     「入っているから直った」と誤認しやすい状態だった。
#   【この結線の役割】判定順 (①既存 ②brew ③公式tar.xz展開) と SHA-256 照合・kill-switch は
#     すべてモジュール側が実装済みなので、ここは薄い結線に留める:
#       モジュールを読み込む → node_provision_ensure → 結果 verdict を add_issue へ流す。
#     モジュールが見つからない場合に旧 brew 経路へ黙って戻さないこと。戻すと
#     「部品が落ちても従来どおり動く」= 死配線に戻ったことを誰も検出できなくなる。
NODE_PROVISION_SH=""
for _np_cand in \
    "$KIT_DIR/installer/lib/node-provision.sh" \
    "$KIT_DIR/lib/node-provision.sh" \
    "$HOME/.soloptilink/installer/lib/node-provision.sh"; do
    if [ -f "$_np_cand" ]; then NODE_PROVISION_SH="$_np_cand"; break; fi
done
if [ -n "$NODE_PROVISION_SH" ]; then
    # shellcheck disable=SC1090
    . "$NODE_PROVISION_SH"
    node_provision_ensure || true
    # 当社の現セッション PATH にのみ前置き (~/.zshrc は書き換えない)
    node_provision_path_prepend >/dev/null 2>&1 || true
    case "${NODE_PROVISION_VERDICT:-}" in
        PASS)
            echo "  ✅ Node.js: 使える状態です (${NODE_PROVISION_VERSION:-版数不明})" ;;
        WARN)
            echo "  ⚠️  Node.js: 使えますが確認事項があります"
            add_issue "Node.js" "${NODE_PROVISION_ISSUE_JA:-Node.js の状態に確認事項があります。nomura.y@soloptilink.com へご連絡ください}" ;;
        not_applicable)
            echo "  ℹ️  Node.js: このパソコンでは自動導入の対象外です"
            add_issue "Node.js" "このパソコンの種類では Node.js の自動導入に対応していません。https://nodejs.org/ja から LTS 版を導入してください" ;;
        "")
            # 【T-03 /  是正】判定そのものが返らなかった場合。
            #   この事象への対処。
            #   ここが空になった。従来はこの空が下の「用意できませんでした」に落ち、
            #   さらに案内文まで既定値に置き換わって【既に入っている Node.js を
            #   入れ直してください】という誤案内が出た。お客様は打つ手を失う。
            #   「用意できなかった」と「判定できなかった」は、お客様が取るべき行動が違う。
            #   判定不能は判定不能として出し、既定の導入案内へ落とさない。
            if [ -n "${NODE_PROVISION_VERSION:-}" ]; then
                echo "  ⚠️  Node.js: 導入済みですが状態を確認できませんでした (${NODE_PROVISION_VERSION})"
            else
                echo "  ⚠️  Node.js: 状態を判定できませんでした"
            fi
            add_issue "Node.js" "Node.js の状態を判定できませんでした。開発ツール (コマンドラインデベロッパツール) が未導入の場合は、その導入を終えてからこの .command をもう一度実行してください。解消しない場合は nomura.y@soloptilink.com へご連絡ください (Node.js を入れ直す必要はありません)" ;;
        *)
            echo "  ⚠️  Node.js: 自動で用意できませんでした (要対応一覧に集約します)"
            add_issue "Node.js" "${NODE_PROVISION_ISSUE_JA:-https://nodejs.org/ja から LTS 版を導入してください}" ;;
    esac
else
    echo "  ⚠️  Node.js: 自動導入に必要な部品が見つかりません"
    add_issue "Node.js" "自動導入に必要な部品が配布物の中に見当たりません。ZIP をもう一度展開し直してから再実行するか、nomura.y@soloptilink.com へご連絡ください"
fi

# --- Claude Code (公式ネイティブインストーラ = sudo 不要・背景自動更新) ---
if command -v claude >/dev/null 2>&1; then
    echo "  [skip] Claude Code ($(claude --version 2>/dev/null | head -1))"
else
    echo "  Claude Code: 未導入 → 公式ネイティブインストーラで導入します (自動更新あり)"
    curl -fsSL https://claude.ai/install.sh | bash >/dev/null 2>&1 || true
    export PATH="$HOME/.local/bin:$PATH"
    # ★ 2026-09-02 是正: 「在るか」ではなく「実際に動くか」で判定する。
    #   command -v は通るのに実行すると失敗する状態 (開発者ツールの割り当てが
    #   ずれている場合など) があり、その場合も従来は「導入完了」と表示していた。
    _cc_ver="$(claude --version 2>/dev/null | head -1)"
    if [ -n "${_cc_ver}" ]; then
        echo "  ✅ Claude Code 導入完了 (${_cc_ver})"
    elif command -v claude >/dev/null 2>&1; then
        # ★2026-10-17 (V-01): 以前は「ターミナルで … をお試しください」とだけ書き、ターミナルの開き方が無かった。
        #   まずはダブルクリックのやり直しで済む案内を先に置き、確かめていただく場合だけ開き方と打つ内容を添える。
        add_issue "Claude Code" "導入はされていますが、実行すると応答しません。Mac を再起動してから、このファイルをもう一度ダブルクリックしてください。それでも同じ表示のときは、この画面のスクリーンショット (⌘+Shift+4 で範囲を選ぶ) を添えて nomura.y@soloptilink.com へご連絡ください。こちらで原因をお調べします。お手元で確かめていただける場合は、ターミナル (Finder の『アプリケーション』→『ユーティリティ』→『ターミナル』、または ⌘+スペースで『ターミナル』と入力して Enter) を開き、claude --version と入力して Enter を押したときの表示もあわせてお送りください"
    else
        add_issue "Claude Code" "自動導入に失敗しました。ネットワーク(社内プロキシ/オフライン)をご確認のうえ再実行するか、nomura.y@soloptilink.com へご連絡ください"
    fi
fi

# --- Python 3 (T-702 新設) ---
#   【なぜここに足したか / 実測】
#     このインストーラ自身が STEP 6 で Claude Desktop の設定を python3 で書き換え、
#     生成物の品質点検も 138 本中 107 本が python3 を呼ぶ。つまり導入の前提なのに、
#     お客様向けの手順書 7 本すべてに記載が 0 件で、前提ソフトの確認対象にも
#     入っていなかった (実測)。
#     python3 が無い状態で同じ組み立て (set -e + ERR トラップ + python3 のヒアドキュメント)
#     を走らせると、終了コード 127 で ERR トラップが発火し、導入がそこで止まる。
#     実際の品質点検も、判定が全て「-」になり合否を出せなくなることを実走で確認した。
#   【方針】自動導入はしない (Apple の開発ツール導入は同意画面を伴い、無人では進まない)。
#     ここでは検出だけ行い、無い場合は導入の案内を「要対応」へ集約する。
#   ★macOS には python3 の「入口」が開発ツール未導入でも実在する。
#     コマンドがあることだけを見ると入っている扱いになるため、版の表示まで確かめる
#     (Windows 側の python3.exe = ストアへ誘導するだけの入口と同じ構造)。
PREREQ_VER=""
prereq_probe python3 --version 'Python 3\.' >/dev/null
case "$PREREQ_VERDICT" in
    available)
        echo "  [skip] Python 3 ($PREREQ_VER)" ;;
    present_but_broken)
        echo "  Python 3: 開発ツールの導入が必要です (コマンドはありますが実行できません)"
        prompt_devtools
        add_issue "Python 3" "${DEVTOOLS_ISSUE}。導入せずに進めると、Claude Desktop の設定登録と、生成した業務システムの品質点検が行えません" ;;
    *)
        echo "  Python 3: 未導入 → 開発ツール一式の導入を案内します"
        prompt_devtools
        add_issue "Python 3" "${DEVTOOLS_ISSUE}。導入せずに進めると、Claude Desktop の設定登録と、生成した業務システムの品質点検が行えません" ;;
esac

set -e   # 以降は通常のエラー検出に戻す
echo ""

# ---------------------------------------------------------------------------
# STEP 3/6: 既存環境のバックアップ
# ---------------------------------------------------------------------------
set_phase "すでに入っているものの控え取り" "パソコンの空き容量をご確認のうえ、このファイルをもう一度ダブルクリックしてください。"
echo "[STEP 3/6] 既存環境のバックアップ"
if [ "$HAD_EXISTING_SOLOPTILINK" -eq 1 ] && [ -d "$HOME/.soloptilink" ]; then
    BK="$HOME/.soloptilink.bak.$TS"
    echo "  すでに入っているものを控えとして取っておきます"
    mv "$HOME/.soloptilink" "$BK"
    echo "  ✅ 控えを取りました (元に戻したいときは、この控えを使って戻せます)"
else
    echo "  既存環境なし (新規インストール)"
fi
mkdir -p "$HOME/.soloptilink"

# ── 再インストール時の認証引継ぎ (PFP-119) ──
# 退避した旧環境から認証系3ファイル (端末認証 activation.json / 端末識別
# .device_identity.json / ライセンスキャッシュ license.json) を新環境へ
# 自動コピー戻しし、再インストール後の再認証 (--activate やり直し) を不要にする。
# 配布物にはこれらの認証ファイルが含まれないため、後続の本体配置で上書きされない。
#
# ★引き継げた数と「登録が済んでいる証拠」は別物である (2026-08-17 是正)
#   .device_identity.json (端末の指紋) は、登録に成功したかどうかに関係なく作られる。
#   したがって「1つでも引き継げた」ことは、登録が済んだ証拠にはならない。
#   登録が済んだと言えるのは activation.json と license.json がそろっている場合だけ。
#   この2つを AUTH_PROOF として別に数える (誤判定の詳細は後段 STEP 8 の注記を参照)。
AUTH_CARRIED=0
AUTH_PROOF=0
if [ -n "${BK:-}" ] && [ -d "${BK:-}" ]; then
    for AUTH_FILE in activation.json .device_identity.json license.json; do
        if [ -f "$BK/$AUTH_FILE" ]; then
            if cp -p "$BK/$AUTH_FILE" "$HOME/.soloptilink/$AUTH_FILE" 2>/dev/null; then
                AUTH_CARRIED=$((AUTH_CARRIED+1))
                case "$AUTH_FILE" in
                    activation.json|license.json) AUTH_PROOF=$((AUTH_PROOF+1)) ;;
                esac
            fi
        fi
    done
fi
if [ "$AUTH_PROOF" -ge 2 ]; then
    echo "  ✅ 認証情報は引き継ぎました (再認証は不要です)"
elif [ "$AUTH_CARRIED" -gt 0 ]; then
    # 指紋だけを引き継いだ状態。登録はこれから行うため、済んだかのように言わない。
    echo "  ℹ️  この端末の情報を引き継ぎました (ご登録はこのあと行います)"
fi

# ── Node ランタイムと導入記録の引継ぎ (T-017a) ──
# 前提ソフト工程で自動導入した Node 本体 (runtime/node/) と、その判定記録
# (var/node-provision-*) は退避先に入ってしまう。同じ絶対パスへ戻さないと
# runtime/node/env.sh が指す先が消え、せっかく導入した Node が使えなくなる。
# 退避元は消さない (コピーで戻す = 元に戻せる状態を保つ)。
if [ -n "${BK:-}" ] && [ -d "${BK:-}" ]; then
    if [ -d "$BK/runtime/node" ]; then
        mkdir -p "$HOME/.soloptilink/runtime" 2>/dev/null || true
        cp -R "$BK/runtime/node" "$HOME/.soloptilink/runtime/" 2>/dev/null || true
    fi
    for NP_FILE in node-provision-results.json node-provision-refiner.json node-provision.log; do
        if [ -f "$BK/var/$NP_FILE" ]; then
            mkdir -p "$HOME/.soloptilink/var" 2>/dev/null || true
            cp -p "$BK/var/$NP_FILE" "$HOME/.soloptilink/var/$NP_FILE" 2>/dev/null || true
        fi
    done
fi
echo ""

# ---------------------------------------------------------------------------
# STEP 4/6: パッケージ本体の配置 (自己完結ZIP → tar.gz → ネットワークの順)
# ---------------------------------------------------------------------------
set_phase "SoloptiLinkAI 本体の配置" "インターネットの接続と空き容量をご確認のうえ、このファイルをもう一度ダブルクリックしてください。"
echo "[STEP 4/6] SoloptiLinkAI 本体を配置中..."

if [ -f "$KIT_DIR/chain.sh" ] && [ -d "$KIT_DIR/lib" ]; then
    # ── モードA: 自己完結ZIP (現行 per-platform ZIP の既定レイアウト) ──
    echo "  自己完結キットを検出 (展開済みパッケージ本体)"
    # この .command 自身と Mac専用補助ファイルは除外して本体をコピー
    ( cd "$KIT_DIR" && \
      find . -mindepth 1 -maxdepth 1 \
        ! -name 'SoloptiLinkAI-Setup.command' \
        ! -name 'はじめに_Mac.txt' \
        ! -name '.DS_Store' \
        -exec cp -R {} "$HOME/.soloptilink/" \; )
    echo "  ✅ 本体の配置が完了しました"
else
    # ── モードB: tar.gz 同梱キット ──
    PAYLOAD_TGZ=$(ls "$KIT_DIR"/../soloptilink-update-v*.tar.gz "$KIT_DIR"/soloptilink-update-v*.tar.gz 2>/dev/null | sort -V | tail -1)
    if [ -n "$PAYLOAD_TGZ" ] && [ -f "$PAYLOAD_TGZ" ]; then
        echo "  オフライン配布物を検出: $(basename "$PAYLOAD_TGZ")"
        tar xzf "$PAYLOAD_TGZ" -C "$HOME/.soloptilink" --strip-components=1
        echo "  ✅ 展開完了"
    else
        # ── モードC: ネットワーク取得 (最終手段 / PFP-101: -L で302追従) ──
        echo "  本体が見つからないため、ネットワーク経由で取得します..."
        # HTTP status と本文を分離取得。stderr は退避して顧客可視に出さない。
        _NET_TMP=$(mktemp -t solai_net.XXXXXX 2>/dev/null || echo "/tmp/solai_net.$$")
        _NET_ERR="${_NET_TMP}.err"
        # curl は接続失敗時にも -w の 000 を標準出力へ印字してから非0終了するため、
        # || echo を重ねると「000000」になり通信失敗の案内が永遠に出ない (実測再現済み)。
        HTTP_CODE=$(curl -sSL --max-time 30 -o "$_NET_TMP" -w "%{http_code}" \
            "$API_BASE/updates/check?version=0&os=darwin&arch=$(uname -m | sed 's/x86_64/amd64/')" \
            2>"$_NET_ERR")
        [ -z "$HTTP_CODE" ] && HTTP_CODE="000"
        LATEST_JSON=$(cat "$_NET_TMP" 2>/dev/null || echo "")
        # 素の macOS (開発ツール未導入) では python3 が使えないため、まず sed で素朴に抜く。
        # 取れなければ python3 でも試す (どちらかが成功すればよい)。
        TAR_URL=$(echo "$LATEST_JSON" | sed -n 's/.*"package_url"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)
        if [ -z "$TAR_URL" ] && command -v python3 >/dev/null 2>&1 && python3 --version >/dev/null 2>&1; then
            TAR_URL=$(echo "$LATEST_JSON" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('package_url') or '')" 2>/dev/null || echo "")
        fi
        rm -f "$_NET_TMP" "$_NET_ERR" 2>/dev/null || true
        if [ -z "$TAR_URL" ]; then
            echo ""
            echo "  ⚠️  本体を取得できませんでした。"
            if [ "$HTTP_CODE" = "000" ]; then
                echo "      インターネットに接続できていない可能性があります。"
                echo "      Wi-Fi や有線接続、社内プロキシ / VPN の設定をご確認のうえ、"
                echo "      再度「①ここをダブルクリック（導入）.command」を実行してください。"
            elif [ "$HTTP_CODE" -ge 500 ] 2>/dev/null; then
                echo "      配信サーバー側で一時的な問題が発生している可能性があります (応答コード: $HTTP_CODE)。"
                echo "      数分おいて再度実行してください。解消しない場合は下記までご連絡ください。"
            elif [ "$HTTP_CODE" -ge 400 ] 2>/dev/null; then
                echo "      配信サーバーへのアクセスが許可されていません (応答コード: $HTTP_CODE)。"
                echo "      ご契約状況の確認が必要な可能性があります。下記までご連絡ください。"
            elif [ "$HTTP_CODE" = "200" ]; then
                echo "      配信情報の読み取りに失敗しました (応答: $HTTP_CODE / 本体パッケージ URL 未指定)。"
                echo "      配信側の準備が完了していない可能性があります。下記までご連絡ください。"
            else
                echo "      配信サーバーから想定外の応答を受け取りました (応答コード: $HTTP_CODE)。"
                echo "      下記までご連絡ください。"
            fi
            echo ""
            echo "      連絡先: nomura.y@soloptilink.com"
            echo "      お手数ですが上記の応答コードを本文にお書き添えください。"
            exit 1
        fi
        echo "  ダウンロード: $TAR_URL"
        curl -fsSL --max-time 300 -o "$HOME/.soloptilink/_latest.tar.gz" "$TAR_URL"
        # ★2026-10-10: 展開する前に、受け取った本体を自動更新・回収と同じ値で確かめる (上の SETUP-PACKAGE-VERIFY)。
        if ! _setup_verify_package "$HOME/.soloptilink/_latest.tar.gz" \
                "$(_setup_json_field "$LATEST_JSON" package_sha256)" \
                "$(_setup_json_field "$LATEST_JSON" package_signature)"; then
            rm -f "$HOME/.soloptilink/_latest.tar.gz"
            echo ""
            echo "  ⚠️  受け取った本体が当社の配信物と一致しないため、安全のため導入を中止しました。"
            echo "      通信の途中で壊れたか、別のものに差し替えられた可能性があります。"
            echo "      時間をおいて、もう一度「①ここをダブルクリック（導入）.command」を実行してください。"
            echo "      繰り返し表示される場合は、nomura.y@soloptilink.com までご連絡ください。"
            exit 1
        fi
        tar xzf "$HOME/.soloptilink/_latest.tar.gz" -C "$HOME/.soloptilink" --strip-components=1
        rm -f "$HOME/.soloptilink/_latest.tar.gz"
        echo "  ✅ ダウンロード+展開完了"
    fi
fi

# AppleDouble 再除去 + 実行権限付与
find "$HOME/.soloptilink" -name '._*' -delete 2>/dev/null || true
find "$HOME/.soloptilink" -name '.DS_Store' -delete 2>/dev/null || true

# ── 送信停止のご意思の引継ぎと「停止した状態での導入」(2026-09-25) ──
# ★欠陥の是正: 再インストールでは既存の設定フォルダを丸ごと控えへ移し、認証の
#   3 ファイルだけを戻していた。停止の印は戻していなかったため、お知らせの停止
#   (や完全停止) を選んだ端末でも、入れ直すと黙って送信が再開していた。
#   同じ理由で、導入前に情報システム部門が停止の印を置いておいても効かなかった。
# ★法人のお客様向け: ZIP に telemetry-off.flag を同梱して渡すと (または導入時に
#   停止の環境変数を指定すると)、初回の登録・起動より前に停止を設定する。
#   手順は docs/ENTERPRISE_TELEMETRY_OFF.md。
# 印の名前はここへ書き写さない。取り決めを読む同意の層 (markers / contract) に聞く。
# 展開直後・端末認証より前に置くのは、最初の起動から停止を効かせるため。
_SL_CONSENT="$HOME/.soloptilink/lib/telemetry-consent.sh"
if [ -f "$_SL_CONSENT" ]; then
    if [ -n "${BK:-}" ] && [ -d "${BK:-}" ]; then
        _sl_carried=0
        for _sl_m in $(bash "$_SL_CONSENT" markers 2>/dev/null); do
            case "$_sl_m" in ''|*/*) continue ;; esac
            if [ -e "$BK/$_sl_m" ] && cp -p "$BK/$_sl_m" "$HOME/.soloptilink/$_sl_m" 2>/dev/null; then
                _sl_carried=1
            fi
        done
        [ "$_sl_carried" = 1 ] && echo "  ✅ 以前お選びいただいた送信停止の設定を引き継ぎました"
    fi
    _sl_want_off=0
    for _sl_f in "$KIT_DIR/telemetry-off.flag" "$KIT_DIR/../telemetry-off.flag"; do
        [ -f "$_sl_f" ] && _sl_want_off=1
    done
    _sl_env_name=$(bash "$_SL_CONSENT" contract 2>/dev/null | sed -n 's/^optout_env=//p' | head -1)
    if [ -n "$_sl_env_name" ]; then
        case "$(printenv "$_sl_env_name" 2>/dev/null)" in 1|true|TRUE|yes|YES) _sl_want_off=1 ;; esac
    fi
    rm -f "$HOME/.soloptilink/telemetry-off.flag" 2>/dev/null || true   # 配置で写った指定書きは残さない
    if [ "$_sl_want_off" = 1 ]; then
        bash "$_SL_CONSENT" stop >/dev/null 2>&1 || true
        # 書けたかどうかは、書いた結果を読み直して確かめる (「停止しました」と言うだけにしない)
        case "$(bash "$_SL_CONSENT" contract 2>/dev/null | sed -n 's/^reason=//p')" in
            stopped*)
                echo "  ✅ ご指定どおり、動作状況のお知らせ (品質統計・エラー報告) を停止した状態で導入しました" ;;
            *)
                echo "  ⚠️  動作状況のお知らせを停止する設定を書き込めませんでした"
                # ★2026-10-17 (V-01): 以前は打ち込む命令と本体の中の場所をそのまま見せていた。
                #   停止の指定書き (telemetry-off.flag) は導入キットの側に残るため、もう一度ダブルクリックすれば
                #   同じ停止の設定をもう一度書き込む。命令を見せない案内に替える (Windows 側と同じ考え方)。
                add_issue "動作状況のお知らせの停止" "停止の設定を書き込めませんでした。このファイルをもう一度ダブルクリックしてください (同じご指定で、停止の設定をもう一度書き込みます)。それでも書き込めないときは nomura.y@soloptilink.com へご連絡ください。停止の手順をご案内します。停止できるまでの間に送られうる内容は、同梱の『プライバシーポリシー』の表のとおりです" ;;
        esac
    fi
fi
chmod +x "$HOME/.soloptilink"/chain.sh 2>/dev/null || true
chmod +x "$HOME/.soloptilink"/*.sh 2>/dev/null || true
echo ""

# ---------------------------------------------------------------------------
# STEP 5/6: Goランチャーの配置 (アーキ自動判定)
# ---------------------------------------------------------------------------
set_phase "このパソコン用の起動プログラムの配置" "インターネットの接続をご確認のうえ、このファイルをもう一度ダブルクリックしてください。"
echo "[STEP 5/6] Goランチャーを配置"
ARCH=$(uname -m)
case "$ARCH" in
    arm64)  LAUNCHER_NAME="soloptilink-darwin-arm64" ;;
    x86_64) LAUNCHER_NAME="soloptilink-darwin-amd64" ;;
    *) echo "  ⚠️  未対応のアーキ: $ARCH"; exit 1 ;;
esac

if [ -f "$HOME/.soloptilink/soloptilink" ]; then
    # 自己完結ZIP は arch 専用バイナリを soloptilink として同梱済み
    :
elif [ -f "$KIT_DIR/$LAUNCHER_NAME" ]; then
    cp "$KIT_DIR/$LAUNCHER_NAME" "$HOME/.soloptilink/soloptilink"
elif [ -f "$KIT_DIR/Mac/$LAUNCHER_NAME" ]; then
    cp "$KIT_DIR/Mac/$LAUNCHER_NAME" "$HOME/.soloptilink/soloptilink"
else
    LAUNCHER_URL="https://github.com/onukih-design/soloptilink-releases/releases/latest/download/${LAUNCHER_NAME}"
    echo "  ダウンロード: $LAUNCHER_URL"
    curl -fsSL --max-time 120 -o "$HOME/.soloptilink/soloptilink" "$LAUNCHER_URL"
fi
chmod +x "$HOME/.soloptilink/soloptilink"
xattr -d com.apple.quarantine "$HOME/.soloptilink/soloptilink" 2>/dev/null || true
echo "  ✅ アーキ: $ARCH 用バイナリを配置"
echo ""

# ---------------------------------------------------------------------------
# STEP 5.5/6: 自動更新フックの登録 (更新が自動で届かない状態を防ぐ)
# ---------------------------------------------------------------------------
# 【鶏卵デッドロックの解消】従来、自動更新フック (~/.claude/settings.json) を
# 登録するのは移行スクリプト 1本だけで、それを呼ぶのは「フックで起動される
# auto-update.sh 自身」だった。そのため新規導入時は誰もフックを登録せず、
# 一度も手動更新しない限り自動更新が永遠に始まらなかった。
# → 導入のこの瞬間にフックを登録し、自動更新の点火を保証する。冪等。
set_phase "自動更新の設定" "このファイルをもう一度ダブルクリックしてください。設定だけをやり直します。"
echo "[STEP 5.5/6] 自動更新を有効化"
_HOOK_OK=0
# ★「登録を実行した」ではなく「登録が効いた」で判定する。
#   【この実装が必要な理由】従来は登録コマンドの終了コードだけを見て成功としていた。
#   これは今日の前提ソフト事案とまったく同じ誤り (実行したことと、効いたことを混同する)。
#   登録が効いていないまま「以降は自動で最新版を取得します」と表示すると、
#   お客様は更新されていることを前提に使い続け、何世代も古いまま気づけない。
#   実際 一部の環境で導入・更新が完了しない事象が確認されたため。
#   そこで登録後に設定ファイルを実際に読み、自動更新の登録が入っているかを確かめる。
#   ★この確認は python3 を使わない (開発ツール未導入の端末でも必ず動く必要があるため)。
_hook_is_registered() {
    local _st="$HOME/.claude/settings.json"
    [ -f "$_st" ] || return 1
    # 自動更新の登録行が実在するかだけを見る (整形の違いに強い素朴な検索)
    grep -q 'auto-update.sh' "$_st" 2>/dev/null || return 1
    grep -q 'SessionStart' "$_st" 2>/dev/null || return 1
    return 0
}
# 第一経路: ランチャー経由の冪等登録 (全OS共通・テスト済みの単一実装・python3 非依存)
if [ -x "$HOME/.soloptilink/soloptilink" ]; then
    "$HOME/.soloptilink/soloptilink" --register-autoupdate-hook >/dev/null 2>&1 || true
    _hook_is_registered && _HOOK_OK=1
fi
# 第二経路 (保険): 移行スクリプト直接実行
if [ "$_HOOK_OK" -eq 0 ] && [ -f "$HOME/.soloptilink/migration/v2027_hook_install.sh" ]; then
    bash "$HOME/.soloptilink/migration/v2027_hook_install.sh" >/dev/null 2>&1 || true
    _hook_is_registered && _HOOK_OK=1
fi
# ★メニュー(スキル)の修復フックも登録する。
#   【この実装が必要な理由】このフックは「顧客端末で毎回確実に動く経路は自分だけである」と
#   自ら宣言しているのに、顧客の設定へ登録する処理が本体のどこにも存在しなかった
#   (全数検索してヒットしたのは同梱リスト・存在検査・資産台帳だけで、登録は 0 件)。
#   そのため、メニューが古い版のまま取り残されても直る機会が無く、
#   さらにこのフックだけが呼び出し元である「新しい版が出ています」の通知も
#   顧客端末で一度も出ていなかった。一部の環境で導入・更新が完了しない事象が確認されたため。
#   15 世代前の版が出続けたのは、この経路が繋がっていなかったためでもある。
#   ★python3 を使わずに登録する (開発ツール未導入の端末でも必ず動く必要があるため)。
# >>> sl-safe-settings-write-sh v2 (2026-10-29) >>>
# お客様の設定の全文の控えは作らない (Python の sl-safe-settings-write v2 と同じ考え方の、
# python3 を使わずに書き換える場面の版。開発ツールの無い Mac でも動く必要があるため)。
# 書き換えた中身の一時ファイル ($2) を、元の権限を引き継ぎ、JSON として読めることと、
# 読んでから設定 ($1) が変わっていないこと ($3 = 読む前に取った cksum の結果) を
# 確かめてから置き換える。一時ファイルは呼ぶ側が設定と同じフォルダに umask 077 で作る。
# JSON として読めるかは python3 → node → macOS の osascript の順に、動くもので確かめる。
# どれも動かない端末では書き換えない。
# 設定がリンクのときはリンクを残し、リンク先の実体を置き換える (撤去の段 3 と同じ扱い)。
# このとき一時ファイルは実体と同じフォルダに作り直す (同じフォルダの中で置き換えるため)。
# v1 はリンクを拒んで書き換えなかった (2026-10-29 独立審査で Python 版とそろえた)。
# 壊れたリンク・行き先をたどりきれないリンク・行き先が変わったリンクには書かずに止める。
_sl_json_dict_ok() {
    if command -v python3 >/dev/null 2>&1 && python3 --version >/dev/null 2>&1; then
        python3 -c 'import json, sys; d = json.load(open(sys.argv[1], encoding="utf-8")); sys.exit(0 if isinstance(d, dict) else 1)' "$1" >/dev/null 2>&1
        return $?
    fi
    if command -v node >/dev/null 2>&1 && node -e '' >/dev/null 2>&1; then
        node -e 'const d = JSON.parse(require("fs").readFileSync(process.argv[1], "utf8")); process.exit(d !== null && typeof d === "object" && !Array.isArray(d) ? 0 : 1)' "$1" >/dev/null 2>&1
        return $?
    fi
    if [ -x /usr/bin/osascript ]; then
        /usr/bin/osascript -l JavaScript -e 'function run(a) { var s = $.NSString.stringWithContentsOfFileEncodingError(a[0], 4, null); if (!s) throw new Error("unreadable"); var d = JSON.parse(s.js); if (d === null || typeof d !== "object" || Array.isArray(d)) throw new Error("not dict"); return "ok"; }' "$1" >/dev/null 2>&1
        return $?
    fi
    return 1
}
# 設定の道 ($1) がリンクなら、たどった先の実体の道を出す (リンクでなければそのまま)。
# realpath の無い古い Mac でも動くよう readlink を 1 段ずつたどる。たどりきれなければ 1 を返す。
_sl_settings_real_path() {
    local _p="$1" _n=0 _l=""
    while [ -L "$_p" ]; do
        _n=$((_n + 1))
        [ "$_n" -le 16 ] || return 1
        _l="$(readlink "$_p" 2>/dev/null)" || return 1
        [ -n "$_l" ] || return 1
        case "$_l" in
            /*) _p="$_l" ;;
            *) _p="$(dirname "$_p")/$_l" ;;
        esac
    done
    printf '%s\n' "$_p"
}
sl_safe_settings_swap() {
    local _mode="" _real="" _tmp=""
    _real="$(_sl_settings_real_path "$1")" || _real=""
    if [ -z "$_real" ] || [ ! -f "$_real" ] || [ -L "$_real" ] || [ ! -f "$2" ] || [ -L "$2" ] || [ ! -s "$2" ]; then
        rm -f "$2" 2>/dev/null
        return 1
    fi
    if [ "$_real" != "$1" ]; then
        _tmp="$(dirname "$_real")/.$(basename "$_real").sl-new.$$"
        if [ -e "$_tmp" ] || [ -L "$_tmp" ]; then
            rm -f "$2" 2>/dev/null
            return 1
        fi
        if ! ( umask 077; set -C; cat "$2" > "$_tmp" ) 2>/dev/null; then
            rm -f "$2" "$_tmp" 2>/dev/null
            return 1
        fi
        rm -f "$2" 2>/dev/null
        set -- "$1" "$_tmp" "$3"
    fi
    _mode="$(stat -f '%Lp' "$_real" 2>/dev/null || stat -c '%a' "$_real" 2>/dev/null)" || _mode=""
    case "$_mode" in
        [0-7][0-7][0-7]|[0-7][0-7][0-7][0-7]) ;;
        *) _mode="" ;;
    esac
    if [ -z "$_mode" ] || ! chmod "$_mode" "$2" 2>/dev/null; then
        rm -f "$2" 2>/dev/null
        return 1
    fi
    if ! _sl_json_dict_ok "$2" || [ "$(cksum < "$1" 2>/dev/null)" != "$3" ] \
        || [ "$(_sl_settings_real_path "$1" 2>/dev/null)" != "$_real" ]; then
        rm -f "$2" 2>/dev/null
        return 1
    fi
    mv -f "$2" "$_real" 2>/dev/null || { rm -f "$2" 2>/dev/null; return 1; }
    return 0
}
# <<< sl-safe-settings-write-sh v2 <<<
# >>> SOLOPTILINK-SKILL-HEAL-WIRE-BEGIN
#   ★2026-10-28: 書き換える前の全文の控え (settings.json.bak.<日時>) は作らない。控えには
#     お客様の環境変数や許可の設定がそのまま写り、消す処理がどこにも無いまま残り続けていた。
#     また、書式の崩れた設定にもこの書き換えが当たり、崩れた設定を書き換えていた (砂箱で実走して確認)。
#     読めない設定には触らず、書き換えた中身を JSON として読み直し、元の権限を引き継いでから置き換える
#     (上の sl_safe_settings_swap)。
_SKILL_HEAL="$HOME/.soloptilink/lib/hooks/session-start-skill-heal.sh"
_ST_JSON="$HOME/.claude/settings.json"
if [ -f "$_SKILL_HEAL" ] && [ -f "$_ST_JSON" ] && _sl_json_dict_ok "$_ST_JSON"; then
    if ! grep -q 'session-start-skill-heal.sh' "$_ST_JSON" 2>/dev/null; then
        # 自動更新の登録行に相乗りする形で 1 行だけ足す (既存の構造を壊さない)
        # ★2026-10-26: 旧版の sed は自動更新の行すべてに当たり、UserPromptSubmit 側にも
        #   相乗りしていた (= お客様が 1 文送るたびに修復が走り、自動更新の 30 秒枠を食う)。
        #   砂箱で実測して確認。SessionStart の区切りの中の行だけに当てる。
        _st_ck="$(cksum < "$_ST_JSON" 2>/dev/null)" || _st_ck=""
        _tmp_st="$_ST_JSON.tmp.$$"
        _st_made=0
        # 一時ファイルは排他で作る。同じ名前が既にあれば (前回の中断の残りなど) 取り違えないよう何もしない
        if ( umask 077; set -C; awk '
            /"[A-Za-z]+"[[:space:]]*:[[:space:]]*\[/ {
                k = $0; sub(/^[^"]*"/, "", k); sub(/".*$/, "", k)
                if (k != "hooks") ev = k      # 各登録の中の "hooks": [ は区切り名ではない
            }
            ev == "SessionStart" && /bash [^"]*auto-update\.sh/ && !done {
                sub(/auto-update\.sh/, "auto-update.sh\\&\\& bash ~/.soloptilink/lib/hooks/session-start-skill-heal.sh >/dev/null 2>\\&1 || true")
                done = 1
            }
            { print }
        ' "$_ST_JSON" > "$_tmp_st" ) 2>/dev/null; then
            _st_made=1
        fi
        # 壊れた設定を残さない: 書けた場合のみ差し替え、登録できたかを必ず確かめる
        if [ "$_st_made" -eq 1 ] && [ -n "$_st_ck" ] && [ -s "$_tmp_st" ] && grep -q 'session-start-skill-heal.sh' "$_tmp_st" 2>/dev/null; then
            sl_safe_settings_swap "$_ST_JSON" "$_tmp_st" "$_st_ck" || true
        elif [ "$_st_made" -eq 1 ]; then
            rm -f "$_tmp_st" 2>/dev/null || true
        fi
    fi
fi
# <<< SOLOPTILINK-SKILL-HEAL-WIRE-END

if [ "$_HOOK_OK" -eq 1 ]; then
    echo "  ✅ 以降 Claude Code 起動時に自動で最新版を取得します (登録を確認済み)"
else
    # ★従来の案内は「チャット欄に『最新版にして』とお伝えください」
    #   だったが、これは効かない。チャットの中からは設定ファイルを書き換えられない
    #   仕組み (自己改変の防止) になっており、お客様が案内どおりにしても状況が変わらない。
    #   実際に効く手段だけを案内する。
    echo "  ⚠️  自動更新の設定を完了できませんでした (このままだと最新版が自動で届きません)"
    echo "      お手数ですが、この画面のあとに表示される案内に沿って"
    echo "      『コマンドラインデベロッパツール』の導入を完了し、"
    echo "      もう一度このセットアップをダブルクリックしてください。"
    echo "      解消しない場合は nomura.y@soloptilink.com へご連絡ください (端末の状態を確認します)。"
    add_issue "自動更新" "自動更新の設定が完了していません。このままでは最新版が自動で届きません。『コマンドラインデベロッパツール』の導入を終えてから、このセットアップをもう一度実行してください。解消しない場合は nomura.y@soloptilink.com までご連絡ください"
fi

# ---------------------------------------------------------------------------
# STEP 5.6/6: 品質・信頼性フックの登録
# ---------------------------------------------------------------------------
# 【この実装が必要な理由】ここで名指しで実行していたのは v2027 (自動更新) の1本だけだった。
#   そのため v2027 以降に追加された遡及配線 (品質ゲート・エラーゼロ化4本柱の結線層など) は
#   【新規導入の端末に一度も適用されない】。実測で、4本柱の結線層 7エントリが顧客端末の
#   ~/.claude/settings.json に一つも入っていないことが判明した (開発機でしか動いていなかった)。
#   名指し列挙は「今後増えるもの」を必ず取りこぼす構造なので、ここは列挙をやめて
#   migration/ 配下の全スクリプトを実行する (各スクリプトが自前で冪等性を保証している)。
# ============================================================
# STEP 5.7/6: Claude Code から呼び出せるように配置する (2026-09-02 新設)
# ------------------------------------------------------------
# 【なぜ要るか — 砂箱でお客様と同じ手順を実走して確認したこと】
#   本体一式は ~/.soloptilink へ正しく配置されるのに、Claude Code が読む
#   ~/.claude/skills / commands / agents には何一つ置かれていませんでした。
#   その状態でも導入は「完了」と表示されるため、お客様は導入できたと思って
#   Claude Code を開き、/soloptilink と入力しても何も起きません。
#   自動更新に配置の処理はありますが、それは「更新が実際に適用されるとき」に
#   しか走らないため、最新版を新規導入した端末では永久に走りません
#   (実測: 導入直後に自動更新を走らせても 0 件のままでした)。
#   ここで確実に配置します。何度実行しても同じ結果になります。
# ============================================================
# ------------------------------------------------------------
# 導入台帳への記録 (RQ-405 / 2026-09-13 新設)
#   退去は「台帳に載っているものだけ」を消す。ここで書かないと、ご解約後も
#   当社のファイルがお客様の端末に残る。source ではなく別プロセスで呼ぶ
#   (相手は set -uo pipefail を立てており、この導入プログラムは set -e で走っている)。
#   記録の失敗で導入は止めない (必ず || true で受ける)。
# ------------------------------------------------------------
_SL_MANIFEST_SH="$HOME/.soloptilink/lib/evict/manifest.sh"
_SL_MANIFEST_MISS=0
_sl_manifest_note() {
    [ "${SOLOPTILINK_INSTALL_MANIFEST:-on}" = "off" ] && return 0
    [ -f "$_SL_MANIFEST_SH" ] || return 0
    bash "$_SL_MANIFEST_SH" add "$@" >/dev/null 2>&1 || _SL_MANIFEST_MISS=$((_SL_MANIFEST_MISS + 1))
    return 0
}
_sl_manifest_note_settings_hooks() {
    [ "${SOLOPTILINK_INSTALL_MANIFEST:-on}" = "off" ] && return 0
    [ -f "$_SL_MANIFEST_SH" ] || return 0
    bash "$_SL_MANIFEST_SH" add-settings-hooks "${1:-installer-mac}" >/dev/null 2>&1 \
      || _SL_MANIFEST_MISS=$((_SL_MANIFEST_MISS + 1))
    return 0
}
# 既存端末の初期投入: 台帳がまだ無いときだけ、いまの接地点を走査して作る
if [ "${SOLOPTILINK_INSTALL_MANIFEST:-on}" != "off" ] && [ -f "$_SL_MANIFEST_SH" ] \
   && [ ! -f "$HOME/.claude/.soloptilink-install-manifest.json" ]; then
    # ★2026-09-29: 以前は出力の数字をすべてつなげて件数にしていたため「009291 件」のように崩れた。
    #   「台帳を作成: N 件」の N だけを取り出す。
    _sl_scan_n="$(bash "$_SL_MANIFEST_SH" scan installer-mac-initial-scan 2>/dev/null \
                  | sed -n 's/.*台帳を作成:[[:space:]]*\([0-9][0-9]*\)[[:space:]]*件.*/\1/p' | tail -1)" || _sl_scan_n=""
    [ -n "$_sl_scan_n" ] && echo "  ✅ この端末に入っている当社の構成要素を台帳へ記録しました (${_sl_scan_n} 件)"
fi

set_phase "呼び出し口の配置" "このファイルをもう一度ダブルクリックしてください。配置だけをやり直します。"
echo "[STEP 5.7/6] Claude Code から呼び出せるように配置"
_SL_SRC_SKILLS="$HOME/.soloptilink/skills"
_SL_DST_SKILLS="$HOME/.claude/skills"
_SL_DST_CMDS="$HOME/.claude/commands"
_SL_DST_AGENTS="$HOME/.claude/agents"
if [ -d "$_SL_SRC_SKILLS" ]; then
    mkdir -p "$_SL_DST_SKILLS" "$_SL_DST_CMDS" "$_SL_DST_AGENTS" 2>/dev/null
    _sl_sk_n=0
    for _sl_sd in "$_SL_SRC_SKILLS"/*/; do
        [ -d "$_sl_sd" ] || continue
        _sl_name="$(basename "$_sl_sd")"
        # 管理者専用のものはお客様の端末に置かない
        case "$_sl_name" in
            soloptilink-release|soloptilink-deploy|soloptilink-doctor|soloptilink-arte) continue ;;
        esac
        # ★2026-10-26: 名前の手書き一覧だけだと新しい管理者専用メニューを取りこぼす。
        #   SKILL.md の先頭 30 行に admin_only: true があるものも置かない (Windows 側と同じ基準)。
        if [ -f "${_sl_sd}SKILL.md" ] && head -30 "${_sl_sd}SKILL.md" 2>/dev/null | grep -Eq '^admin_only:[[:space:]]*true[[:space:]]*$'; then
            continue
        fi
        rm -rf "${_SL_DST_SKILLS}/${_sl_name}" 2>/dev/null
        cp -R "$_sl_sd" "${_SL_DST_SKILLS}/${_sl_name}" 2>/dev/null || continue
        # RQ-405: 置いた瞬間に台帳へ 1 行 (後でまとめて書くと、途中で止まった端末に残る)
        _sl_manifest_note --canonical "$_sl_name" --current "$_sl_name" --kind dir \
                          --path "${_SL_DST_SKILLS}/${_sl_name}" --by installer-mac
        if [ -f "${_SL_DST_SKILLS}/${_sl_name}/SKILL.md" ]; then
            if cp "${_SL_DST_SKILLS}/${_sl_name}/SKILL.md" "${_SL_DST_CMDS}/${_sl_name}.md" 2>/dev/null; then
                _sl_manifest_note --canonical "cmd:${_sl_name}.md" --current "${_sl_name}.md" \
                                  --kind file --path "${_SL_DST_CMDS}/${_sl_name}.md" --by installer-mac
            fi
        fi
        _sl_sk_n=$((_sl_sk_n + 1))
    done
    _sl_ag_n=0
    if [ -d "$HOME/.soloptilink/agents" ]; then
        for _sl_af in "$HOME/.soloptilink/agents"/*.md; do
            [ -f "$_sl_af" ] || continue
            if cp "$_sl_af" "${_SL_DST_AGENTS}/" 2>/dev/null; then
                _sl_ag_n=$((_sl_ag_n + 1))
                _sl_manifest_note --canonical "agent:$(basename "$_sl_af")" \
                                  --current "$(basename "$_sl_af")" --kind file \
                                  --path "${_SL_DST_AGENTS}/$(basename "$_sl_af")" --by installer-mac
            fi
        done
    fi
    # 本体そのもの (退去の最終段で消す対象)
    [ -d "$HOME/.soloptilink" ] && _sl_manifest_note --canonical "soloptilink-core" --kind dir \
        --path "$HOME/.soloptilink" --marker yes --by installer-mac
    # 設定に登録済みの当社フック (位置は登録後にしか分からない)
    _sl_manifest_note_settings_hooks "installer-mac" || true
    if [ "$_sl_sk_n" -gt 0 ]; then
        echo "  ✅ 呼び出し口を配置しました (機能 ${_sl_sk_n} 件 / 専門の担当 ${_sl_ag_n} 件)"
        [ "$_SL_MANIFEST_MISS" -gt 0 ] && \
          echo "  ⚠️  うち ${_SL_MANIFEST_MISS} 件は導入台帳へ記録できませんでした (ご利用は始められます)"
    else
        add_issue "呼び出し口の配置" "Claude Code から呼び出すための配置ができませんでした。この画面を添えて nomura.y@soloptilink.com までご連絡ください"
    fi
else
    add_issue "呼び出し口の配置" "同梱されているはずの機能一式が見つかりませんでした。この画面を添えて nomura.y@soloptilink.com までご連絡ください"
fi
echo ""

set_phase "品質チェックの設定" "このファイルをもう一度ダブルクリックしてください。設定だけをやり直します。"
echo "[STEP 5.6/6] 品質・信頼性フックを登録"
# 【P3 是正 2026-08-17】設定用スクリプトの置き場所は 2 か所ある
# ------------------------------------------------------------
# 何が起きていたか:
#   設定用スクリプトは migration/ と lib/migration/ の 2 か所に分かれて同梱
#   されているが、ここは前者しか走査していなかった。そのため Mac のお客様は
#   「本番モードの封緘」と「常駐チェック機能の登録」の 2 件が一度も適用されない。
#   Linux の入口はこの 2 件を名指しで実行していたので、入口によって端末の
#   状態が食い違っていた。両方の置き場所を走査して揃える。
# 【P3 是正 (第2波) 2026-08-17】走査条件を 3 つの入口で v*.sh に統一する。
#   lib/migration/ 側だけ *.sh にしていたため、社内ツリーでは自己実証用の
#   テストスクリプトまで「設定」として実行・計上される作りだった。
#   適用できなかった件数も数え、成功したことにしない。
_MIG_N=0
_MIG_NG=0
# >>> SOLOPTILINK-MIGRATION-SCAN-BEGIN
#   ★ここから END までが「設定用スクリプトの走査条件」の正体。
#     3 つの入口 (Mac / Windows / Linux) で同じ条件になっているかを、
#     常設検査 L233-INSTALL-ENTRY-PARITY がこの区間だけを実際に走らせて確かめる。
#     区間の外へ条件を書くと、入口ごとの食い違いが再発しても検査に映らない。
# ★2026-10-26: 並び順を言語設定に左右させない。ja_JP.UTF-8 では v2056_* が v2056.10_* より
#   先に並び、応答の見張り 2 本の直接登録が「外す処理 (v2056.10_answer_opinion_direct_unwire)」の
#   前提 (response-gate.sh の登録) より先に入って、導入直後は Stop で 2 回ずつ走る (砂箱で実測)。
#   Windows (Get-ChildItem) と同じ順 (. が _ より前) にそろえる。
_SL_SAVED_LC_COLLATE="${LC_COLLATE-}"
LC_COLLATE=C
for _migdir in "$HOME/.soloptilink/migration" "$HOME/.soloptilink/lib/migration"; do
    [ -d "$_migdir" ] || continue
    for _mig in "$_migdir/"v*.sh; do
        [ -f "$_mig" ] || continue
        # v2027 は直前で実行済み (二重実行しても冪等だが、無駄な処理を避ける)
        case "$_mig" in *v2027_hook_install.sh) continue ;; esac
        if bash "$_mig" >/dev/null 2>&1; then
            _MIG_N=$((_MIG_N + 1))
        else
            _MIG_NG=$((_MIG_NG + 1))
        fi
    done
done
if [ -n "$_SL_SAVED_LC_COLLATE" ]; then LC_COLLATE="$_SL_SAVED_LC_COLLATE"; else unset LC_COLLATE; fi
# <<< SOLOPTILINK-MIGRATION-SCAN-END
if [ "$((_MIG_N + _MIG_NG))" -gt 0 ]; then
    # ★2026-09-29: 以前は「設定処理が正常に終わった数」を有効化した項目数として表示していた。
    #   前提ソフト (python3) が動かない端末では、処理は正常に終わっても登録は行われないため、
    #   「25 項目」と出ながら実際に登録されたのは 2 本だった (砂箱で実測)。
    #   設定ファイルに実際に登録された自動チェックの数を数えて表示する。
    _MIG_HOOKS="$(grep -o '\.soloptilink/' "$HOME/.claude/settings.json" 2>/dev/null | wc -l | tr -d ' ')"
    echo "  ✅ 品質・信頼性の自動チェックの設定を適用しました (いま有効な自動チェック: ${_MIG_HOOKS:-0} 件)"
    if [ "$_MIG_NG" -gt 0 ]; then
        echo "  ⚠️  ${_MIG_NG} 件は適用できませんでした (ご利用は始められます)"
        echo "     次にしていただくこと: このファイルをもう一度ダブルクリックしてください。それでも同じ表示が続く場合は、この画面を添えて nomura.y@soloptilink.com までご連絡ください。"
    fi
else
    echo "  ℹ️  追加で有効化する項目はありませんでした"
fi
echo ""

# ---------------------------------------------------------------------------
# スキル自動連動の登録 (R4-09 / 2026-09-16 新設)
# ---------------------------------------------------------------------------
# 【塞ぐ穴】お客様が 1 文お書きになるたびに適した機能を選ぶ「振り分け」は、
#   端末側の設定 (~/.claude/settings.json の UserPromptSubmit) に登録されて
#   はじめて走る。2026-09-16 に呼び出し件数を数えたところ、登録する道具
#   lib/sar-linkage/wire-sar-hook.sh を呼んでいたのは Linux の setup.sh だけで、
#   **この Mac のダブルクリック経路と Windows 経路は 0 件**だった。
#   Mac のお客様が案内どおりダブルクリックで導入すると、自動連動は一度も走らない。
#   3 経路 (Mac / Windows / Linux) で端末の状態をそろえる。
# 【二重化】migration/v2056.9_sar_gate_wire.sh も同じ登録を行う。どちらが先でも
#   結果は同じ (登録済みなら何もしない)。ここに直接置くのは、migration の走査が
#   何らかの理由で止まった端末でも登録が残るようにするため。
# 【壊さない】設定が JSON として読めないときは、道具の側が書き換えずに止まる。
# 【止めない】登録できなくても導入は続ける。ただし黙らない。
# kill-switch: SOLOPTILINK_SAR_WIRE=off (既定 on)
# >>> SOLOPTILINK-SAR-WIRE-BEGIN
#   ★ここから END までが「振り分けを登録する工程」の正体。3 つの入口で同じ工程を
#     持ち、検査はこの区間だけを実際に走らせて確かめる。
echo "スキル自動連動の設定"
_SAR_WIRE_SH="$HOME/.soloptilink/lib/sar-linkage/wire-sar-hook.sh"
if [ "${SOLOPTILINK_SAR_WIRE:-on}" = "off" ]; then
    echo "  ℹ️  設定で切られているため、自動連動の登録は行いませんでした"
elif [ ! -f "$_SAR_WIRE_SH" ]; then
    echo "  ⚠️  自動連動の部品が見つかりませんでした"
    echo "     次にしていただくこと: この画面を添えて nomura.y@soloptilink.com までご連絡ください。"
else
    # ★この台本は set -e で走っている。登録できなかったとき (壊れた設定・退去済み) は
    #   0 以外が返るため、|| true を付けないと導入そのものが途中で止まる。
    #   「登録できないこと」は導入を止める理由ではない。
    _SAR_OUT="$(bash "$_SAR_WIRE_SH" apply 2>&1)" || true
    if bash "$_SAR_WIRE_SH" check >/dev/null 2>&1; then
        echo "  ✅ ご用件に合う機能を自動で選ぶ設定を登録しました"
        _SAR_MF="$(bash "$_SAR_WIRE_SH" manifest 2>/dev/null | tr -dc '0-9')" || _SAR_MF=""
        if [ "${_SAR_MF:-0}" -ge 2 ] 2>/dev/null; then
            echo "  ✅ 導入台帳へ記録しました (${_SAR_MF} 件。ご解約時にこの2件も取り除かれます)"
        else
            echo "  ⚠️  登録はできましたが、導入台帳へは記録できませんでした"
            echo "     次にしていただくこと: このファイルをもう一度ダブルクリックしてください。"
        fi
    elif printf '%s' "$_SAR_OUT" | grep -q '退去済み'; then
        echo "  ℹ️  ご解約済みの端末のため、自動連動の登録は行いませんでした"
    elif printf '%s' "$_SAR_OUT" | grep -q '読めない'; then
        # お客様の設定は書き換えていない。何をすればよいかまで書く
        echo "  ⚠️  設定ファイル (~/.claude/settings.json) を読み取れないため、登録を見送りました"
        echo "     ★お客様の設定は一切書き換えていません。"
        echo "     次にしていただくこと: 設定ファイルの書式をご確認いただくか、この画面を添えて nomura.y@soloptilink.com までご連絡ください。"
    else
        echo "  ⚠️  自動連動の設定を登録できませんでした (ご利用は始められます)"
        echo "     次にしていただくこと: このファイルをもう一度ダブルクリックしてください。"
    fi
fi
# <<< SOLOPTILINK-SAR-WIRE-END
# 試用端末の登録命令全体を関所で覆う。有料端末の設定は変更しない。
[ ! -f "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" ] || bash "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" >/dev/null 2>&1 || true
echo ""

# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# STEP 5.5/6: 接続の安定化
# ---------------------------------------------------------------------------
# 企業ネットワークの内側では、ご利用に不要な通信 (利用統計の送信・エラー報告) が
#   セキュリティ機器に遮断されることがあり、その待ち時間で起動が止まる。
#   導入時に止めておけば、企業ネットワークでも初回から動く。
#   ★ご利用に必要な通信は一切止めない。既存の設定も壊さない (env へ追記のみ)。
#   ★Windows 側 (soloptilink-install.ps1 の STEP 10.6) と同じ設定を入れる。
#     入口ごとに端末の状態が食い違うと、後から原因が分からなくなるため。
echo "[STEP 5.5/6] 接続を安定化"
# >>> SOLOPTILINK-NETWORK-STABILIZE-BEGIN
# ★2026-10-29: 足し方と記録の仕方は移行の台本 v2056.3 の 1 本だけが持つ (ここは呼ぶだけ)。
#   ・3 つの名前のうち設定に無いものだけを足す。お客様が既に設定していた名前は値を変えない
#     (以前はここで 3 つとも "1" で上書きしていた)
#   ・当社が足した名前だけを ~/.claude/.soloptilink-settings-added.json に記録する
#     (ご解約のときの撤去は、この記録にある名前だけを外す)
#   ・全文の控えは作らない。読めない・想定外の形の設定は 1 バイトも書き換えない
#   ・python3 が動かない端末では jq で同じことをする (どちらも無ければ次回の更新で適用する)
#   STEP 5.6 で移行の台本をすべて回しているので、多くの端末ではここに来る前に済んでいる。
_ns_mig="$HOME/.soloptilink/migration/v2056.3_network_stabilize.sh"
_ns_out=""
if [ -f "$_ns_mig" ]; then
    _ns_out="$(SL_NETSTAB_BY=installer-mac bash "$_ns_mig" 2>/dev/null)" || _ns_out=""
fi
case "$_ns_out" in
    *"network-stabilize: applied"*|*"network-stabilize: already applied"*)
        echo "  ✅ 接続を安定化しました (社内ネットワークでも動作します。既に設定されていた項目は変えていません)" ;;
    *"no usable json tool"*)
        echo "  ⚠️  接続の安定化は次回起動時に適用します (ご利用は始められます)" ;;
    *)
        echo "  ⚠️  接続の安定化を適用できませんでした (ご利用は始められます)" ;;
esac
# ご利用確認の接続先を供給する (未設定の端末のみ・既存の指定は尊重)
_ns_urlfile="$HOME/.soloptilink/.license/.server_url"
if [ ! -f "$_ns_urlfile" ]; then
    mkdir -p "$HOME/.soloptilink/.license" 2>/dev/null || true
    printf '%s\n' "https://admin-dashboard-blue-alpha-78.vercel.app" > "$_ns_urlfile" 2>/dev/null || true
    chmod 600 "$_ns_urlfile" 2>/dev/null || true
fi
# 通信の確認: 通らない場合はここで気づけるようにする (導入後に詰まらせない)
if command -v curl >/dev/null 2>&1; then
    # ★ 2026-09-02 是正: 実際に使う通信先をすべて確かめる。
    #   従来は Claude の窓口 (api.anthropic.com) だけを見ていたため、
    #   会社のネットワークで他の通信先が遮断されている環境では
    #   「通信の確認: 問題ありません」と表示した直後に、
    #   ご利用の確認や本体の取得で止まっていた。
    #   どれが通っていないかを名指しでお伝えする。
    _net_ng=""
    _net_check() {   # $1=表示名  $2=URL
        if curl -s -o /dev/null -m 12 --connect-timeout 8 "${2}" 2>/dev/null; then
            echo "  ✅ ${1}: つながりました"
        else
            echo "  ⚠️  ${1}: つながりません"
            _net_ng="${_net_ng}${_net_ng:+ / }${1}"
        fi
    }
    _net_check "ご利用の確認・更新の受付" "${API_BASE%/api/v1}/"
    _net_check "ソフトウェアの配布元"     "https://github.com/"
    _net_check "Claude の窓口"           "https://api.anthropic.com/"
    if [ -z "${_net_ng}" ]; then
        echo "  ✅ 通信の確認: すべて問題ありません"
    else
        echo ""
        echo "  ⚠️  次の通信先に届いていません: ${_net_ng}"
        echo "     会社のネットワークの設定により遮断されている可能性があります。"
        echo "     次にしていただくこと: この画面を添えて nomura.y@soloptilink.com までご連絡ください。"
        echo "     上記の通信先を許可していただくための案内をお送りします。"
        echo "     (このまま進めた場合、ご利用の確認や更新の受け取りで止まることがあります)"
    fi
fi
# <<< SOLOPTILINK-NETWORK-STABILIZE-END

# STEP 6/6: Claude Desktop MCP 設定 + 端末認証起動
# ---------------------------------------------------------------------------
# ★見出しの「MCP」はお客様には通じない内部用語だった
set_phase "Claude Desktop との連携設定と端末のご登録" "インターネットの接続をご確認のうえ、このファイルをもう一度ダブルクリックしてください。二重にご登録されることはありません。"
echo "[STEP 6/6] Claude Desktop との連携設定 + 端末の登録"

# >>> SOLOPTILINK-DESKTOP-MCP-BEGIN
# ★2026-10-28: 既存の設定の全文の控え (claude_desktop_config.json.bak.<日時>) は作らない。
#   控えには他社の接続先の鍵などがそのまま写り、消す処理がどこにも無いまま残り続けていた。
#   また、読めない設定を空とみなして当社の登録だけで上書きしていた (ほかの連携の登録が消える)。
#   読めない・想定外の形の設定は 1 バイトも書き換えずに要対応へ回し、書くときは共通の書き込み関数で
#   読み直して確かめてから置き換える。
CLAUDE_CONFIG="$HOME/Library/Application Support/Claude/claude_desktop_config.json"
mkdir -p "$(dirname "$CLAUDE_CONFIG")"

# python3 で安全に MERGE (既存 mcpServers を保持)
# ★python3 が無い場合の扱い (T-702)
#   従来はここで終了コード 127 になり、ERR トラップが発火して導入が丸ごと中断していた。
#   その結果、直後にある端末認証まで到達できず、お客様は登録すらできないまま終わる。
#   設定の書き換えは「検査」ではなく「作業」なので、行えなかった事実を要対応へ
#   集約したうえで、端末認証へは進む (前提ソフト工程と同じ fail-open の作法)。
# ★ここも「在るか」ではなく「動くか」で判定する。
#   開発ツール未導入の macOS では python3 の入口だけが実在するため、
#   存在確認だけだと先へ進んでしまい、設定の書き込みが途中で失敗する。
if ! { command -v python3 >/dev/null 2>&1 && python3 --version >/dev/null 2>&1; }; then
    echo "  ⚠️  Claude Desktop への登録は行えませんでした (Python 3 がこの端末で動きません)"
    # ★2026-08-15 是正: ここには「ターミナルを開いて 1 行を貼り付ける」手順と、
    #   その打ち込む内容そのものが書かれていた。開く場所まで書いてあっても、
    #   ターミナルを使ったことのないお客様には荷が重く、打ち間違いの余地も残る。
    #   このセットアップは実行のたびに Apple の導入画面を自分で呼び出しているので、
    #   「もう一度ダブルクリックすれば、その画面がまた出る」だけを案内すれば足りる。
    #   打ち込みを求めない案内に統一する (お客様の画面に打ち込むものを出さない)。
    add_issue "Claude Desktop への登録" "$(cat <<'PY3ISSUE'
Python 3 を導入したあと、このファイルをもう一度ダブルクリックしてください。
Python 3 の入れかた:
  1. 画面に『コマンドラインデベロッパツールをインストールしますか?』という
     Apple の確認画面が出ていれば、[インストール] を押して終わるまでお待ちください
     (Python 3 はこの中に含まれます)。
  2. その画面が見当たらないときは、このファイルをもう一度ダブルクリックしてください。
     Apple の確認画面をあらためてお出しします。
  3. 導入が終わったら、このファイルをもう一度ダブルクリックしてください。
うまくいかないときは nomura.y@soloptilink.com までご連絡ください。
PY3ISSUE
)"
else
_SL_DESKTOP_RC=0
SOLOPTILINK_BIN="$HOME/.soloptilink/soloptilink" python3 - "$CLAUDE_CONFIG" <<'PYEOF' || _SL_DESKTOP_RC=$?
import json, sys, os

# >>> sl-safe-settings-write v2 (2026-10-29) >>>
# お客様の設定の全文の控えは作らない。控えには環境変数や許可の設定がそのまま写り、
# 消す処理がどこにも無いまま残り続けていた。読めた設定だけを一時ファイルに書き、
# JSON として読み直してから原子的に置き換える。読んでから置き換えるまでに
# 別の処理が設定を書いていたら、上書きせずに次の起動でやり直す。
# 設定がリンクのときはリンクを残し、リンク先の実体を同じ手順で置き換える。
# 撤去の段 3 と同じ扱いにそろえた (2026-10-29 独立審査で指摘)。
# v1 はリンクそのものを普通のファイルに置き換え、お客様の管理の先から切り離していた。
# 壊れたリンクと、読んでから置き換えるまでに行き先が変わったリンクには書かずに止める。
def sl_safe_settings_write(path, data, before):
    import json as _json, os as _os, stat as _stat
    target = _os.path.realpath(path)
    folder = _os.path.dirname(target) or "."
    tmp = _os.path.join(folder, "." + _os.path.basename(target) + ".sl-new.%d" % _os.getpid())
    flags = _os.O_WRONLY | _os.O_CREAT | _os.O_EXCL | getattr(_os, "O_NOFOLLOW", 0)
    try:
        fd = _os.open(tmp, flags, 0o600 if before is not None else 0o666)
    except OSError:
        return False
    try:
        with _os.fdopen(fd, "w", encoding="utf-8") as handle:
            if before is not None:
                try:
                    _os.fchmod(handle.fileno(), _stat.S_IMODE(before.st_mode))
                except (AttributeError, OSError):
                    pass
            _json.dump(data, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            _os.fsync(handle.fileno())
        with open(tmp, encoding="utf-8") as handle:
            if not isinstance(_json.load(handle), dict):
                return False
        if _os.path.realpath(path) != target:
            return False
        if before is not None:
            now = _os.stat(path)
            if (now.st_ino, now.st_size, now.st_mtime_ns) != (before.st_ino, before.st_size, before.st_mtime_ns):
                return False
        elif _os.path.lexists(path):
            return False
        _os.replace(tmp, target)
        return True
    except Exception:
        return False
    finally:
        if _os.path.lexists(tmp) and not _os.path.islink(tmp):
            try:
                _os.unlink(tmp)
            except OSError:
                pass
# <<< sl-safe-settings-write v2 <<<

cfg_path = sys.argv[1]
bin_path = os.environ['SOLOPTILINK_BIN']
before = None
cfg = {}
if os.path.exists(cfg_path):
    try:
        before = os.stat(cfg_path)
        with open(cfg_path, encoding='utf-8') as f:
            raw = f.read()
        if raw.strip():
            cfg = json.loads(raw)
    except Exception:
        sys.exit(3)          # 読めない設定は作り直さない (ほかの連携の登録を消してしまうため)
if not isinstance(cfg, dict):
    sys.exit(3)
servers = cfg.get('mcpServers')
if servers is None:
    servers = cfg['mcpServers'] = {}
if not isinstance(servers, dict):
    sys.exit(3)
servers['soloptilink'] = {'command': bin_path, 'args': ['--mcp-server']}
if not sl_safe_settings_write(cfg_path, cfg, before):
    sys.exit(4)
# ★「MCP サーバー」はお客様には通じない内部用語だった
print("  ✅ Claude Desktop との連携を登録しました")
PYEOF
if [ "$_SL_DESKTOP_RC" -eq 3 ]; then
    echo "  ⚠️  Claude Desktop の設定ファイルを読み取れないため、連携の登録を見送りました"
    echo "     ★お客様の設定は一切書き換えていません。"
    add_issue "Claude Desktop との連携" "Claude Desktop の設定ファイル (~/Library/Application Support/Claude/claude_desktop_config.json) を読み取れないため、連携を登録していません。お客様の設定は一切書き換えていません。設定ファイルの書式をご確認いただくか、この画面を添えて nomura.y@soloptilink.com までご連絡ください"
elif [ "$_SL_DESKTOP_RC" -ne 0 ]; then
    echo "  ⚠️  Claude Desktop との連携を登録できませんでした (設定は元のままです。ご利用は始められます)"
    add_issue "Claude Desktop との連携" "Claude Desktop を完全に終了 (⌘+Q) してから、このファイルをもう一度ダブルクリックしてください。何度実行しても二重に登録されることはありません。解消しない場合は nomura.y@soloptilink.com までご連絡ください"
fi
fi
# <<< SOLOPTILINK-DESKTOP-MCP-END

# ★すでに登録済みなら、入力を求めずに飛ばす。
#   【なぜ要るか】案内はどれも「もう一度ダブルクリックしてください」で終わるが、
#   Mac 側にはこの事前確認が無かったため、再実行するたびに必ず入力待ちへ戻っていた。
#   お客様が席を離れていると、そこで止まったまま完了しない (申告①の「放置したが
#   完了しなかった」に直結する)。Windows 側には同等の確認が実装済みで、
#   これも Mac だけが取り残されていた片側実装である。
#
# ★★ 登録済みと判断してよい条件 ★★
#   【起きたこと】一度目の登録に失敗したあと、何度セットアップをやり直しても
#   「すでに登録済みです」と表示され、メールアドレスの入力を二度と求められない。
#   申請が一件も送られないため、お客様は「申請したのに承認されない」、
#   当社は「申請が届いていない」という食い違いのまま止まっていた。
#   【原因】従来はここで「認証系ファイルを1つでも引き継げたか (AUTH_CARRIED)」を
#   登録済みの根拠にしていた。しかし .device_identity.json (端末の指紋) は
#   登録の成否によらず作られるため、登録に失敗した端末でも必ず条件を満たす。
#   一度失敗すると二度と登録できない、出口のない状態に入る。
#   【是正】登録が済んだ証拠は activation.json と license.json がそろっていること。
#   その上で本体自身に状態を尋ね、肯定が取れたときにだけ入力を省く。
#   証拠が無いときは必ず登録工程へ進む (飛ばして完了に見せることを禁ずる)。
#   【判断の材料をサーバ照会にしない理由】
#   登録の有無をサーバへの問い合わせ結果で決めると、接続が不調なだけの端末を
#   「未登録」と読み、逆に問い合わせが通らないときの既定値しだいでは未登録の端末を
#   「登録済み」と読む。どちらも接続状態しだいで結論が変わってしまう。
#   端末に残る登録の記録 (license.json の状態) で判断すれば、接続に左右されない。
#   これは診断 (self-check) が使っている基準と同じものであり、
#   「診断は未登録と言うのにセットアップは登録済みと言う」食い違いも同時に無くなる。
cd "$HOME/.soloptilink"
# >>> SOLOPTILINK-ACTIVATION-SECTION-BEGIN
#     端末のご登録の区間。印の内側を切り出し、砂箱 (別の HOME と偽のサーバー) で
#     実際に走らせて確かめている。登録の処理をこの印の外へ書かないこと。

# ── ご利用資格の記録 (license.json) の取り寄せ (2026-09-25 新設) ──
# 【何が起きていたか】登録 (--activate) が保存するのはお申し込みの記録 (activation.json)
#   だけで、ご利用資格の記録 (license.json) は状態の確認 (--status) をしたときにしか
#   作られない。このセットアップは登録のあと状態の確認を一度も呼ばなかったため、
#   サーバー側では承認済みでも、直後の導入診断は「5 ご契約端末としての登録」が × になった。
#   しかも診断の案内 (入力は不要・セットアップをやり直してください) どおりにやり直すと、
#   下の「登録済みなら入力を省く」判定が license.json まで要求していたため、
#   再びメールアドレスとパスワードの入力に戻る行き止まりになっていた。
# 【ここでしていること】状態の確認を時間の上限つきで 1 回だけ呼び、結果を 1 語にまとめる。
#     approved … 承認済み (license.json が承認済みで作られたことを実物で確かめた)
#     pending  … 承認待ち (サーバーの回答。承認待ちの端末には license.json は作られない)
#     unknown  … それ以外 (通信できない・時間切れ・その他の回答)
#   まとめた結果は導入診断へ渡し、承認待ちを × ではなく「手続き中」と表示させる。
#   ★承認済みかどうかは必ず license.json の実物で判断する (画面の文言だけで承認済みと言わない)。
#   ★承認待ちの判定は、ランチャーの状態表示の「ステータス: … 承認待ち」の行を読む
#     (launcher/main.go runStatusCheck)。読めなくなっても unknown に倒れ、従来どおりの × に戻るだけで、
#     合格側へは倒れない。
# 【止めない】失敗しても時間切れでも導入は続ける。macOS には timeout コマンドが無いため自前で打ち切る。
#   画面の出力は控えのファイルへ回して見せない (状態表示には打ち込み命令の案内が含まれるため)。
_SL_REG_STATUS=""
_sl_license_sync() {
    # $1 = 待つ上限 (秒)
    local _limit="${1:-20}" _out="" _pid="" _ticks=0
    local _lic="$HOME/.soloptilink/license.json" _logd="$HOME/.soloptilink/logs"
    _SL_REG_STATUS="unknown"
    _out="$(mktemp "${TMPDIR:-/tmp}/soloptilink-status.XXXXXX" 2>/dev/null)" || _out=""
    [ -n "$_out" ] || return 0
    SOLOPTILINK_ACTIVATE_NO_WAIT=1 "$HOME/.soloptilink/soloptilink" --status >"$_out" 2>&1 </dev/null &
    _pid=$!
    while kill -0 "$_pid" 2>/dev/null; do
        if [ "$_ticks" -ge $((_limit * 5)) ]; then
            kill "$_pid" 2>/dev/null || true
            sleep 1
            kill -9 "$_pid" 2>/dev/null || true
            break
        fi
        sleep 0.2
        _ticks=$((_ticks + 1))
    done
    wait "$_pid" 2>/dev/null || true
    if [ -f "$_lic" ] && LC_ALL=C grep -Eq '"status"[[:space:]]*:[[:space:]]*"approved"' "$_lic" 2>/dev/null; then
        _SL_REG_STATUS="approved"
    elif LC_ALL=C grep -q 'ステータス:.*承認待ち' "$_out" 2>/dev/null; then
        _SL_REG_STATUS="pending"
    # ★2026-09-29: ランチャーは拒否・取り消し・契約終了・一時停止・未登録をはっきり表示するが、
    #   従来はそれを読み分けず unknown に丸めていたため、画面は必ず「インターネットの接続を
    #   ご確認ください」になり、何度やり直しても抜けられない行き止まりになっていた
    #   (起動プログラムを模型に差し替えて 2 回やり直し、2 回とも再現)。Windows 側と同じ基準。
    elif LC_ALL=C grep -q 'ステータス:.*拒否' "$_out" 2>/dev/null; then
        _SL_REG_STATUS="rejected"
    elif LC_ALL=C grep -q 'ステータス:.*取り消し' "$_out" 2>/dev/null; then
        _SL_REG_STATUS="revoked"
    elif LC_ALL=C grep -q 'ステータス:.*ご契約期間が終了' "$_out" 2>/dev/null; then
        _SL_REG_STATUS="contract_ended"
    elif LC_ALL=C grep -q 'ステータス:.*一時停止' "$_out" 2>/dev/null; then
        _SL_REG_STATUS="suspended"
    elif LC_ALL=C grep -q 'ステータス:.*ご契約端末として登録されていません' "$_out" 2>/dev/null; then
        _SL_REG_STATUS="unregistered"
    fi
    mkdir -p "$_logd" 2>/dev/null || true
    printf '%s license-sync result=%s limit=%ss waited=%sx0.2s\n' \
        "$(date +%Y-%m-%dT%H:%M:%S)" "$_SL_REG_STATUS" "$_limit" "$_ticks" \
        >> "$_logd/setup-license-sync.log" 2>/dev/null || true
    rm -f "$_out" 2>/dev/null || true
    return 0
}

# 登録の状態が「通信の問題ではない」ときの案内を 1 か所にまとめる (2026-09-29 / Windows と同じ基準)
#   案内を出したら 0 を返す (呼び出し側は通信の案内を出さない)。該当しなければ 1。
_sl_state_guide() {
    local _c="nomura.y@soloptilink.com"
    case "$1" in
        rejected)
            echo "  ⚠️  この端末のご登録は、弊社で承認できない状態になっています"
            echo "     セットアップをやり直しても状態は変わりません。お手数ですが ${_c} までご連絡ください"
            add_issue "端末の登録" "ご登録が承認されていません。セットアップのやり直しでは解消しません。${_c} までご連絡ください"
            return 0 ;;
        revoked)
            echo "  ⚠️  この端末のご利用は、弊社側で取り消されています"
            echo "     セットアップをやり直しても状態は変わりません。お心当たりがない場合は ${_c} までご連絡ください"
            add_issue "端末の登録" "この端末のご利用が取り消されています。セットアップのやり直しでは解消しません。${_c} までご連絡ください"
            return 0 ;;
        contract_ended)
            echo "  ⚠️  ご契約期間が終了しているため、専用機能はお休みしています"
            echo "     通常の Claude Code としてはこのままお使いいただけます。ご継続をご希望の場合は ${_c} までご連絡ください"
            add_issue "ご契約" "ご契約期間が終了しています。ご継続をご希望の場合は ${_c} までご連絡ください"
            return 0 ;;
        suspended)
            echo "  ⚠️  ご利用を一時停止している状態です"
            echo "     通常の Claude Code としてはこのままお使いいただけます。お心当たりがない場合は ${_c} までご連絡ください"
            add_issue "ご契約" "ご利用を一時停止しています。お心当たりがない場合は ${_c} までご連絡ください"
            return 0 ;;
        unregistered)
            echo "  ⚠️  この端末のご登録の記録が、弊社のサーバーで見つかりませんでした"
            echo "     セットアップをやり直しても状態は変わりません。お手数ですが ${_c} までご連絡ください"
            add_issue "端末の登録" "ご登録の記録がサーバーで見つかりません。セットアップのやり直しでは解消しません。${_c} までご連絡ください"
            return 0 ;;
    esac
    return 1
}

_ALREADY_REGISTERED=0
_SL_NEED_LICENSE_SYNC=0
if [ -f "$HOME/.soloptilink/activation.json" ] && [ -f "$HOME/.soloptilink/license.json" ]; then
    if LC_ALL=C grep -Eq '"status"[[:space:]]*:[[:space:]]*"(approved|pending|waiting)"' \
        "$HOME/.soloptilink/license.json" 2>/dev/null; then
        _ALREADY_REGISTERED=1
    else
        # ★ 2026-09-02 追加: 記録はあるのに中身が読み取れない場合の案内。
        #   書き込みの途中で電源が落ちた・空き容量が尽きたなどで記録が壊れると、
        #   毎回この画面に戻ってくることになり、お客様には「何度やり直しても
        #   同じ」としか見えない。何が起きていて、どうすれば抜けられるかを伝える。
        echo ""
        echo "  ⚠️  前回の登録の記録が残っていますが、内容を読み取れませんでした。"
        echo "     書き込みの途中で中断されたか、空き容量が不足していた可能性があります。"
        echo "     このまま登録をやり直しても同じ状態が続く場合は、"
        echo "     次の2つのファイルを削除してから、もう一度この画面を開いてください。"
        echo "       ~/.soloptilink/activation.json"
        echo "       ~/.soloptilink/license.json"
        echo "     ご不明な点は nomura.y@soloptilink.com までご連絡ください。"
        echo ""
    fi
elif [ -f "$HOME/.soloptilink/activation.json" ] && \
     LC_ALL=C grep -Eq '"device_id"[[:space:]]*:[[:space:]]*"dev_' "$HOME/.soloptilink/activation.json" 2>/dev/null; then
    # ★2026-09-25 新設: お申し込みは届いているが、ご利用資格の記録だけが無い端末。
    #   (承認がお申し込みより後になった端末 / 登録直後の取り寄せが時間切れになった端末)
    #   導入診断はこの状態に「入力は不要・セットアップをやり直してください」と案内する。
    #   その案内と実際の動きを一致させるため、入力は求めず、状態の確認だけで取り寄せを試みる。
    #   根拠にするのは device_id (dev_ で始まる)。サーバーが登録を受け付けたときにだけ書かれる。
    #   登録の成否によらず作られる端末の指紋 (.device_identity.json) は、従来どおり根拠に数えない。
    #   Windows 側は同じ基準 (activation.json の device_id) で 2026-09-01 から入力を省いている。
    _ALREADY_REGISTERED=1
    _SL_NEED_LICENSE_SYNC=1
fi

if [ "$_ALREADY_REGISTERED" -eq 1 ] && [ "$_SL_NEED_LICENSE_SYNC" -eq 1 ]; then
    echo ""
    echo "  この端末のお申し込みは届いています (入力は不要です)。"
    echo "  ご登録の状態を確認しています..."
    # 休止明けのサーバーは最初の応答に時間がかかることがあるため、登録直後 (20 秒) より長く待つ。
    # Windows 側の同じ場面 (60 秒) と揃えてある。
    _sl_license_sync 60
    case "$_SL_REG_STATUS" in
        approved)
            echo "  ✅ ご登録が承認済みであることを確認し、ご利用の準備を整えました" ;;
        pending)
            echo "  ⏳ ご登録は受け付け済みで、弊社の承認をお待ちいただいている状態です"
            echo "     承認のご連絡を受け取ったあとに、このファイルをもう一度ダブルクリックしてください (入力は不要です)" ;;
        rejected|revoked|contract_ended|suspended|unregistered)
            _sl_state_guide "$_SL_REG_STATUS" || true ;;
        *)
            echo "  ⚠️  ご登録の状態を、いまは確認できませんでした"
            echo "     インターネットの接続をご確認のうえ、しばらくしてからこのファイルをもう一度ダブルクリックしてください (入力は不要です)"
            echo "     何度やり直しても変わらない場合は、この画面の写真を撮って nomura.y@soloptilink.com までお送りください" ;;
    esac
    echo ""
elif [ "$_ALREADY_REGISTERED" -eq 1 ]; then
    echo ""
    echo "  ✅ この端末はすでに登録済みです (入力は不要です)"
    echo ""
else

echo ""
echo "  ── この端末のご登録 ──"
echo ""
echo "  このあと、メールアドレスとパスワードの入力をお願いします。"
echo "  当社からお送りしたご案内メールをお手元にご用意ください。"
echo ""
echo "  ※ パスワードは、安全のため入力しても画面には表示されません。"
echo "     これは正常な動作です。そのまま最後まで入力してください。"
echo ""
sleep 3

# 端末認証を自動チェーン
# 承認待ちポーリング(最大30分)はインストーラ内では行わない
# (登録だけ行い即座に完了画面へ。承認後は自動で有効になる)。
SOLOPTILINK_ACTIVATE_NO_WAIT=1 ./soloptilink --activate || {
    # ★従来はここに打ち込むコマンドを並べていたが、
    #   ターミナルを使わないお客様には実行できない案内だった。
    #   もう一度ダブルクリックすれば同じ登録がやり直せるので、それだけを案内する。
    # ★ここで打ち切らない。
    #   【この実装が必要な理由】従来はここで導入そのものを終了していた。そのため、
    #   前提ソフトの工程が積み上げた「要対応一覧」も、導入の自己診断も、完了画面も
    #   一つも表示されないまま終わっていた。お客様の画面には「登録できませんでした」
    #   だけが残り、他に何が終わっていて何が残っているのかが分からない。
    #   Windows 側は同じ場面で続行し、要対応をまとめて出してから終わる。
    #   ここも同じ形に揃え、最後まで進んでから未完了をまとめてお伝えする。
    echo ""
    echo "  ⚠️  ご登録が完了しませんでした (この後の案内をあわせてご確認ください)"
    echo ""
    # ★案内の順番を、実際に多い原因の順に改めた (2026-08-17)
    #   従来は「インターネット接続をご確認ください」を先頭に置いていたが、
    #   ここまでの工程 (本体の取得・前提ソフトの導入) が終わっている時点で
    #   接続はほぼ確実に生きている。実際に多いのは入力のつまずきであり、
    #   先頭の一文が当たらないと、お客様は確かめようのない項目から順に試すことになる。
    add_issue "端末の登録" "端末のご登録が完了していません。当社からお送りしたご案内メールに記載のメールアドレスとパスワードをご確認のうえ、このファイルをもう一度ダブルクリックしてください (二重に登録されることはありません)。パスワードは入力しても画面に表示されませんが、正しく受け付けています。パスワードが分からない場合や、解消しない場合は、この画面の写真を撮って nomura.y@soloptilink.com までお送りください"
    ACTIVATION_FAILED=1
}
# ★2026-09-25 新設: 登録が通ったら、その場でご利用資格の記録を取り寄せる
#   (理由と結果の読み方は上の _sl_license_sync の注記を参照)。
#   登録の直後はサーバーが応答できる状態にあるため、待つ上限は 20 秒にとどめる。
#   取り寄せられなくても導入は止めない。やり直せば入力なしで取り寄せを試みる。
if [ "${ACTIVATION_FAILED:-0}" != "1" ]; then
    echo ""
    echo "  ご登録の状態を確認しています..."
    _sl_license_sync 20
    case "$_SL_REG_STATUS" in
        approved)
            echo "  ✅ ご登録が承認済みであることを確認しました。このままお使いいただけます" ;;
        pending)
            echo "  ⏳ ご登録を受け付けました。弊社の承認が済みしだい、お使いいただけるようになります" ;;
        rejected|revoked|contract_ended|suspended|unregistered)
            _sl_state_guide "$_SL_REG_STATUS" || true ;;
        *)
            echo "  ご登録は受け付けましたが、承認の状態はこの場では確認できませんでした"
            echo "  承認のご連絡を受け取ったあとに、このファイルをもう一度ダブルクリックすると確認できます (入力は不要です)" ;;
    esac
fi
fi   # ★T-3: 登録済み事前確認の分岐ここまで
# <<< SOLOPTILINK-ACTIVATION-SECTION-END
# 導入した当社のファイルを導入時の台帳（~/.claude/.soloptilink-file-manifest.jsonl）へ記録する（2026-11-01）。
#   自動更新（auto-update.sh）は更新のたびにこの台帳を取り直すが、新しく導入した端末では一度も作られず、
#   無料トライアルの終了後の引き取りが当社のファイルの大半を「台帳に無い」として残していた
#   （2026-11-01 の通しの確認で、引き取りで消えたのが 927 件・残ったのが 6,483 件）。画面には何も出さない。
[ ! -f "$HOME/.soloptilink/lib/evict-delivery/install-hook.sh" ] || SL_IH_EVENT=install SL_IH_QUIET=1 bash "$HOME/.soloptilink/lib/evict-delivery/install-hook.sh" >/dev/null 2>&1 || true
# 端末の登録で試用の端末になった場合に、登録済みの当社の見張りを試用の入口で包み直す（2026-11-01）。
#   上の配線は登録の前に動くため、試用の印がまだ無く何も包まない。登録の後にもう一度呼ぶ。
#   有料の端末（試用の印が無い）の設定は変更しない。
[ ! -f "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" ] || bash "$HOME/.soloptilink/lib/free-trial/wire-runtime-hooks.sh" >/dev/null 2>&1 || true

# ---------------------------------------------------------------------------
# 仕上げの実測 (「完了」と表示してよいかを、表示する前に確かめる)
# ---------------------------------------------------------------------------
# ★順序の是正 (2026-08-15)
#   従来は「セットアップ完了!」の額を先に出し、そのあとで動作確認と自己診断を走らせ、
#   要対応を後ろに並べていた。要対応が残っている端末にも先に「完了」と言い切るため、
#   お客様は完了したものと受け取ってそのまま使い始めてしまう。
#   実測と診断を先に済ませ、その結果で見出しを決める。
set_phase "導入内容の確認" "このファイルをもう一度ダブルクリックしてください。確認からやり直します。ここまでの導入内容はそのまま残っています。"

# 動作確認 (各前提ソフトのバージョンを実測表示)
echo "  ── 動作確認 ──"
export PATH="$HOME/.local/bin:$PATH"
for c in git node npm claude python3; do
    if command -v "$c" >/dev/null 2>&1; then
        # ★2026-09-29: 置き場所だけあって動かないもの (版数が返らない) を [ OK ] と出していた。
        #   素の Mac の python3 は開発ツール導入の案内役で、版数を返さないことがある。
        _vc="$("$c" --version 2>/dev/null | head -1 | tr -d '\r')"
        if [ -n "$_vc" ]; then
            printf "    [ OK ] %-7s: %s\n" "$c" "$_vc"
        else
            printf "    [要対応] %-7s: 置かれていますが動作を確認できません (開発ツールの導入後にもう一度ダブルクリックしてください)\n" "$c"
        fi
    else
        printf "    [要対応] %-7s: 確認できません (再起動後に再確認してください)\n" "$c"
    fi
done
echo ""

# ---------------------------------------------------------------------------
# 導入自己診断 (AC-I08) — 「最後まで走った」ではなく「診断が通った」を完了とする
# ---------------------------------------------------------------------------
# 【何が壊れていたか (T-017e)】installer/self-check.sh は 12 項目の自己診断を
#   実装し配布物にも同梱されているのに、Mac/Windows どちらのインストーラからも
#   呼ばれていなかった (呼出元は社内テストの台帳行と同梱必須リストだけ)。
#   そのため従来の完了画面は「セットアップが最後まで走った」ことしか示さず、
#   スキル未配置・フック未登録のまま「完了」と表示していた。
# 【契約】診断は fail-open。× があってもここで導入を中断しない (要対応一覧へ集約する)。
#   無効化: SOLOPTILINK_SELF_CHECK=off (診断側が「無効化した事実」を記録して終了する)
SELF_CHECK_SH=""
for _sc_cand in \
    "$HOME/.soloptilink/installer/self-check.sh" \
    "$KIT_DIR/installer/self-check.sh" \
    "$KIT_DIR/self-check.sh"; do
    if [ -f "$_sc_cand" ]; then SELF_CHECK_SH="$_sc_cand"; break; fi
done
if [ -n "$SELF_CHECK_SH" ]; then
    echo "  ── 導入の自己診断 ──"
    # ★ERR トラップの落とし穴:
    #   set +e は ERR トラップを抑止しない (bash では errexit と ERR トラップは別物)。
    #   診断が × を返した瞬間に「エラーが発生しました」の異常終了画面が出て、
    #   せっかく印字した診断結果の意味が顧客に伝わらなくなる。
    #   || で受けることで ERR トラップの発火条件から外し、rc だけを回収する。
    SELF_CHECK_RC=0
    # ★2026-09-25: 上の端末のご登録の区間で確かめた状態 (承認待ちなど) を渡す。
    #   承認待ちの端末には license.json が作られないため、渡さないと × と表示される。
    SOLOPTILINK_SETUP_REGISTRATION_STATUS="${_SL_REG_STATUS:-}" bash "$SELF_CHECK_SH" run || SELF_CHECK_RC=$?
    if [ "$SELF_CHECK_RC" -ne 0 ]; then
        add_issue "導入の自己診断" "診断で確認が必要な項目が見つかりました。上の診断結果に表示された「お客様がすること」を実施してから、もう一度このファイルをダブルクリックしてください"
    fi
    echo ""
else
    echo "  ⚠️  導入の自己診断を実施できませんでした (診断の部品が見つかりません)"
    add_issue "導入の自己診断" "自己診断に必要な部品が配布物の中に見当たりません。ZIP をもう一度展開し直してから再実行するか、nomura.y@soloptilink.com へご連絡ください"
fi

# ---------------------------------------------------------------------------
# 利用規約のご確認と「未同意」の記録 (RQ-806 / 2026-09-13 新設)
# ---------------------------------------------------------------------------
# 【なぜ完了画面の直前か】途中に置くと、規約で止まった端末が「半分だけ入った状態」に
#   なる。ここまで来れば配置も登録も済んでいるので、断られても導入は止まらない。
# 【断っても止めない】返事は記録するだけで、導入の成否 (要対応の件数) には使わない。
# 【止まって見えない】入力を受けられないときは表示だけ・10 秒で打ち切って続行。
#   ★別プロセスで呼ぶ (この導入プログラムは set -e で走っている)。
_SL_TERMS_SH="$HOME/.soloptilink/lib/terms/terms-consent.sh"
[ -f "$_SL_TERMS_SH" ] || _SL_TERMS_SH="$KIT_DIR/lib/terms/terms-consent.sh"
[ -f "$_SL_TERMS_SH" ] || _SL_TERMS_SH="$KIT_DIR/../lib/terms/terms-consent.sh"
if [ -f "$_SL_TERMS_SH" ]; then
    bash "$_SL_TERMS_SH" show "installer-mac" || true
else
    echo ""
    echo "  利用規約のご確認: この配布物には規約のご案内の部品が含まれていないため、表示は行いませんでした"
fi

# ---------------------------------------------------------------------------
# 完了画面 (要対応が 1 件でも残っていれば「完了」とは表示しない)
# ---------------------------------------------------------------------------
# 【なぜ分けるか】「完了」は、お客様がこの先の作業を安心して始めてよいという合図である。
#   要対応が残ったまま同じ合図を出すと、直っていないものを直ったと受け取らせてしまう。
if [ "${#PREREQ_ISSUES[@]}" -gt 0 ]; then
cat <<'DONE'

  ╔════════════════════════════════════════════════════════════════╗
  ║                                                                ║
  ║      ⚠️  セットアップは一部が未完了です                         ║
  ║                                                                ║
  ╚════════════════════════════════════════════════════════════════╝

DONE
    printf '  【要対応】以下は自動で完了できませんでした (%s 件):\n' "${#PREREQ_ISSUES[@]}"
    # 対処が複数行になる項目 (手順つきの案内) は 2 行目以降も字下げして読めるようにする
    for it in "${PREREQ_ISSUES[@]}"; do
        printf '    ・%s: %s\n' "${it%%|*}" "${it#*|}" | sed '2,$s/^/      /'
    done
    echo ""
    echo "  ※ まず上記を解消し、このファイルをもう一度ダブルクリックしてください。"
    echo "     解消したところから続きが進みます (はじめからやり直しにはなりません)。"
    echo ""
else
cat <<'DONE'

  ╔════════════════════════════════════════════════════════════════╗
  ║                                                                ║
  ║      ✅ SoloptiLinkAI セットアップ完了！                        ║
  ║                                                                ║
  ╚════════════════════════════════════════════════════════════════╝

DONE
fi

cat <<'DONE'
  次のステップ:

    1. Claude Desktop / Claude Code を一度終了して、再起動してください
       (SoloptiLinkAI との連携を読み込むため)

    2. 起動後、Claude Desktop の場合は「Code」の画面に切り替えてから
       (通常のチャット画面では SoloptiLinkAI の機能は読み込まれません)、
       入力欄に /soloptilink-boost と入力し、続けてお仕事の内容をそのままお伝えください

DONE

# ★例示とご利用開始の案内は正典 (lib/onboarding-canon.sh) から取り出して表示する
#   (T-703 / T-706)。ここに文面を書き写すと、手順書・同梱案内・
#   ランチャーの案内と必ずどこか 1 箇所だけが古くなる。実測でも、手順書 3 本は
#   「最大で1〜2営業日」、この完了画面は「通常1営業日以内」と食い違っていた。
_OBC="$HOME/.soloptilink/lib/onboarding-canon.sh"
if [ -f "$_OBC" ]; then
    bash "$_OBC" emit starter 2>/dev/null | sed 's/^/    /' || true
    echo ""
    bash "$_OBC" emit wait 2>/dev/null | sed 's/^/    /' || true
else
    echo "    ご利用開始のタイミングは、同梱の手順書をご覧ください。"
fi

# ★従来はここに打ち込むコマンドを 1 行そのまま出していた
#   (ご登録の状態を確かめる 1 行)。ターミナルを開いたことのないお客様には実行できず、
#   「自分の端末が使える状態か」を自力で確かめる手段が無くなっていた。ご登録の状態を
#   確かめる道順は正典 (上の「ご利用開始のタイミングについて」) が持っているので、
#   ここでは書き写さない。
cat <<'DONE'

  サポート: nomura.y@soloptilink.com

DONE

# Claude Code ログインと有料プランの注意
# ★従来は「またはターミナルで claude」と併記していたが、
#   打ち込む場所も手順も書かれておらず、Claude Desktop を使わないお客様が
#   そこで止まっていた。画面上で完結する Claude Desktop の道順だけを案内する。
echo "  ── Claude Code のログイン ──"
echo "    初回のみログインが必要です。Claude Desktop を起動し、画面の案内にしたがって"
echo "    ログインしてください (すでにログイン済みの場合はそのままお使いいただけます)。"
echo "    ※ ご利用には有料の Claude プラン (Pro / Max / Team / Enterprise) または"
echo "      API のご契約が必要です。無料プランでは Claude Code は使えません。"
echo ""

# ★キー入力を待てない状況 (入力が閉じられた状態で起動された等) でも、
#   ここで異常終了させない。実走で確認: この read が失敗すると ERR トラップが
#   発火し、正常に終わった直後のお客様の画面に「予期しない問題が発生しました」が
#   出てしまう (導入は成功しているのに失敗したと受け取られる)。
echo "[Enterキーで閉じます]"
read -r _ || true
exit 0
