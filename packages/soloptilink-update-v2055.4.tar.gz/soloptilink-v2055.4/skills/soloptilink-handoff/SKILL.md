---
name: soloptilink-handoff
description: "SoloptiLinkAI v2055.4 - 「運用手順書」「Runbook」「障害対応」「保守計画書」「SLA」「エスカレーション」「オンコール」「月次運用報告」「引継書」等で起動。日本SI受託開発の運用引継ぎ文書を一括生成する。"
argument-hint: "[案件名 or プロジェクトディレクトリ] [--mode operations|runbook|maintenance|sla|oncall|handover|all] [--severity-levels SEV1,SEV2,SEV3,SEV4] [--coverage 24x365|business-hours|extended] [--availability 99.9|99.95|99.99] [--industry construction|manufacturing|healthcare|longterm_care|finance|public_sector|retail|...] [--client-type 民間|公共|自治体] [--locale ja|en]"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, Agent, AskUserQuestion, TodoWrite"
---

# SoloptiLinkAI v2055.4 - Operations Handoff Engine


## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

## 機能概要

SoloptiLinkAI v1.0 Operations Handoff Engine - 日本SI受託開発の運用引継ぎフェーズを完全自動化。検収後の運用手順書/障害対応Runbook (ランブック)/保守計画書/SLA/エスカレーションフロー/オンコール体制/月次運用報告/引継書を一括生成。SEV1〜SEV4の障害分類、24x365/business-hours/extendedのサービス時間、RTO/RPO目標、エラーバジェット、日本祝日カレンダー連動、業種別運用差分(医療/介護/金融/公共)に完全対応。「運用手順書」「Runbook」「ランブック」「障害対応」「保守計画書」「SLA」「エスカレーション」「オンコール」「月次運用報告」「引継書」「保守契約」「SLO」「サービスレベル」「ポストモーテム」等で起動。受託者→顧客運用部門の引継ぎ、または顧客運用部門→新運用ベンダーへの再委託まで網羅。Claude Code が触れない日本SIの運用フェーズ独占。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

Claude Code が触れない**日本のSI受託開発の運用引継ぎフェーズ**を完全自動化するスキル。

検収後の「運用引継ぎ→保守」を、受託者(SIer)から顧客運用部門への引継ぎ、もしくは顧客運用部門から新規運用ベンダーへの再委託まで網羅する。

## 対 Claude Code 差別化

| 工程 | Claude Code | SoloptiLinkAI-Handoff |
|------|------------|----------------------|
| 運用手順書 | ❌ テキストレベル | ✅ 日次/週次/月次/年次 全章構成 (8章) |
| 障害対応Runbook | ❌ | ✅ SEV1〜SEV4分類 + 6シナリオ + Mermaidフロー |
| 保守計画書 | ⚠️ 雑な箇条書き | ✅ 4区分(障害/制度/改良/予防) + 月次/年次工数 |
| SLA | ❌ | ✅ 24x365/業務時間/拡張 + RTO/RPO + エラーバジェット |
| オンコール体制 | ❌ | ✅ 公平ローテーション + 日本祝日除外 + 月次レポート |
| 引継書 | ❌ | ✅ 8章完全構成 (受託者→顧客 OR 顧客→新ベンダー) |
| 業種別カスタマイズ | ❌ | ✅ 医療(3省2GL)/介護(LIFE)/金融(FISC)/公共(99.99%) |
| 日本祝日連動 | ❌ | ✅ 2024-2026 内蔵カレンダー、営業日除外計算 |

## Step 0: 端末認証 (BOOST と同一)

```bash
SOLOPTILINK_BIN=""; if [ -f ~/.soloptilink/soloptilink ]; then SOLOPTILINK_BIN="./soloptilink"; elif [ -f ~/.soloptilink/soloptilink.exe ]; then SOLOPTILINK_BIN="./soloptilink.exe"; fi
AUTH_CHECK=$(cd ~/.soloptilink 2>/dev/null && ${SOLOPTILINK_BIN:-./soloptilink} --status 2>&1); if echo "$AUTH_CHECK" | grep -q "承認済み"; then echo "AUTHORIZED"; else echo "UNAUTHORIZED"; fi
```

`UNAUTHORIZED` の場合、認証案内を表示して処理中止。

## Step 0.5: 検収コンテキスト取り込み

`.soloptilink-acceptance-session.json` がプロジェクトに存在すれば読み込み、検収時の残不具合一覧を引継書 (Step 6) の第4章「既知の問題と回避策」(`known_issues`) へ自動転記する。存在しない場合はスキップして次へ進む。

## Step 1: 運用手順書生成 (`--mode operations`)

日次/週次/月次/年次 の運用手順書を生成:

```typescript
import { generateOperationsManual } from './lib/operations_manual';

const manual = generateOperationsManual({
  system_name: 'レセプト管理システム',
  industry: 'healthcare',
  client_type: '民間',
  coverage: '24x365',
  contacts: { primary, secondary, manager_escalation, vendor_support },
  retention: { backup_days: 30, audit_log_years: 7 },
});
```

### 章構成 (日本SI標準)

1. **システム概要** - 目的・利用者・主要機能・SLA要約
2. **アーキテクチャ図** - 構成・ネットワーク・バックアップ・監視ポイント
3. **日常運用** - 起動/停止/バックアップ/ログ確認 (毎営業日)
4. **定期運用** - 週次バッチ/月次集計/年次データ整理/棚卸
5. **アカウント管理** - 入退社対応・権限変更・棚卸 (年2回)
6. **バックアップ・リストア** - 取得方針/保管/復旧手順/リストア訓練
7. **セキュリティ運用** - 監査ログ確認/脆弱性対応/CVE監視/インシデント
8. **連絡先・エスカレーション** - 一次窓口/二次窓口/役員エスカレーション

### 業種別運用差分

| 業種 | 必須追加項目 |
|------|------------|
| 構築/manufacturing | 在庫棚卸/EDI監視/MRP夜間バッチ確認 |
| 医療/healthcare | レセプト電算ファイル提出(月10日)/HPKI証明書更新/3省2GL監査ログ7年保管 |
| 介護/longterm_care | LIFEデータ送信(月10日)/介護報酬改定3年毎反映/科学的介護指標 |
| 金融/finance | 全銀フォーマット監視/FISC安全対策基準/反社チェック更新 |
| 公共/public_sector | 標準ガイドライン群/検査調書整備/会計法29条の3支払 |
| 不動産/real_estate | レインズ連携/35条書面PDF保管/宅建業者免許更新 |
| 建設/construction | 工事台帳保管10年/CCUS連携/建退共納付管理 |

## Step 2: 障害対応 Runbook 生成 (`--mode runbook`)

SEV1〜SEV4 + 代表的6シナリオ + Mermaidフローチャート:

```typescript
import { generateRunbook } from './lib/runbook_generator';

const runbook = generateRunbook({
  system_name: '...',
  contacts: {...},
  scenarios: ['db_unreachable', 'api_slow', 'auth_failure_spike', 'batch_failure', 'capacity_exhaustion', 'unauthorized_access'],
});
```

### SEV分類 (Severity Levels)

| Level | 判定基準 | 一次対応SLA | エスカレーション |
|-------|---------|-----------|----------------|
| SEV1 | 全停止・全業務影響 | 15分以内応答/60分以内復旧着手 | 即時マネージャ + 1h以内役員 |
| SEV2 | 主要機能停止・複数部門影響 | 1時間以内応答/4時間以内復旧 | マネージャ通知 |
| SEV3 | 一部機能停止・代替手段あり | 4時間以内応答/翌営業日復旧 | チームリード通知 |
| SEV4 | 軽微・運用影響限定 | 翌営業日応答 | 週次定例で報告 |

### 代表的6シナリオ

各シナリオに **検知 → 一次対応 → 二次対応 → エスカ → 復旧確認 → ポストモーテム** のフロー:

1. **DB接続不可** (db_unreachable) - PostgreSQL/MySQL/Oracle 接続喪失
2. **API応答遅延** (api_slow) - p95 > 3秒、外形監視アラート
3. **認証失敗多発** (auth_failure_spike) - ブルートフォース疑い
4. **バッチ失敗** (batch_failure) - 夜間バッチ異常終了
5. **容量逼迫** (capacity_exhaustion) - ディスク>85%/メモリ>90%
6. **不正アクセス疑い** (unauthorized_access) - 不審IP・特権操作・SQLi痕跡

### Mermaidフローチャート

```mermaid
graph TD
  A[アラート検知] --> B{SEV判定}
  B -- SEV1 --> C[即時電話 PRIMARY]
  B -- SEV2 --> D[Slack/メール PRIMARY]
  B -- SEV3 --> E[チケット起票]
  B -- SEV4 --> F[週次定例]
  C --> G[15分以内応答]
  G --> H[一次対応: ログ確認]
  H --> I{解決?}
  I -- Yes --> J[復旧確認 + ポストモーテム]
  I -- No --> K[二次対応 + マネージャエスカ]
  K --> L[ベンダーサポート連絡]
  L --> J
```

## Step 3: 保守計画書生成 (`--mode maintenance`)

4保守区分 + 月次/年次工数想定:

```typescript
import { generateMaintenancePlan } from './lib/maintenance_plan';

const plan = generateMaintenancePlan({
  system_name: '...',
  industry: 'healthcare',
  team_size: 3,
  contract_period_months: 12,
});
```

### 保守区分 (4分類)

| 区分 | 内容 | 月次工数想定 |
|------|------|------------|
| 障害対応 | 緊急バグ修正・データパッチ | 0.5〜1.0人月 |
| 制度対応 | 法改正対応 (インボイス/電帳法/個情法/介護報酬改定/3省2GL) | 0.3〜0.8人月 |
| 改良要望 | 機能追加・UI改善 (顧客要望キュー消化) | 0.5〜2.0人月 |
| 予防保守 | OS/ライブラリパッチ・脆弱性対応・性能改善 | 0.5〜1.0人月 |

### 月次定例作業

- パッチ適用 (OS/ミドルウェア/CVE-CRITICAL 即時)
- バックアップ検証 (ランダム1日リストア試験)
- 容量監視レポート (ディスク/DB/ログ)
- 死活監視レポート (稼働率/平均応答時間)
- セキュリティ監査 (脆弱性スキャン/監査ログレビュー)

### 年次定例作業

- BCP訓練 (机上訓練 + 実機停止訓練)
- リストア訓練 (本番相当環境で全面リストア)
- 脆弱性診断 (Webアプリ + ネットワーク + ペネトレーション)
- SLA見直し (実績ベース)
- 契約更新 (条件改定協議)

## Step 4: SLA生成 (`--mode sla`)

```typescript
import { generateSla } from './lib/sla_generator';

const sla = generateSla({
  system_name: '...',
  coverage: '24x365' | 'business-hours' | 'extended',
  availability_target: 0.999,  // 99.9% / 99.95% / 99.99%
  rto_minutes: 60,
  rpo_minutes: 15,
  client_type: '民間',
  industry: 'finance',
});
```

### サービス時間定義

| coverage | 内容 |
|---------|------|
| `24x365` | 24時間365日 (祝日含む) |
| `business-hours` | 平日 9:00〜18:00 (土日祝除外) |
| `extended` | 平日 8:00〜22:00 + 土日祝は要相談 |

### 可用性目標

| 目標 | 月間許容ダウンタイム | 適用想定 |
|------|------------------|---------|
| 99.9% (Three Nines) | 約43.2分 | 一般業務システム |
| 99.95% | 約21.6分 | 重要業務システム |
| 99.99% (Four Nines) | 約4.32分 | 公共/金融/医療デフォルト |

### 応答時間SLA

| Severity | 応答時間 | 復旧目標 |
|----------|---------|---------|
| SEV1 | 15分以内 | 4時間以内 |
| SEV2 | 1時間以内 | 翌営業日 |
| SEV3 | 4時間以内 | 1週間以内 |
| SEV4 | 翌営業日 | 月次定例 |

### RTO/RPO + エラーバジェット

- **RTO** (Recovery Time Objective): 復旧時間目標 (例: 60分)
- **RPO** (Recovery Point Objective): 復旧地点目標 (例: 15分前データまで保証)
- **エラーバジェット**: (1 - 可用性目標) × 期間。99.9% × 30日 = 43.2分の月間バジェット
- 月間稼働率 < 99% でサービスクレジット (返金 or 翌月無料延長)

### 営業日除外計算 (日本祝日カレンダー 2024-2026 内蔵)

`lib/sla_generator.ts` に元日/成人の日/建国記念日/天皇誕生日/春分の日/昭和の日/憲法記念日/みどりの日/こどもの日/海の日/山の日/敬老の日/秋分の日/スポーツの日/文化の日/勤労感謝の日 の3年分を内蔵。`isBusinessDay(date)` で平日かつ祝日でない日を判定し、SLA算出/エスカレーション時刻計算で利用。

## Step 5: オンコール体制生成 (`--mode oncall`)

```typescript
import { generateOncallSchedule } from './lib/oncall_scheduler';

const schedule = generateOncallSchedule({
  team: ['田中', '鈴木', '佐藤', '渡辺'],
  start_date: '2026-04-01',
  weeks: 12,
  coverage: '24x365',
  vacation_blocks: [...],  // 個人別休暇 + 年末年始/GW/お盆 共通
});
```

### 体制構造

- **プライマリ** (Primary On-Call): 一次対応者。SEV1/SEV2 で15分以内応答
- **セカンダリ** (Secondary On-Call): プライマリ不在時のバックアップ
- **マネージャエスカレーション** (Manager Escalation): 1時間以内に対応開始されない場合

### 公平性

- 1人月あたりオンコール時間の偏りを最小化 (標準偏差 < 平均×10%)
- 本人指定休暇 + 日本の年末年始(12/29-1/3) / GW(4/29-5/5) / お盆(8/13-8/16) を自動ブロック
- 連続2週間以上のオンコール禁止 (バーンアウト防止)

### 月次レポート出力

- 出動回数 (SEV別)
- 平均応答時間
- Toil率 (繰り返し作業の割合) - 30%超で改善提案

## Step 6: 引継書生成 (`--mode handover`)

受託者→顧客運用部門 OR 顧客運用部門→新運用ベンダー の双方向対応:

```typescript
import { generateHandoverDoc } from './lib/handover_doc';

const handover = generateHandoverDoc({
  direction: 'sier_to_client' | 'client_to_new_vendor',
  system_name: '...',
  assets: {...},
  known_issues: [...],
  improvement_proposals: [...],
});
```

### 章構成 (8章)

0. **エグゼクティブサマリ** - 引継ぎの目的・対象範囲・期間・体制
1. **システム概要** - アーキテクチャ・利用者・SLA・データ量
2. **資産一覧** - サーバ/ライセンス/アカウント/ドメイン/証明書
3. **運用手順** - 日次/週次/月次/年次 (operations_manual のサマリ)
4. **既知の問題と回避策** - 未解決バグ/性能課題/制約事項
5. **連絡先** - ステークホルダ全員 + ベンダーサポート
6. **変更履歴** - 過去12ヶ月の主要変更
7. **将来の改善提案** - 技術的負債/性能向上/セキュリティ強化
8. **付録** - パスワード保管場所(KeyVault/1Password)/契約書類PDFリンク

### 案件台帳自動登録 (引継書完成時)

引継書の完成時に `bash ~/.soloptilink/lib/engagement-ledger.sh ingest .soloptilink-handoff-session.json` を実行し、案件台帳 (Engagement Ledger) に status=maintenance で自動登録する (保守期限も自動記録)。

## Step 7: 全モード一括実行 (`--mode all`)

運用手順書 + Runbook + 保守計画書 + SLA + オンコール + 引継書 + 月次運用報告テンプレ を一括生成:

```typescript
import { generateHandoffPackage } from './lib/index';

const pkg = generateHandoffPackage({
  system_name: '...',
  industry: 'healthcare',
  coverage: '24x365',
  availability_target: 0.9999,
  ...
});
```

## 業種別カスタマイズ (将来の soloptilink-japan 連携)

`--industry` 指定時、業種固有の運用差分を自動反映。本スキルは独立稼働するが、将来的に `~/.claude/skills/soloptilink-japan/lib/japan/sre_jp.ts` (祝日/SLO/凍結窓)・`bcp.ts` (BCP訓練計画)・`incident.ts` (インシデント分類) との連携を想定。連携前提の追加項目:

- 医療: 3省2GL監査ログ保管7年/HPKI/レセプト電算月次提出
- 介護: 介護報酬改定3年/LIFEデータ提出/科学的介護
- 金融: FISC/反社/全銀/E2EE
- 公共: 標準ガイドライン群/検査調書/会計法
- 建設: 工事台帳10年/CCUS/建退共

## 出力フォーマット

| 種類 | フォーマット | 用途 |
|------|------------|------|
| 運用手順書 | .docx (anthropic-skills:docx 経由) | 顧客運用部門へ提供 |
| Runbook | .md + .pdf | オンコールエンジニア用 (印刷可) |
| 保守計画書 | .docx | 保守契約書添付 |
| SLA | .docx + .pdf | 契約書別紙 |
| オンコール表 | .xlsx + .ics | カレンダー取込 |
| 引継書 | .docx | 製本/正式提出 |
| 月次運用報告 | .docx テンプレ | 毎月差し替え運用 |

## 出力配置

デフォルト: `<カレントディレクトリ>/docs/operations/`

- `01_operations_manual.docx`
- `02_runbook.md` + `02_runbook.pdf`
- `03_maintenance_plan.docx`
- `04_sla.docx`
- `05_oncall_schedule.xlsx`
- `06_handover.docx`
- `07_monthly_report_template.docx`
- `metadata.json` (パラメータ + 生成系統)

## 統合スキル

- `/soloptilink-japan`: 業種辞書 / 法令DNA / 帳票テンプレ / sre_jp.ts (将来連携)
- `/soloptilink-acceptance`: 検収フェーズ (運用引継ぎの直前)
- `/soloptilink-rfp`: 受注フェーズ (運用引継ぎの起点)
- `anthropic-skills:docx`: .docx 生成エンジン
- `anthropic-skills:xlsx`: .xlsx オンコール表生成

## 引数の解釈

| 引数 | 動作 |
|------|------|
| 引数なし | インタラクティブモード (案件名 + 業種を確認) |
| 案件名 | 案件用ディレクトリを推測 |
| ディレクトリパス | 既存プロジェクトディレクトリから情報抽出 |
| `--mode operations` | 運用手順書のみ生成 |
| `--mode runbook` | Runbookのみ生成 |
| `--mode maintenance` | 保守計画書のみ生成 |
| `--mode sla` | SLAのみ生成 |
| `--mode oncall` | オンコール表のみ生成 |
| `--mode handover` | 引継書のみ生成 |
| `--mode all` (デフォルト) | フルセット生成 |
| `--severity-levels SEV1,SEV2,SEV3,SEV4` | カスタムSEV (デフォルト4種) |
| `--coverage 24x365|business-hours|extended` | サービス時間 |
| `--availability 99.9|99.95|99.99` | 可用性目標 |
| `--industry construction|healthcare|...` | 業種固有運用 |
| `--client-type 民間|公共|自治体` | 顧客タイプ (公共は99.99%デフォルト) |
| `--locale ja|en` | 言語選択 (英語版は要約ベース) |

## 使用例

```
/soloptilink-handoff レセプト管理システム --mode all --industry healthcare --coverage 24x365 --availability 99.99

/soloptilink-handoff ./project-acme --mode runbook --severity-levels SEV1,SEV2,SEV3

/soloptilink-handoff 介護記録システム --mode oncall --industry longterm_care --coverage business-hours

/soloptilink-handoff --mode handover --client-type 公共 (公共システムの引継書のみ)
```

## セッション継続ルール

このスキル起動後、`.soloptilink-handoff-session.json` がプロジェクトに作成され、以降の会話で:

- 「SEV2の応答時間を30分に変更」→ SLA再生成
- 「12月にBCP訓練を追加」→ 保守計画書を更新
- 「鈴木さんを5月のオンコールから除外」→ オンコール表を再計算

として継続的に操作可能。

## 月次再認証 (継続的動作保証の実体 / 2026-08-06 T-240 結線)

月次運用報告を生成するときは、報告書作成の前に納品済みプロジェクトの**月次再認証**を実行し、その結果を月次運用報告へ反映すること:

```bash
bash ~/.soloptilink/lib/re-certification.sh "$PROJECT_DIR"
```

内容: 依存脆弱性スキャン → 主要ゲート再走 → 品質証明書+セキュリティ診断報告書の再発行 → 発行記録の登録。これが月額課金 (継続的動作保証) の実体的根拠になる。best-effort 設計のため、失敗しても月次運用報告の生成全体は止めない。
