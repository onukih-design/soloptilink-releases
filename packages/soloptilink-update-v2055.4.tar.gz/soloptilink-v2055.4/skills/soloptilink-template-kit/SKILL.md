---
name: soloptilink-template-kit
description: "SoloptiLinkAI v2055.4 - 「テンプレ」「ひな形」「90%完成」「工事台帳」「物件管理」「介護記録」「レセプト」「学籍管理」「経費精算」「kit」等で起動。中小企業の基幹システム10種を90%完成テンプレで3分立ち上げする。"
argument-hint: "[--kit construction|drawing|manufacturing|real_estate|legal|care|medical|education|crm|order|expense] [--target-dir <dir>] [--list] [--describe <kit>] [--locale ja|en]"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, Agent"
---

# SoloptiLinkAI v2055.4 - Template Kit (90%完成スキャフォールドエンジン)


## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

## 機能概要

SoloptiLinkAI v1.0 Template Kit - 日本の中小企業がよく作る基幹システム10種を「90%完成テンプレ」として3分でスキャフォールド。Claude Code が毎回フルスクラッチで生成するのに対し、本スキルは業種別の「あと10%だけカスタマイズすれば動く」プロジェクトを即座に立ち上げる。10種kit: 工事台帳/受発注台帳/物件管理/案件管理/介護記録/レセプト管理/学籍管理/顧客管理/受注管理/経費精算。「テンプレ」「スキャフォールド」「ひな形」「90%完成」「3分で立ち上げ」「工事台帳」「物件管理」「介護記録」「レセプト」「学籍管理」「受発注台帳」「案件管理」「顧客管理」「経費精算」「受注管理」「kit」「ベース作って」等で起動。営業現場で『これすぐ使えます』と言える瞬間を作る対 Claude Code 差別化スキル。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

Claude Code が毎回フルスクラッチでコード生成するのに対して、本スキルは**日本の中小企業がよく作る基幹システム**を業種別 90% 完成テンプレとして即座に立ち上げる。3分後には `npm install && npm run dev` で動くプロジェクトが手に入る。営業現場で「これすぐ使えます」と言える瞬間を作る、対 Claude Code 差別化戦略の中核施策。

## 対 Claude Code 差別化

| 観点 | Claude Code | SoloptiLinkAI Template Kit |
|------|-------------|---------------------------|
| 業種知識 | 一般論 | ✅ 日本の業種辞書 (建設業法/宅建業法/介護保険法...) を埋め込み済み |
| 起動速度 | フルスクラッチ毎回数十分 | ✅ 3分で 30+ ファイル生成 |
| 法令適合 | 都度プロンプトで指示 | ✅ kit 設計時に法令ルール反映済 |
| 帳票テンプレ | 都度生成 | ✅ 工事日報/レセプト/ケアプラン等を最初から内蔵 |
| ダッシュボード KPI | 都度議論 | ✅ 業種別 KPI を最初から配線 |
| 残作業 | 全工程 | ✅ ロゴ/カラー/勘定科目連携先 等の 10% のみ |

### kit_id 命名規則 (schemas/kit.schema.json '^[a-z][a-z_]+$' 準拠)

- snake_case のみ・**数字非許容** (kit.schema.json L27 pattern 実測)
- 誤例: `medical_v2` (数字含・違反) / `MedicalOverlay` (大文字違反)
- 正例: `medical_overlay` / `dispensing_pharmacy` / `home_nursing`

## 利用可能な14種 Kit (2026-08-01 図面管理を追加)

| kit_id | 日本語名 | 業種 | 想定ユーザー |
|--------|---------|------|-------------|
| construction | 工事台帳キット | 建設業 | 工務店/建設会社 |
| drawing | 図面管理キット | 建設業 (図面管理) | 図面が実在する案件を持つ工務店/建設会社/専門工事業者/設計事務所 |
| manufacturing | 受発注台帳キット | 製造業 | 中小製造業/部品メーカー |
| real_estate | 物件管理キット | 不動産業 | 賃貸/売買仲介/管理会社 |
| legal | 案件管理キット | 士業 | 税理士/社労士/行政書士/弁護士事務所 |
| care | 介護記録キット | 介護 | 訪問介護/居宅介護支援/特養 |
| medical | レセプト管理キット (医科・base) | 医療 | 診療所/クリニック |
| medical_overlay | レセプト管理キット (医科・overlay) | 医療 | Phase Bエンジン接地レイヤ (base=medical に自動適用) |
| dispensing_pharmacy | 調剤薬局キット | 医療 (調剤) | 保険薬局/院内薬剤部 |
| home_nursing | 訪問看護キット | 医療/介護 | 訪問看護ステーション |
| education | 学籍管理キット | 教育 | 学習塾/予備校/家庭教師 |
| crm | 顧客管理キット | B2B営業 | 中小SaaS/SIer/卸売 |
| order | 受注管理キット | 一般 | 小売/卸売/EC |
| expense | 経費精算キット | 一般 | バックオフィス共通 |

## コマンド

```bash
# 1. 全 kit を一覧
/soloptilink-template-kit --list

# 2. kit の詳細を見る
/soloptilink-template-kit --describe construction

# 3. 工事台帳キットを /tmp/my-app/ にスキャフォールド
/soloptilink-template-kit --kit construction --target-dir /tmp/my-app

# 4. 多言語化 (英語UI)
/soloptilink-template-kit --kit crm --target-dir /tmp/my-crm --locale en
```

## 各 kit に含まれるもの

```
my-app/
├── package.json                     # Next.js 15 + Prisma 5 + Tailwind v4 + shadcn/ui v2 + Auth.js v5 + zod
├── tsconfig.json
├── next.config.ts
├── tailwind.config.ts
├── postcss.config.mjs
├── prisma/
│   ├── schema.prisma                # kit の prisma_models から生成
│   └── seed.ts                      # サンプルデータ 3件以上
├── src/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx                 # ダッシュボード (業種別 KPI)
│   │   ├── (domain)/<resource>/page.tsx          # 一覧
│   │   ├── (domain)/<resource>/[id]/page.tsx     # 詳細
│   │   ├── (domain)/<resource>/new/page.tsx      # 新規作成
│   │   └── api/<resource>/route.ts               # CRUD API
│   ├── lib/
│   │   ├── db.ts                    # Prisma client
│   │   └── validators.ts            # zod
│   └── components/
│       └── ui/                      # shadcn/ui v2
├── docs/
│   └── DESIGN_CONTRACT.md           # 機能一覧/適用法令/残り10%
├── README.md                        # セットアップ手順
└── .env.example
```

## 出力規模 (例: 工事台帳キット)

- ファイル数: 30+
- 行数: ~4500
- セットアップ時間: 3分
- 完成度: 90% (残作業: ロゴ/カラー/勘定科目連携先)

## 内部アーキテクチャ

```
soloptilink-template-kit/
├── SKILL.md                       # 本ファイル
├── README.md                      # スキル概要
├── kits/                          # 14種 kit 設計図 (2026-08-01: 図面管理を追加)
│   ├── construction.json
│   ├── drawing.json               # 図面管理 (2026-08-01 新設・T-018)
│   ├── manufacturing.json
│   ├── real_estate.json
│   ├── legal.json
│   ├── care.json
│   ├── medical.json               # base=医科レセプト
│   ├── medical_overlay.json       # overlay (medical に engine_refs+phase_c_disclosure を上乗せ)
│   ├── dispensing_pharmacy.json   # 調剤薬局レセプト (2026-07-09 新設)
│   ├── home_nursing.json          # 訪問看護 (2026-07-09 新設)
│   ├── education.json
│   ├── crm.json
│   ├── order.json
│   └── expense.json
├── lib/
│   ├── kit_loader.ts              # JSON Schema 検証 + 一覧/詳細 (無編集・SHA-256 baseline 維持)
│   ├── scaffolder.ts              # ディレクトリ生成エンジン (SHA-256 baseline 管理・変更時は理由記載+baseline 更新)
│   ├── kit_overlay_resolver.ts    # overlay の shallow-merge + kill-switch ENABLE_KIT_OVERLAY
│   │                              #   ★off は暗号化列を失うため危険側。明示同意 KIT_OVERLAY_ACCEPT_PLAINTEXT=yes が無ければ例外で停止
│   └── index.ts                   # 公開API: scaffoldKit() → loadKitWithOverlay 経由に更新
├── schemas/
│   └── kit.schema.json            # KitDefinition の JSON Schema (無編集・SHA-256 baseline 維持)
├── examples/
│   ├── 01_construction_scaffold.ts
│   └── 02_list_kits.ts
└── tests/
    ├── template_kit_check.mjs     # node:test (33 ケース)
    ├── kit_overlay_check.mjs      # 2026-07-09 新設 — overlay 両側弁別 born-passing (14 ケース)
    ├── prisma_schema_validate_check.mjs  # 2026-08-01 新設 — 全 kit を展開し実 prisma validate (24 ケース)
    ├── route_generation_check.mjs # 2026-08-01 新設 — 宣言ルートと生成ファイルの突合 (79 ケース・2026-08-06 に全件 PASS)
    ├── path_reference_check.mjs   # 2026-08-05 新設 / 2026-08-07 拡張 — 文書が参照するパスの実在 (11 ケース・本体側 + 生成物側)
    └── generated_typecheck_check.mjs # 2026-08-06 新設 (T-312) — 実 prisma generate + tsc --noEmit (20 ケース)
```

## ドメイン辞書連携

各 kit は `~/.claude/skills/soloptilink-japan/domains/` の業種辞書を参照:

| kit_id | 参照辞書 |
|--------|---------|
| construction | construction.json |
| drawing | construction.json (図面管理は工事案件と同じ建設業辞書を参照) |
| manufacturing | manufacturing.json |
| real_estate | real_estate.json |
| legal | professional.json |
| care | healthcare.json + longterm_care |
| medical | healthcare.json + pharmacy.json |
| medical_overlay | healthcare.json (base=medical の overlay) |
| dispensing_pharmacy | pharmacy.json |
| home_nursing | healthcare.json (医療分) + longterm_care (介護分) |
| education | education.json |
| crm | retail.json (顧客管理参考) |
| order | retail.json + manufacturing.json |
| expense | hr.json (経費精算は人事労務領域) |

これにより、用語/必須フィールド/法令ルール/帳票テンプレが日本のリアルな業務に合致する。

## 図面管理キット (drawing) の設計規約 (2026-08-01 新設・T-018)

### 位置づけ: construction の拡張ではなく単独 kit

図面が実在する案件で必要になる機能は `lib/drawing-link/manifest.json` に要件として定義済みだったが、雛形が無いため毎回ゼロから作られていた。これを 90% 完成テンプレとして起こしたもの。

- **construction.json を拡張しなかった理由**: manifest の policy に「図面が無い案件では完全な no-op (過剰注入しない)」とある。construction に図面 5 モデルを混ぜると、図面が存在しない工事案件にも図面テーブルが常時生成され、この原則に反する。
- **overlay (overlay_of: construction) にしなかった理由**: overlay は base kit_id を指定した全ての展開に自動適用される。つまり図面の無い工事案件にも必ず乗るため、同じく no-op 原則に反する。
- **単独 kit にした結果**: 図面が実在する案件でのみ `--kit drawing` を選択する。工事台帳と併用する場合は `DrawingProjectLink.projectCode` (工事番号) と `projectId` で construction の `Project` と相互参照する。

### 単価を製品側で作らない (最重要・破ると誤った見積が出る)

図面から決まるのは**数量だけ**である。単価・歩掛り・許容差の閾値は**利用者入力**とし、製品側で数値を作らない。

| 製品側が算出してよい | 利用者が入力する |
|---------------------|-----------------|
| 数量 / 面積 / 周長 / 個数 / 長さ | 単価 / 歩掛り / 許容差の閾値 / 金額 |

- `QuantityTakeoff.unitPrice` / `.amount` / `AreaDiscrepancy.toleranceRate` は **既定値を持たない任意フィールド**とする
- UI は単価欄を空欄で初期表示し、利用者が入力するまで金額を算出しない
- 恒久ゲート: `tests/template_kit_check.mjs` の「単価・金額・許容差の閾値に既定値を持たない」で既定値の混入を検出する (欠陥注入で不合格になることを実証済み)

### 面積不一致アラート (図面案件の中核価値)

`AreaDiscrepancy` は図面に**記載された**面積 (`notedArea`) と、読み取って**算出した**面積 (`computedArea`) の両方を保持し、差と差率を持つ。記載と作図の食い違いは見積誤りに直結するため、`blocksEstimate` により**見積を確定する前に確認を促す**。確認結果は `judgement` (OK/NG/PENDING) に記録する。

### scaffolder 契約への適合 (scaffolder.ts は SHA-256 baseline 管理)

`lib/scaffolder.ts` は原則無編集 (SHA-256 baseline 固定) のため、生成される Prisma が妥当になるよう **kit 定義側**で以下を守る:

- **enum 型名は `defaultEnumValuesFor()` が解決できるものだけを使う**。drawing kit は `DrawingStatus` (→ ACTIVE/INACTIVE/PENDING) と `Judgement` (→ OK/NG/PENDING) のみを使い、既定値は必ずその値集合に含める。解決されない新 enum 名を使うと、生成される `@default(...)` が enum に存在しない値になり `prisma validate` が落ちる。
- **String 型に全大文字の既定値を置かない**。scaffolder は `/^[A-Z_]+$/` の既定値を enum 値とみなし引用符なしで出力するため、`field String @default(ACTIVE)` となり不正になる。分類値は String + 説明での列挙とし、既定値を置かないか非全大文字にする。
- **scaffolder が解釈できない独自型を新設しない**。現在 scaffolder が解釈する独自型は `EncryptedString` のみ (下記)。それ以外の未知の型名はそのまま Prisma へ出力され `prisma validate` が落ちる。
- 上記は `tests/template_kit_check.mjs` の生成器契約ガードと、`tests/prisma_schema_validate_check.mjs` の実 `prisma validate` で全 kit を横断的に検査する。

#### baseline を更新してよい場合と手順

kit 定義側で回避できない欠陥 (生成器そのものの実装漏れ) を直す場合に限り、scaffolder.ts を変更してよい。手順:

1. 変更前に両ミラーをバックアップする (`~/.soloptilink/.backups/`)
2. `node tests/prisma_schema_validate_check.mjs` と `node tests/generated_typecheck_check.mjs` で
   **変更前の実測**を取る (どの kit が落ちているか)
3. 実装後、同ゲート 2 本で全 kit PASS を実走確認する
4. `tests/kit_overlay_check.mjs` の `L3-b` baseline を新 SHA-256 に更新し、**更新理由をコメントで残す**
5. **旧実装へ戻すとゲートが落ちること**を実走で確認する (両側判定・ゲートが飾りでないことの証明)
6. 本体 `~/.soloptilink/skills/` と配布ミラー `~/.claude/skills/` の両方を同期する
   (SKILL.md の SoT は `~/.claude/commands/soloptilink-template-kit.md`。ここを直さないと
    skill-sot-guard の heal が両ミラーを旧版へ巻き戻す)

### 資源名 → Prisma モデルの解決と、必須項目からの生成 (2026-08-06 新設・T-312)

生成物が **生成直後から本当に保存・取得できる**ようにするための規約。

#### モデルの解決は推測しない

資源名 (`/projects` の `projects`) から書き込み先モデルを決めるとき、**kit 定義の `prisma_models` だけを出典**にする。

| 優先 | 決め方 |
|------|--------|
| 1 | kit が `routes[].model` を宣言していればそれ (kit 定義が明示した対応) |
| 2 | 資源名を正規化して model 名と突合 (小文字英数化 + 単数形候補 + 全モデル共通接頭辞の除去) |
| 3 | どちらでも決まらなければ **解決しない** |

3 になった資源は、画面に理由を表示し API は 501 を返す。README と `docs/DESIGN_CONTRACT.md` の
「この版で保存・取得を有効にしていない資源」節に理由付きで載る。**モデル名を推測して埋めない**
(2026-08-06 以前は `camelOf()` が推測しており、実測の解決成功率は 45%。残りは
`prisma.activitie` / `prisma.propertie` のような存在しない呼び出しになり顧客環境でビルドが落ちていた)。

実測 (2026-08-06 T-312 時点): 155 資源中 111 (72%) が結線。8 kit は 100%。

#### 資源名とモデル名が対応しない導線は kit 定義で明示する

`/incidents` が `IncidentReport` を、`/reports` が `ExpenseReport` を指すような導線は、
**kit 側の該当ルートに 1 行足す**:

```json
{ "path": "/incidents", "purpose": "ヒヤリハット一覧", "type": "list", "resource": "incidents", "model": "IncidentReport" }
```

`prisma_models` に無いモデル名を書いた場合、また同じ資源に別々のモデルを宣言した場合は
`scaffold()` が日本語の例外で止まる (黙って片方を採らない)。

#### 入力フォームと zod スキーマはモデルの必須項目から作る

- `src/lib/validators.ts` に **全モデル**の `<Model>CreateSchema` / `<Model>UpdateSchema` を出す
- 入力フォームに出すのは「値が無いと保存できない必須項目」のみ (既定値のある列は出さない)
- 型ごとの入力欄: 関連 ID は**関連先から選択肢を引く選択欄** / 日付は日付入力 /
  `Decimal`・`Int` は数値入力 / enum は選択欄 / `Json` はテキストエリア / `Boolean` は はい・いいえ
- 画面はサーバコンポーネント (`page.tsx`) が選択肢と初期値を prisma から取り、
  隣の `create-form.tsx` / `edit-form.tsx` (`'use client'`) が送信を担う
- API の例外は `src/lib/api-error.ts` が日本語へ変換する (内部情報を画面に出さない。
  重複は 409、対象なしは 404、想定外は 500 でサーバログにのみ詳細を残す)

#### システム列の既定値は生成器が補う

kit 定義が `id` / `createdAt` / `updatedAt` に既定値を宣言していない場合 (実測 114 モデル中 44 件)、
生成器が `@default(cuid())` / `@default(now())` / `@updatedAt` を補う。補ったことは
`schema.prisma` の `///` 注記に残す。補わないと、システム列は入力フォームに出さない方針と衝突して
**登録処理が成立しない**。

#### 説明文はそのまま JSX に置かない

kit 定義の `description` / `purpose` には `{draft, finalized, exported}` のような波括弧が入る。
JSX へ素通しすると「存在しない変数の参照」になるため、画面本文へ入れる前に必ずエスケープする
(`jsxText()`)。見出しは `shortTitleOf()` で先頭の一句だけを使う (説明文の段落を見出しにしない)。

#### kill-switch

`TEMPLATE_KIT_PRISMA_WIRING=off` で T-301 時点の挙動 (取得はコメント / 書き込みは 501 /
`measured=false`) へ完全復帰する。回帰は `tests/generated_typecheck_check.mjs` の C-1 が守る。

### 要配慮個人情報の暗号化 (独自型 `EncryptedString`)

kit 定義の `type: "EncryptedString"` は、**要配慮個人情報を at-rest 暗号化して保管する**フィールドの宣言。

現在この宣言を使っている kit (2026-08-06 実測):

| kit | 対象フィールド数 | 内容 |
|-----|------------------|------|
| `medical_overlay` | 12 | SOAP 診療録・傷病名・投薬歴・バイタル・被保険者番号 |
| `dispensing_pharmacy` | 13 | 患者氏名/カナ・保険者番号・交付医師・電子処方箋 payload・薬歴 SOAP・録画パス・UKE payload・同意書画像パス |
| `home_nursing` | 15 | 利用者氏名・医療/介護保険番号・主治医氏名・訪問記録 SOAP と処置・改訂スナップショット・看護計画 |

scaffolder は次のように扱う (2026-08-01 実装。それ以前は変換が未実装で `prisma validate` が落ちていた):

| 層 | 生成物 |
|----|--------|
| Prisma 保管型 | `String` (暗号文) + `/// encrypted:true (要配慮個人情報・暗号文で保管)` 注記 |
| 対象一覧 (SoT) | `src/lib/crypto/encrypted-fields.ts` (kit 定義からの自動生成) |
| 暗号化本体 | `src/lib/crypto/field-encryption.ts` (AES-256-GCM・Node 標準 crypto のみ・外部依存なし) |
| 透過適用 | `src/lib/crypto/prisma-encryption-extension.ts` (Prisma Client Extension) |
| 配線 | `src/lib/db.ts` が Extension 適用済み client のみを export |
| 鍵の設定手順 | `.env.example` の `FIELD_ENCRYPTION_KEY` / `_KEY_ID` / `_KEYS_OLD` |
| 利用者への明示 | 生成物 README の「要配慮個人情報の暗号化 (必読)」節 |

設計上の約束:

- **鍵未設定なら例外で停止する。平文保存へは倒れない** (要配慮個人情報が黙って平文で残ることを防ぐ)
- 保管形式は `enc:v1:<keyId>:<iv>:<authTag>:<ciphertext>`。keyId 埋め込みにより鍵ローテーション中も旧鍵で復号できる
- **暗号文は DB 側の部分一致検索・並べ替えができない**。完全一致検索だけは blind index で成立させられる (下記)。それ以外の検索が要る項目は `EncryptedString` にしない
- 本テンプレが担保するのは**アプリケーション経路の at-rest 暗号化まで**。DB バックアップ・監査ログ・エクスポート先の保護は別途必要 (生成物 README に明記)
- raw SQL (`$queryRaw` / `$executeRaw`) と DB 直操作は Extension を通らないため暗号化・復号されない

暗号化しない判断をした場合は、**kit の description と生成物 README に「暗号化していない」ことを書く**こと
(実測 2026-08-06 の owner 判断: 患者/利用者の `birthDate` は `EncryptedString` にすると Prisma 上 String になり
年齢集計・範囲検索・並べ替えが不能になるため対象外とし、ディスク暗号化とアクセス制御で保護する)。
黙って外すと「暗号化されている」と誤解される。

#### 用途別鍵は未対応 (実態)

生成される `field-encryption.ts` は **単一の現行鍵 `FIELD_ENCRYPTION_KEY` + 旧鍵リング `FIELD_ENCRYPTION_KEYS_OLD`** だけを扱う。
kit 側に `EncryptionKey.purpose` (patient_pii / insurance_number / …) のような用途区分があっても、
**暗号化処理の鍵選択には使われない** (台帳項目である)。kit の文章で用途別鍵を「実装済み」と書かないこと。

### 暗号化列の完全一致検索 (`blind_index_of` / 2026-08-06 新設)

暗号文は検索できない。氏名のように「暗号化したいが完全一致検索だけは要る」列には、
**索引列側**に `blind_index_of` を書いて宣言する:

```json
{ "name": "familyName",      "type": "EncryptedString" },
{ "name": "familyNameIndex", "type": "String", "blind_index_of": "familyName" }
```

| 層 | 生成物 |
|----|--------|
| 索引の算出 | `src/lib/crypto/blind-index.ts` (HMAC-SHA256 + pepper・NFKC 正規化) |
| 索引の自動充填 | コレクション API の POST が平文から算出して埋め、`prisma-encryption-extension.ts` が書込直前にも同じ値を算出する (素の PrismaClient を使われたときの保険) |
| 顧客画面での扱い | **索引列は入力欄にも検証スキーマにも出さない** (お客様が入力する項目ではない) |
| 検索の組み立て | `blindIndexWhere('Patient', 'familyName', q)` |
| pepper の設定手順 | `.env.example` の `FIELD_ENCRYPTION_INDEX_PEPPER` |
| 利用者への明示 | 生成物 README の「暗号化した項目の検索 (blind index)」節 |

設計上の約束 (できないことを隠さない):

- **完全一致のみ成立**。部分一致・前方一致・並べ替え・範囲検索は成立しない。一覧画面には「完全一致で検索します」と出す
- **索引列をお客様の入力項目にしない** (2026-08-07 / PFP-191)。索引列は生成器が平文から算出する列であり、
  入力フォーム・zod スキーマ・一覧の列・詳細の行のいずれにも出さない。
  判断元は `blindIndexMap()` ただ 1 つ。`TEMPLATE_KIT_BLIND_INDEX=off` のときは Map が空になり
  自動算出も生成されないため、索引列は入力欄に残る (自動で埋まらないのに入力欄も無い=保存できない、へは倒れない)
- pepper 未設定なら例外で停止する (索引をハッシュ無しで保存しない)。pepper は暗号鍵と**別の値**にする
- pepper が漏れると氏名候補の総当たり照合が可能。pepper は暗号鍵と同等に管理する
- pepper を変更したら索引列を**全件再計算**する必要がある
- 宣言不整合 (存在しない列を指す / 暗号化列が 1 つも無いのに索引だけ宣言) は **scaffold が例外で止まる**。
  黙って読み飛ばすと「索引列が空のまま・検索が常に 0 件」の生成物が出荷されるため

氏名検索が要件に無い kit には索引列を作らない (未使用の列を増やさない)。
`home_nursing` は routes に氏名検索が無いため索引列を持たない — 追加する場合は列と宣言の両方が要る。

kill-switch は `TEMPLATE_KIT_BLIND_INDEX=off` (旧挙動=索引を生成しない へ完全復帰)。
off で生成した場合は「索引が入っていないため氏名検索は常に 0 件になる」旨を生成物 README に必ず出す
(黙って検索できないシステムを渡さないため)。

回帰は `tests/prisma_schema_validate_check.mjs` の C-6/C-7/C-8 と
`verify.d/L106-KIT-CRYPTO` (2 拠点の宣言一致・記述と実装の一致・宣言の自己整合) が守る。

### 顧客画面の 3 つの約束 (2026-08-07 / PFP-191〜193)

生成した画面はお客様がそのまま業務に使う。次の 3 点は生成器側で必ず守る。

| 約束 | 内容 | 判断元 |
|------|------|--------|
| 入力欄に出すのは「お客様が決める項目」だけ | 生成器が自動で埋める列 (blind index の索引列) は入力欄・検証スキーマ・一覧列・詳細行に出さない | `inputSpecsOf()` の 1 か所 |
| トップから全画面に辿り着ける | 4 点セットの資源名は **宣言ルートに実在するコレクション URL** から採る。ダッシュボードのクイックリンクは「実際に生成した画面」だけを日本語名で並べる。一覧→詳細/新規作成、詳細→子画面の導線も生成済みの画面にだけ張る | `buildGenerationPlan()` が返す `uiRoutes` |
| 画面の地の文に内部向けの記述を出さない | `routes[].purpose` / `fields[].description` は開発側の設計メモ。先頭の一句だけを採り、実装名・内部フラグ・ファイルパス・英語識別子が混ざっていればその項目ごと画面に出さない。列名は語単位の対訳表で日本語にする | `customerNoteOf()` / `labelOf()` / `humanizeFieldName()` |

「入る手段の無い画面は作らない」も同じ計画で決める。可変セグメントを含む画面は、
上位画面が生成されていない・上位の一覧がデータを引けない (行から開けない) 場合、
生成対象から外して README / 設計契約に理由付きで開示する。開けない画面をお客様に渡さないため。

kill-switch は従来どおり `TEMPLATE_KIT_DECLARED_ROUTES=off` (旧挙動=`routes[].resource` 由来の
4 点セット展開へ完全復帰)。off のときは到達性の絞り込みも行わない。

回帰は `verify.d/L124-KIT-CUSTOMER-SCREEN` (FORM / REACH / TEXT) が
全 14 kit を実 scaffold して毎回測る。両側判定は
「索引列の入力欄を復活 + ダッシュボードのリンク削除 + 設計メモを画面へ貼付」を
実際に注入した検体で実証済み。

### manifest.json の 7 要件との対応

`kits/drawing.json` の `manifest_requirement_map` が要件キーごとにモデルと画面を明示する。この対応表は `tests/template_kit_check.mjs` が実 `manifest.json` と突き合わせ、**要件の取りこぼしと、実在しないモデル/画面への参照**を検出する。

| manifest 要件 | モデル | 主な画面 |
|--------------|--------|---------|
| drawing_registry | Drawing | /drawings, /drawings/[id] |
| revision_control | DrawingRevision | /drawing-revisions, /drawings/[id]/revisions |
| drawing_project_link | DrawingProjectLink | /drawing-project-links |
| quantity_record | QuantityTakeoff | /quantity-takeoffs, /quantity-takeoffs/[id] |
| area_discrepancy_alert | AreaDiscrepancy | /area-discrepancies, /area-discrepancies/[id] |
| drawing_read_view | DrawingRevision + QuantityTakeoff | /drawing-revisions/[id] |
| file_format_guidance | Drawing (sourceFormat/formatSupport/formatGuidance) | /drawings, /drawings/[id], /drawings/formats |

図面読取エンジンが書き込んだ表題欄・レイヤ・寸法の記載値は `DrawingRevision` の Json フィールドに版ごとに保持し、`/drawing-revisions/[id]` が読取レポート閲覧画面になる。

## overlay 消費規則 (2026-07-09 追加・PFP-143 系統 kit の Phase B エンジン接地レイヤ)

### 目的

既存 kit JSON (例: `medical.json`) を**無編集のまま**、Phase B エンジン (`lib/japan/medical-billing/*`, `lib/japan/emr-core/*`) への接地情報 (`engine_refs`) と Phase C 実接続の正直開示 (`phase_c_disclosure`) を追加するための構造。共有本体 SHA-256 (kit_loader.ts / scaffolder.ts / kit.schema.json / skill-sot-guard.sh) を触らずに Phase B エンジンをテンプレに繋げる。

### 動作 (プログラム経路・lib/kit_overlay_resolver.ts)

- `scaffoldKit(kit_id, ...)` は内部で `loadKitWithOverlay(kit_id)` を呼び、`kit_id` に対応する overlay (`overlay_of: <kit_id>` を持つ他の JSON) が `kits/` に存在すれば、非破壊で `engine_refs` / `phase_c_disclosure` / その他追加フィールドを上乗せする。
- `kit_loader.ts` の低レベル API (`loadKit`) は overlay を無視する (下位互換=silently 昇格禁止)。
- **返り値の `kit_id` は常に base の kit_id** (`medical_overlay` ではない・silently 昇格しない)。

### 動作 (LLM 経路・SKILL.md 消費側の規則)

1. `industry='medical'` の kit を新規生成する場合、`scaffoldKit('medical', ...)` を呼ぶ (overlay は自動適用される)。
2. overlay 自身の kit_id (`medical_overlay`) を **直接** `scaffoldKit('medical_overlay', ...)` で指定した場合は、その overlay ファイル自身が base として扱われる (明示選択・silently 昇格ではない)。
3. `listKits()` は base kit と overlay kit の**両方**を並存表示する (overlay は隠さない=検索の透明性を保つ)。

### kill-switch (★off は安全側ではない)

- **`ENABLE_KIT_OVERLAY=off`** (or `false` / `0` / `no`) で overlay 適用を停止し、base kit のみの構成へ戻す。
- **未設定は on**。「未設定なら off に倒れる」ことはない (実装 `overlayEnabled()` が空文字を true で返す)。
- ★**off は安全側ではなく危険側**である。base=medical.json は暗号化列を 1 列も持たないため、
  off にすると overlay 由来の暗号化列 13 列が失われ、氏名・被保険者証番号・保険証画像・住所・電話・
  アレルギー・服薬中の薬・既往歴・診断名・薬剤名が平文保管の構成に戻る (実走で再現済み:
  23 モデル/174 列/暗号化 13 列 → 6 モデル/60 列/暗号化 0 列)。
- そのため resolver は `assertNoSilentPlaintextDowngrade()` を持ち、off が暗号化列を減らす場合は
  **例外で停止する**。障害切り分け等で意図的に平文構成へ戻す場合に限り、二つ目の環境変数
  **`KIT_OVERLAY_ACCEPT_PLAINTEXT=yes`** を併せて指定する (退避弁は殺さず、うっかり降格だけを塞ぐ二重鍵)。
- この降格が起きないことは検証軸 **L187-KIT-CRYPTO-FLOOR** が resolver の実走で常設監視する。

### マージ規則 (shallow-merge・集合和ではない)

`applyOverlay()` は **shallow-merge** である。`prisma_models` / `routes` / `report_templates` /
`dashboard_kpis` / `applicable_laws` などの配列キーは overlay 側の値が base の同名キーを
**置き換える** (集合和は取らない)。overlay 側にはこれらのキーの完全な内容を宣言すること。
`kit_id` と `overlay_of` だけは base 側を保つ (silently 昇格禁止)。

### base kit=medical.json 到達動線の破壊禁止

- overlay 導入前後で `industry='medical'` 検索の base 動線 (medical.json ヒット) は破壊されない。`listKits()` は base + overlay の両方を返す。
- base kit の SHA-256 は無編集 (物理ファイルを touch しない・返り値のオブジェクトのみ変わる)。
- kill-switch off + `KIT_OVERLAY_ACCEPT_PLAINTEXT=yes` で base 単独動線へ戻せる (障害時の復帰手段は維持)。
  明示同意なしの off は暗号化を失うため例外で停止する。

### born-passing 両側弁別

`tests/kit_overlay_check.mjs` で 14 テスト全 PASS を維持する:
- overlay あり=engine_refs 上乗せ ∧ overlay 削除=base のみ
- kill-switch off=base のみ ∧ silently 昇格禁止 (kit_id=base 不変)
- kit_loader/scaffolder/schema/skill-sot-guard/medical/care SHA-256 baseline 保持

### 要配慮個人情報の列の扱い (完全性)

医療・介護・調剤・訪問看護の kit では、要配慮個人情報 (個人情報保護法2条3項) と
医療保険の個人識別符号 (同法施行令1条) に当たる列は、次のどちらかを必ず満たす:

1. `prisma_models[].fields[].type` が `EncryptedString` である、または
2. 平文である理由が顧客へ開示されている
   - その列に `plaintext_disclosure_term` (顧客向け開示文に現れる語) と `plaintext_reason_ja` を宣言し、
   - `phase_c_disclosure.disclosure_line` の中に、その語を含みかつ「平文」と述べた文が実在すること

どちらも満たさない列があれば検証軸 **L186-SENSITIVE-COVERAGE** が不合格を出す。
「暗号化する列を数え忘れる」形の取りこぼしは、件数の内部整合だけを見る検査では見つからないため、
本規則で完全性の側から塞ぐ。集計・突合・範囲検索を成立させるために平文が必要な列 (生年月日・
要介護度・傷病名の ICD-10 コード・別表該当状態・バイタル・保険者番号・調剤明細) は、
2 の経路で必ず開示する。

### 誇大表示禁止 (Phase C 実接続の正直開示)

3業態kit (`dispensing_pharmacy`, `home_nursing`, `medical_overlay`) は `phase_c_disclosure` で以下を正直に開示する:
- Phase C 実接続 (オンライン資格確認 / 電子処方箋 (HPKI 署名) / 国保連伝送 / マイナ保険証読取) は **接続テストボタンまで** の実装
- 実接続は **次回リリース時** (go:embed バイナリ payload 再ビルド) に段階提供
- 生成物 README にも同じ内容を明示 (顧客可視の誇大表示禁止)

## 実行例

```bash
# 工事台帳キットを生成
$ /soloptilink-template-kit --kit construction --target-dir /tmp/koji-daicho-app

✓ kit 読み込み: construction (建設業)
✓ ターゲット作成: /tmp/koji-daicho-app/
✓ package.json 書き出し
✓ Prisma スキーマ生成 (5 models: Project/Estimate/PurchaseOrder/Invoice/DailyReport)
✓ ダッシュボード生成 (KPI: 進行中工事/粗利率/キャッシュフロー/次回検査日)
✓ 一覧/詳細/新規ページ生成 (12 routes)
✓ API ルート生成 (28 routes)
✓ 帳票テンプレ生成 (工事日報/週報/月次出来高/見積書/注文書/請求書)
✓ DESIGN_CONTRACT.md 書き出し
✓ README.md 書き出し
✓ .env.example 書き出し

完了: 48 files, 4500 lines, 3 min setup
残り10%: ロゴ・カラー、勘定科目連携先(奉行/freee)、建設業許可番号
```

## セルフチェック

```bash
cd ~/.claude/skills/soloptilink-template-kit
node tests/template_kit_check.mjs
# 期待: 33 ケース PASS

node tests/kit_overlay_check.mjs
# 期待: 14 ケース PASS

node tests/prisma_schema_validate_check.mjs
# 期待: 24 ケース PASS (全 kit を実際に展開し、実 prisma validate に掛ける)
# 注意: typescript と prisma CLI が要る。無い場合は PASS ではなく終了コード 2 (未測定) で落ちる

node tests/path_reference_check.mjs
# 期待: 11 ケース PASS (typescript が要る。無い場合は PASS ではなく終了コード 2 (未測定) で落ちる)
# kit の記述が参照するパスが実在することを確認する。
# purpose / description は README.md と docs/DESIGN_CONTRACT.md へ無条件に転記されるため、
# 実在しないパスを書くと顧客提示文書にそのまま載る (2026-08-05 に実際に発生し根治)。
# 2026-08-07 拡張: 本体側パスに加えて、生成物側パス (src/...) を【実 scaffold の生成物】と
# 突き合わせる。あわせて「文書が主要ページとして列挙した画面に実ファイルが必ずある」
# 「生成しない宣言ルートは全件が理由付きで開示され、本数が基準を超えて増えない」も測る。

node tests/route_generation_check.mjs
# 期待: 79 ケース PASS (2026-08-06 / T-301 で実装完了。それ以前は pass 2 / fail 61)。
# scaffolder の routePlan() が宣言ルート 1 本ごとに生成先と生成可否を返し、
# scaffold / README / 設計契約がすべてその判断を見る。生成しないものは
# 「この版では生成していない画面」として理由付きで開示される。
# A-6 (2026-08-06 追補): 実装していない書き込みを成功として返す API を生成していないこと。
#   全 14 kit のコレクション API の POST が prisma 未接続のまま固定値を 201 で返しており、
#   「保存に成功したのに一覧に出てこない」状態だった欠陥の再発を止める床。
#   両側実証済み — 旧実装へ戻すと A-6 が 14 kit すべてで落ち (65/79)、
#   本当に prisma へ書く実装は B-5 で誤検知しない。
# kill-switch: TEMPLATE_KIT_DECLARED_ROUTES=off で 2026-08-06 以前の挙動へ完全復帰。
# 自動実行: verify.d/L145-KIT-ROUTE-CONTRACT が verify-all / doctor 経由で毎回走らせる。

node tests/generated_typecheck_check.mjs
# 期待: 20 ケース PASS (2026-08-06 / T-312 新設・所要 約45秒)
# 全 14 kit の生成物に実 prisma generate を掛け、その出力型を正典として tsc --noEmit を通す。
# route_generation_check の A-3 は「構文が壊れていないか」しか見ないため、
#   ・存在しない prisma delegate (prisma.activitie / prisma.propertie など)
#   ・create() の必須項目不足
#   ・説明文の波括弧が JSX で式として解釈され未定義変数を参照する
# のいずれも捕まえられず、緑のまま顧客環境でビルドが落ちていた。その床がこのゲート。
# 両側実証済み — T-312 以前の実装へ戻すと 20 軸中 18 軸が落ちる (pass 2 / fail 18)。
#   旧実装の型エラー実測: care 21 / construction 18 / crm 18 / drawing 19 /
#   expense 21 / medical 49 / medical_overlay 49 件。新実装は全 14 kit で 0 件。
# 測っていないもの: next / react などフレームワークの型は最小のシムに置き換えている。
#   このゲートが保証するのは Prisma と zod を含む「データ層の型の辻褄」である。
# 依存: typescript / prisma CLI / @prisma/client / zod。無い場合は PASS ではなく
#   終了コード 2 (未測定) で落ちる。zod は ~/.soloptilink/.gate-deps/typecheck/ に
#   1 度だけ取り寄せて使う (生成物にも配布物にも入れない)。
# kill-switch: TEMPLATE_KIT_PRISMA_WIRING=off で T-301 時点の挙動 (501/measured=false) へ復帰。
# 自動実行: verify.d/L145-KIT-ROUTE-CONTRACT の .typecheck 軸。
```

## 認証

```bash
SOLOPTILINK_BIN=""
if [ -f ~/.soloptilink/soloptilink ]; then SOLOPTILINK_BIN="./soloptilink"
elif [ -f ~/.soloptilink/soloptilink.exe ]; then SOLOPTILINK_BIN="./soloptilink.exe"
fi
AUTH_CHECK=$(cd ~/.soloptilink 2>/dev/null && ${SOLOPTILINK_BIN:-./soloptilink} --status 2>&1)
if echo "$AUTH_CHECK" | grep -q "承認済み"; then
  echo "AUTHORIZED"
else
  echo "UNAUTHORIZED"
fi
```

## セキュリティ診断報告書 (標準同梱・全モード共通 / 2026-08-06 T-240)

`セキュリティ診断報告書.html` は BOOST 専用ではなく**全生成物の標準同梱物**である。chain.sh 経路では品質証明書の直後に、Claude Code / Desktop 経路では完成ゲート hook が、それぞれ自動発行する (どちらも既定 ON)。

- 記載内容: 実装状況23項目の検査 / 秘密情報の混入 / 外部部品の既知の弱点 / 情報セキュリティ基準への適合度 — **実測のみ** (捏造ゼロ)。
- **未実施の検査と診断範囲外 (侵入テスト・運用体制・お客様側の改変部分等) は必ず開示される**。開示節 (「本診断の範囲と限界」) を削って納品してはならない — 検査軸 L154-SECREPORT が開示節の欠落を検出する。
- 完成報告の前に `<プロジェクト>/セキュリティ診断報告書.html` の存在を確認し、無ければ手動発行する: `bash ~/.soloptilink/lib/security-assessment-report.sh generate "$PROJECT_DIR"` (非ブロッキング)。
- kill-switch: `ENABLE_SECURITY_ASSESSMENT_REPORT=false` (既定 on)。
- 営業向けの線引き (何を診断し何を診断しないか・商用可否の層A/B/C) は `~/.soloptilink/lib/security-assessment-scope.md` を参照。
