﻿# =============================================================================
# SoloptiLinkAI v2038.2 - Windows PowerShell Installer
# =============================================================================
# Built: 2026-06-11 (Nomura incident response - ZIP配布形式対応)
# Purpose: 配布物の自動配置 + lib/ 完整性検証 + Goランチャー認証起動
#   モードA (ZIP配布 / 主経路): 解凍済み配布フォルダ (installer の親) を
#     ~\.soloptilink へ配置する。顧客ZIP (SoloptiLinkAI_vX.Y_Windows.zip) は
#     展開済みフォルダ形式のため tar.gz は同梱されない。
#   モードB (tar.gz / 保守経路): soloptilink-update-*.tar.gz を検出して展開する。
# Compliance: WCG-2 (critical files), WCG-5 (LF guard), WCG-11 (tar)
# Hinoue-incident compliant: no cls / no findstr / END_PAUSE / STEP markers
# =============================================================================

[CmdletBinding()]
param(
    [string]$TarballPath = "",
    # 2026-07-13: $HOME (HOMEDRIVE+HOMEPATH 由来) ではなく %USERPROFILE% を既定にする。
    # Goランチャー/自動更新フックは os.UserHomeDir()=%USERPROFILE% を参照するため、
    # AD ホームフォルダリダイレクトのある企業PCで導入先と参照先が分裂する事故を防ぐ。
    [string]$InstallDir = $(if ($env:USERPROFILE) { Join-Path $env:USERPROFILE '.soloptilink' } else { "$HOME\.soloptilink" }),
    [switch]$SkipExtract,
    [switch]$Force,
    [switch]$Verify,
    [switch]$NoActivate
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

# -----------------------------------------------------------------------------
# Colored output (Hinoue-incident compliant: no cls, no findstr)
# -----------------------------------------------------------------------------
function Write-Step($msg) { Write-Host "[STEP] $msg" -ForegroundColor Cyan }
function Write-Ok($msg)   { Write-Host "[ OK ] $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Write-Err($msg)  { Write-Host "[FAIL] $msg" -ForegroundColor Red }
function Write-Skip($msg) { Write-Host "[SKIP] $msg" -ForegroundColor DarkGreen }

# 前提ソフト導入の「要対応一覧」を集約する collector (StrictMode 対策で先に初期化)
$script:Issues    = @()
$script:HasWinget = $false
$script:LogPath   = ""
function Add-Issue($item, $detail, $remedy) {
    $script:Issues += [PSCustomObject]@{ Item = $item; Detail = $detail; Remedy = $remedy }
}
function Test-CommandExists($name) {
    return [bool](Get-Command $name -ErrorAction SilentlyContinue)
}
# 現セッションの PATH をマシン+ユーザー+既知の claude 配置先から再構築する。
# (winget / ネイティブインストーラ導入直後は現セッションに PATH 未反映のため必須)
#
# ★ ~/.local\bin を固定合成している理由 (重要・既知バグ #21365 への対処):
#   Claude Code 公式ネイティブインストーラ (irm https://claude.ai/install.ps1 | iex) は
#   claude.exe を ~/.local\bin (C:\Users\<user>\.local\bin) へ配置するが、
#   ユーザー PATH レジストリ (HKCU Environment の Path) を更新しない既知バグがある
#   (anthropics/claude-code #21365 / #14902)。このため「Installation complete!」と
#   表示されても claude が CommandNotFoundException で即失敗する。本関数が ~/.local\bin
#   を固定で合成することで、レジストリ未更新でも現セッションから claude を発見でき、
#   この既知バグを回避している。
#   ※ 配置先 ~/.local\bin はハードコード前提。将来インストーラの配置先が変われば
#     この固定合成は追従しない。配信前に必ず実機で最新の配置先を確認すること。
function Update-SessionPath {
    $machine  = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user     = [Environment]::GetEnvironmentVariable('Path', 'User')
    # 既知バグ #21365 への対処 (上記コメント参照): 公式配置先を固定で合成する。要実機確認。
    $localbin = Join-Path $HOME '.local\bin'
    $parts = @()
    foreach ($p in @($machine, $user, $localbin)) { if ($p) { $parts += ([string]$p).TrimEnd(';') } }

    # 配置先変更耐性 (任意・低優先): 他の既知候補に claude 実体があれば、その親ディレクトリも
    #   セッション PATH へ合成する。where / Get-ChildItem の再帰探索はレジストリ PATH 未更新下では
    #   空振りしうるため、ここでは "候補ディレクトリ内に claude.exe / claude.cmd が実在するか" を
    #   Test-Path でピンポイント確認し、見つかった親ディレクトリだけを足すに留める (探索しない)。
    #   ↓の候補は ~/.local\bin 以外まだ未確認。実機で実際の配置先が判明したら整理・追加すること。
    $binCandidates = @(
        $localbin,
        (Join-Path $env:LOCALAPPDATA 'Programs\claude')
    )
    foreach ($dir in $binCandidates) {
        if (-not $dir) { continue }
        $hit = (Test-Path (Join-Path $dir 'claude.exe')) -or (Test-Path (Join-Path $dir 'claude.cmd'))
        $norm = ([string]$dir).TrimEnd(';')
        if ($hit -and ($parts -notcontains $norm)) { $parts += $norm }
    }

    $env:Path = ($parts -join ';')
}
# 外部プロセスを看視付きで実行する。timeoutSec を超えたら強制終了し $null を返す
# (2026-07-13: 前提ソフト導入のハングでセットアップ全体が死ぬ事案の恒久対策)。
function Invoke-WithTimeout($file, $argList, $timeoutSec, $label) {
    try {
        $proc = Start-Process -FilePath $file -ArgumentList $argList -NoNewWindow -PassThru
    } catch {
        Write-Err "  $label の起動に失敗: $($_.Exception.Message)"
        return $null
    }
    # PS 5.1 既知問題: Handle に触れておかないと WaitForExit 後の ExitCode が $null になる
    # (プロセスハンドル未キャッシュ)。終了コードによる成否二分判定の生命線なので必須。
    $null = $proc.Handle
    if (-not $proc.WaitForExit($timeoutSec * 1000)) {
        Write-Warn "  $label が $timeoutSec 秒以内に完了しなかったため中断して次へ進みます。"
        # PS 5.1 の $proc.Kill() は子プロセスツリーを殺せない (winget の実インストーラが残る)
        # ため taskkill /T /F でツリーごと終了する。失敗時のみ Kill() にフォールバック。
        try { & taskkill /PID $proc.Id /T /F 2>$null | Out-Null } catch { try { $proc.Kill() } catch { } }
        try { $proc.WaitForExit(10000) | Out-Null } catch { }
        Add-Issue $label "導入処理が $timeoutSec 秒でタイムアウトしました (ネットワーク遅延またはハング)" '通信環境の良い状態で本インストーラを再実行するか、公式サイトから手動導入してください。導入済みの SoloptiLinkAI 本体はそのまま利用できます。'
        return $null
    }
    return $proc.ExitCode
}

# winget で1パッケージを導入 → PATH 再構築 → コマンド再検出で成否判定 (失敗は記録して継続)
#   ★winget の終了コードを捕捉し「導入失敗(ネット/権限/ソース)」と「要再起動(PATH未反映)」を二分する。
#     これをしないと、社内プロキシ遮断・ストアソース無効・管理者権限不足での失敗時に
#     『PC再起動で直る』という再起動では直らない誤った対処を要対応一覧に出してしまう
#     (日本の管理された Windows 端末で発火確度が高い)。
function Install-ViaWinget($packageId, $displayName, $verifyCommand, $officialUrl) {
    if (-not $script:HasWinget) {
        Write-Err "$displayName を自動導入できません (winget 非搭載)"
        Add-Issue $displayName 'winget (アプリ インストーラー) がこの PC に無いため自動導入できませんでした' "Microsoft Store から「アプリ インストーラー」を導入して再実行するか、公式サイト ($officialUrl) から手動で導入してください。企業管理 PC でストアが使えない場合は社内 IT 部門へ導入をご依頼ください。"
        return $false
    }
    Write-Host "  $displayName を導入中... (winget: $packageId)"
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    # ハング対策 (2026-07-13): winget が応答しなくなっても最大10分で打ち切り、
    # セットアップ全体を巻き込まない (要対応一覧に集約して続行)。
    $code = Invoke-WithTimeout 'winget' @('install','--id',$packageId,'-e','--source','winget','--accept-source-agreements','--accept-package-agreements','--silent') 600 $displayName
    if ($null -eq $code) { $code = -1 }
    $ErrorActionPreference = $prev
    Update-SessionPath
    if (Test-CommandExists $verifyCommand) {
        Write-Ok "  $displayName 導入完了"
        return $true
    }
    # winget は走ったがコマンド未検出 → 終了コードで「成功(要再起動)」と「導入失敗」を二分する。
    #   0 / 既導入 (-1978335189 = 0x8A15002B) = 導入は成功扱い → PATH 反映待ち (再起動で直る)
    #   それ以外 = 導入そのものが失敗 (ネット遮断 / ソース無効 / 権限不足) → 再起動では直らない
    if ($code -eq 0 -or $code -eq -1978335189) {
        Write-Warn "  $displayName を導入しましたが、このセッションでは確認できませんでした (PC 再起動後に反映)"
        Add-Issue $displayName '導入は成功しましたが PATH の反映に再起動が必要な可能性があります' 'PC を再起動後、新しいウィンドウで動作確認してください'
    } else {
        Write-Err "  $displayName の自動導入に失敗しました (winget 終了コード: $code)"
        Add-Issue $displayName "自動導入に失敗しました (winget 終了コード $code)。社内プロキシ/ファイアウォールによる配信先の遮断、企業ポリシーによる winget ソース無効化、または管理者権限の不足が考えられます" "ネットワーク管理者に winget 配信先 (cdn.winget.microsoft.com 等) の許可を依頼するか、公式サイト ($officialUrl) のインストーラを IT 部門経由で導入してください。管理者権限が必要な場合があります。"
    }
    return $false
}

# Hinoue-incident: always pause at the end so cmd window does not vanish
function End-Pause {
    Write-Host ""
    Write-Host "==============================================================="
    Write-Host " 何かキーを押すとウィンドウを閉じます。"
    Write-Host "==============================================================="
    if ($Host.Name -eq "ConsoleHost") {
        [void][System.Console]::ReadKey($true)
    }
}

trap {
    Write-Err "予期しないエラーが発生しました: $($_.Exception.Message)"
    Write-Host ""
    Write-Host "サポート窓口 (assist@soloptilink.com) にこの画面のスクリーンショットをお送りください。"
    try { Stop-Transcript | Out-Null } catch { }
    End-Pause
    exit 1
}

# -----------------------------------------------------------------------------
# Banner
# -----------------------------------------------------------------------------
Write-Host ""
Write-Host "================================================================="
Write-Host " SoloptiLinkAI  Windows セットアップ"
Write-Host "================================================================="
Write-Host ""

# 実行ログを setup_log.txt に保存 (うまくいかない時の原因切り分け用)
try {
    if (-not (Test-Path $InstallDir)) { New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
    $script:LogPath = Join-Path $InstallDir 'setup_log.txt'
    Start-Transcript -Path $script:LogPath -Append | Out-Null
} catch {
    $script:LogPath = ""
    Write-Host "  (ログの保存に失敗しました。環境ポリシーの可能性があります。処理は続行します。)" -ForegroundColor DarkGray
}

# -----------------------------------------------------------------------------
# STEP 1: PowerShell / Windows 環境チェック
# -----------------------------------------------------------------------------
Write-Step "1/11 環境チェック"

$psVer = $PSVersionTable.PSVersion
Write-Host "  PowerShell: $psVer"
if ($psVer.Major -lt 5) {
    Write-Err "PowerShell 5.0+ が必要です。Windows Update を適用してください。"
    End-Pause; exit 1
}

$winVer = [System.Environment]::OSVersion.Version
Write-Host "  Windows:    $winVer"

# Long path support check
try {
    $longPath = Get-ItemPropertyValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" -Name "LongPathsEnabled" -ErrorAction SilentlyContinue
    if ($longPath -eq 1) {
        Write-Ok "  ロングパス対応: 有効"
    } else {
        Write-Warn "  ロングパス未対応 (260文字制限あり)。管理者 PowerShell で以下を推奨:"
        Write-Warn "    Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' LongPathsEnabled 1"
    }
} catch {
    Write-Warn "  ロングパス設定の確認をスキップ"
}

# -----------------------------------------------------------------------------
# STEP 2: インストール先確認
# -----------------------------------------------------------------------------
Write-Step "2/11 インストール先確認: $InstallDir"

if (-not (Test-Path $InstallDir)) {
    Write-Host "  ディレクトリを作成します。"
    New-Item -ItemType Directory -Path $InstallDir | Out-Null
}
Write-Ok "  インストール先 OK"

# -----------------------------------------------------------------------------
# STEP 3: 配布物の検出 (モードA: ZIP展開済みフォルダ / モードB: tar.gz)
# -----------------------------------------------------------------------------
Write-Step "3/11 配布物を検出"

# モードA: このスクリプトの親フォルダ = 解凍済み配布フォルダか?
#   顧客ZIP の構造: SoloptiLinkAI_vX.Y_Windows\installer\soloptilink-install.ps1
#   → 親フォルダに chain.sh + lib\ が居れば配布フォルダと判定
$PkgRoot = Split-Path -Parent $PSScriptRoot
$IsZipMode = $false
if ((Test-Path (Join-Path $PkgRoot "chain.sh")) -and (Test-Path (Join-Path $PkgRoot "lib"))) {
    $IsZipMode = $true
    Write-Ok "  解凍済み配布フォルダを検出: $PkgRoot"
}

# モードB: tar.gz 検索 (ZIPフォルダが見つからない場合のみ)
if (-not $IsZipMode) {
    if (-not $TarballPath) {
        $candidates = @(
            "$InstallDir\soloptilink-update-*.tar.gz",
            "$HOME\Downloads\soloptilink-update-*.tar.gz",
            "$PSScriptRoot\soloptilink-update-*.tar.gz"
        )
        foreach ($pat in $candidates) {
            $found = Get-ChildItem $pat -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if ($found) {
                $TarballPath = $found.FullName
                break
            }
        }
    }
    if (-not $TarballPath -or -not (Test-Path $TarballPath)) {
        Write-Err "  配布物が見つかりません。"
        Write-Host ""
        Write-Host "  以下のいずれかをお試しください:"
        Write-Host "   1. ダウンロードした SoloptiLinkAI_v*_Windows.zip を右クリック →「すべて展開」"
        Write-Host "      で解凍し、その中の installer\soloptilink-install.bat を実行する"
        Write-Host "   2. (保守用) soloptilink-update-v*.tar.gz を ~\Downloads に置いて再実行する"
        End-Pause; exit 1
    }
    Write-Ok "  検出 (tar.gz): $TarballPath"
}

# -----------------------------------------------------------------------------
# STEP 4: 既存インストールのバックアップ
# -----------------------------------------------------------------------------
Write-Step "4/11 既存ファイルのバックアップ"

# PFP-119: 認証引継ぎ用にバックアップ先を後続ステップでも参照できるよう初期化
$backupDir = ""

# ZIPモードで既に ~\.soloptilink 内から実行されている場合は配置不要
$SamePlace = $false
if ($IsZipMode) {
    try {
        $a = (Resolve-Path $PkgRoot).Path.TrimEnd('\')
        $b = (Resolve-Path $InstallDir).Path.TrimEnd('\')
        if ($a -ieq $b) { $SamePlace = $true }
    } catch { }
}

if (-not $SkipExtract -and -not $SamePlace) {
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $backupDir = "$InstallDir\.backups\pre-install-$stamp"
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

    # PFP-119: 認証系3ファイル (activation.json / .device_identity.json / license.json) も退避対象に含める
    foreach ($item in @("lib", "chain.sh", "VERSION", "VERSION.txt", "activation.json", ".device_identity.json", "license.json")) {
        $src = Join-Path $InstallDir $item
        if (Test-Path $src) {
            Copy-Item $src $backupDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
    Write-Ok "  バックアップ: $backupDir"
} else {
    Write-Warn "  バックアップをスキップ"
}

# -----------------------------------------------------------------------------
# STEP 5: 配布物の配置 (モードA: コピー / モードB: tar.gz 展開)
# -----------------------------------------------------------------------------
Write-Step "5/11 配布物の配置"

if ($SkipExtract) {
    Write-Warn "  -SkipExtract 指定により配置をスキップ"
} elseif ($IsZipMode) {
    if ($SamePlace) {
        Write-Ok "  既に $InstallDir に展開済みのため配置をスキップ"
    } else {
        # 解凍済みフォルダの中身を丸ごと InstallDir へ上書きコピー
        # robocopy exit code: 0-7 = 成功 (8+ が失敗)
        & robocopy "$PkgRoot" "$InstallDir" /E /NFL /NDL /NJH /NJS /R:2 /W:2 | Out-Null
        $rc = $LASTEXITCODE
        if ($rc -ge 8) {
            Write-Err "  コピー失敗 (robocopy exit=$rc)"
            Write-Host "  ヒント: Claude Desktop / Claude Code が起動中だと本体ファイルがロックされ" -ForegroundColor Yellow
            Write-Host "         コピーに失敗することがあります。両方を終了してから再実行してください。" -ForegroundColor Yellow
            End-Pause; exit 1
        }
        Write-Ok "  配置完了: $PkgRoot → $InstallDir"
    }
} else {
    # tar (Windows 10 1803+ で標準搭載)
    if (-not (Get-Command tar -ErrorAction SilentlyContinue)) {
        Write-Err "  tar コマンドが見つかりません。Windows 10 1803 以降が必要です。"
        End-Pause; exit 1
    }
    Push-Location $InstallDir
    try {
        # --strip-components=1 でトップディレクトリ (soloptilink-vX.Y.Z/) を剥がす
        & tar -xzf $TarballPath --strip-components=1
        if ($LASTEXITCODE -ne 0) {
            Write-Err "  tar 展開失敗 (exit=$LASTEXITCODE)"
            End-Pause; exit 1
        }
        Write-Ok "  展開完了"
    } finally {
        Pop-Location
    }
}

# -----------------------------------------------------------------------------
# 再インストール時の認証引継ぎ (PFP-119 / 2026-06-12)
# 認証系3ファイル (activation.json / .device_identity.json / license.json) は
# 配布物に含まれないため、上書き配置後もそのまま残る設計。万一消えていた場合は
# STEP 4 のバックアップから自動で書き戻し、再インストール後の再認証を不要にする。
# -----------------------------------------------------------------------------
$authFiles = @("activation.json", ".device_identity.json", "license.json")
$authCarried = 0
foreach ($af in $authFiles) {
    $dst = Join-Path $InstallDir $af
    if (-not (Test-Path $dst) -and $backupDir -and (Test-Path (Join-Path $backupDir $af))) {
        Copy-Item (Join-Path $backupDir $af) $dst -Force -ErrorAction SilentlyContinue
    }
    if (Test-Path $dst) { $authCarried++ }
}
if ($authCarried -gt 0) {
    Write-Ok "  認証情報は引き継ぎました (再認証は不要です)"
}

# -----------------------------------------------------------------------------
# STEP 6: CRLF -> LF 正規化 (Windows 標準展開で CRLF が混入することがある)
# -----------------------------------------------------------------------------
Write-Step "6/11 改行コード正規化 (.sh ファイル)"

$shFiles = Get-ChildItem -Path $InstallDir -Filter "*.sh" -Recurse -ErrorAction SilentlyContinue
$fixedCount = 0
foreach ($f in $shFiles) {
    try {
        $bytes = [System.IO.File]::ReadAllBytes($f.FullName)
        if ($bytes -contains 13) {
            $text = [System.IO.File]::ReadAllText($f.FullName)
            $text = $text -replace "`r`n", "`n" -replace "`r", "`n"
            [System.IO.File]::WriteAllText($f.FullName, $text, [System.Text.UTF8Encoding]::new($false))
            $fixedCount++
        }
    } catch {
        # skip
    }
}
Write-Ok "  CRLF 正規化: $fixedCount ファイル修正"

# -----------------------------------------------------------------------------
# STEP 7: WCG-2 lib/ 完整性検証 (林事案の直接ガード)
# -----------------------------------------------------------------------------
Write-Step "7/11 lib/ 完整性検証 (WCG-2)"

$required = @(
    "lib\license-guard.sh",
    "lib\core\layer-loader.sh",
    "chain.sh"
)
$missing = @()
foreach ($r in $required) {
    $p = Join-Path $InstallDir $r
    if (-not (Test-Path $p)) { $missing += $r }
}

if ($missing.Count -gt 0) {
    Write-Err "  必須ファイルが不足しています:"
    foreach ($m in $missing) { Write-Host "     - $m" -ForegroundColor Red }
    Write-Host ""
    Write-Host "  配布物が破損している可能性があります。assist@soloptilink.com にお問い合わせください。"
    End-Pause; exit 1
}
Write-Ok "  lib/license-guard.sh, lib/core/layer-loader.sh, chain.sh すべて存在"

# -----------------------------------------------------------------------------
# STEP 8: Goランチャー検出 + 端末認証 (アクティベーション)
# -----------------------------------------------------------------------------
Write-Step "8/11 Goランチャー検出 + 端末認証"

$launcher = $null
$candidates = @("soloptilink.exe", "soloptilink-windows-amd64.exe", "soloptilink-windows-arm64.exe")
foreach ($c in $candidates) {
    $p = Join-Path $InstallDir $c
    if (Test-Path $p) { $launcher = $p; break }
}

$activated = $false
if (-not $launcher) {
    Write-Warn "  soloptilink.exe が見つかりません。"
    Write-Host "  assist@soloptilink.com に Windows 用ランチャーをご請求ください。"
} else {
    Write-Ok "  検出: $launcher"

    if ($Verify) {
        Write-Host ""
        Write-Step "認証ステータス確認"
        # ネイティブコマンドの stderr が Stop で例外化する PS 5.1 の罠を避ける
        # (自動更新直後の初回 --status やオフライン時の警告が stderr に出ると
        #  NativeCommandError へ昇格し最上位 trap に捕捉されてしまう)
        $prevEAP = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try { & $launcher --status 2>&1 | Out-Host } catch { }
        $ErrorActionPreference = $prevEAP
    }

    # 端末認証 (承認済みなら自動スキップ / -NoActivate で抑止)
    if (-not $NoActivate) {
        # ネイティブコマンドの stderr が Stop で例外化する PS 5.1 の罠を避ける
        $prevEAP = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        $statusOut = ""
        try { $statusOut = (& $launcher --status 2>&1 | Out-String) } catch { }
        if ($statusOut -match "承認済み") {
            Write-Ok "  この端末は承認済みです。アクティベーションは不要です。"
            $activated = $true
        } else {
            Write-Host ""
            Write-Host "  続けて端末認証 (アクティベーション) を開始します。"
            Write-Host "  画面の案内に従ってメールアドレス等を入力してください。"
            Write-Host ""
            try {
                # 2026-07-13 敵対検証で確証: 承認待ちポーリング (最大30分) をインストーラ内で
                # 同期実行すると、ランチャー自身が案内する Ctrl+C がコンソール全体に配送されて
                # 本インストーラごと停止し、後続工程 (MCP登録/自動更新フック/前提ソフト) が
                # 全滅する。登録だけ行い、承認待ちはスキップして次の工程へ進む。
                $env:SOLOPTILINK_ACTIVATE_NO_WAIT = '1'
                & $launcher --activate
                $activated = $true
            } catch {
                Write-Warn "  端末認証を完了できませんでした。後で以下を実行してください:"
                Write-Host "    cd ~\.soloptilink"
                Write-Host "    .\soloptilink.exe --activate"
            } finally {
                Remove-Item Env:SOLOPTILINK_ACTIVATE_NO_WAIT -ErrorAction SilentlyContinue
            }
        }
        $ErrorActionPreference = $prevEAP
    }
}

# -----------------------------------------------------------------------------
# STEP 9: Claude Desktop MCP 自動登録 (PFP-119 / 2026-06-12)
# %APPDATA%\Claude\claude_desktop_config.json へ soloptilink MCP サーバーを
# マージ登録する (ConvertFrom-Json/ConvertTo-Json で既存の mcpServers 設定は保持)。
# 登録に失敗してもセットアップ全体は続行する (後から手動登録可能)。
# -----------------------------------------------------------------------------
Write-Step "9/11 Claude Desktop MCP 自動登録"

if (-not $launcher) {
    Write-Warn "  Goランチャー未検出のため MCP 登録をスキップしました。"
    Write-Host "  ランチャー配置後に installer\install-claude-desktop-mcp.ps1 を実行してください。"
} else {
    try {
        $cfgDir = Join-Path $env:APPDATA "Claude"
        $cfgPath = Join-Path $cfgDir "claude_desktop_config.json"
        if (-not (Test-Path $cfgDir)) {
            New-Item -ItemType Directory -Path $cfgDir -Force | Out-Null
            Write-Warn "  Claude Desktop が未インストールの可能性があります (設定フォルダを新規作成)"
        }

        # 既存設定の読み込み + バックアップ (壊れていても新規作成にフォールバック)
        $mcpStamp = Get-Date -Format "yyyyMMdd-HHmmss"
        $cfg = $null
        if (Test-Path $cfgPath) {
            Copy-Item $cfgPath "$cfgPath.bak.$mcpStamp" -Force -ErrorAction SilentlyContinue
            try { $cfg = Get-Content $cfgPath -Raw | ConvertFrom-Json } catch { $cfg = $null }
        }
        if ($null -eq $cfg) { $cfg = [PSCustomObject]@{} }

        # mcpServers プロパティが無い/null なら作成 (既存エントリは保持)
        if (-not ($cfg.PSObject.Properties.Name -contains "mcpServers")) {
            $cfg | Add-Member -MemberType NoteProperty -Name "mcpServers" -Value ([PSCustomObject]@{})
        }
        if ($null -eq $cfg.mcpServers) { $cfg.mcpServers = [PSCustomObject]@{} }

        # soloptilink エントリを登録 (既存なら上書き)
        $entry = [PSCustomObject]@{
            command = $launcher.Replace("\", "/")
            args    = @("--mcp-server")
        }
        if ($cfg.mcpServers.PSObject.Properties.Name -contains "soloptilink") {
            $cfg.mcpServers.soloptilink = $entry
        } else {
            $cfg.mcpServers | Add-Member -MemberType NoteProperty -Name "soloptilink" -Value $entry
        }

        # JSON 書き戻し (UTF-8 BOM なし)
        $json = $cfg | ConvertTo-Json -Depth 20
        [System.IO.File]::WriteAllText($cfgPath, $json, [System.Text.UTF8Encoding]::new($false))
        Write-Ok "  Claude Desktop に soloptilink MCP サーバーを登録しました"
        Write-Host "  (反映には Claude Desktop の完全終了 → 再起動が必要です)"
    } catch {
        Write-Warn "  MCP 自動登録に失敗しました: $($_.Exception.Message)"
        Write-Host "  後で installer\install-claude-desktop-mcp.ps1 を実行してください。"
    }
}

# -----------------------------------------------------------------------------
# STEP 10: Claude Code 自動更新フックの登録 (2026-06-15 野村Windows事案 恒久対策)
# -----------------------------------------------------------------------------
# 【鶏卵デッドロックの解消 + Windows bash 非依存化】
# 従来 Windows では「自動更新フックを誰も登録しない」かつ「フック本体が bash 依存で
# 起動できない」ため、自動更新が一度も走らなかった。ここで導入時点で、ランチャー
# (.exe) 経由のフック (`"<exe>" --hook-autoupdate`) を ~/.claude/settings.json へ
# 冪等登録する。JSON マージは Go 実装に委譲し、PowerShell の配列直列化事故を避ける。
Write-Step "10/11 自動更新を有効化 (Claude Code フック登録)"

if (-not $launcher) {
    Write-Warn "  Goランチャー未検出のため自動更新フック登録をスキップしました。"
    Write-Host "  ランチャー配置後に手動更新できます: .\soloptilink.exe --update"
} else {
    $prevEAP2 = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $hookOut = ""
    try { $hookOut = (& $launcher --register-autoupdate-hook 2>&1 | Out-String) } catch { }
    $ErrorActionPreference = $prevEAP2
    # 2026-07-13 敵対検証で確証: 旧判定 (-match "登録") は失敗メッセージ
    # 「自動更新フックの登録に失敗」にもマッチして偽成功になる。成功文言に限定する。
    if ($hookOut -match "登録しました|既に登録済み") {
        Write-Ok "  自動更新フックを登録しました (以降 Claude Code 起動時に最新版を自動取得)"
    } else {
        Write-Warn "  自動更新フック登録の結果を確認できませんでした。"
        Write-Host "  手動更新できます: cd ~\.soloptilink ; .\soloptilink.exe --update"
    }
}

# -----------------------------------------------------------------------------
# STEP 11: 前提ソフト (Git / Node.js / Claude Code) の確認と導入 — 必ず最後に実行する
#   【2026-07-13 インサイドグロース事案 恒久対策 / 順序の設計意図】
#   旧実装はこの前提ソフト導入を本体配置より前 (STEP 1.5) に実行しており、
#   winget が固まる・ウィンドウが閉じられる等で死ぬと SoloptiLink 本体が
#   1 ファイルも配置されないまま導入失敗になっていた (実事案: Git 導入中に
#   トランスクリプトが途絶し ~/.soloptilink が空のまま)。
#   本体配置・端末認証・MCP 登録・自動更新フックはいずれも Git/Node に依存
#   しないため、先に本体導入を完遂し、前提ソフトは最後に看視付きで導入する。
#   各ソフトは「先に検出し、在ればスキップ」する冪等設計 (再実行しても無害)。
#     - Git for Windows : SoloptiLink の bash 製 lib / chain.sh の動作に必要
#     - Node.js (LTS)   : 生成される業務システムの実行・ビルド検証に必要 (Claude Code 自体は Node 不要)
#     - Claude Code     : 公式ネイティブインストーラで導入 (背景で自動更新)
#   途中で失敗しても終了せず、最後に「要対応一覧」へ集約する。
# -----------------------------------------------------------------------------
Write-Step "11/11 前提ソフト (Git / Node.js / Claude Code) を確認・導入"
Write-Host "  ※ SoloptiLinkAI 本体の導入・端末認証はすでに完了しています。" -ForegroundColor DarkGray
Write-Host "  ※ ここから先は補助ソフトの導入です。数分かかることがありますが、" -ForegroundColor DarkGray
Write-Host "     このウィンドウを閉じずにお待ちください (各ソフト最大10分で自動的に次へ進みます)。" -ForegroundColor DarkGray

# winget (アプリ インストーラー) の有無 = 前提ソフト導入の主手段
$script:HasWinget = Test-CommandExists 'winget'
if ($script:HasWinget) { Write-Ok "  winget (アプリ インストーラー) 検出" }
else { Write-Warn "  winget が見つかりません。前提ソフトの自動導入が制限されます (要対応に集約します)。" }

# 管理者権限の状況を通知 (昇格は強制しない = UAC 摩擦を最小化)。ソフト導入時に winget/MSI が
# 個別に昇格を求めることがあるため、その際の操作を事前に案内する。
try {
    $IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $IsAdmin) {
        Write-Warn "  一般ユーザーで実行中です。ソフト導入時に管理者の許可 (UAC) を求められたら「はい」を選んでください。企業管理 PC では IT 部門の協力が必要な場合があります。"
    }
} catch { }

# 失敗してもセットアップ全体を止めないため、このフェーズ中は継続モードにする
$prereqEAP = $ErrorActionPreference
$ErrorActionPreference = 'Continue'

# --- Git for Windows ---
if (Test-CommandExists 'git') {
    Write-Skip ("Git ({0})" -f (& git --version 2>&1 | Select-Object -First 1))
} else {
    Write-Host "  Git: 未導入 → 導入します"
    Install-ViaWinget 'Git.Git' 'Git for Windows' 'git' 'https://git-scm.com/download/win' | Out-Null
}

# --- Node.js (LTS / v18 以上) ---
$needNode = $true
if (Test-CommandExists 'node') {
    $nodeVer = (& node -v 2>&1 | Select-Object -First 1)
    $nodeMajor = 0
    if ($nodeVer -match '^v(\d+)\.') { $nodeMajor = [int]$matches[1] }
    if ($nodeMajor -ge 18) {
        Write-Skip ("Node.js ({0})" -f $nodeVer)
        $needNode = $false
    } else {
        Write-Warn ("  Node.js ({0}) は古いため最新 LTS へ更新します (必要: v18 以上)" -f $nodeVer)
    }
} else {
    Write-Host "  Node.js: 未導入 → 導入します"
}
if ($needNode) {
    Install-ViaWinget 'OpenJS.NodeJS.LTS' 'Node.js (LTS)' 'node' 'https://nodejs.org/en/download' | Out-Null
}

# --- Claude Code (公式ネイティブインストーラ = 背景で自動更新) ---
if (Test-CommandExists 'claude') {
    Write-Skip ("Claude Code ({0})" -f (& claude --version 2>&1 | Select-Object -First 1))
} else {
    Write-Host "  Claude Code: 未導入 → 導入します (公式ネイティブインストーラ / 自動更新あり)"
    # iex が exit を呼んでも本インストーラを巻き込まないよう、子 PowerShell で実行する。
    # ハング対策: 看視付き (Invoke-WithTimeout)。固まっても最大10分で次へ進む。
    # 注: PS 5.1 の Start-Process は配列引数を引用符なしで空白結合するため、
    #     空白を含む -Command は単一文字列で渡す (二重引用符を明示)。
    $claudeCode = Invoke-WithTimeout 'powershell' '-NoProfile -ExecutionPolicy Bypass -Command "irm https://claude.ai/install.ps1 | iex"' 600 'Claude Code (公式インストーラ)'
    if ($null -eq $claudeCode) { $claudeCode = -1 }
    Update-SessionPath
    # ネイティブで入らなければ winget 版へフォールバック (自動更新は環境変数で補う)
    if (-not (Test-CommandExists 'claude') -and $script:HasWinget) {
        Write-Warn "  winget 経由での導入に切り替えます"
        try {
            [Environment]::SetEnvironmentVariable('CLAUDE_CODE_PACKAGE_MANAGER_AUTO_UPDATE', '1', 'User')
            $claudeCode = Invoke-WithTimeout 'winget' @('install','--id','Anthropic.ClaudeCode','-e','--source','winget','--accept-source-agreements','--accept-package-agreements','--silent') 600 'Claude Code (winget)'
            if ($null -eq $claudeCode) { $claudeCode = -1 }
        } catch {
            Write-Err "  winget 経由でも導入に失敗: $($_.Exception.Message)"
            $claudeCode = -1
        }
        Update-SessionPath
    }
    if (Test-CommandExists 'claude') {
        Write-Ok "  Claude Code 導入完了"
    } elseif ($claudeCode -eq 0 -or $claudeCode -eq -1978335189) {
        # 導入は成功した形跡 → PATH 未反映 (公式インストーラがレジストリ PATH を更新しない既知事象 #21365 を含む。再起動で直る)
        Write-Warn "  Claude Code を導入しましたが、このセッションでは確認できませんでした (PC 再起動後に反映)"
        Add-Issue 'Claude Code' '導入は成功しましたが PATH の反映に再起動が必要な可能性があります' 'PC を再起動後、新しいウィンドウで claude --version を実行してください。表示されない場合はサポートへご連絡ください。'
    } else {
        # 導入そのものが失敗 → ネットワーク / プロキシ / SmartScreen / オフライン
        Write-Err "  Claude Code の自動導入に失敗しました (終了コード: $claudeCode)"
        Add-Issue 'Claude Code' "自動導入に失敗しました (終了コード $claudeCode)。claude.ai への到達不可 (社内プロキシ/ファイアウォール)、SmartScreen による実行ブロック、またはオフライン環境が考えられます" 'ネットワーク管理者に claude.ai および Anthropic 配信ドメインの許可を依頼してください。SmartScreen の警告画面でブロックされた場合は「詳細情報」→「実行」を選択するか、IT 部門に実行許可を依頼してください。オフライン環境では、別のオンライン端末で導入した Claude Code を持ち込むか、サポートへご連絡ください。'
    }
}

$ErrorActionPreference = $prereqEAP

# -----------------------------------------------------------------------------
# 動作確認 (各前提ソフトのバージョンを実測表示)
# -----------------------------------------------------------------------------
Write-Step "動作確認 (バージョン表示)"
$verEAP = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
function Show-Ver($label, $cmd, $verArg) {
    if (Test-CommandExists $cmd) {
        $out = (& $cmd $verArg 2>&1 | Select-Object -First 1)
        Write-Host ("  [ OK ] {0,-12}: {1}" -f $label, $out) -ForegroundColor Green
    } else {
        Write-Host ("  [FAIL] {0,-12}: 確認できません (PC 再起動後に再確認してください)" -f $label) -ForegroundColor Red
    }
}
Show-Ver 'Git'         'git'    '--version'
Show-Ver 'Node.js'     'node'   '-v'
Show-Ver 'npm'         'npm'    '-v'
Show-Ver 'Claude Code' 'claude' '--version'
$ErrorActionPreference = $verEAP

# -----------------------------------------------------------------------------
# Finish
# -----------------------------------------------------------------------------
Write-Host ""
Write-Host "================================================================="
Write-Host " セットアップ完了"
Write-Host "================================================================="
Write-Host ""
# 要対応一覧 (前提ソフトで自動完了できなかったもの)
if ($script:Issues.Count -gt 0) {
    Write-Host " 【要対応】以下は自動で完了できませんでした:" -ForegroundColor Yellow
    $idx = 1
    foreach ($iss in $script:Issues) {
        Write-Host ("   {0}. {1}" -f $idx, $iss.Item) -ForegroundColor Yellow
        Write-Host ("      原因 : {0}" -f $iss.Detail)
        Write-Host ("      対処 : {0}" -f $iss.Remedy)
        $idx++
    }
    Write-Host "   ※ まず上記の【要対応】を解消してから、下の「次のステップ」へお進みください。" -ForegroundColor Yellow
    Write-Host ""
}

Write-Host " 次のステップ:"
Write-Host ""
if (-not $activated) {
    Write-Host "   1. 端末アクティベーション (未完了の場合):"
    Write-Host "        cd ~\.soloptilink"
    Write-Host "        .\soloptilink.exe --activate"
    Write-Host ""
    Write-Host "   2. 管理者による端末承認をお待ちください (承認メールが届きます)"
    Write-Host ""
    Write-Host "   3. Claude Code にログイン (新しいウィンドウで claude と入力)"
    Write-Host "      ※ ご利用には有料の Claude プラン (Pro / Max / Team / Enterprise) または" -ForegroundColor DarkYellow
    Write-Host "        API のご契約が必要です。無料プランでは Claude Code は使えません。" -ForegroundColor DarkYellow
    Write-Host ""
    Write-Host "   4. Claude Code を開いて /soloptilink または /soloptilink-boost で開始"
} else {
    Write-Host "   1. 管理者による端末承認をお待ちください (承認メールが届きます)"
    Write-Host ""
    Write-Host "   2. Claude Code にログイン (新しいウィンドウで claude と入力)"
    Write-Host "      ※ ご利用には有料の Claude プラン (Pro / Max / Team / Enterprise) または" -ForegroundColor DarkYellow
    Write-Host "        API のご契約が必要です。無料プランでは Claude Code は使えません。" -ForegroundColor DarkYellow
    Write-Host ""
    Write-Host "   3. Claude Code を開いて /soloptilink または /soloptilink-boost で開始"
}
Write-Host ""
Write-Host "   すでに前提ソフトを導入済みの方は、導入工程は自動でスキップされています (再実行しても無害)。" -ForegroundColor DarkGray
if ($script:LogPath) { Write-Host ("   実行ログ: {0}" -f $script:LogPath) -ForegroundColor DarkGray }
Write-Host ""

try { Stop-Transcript | Out-Null } catch { }
End-Pause
exit 0
