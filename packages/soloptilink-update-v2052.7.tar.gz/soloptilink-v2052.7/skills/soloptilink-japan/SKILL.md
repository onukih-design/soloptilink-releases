---
name: soloptilink-japan
description: "SoloptiLinkAI v2052.7 JAPAN-NATIVE Mode v15.4.0 - 日本の法令・業種・SI実務知識を完全内蔵するドメイン特化モード。日本の仕事にそのまま刺さる成果物を生成する。詳細は本文「機能概要」参照。"
argument-hint: "[作りたいもの] [--industry 建設|建築設計|製造|医療|介護|士業|小売|飲食|運輸|IT|美容|金融|公共|教育|不動産|観光|...] [--laws インボイス,電帳法,...] [--locale ja|en|zh-CN] [--enterprise sso,offline] [--bug-prevention strict|standard] [--inject <target_project_dir>] [--drawings site_plan,floor_plan,elevation,section,detail_section,door_window_schedule,foundation_plan] [--estimate rough|detailed] [--prefecture <県名>] [--city <市町村名>] [--ops incident,bcp,sre,security_audit] [--law-tracking egov,case_law] [--public procurement,subsidy] [--finance zengin,aml,suitability] [--gov-eapps corporate_number,gbiz_id,etax,eltax,egov,jgrants] [--education irt,scorm,xapi,lti,course_of_study,shidoyoroku] [--real-estate mediation,reins,article35,sinrikashi] [--logistics tenko,kaizen_kijun,standard_freight,operations_manager,tsp] [--tourism minpaku,ryokan,travel_agency,accommodation_tax,duty_free]"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, Agent, WebSearch, WebFetch, AskUserQuestion, TodoWrite"
---

# SoloptiLinkAI v2052.7 - JAPAN-NATIVE MODE (Phase 16-20 政府電子申請・教育機関・不動産業・物流運輸・観光宿泊)

## 機能概要

SoloptiLinkAI v2052.7 JAPAN-NATIVE Mode v15.4.0 (Phase 51 SIEL Production-Grade Layer NEW 2026-05-17: +8 Forges (observability OTel+Prometheus+Grafana / api_documentation OpenAPI 3.0+Postman / multi_tenant_saas RLS+RBAC+Stripe / compliance_audit ISO27001+SOC2+個情法R4+HIPAA+GDPR / disaster_recovery RTO+RPO+3-2-1+訓練 / ai_integration LLM Provider抽象化+RAG+Token / database_schema 業種別Prisma+AuditLog / customer_onboarding 12週標準)、Ecosystem Test 50/50 PASS、Phase 51 専用 15/15 PASS、累計353/353 PASS、SIEL累計70要素、本番運用グレード達成) + Phase 50 SIEL Ecosystem Integration Layer (2026-05-17: +11 Forges (arte_omega_bridge ARTE-Omega→CCS軸9連動 / siel_orchestrator 4phase連鎖 / migration_forge 業種別データ移行 / pm_forge WBS+リスク+課題+進捗 / qa_forge 静的解析+セキュリティ+性能+UX / performance_test_forge k6+Artillery業種別 / ci_cd_forge GitHub Actions 4workflow / docker_forge multi-stage+healthcheck+non-root / i18n_forge ja/en/zh-CN / siel_self_heal 6種コード修復 / ecosystem_integration_test 42アサーション)、Ecosystem Test 42/42 PASS、累計338/338 PASS、56+ファイル自動生成、SIEL累計62要素) + Phase 49 SIEL Completion Layer (2026-05-16: +4 scripts manual_forge/siel_hook/ccs_html_report/integration_test + 5 NFR追加 printing/dental/bridal/bpo/franchise + diagram_industry_matrix.json + バグ修正 calc_ccs/d2d_run/requirement_extractor、integration_test.sh 36/36 PASS、累計323/323 PASS、業種カバー15業種、CCS HTMLダッシュボード対応、siel_hook.sh で chain.sh統合エントリポイント7actions提供) + Phase 48 SIEL Implementation Layer (2026-05-16: 14 scripts d2d_run/siel_init/industry_mapper/requirement_extractor/review_point_detector/trace_matrix_gen/uat_evidence_collect/legal_doc_render/ccs_repair_loop + Mermaid5種ジェネレーター + 5追加NFR(construction/logistics/longterm_care/education/professional) + 5 Legal Templates + Workshop Template、bash d2d_run.sh 1コマンドでPhase A→G完走 311テスト全PASS + Phase 47 SI Excellence Layer + Phase 46 ドメインカバレッジ完成 + Phase 44-IP 知財3法 + Phase 43-IT 国際貿易 + Phase 42-HC ヘルスケアIT + Phase 32-CS サイバーセキュリティ + Phase 37-41 + Phase 32-36 + Phase 27-31 + Phase 22-26 + Phase 22 ガバナンス3軸 + Phase 23-CS/24-FA) - 日本のあらゆる知識を完全内蔵。**Phase 47 (NEW v15.0.0 2026-05-16): SI Excellence Layer (SIEL) 構築** — 1発でSI受託開発会社レベルを実現する16要素 (9サブモジュール: SIEL Manifest/D2D Pipeline/DiagramForge Mermaid5種/Review Point Forge 10カテゴリ謙虚な真実性/UAT Evidence Collector スクショ+API+JSON/Trace Matrix 5軸/Manual Forge 管理者+EU/Legal Doc Forge 5書類/Customer Confidence Score 10軸100点 Reject〜Platinum認定 + 5 NFRテンプレ generic/medical 3省2GL/finance FISC+PCI-DSS/public 会計法29条の3+ガバメントクラウド/retail 特商法+ステマ + 2 scripts siel_validate.sh+calc_ccs.sh)。**Phase 46 (v14.0.0): ドメイン辞書 39→51 完成**。JP-Quality Fortress **v17 71軸710点満点 Diamond★★★★★ 維持**。Phase 1-47 自己検証 **299件全PASS** (Phase 47 12件加算)。トヨタ生産方式モード+SI Excellence Layer の二層構造で「賢いAIではなく賢いシステム」「無謬でなく謙虚に正直」を実装、Claude Code 原理的に到達不可能領域を完全独占。**Phase 52 (v2051 2026-07-08): 税務特化 Phase B (tax-advisory 9モジュール: taxability/corporate-tax/incentives/audit-risk/group-taxation/reorganization/international/amendments/local-tax・provenance 302件辞書照合・TaxJudgment契約=根拠条文+専門家確認フラグ) + 医療特化 Phase A/B (medical-billing 3業態+emr-core+医療用語辞書345エントリ・PFP-143 3省2ガイドラインゲート) + 建設・図面レーン (drawings 21種SVG+DXF/construction-knowledge 建築知識DB+概算見積) + 生成経路16レーン一本化 (domain-lane-injector: reward/tax/authority/official-forms/drawings/construction-knowledge/payroll/logistics/real-estate/finance-transfer/accounting/medical-billing/emr-core/tax-advisory)。L41-TAX/L44-MDICT/PFP-144/PFP-150 検証軸+ゲート敷設・回帰ゼロ・born-passing両側弁別実証済。**

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

Claude Code が絶対に作らない「日本の仕事にそのまま刺さる」成果物を作るためのドメイン特化スキル。
対Claude Code差別化戦略の第一柱 **JAPAN-NATIVE** + 第三柱 **ENTERPRISE-READY** + 第四柱 **ECOSYSTEM** の実装本体。

## パッケージ構成（Phase 20 完了時 / v2015.9）

```
soloptilink-japan/
├── domains/ 25業種 (Phase 21 で +5: hr / franchise / dental / pharmacy / laundry)
├── lib/japan/ 49ファイル (
│     ── Phase 1〜9 既存 23ファイル ──
│     laws.ts + laws_extended.ts (20法令)
│     + Wareki/Tax/Keigo/Kana/Postal + Visual Confirm + Intent Compiler + i18n
│     + compliance_ledger + dialect_parser + handoff_plus + observability + workflow_engine
│     + save_guarantee.ts + bug_prevention.ts + bug_prevention_ext.ts (Phase 6/7: 25バグ予防)
│     + architecture.ts + drawings.ts + estimates.ts + regional_laws.ts + knowledge_index.ts (Phase 9: 1級建築士)
│     ── Phase 10 商習慣完全統合 ──
│     + eseal.ts (NEW: 電子印鑑/タイムスタンプ署名/JIPDEC適合)
│     + fax_ocr.ts (NEW: FAX注文書OCR + 商品マスタ突合)
│     + excel_pivot.ts (NEW: Excel風ピボット集計 SUMIFS/VLOOKUP相当)
│     + ringi.ts (NEW: 決裁権限規程DSL + 合議ルート + 職位印)
│     ── Phase 11 医療・介護 ──
│     + medical.ts (NEW: 診療報酬R6 + UKE電算 + HPKI + 3省2ガイドライン + FHIR JP Core)
│     + longterm_care.ts (NEW: 介護報酬R6 + 区分支給限度額 + LIFE + ケアプラン1〜7表 + 処遇改善加算)
│     ── Phase 12 運用成熟 ──
│     + incident.ts (NEW: 個情法第26条R4改正 + JPCERT/CC + 謝罪文/プレスリリース + Blameless Post-Mortem)
│     + bcp.ts (NEW: 15災害シナリオ + 首都直下70%/南海トラフ80% + RTO/RPO/MTPD)
│     + security_audit.ts (NEW: ISMS/Pマーク/SOC2/J-SOX ITGC/ISMAP + WORM保管7年)
│     + sre_jp.ts (NEW: 日本祝日カレンダー2024-25 + 営業時間別SLO + リリース凍結窓 + Toil削減判定)
│     ── Phase 13 法令ライブ追跡 ──
│     + law_tracker.ts (NEW: e-Gov 9法令カタログ + diffLawVersions + 通知ルーター)
│     + case_law.ts (NEW: 判例7件 ハマキョウレックス/大阪医科薬科/ベネッセ/JAL管財 + DAMAGE_BENCHMARKS)
│     ── Phase 14 横断学習 ──
│     + pattern_library.ts (NEW: 7 STANDARD_PATTERNS + 4 STANDARD_ANTIPATTERNS + Knowledge Graph)
│     ── Phase 15 公共調達+金融 ──
│     + public_sector.ts (入札方式/評価/補助金6種/検査調書/デジタル庁ガイドライン/自治体20基幹業務)
│     + finance.ts (全銀フォーマット120バイト/AML/金商法適合性原則/J-CSIP/暗号資産規制)
│     ── Phase 16 政府電子申請 (NEW v2015.9) ──
│     + gov_eapps.ts (NEW: 法人番号13桁mod9検証 / GビズID Prime/Member/Entry / e-Tax XML / eLTAX PCdesk / e-Gov 社会保険 / jGrants 補助金API)
│     ── Phase 17 教育機関 (NEW v2015.9) ──
│     + education.ts (NEW: 学校教育法 / 学習指導要領R2 / 指導要録(学籍20年指導5年保存) / 観点別評価ABC / 評定1-5 / 不登校30日年判定 / IRT 1PL/2PL/3PL+EAP推定 / SCORM 1.2/2004/xAPI/cmi5/LTI 1.3)
│     ── Phase 18 不動産業 (NEW v2015.9) ──
│     + real_estate.ts (NEW: 宅建業法 / 媒介契約3種 / レインズ5-7日登録 / R6低廉特例報酬 / 35条書面21項目 / 心理的瑕疵R3.10ガイドライン)
│     ── Phase 19 物流運輸 (NEW v2015.9) ──
│     + logistics.ts (NEW: 改善基準告示R6.4 拘束13h休息11h連続運転4h / 運行管理者 車両30両1名 / 点呼アルコール0.15mg/L / 標準的な運賃 / Greedy TSP / Haversine距離 / 過積載判定)
│     ── Phase 20 観光宿泊 (NEW v2015.9) ──
│     + tourism.ts (NEW: 旅館業法 / 民泊180日上限 / 簡易宿所33㎡ / 宿泊税5自治体 / 旅行業1〜3種 / 旅程管理主任者 / 入湯税150円 / 免税R6改正 / JNTO / TIC観光案内所)
│     ── Phase 21 Customer Intelligence Suite (学習データ駆動・顧客UX強化) ──
│     + learning_analytics.ts (NEW: 学習データ集計 + 戦略ランキング + ドメインカバレッジ + 次アクション提案)
│     + usage_insights.ts (NEW: モジュール利用統計 + フェーズタイミング + フックブロッカー + 30日トレンド)
│     + feature_recommender.ts (NEW: 業種別バンドル + 共通バックボーン + 推薦理由 + 品質期待値)
│     + hr_payroll.ts (NEW: 給与計算 + 社保 + 源泉 + 算定基礎 + 賞与 + 36協定 + 育児介護休業)
│     + marketing_compliance.ts (NEW: 景表法5条 + ステマ規制 + 特商法 + 薬機法 + 食品表示 + 特電法 + 個情法26条)
│     + customer_journey.ts (NEW: RFM + LTV + チャーン + セグメント10種 + 業種別アクション)
│   )
├── components/japan/ 9ファイル
├── templates/japan/ 21ファイル (20帳票 + _common)
├── enterprise/ (SAML/OIDC + Offline/閉域網)
├── schemas/ + contrib/ (validate_domain.sh v3)
├── quality/ (JP-Quality Fortress v8 runnable shell — 24軸240点 Platinum/Diamond)
├── scripts/ (jp_inject.sh + distill_patterns.mjs)
├── estimates/ (unit_prices.json) + regions/ (47prefectures/index.json)
├── examples/ 25本 (01〜10 既存 + 11 商習慣 / 12 ringi / 13 医療 / 14 介護 / 15 incident / 16 bcp+sre / 17 law_tracker / 18 pattern_library / 19 public_sector / 20 finance / 21 gov_eapps / 22 education / 23 real_estate / 24 logistics / 25 tourism)
├── quality/ (JP-Quality Fortress **v9 runnable shell — 29軸290点 Diamond認定**)
├── tests/
│     ├── phase6_self_check.mjs (6件)
│     ├── phase7_bug_prevention_runtime.mjs (10件)
│     ├── phase9_knowledge_check.mjs (10件)
│     ├── phase10_business_practice_check.mjs (6件)
│     ├── phase11_medical_care_check.mjs (4件)
│     ├── phase12_operations_check.mjs (6件)
│     ├── phase13_law_tracker_check.mjs (4件)
│     ├── phase14_pattern_library_check.mjs (4件)
│     ├── phase15_public_finance_check.mjs (4件)
│     ├── phase16_gov_eapps_check.mjs (NEW v2015.9: 3件)
│     ├── phase17_education_check.mjs (NEW v2015.9: 3件)
│     ├── phase18_real_estate_check.mjs (NEW v2015.9: 3件)
│     ├── phase19_logistics_check.mjs (NEW v2015.9: 3件)
│     ├── phase20_tourism_check.mjs (NEW v2015.9: 3件)
│     └── phase21_customer_intelligence_check.mjs (20件)
└── CHANGELOG.md (Phase 1→...→20 変更履歴)
```

### Phase 20 自己検証結果 (2026-04-25 v2015.9)

| Test | 件数 | 結果 |
|------|------|------|
| phase6_self_check.mjs | 6 | **6/6 PASS** |
| phase7_bug_prevention_runtime.mjs | 10 | **10/10 PASS** |
| phase9_knowledge_check.mjs | 10 | **10/10 PASS** |
| phase10_business_practice_check.mjs | 6 | **6/6 PASS** |
| phase11_medical_care_check.mjs | 4 | **4/4 PASS** |
| phase12_operations_check.mjs | 6 | **6/6 PASS** |
| phase13_law_tracker_check.mjs | 4 | **4/4 PASS** |
| phase14_pattern_library_check.mjs | 4 | **4/4 PASS** |
| phase15_public_finance_check.mjs | 4 | **4/4 PASS** |
| phase16_gov_eapps_check.mjs (Phase 16 NEW) | 3 | **3/3 PASS** |
| phase17_education_check.mjs (Phase 17 NEW) | 3 | **3/3 PASS** |
| phase18_real_estate_check.mjs (Phase 18 NEW) | 3 | **3/3 PASS** |
| phase19_logistics_check.mjs (Phase 19 NEW) | 3 | **3/3 PASS** |
| phase20_tourism_check.mjs (Phase 20 NEW) | 3 | **3/3 PASS** |
| phase21_customer_intelligence_check.mjs | 20 | **20/20 PASS** |
| **合計** | **89** | **89/89 PASS** |

JP-Quality Fortress **v9** 自己採点: **290/290 = Diamond ★★★★★**（29軸290点満点 / 認定Tier: Reject<240 / Gold 240-259 / Platinum 260-281 / Diamond 282-290）

### Phase 15 自己検証結果 (2026-04-23)

| Test | 件数 | 結果 |
|------|------|------|
| phase6_self_check.mjs | 6 | **6/6 PASS** |
| phase7_bug_prevention_runtime.mjs | 10 | **10/10 PASS** |
| phase9_knowledge_check.mjs | 10 | **10/10 PASS** |
| phase10_business_practice_check.mjs | 4 | **PASS** |
| phase11_medical_care_check.mjs | 4 | **4/4 PASS** |
| phase12_operations_check.mjs | 6 | **6/6 PASS** |
| phase13_law_tracker_check.mjs | 4 | **4/4 PASS** |
| phase14_pattern_library_check.mjs | 4 | **4/4 PASS** |
| phase15_public_finance_check.mjs | 4 | **4/4 PASS** |
| phase21_customer_intelligence_check.mjs (Phase 21 NEW) | 20 | **20/20 PASS** |
| **合計** | **72** | **72/72 PASS** |

JP-Quality Fortress v8 自己採点: **222/240 = Platinum ★★★★**（24軸240点満点 / 認定Tier: Reject<200 / Gold 200-215 / Platinum 216-231 / Diamond 232-240）

### Phase 21 Customer Intelligence Suite (2026-04-26 NEW)

**学習データ駆動・顧客UX強化**を目的とした追加スイート。並行セッションが進めている Phase 16-20 (gov_eapps / education / real_estate / logistics / tourism) と完全独立。

**6 モジュール (TypeScript)**:
1. `learning_analytics.ts` — `~/.soloptilink/learning/*.jsonl` から戦略ランキング・ドメインカバレッジ・次アクション提案を抽出
2. `usage_insights.ts` — モジュール利用統計・フェーズタイミング・フックブロッカー・30日トレンド (rising/declining)
3. `feature_recommender.ts` — 業種別バンドル6種 (construction/healthcare/longterm_care/finance/retail/it) + 共通バックボーン3種 (save_guarantee/ロール小文字/監査ログ)
4. `hr_payroll.ts` — 給与計算 + 社保 (協会けんぽ料率) + 源泉所得税 + 算定基礎届 + 賞与支払届 + 36協定上限チェック (一般則/特別条項) + 有給5日付与義務 + 育児介護休業
5. `marketing_compliance.ts` — 景表法第5条 (優良/有利誤認) + ステマ規制 (2023年10月) + 特商法 + 薬機法66条 + 食品表示法 (特定原材料8品目) + 特電法 (オプトイン) + 個情法第26条 R4改正
6. `customer_journey.ts` — RFM スコアリング + LTV 予測 + チャーン予測 + セグメント10種分類 (Champion/Loyal/At-Risk等) + 業種別アクションテンプレ

**5 業種辞書 (JSON)**: hr (人事労務) / franchise (FC本部・加盟店) / dental (歯科診療所) / pharmacy (薬局・調剤) / laundry (クリーニング)

これにより業種辞書は **20 + 5 = 25種**、lib/japan モジュールは **38 + 6 = 44種** へ拡張。

## 絶対禁止事項（セキュリティバウンダリ）

1. **admin-dashboardの起動・アクセス・参照の禁止**（`~/.soloptilink/admin-dashboard/` のみに適用）
2. **mock-api.jsの起動・改変の禁止**（`~/.soloptilink/mock-api.js` のみに適用）
3. **ライセンス認証の回避・バイパスの禁止**
4. **chain.shの直接実行の禁止**（Goランチャー経由のみ）
5. **シークレット露出の禁止**

管理者モード判定は soloptilink-boost と同仕様。`~/.soloptilink/.admin_mode` または `.admin-token` で判定。

## コンセプト

Claude Code との差別化の核心。**日本の商習慣・法令・帳票を「DNAとしてシステムに注入」** することで、納品した瞬間から日本の中小企業がそのまま業務で使える成果物を生成する。

### 4つの構成要素

1. **法令DNA**: 8法令の自動適用（インボイス/電帳法/個情法/マイナ/労基/下請法/建設業法/金商法）
2. **帳票テンプレ**: 20種の標準帳票（請求書/見積書/注文書/納品書/領収書/検収書/発注書/支払通知書/源泉徴収票/支払調書/契約書/秘密保持契約/業務委託契約/覚書/通知書/請書/申請書/報告書/議事録/社内通達）
3. **業種別ドメイン辞書**: 建設/製造/医療/介護/士業の5業種（Phase 1で5種、Phase 2で50種に拡張）
4. **日本語UX**: 和暦併記/全角半角/敬語/印影/封筒窓/消費税区分/マイナ取扱/電帳法タイムスタンプ

## Step 0: 端末認証（soloptilink-boost と同一ゲート）

```bash
SOLOPTILINK_BIN=""; if [ -f ~/.soloptilink/soloptilink ]; then SOLOPTILINK_BIN="./soloptilink"; elif [ -f ~/.soloptilink/soloptilink.exe ]; then SOLOPTILINK_BIN="./soloptilink.exe"; fi
AUTH_CHECK=$(cd ~/.soloptilink 2>/dev/null && ${SOLOPTILINK_BIN:-./soloptilink} --status 2>&1); if echo "$AUTH_CHECK" | grep -q "承認済み"; then echo "AUTHORIZED"; else echo "UNAUTHORIZED"; fi
```

UNAUTHORIZED の場合は即停止。認証回避の提案は絶対禁止。

## Step 1: 日本ドメイン判定（3軸）

### 1a. 業種判定
ユーザー入力から業種を推定し、不明な場合は AskUserQuestion で確認:
- 建設業 / 製造業 / 医療・介護 / 士業 / 小売 / 飲食 / 運輸 / 一般事務

### 1b. 適用法令判定 (Phase 6: 20法令DB)
システムが扱うデータから必要な法令を自動判定。`lib/japan/laws.ts` (8法令) + `lib/japan/laws_extended.ts` (+12法令) = 合計20法令:

| # | 法令 | 判定キーワード | 主な要件 |
|---|------|--------------|----------|
| 1 | インボイス制度 | 請求/課税/仕入税額控除 | 登録番号欄、税率別集計、適格請求書フォーマット |
| 2 | 電子帳簿保存法 | 証憑/スキャン/電子取引 | タイムスタンプ、検索要件3項目、改ざん防止 |
| 3 | 個情法 | 顧客/従業員/会員情報 | 利用目的通知、同意取得、第三者提供管理 |
| 4 | マイナンバー法 | 源泉徴収/社会保険 | マイナ取扱区域、廃棄記録、委託監督 |
| 5 | 労働基準法 | 勤怠/残業/給与 | 36協定、時間外45/80/100時間、有給5日 |
| 6 | 下請法 | 発注/下請/外注 | 3条書面、支払遅延、買いたたき禁止 |
| 7 | 建設業法 | 工事/建設/請負 | 許可番号、技術者配置、一括下請禁止 |
| 8 | 金商法 | 証券/投資/運用 | 広告規制、適合性原則、説明義務 |
| 9 | PL法 (Phase 6) | 製造/加工/販売 | 製造物責任、時効3年/10年、警告表示 |
| 10 | 景品表示法 (Phase 6) | 懸賞/景品/キャンペーン/広告 | 懸賞額上限、優良誤認、二重価格 |
| 11 | 特定商取引法 (Phase 6) | 通販/訪販/電話勧誘/連鎖 | クーリングオフ、表示義務、不実告知禁止 |
| 12 | 食品衛生法 (Phase 6) | 飲食/食品製造/調理 | HACCP、営業許可32業種、食中毒届出24h |
| 13 | 食品表示法 (Phase 6) | 加工食品/アレルゲン | 必須表示、特定原材料8品目、栄養成分5項目 |
| 14 | 薬機法 (Phase 6) | 化粧品/健康食品/医療機器 | 効能効果範囲、医薬品的表現禁止 |
| 15 | 旅館業法 (Phase 6) | 宿泊/ホテル/旅館/民泊 | 宿泊者名簿、保存3年、民泊180日以下 |
| 16 | 宅建業法 (Phase 6) | 不動産/仲介/媒介 | 重要事項説明15項目、媒介3種類、報酬上限 |
| 17 | 児童福祉法 (Phase 6) | 保育/こども/学童 | 保育士配置基準、虐待4類型、通告義務 |
| 18 | 労働安全衛生法 (Phase 6) | 50人以上/製造/建設 | 産業医、ストレスチェック、安全管理者 |
| 19 | 育児介護休業法 (Phase 6) | 育休/産休/介護 | 育休1歳・産後パパ28日・介護93日 |
| 20 | 労働者派遣法 (Phase 6) | 派遣/スタッフ | 3年制限、禁止業務、同一労働同一賃金 |

### 1c. 必要な帳票タイプ判定
20帳票から使用するものを選定:

```
基本7: 請求書/見積書/注文書/納品書/領収書/検収書/発注書
支払3: 支払通知書/源泉徴収票/支払調書
契約4: 契約書/NDA/業務委託/覚書
通知6: 通知書/請書/申請書/報告書/議事録/社内通達
```

## Step 2: ドメイン辞書読み込み

`~/.claude/skills/soloptilink-japan/domains/<industry>.json` を読み込み、業種固有の用語・慣習・UIパターンを注入。

Phase 1 実装範囲（5業種）:
- `construction.json` - 建設業（工種/工程/積算/一括下請/建退共）
- `manufacturing.json` - 製造業（BOM/ロット/原価/品管/FSSC22000）
- `healthcare.json` - 医療介護（レセプト/カルテ/加算算定/個情強化）
- `professional.json` - 士業（税理士/社労士/行政書士の業務要件）
- `retail.json` - 小売（POS/在庫/軽減税率/ポイント）

Phase 2 で追加する15業種: 飲食/運輸/物流/不動産/建築設計/IT/広告/美容/フィットネス/塾/保育/農業/漁業/ホテル/ブライダル

## Step 3: Japan Pack 注入

Step 1〜2 の判定結果から、以下を対象プロジェクトに注入:

### 3a. 法令DNAライブラリ
`lib/japan/laws.ts` を生成し、各法令の判定・計算関数を提供:

```typescript
// 例: インボイス登録番号検証
export function validateInvoiceNumber(no: string): boolean { /* T + 13桁数字 */ }

// 例: 電帳法タイムスタンプ付与
export function attachTimestamp(file: Buffer): TimestampedFile { /* JIIMA認定 */ }

// 例: 源泉徴収税額計算
export function calcWithholdingTax(amount: number, type: 'designer' | 'lecturer' | ...): number

// 例: 36協定違反検知
export function check36Agreement(workHours: WorkHour[]): Violation[]
```

### 3b. 帳票テンプレ
`templates/japan/<document-type>.html.tsx` を生成。日本の慣習（印影位置、封筒窓対応、但し書き、振込先、注記）を完備。

### 3c. 日本UXコンポーネント
`components/japan/` に以下を配置:
- `<WarekiDate />` - 和暦併記（令和6年4月21日 / 2026-04-21）
- `<HanzenInput />` - 全角半角自動変換入力
- `<KeigoText />` - 敬語レベル自動調整
- `<InshoSeal />` - 印影画像アップロード＆配置
- `<TaxRateSelector />` - 10%/軽減8%/非課税の区分選択
- `<MyNumberField />` - マイナ入力欄（マスク+audit）
- `<PostalCodeInput />` - 郵便番号→住所自動補完（日本郵便API）
- `<PhoneInput />` - 日本固有の電話番号フォーマット

### 3d. バグ予防DNA (Phase 6 新機能)

`lib/japan/save_guarantee.ts` と `lib/japan/bug_prevention.ts` を注入。
日本の業務システムで頻出する「保存できない系」バグを**生成時点で根絶**する予防層。

**save_guarantee.ts** — 保存エラー15パターンを封じ込める:
| # | バグパターン | 予防策 |
|---|------------|--------|
| P1 | CSRF トークン欠落 → 403 | `generateIdempotencyKey` + `withIdempotency` |
| P2 | zod スキーマ不一致 → 422 | `diagnoseSaveFailure` が `VALIDATION_FAILED` を日本語化 |
| P3 | unique 制約違反を握り潰す | `UNIQUE_VIOLATION` 検知 + フィールド名の日本語化 |
| P4 | トランザクション外の複数書込 → 孤児 | `SaveGuarantee.ensure(tx => ...)` でラップ |
| P5 | 楽観ロックなしの同時編集 | `buildOptimisticWhere` で version/updated_at 条件付加 |
| P6 | Content-Type 取り違え | 統一ラッパで FormData/JSON 自動判別 |
| P7 | Date/Decimal シリアライズ欠落 | `jstToUtcIso` / `utcToJstDisplay` |
| P8 | NOT NULL への undefined → 23502 | `NOT_NULL_VIOLATION` をフィールド単位でエラー返却 |
| P9 | FK 違反の不可解メッセージ | `FK_VIOLATION` を「関連する項目が見つかりません」に |
| P10 | 非同期 onClick の多重発火 | Idempotency-Key で自動冪等化 |
| P11 | エラー時のスピナー永続化 | `SaveGuarantee.ensure` が必ず result を返す |
| P12 | field レベルエラー非対応 | `fieldErrors` マップで赤字表示 |
| P13 | サロゲートペア/絵文字半切れ | `truncateSafe` で code point 単位切断 |
| P14 | JST/UTC 混在で日付ズレ | `jstToUtcIso` 必須化 |
| P15 | 楽観更新の rollback 欠落 | ラッパが失敗時に throw してトランザクション巻戻し |

**bug_prevention.ts** — 日本固有の計算/表記バグを予防:
- `calcTax` / `groupAndCalcTax` — インボイス制度の「税率ごとに1回」端数処理
- `formatYen` / `parseYen` — 全角数字・¥/￥/△ 混在を安全にパース
- `normalizePhoneJP` / `formatPhoneJP` — 携帯/固定/IP/フリーダイヤル別フォーマット
- `normalizePostalJP` / `formatPostalJP` — 〒 と全半角混在を正規化
- `toCsvJP` — UTF-8 BOM + CRLF + CSV Injection 対策 (`=+-@` prefix)
- `attachHonorific` — 様/御中 の二重付与防止
- `calcPaymentDueDate` — 月末締翌月末払い等の商慣習日計算
- `Brand<T, 'SaveGuaranteed'>` 型 — 保存時に必ず通すべき関数を静的に強制

引数 `--bug-prevention strict` 指定時は全関数呼び出し箇所を AST 走査し、
未経由の raw input を検出したら build エラーとする（Phase 6 新規）。

## Step 4: 日本最適化品質ゲート（15軸 - JP-Quality Fortress v4）

| # | 検証軸 | チェック内容 | 基準 |
|---|--------|------------|------|
| 1 | 和暦対応 | 日付表示に和暦併記または切替可能か | 必須フィールドの80%以上 |
| 2 | 全角半角 | 数字・英字・記号の正しい全半角区別 | 金額は半角、氏名住所は全角 |
| 3 | 敬語 | 顧客向け文言が尊敬・謙譲の区別 | システムメッセージ全件 |
| 4 | 消費税区分 | 10%/軽減8%/非課税/不課税の区分 | 全取引データ |
| 5 | インボイス | 登録番号欄と税率別集計 | 請求書に必須 |
| 6 | 源泉徴収 | 個人取引時の自動計算 | 支払先種別判定 |
| 7 | マイナ | 取扱範囲の最小化・audit | 源泉・社保系のみ |
| 8 | 電帳法 | タイムスタンプ・検索3要件 | 証憑データ全件 |
| 9 | 個情法 | 利用目的・同意・第三者提供管理 | 個人データ取得時 |
| 10 | 業種適合 | ドメイン辞書の用語・フロー一致 | 業種別テストケース合格 |
| 11 | i18n | locale prop 対応、ja/en/zh-CN 切替 | 全 UI コンポーネント |
| 12 | Enterprise | SSO/Offline/監査ログ準拠 | エンタープライズ判定時 |
| 13 | **バグ予防** (Phase 6) | `SaveGuarantee.ensure` 経由の書込み率 | CRUD API の 100% |
| 14 | **金額整合性** (Phase 6) | `calcTax` 以外の税計算の不在 | 全帳票・集計 |
| 15 | **拡張法令** (Phase 6) | PL/景表/特商/食衛/食表/薬機/旅館/宅建/児福/安衛/育介/派遣 の業種別適用 | ドメイン辞書と整合 |

**スコアリング (v4 Phase 6)**: 各軸 10 点満点 × 15 軸 = 150 点。
- 120点未満: 納品禁止 (修復ループへ)
- 120〜134: Gold (標準納品可)
- 135〜144: Platinum ★★★★
- 145〜150: **Diamond ★★★★★** (Japan-Native Certified 付与、販促利用可)

80 点未満で納品された場合は既存 `/soloptilink-deploy --rollback` で巻き戻し (Phase 6 連携)。

## Step 5: 生成・検証

1. Agent 並列で法令DNA注入、帳票テンプレ展開、業種UI生成
2. JP-Quality Fortress で 10軸検証
3. 日本語テストデータでCRUD往復
4. 印刷プレビュー確認（帳票がA4に収まるか）
5. 完了報告時に「適用法令」「搭載帳票」「対象業種」を明示

## BOOST統合

`/soloptilink-boost` が Step 0.3 Intent Classification で以下を検出した場合、このスキルを自動呼び出し:
- 業種キーワード（建設/製造/医療/介護/士業/小売/飲食/運輸）
- 法令キーワード（インボイス/電帳法/個情法/マイナ/労基/下請法/建設業法/金商法）
- 帳票キーワード（請求書/見積書/注文書/納品書/源泉/社保/給与計算）
- 日本特化キーワード（和暦/全角半角/敬語/印影/封筒窓）

BOOST Pre-Flight の P4 質問に「業種」「必要帳票」を追加し、このスキルに結果を渡す。

## 使用例

```
/soloptilink-japan 建設業向けの原価管理システム作って
→ construction.json 読み込み → 建設業法+インボイス+下請法+電帳法適用 → 7帳票自動生成

/soloptilink-japan 社労士事務所の顧問先管理システム
→ professional.json 読み込み → 労基+マイナ+個情強化 → 給与計算+源泉+社保完備

/soloptilink-japan 小売の在庫・売上管理（軽減税率対応）
→ retail.json 読み込み → インボイス+電帳法+POS連携 → 軽減8%区分フル対応
```

## Quality Fortress Checklist

- [ ] 業種別ドメイン辞書が読み込まれていること
- [ ] 適用法令が明示されていること
- [ ] 法令DNAライブラリ（lib/japan/laws.ts）が生成されていること
- [ ] 必要な帳票テンプレが全て配置されていること
- [ ] 日本UXコンポーネントが全ページで使用されていること
- [ ] JP-Quality Fortress 10軸で80点以上
- [ ] 印刷プレビューでA4に収まること（帳票）
- [ ] タイムスタンプ付与機構が動作すること（電帳法対象システム）
- [ ] マイナ取扱範囲が最小化されていること
- [ ] 全角半角の混在エラーがないこと
- [ ] 日本語テストデータでCRUD全PASS

## Phase 別拡張計画

- **Phase 1 (5〜7月)**: 5業種 × 8法令 × 20帳票 = 800組合せカバー
- **Phase 2 (8〜10月)**: 20業種に拡張、Visual Confirm Loop統合
- **Phase 3 (11月〜)**: パートナーSIerがドメイン辞書をカスタム投稿できるマーケット化

## セッション永続化

`/soloptilink-japan` で起動したセッションは `.soloptilink-japan-session.json` をプロジェクトルートに生成し、以降の会話でも適用法令・業種判定を継続する。BOOST連携時は boost セッションに japan フラグを追加。
