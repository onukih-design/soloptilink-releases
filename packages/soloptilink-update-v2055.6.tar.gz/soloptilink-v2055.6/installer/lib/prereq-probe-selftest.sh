#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# 前提ソフト判定の両側検証
#
# 【なぜ要るか】導入の検査は「Node.js が【無い】端末」は模擬していたが、
#   「部品は【在る】が動かない端末」を模擬していなかった。そのため、
#   その組み合わせで起きる不具合を検査がすり抜けていた。
#
# 【この検査が見るもの】
#   S1 開発ツール未導入 (git / python3 が入口だけ在って実行できない)
#   S2 python3 が動かない状態で、Node の判定が正しく呼び出し側へ伝わるか
#   S3 判定が空のとき「用意できませんでした」ではなく「判定できません」と出るか
#   S4 正常な端末で従来どおり動くか (回帰が無いこと)
#
# 【両側弁別】健全な検体で PASS し、欠陥のある検体 (修正前の実装) で FAIL する
#   ことを同じ実行の中で示す。片側だけの検査は「何を与えても PASS する検査」と
#   区別がつかないため、無効とする。
#
# 使い方: bash prereq-probe-selftest.sh [--json]
# ---------------------------------------------------------------------------
set -uo pipefail

PPS_SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd)"
PPS_SETUP="${PPS_SETUP:-$PPS_SELF_DIR/../SoloptiLinkAI-Setup.command}"
PPS_NODEPROV="${PPS_NODEPROV:-$PPS_SELF_DIR/node-provision.sh}"

PASS_N=0; FAIL_N=0; NA_N=0
RESULTS=""

_ok()   { PASS_N=$((PASS_N+1)); RESULTS="${RESULTS}  ✅ $1\n"; }
_ng()   { FAIL_N=$((FAIL_N+1)); RESULTS="${RESULTS}  ❌ $1\n"; }
# 対象外 = 「この検体には設計上存在しないもの」。合格にも不合格にもせず、理由つきで開示する。
# ★「取れなかった」と「そもそも無い」を混ぜると、正常な状態で検査が落ちて無効化に倒れる
#   (2026-08-14 実測: 回収経路は配布物へ同梱しない設計なのに、出荷物での不在を欠陥と読んで配信が止まった)。
_na()   { NA_N=$((NA_N+1));  RESULTS="${RESULTS}  ➖ $1\n"; }
_judge(){ if [ "$1" = "$2" ]; then _ok "$3 (期待=$2 実測=$1)"; else _ng "$3 (期待=$2 実測=$1)"; fi; }

# --- 検体置き場 (実HOMEに触れない) -----------------------------------------
SB="$(mktemp -d 2>/dev/null)" || { echo "作業領域を作れません" >&2; exit 2; }
trap 'rm -rf "$SB" 2>/dev/null || true' EXIT

# 開発ツール未導入の macOS を模した検体を作る。
#   実機の /usr/bin/git は「入口(シム)」で、存在はするが実行すると失敗する。
#   その挙動を、非ゼロで終了し何も出力しない実行ファイルで再現する。
mk_shim() {           # $1 = 名前
    printf '#!/bin/sh\nexit 1\n' > "$SB/bin/$1"
    chmod +x "$SB/bin/$1"
}
mk_real_python() {    # 正常に動く python3 を用意する (健全側)
    local p; p="$(command -v python3 2>/dev/null || true)"
    [ -n "$p" ] && ln -sf "$p" "$SB/bin/python3"
}
mk_fake_node() {      # $1 = 版数
    printf '#!/bin/sh\n[ "$1" = "-v" ] && { echo "%s"; exit 0; }\necho "%s"\n' "$1" "$1" > "$SB/bin/node"
    chmod +x "$SB/bin/node"
}
mkdir -p "$SB/bin"

# 判定関数だけを Setup.command から取り出して一時ファイルへ置く
#   (.command 全体を実行すると導入が走ってしまうため、関数定義部だけを抜き出す)
#   ★検体側では PATH を絞るため、取り出しは PATH を絞る【前】に済ませておく
#     (絞った中で sed を呼ぶと sed 自体が見つからず、製品ではなく検体が壊れる)
PROBE_LIB="$SB/probe.sh"
sed -n '/^prereq_probe() {/,/^}/p' "$PPS_SETUP" > "$PROBE_LIB" 2>/dev/null || true
if [ ! -s "$PROBE_LIB" ]; then
    echo "判定関数を取り出せませんでした (検査を実行できません = 未測定)" >&2
    exit 2
fi

# ===========================================================================
# S1: 開発ツール未導入 — 入口はあるが実行できない
# ===========================================================================
s1_probe_verdict() {
    # $1 = "fixed" (是正後の判定) / "legacy" (是正前の存在確認だけの判定)
    local mode="$1" out
    out="$(
        PATH="$SB/bin:/usr/bin:/bin"
        if [ "$mode" = "legacy" ]; then
            # 【是正前の実装】存在確認だけ。入口があれば「使える」と判定していた
            if command -v git >/dev/null 2>&1; then printf 'available'; else printf 'absent'; fi
        else
            # shellcheck disable=SC1090
            . "$PROBE_LIB"
            PREREQ_VER=""
            prereq_probe git --version 'git version [0-9]'
        fi
    )"
    printf '%s' "$out"
}

mk_shim git
_judge "$(s1_probe_verdict fixed)"  "present_but_broken" \
    "S1 是正後: 入口だけの git を『存在するが動かない』と判定する"
_judge "$(s1_probe_verdict legacy)" "available" \
    "S1 是正前: 同じ検体を『使える』と誤判定していた (欠陥側の再現)"

# S1b: 入口ごと無い場合は absent (真の未導入と区別できること)
#   git を PATH から完全に外す (実機の /usr/bin/git を拾わないよう $SB/bin だけにする。
#   absent は command -v の時点で確定するので、他の外部コマンドには到達しない)
rm -f "$SB/bin/git"
_judge "$( PATH="$SB/bin"; . "$PROBE_LIB"; prereq_probe git --version 'git version [0-9]' )" \
    "absent" "S1b 入口ごと無い端末は『未導入』と判定する"

# S1c: 正常に動く場合は available (回帰が無いこと)
printf '#!/bin/sh\necho "git version 2.39.0"\n' > "$SB/bin/git"; chmod +x "$SB/bin/git"
_judge "$( PATH="$SB/bin:/usr/bin:/bin"; . "$PROBE_LIB"; prereq_probe git --version 'git version [0-9]' )" \
    "available" "S1c 正常な端末では従来どおり『使える』と判定する"

# ===========================================================================
# S2: python3 が動かない状態で、Node の判定が呼び出し側へ伝わるか
#     (開発ツール未導入の端末で、正常な Node.js を「用意できませんでした」と
#      誤報告する経路があったため)
# ===========================================================================
s2_verdict() {
    # $1 = "broken_python" / "ok_python"
    local mode="$1"
    rm -f "$SB/bin/python3"
    [ "$mode" = "broken_python" ] && mk_shim python3 || mk_real_python
    mk_fake_node "v24.19.0"
    (
        export NP_HOME="$SB/home" NP_SOLOPTILINK="$SB/home/.soloptilink"
        export NP_VAR_DIR="$SB/home/.soloptilink/var"
        export NP_RUNTIME_DIR="$SB/home/.soloptilink/runtime/node"
        export SOLOPTILINK_NODE_TARBALL=off SOLOPTILINK_NODE_BREW=off
        mkdir -p "$NP_VAR_DIR"
        PATH="$SB/bin:/usr/bin:/bin"
        # shellcheck disable=SC1090
        . "$PPS_NODEPROV" 2>/dev/null
        node_provision_ensure >/dev/null 2>&1
        printf '%s' "${NODE_PROVISION_VERDICT:-<空>}"
    )
}

_judge "$(s2_verdict ok_python)" "PASS" \
    "S2a python3 が動く端末: Node 判定が伝わる (回帰なし)"
_judge "$(s2_verdict broken_python)" "PASS" \
    "S2b python3 が動かない端末でも Node 判定が伝わる (★最重要)"

# ===========================================================================
# S3: 判定が空のとき、誤った導入案内を出さないか
# ===========================================================================
s3_message() {
    # $1 = "fixed" / "legacy"。判定が空の状態で、お客様に何と表示されるかを見る
    local mode="$1" verdict="" version="v24.19.0"
    if [ "$mode" = "legacy" ]; then
        # 【是正前】空は「*」に落ち、既定文言 (nodejs.org から導入) が出ていた
        case "$verdict" in
            PASS) printf '使える' ;;
            *)    printf 'nodejs.org から導入してください' ;;
        esac
    else
        # 【是正後】空は専用の枝で受け、導入案内へ落とさない
        case "$verdict" in
            PASS) printf '使える' ;;
            "")   if [ -n "$version" ]; then printf '判定できませんでした(導入済み)'; else printf '判定できませんでした'; fi ;;
            *)    printf 'nodejs.org から導入してください' ;;
        esac
    fi
}
_judge "$(s3_message fixed)"  "判定できませんでした(導入済み)" \
    "S3 是正後: 判定不能を『判定できません』と伝える"
_judge "$(s3_message legacy)" "nodejs.org から導入してください" \
    "S3 是正前: 既に入っている Node の導入を促す誤案内だった (欠陥側の再現)"

# ===========================================================================
# S4: 是正後の実装に、存在確認だけで合格させる書き方が残っていないか
# ===========================================================================
s4_leftovers() {
    # 前提ソフトの判定で command -v の結果だけを [skip] に直結している行を探す
    grep -nE 'if command -v (git|python3) >/dev/null 2>&1; then' "$PPS_SETUP" 2>/dev/null | wc -l | tr -d ' '
}
_judge "$(s4_leftovers)" "0" "S4 存在確認だけで合格させる判定が残っていない"

# ===========================================================================
# S5: 自動更新が「入口だけの python3」で止まらないか (v2040 固着デッドロックの経路)
#     自動更新には python3 が使えない端末向けの代替経路が実装済みだったが、
#     その入口の判定が存在確認だけだったため、代替経路へ到達できなかった。
# ===========================================================================
PPS_AUTOUPD="${PPS_AUTOUPD:-$PPS_SELF_DIR/../../auto-update.sh}"
s5_fallback_reachable() {
    # $1 = "fixed" / "legacy"。入口だけの python3 がある端末で、代替経路に入れるか
    local mode="$1"
    rm -f "$SB/bin/python3"; mk_shim python3
    (
        PATH="$SB/bin:/usr/bin:/bin"
        if [ "$mode" = "legacy" ]; then
            HAS_PY3=0; command -v python3 >/dev/null 2>&1 && HAS_PY3=1
        else
            HAS_PY3=0
            if command -v python3 >/dev/null 2>&1 && python3 --version >/dev/null 2>&1; then HAS_PY3=1; fi
        fi
        # HAS_PY3=1 だと python3 経路が選ばれ、代替経路(sed)へ到達しない
        [ "$HAS_PY3" -eq 0 ] && printf '代替経路に到達' || printf 'python3経路を選択'
    )
}
_judge "$(s5_fallback_reachable fixed)" "代替経路に到達" \
    "S5 是正後: python3 が動かない端末で代替経路に到達する (v2040 固着を回避)"
_judge "$(s5_fallback_reachable legacy)" "python3経路を選択" \
    "S5 是正前: 同じ端末で代替経路に到達できず更新が止まっていた (欠陥側の再現)"

# S5b: 実装側にその是正が入っているか (巻き戻り検出)
if [ -f "$PPS_AUTOUPD" ]; then
    _s5b=$(grep -c 'python3 --version >/dev/null 2>&1' "$PPS_AUTOUPD" 2>/dev/null || true)
    _judge "$([ "${_s5b:-0}" -ge 1 ] && echo あり || echo なし)" "あり" \
        "S5b 自動更新の判定が実行可否ベースになっている"
else
    _ng "S5b 自動更新スクリプトが見つからず確認できない (未測定)"
fi

# ===========================================================================
# S6: 自動更新の登録を「実行した」ではなく「効いた」で判定しているか
#     この事象への対処。
#     実際に登録されたかを確かめていなかった。登録されていないまま
#     「以降は自動で最新版を取得します」と表示され、お客様は気づけない。
# ===========================================================================
s6_verify_wired() {
    grep -c '_hook_is_registered' "$PPS_SETUP" 2>/dev/null || true
}
_s6=$(s6_verify_wired)
_judge "$([ "${_s6:-0}" -ge 2 ] && echo あり || echo なし)" "あり" \
    "S6 自動更新の登録を実際に確認してから成功と表示する"

# S6b: その確認が python3 に依存していないこと
#      (依存すると、確認したい端末でこそ確認できないという自己矛盾になる)
s6b_no_py_dep() {
    # _hook_is_registered 関数の本体に python3 が出てこないこと
    sed -n '/^_hook_is_registered() {/,/^}/p' "$PPS_SETUP" 2>/dev/null | grep -c 'python3' || true
}
_judge "$(s6b_no_py_dep)" "0" "S6b 登録の確認が python3 に依存していない"

# ===========================================================================
# S7: 効かない案内が残っていないか
#     この事象への対処。
#     お伝えください」と案内していたが、チャットの中からは設定を書き換えられない
#     仕組みになっており、案内どおりにしても解決しない行き止まりだった。
# ===========================================================================
s7_dead_end() {
    grep -c 'チャット欄に「最新版にして」' "$PPS_SETUP" 2>/dev/null || true
}
_judge "$(s7_dead_end)" "0" "S7 効かない案内 (チャットから更新できる旨) が残っていない"

# ===========================================================================
# S8: 認証に失敗しても、要対応の一覧まで到達するか (Windows と同じ形か)
#     この事象への対処。
#     前提ソフト工程が積み上げた要対応一覧も自己診断も完了画面も出ないまま
#     終わっていた。お客様には「登録できませんでした」しか残らない。
# ===========================================================================
s8_failopen() {
    # 要対応一覧の行番号より手前に、認証失敗による打ち切りが残っていないか
    local l_issue l_exit
    l_issue=$(grep -n 'PREREQ_ISSUES\[@\]' "$PPS_SETUP" 2>/dev/null | head -1 | cut -d: -f1)
    [ -n "$l_issue" ] || { printf '判定不能'; return 0; }
    # 認証分岐の中に exit が残っていれば打ち切りが復活している
    l_exit=$(awk '/soloptilink --activate \|\| \{/,/^\}/' "$PPS_SETUP" 2>/dev/null | grep -c 'exit 1' || true)
    [ "${l_exit:-0}" -eq 0 ] && printf '到達する' || printf '打ち切られる'
}
_judge "$(s8_failopen)" "到達する" "S8 認証に失敗しても要対応一覧まで到達する (Windows と同じ形)"

# ===========================================================================
# S9: すでに登録済みなら入力を求めずに飛ばすか
#     再実行が救済にならず、毎回入力待ちへ戻る問題 (申告①の「放置したが完了しない」)
# ===========================================================================
s9_preskip() {
    grep -c '_ALREADY_REGISTERED' "$PPS_SETUP" 2>/dev/null || true
}
_s9=$(s9_preskip)
_judge "$([ "${_s9:-0}" -ge 3 ] && echo あり || echo なし)" "あり" \
    "S9 登録済みの端末では認証の入力を求めない (再実行が救済になる)"

# ===========================================================================
# S10: メニュー修復フックを顧客端末へ登録する経路が実在するか
#      この事象への対処。
#      宣言していたのに、登録する処理が本体のどこにも無かった (死配線)。
# ===========================================================================
s10_heal_wired() {
    grep -c 'session-start-skill-heal.sh' "$PPS_SETUP" 2>/dev/null || true
}
_s10=$(s10_heal_wired)
_judge "$([ "${_s10:-0}" -ge 2 ] && echo あり || echo なし)" "あり" \
    "S10 メニュー修復フックを登録する経路が実在する"

# ===========================================================================
# S11: 顧客に見せる版数が、代入の無い変数を参照していないか
#      この事象への対処。
#      測っていない値をエージェントが補完して断定していた。
# ===========================================================================
#   ★検査対象は2系統。スキル本文の正典は ~/.claude/commands/ 側であり、
#     配布物側 (~/.soloptilink/skills/) だけを直しても同期で巻き戻る。両方を見る。
PPS_UPG="${PPS_UPG:-$PPS_SELF_DIR/../../skills/soloptilink-upgrade/SKILL.md}"
PPS_UPG_CANON="${PPS_UPG_CANON:-$HOME/.claude/commands/soloptilink-upgrade.md}"
s11_undefined_var() {
    # 提示文に代入の無い変数が残っていないか ($CURRENT_VERSION は別物なので除外)。
    # ★「使ってはいけない」と説明している行そのものは検査対象から外す
    #   (自己参照による誤検知。除外しないと、直した本人の注意書きが違反として数えられる)。
    local n=0 f
    for f in "$PPS_UPG" "$PPS_UPG_CANON"; do
        [ -f "$f" ] || continue
        local c
        c=$(grep -vE '禁止|使わない|使うこと|原因はこれ' "$f" 2>/dev/null \
            | grep -oE '\$CURRENT([^_A-Z]|$)' 2>/dev/null | wc -l | tr -d ' ')
        n=$((n + ${c:-0}))
    done
    [ "${n:-0}" -eq 0 ] && printf 'なし' || printf "残存${n}件"
}
_judge "$(s11_undefined_var)" "なし" "S11 顧客提示文が代入の無い変数を参照していない (正典と配布物の両方)"

# S11b: 実測値を入れる変数が用意されているか (両系統)
s11b_measured() {
    local ok=0 f
    for f in "$PPS_UPG" "$PPS_UPG_CANON"; do
        [ -f "$f" ] || continue
        if grep -q 'CUR_LOCAL=' "$f" 2>/dev/null && grep -q 'SRV_LATEST=' "$f" 2>/dev/null; then
            ok=$((ok + 1))
        fi
    done
    [ "$ok" -ge 2 ] && printf 'あり' || printf "不足(${ok}/2)"
}
_judge "$(s11b_measured)" "あり" "S11b 実測値とサーバ申告値を別々に取る実装が両系統に入っている"

# ===========================================================================
# S12: 回収経路 (最後の砦) が「入口だけの python3」で止まらないか
#      回収は開発ツールが壊れた端末のための経路なのに、その解析関数が
#      存在確認だけで python3 経路を選び、sed 代替へ到達しない欠陥があった。
# ===========================================================================
PPS_RECOVER="${PPS_RECOVER:-$PPS_SELF_DIR/../../scripts/distribution/recover.sh}"
PPS_RECOVER_HOME_DIR="$(dirname "$PPS_RECOVER")"

# この検体で回収経路を測れる文脈かを判定する (3値)。
#   applicable   … 回収経路が在るべき場所で、実際に在る            → 通常どおり検査する
#   missing      … 在るべき場所なのに不在                          → 欠陥 (不合格)
#   not_shipped  … 配信対象外の領域ごと存在しない (＝出荷物の中)   → 対象外
# ★出荷物には配信用スクリプト群 (回収経路を含む) を一切同梱しない設計である。
#   顧客は回収エンドポイントの URL から直接取得して実行する。したがって出荷物の中に
#   無いことは欠陥ではない。ただし「無いから合格」にもしない — 対象外として開示する。
_pps_recover_context() {
    if [ -f "$PPS_RECOVER" ]; then printf 'applicable'; return 0; fi
    if [ -d "$PPS_RECOVER_HOME_DIR" ]; then printf 'missing'; return 0; fi
    printf 'not_shipped'
}
PPS_RECOVER_CTX="$(_pps_recover_context)"

s12_recover_guard() {
    [ -f "$PPS_RECOVER" ] || { printf '判定不能'; return 0; }
    # 実行可否を見ない python3 ガードが残っていないか
    local n
    n=$(grep -c 'command -v python3 >/dev/null 2>&1' "$PPS_RECOVER" 2>/dev/null || true)
    local ok
    ok=$(grep -c 'python3 --version >/dev/null 2>&1' "$PPS_RECOVER" 2>/dev/null || true)
    if [ "${n:-0}" -ge 1 ] && [ "${n:-0}" -eq "${ok:-0}" ]; then printf '全て実行可否ベース'
    elif [ "${n:-0}" -eq 0 ]; then printf 'python3不使用'
    else printf "存在確認だけが$((n-ok))件残存"; fi
}
if [ "$PPS_RECOVER_CTX" = "not_shipped" ]; then
    _na "S12 回収経路の python3 判定 — 対象外 (回収経路は配布物へ同梱せず、回収用の入口から直接取得して実行する設計。正典ツリーでは本検査が実走する)"
else
    _judge "$(s12_recover_guard)" "全て実行可否ベース" \
        "S12 回収経路の python3 判定が実行可否ベースになっている"
fi

# S12b: 実際に「入口だけの python3」で sed 代替に到達するか (実走)
s12b_fallback() {
    [ -f "$PPS_RECOVER" ] || { printf '判定不能'; return 0; }
    rm -f "$SB/bin/python3"; mk_shim python3
    (
        PATH="$SB/bin:/usr/bin:/bin"
        # _json_field 関数だけを取り出して実走する
        eval "$(sed -n '/^_json_field() {/,/^}/p' "$PPS_RECOVER")"
        _json_field '{"version":"2055.5"}' version
    )
}
if [ "$PPS_RECOVER_CTX" = "not_shipped" ]; then
    _na "S12b 回収の解析が sed 代替に到達するか — 対象外 (同上・正典ツリーでは実走で検証する)"
else
    _judge "$(s12b_fallback)" "2055.5" \
        "S12b 入口だけの python3 端末で回収の解析が sed 代替に到達する (実走)"
fi

# ===========================================================================
# 結果
# ===========================================================================
TOTAL=$((PASS_N+FAIL_N+NA_N))
if [ "${1:-}" = "--json" ]; then
    printf '{"gate":"prereq-probe-selftest","verdict":"%s","pass":%d,"fail":%d,"not_applicable":%d,"total":%d,"recover_context":"%s"}\n' \
        "$([ "$FAIL_N" -eq 0 ] && echo PASS || echo FAIL)" "$PASS_N" "$FAIL_N" "$NA_N" "$TOTAL" "$PPS_RECOVER_CTX"
else
    echo "前提ソフト判定 両側検証 (T-04/T-08):"
    printf "%b" "$RESULTS"
    echo "判定: $([ "$FAIL_N" -eq 0 ] && echo PASS || echo FAIL)  (合格 $PASS_N / 不合格 $FAIL_N / 対象外 $NA_N / 全 $TOTAL)"
fi
[ "$FAIL_N" -eq 0 ] && exit 0 || exit 1
